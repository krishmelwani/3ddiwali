"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [13146], {
        13146: (e, t, a) => {
            a.r(t), a.d(t, {
                cpWorldDiwaliTemplate: () => s
            });
            var i = a(62513);
            let l = "https://cdn.cutiepage.in/template-seeds/cp-diwali-dabba/art",
                o = "https://cdn.cutiepage.in/template-seeds/diwali-audio/music",
                n = {
                    key: "diwali",
                    introPhoto: `${l}/diya-clay-v2.webp`,
                    endPhoto: `${l}/urli-v2.webp`,
                    songs: [{
                        src: `${o}/song-1-v1.mp3`,
                        title: "Diwali Night"
                    }, {
                        src: `${o}/song-2-v1.mp3`,
                        title: "Diyon Ki Roshni"
                    }, {
                        src: `${o}/song-3-v1.mp3`,
                        title: "Phuljhadi"
                    }],
                    people: {
                        a: {
                            top: "Kurti",
                            topColor: "Mustard",
                            bottom: "Lehenga",
                            bottomColor: "Red",
                            accessory: "Bindi"
                        },
                        b: {
                            top: "Kurta",
                            topColor: "White",
                            bottom: "Trousers",
                            bottomColor: "Navy"
                        }
                    },
                    memories: [{
                        title: "The first diya",
                        caption: "One small flame",
                        line: "Every Diwali starts with one small flame. Ours started the day you walked into my life, and look how bright it got.",
                        photoAlt: "The two of us lighting a diya on a doorstep",
                        action: "Light the first diya"
                    }, {
                        title: "The kandils",
                        caption: "Lanterns over our lane",
                        line: "We hung these kandils together and argued about which one was crooked. Every one of them glows a little brighter because of you.",
                        photoAlt: "The two of us under glowing paper lanterns",
                        action: "Light the kandils"
                    }, {
                        title: "Our rangoli",
                        caption: "Colours, a little messy",
                        line: "Your side was perfect, mine was a mess of colours, and somehow together it became the prettiest rangoli in the gali.",
                        photoAlt: "The two of us beside a colourful rangoli",
                        action: "Hold to draw it"
                    }, {
                        title: "The temple bell",
                        caption: "A little prayer",
                        line: "I rang the bell and asked for just one thing: many more Diwalis with you, exactly like this one.",
                        photoAlt: "The two of us smiling by a small temple lit with diyas",
                        action: "Ring the bell"
                    }, {
                        title: "The mithai box",
                        caption: "Sweetest thing here",
                        line: "Laddoo, kaju katli, jalebi, and still the sweetest thing in this box is you. Okay, maybe tied with the kaju katli.",
                        photoAlt: "The two of us sharing sweets from a box",
                        action: "Open the box"
                    }, {
                        title: "Phuljhadi",
                        caption: "Writing in sparks",
                        line: "Remember trying to write our names with phuljhadis? Yours came out perfect. Mine always came out as a heart.",
                        photoAlt: "The two of us holding sparklers",
                        action: "Light the phuljhadis"
                    }, {
                        title: "The anar",
                        caption: "A fountain of light",
                        line: "You still step back three times before lighting an anar, and I still love standing right behind you, laughing.",
                        photoAlt: "The two of us watching a fountain cracker",
                        action: "Light the anar"
                    }, {
                        title: "The chakri",
                        caption: "Round and round",
                        line: "Life with you is a bit like this chakri: loud, bright, a little dizzy, and impossible to stop smiling at.",
                        photoAlt: "The two of us laughing by a spinning chakri",
                        action: "Spin the chakri"
                    }, {
                        title: "The rocket",
                        caption: "Up to the stars",
                        line: "One rocket, one wish, and the whole sky lit up. Some wishes come true when you are standing next to the right person.",
                        photoAlt: "The two of us looking up at fireworks",
                        action: "Launch the rocket"
                    }, {
                        title: "The sky lantern",
                        caption: "Our wish, flying",
                        line: "We wrote our wish on a lantern and let it go. I won't tell you what it was, but you are in every word of it.",
                        photoAlt: "The two of us letting a sky lantern fly",
                        action: "Let it fly"
                    }],
                    moods: [{
                        id: "diwali-night",
                        label: "Diwali night",
                        values: {
                            bg: "#160b2a",
                            surface: "#26163f",
                            fg: "#fff4e4",
                            muted: "#e8d3dc",
                            accent: "#ffb13b",
                            onAccent: "#2a1500",
                            line: "#3d2558",
                            glow: "#7a3a2a",
                            mood: 0
                        }
                    }, {
                        id: "rose-dusk",
                        label: "Rose dusk",
                        values: {
                            bg: "#2a1838",
                            surface: "#3a2350",
                            fg: "#fff3f0",
                            muted: "#f0d6e0",
                            accent: "#ff8fab",
                            onAccent: "#2b0f19",
                            line: "#4d2d63",
                            glow: "#9a4a6a",
                            mood: 1
                        }
                    }, {
                        id: "golden-midnight",
                        label: "Golden midnight",
                        values: {
                            bg: "#1c0a10",
                            surface: "#2f121c",
                            fg: "#fff1dc",
                            muted: "#efd4c4",
                            accent: "#ffc94a",
                            onAccent: "#2a1a00",
                            line: "#4a1e2a",
                            glow: "#8a3a1c",
                            mood: 2
                        }
                    }],
                    decorations: [{
                        label: "Ladi lights",
                        options: ["Warm", "Rainbow", "Pink", "Marigold"],
                        photoHint: "Printed on the cloth banner across the lane."
                    }, {
                        label: "Kandil lanterns",
                        options: ["Saffron", "Pink", "Teal", "Gold"],
                        photoHint: "Printed on the paper of the hanging kandils."
                    }],
                    copy: {
                        coverKicker: "A Diwali gali, just for us",
                        headline: "come light up Diwali with me",
                        lede: "A sleepy little lane waiting in the dark. Light the first diya and watch our whole town glow, one memory at a time.",
                        openLabel: "Step into the gali",
                        loadingLabel: "Lighting the diyas",
                        stageLabel: "A 3D Diwali lane at night with diyas, kandils, rangoli, crackers and our memories to find",
                        chooseTitle: "How do you want to see it?",
                        walkLabel: "Walk around",
                        tourLabel: "Take the tour",
                        letterGreeting: "Happy Diwali,",
                        letterBody: "Of all the lights tonight, the one I am most grateful for is you. You make ordinary evenings feel like festivals and long days feel short.\n\nThank you for every laugh, every late night chat, every time you stood beside me, on the good days and the messy ones.\n\nThis Diwali I wish you sweetness like mithai, light like a thousand diyas and a year full of reasons to smile. And I hope I get to stand right next to you for all of it.",
                        letterSignoff: "Always with you,",
                        finaleLine: "You light up my world",
                        finaleButton: "See the rest",
                        endLine: "Happy Diwali to us",
                        message: "Thank you for being my light, this Diwali and every day after. Here's to sweets, sparklers and many more festivals together.",
                        signoff: "With love,",
                        replyMessage: "I loved our Diwali gali! Happy Diwali to you too \uD83E\uDE94",
                        replyLabel: "Reply to me",
                        replayLabel: "Watch it again"
                    }
                },
                s = (0, i.J)(n, {
                    key: "cp-world-diwali",
                    name: "Diwali Night in 3D",
                    description: "A tiny 3D Diwali lane you can walk through together: light the first diya and watch the whole town glow, draw a rangoli, open a mithai box, light phuljhadis and an anar, and end with fireworks that write your names in the sky.",
                    meta: {
                        title: "Come light up Diwali with me \uD83E\uDE94",
                        description: "Diyas, kandils, mithai and our story. Step into our little Diwali gali."
                    },
                    cover: "https://cdn.cutiepage.in/template-seeds/cp-world-diwali/cover-v1.webp"
                })
        },
        62513: (e, t, a) => {
            a.d(t, {
                J: () => v
            });
            var i = a(73365),
                l = a(92407),
                o = a(34212),
                n = a(87191),
                s = a(34768),
                r = a(63054),
                d = a(36744),
                c = a(84100);
            let h = "font-(family-name:--f-display)",
                f = "font-(family-name:--f-body)",
                p = {
                    src: "",
                    loop: !0,
                    volume: .6,
                    effects: "soft"
                },
                u = `inline-flex min-h-[56px] items-center justify-center gap-2 rounded-full px-8 ${f} text-[17px] font-bold leading-[1.4] transition-transform active:translate-y-[2px]`,
                m = `${u} bg-(--f-accent) text-(--f-onAccent) shadow-[0_8px_24px_-8px_var(--f-accent)]`,
                g = `${u} bg-(--f-surface) text-(--f-fg) shadow-[0_0_0_2px_var(--f-line)]`;

            function y(e) {
                let t = c.n8.find(t => t.key === e);
                if (!t) throw Error(`Unknown world template ${e}`);
                return t.world
            }

            function x({
                field: e,
                prefix: t,
                family: a
            }) {
                let l = (0, s.useAssetUrl)(e),
                    n = (0, s.useMode)();
                return a && !l && "edit" !== n ? (0, i.jsx)("div", {
                    className: `${t}mark aspect-square`,
                    "aria-hidden": !0
                }) : (0, i.jsx)(o.YQ, {
                    field: e
                })
            }
            let w = e => c.n8.find(t => t.key === e) ? .bond === "siblings";

            function b({
                prefix: e,
                family: t
            }) {
                let a = (0, s.useText)("replyNumber"),
                    o = (0, s.useText)("replyMessage");
                return (0, i.jsxs)("section", {
                    className: "wd-ground relative flex min-h-[720px] flex-col items-center justify-center overflow-hidden px-5 pb-24 pt-10 text-center text-(--f-fg) @3xl:min-h-[800px]",
                    children: [(0, i.jsx)("div", {
                        className: "wd-cover-glow",
                        "aria-hidden": !0
                    }), (0, i.jsxs)("div", {
                        className: "relative z-[1] flex w-full max-w-[360px] flex-col items-center @3xl:max-w-[560px]",
                        children: [(0, i.jsx)("div", {
                            className: "w-[170px]",
                            children: (0, i.jsx)(x, {
                                field: "endMedia",
                                prefix: e,
                                family: t
                            })
                        }), (0, i.jsx)(s.FText, {
                            as: "h2",
                            field: "line",
                            className: `mt-6 block text-balance ${h} text-[36px] leading-[1.1] text-(--f-accent) @3xl:text-[46px]`
                        }), (0, i.jsx)(s.FText, {
                            as: "p",
                            field: "message",
                            className: `mt-4 block rounded-(--f-radius) bg-(--f-surface) px-5 py-4 text-pretty ${f} text-[17px] font-medium leading-[1.6] text-(--f-fg)`
                        }), (0, i.jsxs)("div", {
                            className: "mt-5 flex flex-col items-center",
                            children: [(0, i.jsx)(s.FText, {
                                field: "signoff",
                                className: `block ${f} text-[17px] font-semibold leading-[1.3] text-(--f-muted)`
                            }), (0, i.jsx)(s.FText, {
                                as: "p",
                                field: "signature",
                                className: "block font-(family-name:--f-script) text-[44px] leading-[1.2] text-(--f-accent)"
                            })]
                        }), (0, i.jsxs)("div", {
                            className: "mt-6 flex flex-col items-center gap-3",
                            children: [(0, i.jsx)(l.WhatsAppReply, {
                                number: a,
                                message: o,
                                className: m,
                                children: (0, i.jsx)(s.FText, {
                                    field: "replyLabel"
                                })
                            }), (0, i.jsx)(n.ReplayButton, {
                                className: `shadow-none ${g}`,
                                children: (0, i.jsx)(s.FText, {
                                    field: "replayLabel"
                                })
                            })]
                        })]
                    })]
                })
            }
            let k = {
                bg: {
                    type: "color",
                    label: "Background",
                    default: "#1b1424"
                },
                surface: {
                    type: "color",
                    label: "Cards",
                    default: "#2a2036"
                },
                fg: {
                    type: "color",
                    label: "Text",
                    default: "#fff5f1"
                },
                muted: {
                    type: "color",
                    label: "Small text",
                    default: "#e6d6e0"
                },
                accent: {
                    type: "color",
                    label: "Main colour",
                    default: "#ff8fab"
                },
                onAccent: {
                    type: "color",
                    label: "Text on main colour",
                    default: "#2a0f19"
                },
                line: {
                    type: "color",
                    label: "Outlines",
                    default: "#3a2c48"
                },
                glow: {
                    type: "color",
                    label: "Background glow",
                    default: "#5a3a6a"
                },
                display: {
                    type: "font",
                    label: "Headlines",
                    default: "fraunces"
                },
                body: {
                    type: "font",
                    label: "Text",
                    default: "dm-sans"
                },
                script: {
                    type: "font",
                    label: "Handwriting",
                    default: "caveat"
                },
                radius: {
                    type: "length",
                    label: "Corner roundness",
                    default: 22,
                    min: 0,
                    max: 32
                },
                mood: {
                    type: "length",
                    label: "World mood",
                    default: 0,
                    min: 0,
                    max: 2
                }
            };

            function v(e, t) {
                var a, l, o, n;
                let u, g, v = (a = t.key, c.n8.find(e => e.key === a) ? .prefix ? ? "wd-"),
                    T = {},
                    j = e.moods[0].values;
                for (let [e, t] of Object.entries(k)) {
                    let a = j[e];
                    T[e] = void 0 === a ? t : { ...t,
                        default: a
                    }
                }
                let N = {
                        looks: !0,
                        groups: (0, d.Vw)(e)
                    },
                    L = {
                        label: "Opening (first page)",
                        description: "The first page: their name, your line, an opening photo or GIF and the Enter button. The world loads behind it.",
                        category: "hero",
                        entrance: "fade",
                        ownsStoryNext: !0,
                        fields: (0, d.XX)(e),
                        items: {},
                        stacks: {},
                        render: (l = t.key, function() {
                            let e = (0, s.useText)("toName").trim();
                            return (0, i.jsxs)("section", {
                                className: `wd-ground ${v}cover relative flex min-h-[720px] flex-col items-center justify-center overflow-hidden px-5 pb-24 pt-10 text-center text-(--f-fg) @3xl:min-h-[800px]`,
                                children: [(0, i.jsx)("div", {
                                    className: "wd-cover-glow",
                                    "aria-hidden": !0
                                }), (0, i.jsxs)("div", {
                                    className: "relative z-[1] flex w-full max-w-[360px] flex-col items-center @3xl:max-w-[620px]",
                                    children: [(0, i.jsx)(s.FText, {
                                        field: "kicker",
                                        className: `inline-flex rounded-full bg-(--f-surface) px-4 py-1 ${f} text-[14px] font-bold leading-[1.5] text-(--f-fg)`
                                    }), (0, i.jsx)("div", {
                                        className: "mt-6 w-[150px] @3xl:w-[180px]",
                                        children: (0, i.jsx)(x, {
                                            field: "introMedia",
                                            prefix: v,
                                            family: w(l)
                                        })
                                    }), (0, i.jsxs)("h1", {
                                        className: `mt-6 block text-balance ${h} text-[44px] font-normal leading-[1.05] @3xl:text-[60px]`,
                                        children: [(0, i.jsx)(s.FText, {
                                            field: e ? "toName" : "toFallback",
                                            className: "text-(--f-accent)"
                                        }), ", ", (0, i.jsx)(s.FText, {
                                            field: "headline"
                                        })]
                                    }), (0, i.jsx)(s.FText, {
                                        as: "p",
                                        field: "lede",
                                        className: `mt-4 block max-w-[34ch] text-pretty ${f} text-[17px] font-medium leading-[1.55] text-(--f-muted)`
                                    }), (0, i.jsx)(r.WorldEnter, {
                                        world: y(l),
                                        buttonClassName: m,
                                        label: (0, i.jsx)(s.FText, {
                                            field: "openLabel"
                                        }),
                                        loading: (0, i.jsx)(s.FText, {
                                            field: "loadingLabel"
                                        })
                                    })]
                                })]
                            })
                        })
                    },
                    A = {
                        label: "The 3D world",
                        description: "Your walkable 3D world: the two of you and your pet, your memories glowing in it, the letter and the finale.",
                        category: "experience",
                        ownsStoryNext: !0,
                        fields: (0, d.qf)(e),
                        items: {},
                        stacks: {},
                        render: (o = t.key, u = e.memories.map(e => ({
                            title: e.title,
                            action: e.action ? ? null
                        })), g = y(o), function() {
                            return (0, i.jsx)(r.WorldStage, {
                                world: g,
                                templateKey: o,
                                memories: u
                            })
                        })
                    },
                    D = {
                        label: "The end",
                        description: "The last page: your ending photo or GIF, your message, a reply button and replay.",
                        category: "cta",
                        entrance: "fade",
                        fields: (0, d.b0)(e),
                        items: {},
                        stacks: {},
                        render: (n = w(t.key), function() {
                            return (0, i.jsx)(b, {
                                prefix: v,
                                family: n
                            })
                        })
                    };
                return {
                    key: t.key,
                    product: "cutiepage",
                    name: t.name,
                    description: t.description,
                    category: "gift",
                    cover: t.cover,
                    meta: t.meta,
                    sound: { ...p,
                        src: e.songs ? .[0] ? .src ? ? p.src
                    },
                    tokens: T,
                    presets: [...e.moods],
                    sections: {
                        cover: L,
                        world: A,
                        finale: D
                    },
                    pages: [{
                        id: "home",
                        path: "/",
                        title: t.name,
                        layout: "story",
                        sections: [{
                            type: "cover"
                        }, {
                            type: "world"
                        }, {
                            type: "finale"
                        }]
                    }],
                    simpleEditor: N,
                    storyNav: "none",
                    soundChip: "icon"
                }
            }
        }
    }
]);