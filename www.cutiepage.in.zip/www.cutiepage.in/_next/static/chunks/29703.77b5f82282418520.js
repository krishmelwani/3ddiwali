"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [29703], {
        29703: (e, o, t) => {
            t.d(o, {
                Cw: () => s,
                Yo: () => d,
                bM: () => g,
                pt: () => m,
                tl: () => f,
                zm: () => u
            });
            var a = t(84910),
                l = t(95813),
                i = t(95468);
            let n = `
varying vec3 vW; varying vec3 vN; varying vec3 vCol; varying vec3 vLocal; varying vec3 vSize; varying vec2 vSeed;
#include <common>
#include <fog_pars_vertex>
void main(){
  mat4 im = instanceMatrix;
  vec4 w = modelMatrix*im*vec4(position, 1.0);
  vW = w.xyz;
  vN = normalize(mat3(modelMatrix)*mat3(im)*normal);
  vSize = vec3(length(im[0].xyz), length(im[1].xyz), length(im[2].xyz));
  vLocal = position;
  vSeed = im[3].xz;
  #ifdef USE_INSTANCING_COLOR
    vCol = instanceColor;
  #else
    vCol = vec3(0.6);
  #endif
  vec4 mvPosition = viewMatrix*w;
  gl_Position = projectionMatrix*mvPosition;
  #include <fog_vertex>
}`,
                r = `
uniform float uTime, uLit, uDiwali; uniform vec3 uMoonDir, uMoonCol, uAmb, uStreet;
varying vec3 vW; varying vec3 vN; varying vec3 vCol; varying vec3 vLocal; varying vec3 vSize; varying vec2 vSeed;
#include <common>
#include <fog_pars_fragment>
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7)))*43758.5453); }
void main(){
  vec3 n = normalize(vN);
  float diff = max(dot(n, normalize(uMoonDir)), 0.0);
  float band = diff > 0.55 ? 1.0 : diff > 0.2 ? 0.6 : 0.3;
  vec3 base = vCol*(uAmb + uMoonCol*band*0.32);
  // warm street glow on the lower floors
  float fromStreet = vW.y - -13.0;
  base += uStreet*vCol*exp(-fromStreet*0.35)*0.9;
  vec3 col = base; vec3 emit = vec3(0.0);
  vec3 ln = abs(vLocal);
  bool side = abs(n.y) < 0.5;
  if (side) {
    // local face coordinate (metres) along the face and down from the top
    float alongX = step(ln.z, ln.x);   // 1 on the +-x faces
    float u = alongX > 0.5 ? (vLocal.z + 0.5)*vSize.z : (vLocal.x + 0.5)*vSize.x;
    float width = alongX > 0.5 ? vSize.z : vSize.x;
    float fromTop = (0.5 - vLocal.y)*vSize.y;
    float face = alongX > 0.5 ? sign(vLocal.x) + 3.0 : sign(vLocal.z) + 7.0;
    float nWin = max(1.0, floor(width/2.3));
    float cu = u/width*nWin;
    float floorIdx = floor((fromTop - 0.9)/3.0);
    float fv = fract((fromTop - 0.9)/3.0);
    vec2 cell = vec2(floor(cu), floorIdx);
    vec2 f = vec2(fract(cu), fv);
    float inWin = step(0.27, f.x)*step(f.x, 0.73)*step(0.24, f.y)*step(f.y, 0.8)*step(0.9, fromTop)*step(2.0, vW.y - -13.0);
    float h = h21(cell + vSeed*0.137 + face*17.0);
    float h2 = h21(cell*1.7 + vSeed*0.071 + face*3.0);
    float lit = step(h, uLit);
    vec3 warm = mix(vec3(1.0, 0.72, 0.36), vec3(1.0, 0.86, 0.55), h2);
    vec3 tube = vec3(0.78, 0.9, 1.0);
    vec3 tv = vec3(0.45, 0.6, 1.0)*(0.75 + 0.25*sin(uTime*(3.0 + h2*4.0) + h*30.0));
    vec3 wc = h2 < 0.62 ? warm : h2 < 0.9 ? tube : tv;
    // a soft gradient inside the window (curtain glow)
    float glowIn = 0.75 + 0.35*(1.0 - abs(f.x - 0.5)*2.0);
    vec3 dark = vCol*0.18 + vec3(0.02, 0.025, 0.05);
    col = mix(col, dark, inWin);
    emit = wc*lit*inWin*glowIn*1.15;
    // the floor slab line
    col *= 1.0 - 0.18*step(fv, 0.06)*step(0.9, fromTop);
    // Diwali torans: coloured bulbs along some floor lines
    if (uDiwali > 0.0) {
      float hasToran = step(0.45, h21(vec2(floorIdx, face) + vSeed*0.31));
      float dotU = fract(u*2.2); float dotV = abs(fv - 0.12);
      float bulb = smoothstep(0.22, 0.0, length(vec2(dotU - 0.5, dotV*3.0)))*hasToran*step(0.9, fromTop);
      float k = floor(u*2.2);
      vec3 bc = 0.5 + 0.5*cos(6.2831*(h21(vec2(k, floorIdx)) + vec3(0.0, 0.33, 0.67)));
      float blink = 0.6 + 0.4*sin(uTime*2.0 + k*0.9);
      emit += bc*bulb*blink*1.6*uDiwali;
    }
  } else if (n.y > 0.5) {
    col = vCol*(uAmb*0.8 + uMoonCol*0.35)*0.75;
  }
  vec3 outCol = col + emit;
  gl_FragColor = vec4(outCol, 1.0);
  #ifdef USE_FOG
    #ifdef FOG_EXP2
      float fogFactor = 1.0 - exp(-fogDensity*fogDensity*vFogDepth*vFogDepth);
    #else
      float fogFactor = smoothstep(fogNear, fogFar, vFogDepth);
    #endif
    // lit windows keep shining through the haze a little
    vec3 fogged = mix(col, fogColor, fogFactor) + emit*(1.0 - fogFactor*0.72);
    gl_FragColor = vec4(fogged, 1.0);
  #endif
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

            function f(e) {
                let o = a.LlO.merge([l.fCn.fog, {
                    uLit: {
                        value: .4
                    },
                    uDiwali: {
                        value: 0
                    },
                    uMoonDir: {
                        value: new a.Pq0(.4, .6, -.7)
                    },
                    uMoonCol: {
                        value: new a.Q1f("#8fa0d8")
                    },
                    uAmb: {
                        value: new a.Q1f("#3a3f66")
                    },
                    uStreet: {
                        value: new a.Q1f("#ff9a4a")
                    }
                }]);
                return o.uTime = e, new a.BKk({
                    uniforms: o,
                    vertexShader: n,
                    fragmentShader: r,
                    fog: !0
                })
            }
            let c = ["#c9a98f", "#b8c4b0", "#a9b8cc", "#d6c3a3", "#c7a3a8", "#9fa6ad", "#d1b48c", "#b3a4c6", "#cfd2c7", "#a7c2bf"],
                v = ["#e6c8ae", "#cfe0cc", "#c6d3e8", "#efdcbb", "#e8c4c6", "#d9d4cc"];

            function s(e, o) {
                let t = (o, t) => o + (t - o) * e(),
                    a = o => o[Math.floor(e() * o.length) % o.length],
                    l = [],
                    i = [];
                l.push({
                    x: 0,
                    z: 0,
                    w: 22.6,
                    d: 22.6,
                    top: -.02,
                    color: "#e3c3a6"
                });
                let n = o ? 5 : 4;
                for (let o = -n; o <= n; o++)
                    for (let r = -n; r <= n; r++) {
                        if (0 === o && 0 === r) continue;
                        let n = Math.max(Math.abs(o), Math.abs(r)),
                            f = 30 * o,
                            s = 30 * r,
                            u = 1 === n || .5 > e() ? 2 : 1,
                            d = 22 / u;
                        for (let o = 0; o < u; o++)
                            for (let r = 0; r < u; r++) {
                                if (n >= 2 && .12 > e()) continue;
                                let u = f - 11 + d * (o + .5),
                                    m = s - 11 + d * (r + .5),
                                    g = d - t(.4, 2.2),
                                    p = d - t(.4, 2.2),
                                    x = m < -8,
                                    h = .3 > Math.abs(Math.atan2(u, -m) - .42) && x,
                                    w = m > 14,
                                    b = {
                                        x: u,
                                        z: m,
                                        w: g,
                                        d: p,
                                        top: 1 === n ? x ? t(-8, -3.5) : w ? t(-4, 4.5) : t(-6, .2) : 2 === n ? x ? t(-6, 3) : t(-3, 10) : h ? t(0, 12) : t(2, .15 > e() ? 42 : 24),
                                        color: a(1 === n ? v : c)
                                    };
                                l.push(b), 1 === n && i.push(b)
                            }
                    }
                return {
                    buildings: l,
                    nearRoofs: i
                }
            }

            function u(e, o) {
                let t = new a.iNn(1, 1, 1),
                    l = new a.ZLX(t, o, e.length),
                    i = new a.B69,
                    n = new a.Q1f;
                return e.forEach((e, o) => {
                    let t = e.top - -13;
                    i.position.set(e.x, -13 + t / 2, e.z), i.rotation.set(0, e.rot ? ? 0, 0), i.scale.set(e.w, t, e.d), i.updateMatrix(), l.setMatrixAt(o, i.matrix), l.setColorAt(o, n.set(e.color))
                }), l.instanceMatrix.needsUpdate = !0, l.instanceColor && (l.instanceColor.needsUpdate = !0), l.computeBoundingSphere(), l.frustumCulled = !1, l.userData.noShadow = !0, l
            }

            function d(e, o, t, l, i) {
                let n = (e, o) => e + (o - e) * l(),
                    r = new a.Ho_(1, 1, 1, i ? 14 : 10);
                for (let a of e) {
                    let e = a.top,
                        f = a.w / 2,
                        c = a.d / 2,
                        v = a.color,
                        s = "#d8d2c8";
                    o.box([a.w, .8, .2], [a.x, e + .4, a.z - c + .1], v), o.box([a.w, .8, .2], [a.x, e + .4, a.z + c - .1], v), o.box([.2, .8, a.d], [a.x - f + .1, e + .4, a.z], v), o.box([.2, .8, a.d], [a.x + f - .1, e + .4, a.z], v), o.box([a.w + .1, .06, .3], [a.x, e + .83, a.z - c + .1], s), o.box([a.w + .1, .06, .3], [a.x, e + .83, a.z + c - .1], s), o.box([a.w - .4, .04, a.d - .4], [a.x, e + .02, a.z], "#8d8a94");
                    let u = 1 + Math.floor(2 * l());
                    for (let t = 0; t < u; t++) {
                        let t = a.x + n(-f + 1.6, f - 1.6),
                            i = a.z + n(-c + 1.6, c - 1.6);
                        o.box([1.6, .7, 1.6], [t, e + .35, i], "#9a8f86"), o.add(r, .75 > l() ? "#1d1f24" : "#3b5ea8", [t, e + .7 + .65, i], [0, 0, 0], [.62, 1.3, .62]), o.sph([.5, .18, .5], [t, e + 2, i], "#25272d")
                    }
                    if (.6 > l()) {
                        let i = a.x + (.5 > l() ? -1 : 1) * (f - 2.2),
                            n = a.z + (.5 > l() ? -1 : 1) * (c - 2);
                        o.box([3.2, 2.5, 3], [i, e + 1.25, n], v), o.box([3.5, .14, 3.3], [i, e + 2.55, n], s);
                        let r = n > a.z ? -1 : 1;
                        t.box([.9, 1.9, .04], [i, e + .95, n + 1.52 * r], .7 > l() ? "#ffcf8a" : "#cfe6ff"), .6 > l() && (o.rod([i + 1, e + 2.6, n], [i + 1, e + 3.2, n], .03, "#777b84"), o.sph([.42, .12, .42], [i + 1, e + 3.3, n], "#e8e8ec", [.7, .4, 0]))
                    }
                    if (i) {
                        let t = 2 + Math.floor(4 * l());
                        for (let i = 0; i < t; i++) {
                            let t = a.x + n(-f + .6, f - .6),
                                i = a.z - c + .6;
                            o.cyl(.22, .36, [t, e + .18, i], "#b5643c", 8), o.sph([.36, .42, .36], [t, e + .6, i], .5 > l() ? "#3f6e46" : "#4f7d3c")
                        }
                    }
                }
                r.dispose()
            }

            function m(e, o) {
                let t = e.createElement("canvas");
                t.width = 2048, t.height = 256;
                let l = t.getContext("2d");
                if (l) {
                    l.fillStyle = "#000", l.fillRect(0, 0, 2048, 256);
                    for (let e = 0; e < 2; e++) {
                        let t = 0;
                        for (; t < 2048;) {
                            let a = 14 + o() * (e ? 46 : 30),
                                i = e ? 40 + 120 * o() + 70 * (.08 > o()) : 30 + 60 * o(),
                                n = 256 - i;
                            l.fillStyle = e ? "#ff0000" : "#b00000", l.fillRect(t, n, a, i);
                            for (let i = n + 6; i < 252; i += 7)
                                for (let n = t + 3; n < t + a - 3; n += 5) .16 > o() && (l.fillStyle = e ? "#ffff00" : "#b0b000", l.fillRect(n, i, 2, 2));
                            e && i > 140 && (l.fillStyle = "#ff00ff", l.fillRect(t + a / 2 - 1.5, n - 3, 3, 3)), t += a + (e ? 30 * o() : 0)
                        }
                    }
                }
                let i = new a.GOR(t);
                i.colorSpace = a.er$, i.wrapS = a.GJx, i.repeat.set(3, 1);
                let n = {
                        uMap: {
                            value: i
                        },
                        uSil: {
                            value: new a.Q1f("#141a33")
                        },
                        uWin: {
                            value: new a.Q1f("#ffcf7a")
                        },
                        uHaze: {
                            value: new a.Q1f("#2a2550")
                        },
                        uTime: {
                            value: 0
                        }
                    },
                    r = new a.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        side: a.$EB,
                        uniforms: n,
                        vertexShader: "varying vec2 vUv; void main(){ vUv = uv*vec2(3.0, 1.0); gl_Position = projectionMatrix*modelViewMatrix*vec4(position, 1.0); }",
                        fragmentShader: `uniform sampler2D uMap; uniform vec3 uSil, uWin, uHaze; varying vec2 vUv;
      void main(){ vec4 t = texture2D(uMap, vUv); float near = step(0.85, t.r);
        vec3 sil = mix(mix(uHaze, uSil, 0.55), uSil, near);
        vec3 c = sil + uWin*t.g*(near > 0.5 ? 0.9 : 0.5) + vec3(1.0, 0.15, 0.1)*t.b*1.4;
        gl_FragColor = vec4(c, step(0.2, t.r));
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                    }),
                    f = new a.Ho_(255, 255, 36, 64, 1, !0);
                f.translate(0, 9, 0);
                let c = new a.eaF(f, r);
                return c.renderOrder = 0, c.frustumCulled = !1, c.userData.noShadow = !0, {
                    mesh: c,
                    setColors(e, o, t) {
                        n.uSil.value.set(e), n.uWin.value.set(o), n.uHaze.value.set(t)
                    },
                    dispose() {
                        i.dispose(), f.dispose(), r.dispose()
                    }
                }
            }

            function g(e) {
                let {
                    time: o,
                    px: t,
                    rand: n,
                    high: r,
                    extent: f
                } = e, c = new a.bdM(2.4 * f, 2.4 * f);
                c.rotateX(-Math.PI / 2);
                let v = new a.BKk({
                        uniforms: a.LlO.merge([l.fCn.fog, {
                            uRoad: {
                                value: new a.Q1f("#2a2c36")
                            },
                            uLot: {
                                value: new a.Q1f("#1b1d26")
                            }
                        }]),
                        fog: !0,
                        vertexShader: `varying vec3 vW;
      #include <common>
      #include <fog_pars_vertex>
      void main(){ vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; vec4 mvPosition = viewMatrix*w; gl_Position = projectionMatrix*mvPosition;
      #include <fog_vertex>
      }`,
                        fragmentShader: `uniform vec3 uRoad, uLot; varying vec3 vW;
      #include <common>
      #include <fog_pars_fragment>
      void main(){ vec2 g = abs(mod(vW.xz + 15.0, 30.0) - 15.0);
        float road = step(11.2, max(g.x, g.y));
        vec3 c = mix(uLot, uRoad, road);
        float dash = road*step(14.85, max(g.x, g.y))*step(0.5, fract((g.x > g.y ? vW.z : vW.x)*0.25));
        c += vec3(0.25, 0.22, 0.15)*dash;
        gl_FragColor = vec4(c, 1.0);
        #include <fog_fragment>
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                    }),
                    s = new a.eaF(c, v);
                s.position.y = -13.02, s.userData.noShadow = !0;
                let u = [],
                    d = [],
                    m = Math.floor(f / 30),
                    g = r ? 10 : 15;
                for (let e = -m; e <= m; e++) {
                    let o = 30 * e + 15;
                    for (let e = -f; e <= f; e += g) {
                        let t = (Math.round(e / g) % 2 == 0 ? 1 : -1) * 3.4;
                        u.push(o + t, -7.8, e, e, -7.8, o + t);
                        let a = .75 > n() ? "#ffad5a" : "#e8f2ff";
                        d.push(a, a)
                    }
                }
                let p = (0, i.zq)({
                        positions: u,
                        colors: d,
                        sizes: 2.4,
                        time: o,
                        px: t,
                        rand: n,
                        twinkle: .05,
                        opacity: .9,
                        core: .18
                    }),
                    x = r ? 150 : 70,
                    h = new Float32Array(2 * x * 3),
                    w = new Float32Array(2 * x * 3),
                    b = new Float32Array(2 * x),
                    S = new Float32Array(2 * x),
                    y = new Float32Array(2 * x * 3),
                    z = 2 * f,
                    C = new a.Q1f;
                for (let e = 0; e < x; e++) {
                    let o = .5 > n(),
                        t = (Math.floor(n() * (2 * m + 1)) - m) * 30 + 15,
                        a = .5 > n() ? 1 : -1,
                        l = (6 + 7 * n()) * a,
                        i = n() * z,
                        r = .5 > n();
                    for (let n = 0; n < 2; n++) {
                        let c = 2 * e + n,
                            v = (n - .5) * .9;
                        o ? (h.set([-f, -12.4, t + 1.8 * a + v], 3 * c), w.set([1, 0, 0], 3 * c)) : (h.set([t + 1.8 * a + v, -12.4, -f], 3 * c), w.set([0, 0, 1], 3 * c)), b[c] = l, S[c] = i, C.set(r ? "#ff3b30" : "#fff2d0"), y.set([C.r, C.g, C.b], 3 * c)
                    }
                }
                let _ = new a.LoY;
                _.setAttribute("position", new a.THS(h, 3)), _.setAttribute("aDir", new a.THS(w, 3)), _.setAttribute("aSpeed", new a.THS(b, 1)), _.setAttribute("aPhase", new a.THS(S, 1)), _.setAttribute("aColor", new a.THS(y, 3));
                let M = new a.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: a.EZo,
                        uniforms: {
                            uTime: o,
                            uPx: t,
                            uLen: {
                                value: z
                            }
                        },
                        vertexShader: `uniform float uTime, uPx, uLen; attribute vec3 aDir; attribute float aSpeed, aPhase; attribute vec3 aColor; varying vec3 vC;
      void main(){ vec3 p = position + aDir*mod(aPhase + uTime*aSpeed, uLen); vC = aColor;
        vec4 mv = modelViewMatrix*vec4(p, 1.0); gl_Position = projectionMatrix*mv; gl_PointSize = clamp(0.9*uPx/max(-mv.z, 0.1), 1.0, 40.0); }`,
                        fragmentShader: `varying vec3 vC; void main(){ float d = length(gl_PointCoord - 0.5)*2.0; if (d > 1.0) discard; float a = pow(1.0 - d, 2.0);
      gl_FragColor = vec4(vC*a*1.4, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`
                    }),
                    L = new a.ONl(_, M);
                return L.frustumCulled = !1, L.userData.noShadow = !0, {
                    ground: s,
                    lamps: p,
                    cars: L,
                    dispose() {
                        c.dispose(), v.dispose(), _.dispose(), M.dispose(), p.geometry.dispose(), p.material.dispose()
                    }
                }
            }
        }
    }
]);