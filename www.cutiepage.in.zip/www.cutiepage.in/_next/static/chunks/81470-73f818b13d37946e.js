"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [81470], {
        5965: (e, t, n) => {
            n.d(t, {
                X1: () => l,
                lI: () => s
            });
            var a = n(1521),
                i = n(33736),
                o = n(89307),
                r = n(29144);

            function s({
                templateKey: e
            }) {
                let t = (0, i.tA)(),
                    {
                        session: n
                    } = (0, r.kB)(),
                    d = (0, o.O)(() => "project" === n.kind ? {
                        editor: "v2",
                        mode: "signed_in",
                        templateSlug: n.project.templateSlug,
                        projectId: n.project.projectId,
                        hasMusic: !0,
                        needsPayment: n.project.requiresCheckout,
                        engine: "folio"
                    } : "guest" === n.kind ? {
                        editor: "v2",
                        mode: "guest",
                        templateSlug: n.templateSlug ? ? e,
                        projectId: null,
                        hasMusic: !0,
                        needsPayment: "number" == typeof n.priceInr ? n.priceInr > 0 : null,
                        engine: "folio"
                    } : {
                        editor: "v2",
                        mode: "playground",
                        templateSlug: e,
                        projectId: null,
                        hasMusic: !0,
                        needsPayment: null,
                        engine: "folio"
                    }),
                    u = "project" === n.kind ? "project" : "guest" === n.kind ? "guest" : "none";
                return (0, a.useEffect)(() => t.subscribe((e, t) => {
                    let n = d.current;
                    n && (function(e, t, n, a) {
                        try {
                            let i = t.revision > n.revision;
                            i && e.firstEdit(), "error" === t.saveState && "error" !== n.saveState && e.track("editor_save_failed", {
                                sink: a
                            });
                            let o = t.doc.sound ? .src ? ? "";
                            i && o && o !== (n.doc.sound ? .src ? ? "") && 0 === t.future.length && e.track("editor_music_added")
                        } catch {}
                    }(n, e, t, u), e.selection && e.selection !== t.selection && n.section(l(e.doc, e.selection.sectionId) ? ? ""))
                }), [t, d, u]), null
            }

            function l(e, t) {
                if (!t) return null;
                for (let n of e.pages) {
                    let e = n.sections.find(e => e.id === t);
                    if (e) return e.type
                }
                return null
            }
        },
        21992: (e, t, n) => {
            n.d(t, {
                c: () => s
            });
            var a = n(73365),
                i = n(1521),
                o = n(54872);
            let r = ["simple", "advanced"];

            function s({
                value: e,
                onChange: t,
                className: n,
                labels: l = {
                    group: "Editor",
                    simple: "Simple",
                    advanced: "Advanced"
                }
            }) {
                let d = r.map(e => ({
                        value: e,
                        label: l[e]
                    })),
                    u = (0, i.useRef)([]);
                return (0, a.jsx)("div", {
                    role: "radiogroup",
                    "aria-label": l.group,
                    onKeyDown: n => {
                        if (!["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp", "Home", "End"].includes(n.key)) return;
                        n.preventDefault();
                        let a = d.findIndex(t => t.value === e),
                            i = "Home" === n.key ? 0 : "End" === n.key ? d.length - 1 : (a + ("ArrowRight" === n.key || "ArrowDown" === n.key ? 1 : -1) + d.length) % d.length;
                        t(d[i].value), u.current[i] ? .focus()
                    },
                    className: (0, o.cn)("inline-flex h-10 items-stretch sm:h-11 rounded-full border border-cp-line bg-cp-subtle p-1", n),
                    children: d.map((n, i) => {
                        let r = n.value === e;
                        return (0, a.jsx)("button", {
                            ref: e => {
                                u.current[i] = e
                            },
                            type: "button",
                            role: "radio",
                            "aria-checked": r,
                            tabIndex: r ? 0 : -1,
                            onClick: () => t(n.value),
                            className: (0, o.cn)("flex flex-1 items-center justify-center rounded-full px-3 text-[14px] sm:px-5 whitespace-nowrap transition-[background-color,color,box-shadow] duration-150 motion-reduce:transition-none", "focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-cp-select", r ? "bg-cp-bg font-semibold text-cp-ink shadow-[0_1px_3px_rgba(20,12,60,0.12)]" : "font-medium text-cp-muted hover:text-cp-ink"),
                            children: n.label
                        }, n.value)
                    })
                })
            }
        },
        22908: (e, t, n) => {
            n.d(t, {
                A: () => d
            });
            var a = n(73365),
                i = n(86714),
                o = n(1521),
                r = n(98196);
            let s = (0, i.default)(() => Promise.all([n.e(27996), n.e(15517), n.e(40456), n.e(65366), n.e(89425), n.e(54341), n.e(25040), n.e(8931), n.e(18307), n.e(59082), n.e(31148), n.e(62437), n.e(59780), n.e(3029), n.e(17418), n.e(81597), n.e(17334)]).then(n.bind(n, 81597)).then(e => e.StudioEditor), {
                    loadableGenerated: {
                        webpack: () => [81597]
                    },
                    ssr: !1,
                    loading: () => (0, a.jsx)("div", {
                        className: "flex h-dvh items-center justify-center text-[14px] text-cp-muted",
                        children: "Opening the editor\u2026"
                    })
                }),
                l = "Back to simple",
                d = (0, o.memo)(function({
                    templateKey: e,
                    initialDocument: t,
                    projectName: n,
                    session: i,
                    backHref: d,
                    onClose: u,
                    changeDesign: c,
                    publishState: p,
                    wishes: m,
                    onDocument: h
                }) {
                    return (0, o.useEffect)(() => {
                        let e = document.body.style.overflow;
                        return document.body.style.overflow = "hidden", () => {
                            document.body.style.overflow = e
                        }
                    }, []), (0, r.createPortal)((0, a.jsx)("div", {
                        role: "dialog",
                        "aria-modal": "true",
                        "aria-label": "Advanced editor",
                        className: "fixed inset-0 z-[100] bg-cp-bg",
                        onClickCapture: e => {
                            let t = e.target;
                            t ? .closest(`button[aria-label="${l}"]`) && (e.preventDefault(), e.stopPropagation(), u())
                        },
                        children: (0, a.jsx)(s, {
                            templateKey: e,
                            initialDocument: t,
                            projectName: n,
                            session: i,
                            backHref: d,
                            backLabel: l,
                            changeDesign: c,
                            publishState: p,
                            wishes: m,
                            onDocument: h
                        })
                    }), document.body)
                })
        },
        26796: (e, t, n) => {
            n.d(t, {
                uG: () => g,
                mk: () => y,
                qD: () => f,
                jq: () => m,
                UX: () => h,
                Ec: () => w,
                fC: () => v
            });
            var a = n(49688),
                i = n(69177),
                o = n(80178);
            let r = (e, t, n) => Math.max(Math.abs(e[t] - n[0]), Math.abs(e[t + 1] - n[1]), Math.abs(e[t + 2] - n[2]));

            function s(e, t) {
                return [0, 1, 2].map(n => {
                    let a;
                    return (a = [...t.map(t => e[4 * t + n])].sort((e, t) => e - t))[a.length >> 1] ? ? 0
                })
            }

            function l(e, t) {
                let n = document.createElement("canvas");
                return n.width = e, n.height = t, n
            }
            async function d(e) {
                if ("image/gif" === e.type || "image/svg+xml" === e.type) return e;
                try {
                    let t = await createImageBitmap(e),
                        n = Math.min(1, 1600 / Math.max(t.width, t.height)),
                        a = Math.max(1, Math.round(t.width * n)),
                        i = Math.max(1, Math.round(t.height * n)),
                        o = l(a, i),
                        d = o.getContext("2d", {
                            willReadFrequently: !0
                        });
                    if (!d) return e;
                    d.drawImage(t, 0, 0, a, i), t.close();
                    let u = d.getImageData(0, 0, a, i);
                    ! function(e, t, n) {
                        let a = function(e, t) {
                            let n = [];
                            for (let a = 0; a < e; a++) n.push(a, (t - 1) * e + a);
                            for (let a = 1; a < t - 1; a++) n.push(a * e, a * e + e - 1);
                            return n
                        }(t, n);
                        if (0 === a.length || a.filter(t => e[4 * t + 3] < 128).length / a.length >= .25) return;
                        let i = a.filter(t => e[4 * t + 3] >= 128),
                            o = s(e, i),
                            l = i.filter(t => r(e, 4 * t, o) > 40),
                            d = [o];
                        l.length / i.length >= .15 && d.push(s(e, l));
                        let u = t * n,
                            c = new Uint8Array(u);
                        for (let t = 0; t < u; t++) {
                            let n = 255;
                            for (let a of d) n = Math.min(n, r(e, 4 * t, a));
                            c[t] = n
                        }
                        let p = new Uint8Array(u),
                            m = new Int32Array(u),
                            h = 0,
                            g = 0;
                        for (let e of a) !p[e] && c[e] <= 40 && (p[e] = 1, m[g++] = e);
                        if (0 !== g) {
                            for (; h < g;) {
                                let e = m[h++],
                                    n = e % t;
                                for (let a of [n > 0 ? e - 1 : -1, n < t - 1 ? e + 1 : -1, e - t, e + t]) a < 0 || a >= u || p[a] || c[a] <= 40 && (p[a] = 1, m[g++] = a)
                            }
                            for (let n = 0; n < u; n++) {
                                if (p[n]) {
                                    e[4 * n + 3] = 0;
                                    continue
                                }
                                let a = n % t;
                                if (!(a > 0 && p[n - 1] || a < t - 1 && p[n + 1] || p[n - t] || p[n + t])) continue;
                                let i = Math.min(1, Math.max(0, (c[n] - 20) / 60));
                                e[4 * n + 3] = Math.round(e[4 * n + 3] * i)
                            }
                        }
                    }(u.data, a, i);
                    let c = function(e, t, n) {
                        let a = t,
                            i = n,
                            o = -1,
                            r = -1;
                        for (let s = 0; s < n; s++)
                            for (let n = 0; n < t; n++) !(e[(s * t + n) * 4 + 3] <= 16) && (n < a && (a = n), n > o && (o = n), s < i && (i = s), s > r && (r = s));
                        return o < 0 ? null : {
                            x: a,
                            y: i,
                            width: o - a + 1,
                            height: r - i + 1
                        }
                    }(u.data, a, i);
                    if (!c) return e;
                    d.putImageData(u, 0, 0);
                    let p = Math.round(.02 * Math.max(c.width, c.height)),
                        m = l(c.width + 2 * p, c.height + 2 * p);
                    m.getContext("2d") ? .drawImage(o, c.x, c.y, c.width, c.height, p, p, c.width, c.height);
                    let h = await new Promise(e => m.toBlob(e, "image/webp", .92));
                    if (!h) return e;
                    let g = "image/webp" === h.type ? "character.webp" : "character.png";
                    return new File([h], g, {
                        type: h.type || "image/png"
                    })
                } catch {
                    return e
                }
            }
            var u = n(70704),
                c = n(51801);
            async function p(e) {
                let t = await e.json().catch(() => null);
                return e.ok && t && "data" in t ? {
                    ok: !0,
                    data: t.data
                } : {
                    ok: !1,
                    status: e.status,
                    message: t ? .error ? .message ? ? "Something went wrong. Please try again.",
                    ...t ? .error ? .details ? .code ? {
                        code: t.error.details.code
                    } : {}
                }
            }

            function m(e, t, n) {
                return JSON.stringify({
                    name: e,
                    draftContent: (0, i.K0)(t),
                    themeTokens: {},
                    ...n ? {
                        templateVersionId: n
                    } : {}
                })
            }
            async function h(e, t, n, a) {
                try {
                    let i = await fetch(`/api/projects/${encodeURIComponent(e)}`, {
                        method: "PATCH",
                        headers: {
                            "content-type": "application/json"
                        },
                        credentials: "same-origin",
                        body: m(t, n, a)
                    });
                    return p(i)
                } catch {
                    return {
                        ok: !1,
                        status: 0,
                        message: "You're offline. We'll keep trying."
                    }
                }
            }

            function g(e, t) {
                return "image" === e ? "image/png,image/jpeg,image/webp,image/gif,image/avif" : "project" === t ? "audio/mpeg,audio/mp4,audio/x-m4a,audio/ogg,.mp3,.m4a,.ogg" : "audio/mpeg,.mp3"
            }
            async function f(e, t, n = {}) {
                if ("image" === t) {
                    if (!e.type.startsWith("image/")) return {
                        ok: !1,
                        message: "Please pick a photo."
                    };
                    let t = await (0, o.w4)(n.cutout ? await d(e) : e);
                    return t.ok ? {
                        ok: !0,
                        file: t.file
                    } : {
                        ok: !1,
                        message: "too-large" !== t.reason ? "Could not process that image. Try a different file." : "image/gif" === e.type ? `That GIF is too big. Please pick one under ${a.Dk/1024/1024} MB.` : "That image is too large to process. Try a smaller one."
                    }
                }
                return e.size > 3145728 ? {
                    ok: !1,
                    message: "That music file is too big. Please pick one under 3 MB."
                } : {
                    ok: !0,
                    file: e
                }
            }

            function y(e, t, n) {
                if (n.itemId) return !1;
                let a = t.pages.flatMap(e => e.sections).find(e => e.id === n.sectionId),
                    i = a ? e.sections[a.type] : void 0;
                return i ? .fields.find(e => e.id === n.fieldId) ? .cutout === !0
            }
            async function v(e, t, n) {
                let a = new FormData;
                a.append("kind", n), a.append("file", t, t.name);
                try {
                    let t = await fetch(`/api/projects/${encodeURIComponent(e)}/engine-uploads`, {
                        method: "POST",
                        headers: {
                            "x-upload-kind": n
                        },
                        credentials: "same-origin",
                        body: a
                    });
                    return p(t)
                } catch {
                    return {
                        ok: !1,
                        status: 0,
                        message: "audio" === n ? "Your music file did not finish uploading. Please check your internet and try again." : "Your photo did not finish uploading. Please check your internet and try again."
                    }
                }
            }
            async function w(e, t, n) {
                let a = t.name || ("audio" === n ? "song.mp3" : "photo.webp"),
                    i = t;
                return ("audio" === n && (a.toLowerCase().endsWith(".mp3") || (a = `${a}.mp3`), "audio/mpeg" !== t.type && (i = new Blob([t], {
                    type: "audio/mpeg"
                }))), await (0, u.Ai)({
                    fieldPath: e,
                    blob: i,
                    fileName: a,
                    kind: n
                })) ? {
                    ok: !0,
                    sentinel: (0, c.BI)(e)
                } : {
                    ok: !1,
                    message: "This browser couldn't keep that file. Sign in to save it to your account."
                }
            }
        },
        29144: (e, t, n) => {
            n.d(t, {
                _X: () => d,
                aI: () => s,
                kB: () => l
            });
            var a = n(73365),
                i = n(1521);

            function o() {
                let e = null;
                return {
                    register: t => (e = t, () => {
                        e === t && (e = null)
                    }),
                    run: () => e ? .()
                }
            }
            let r = (0, i.createContext)(null);

            function s({
                session: e,
                children: t
            }) {
                let [n, l] = (0, i.useState)({}), [d] = (0, i.useState)(o), u = (0, i.useMemo)(() => "project" === e.kind ? { ...e,
                    project: { ...e.project,
                        ...n
                    }
                } : e, [e, n]), c = (0, i.useMemo)(() => ({
                    session: u,
                    updateProject: e => l(t => ({ ...t,
                        ...e
                    })),
                    pay: d
                }), [u, d]);
                return (0, a.jsx)(r.Provider, {
                    value: c,
                    children: t
                })
            }

            function l() {
                let e = (0, i.useContext)(r);
                if (!e) throw Error("useCutiepageEditorSession must be used inside StudioEditor");
                return e
            }

            function d() {
                let {
                    session: e
                } = l();
                return "project" === e.kind ? e.project : null
            }
        },
        33736: (e, t, n) => {
            n.d(t, {
                DT: () => h,
                EF: () => g,
                kt: () => w,
                oS: () => y,
                tA: () => v
            });
            var a = n(1521),
                i = n(22751),
                o = n(16995),
                r = n(85319),
                s = n(89973),
                l = n(77420),
                d = n(40646);
            let u = ["desktop", "tablet", "phone"];

            function c(e, t, n) {
                if (!n || t ? .kind !== "element") return null;
                let a = new Set(((0, r.rv)(e, t.pageId, t.sectionId) ? .elements ? ? []).map(e => e.id)),
                    i = n.filter(e => a.has(e));
                return i.length >= 2 && i.includes(t.elementId) ? i : null
            }
            let p = {
                setElementFrame: "move",
                setOffset: "move",
                moveSection: "move",
                moveItem: "move",
                moveElementItem: "move",
                movePage: "move",
                setFreeHeight: "resize",
                moveElementZ: "layer order",
                removeElement: "delete",
                removeSection: "delete",
                removeItem: "delete",
                removeElementItem: "delete",
                removePage: "delete",
                addElement: "add",
                addSection: "add",
                addItem: "add",
                addElementItem: "add",
                addPage: "add",
                insertPreset: "add",
                duplicateElement: "duplicate",
                duplicateSection: "duplicate",
                duplicateItem: "duplicate",
                setElementHidden: "hide",
                setSectionHidden: "hide",
                setItemHidden: "hide",
                setElementItemHidden: "hide",
                setElementLocked: "lock",
                setTheme: "style",
                applyPreset: "style",
                setSectionTheme: "style",
                setItemTheme: "style",
                setItemStyle: "style",
                setElementCreator: "style",
                setDocumentCss: "style",
                setSectionField: "edit",
                setItemField: "edit",
                updateElementItem: "edit",
                setSound: "music",
                setLogic: "interaction",
                resetToTemplate: "reset"
            };

            function m(e, t) {
                return e.pages.some(e => e.id === t) ? t : e.pages[0] ? .id ? ? t
            }

            function h(e, t) {
                if (!t || e === t) return !1;
                let n = Date.parse(e),
                    a = Date.parse(t);
                return !Number.isNaN(n) && !Number.isNaN(a) && n < a
            }

            function g(e) {
                let t = "updatedAt" in e ? e.updatedAt : void 0;
                return "string" == typeof t && "" !== t ? t : void 0
            }
            let f = (0, a.createContext)(null);

            function y({
                site: e,
                template: t,
                valueOptions: n,
                frames: o,
                children: g
            }) {
                let [v] = (0, a.useState)(() => (function(e) {
                    let {
                        document: t,
                        ...n
                    } = e.site, a = "phone" === e.template.frame, o = (e, t) => !a || "phone" === t || (0, s.ll)(e, t) ? t : "phone", g = new WeakMap;
                    return (0, i.y)()((i, s) => ({
                        site: n,
                        template: e.template,
                        doc: t,
                        pageId: t.pages[0] ? .id ? ? "home",
                        selection: null,
                        multi: null,
                        hover: null,
                        tool: "select",
                        zoom: .5,
                        frames: a ? ["phone"] : e.frames && e.frames.length > 0 ? [...e.frames] : u,
                        breakpoint: a ? "phone" : "desktop",
                        past: [],
                        future: [],
                        lastGesture: null,
                        revision: 0,
                        savedRevision: 0,
                        saveState: "saved",
                        saveError: null,
                        lastError: null,
                        stale: null,
                        siteWritesInFlight: 0,
                        editLimits: null,
                        dispatch(t, n) {
                            let a, u = s();
                            if (u.editLimits) {
                                let e = (0, d.MR)(u.doc, Array.isArray(t) ? t : [t], u.editLimits);
                                if (e >= 0) return n ? .silent || i({
                                    lastError: d.xo
                                }), {
                                    ok: !1,
                                    error: d.xo,
                                    index: e
                                }
                            }
                            let h = (0, l.Lx)(u.doc, t, u.template, e.valueOptions);
                            if (!h.ok) return n ? .silent || i({
                                lastError: h.error
                            }), h;
                            let f = n ? .gesture !== void 0 && n.gesture === u.lastGesture ? u.past : [...u.past, u.doc].slice(-100);
                            g.set(h.doc, n ? .label ? ? ((a = (Array.isArray(t) ? t : [t])[0]) ? "updateElement" === a.op ? a.values ? "edit" : "style" : p[a.op] ? ? "change" : "change"));
                            let y = (0, r.Bs)(h.doc, u.selection) ? u.selection : null;
                            return i({
                                doc: h.doc,
                                past: f,
                                future: [],
                                lastGesture: n ? .gesture ? ? null,
                                revision: u.revision + 1,
                                saveState: "dirty",
                                lastError: null,
                                pageId: m(h.doc, u.pageId),
                                breakpoint: o(h.doc, u.breakpoint),
                                selection: y,
                                multi: c(h.doc, y, u.multi),
                                hover: (0, r.Bs)(h.doc, u.hover) ? u.hover : null
                            }), h
                        },
                        undo() {
                            let e = s(),
                                t = e.past[e.past.length - 1];
                            if (!t) return null;
                            let n = (0, r.Bs)(t, e.selection) ? e.selection : null;
                            return i({
                                doc: t,
                                past: e.past.slice(0, -1),
                                future: [e.doc, ...e.future].slice(0, 100),
                                lastGesture: null,
                                revision: e.revision + 1,
                                saveState: "dirty",
                                pageId: m(t, e.pageId),
                                breakpoint: o(t, e.breakpoint),
                                selection: n,
                                multi: c(t, n, e.multi),
                                hover: null
                            }), g.get(e.doc) ? ? "change"
                        },
                        redo() {
                            let e = s(),
                                t = e.future[0];
                            if (!t) return null;
                            let n = (0, r.Bs)(t, e.selection) ? e.selection : null;
                            return i({
                                doc: t,
                                past: [...e.past, e.doc].slice(-100),
                                future: e.future.slice(1),
                                lastGesture: null,
                                revision: e.revision + 1,
                                saveState: "dirty",
                                pageId: m(t, e.pageId),
                                breakpoint: o(t, e.breakpoint),
                                selection: n,
                                multi: c(t, n, e.multi),
                                hover: null
                            }), g.get(t) ? ? "change"
                        },
                        select: e => i({
                            selection: e,
                            multi: null,
                            lastGesture: null
                        }),
                        selectPieces({
                            pageId: e,
                            sectionId: t
                        }, n, a) {
                            let o = [...new Set(n)],
                                r = a && o.includes(a) ? a : o[o.length - 1];
                            if (!r) return void i({
                                selection: {
                                    kind: "section",
                                    pageId: e,
                                    sectionId: t
                                },
                                multi: null,
                                lastGesture: null
                            });
                            let l = {
                                kind: "element",
                                pageId: e,
                                sectionId: t,
                                elementId: r
                            };
                            i({
                                selection: l,
                                multi: c(s().doc, l, o),
                                lastGesture: null
                            })
                        },
                        setHover: e => i({
                            hover: e
                        }),
                        setTool: e => i({
                            tool: e
                        }),
                        setZoom: e => i({
                            zoom: Math.min(2, Math.max(.1, e))
                        }),
                        setFrames: e => {
                            0 !== e.length && i({
                                frames: [...e]
                            })
                        },
                        setBreakpoint: e => {
                            let t = o(s().doc, e);
                            s().breakpoint !== t && i({
                                breakpoint: t
                            })
                        },
                        setPage: e => i({
                            pageId: e,
                            selection: null,
                            multi: null,
                            hover: null
                        }),
                        setSite: e => i({
                            site: { ...s().site,
                                ...e
                            }
                        }),
                        beginSiteWrite: () => i({
                            siteWritesInFlight: s().siteWritesInFlight + 1
                        }),
                        endSiteWrite(e) {
                            let t = s();
                            i({
                                siteWritesInFlight: Math.max(0, t.siteWritesInFlight - 1),
                                ...void 0 !== e && !h(e, t.site.updatedAt) ? {
                                    site: { ...t.site,
                                        updatedAt: e
                                    }
                                } : {}
                            })
                        },
                        endGesture: () => i({
                            lastGesture: null
                        }),
                        clearError: () => i({
                            lastError: null
                        }),
                        notify: e => i({
                            lastError: e
                        }),
                        setEditLimits: e => {
                            s().editLimits !== e && i({
                                editLimits: e
                            })
                        },
                        markSaving: () => i({
                            saveState: "saving",
                            saveError: null
                        }),
                        markSaved(e, t) {
                            var n;
                            let a, o = s();
                            i({
                                savedRevision: Math.max(o.savedRevision, e),
                                saveState: e >= o.revision ? "saved" : "dirty",
                                saveError: null,
                                site: t ? (n = o.site, a = { ...n,
                                    ...t
                                }, void 0 !== t.updatedAt && h(t.updatedAt, n.updatedAt) && (a.updatedAt = n.updatedAt), a) : o.site
                            })
                        },
                        markSaveError: e => i({
                            saveState: "error",
                            saveError: e
                        }),
                        setStale(e) {
                            let t = s(),
                                n = e && "saving" === t.saveState ? t.revision > t.savedRevision ? "dirty" : "saved" : t.saveState;
                            i({
                                stale: e,
                                saveState: n
                            })
                        },
                        reloadLatest() {
                            let e = s(),
                                t = e.stale;
                            if (!t) return;
                            let {
                                document: n,
                                ...a
                            } = t, l = e.revision + 1;
                            i({
                                doc: n,
                                past: [...e.past, e.doc].slice(-100),
                                future: [],
                                lastGesture: null,
                                revision: l,
                                savedRevision: l,
                                saveState: "saved",
                                saveError: null,
                                lastError: null,
                                stale: null,
                                site: { ...e.site,
                                    ...a
                                },
                                pageId: m(n, e.pageId),
                                breakpoint: o(n, e.breakpoint),
                                selection: (0, r.Bs)(n, e.selection) ? e.selection : null,
                                multi: null,
                                hover: null
                            })
                        }
                    }))
                })({
                    site: e,
                    template: t,
                    valueOptions: n,
                    frames: o
                }));
                return (0, a.createElement)(f.Provider, {
                    value: v
                }, g)
            }

            function v() {
                let e = (0, a.useContext)(f);
                if (!e) throw Error("useFolioEditor must be used inside FolioEditorProvider");
                return e
            }

            function w(e) {
                return (0, o.P)(v(), e)
            }
        },
        35104: (e, t, n) => {
            n.d(t, {
                wt: () => u,
                e3: () => g,
                YH: () => c
            });
            var a = n(51801),
                i = n(70704),
                o = n(47060),
                r = n(17701);
            n(52550);
            let s = "cp_guest_details";

            function l(e) {
                return "string" == typeof e ? e.trim() : ""
            }
            async function d() {
                let e = function() {
                    try {
                        let e = JSON.parse(localStorage.getItem(s) ? ? "null");
                        if (!e || "string" != typeof e.email || "string" != typeof e.phone || "email" !== e.channel && "whatsapp" !== e.channel || "number" != typeof e.at || Date.now() - e.at > 18e5) return null;
                        return e
                    } catch {
                        return null
                    }
                }();
                if (e) try {
                    let t, a, {
                            createSupabaseBrowserClient: i
                        } = await Promise.all([n.e(74339), n.e(16937), n.e(88681)]).then(n.bind(n, 11062)),
                        o = i(),
                        {
                            data: r
                        } = await o.auth.getSession(),
                        d = r.session ? .user;
                    if (!d) return;
                    let u = (t = d.user_metadata ? ? {}, a = {}, d.phone || l(t.phone) || (a.phone = e.phone), d.email || l(t.contact_email) || (a.contact_email = e.email), Object.keys(a).length > 0 ? a : null);
                    if (u) {
                        let {
                            error: e
                        } = await o.auth.updateUser({
                            data: u
                        });
                        if (e) return;
                        await o.auth.refreshSession()
                    }
                    try {
                        localStorage.removeItem(s)
                    } catch {}
                } catch {}
            }
            async function u(e, t = {}) {
                let n = p(),
                    a = await m(e, t);
                return await n, a
            }
            async function c(e) {
                let [t] = await Promise.all([f(e, void 0, !1), p()]);
                return "string" == typeof t ? {
                    ok: !0,
                    projectId: t
                } : t
            }

            function p() {
                return Promise.race([d(), new Promise(e => setTimeout(e, 4e3))])
            }
            async function m(e, {
                onProgress: t,
                intoProjectId: n,
                keepDraft: o = !1
            }) {
                let r, s = (0, a.ri)(e.draftContent),
                    l = !n && 0 === s.length,
                    d = n ? ? await f(e, t, l);
                if ("string" != typeof d) return d;
                if (l) return h(e, d, o);
                let u = {};
                if (s.length > 0) {
                    let e = 0;
                    t ? .("uploading", {
                        done: 0,
                        total: s.length
                    });
                    let n = null,
                        a = [...s];
                    async function c() {
                        for (;;) {
                            let o, r, l = a.shift();
                            if (void 0 === l || n) return;
                            let c = await (0, i.LW)(l);
                            if (!c) continue;
                            let p = (0, i.tu)(c);
                            try {
                                o = new Blob([await c.blob.arrayBuffer()], {
                                    type: "audio" === p ? "audio/mpeg" : c.blob.type
                                })
                            } catch {
                                continue
                            }
                            let m = c.fileName;
                            "audio" !== p || m.toLowerCase().endsWith(".mp3") || (m = `${m}.mp3`);
                            let h = new FormData;
                            h.append("projectId", d), h.append("kind", p), h.append("file", o, m);
                            let g = null,
                                f = !1;
                            for (let e = 0; e < 2; e += 1) {
                                f = !1;
                                try {
                                    r = await fetch("/api/uploads/direct", {
                                        method: "POST",
                                        signal: AbortSignal.timeout(6e4),
                                        headers: {
                                            "x-upload-kind": p
                                        },
                                        body: h
                                    })
                                } catch {
                                    f = !0, r = void 0
                                }
                                if (r && (g = await r.json().catch(() => null), r.ok && g ? .data ? .secureUrl)) break;
                                let t = r ? .status ? ? 0;
                                if (!(f || 408 === t || 429 === t || t >= 500 || 400 === t) || 1 === e) break;
                                await new Promise(e => setTimeout(e, 800))
                            }
                            let y = g ? .data ? .secureUrl;
                            if (!r ? .ok || !y) {
                                n = {
                                    status: r ? .status ? ? 0,
                                    message: (f ? null : g ? .error ? .message) ? ? ("audio" === p ? "We couldn't save your music. Please try again." : "We couldn't save one of your photos. Please try again.")
                                };
                                return
                            }
                            u[l] = y, e += 1, t ? .("uploading", {
                                done: e,
                                total: s.length
                            })
                        }
                    }
                    if (await Promise.all(Array.from({
                            length: Math.min(3, s.length)
                        }, () => c())), n) {
                        let {
                            message: e,
                            status: t
                        } = n;
                        return {
                            ok: !1,
                            projectId: d,
                            message: e,
                            stage: "uploading",
                            status: t
                        }
                    }
                }
                let p = (0, a.TP)(e.draftContent, u);
                if ((0, a.ri)(p).length > 0) return {
                    ok: !1,
                    projectId: d,
                    stage: "uploading",
                    status: 0,
                    message: "Some of your photos couldn't be restored. Please re-add them and try again."
                };
                t ? .("saving");
                try {
                    r = await fetch(`/api/projects/${d}`, {
                        method: "PATCH",
                        signal: AbortSignal.timeout(2e4),
                        headers: {
                            "content-type": "application/json"
                        },
                        body: JSON.stringify({
                            name: e.name,
                            draftContent: p,
                            themeTokens: e.themeTokens ? ? {}
                        })
                    })
                } catch {
                    return {
                        ok: !1,
                        projectId: d,
                        stage: "saving",
                        status: 0,
                        message: "We couldn't save your page. Please check your connection and try again."
                    }
                }
                if (!r.ok) {
                    let e = await r.json().catch(() => null);
                    return {
                        ok: !1,
                        projectId: d,
                        stage: "saving",
                        status: r.status,
                        message: e ? .error ? .message ? ? "We couldn't save your page. Please try again."
                    }
                }
                return h(e, d, o)
            }

            function h(e, t, n) {
                return n || g(e), {
                    ok: !0,
                    projectId: t
                }
            }

            function g(e) {
                (0, o.l2)(e.templateSlug), (0, r.HJ)(e.templateSlug), (0, r.EH)(e)
            }
            async function f(e, t, n) {
                let a;
                t ? .("creating");
                try {
                    a = await fetch("/api/guest-drafts/claim", {
                        method: "POST",
                        signal: AbortSignal.timeout(2e4),
                        headers: {
                            "content-type": "application/json"
                        },
                        body: JSON.stringify(n ? {
                            templateSlug: e.templateSlug,
                            save: {
                                name: e.name,
                                draftContent: e.draftContent,
                                themeTokens: e.themeTokens ? ? {}
                            }
                        } : {
                            templateSlug: e.templateSlug
                        })
                    })
                } catch {
                    return {
                        ok: !1,
                        stage: "creating",
                        status: 0,
                        message: "We couldn't set up your page. Please check your connection and try again."
                    }
                }
                let i = await a.json().catch(() => null),
                    o = i ? .data ? .projectId;
                return !a.ok && n && o ? {
                    ok: !1,
                    projectId: o,
                    stage: "saving",
                    status: a.status,
                    message: i ? .error ? .message ? ? "We couldn't save your page. Please try again."
                } : a.ok && o ? o : {
                    ok: !1,
                    stage: "creating",
                    status: a.status,
                    message: i ? .error ? .message ? ? "We couldn't set up your page. Please try again."
                }
            }
        },
        36084: (e, t, n) => {
            n.d(t, {
                Af: () => l,
                F3: () => o,
                HG: () => s,
                OK: () => i,
                QM: () => r
            });
            var a = n(82055);

            function i(e) {
                return `/dashboard/projects/${e}/video`
            }
            let o = `Your video's ${a.kq} hours of edits are over. You can still download it anytime from your dashboard.`;

            function r(e) {
                return `Get my video \xb7 ${e}`
            }
            let s = {
                    title: "Get my video",
                    readyLabel: "Your video is ready to make",
                    summaryLine: "Video \xb7 download anytime",
                    includes: ["One-time payment", "HD video (MP4)", "Share or download", "Download again anytime", `Edits for ${a.kq} hours`]
                },
                l = "Download video"
        },
        40646: (e, t, n) => {
            n.d(t, {
                Ih: () => s,
                MR: () => r,
                xo: () => i
            });
            var a = n(85319);
            let i = "This part of the design can't be changed.";

            function o(e, t, n, i) {
                if (!i || !n) return !0;
                let o = (0, a.Kt)(e, t.pageId, t.sectionId, t.elementId);
                return !o || Object.keys(n).every(e => i(o, e))
            }

            function r(e, t, n) {
                return t.findIndex(t => ! function(e, t, n) {
                    switch (t.op) {
                        case "updateElement":
                            if (n.lockStructure && (t.style || t.unsetStyle || t.styleBy)) return !1;
                            return o(e, t, t.values, n.fieldFilter);
                        case "updateElementItem":
                            if (void 0 === t.elementId) return !n.lockStructure;
                            return o(e, {
                                pageId: t.pageId,
                                sectionId: t.sectionId,
                                elementId: t.elementId
                            }, t.values, n.fieldFilter);
                        case "setSound":
                            return !0;
                        default:
                            return !n.lockStructure
                    }
                }(e, t, n))
            }

            function s(e, t) {
                return null !== e.editLimits && r(e.doc, [t], e.editLimits) >= 0
            }
        },
        47433: (e, t, n) => {
            n.d(t, {
                $I: () => a,
                ql: () => i
            });
            let a = [{
                slug: "birthday",
                category: "Birthday",
                path: "/birthday-templates",
                name: "Birthday",
                title: "Birthday website templates",
                metaDescription: "Birthday website templates you personalise in minutes. Add photos, a message and a song, then send one link that unfolds like a little story.",
                intro: "A birthday page beats a midnight text. Pick a design, drop in their photos and your words, and send one link that opens into confetti, flip-card wishes and a letter they will keep.",
                tagline: "Confetti, wishes, and a letter at the end.",
                keywords: ["birthday website template", "birthday gift website", "online birthday surprise", "personalised birthday page"],
                faq: [{
                    question: "How long does a birthday page take to make?",
                    answer: "About 30 seconds if you already have the photos. Pick a template, fill in the names and words, hit Make it live, and share the link."
                }, {
                    question: "Can I schedule it for midnight?",
                    answer: "Make it live whenever you like and send the link at 12:00. It stays live for life."
                }, {
                    question: "Do they need an app or an account to open it?",
                    answer: "No. It is a normal link that opens in any phone browser, with no sign-up on their side."
                }],
                palette: {
                    ground: "#FDF6EC",
                    ink: "#C97B8A",
                    accent: "#E9B8C0"
                },
                coverImageUrl: "https://cdn.cutiepage.in/static/catalog/covers/birthday.webp"
            }, {
                slug: "love",
                category: "Love",
                path: "/love-templates",
                name: "Love",
                title: "Love website templates for your partner",
                metaDescription: "Romantic website templates for a girlfriend, boyfriend or partner. Your photos, your story, your song, on one private link.",
                intro: "For the person who deserves more than a caption. These pages carry your photos, your inside jokes and your song, and open into something they will scroll through twice.",
                tagline: "Your story, told the way you would tell it.",
                keywords: ["love website template", "website for girlfriend", "website for boyfriend", "romantic surprise website"],
                faq: [{
                    question: "Is the page private?",
                    answer: "Yes. You set a password when you make your page live, so only the person you share the link with can open it."
                }, {
                    question: "Can I add our song?",
                    answer: "Most love templates have a music slot. Upload an audio file and it plays as they scroll."
                }, {
                    question: "Can I edit it after sending?",
                    answer: "Any time. Edit and the same link updates, so a typo never has to be a thing."
                }],
                palette: {
                    ground: "#FBEEF0",
                    ink: "#C4574A",
                    accent: "#F0A99C"
                },
                coverImageUrl: "https://cdn.cutiepage.in/static/catalog/covers/love.webp"
            }, {
                slug: "anniversary",
                category: "Anniversary",
                path: "/anniversary-templates",
                name: "Anniversary",
                title: "Anniversary website templates",
                metaDescription: "Anniversary website templates that turn your years together into a page: a timeline, your photos, and a letter, shared as one link.",
                intro: "One year or twenty. An anniversary page lays your years out in order, with the photos, the milestones and the letter you never quite manage to say out loud.",
                tagline: "Every year, in order, on one page.",
                keywords: ["anniversary website template", "anniversary gift website", "first anniversary surprise", "wedding anniversary page"],
                faq: [{
                    question: "Does it work for a parents' anniversary too?",
                    answer: "Yes. The same templates work for your own relationship or for a page the whole family signs for your parents."
                }, {
                    question: "How many photos can I add?",
                    answer: "It varies by template, but every anniversary design has room for a gallery and a timeline."
                }, {
                    question: "Is it a one-time payment?",
                    answer: "Yes. One payment, and the page stays live for life with no renewals."
                }],
                palette: {
                    ground: "#F8F3E9",
                    ink: "#B08A3E",
                    accent: "#E4CD98"
                },
                coverImageUrl: "https://cdn.cutiepage.in/static/catalog/covers/anniversary.webp"
            }, {
                slug: "wedding",
                category: "Wedding",
                path: "/wedding-templates",
                name: "Wedding",
                title: "Wedding website templates",
                metaDescription: "Wedding website templates for invitations, the couple's story and the event schedule, ready to share as one link with every guest.",
                intro: "An invitation that opens, not a PDF that downloads. Wedding pages hold the couple's story, the dates and venues, and a gallery, on one link every guest can save.",
                tagline: "The invite, the story, the schedule.",
                keywords: ["wedding website template", "wedding invitation website", "indian wedding website", "digital wedding invite"],
                faq: [{
                    question: "Can I use it as the wedding invitation?",
                    answer: "Yes. Add the dates, venues and schedule, and send the link on WhatsApp instead of a PDF."
                }, {
                    question: "Can guests open it without an app?",
                    answer: "Yes. It is a normal web link that opens on any phone."
                }, {
                    question: "Can I update the schedule later?",
                    answer: "Any time. Edit the page and every guest's link shows the change."
                }],
                palette: {
                    ground: "#EDF2E9",
                    ink: "#7A8F62",
                    accent: "#D9B85A"
                },
                coverImageUrl: "https://cdn.cutiepage.in/static/catalog/covers/wedding.webp",
                collectionLink: {
                    path: "/collections/wedding-invite",
                    label: "Make a wedding invite with a link for every guest",
                    templateSlug: "cp-wedding-invite"
                }
            }, {
                slug: "family",
                category: "Family",
                path: "/family-templates",
                name: "Family",
                title: "Family website templates for parents and siblings",
                metaDescription: "Website templates for Mother's Day, Father's Day, siblings and the whole family. Photos, a message and a page they can keep.",
                intro: "For the people who have every photo of you already. Family pages are built for parents and siblings: warm, simple, and easy for anyone to open and keep.",
                tagline: "For the people who raised you.",
                keywords: ["mother's day website", "father's day website", "family gift website", "page for parents"],
                faq: [{
                    question: "Will my parents be able to open it easily?",
                    answer: "Yes. It is a link that opens in any browser, with nothing to install and no account to make."
                }, {
                    question: "Can siblings contribute?",
                    answer: "Collect the photos and messages, add them in the editor, and make it live as one page from everyone."
                }, {
                    question: "Can I print a QR code for it?",
                    answer: "Every live page comes with a QR code you can print on a card or frame."
                }],
                palette: {
                    ground: "#F6EFE4",
                    ink: "#B5674A",
                    accent: "#E8BBA4"
                },
                coverImageUrl: "https://cdn.cutiepage.in/static/catalog/covers/family.webp"
            }, {
                slug: "friendship",
                category: "Friendship",
                path: "/friendship-templates",
                name: "Friendship",
                title: "Friendship website templates for your best friend",
                metaDescription: "Website templates for best friends and friendship day. The inside jokes, the photos, the chaos, on one link they will screenshot.",
                intro: "For the friend who has been there for all of it. These pages are built for inside jokes, ugly photos, and the kind of letter you would never say out loud.",
                tagline: "The inside jokes, finally documented.",
                keywords: ["friendship day website", "best friend gift website", "friendship page online", "digital gift for best friend"],
                faq: [{
                    question: "Can I make one for a group of friends?",
                    answer: "Yes. Add everyone's photos and messages; the page works for one friend or the whole group."
                }, {
                    question: "Does it work for a long-distance friend?",
                    answer: "That is what it is for. Send the link and it opens anywhere in the world."
                }, {
                    question: "Can I add videos?",
                    answer: "Templates support photos and music. For video, link to it from the page's message."
                }],
                palette: {
                    ground: "#FBF3DE",
                    ink: "#B8892A",
                    accent: "#E7C15A"
                },
                coverImageUrl: "https://cdn.cutiepage.in/static/catalog/covers/friendship.webp"
            }, {
                slug: "apology",
                category: "Apology",
                path: "/apology-templates",
                name: "Apology",
                title: "Apology website templates",
                metaDescription: "Apology website templates for when a text is not enough. A page that says sorry properly, with your words and a way back.",
                intro: "When a text will not do. An apology page gives your words room, asks the question once, and lets them answer yes on the page itself.",
                tagline: "Say it properly. Then wait.",
                keywords: ["apology website", "sorry website template", "cute apology page", "will you forgive me page"],
                faq: [{
                    question: "Can they respond on the page?",
                    answer: "Most apology templates end with a yes/no moment, so the answer is part of the page."
                }, {
                    question: "Is it private?",
                    answer: "Yes. Set a password when you make your page live and only they can open the link."
                }, {
                    question: "How fast can I make one?",
                    answer: "About 30 seconds. Fill in the words, add a photo if you want, make it live, and send the link."
                }],
                palette: {
                    ground: "#F0ECF5",
                    ink: "#7B6A9E",
                    accent: "#C9B8E0"
                },
                coverImageUrl: "https://cdn.cutiepage.in/static/catalog/covers/apology.webp"
            }, {
                slug: "festival",
                category: "Festival",
                path: "/festival-templates",
                name: "Festival",
                title: "Festival greeting website templates",
                metaDescription: "Festival website templates for Raksha Bandhan, Diwali and every celebration in between. A greeting that opens, not a forwarded image.",
                intro: "A festival wish that is actually yours. These pages replace the forwarded image with a greeting that carries your names, your photos and your words.",
                tagline: "A wish they will not forward. They will keep it.",
                keywords: ["raksha bandhan website", "diwali greeting website", "festival wish online", "personalised festival greeting"],
                faq: [{
                    question: "Which festivals do the templates cover?",
                    answer: "Raksha Bandhan today, with more festival designs landing through the year. Any festival page also works as a general greeting."
                }, {
                    question: "Can I send it to many people?",
                    answer: "One page, one link. Share it with as many people as you like; everyone sees the same page."
                }, {
                    question: "Does it stay live after the festival?",
                    answer: "Yes. Every live page stays live for life."
                }],
                palette: {
                    ground: "#FAF0E0",
                    ink: "#C0662E",
                    accent: "#EFA94A"
                },
                coverImageUrl: "https://cdn.cutiepage.in/static/catalog/covers/festival.webp"
            }];

            function i(e) {
                let t = Object.fromEntries(a.map(e => [e.slug, 0]));
                for (let n of e) {
                    let e = function(e) {
                        return a.find(t => t.category === e) ? ? null
                    }(n.category);
                    e && (t[e.slug] += 1)
                }
                return t
            }
            a.map(e => e.path)
        },
        68279: (e, t, n) => {
            n.d(t, {
                LX: () => f,
                Mg: () => w,
                N1: () => v,
                kh: () => k,
                p6: () => y
            });
            var a = n(37809),
                i = n(81042);
            let o = "cp_ed_j",
                r = {
                    read() {
                        try {
                            let e = window.sessionStorage.getItem(o),
                                t = e ? JSON.parse(e) : null;
                            return t && "object" == typeof t && !Array.isArray(t) ? t : {}
                        } catch {
                            return {}
                        }
                    },
                    write(e) {
                        try {
                            window.sessionStorage.setItem(o, JSON.stringify(e))
                        } catch {}
                    }
                };

            function s() {
                try {
                    if ("u" > typeof crypto && "randomUUID" in crypto) return crypto.randomUUID().replace(/-/g, "").slice(0, 24)
                } catch {}
                return `${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`.slice(0, 24)
            }
            let l = e => `p:${e}`,
                d = e => `g:${e}`;

            function u(e, t) {
                let n = {};
                for (let [a, i] of Object.entries(e)) i && "number" == typeof i.lastAt && t - i.lastAt < 864e5 && (n[a] = i);
                return n
            }

            function c(e, t) {
                if ("playground" === t.mode) return;
                let n = u(e.read(), Date.now());
                n[t.projectId ? l(t.projectId) : d(t.templateSlug)] = t, e.write(n)
            }

            function p(e, t, n, a = {}) {
                let i = "";
                try {
                    i = window.location.pathname
                } catch {}
                return {
                    name: e,
                    path: i,
                    template_slug: t.templateSlug,
                    project_id: t.projectId ? ? void 0,
                    props: {
                        editor: t.editor,
                        device: t.device,
                        mode: t.mode,
                        editor_session: n,
                        journey: t.id,
                        ...a
                    }
                }
            }
            let m = {
                    editor_open: "editor_open",
                    editor_continue_click: "editor_continue",
                    editor_publish_success: "publish"
                },
                h = e => {
                    (0, a.G4)(e),
                    function(e) {
                        let t = m[e.name];
                        if (!t) return;
                        let n = e.props ? ? {};
                        "playground" === n.mode || ("editor_open" !== e.name || 1 === n.journey_start) && (0, i.$m)(t, {
                            template_slug: e.template_slug,
                            editor_kind: n.editor,
                            editor_mode: n.mode
                        })
                    }(e)
                },
                g = null;

            function f() {
                return g
            }

            function y(e, t = {}) {
                let n, i = t.storage ? ? r,
                    o = t.sink ? ? h,
                    m = t.now ? ? Date.now,
                    f = s(),
                    v = new Map,
                    w = m(),
                    k = 0,
                    b = null,
                    I = !1,
                    S = !0;
                try {
                    let a = function(e, t) {
                        let {
                            storage: n,
                            now: a
                        } = t, i = u(n.read(), a);
                        if ("playground" === e.mode) return {
                            started: !0,
                            journey: {
                                id: t.newId(),
                                editor: e.editor,
                                device: t.device,
                                mode: "playground",
                                templateSlug: e.templateSlug,
                                projectId: e.projectId,
                                startedAt: a,
                                lastAt: a,
                                firstEditSent: !1,
                                handoff: !1,
                                sessionId: t.sessionId
                            }
                        };
                        let o = (t, n) => !!t && a - t.lastAt < n && t.editor === e.editor,
                            r = null;
                        if (e.projectId) {
                            let t = i[l(e.projectId)];
                            if (o(t, 432e5)) r = t;
                            else {
                                let t = i[d(e.templateSlug)];
                                o(t, 72e5) && t.handoff && (r = { ...t,
                                    projectId: e.projectId,
                                    handoff: !1
                                }, delete i[d(e.templateSlug)])
                            }
                        } else {
                            let t = i[d(e.templateSlug)];
                            o(t, 432e5) && (r = t)
                        }
                        let s = null === r,
                            c = r ? { ...r,
                                lastAt: a,
                                sessionId: t.sessionId
                            } : {
                                id: t.newId(),
                                editor: e.editor,
                                device: t.device,
                                mode: e.mode,
                                templateSlug: e.templateSlug,
                                projectId: e.projectId,
                                startedAt: a,
                                lastAt: a,
                                firstEditSent: !1,
                                handoff: !1,
                                sessionId: t.sessionId
                            };
                        return i[e.projectId ? l(e.projectId) : d(e.templateSlug)] = c, n.write(i), {
                            journey: c,
                            started: s
                        }
                    }(e, {
                        storage: i,
                        now: m(),
                        device: t.device ? ? function() {
                            try {
                                return window.matchMedia("(max-width: 1023.98px)").matches ? "mobile" : "desktop"
                            } catch {
                                return "desktop"
                            }
                        }(),
                        newId: s,
                        sessionId: f
                    });
                    n = a.journey, S = a.started
                } catch {
                    n = {
                        id: s(),
                        editor: e.editor,
                        device: "desktop",
                        mode: e.mode,
                        templateSlug: e.templateSlug,
                        projectId: e.projectId,
                        startedAt: 0,
                        lastAt: 0,
                        firstEditSent: !1,
                        handoff: !1,
                        sessionId: f
                    }
                }
                let A = (e, t) => {
                        try {
                            o(p(e, n, f, t))
                        } catch {}
                    },
                    E = () => {
                        try {
                            n = { ...n,
                                lastAt: m()
                            }, c(i, n)
                        } catch {}
                    };
                A("editor_open", {
                    journey_start: +!!S,
                    has_music: +!!e.hasMusic,
                    needs_payment: null === e.needsPayment ? null : +!!e.needsPayment,
                    engine: e.engine
                });
                let j = {
                    get journey() {
                        return n
                    },
                    sessionId: f,
                    track(e, t) {
                        let n = v.get(e) ? ? 0;
                        n >= 20 || (v.set(e, n + 1), ("editor_continue_click" === e || "editor_checkout_open" === e || "editor_publish_success" === e) && (I = !0), A(e, t), E())
                    },
                    noteEdit() {
                        k += 1
                    },
                    section(e) {
                        e && (b = e.slice(0, 48))
                    },
                    exit(e) {
                        let t = v.get("editor_exit") ? ? 0;
                        if (!(t >= 20)) {
                            v.set("editor_exit", t + 1), A("editor_exit", {
                                reason: e,
                                edits: k,
                                active_s: Math.min(Math.round((m() - w) / 1e3), 86400),
                                continued: +!!I,
                                last_section: b
                            });
                            try {
                                (0, a.Sm)(!0)
                            } catch {}
                        }
                    },
                    firstEdit() {
                        k += 1, n.firstEditSent || (n = { ...n,
                            firstEditSent: !0
                        }, A("editor_first_edit"), E())
                    },
                    markGuestHandoff() {
                        try {
                            n = { ...n,
                                handoff: !0,
                                lastAt: m()
                            }, c(i, n)
                        } catch {}
                    }
                };
                return g = j, j
            }

            function v(e) {
                e && g === e && (g = null)
            }

            function w(e) {
                g = e
            }

            function k(e, t, n = {}, a = {}) {
                try {
                    let i = g;
                    if (i && i.journey.projectId === e) return i.track(t, {
                        surface: "editor",
                        ...n
                    }), !0;
                    let o = a.storage ? ? r,
                        s = (a.now ? ? Date.now)(),
                        d = u(o.read(), s)[l(e)];
                    if (!d || s - d.lastAt >= 432e5) return !1;
                    return (a.sink ? ? h)(p(t, d, d.sessionId, {
                        surface: "panel",
                        ...n
                    })), c(o, { ...d,
                        lastAt: s
                    }), !0
                } catch {
                    return !1
                }
            }
        },
        89307: (e, t, n) => {
            n.d(t, {
                O: () => o
            });
            var a = n(1521),
                i = n(68279);

            function o(e) {
                let t = (0, a.useRef)(null),
                    n = (0, a.useRef)(e);
                return (0, a.useEffect)(() => {
                    try {
                        let e = n.current();
                        if (!e) return;
                        t.current ? (0, i.Mg)(t.current) : t.current = (0, i.p6)(e)
                    } catch {}
                    let e = t.current,
                        a = () => {
                            "hidden" === document.visibilityState && e ? .exit("hidden")
                        };
                    return document.addEventListener("visibilitychange", a), () => {
                        document.removeEventListener("visibilitychange", a), e ? .exit("unmount"), (0, i.N1)(e)
                    }
                }, []), t
            }
        }
    }
]);