(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [66107], {
        21905: (e, s, a) => {
            "use strict";
            a.d(s, {
                H_: () => l,
                Oh: () => c,
                Yw: () => p,
                iH: () => i,
                wS: () => u
            });
            let l = 324,
                c = 396,
                t = {
                    x: 92,
                    y: 360,
                    side: "right"
                },
                n = {
                    1: [{
                        x: 214,
                        y: 196,
                        side: "left"
                    }],
                    2: [{
                        x: 226,
                        y: 252,
                        side: "left"
                    }, {
                        x: 130,
                        y: 104,
                        side: "right"
                    }],
                    3: [{
                        x: 226,
                        y: 284,
                        side: "left"
                    }, {
                        x: 124,
                        y: 192,
                        side: "right"
                    }, {
                        x: 222,
                        y: 92,
                        side: "left"
                    }],
                    4: [{
                        x: 226,
                        y: 300,
                        side: "left"
                    }, {
                        x: 122,
                        y: 228,
                        side: "right"
                    }, {
                        x: 228,
                        y: 156,
                        side: "left"
                    }, {
                        x: 130,
                        y: 78,
                        side: "right"
                    }],
                    5: [{
                        x: 226,
                        y: 314,
                        side: "left"
                    }, {
                        x: 120,
                        y: 256,
                        side: "right"
                    }, {
                        x: 228,
                        y: 196,
                        side: "left"
                    }, {
                        x: 122,
                        y: 136,
                        side: "right"
                    }, {
                        x: 218,
                        y: 72,
                        side: "left"
                    }]
                };

            function i(e) {
                let s = Math.floor(Number.isFinite(e) ? e : 0);
                return s <= 0 ? [] : n[Math.min(5, s)]
            }
            let r = e => Math.round(10 * e) / 10,
                d = e => `M ${e.from.x} ${e.from.y} C ${e.c1.x} ${e.c1.y} ${e.c2.x} ${e.c2.y} ${e.to.x} ${e.to.y}`;

            function p(e) {
                let s = [t, ...i(e)].map(({
                    x: e,
                    y: s
                }) => ({
                    x: e,
                    y: s
                }));
                if (s.length < 2) return {
                    d: `M ${t.x} ${t.y}`,
                    legs: [],
                    stops: s,
                    distances: [0]
                };
                let a = function(e) {
                        let s = [];
                        for (let a = 0; a < e.length - 1; a += 1) {
                            let l = e[a - 1] ? ? e[a],
                                c = e[a],
                                t = e[a + 1],
                                n = e[a + 2] ? ? t;
                            s.push({
                                from: c,
                                c1: {
                                    x: r(c.x + (t.x - l.x) / 6),
                                    y: r(c.y + (t.y - l.y) / 6)
                                },
                                c2: {
                                    x: r(t.x - (n.x - c.x) / 6),
                                    y: r(t.y - (n.y - c.y) / 6)
                                },
                                to: t
                            })
                        }
                        return s
                    }(s),
                    l = a.map(e => (function(e, s = 48) {
                        let a = 0,
                            l = e.from;
                        for (let c = 1; c <= s; c += 1) {
                            let t = function(e, s) {
                                let a = 1 - s,
                                    l = a * a * a,
                                    c = 3 * a * a * s,
                                    t = 3 * a * s * s,
                                    n = s * s * s;
                                return {
                                    x: l * e.from.x + c * e.c1.x + t * e.c2.x + n * e.to.x,
                                    y: l * e.from.y + c * e.c1.y + t * e.c2.y + n * e.to.y
                                }
                            }(e, c / s);
                            a += Math.hypot(t.x - l.x, t.y - l.y), l = t
                        }
                        return a
                    })(e)),
                    c = l.reduce((e, s) => e + s, 0),
                    n = [0],
                    p = 0;
                for (let e of l) p += e, n.push(Math.round(p / c * 1e3) / 10);
                n[n.length - 1] = 100;
                let u = a[0];
                return {
                    d: [`M ${u.from.x} ${u.from.y}`, ...a.map(e => `C ${e.c1.x} ${e.c1.y} ${e.c2.x} ${e.c2.y} ${e.to.x} ${e.to.y}`)].join(" "),
                    legs: a.map(d),
                    stops: s,
                    distances: n
                }
            }

            function u(e, s, a) {
                let l = e.stops[s],
                    c = e.stops[a];
                return l && c && c.x < l.x ? "left" : "right"
            }
        },
        56332: (e, s, a) => {
            "use strict";
            a.r(s), a.d(s, {
                Burst: () => d,
                COIN_DROP_MS: () => x,
                CardPick: () => k,
                Coin3D: () => u,
                CoinSlot: () => m,
                HEART_LANES: () => f,
                HeartCatch: () => y,
                LockedPhoto: () => $,
                PRIZE_FLIP_MS: () => N,
                PhotoUnlock: () => g,
                SKIP_AFTER_MS: () => j,
                Trophy3D: () => h
            });
            var l = a(73365),
                c = a(1521),
                t = a(87191),
                n = a(34768),
                i = a(82161);

            function r() {
                let e = (0, c.useRef)([]);
                return (0, c.useEffect)(() => () => e.current.forEach(clearTimeout), []), {
                    later(s, a) {
                        e.current.push(setTimeout(a, s))
                    },
                    clear() {
                        e.current.forEach(clearTimeout), e.current = []
                    }
                }
            }

            function d({
                seed: e = 7,
                count: s = 30,
                top: a
            }) {
                return "edit" === (0, n.useMode)() ? null : (0, l.jsx)(t.ConfettiBurst, {
                    seed: e,
                    count: s,
                    top: a
                })
            }
            a(33381), a(99308);
            let p = [-4, -3, -2, -1, 0, 1, 2, 3, 4];

            function u({
                face: e,
                size: s = 150,
                className: a
            }) {
                return (0, l.jsx)("span", {
                    "aria-hidden": !0,
                    className: `cpcp-coin${a?` ${a}`:""}`,
                    style: {
                        "--size": `${s}px`
                    },
                    children: (0, l.jsxs)("span", {
                        className: "cpcp-coin-body",
                        children: [p.map(e => (0, l.jsx)("span", {
                            className: "cpcp-coin-edge",
                            style: {
                                "--i": e
                            }
                        }, e)), (0, l.jsx)("span", {
                            className: "cpcp-coin-face cpcp-coin-front",
                            children: e
                        }), (0, l.jsx)("span", {
                            className: "cpcp-coin-face cpcp-coin-back",
                            children: e
                        })]
                    })
                })
            }
            let o = [-3, -2, -1, 0, 1, 2, 3];

            function h({
                art: e,
                size: s = 170,
                className: a
            }) {
                return (0, l.jsxs)("span", {
                    "aria-hidden": !0,
                    className: `cpcp-trophy${a?` ${a}`:""}`,
                    style: {
                        "--size": `${s}px`
                    },
                    children: [(0, l.jsx)("span", {
                        className: "cpcp-trophy-shadow"
                    }), (0, l.jsx)("span", {
                        className: "cpcp-trophy-body",
                        children: o.map(s => (0, l.jsx)("span", {
                            className: "cpcp-trophy-layer",
                            style: {
                                "--i": s
                            },
                            ...3 === s ? {
                                "data-front": ""
                            } : {},
                            children: e
                        }, s))
                    })]
                })
            }
            let x = 700;

            function m({
                coin: e,
                insertLabel: s,
                joined: a,
                next: d,
                className: p
            }) {
                let o = "edit" === (0, n.useMode)(),
                    h = (0, i.useFolioSound)(),
                    f = r(),
                    j = (0, c.useRef)(null),
                    [y, N] = (0, c.useState)(!1),
                    [k, v] = (0, c.useState)(!1);
                (0, t.useReplaySignal)(j, () => {
                    f.clear(), N(!1), v(!1)
                });
                let g = () => {
                        o || y || (h.unlock(), h.playEffect("unlock"), N(!0), f.later(x, () => {
                            h.playEffect("boot"), v(!0)
                        }))
                    },
                    $ = o || k;
                return (0, l.jsxs)("div", {
                    ref: j,
                    className: `cpcp-slot-game${p?` ${p}`:""}`,
                    ...y ? {
                        "data-inserted": ""
                    } : {},
                    children: [(0, l.jsxs)("div", {
                        className: "cpcp-slot-stage",
                        children: [(0, l.jsx)("span", {
                            className: "cpcp-coin-hit",
                            onClick: g,
                            children: (0, l.jsx)(u, {
                                face: e,
                                size: 176
                            })
                        }), $ ? (0, l.jsx)("div", {
                            className: o ? "cpcp-slot-joined" : "cpcp-slot-joined cpi-pop-in",
                            children: a
                        }) : null]
                    }), (0, l.jsx)("span", {
                        "aria-hidden": !0,
                        className: "cpcp-slot",
                        children: (0, l.jsx)("span", {
                            className: "cpcp-slot-mouth"
                        })
                    }), !y || o ? (0, l.jsx)("button", {
                        type: "button",
                        className: "cpcp-slot-insert",
                        onClick: g,
                        tabIndex: o ? -1 : void 0,
                        children: s
                    }) : null, $ ? (0, l.jsx)("div", {
                        className: o ? "cpcp-slot-next" : "cpcp-slot-next cpi-rise-in",
                        children: d
                    }) : null]
                })
            }
            let f = [{
                    x: 4,
                    dur: 5.2,
                    delay: -.6,
                    sway: 8,
                    rest: 16
                }, {
                    x: 37,
                    dur: 6,
                    delay: -3.4,
                    sway: -10,
                    rest: 40
                }, {
                    x: 70,
                    dur: 5.6,
                    delay: -1.8,
                    sway: 9,
                    rest: 18
                }, {
                    x: 18,
                    dur: 6.4,
                    delay: -4.9,
                    sway: -7,
                    rest: 62
                }, {
                    x: 54,
                    dur: 5,
                    delay: -2.6,
                    sway: 10,
                    rest: 70
                }, {
                    x: 76,
                    dur: 6.2,
                    delay: -5.4,
                    sway: -9,
                    rest: 48
                }],
                j = 6e3;

            function y({
                heart: e,
                compliments: s,
                score: a,
                clear: r,
                next: p,
                skip: u,
                className: o
            }) {
                let h = "edit" === (0, n.useMode)(),
                    x = (0, i.useSoundEffect)(),
                    m = (0, n.useStory)(),
                    N = (0, n.useSectionIndex)(),
                    k = (0, c.useRef)(null),
                    [v, g] = (0, c.useState)(() => new Set),
                    [$, S] = (0, c.useState)(!1),
                    b = Math.max(1, Math.min(s.length, f.length)),
                    w = v.size >= b,
                    M = !m.active || m.index === N;
                (0, c.useEffect)(() => {
                    if (h || !M || w || $) return;
                    let e = setTimeout(() => S(!0), j);
                    return () => clearTimeout(e)
                }, [h, M, w, $]), (0, t.useReplaySignal)(k, () => {
                    g(new Set), S(!1)
                });
                let C = v.size > 0 ? s[Math.min(v.size, s.length) - 1] : null;
                return (0, l.jsxs)("div", {
                    ref: k,
                    className: `cpcp-catch${o?` ${o}`:""}`,
                    ...w ? {
                        "data-done": ""
                    } : {},
                    children: [(0, l.jsx)("div", {
                        className: "cpcp-cab",
                        children: (0, l.jsxs)("div", {
                            className: "cpcp-cab-screen",
                            children: [(0, l.jsxs)("span", {
                                className: "cpcp-cab-score",
                                "aria-live": "polite",
                                children: [a, (0, l.jsxs)("b", {
                                    children: [h ? 0 : v.size, "/", b]
                                })]
                            }), w && !h ? null : (0, l.jsx)("span", {
                                className: "cpcp-lanes",
                                children: f.map((s, a) => v.has(a) && !h ? null : (0, l.jsx)("span", {
                                    className: "cpcp-lane",
                                    style: {
                                        left: `${s.x}%`,
                                        "--dur": `${s.dur}s`,
                                        "--delay": `${s.delay}s`,
                                        "--sway": `${s.sway}deg`,
                                        "--rest": `${s.rest}%`
                                    },
                                    children: (0, l.jsx)("button", {
                                        type: "button",
                                        className: "cpcp-fall",
                                        onClick: () => (e => {
                                            if (h || w || v.has(e)) return;
                                            let s = new Set(v).add(e);
                                            g(s), x(s.size >= b ? "win" : "pop")
                                        })(a),
                                        tabIndex: h ? -1 : void 0,
                                        "aria-label": "Catch this heart",
                                        children: e
                                    })
                                }, a))
                            }), h ? null : C && !w ? (0, l.jsx)("span", {
                                className: "cpcp-cab-pop cpcp-cab-toast",
                                children: C
                            }, v.size) : null, h || w ? (0, l.jsxs)("span", {
                                className: h ? "cpcp-cab-clear" : "cpcp-cab-clear cpi-pop-in",
                                children: [w ? (0, l.jsx)(d, {
                                    seed: 21,
                                    count: 28,
                                    top: "40%"
                                }) : null, r]
                            }) : null]
                        })
                    }), h ? (0, l.jsx)("span", {
                        className: "cpcp-cab-pops",
                        children: s.map((e, s) => (0, l.jsx)("span", {
                            className: "cpcp-cab-pop",
                            children: e
                        }, s))
                    }) : null, (0, l.jsxs)("div", {
                        className: "cpcp-catch-after",
                        children: [h || w ? (0, l.jsx)("div", {
                            className: h ? "" : "cpi-rise-in",
                            children: p
                        }) : null, h || $ && !w ? (0, l.jsx)("div", {
                            className: h ? "" : "cpi-rise-in",
                            children: u
                        }) : null]
                    })]
                })
            }
            let N = 800;

            function k({
                back: e,
                prize: s,
                hint: a,
                next: p,
                className: u
            }) {
                let o = "edit" === (0, n.useMode)(),
                    h = (0, i.useSoundEffect)(),
                    x = r(),
                    m = (0, c.useRef)(null),
                    [f, j] = (0, c.useState)(null),
                    [y, v] = (0, c.useState)(!1);
                return (0, t.useReplaySignal)(m, () => {
                    x.clear(), j(null), v(!1)
                }), (0, l.jsxs)("div", {
                    ref: m,
                    className: `cpcp-pick${u?` ${u}`:""}`,
                    children: [o || null === f ? (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("div", {
                            className: "cpcp-pick-row",
                            children: [0, 1, 2].map(s => (0, l.jsx)("button", {
                                type: "button",
                                className: "cpcp-pick-card",
                                "data-slot": s,
                                onClick: () => {
                                    !o && null === f && (j(s), h("reveal"), x.later(N, () => {
                                        h("win"), v(!0)
                                    }))
                                },
                                tabIndex: o ? -1 : void 0,
                                children: (0, l.jsx)("span", {
                                    className: "cpcp-pick-card-inner",
                                    children: e
                                })
                            }, s))
                        }), (0, l.jsx)("p", {
                            className: "cpcp-pick-hint",
                            children: a
                        })]
                    }) : null, o || null !== f ? (0, l.jsxs)("div", {
                        className: "cpcp-prize",
                        ...o ? {
                            "data-still": ""
                        } : {},
                        children: [(0, l.jsxs)("span", {
                            className: "cpcp-prize-inner",
                            children: [(0, l.jsx)("span", {
                                "aria-hidden": !0,
                                className: "cpcp-prize-face cpcp-prize-back",
                                children: e
                            }), (0, l.jsx)("span", {
                                className: "cpcp-prize-face cpcp-prize-front",
                                children: s
                            })]
                        }), y ? (0, l.jsx)(d, {
                            seed: 12,
                            count: 26,
                            top: "20%"
                        }) : null]
                    }) : null, o || y ? (0, l.jsx)("div", {
                        className: o ? "cpcp-pick-next" : "cpcp-pick-next cpi-rise-in",
                        children: p
                    }) : null]
                })
            }
            let v = (0, c.createContext)(null);

            function g({
                count: e,
                door: s,
                hint: a,
                done: r,
                children: d,
                className: p
            }) {
                let u = "edit" === (0, n.useMode)(),
                    o = (0, i.useSoundEffect)(),
                    h = (0, c.useRef)(null),
                    [x, m] = (0, c.useState)(() => new Set);
                (0, t.useReplaySignal)(h, () => m(new Set));
                let f = x.size >= Math.max(1, e);
                return (0, l.jsx)(v.Provider, {
                    value: {
                        editing: u,
                        opened: x,
                        open: s => {
                            if (u || x.has(s)) return;
                            let a = new Set(x).add(s);
                            m(a), o(a.size >= e ? "win" : "unlock")
                        },
                        door: s
                    },
                    children: (0, l.jsxs)("div", {
                        ref: h,
                        className: `cpcp-unlock${p?` ${p}`:""}`,
                        children: [d, (0, l.jsx)("div", {
                            className: "cpcp-unlock-status",
                            "aria-live": "polite",
                            children: u ? (0, l.jsxs)(l.Fragment, {
                                children: [(0, l.jsx)("span", {
                                    className: "cpcp-unlock-door-sample",
                                    children: s
                                }), a, r]
                            }) : f ? (0, l.jsx)("div", {
                                className: "cpi-rise-in",
                                children: r
                            }, "done") : a
                        })]
                    })
                })
            }

            function $({
                index: e,
                children: s
            }) {
                let a = (0, c.useContext)(v),
                    t = !a || a.editing,
                    n = t || a.opened.has(e);
                return (0, l.jsxs)("div", {
                    className: "cpcp-case",
                    ...n ? {
                        "data-open": ""
                    } : {},
                    style: {
                        "--tilt": `${e%2?2.5:-2.5}deg`
                    },
                    children: [(0, l.jsx)("div", {
                        className: "cpcp-case-photo",
                        "aria-hidden": !n || void 0,
                        children: s
                    }), t ? null : (0, l.jsx)("button", {
                        type: "button",
                        className: "cpcp-case-door",
                        onClick: () => a ? .open(e),
                        disabled: n,
                        "aria-label": "Unlock this photo",
                        children: (0, l.jsx)("span", {
                            className: "cpcp-case-door-face",
                            children: a ? .door
                        })
                    })]
                })
            }
        },
        75342: () => {},
        99308: () => {},
        99334: (e, s, a) => {
            "use strict";
            let l, c;
            a.r(s), a.d(s, {
                DECK_SWING_MS: () => R,
                DHUNUCHI_MOVES: () => w,
                DeckCard: () => E,
                MapPin: () => N,
                PHUCHKA_CAT_TAP: () => v,
                PHUCHKA_FLIGHT_MS: () => $,
                PHUCHKA_GOAL: () => k,
                PROPOSAL_DODGES: () => P,
                PandalWalk: () => y,
                PhotoDeck: () => _,
                PhuchkaStall: () => b,
                ProposalAsk: () => z,
                SHIULI_RAIN: () => A,
                ShiuliRain: () => I,
                WALK_FRAME_MS: () => f,
                WALK_MS: () => m,
                dhunuchiBeat: () => M,
                phuchkaEaten: () => g,
                proposalAnswerKey: () => T
            });
            var t = a(73365),
                n = a(1521),
                i = a(87191),
                r = a(34768),
                d = a(82161),
                p = a(26244),
                u = a(2418),
                o = a(21905);

            function h() {
                return (0, r.useTemplate)() ? .lang === "bn" ? p.wb : String
            }

            function x() {
                let e = (0, n.useRef)([]);
                return (0, n.useEffect)(() => () => {
                    for (let s of e.current) clearTimeout(s)
                }, []), {
                    later(s, a) {
                        e.current.push(setTimeout(a, s))
                    },
                    clear() {
                        for (let s of e.current) clearTimeout(s);
                        e.current = []
                    }
                }
            }
            a(75342);
            let m = 900,
                f = 180,
                j = (0, n.createContext)(null);

            function y({
                route: e,
                layout: s,
                art: a,
                start: l,
                pins: c,
                frames: p,
                seenLabel: u,
                counterLabel: f,
                hint: N,
                done: k,
                className: v
            }) {
                let g = "edit" === (0, r.useMode)(),
                    $ = (0, i.usePrefersReducedMotion)(),
                    S = (0, d.useSoundEffect)(),
                    b = x(),
                    w = h(),
                    M = (0, n.useRef)(null),
                    [C, R] = (0, n.useState)(0),
                    [_, E] = (0, n.useState)(0),
                    [P, T] = (0, n.useState)(!1),
                    [z, A] = (0, n.useState)("right");
                (0, i.useReplaySignal)(M, () => {
                    b.clear(), R(0), E(0), T(!1), A("right")
                });
                let I = s.length,
                    H = g ? I : Math.min(C, I),
                    F = g ? I : Math.min(_, I),
                    L = e.stops[F] ? ? e.stops[0],
                    D = H >= I,
                    O = {
                        "--route": `path("${e.d}")`,
                        "--at": `${e.distances[F]??0}%`,
                        "--sx": `${L.x}px`,
                        "--sy": `${L.y}px`
                    };
                return (0, t.jsx)(j.Provider, {
                    value: {
                        editing: g,
                        visited: H,
                        walking: P,
                        layout: s,
                        seenLabel: u,
                        walkTo: s => {
                            if (g || P || s !== C || s >= I) return;
                            let a = s + 1;
                            A((0, o.wS)(e, C, a)), E(a), T(!0), S("tap"), b.later($ ? 80 : m, () => {
                                T(!1), R(a), S("dhaak"), a === I && b.later(320, () => S("ghonta"))
                            })
                        }
                    },
                    children: (0, t.jsxs)("div", {
                        ref: M,
                        className: `cdp-walk${v?` ${v}`:""}`,
                        "data-visited": H,
                        ...P ? {
                            "data-walking": ""
                        } : {},
                        ...D ? {
                            "data-done": ""
                        } : {},
                        children: [(0, t.jsx)("div", {
                            className: "cdp-map-frame",
                            children: (0, t.jsxs)("div", {
                                className: "cdp-map",
                                style: {
                                    width: o.H_,
                                    height: o.Oh
                                },
                                children: [a, (0, t.jsx)("svg", {
                                    viewBox: `0 0 ${o.H_} ${o.Oh}`,
                                    width: o.H_,
                                    height: o.Oh,
                                    "aria-hidden": !0,
                                    className: "cdp-route",
                                    children: e.legs.map((e, s) => (0, t.jsxs)("g", {
                                        children: [(0, t.jsx)("path", {
                                            d: e,
                                            className: "cdp-route-dash"
                                        }), (0, t.jsx)("path", {
                                            d: e,
                                            className: "cdp-route-walked",
                                            ...s < H || P && s === H ? {
                                                "data-walked": ""
                                            } : {}
                                        })]
                                    }, e))
                                }), (0, t.jsxs)("span", {
                                    className: "cdp-map-start",
                                    style: {
                                        left: e.stops[0].x,
                                        top: e.stops[0].y
                                    },
                                    children: [(0, t.jsx)("span", {
                                        "aria-hidden": !0,
                                        className: "cdp-map-start-dot"
                                    }), (0, t.jsx)("span", {
                                        className: "cdp-map-start-tag",
                                        children: l
                                    })]
                                }), c, (0, t.jsx)("span", {
                                    "aria-hidden": !0,
                                    className: "cdp-walker",
                                    "data-facing": z,
                                    style: O,
                                    children: (0, t.jsxs)("span", {
                                        className: "cdp-walker-body",
                                        children: [(0, t.jsx)("span", {
                                            className: "cdp-walker-frame cdp-walker-a",
                                            children: p[0]
                                        }), (0, t.jsx)("span", {
                                            className: "cdp-walker-frame cdp-walker-b",
                                            children: p[1]
                                        })]
                                    })
                                }), (0, t.jsxs)("p", {
                                    className: "cdp-walk-count",
                                    "aria-live": "polite",
                                    children: [(0, t.jsxs)("span", {
                                        className: "cdp-walk-number",
                                        children: [w(H), "/", w(I)]
                                    }), " ", f]
                                })]
                            })
                        }), (0, t.jsx)("div", {
                            className: "cdp-walk-after",
                            children: g ? (0, t.jsxs)(t.Fragment, {
                                children: [N, k]
                            }) : D ? (0, t.jsx)("div", {
                                className: "cpi-rise-in cdp-stack",
                                children: k
                            }) : N
                        })]
                    })
                })
            }

            function N({
                index: e,
                name: s
            }) {
                let a = (0, n.useContext)(j),
                    l = h(),
                    c = a ? .layout[e];
                if (!a || !c) return null;
                let i = a.editing || e < a.visited,
                    r = !a.editing && !a.walking && e === a.visited,
                    d = a.editing ? e === a.layout.length - 1 : e === a.visited - 1,
                    p = (0, t.jsxs)(t.Fragment, {
                        children: [(0, t.jsx)("span", {
                            "aria-hidden": !0,
                            className: "cdp-pin-dot"
                        }), (0, t.jsxs)("span", {
                            className: "cdp-pin-tag",
                            children: [(0, t.jsx)("span", {
                                "aria-hidden": !0,
                                className: "cdp-pin-number",
                                children: l(e + 1)
                            }), (0, t.jsx)("span", {
                                className: "cdp-pin-name",
                                children: s
                            }), i && a.seenLabel ? d ? (0, t.jsx)("span", {
                                className: "cdp-pin-seen",
                                children: a.seenLabel
                            }) : (0, t.jsx)("span", {
                                className: "cdp-sr-only",
                                children: a.seenLabel
                            }) : null]
                        })]
                    }),
                    u = {
                        className: "cdp-pin",
                        style: {
                            left: c.x,
                            top: c.y
                        },
                        "data-side": c.side,
                        ...i ? {
                            "data-seen": ""
                        } : {},
                        ...r ? {
                            "data-next": ""
                        } : {}
                    };
                return a.editing ? (0, t.jsx)("span", { ...u,
                    children: p
                }) : (0, t.jsx)("button", {
                    type: "button",
                    ...u,
                    "aria-disabled": !r,
                    onClick: () => a.walkTo(e),
                    children: p
                })
            }
            let k = 6,
                v = 3;

            function g(e) {
                let s = Math.min(Math.max(e, 0), k);
                return s - (s >= v)
            }
            let $ = 350,
                S = Array.from({
                    length: 14
                }, (e, s) => {
                    let a = s / 14 * Math.PI * 2 + .2,
                        l = 70 + s % 3 * 26;
                    return {
                        x: Math.round(Math.cos(a) * l),
                        y: Math.round(Math.sin(a) * l * .7 - 30),
                        spin: (s % 2 == 0 ? 1 : -1) * (160 + 17 * s),
                        delay: s % 4 * 40
                    }
                });

            function b({
                vendor: e,
                girlWait: s,
                girlEat: a,
                boy: l,
                cat: c,
                piece: p,
                meterLabel: u,
                feed: o,
                countLabel: m,
                catLine: f,
                fauLine: j,
                done: y,
                className: N,
                buttonClassName: w,
                label: M
            }) {
                let C = "edit" === (0, r.useMode)(),
                    R = (0, i.usePrefersReducedMotion)(),
                    _ = (0, d.useSoundEffect)(),
                    E = x(),
                    P = h(),
                    T = (0, n.useRef)(null),
                    [z, A] = (0, n.useState)(0),
                    [I, H] = (0, n.useState)(!1);
                (0, i.useReplaySignal)(T, () => {
                    E.clear(), A(0), H(!1)
                });
                let F = C ? k : z,
                    L = F >= k,
                    D = F >= v,
                    O = R ? 0 : $,
                    K = !C && z === v;
                return (0, t.jsxs)("div", {
                    ref: T,
                    className: `cdp-stall${N?` ${N}`:""}`,
                    "data-taps": F,
                    ...I || L ? {
                        "data-eating": ""
                    } : {},
                    ...D ? {
                        "data-cat": ""
                    } : {},
                    ...L ? {
                        "data-done": ""
                    } : {},
                    children: [(0, t.jsxs)("div", {
                        className: "cdp-stall-stage",
                        children: [l ? (0, t.jsx)("div", {
                            className: "cdp-stall-boy",
                            children: l
                        }) : null, (0, t.jsxs)("div", {
                            className: "cdp-stall-girl",
                            children: [(0, t.jsx)("span", {
                                className: "cdp-girl-wait",
                                children: s
                            }), (0, t.jsx)("span", {
                                className: "cdp-girl-eat",
                                children: a
                            })]
                        }), (0, t.jsx)("div", {
                            className: "cdp-stall-vendor",
                            children: e
                        }), (0, t.jsxs)("div", {
                            className: "cdp-stall-cat",
                            children: [D ? (0, t.jsx)("span", {
                                className: "cdp-stall-cat-line",
                                children: f
                            }) : null, c]
                        }), !C && z > 0 && z <= k ? (0, t.jsx)("span", {
                            "aria-hidden": !0,
                            className: "cdp-fly",
                            "data-to": K ? "cat" : "girl",
                            children: (0, t.jsx)("span", {
                                className: "cdp-fly-arc",
                                children: p
                            })
                        }, z) : null, !C && L ? (0, t.jsx)("span", {
                            "aria-hidden": !0,
                            className: "cdp-burst",
                            children: S.map((e, s) => (0, t.jsx)("span", {
                                className: "cdp-burst-bit",
                                style: {
                                    "--x": `${e.x}px`,
                                    "--y": `${e.y}px`,
                                    "--spin": `${e.spin}deg`,
                                    "--d": `${e.delay}ms`
                                },
                                children: p
                            }, s))
                        }) : null]
                    }), (0, t.jsxs)("div", {
                        className: "cdp-stall-meter",
                        role: "meter",
                        "aria-label": M,
                        "aria-valuemin": 0,
                        "aria-valuemax": k,
                        "aria-valuenow": F,
                        children: [(0, t.jsx)("span", {
                            className: "cdp-stall-meter-label",
                            children: u
                        }), (0, t.jsx)("ol", {
                            "aria-hidden": !0,
                            children: Array.from({
                                length: k
                            }, (e, s) => (0, t.jsx)("li", {
                                "data-taste": s < 2 ? "tok" : s < 4 ? "jhal" : "mishti",
                                ...s < F ? {
                                    "data-on": ""
                                } : {},
                                ...s === v - 1 && s < F ? {
                                    "data-cat": ""
                                } : {}
                            }, s))
                        })]
                    }), (0, t.jsxs)("p", {
                        className: "cdp-stall-count",
                        "aria-live": "polite",
                        children: [(0, t.jsx)("span", {
                            className: "cdp-stall-number",
                            children: P(g(F))
                        }), m]
                    }), C ? (0, t.jsx)("span", {
                        className: `cdp-stall-button${w?` ${w}`:""}`,
                        children: o
                    }) : L ? null : (0, t.jsx)("button", {
                        type: "button",
                        className: `cdp-stall-button${w?` ${w}`:""}`,
                        onClick: () => {
                            if (C || z >= k) return;
                            let e = z + 1;
                            (A(e), _("tap"), e === v) ? E.later(O, () => _("puff")): (E.later(O, () => {
                                _("crunch"), H(!0), E.later(900, () => H(!1))
                            }), e === k && E.later(O + 360, () => _("fanfare")))
                        },
                        children: o
                    }), (0, t.jsx)("div", {
                        className: "cdp-stall-after",
                        "aria-live": "polite",
                        children: C ? (0, t.jsxs)(t.Fragment, {
                            children: [j, y]
                        }) : L ? (0, t.jsxs)("div", {
                            className: "cpi-rise-in cdp-stack",
                            children: [j, y]
                        }) : null
                    })]
                })
            }
            let w = ["sway", "hop", "dip", "spin", "sway", "clap", "hop", "twirl"];

            function M() {
                return "dhaak"
            }
            let C = (0, n.createContext)(null),
                R = 220;

            function _({
                count: e,
                frame: s,
                cards: a,
                hint: l,
                done: c,
                className: p
            }) {
                let u = "edit" === (0, r.useMode)(),
                    o = (0, d.useSoundEffect)(),
                    m = x(),
                    f = h(),
                    j = (0, n.useRef)(null),
                    [y, N] = (0, n.useState)(0),
                    [k, v] = (0, n.useState)(-1),
                    [g, $] = (0, n.useState)(0);
                (0, i.useReplaySignal)(j, () => {
                    m.clear(), N(0), v(-1), $(0)
                });
                let S = Math.max(1, e),
                    b = u ? 0 : y % S;
                return (0, t.jsx)(C.Provider, {
                    value: {
                        editing: u,
                        current: b,
                        count: S,
                        leaving: k,
                        flip: () => {
                            u || S < 2 || (m.clear(), v(b), N((b + 1) % S), $(e => e + 1), o("rustle"), m.later(R, () => v(-1)))
                        }
                    },
                    children: (0, t.jsxs)("div", {
                        ref: j,
                        className: `cdp-deck${p?` ${p}`:""}`,
                        "data-count": S,
                        children: [(0, t.jsxs)("div", {
                            className: "cdp-deck-stage",
                            children: [s, (0, t.jsx)("div", {
                                className: "cdp-deck-cards",
                                children: a
                            })]
                        }), S > 1 ? (0, t.jsxs)("p", {
                            className: "cdp-deck-status",
                            children: [(0, t.jsxs)("span", {
                                className: "cdp-deck-number",
                                children: [f(b + 1), "/", f(S)]
                            }), l]
                        }) : null, c && (u || g >= S - 1) ? (0, t.jsx)("div", {
                            className: u ? "cdp-stack" : "cpi-rise-in cdp-stack",
                            children: c
                        }) : null]
                    })
                })
            }

            function E({
                index: e,
                children: s
            }) {
                let a = (0, n.useContext)(C);
                if (!a) return (0, t.jsx)("div", {
                    className: "cdp-deck-card",
                    children: s
                });
                let l = (e - a.current + a.count) % a.count,
                    c = !a.editing && a.count > 1 && 0 === l;
                return (0, t.jsx)("div", {
                    className: "cdp-deck-card",
                    "data-pos": a.editing ? e : l,
                    ...e === a.leaving ? {
                        "data-leaving": ""
                    } : {},
                    ...!a.editing && 0 !== l ? {
                        "aria-hidden": !0
                    } : {},
                    ...c ? {
                        role: "button",
                        tabIndex: 0,
                        "data-live": "",
                        onClick: a.flip,
                        onKeyDown: e => {
                            ("Enter" === e.key || " " === e.key) && (e.preventDefault(), a.flip())
                        }
                    } : {},
                    children: s
                })
            }
            let P = [
                [-142, 62],
                [32, 116],
                [-96, 150],
                [-160, 104],
                [6, 66]
            ];

            function T(e) {
                try {
                    let s = new URL(e);
                    return `cp_proposal_answer_v1:${s.origin}${s.pathname}`
                } catch {
                    return null
                }
            }

            function z({
                question: e,
                before: s,
                after: a,
                yes: l,
                no: c,
                giveIn: p,
                replies: o,
                answered: h,
                petal: m,
                yesClassName: f,
                noClassName: j,
                className: y
            }) {
                let N = (0, r.useMode)(),
                    k = "edit" === N,
                    v = (0, u.QE)(N, (0, u.mY)()),
                    g = (0, d.useSoundEffect)(),
                    $ = x(),
                    S = (0, n.useRef)(null),
                    [b, w] = (0, n.useState)(!1),
                    [M, C] = (0, n.useState)(!1),
                    [R, _] = (0, n.useState)(0),
                    E = (0, n.useRef)(!1);
                (0, n.useEffect)(() => {
                    if (!v || ! function() {
                            try {
                                let e = T(window.location.href);
                                return !!e && "yes" === window.localStorage.getItem(e)
                            } catch {
                                return !1
                            }
                        }()) return;
                    E.current = !0;
                    let e = setTimeout(() => {
                        w(!0), C(!0)
                    }, 0);
                    return () => clearTimeout(e)
                }, [v]), (0, i.useReplaySignal)(S, () => {
                    $.clear(), _(0), w(E.current), C(E.current)
                });
                let A = R >= Math.min(o.length, P.length),
                    H = () => {
                        if (!k && !b && (w(!0), C(!1), g("shankh"), $.later(560, () => g("dhaakRoll")), v)) {
                            E.current = !0;
                            try {
                                let e = T(window.location.href);
                                e && window.localStorage.setItem(e, "yes")
                            } catch {}
                        }
                    },
                    F = () => {
                        if (!k && !b) {
                            if (A) return void H();
                            _(e => e + 1), g("nope")
                        }
                    },
                    L = `cdp-ask${y?` ${y}`:""}`,
                    D = `cdp-ask-yes${f?` ${f}`:""}`,
                    O = `cdp-ask-no${j?` ${j}`:""}`;
                if (k) return (0, t.jsxs)("div", {
                    ref: S,
                    className: L,
                    children: [e, (0, t.jsx)("div", {
                        className: "cdp-ask-art",
                        children: s
                    }), (0, t.jsx)("div", {
                        className: "cdp-ask-replies",
                        children: o.map((e, s) => (0, t.jsx)("span", {
                            className: "cdp-ask-reply",
                            children: e
                        }, s))
                    }), (0, t.jsxs)("div", {
                        className: "cdp-ask-buttons",
                        children: [(0, t.jsx)("span", {
                            className: D,
                            children: l
                        }), (0, t.jsx)("span", {
                            className: O,
                            children: c
                        }), (0, t.jsx)("span", {
                            className: O,
                            children: p
                        })]
                    }), (0, t.jsxs)("div", {
                        className: "cdp-ask-answered",
                        children: [(0, t.jsx)("div", {
                            className: "cdp-ask-art cdp-ask-art-after",
                            children: a
                        }), h]
                    })]
                });
                let K = R > 0 && !A ? P[(R - 1) % P.length] : null;
                return (0, t.jsxs)("div", {
                    ref: S,
                    className: L,
                    ...b ? {
                        "data-said": ""
                    } : {},
                    ...M ? {
                        "data-restored": ""
                    } : {},
                    children: [b && !M ? (0, t.jsx)(I, {
                        petal: m
                    }) : null, e, b ? (0, t.jsxs)(t.Fragment, {
                        children: [(0, t.jsx)("div", {
                            className: `cdp-ask-art cdp-ask-art-after${M?"":" cpi-pop-in"}`,
                            children: a
                        }), (0, t.jsx)("div", {
                            className: `cdp-ask-answered${M?"":" cpi-rise-in"}`,
                            children: h
                        })]
                    }) : (0, t.jsxs)(t.Fragment, {
                        children: [(0, t.jsx)("div", {
                            className: "cdp-ask-art",
                            children: s
                        }), (0, t.jsx)("p", {
                            className: "cdp-ask-replies",
                            "aria-live": "polite",
                            children: R > 0 ? (0, t.jsx)("span", {
                                className: "cdp-ask-reply cpi-rise-in",
                                children: o[Math.min(R, o.length) - 1]
                            }, R) : null
                        }), (0, t.jsxs)("div", {
                            className: "cdp-ask-buttons",
                            children: [(0, t.jsx)("button", {
                                type: "button",
                                className: D,
                                onClick: H,
                                children: l
                            }), (0, t.jsx)("button", {
                                type: "button",
                                className: O,
                                style: K ? {
                                    translate: `${K[0]}px ${K[1]}px`
                                } : void 0,
                                onClick: F,
                                onPointerEnter: e => {
                                    "mouse" !== e.pointerType || A || F()
                                },
                                ...A ? {
                                    "data-gave-in": ""
                                } : {},
                                children: A ? p : c
                            })]
                        })]
                    })]
                })
            }
            let A = (l = 1910, c = () => (l = Math.imul(l, 1664525) + 0x3c6ef35f >>> 0) / 0x100000000, Array.from({
                length: 40
            }, (e, s) => ({
                left: Math.round((s + .8 * c()) / 40 * 1e3) / 10,
                size: 16 + Math.round(12 * c()),
                delay: Math.round(1400 * c()),
                duration: 2200 + Math.round(1600 * c()),
                dx: Math.round((c() - .5) * 120),
                spin: Math.round((c() - .5) * 720)
            })));

            function I({
                petal: e,
                count: s = 40
            }) {
                return (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className: "cdp-rain",
                    children: A.slice(0, s).map((s, a) => (0, t.jsx)("span", {
                        className: "cdp-rain-petal",
                        style: {
                            left: `${s.left}%`,
                            width: s.size,
                            "--d": `${s.delay}ms`,
                            "--t": `${s.duration}ms`,
                            "--dx": `${s.dx}px`,
                            "--spin": `${s.spin}deg`
                        },
                        children: e
                    }, a))
                })
            }
        }
    }
]);