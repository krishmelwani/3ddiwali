(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [40139], {
        40139: (e, s, r) => {
            "use strict";
            r.r(s), r.d(s, {
                BOOT_BEATS: () => d,
                BootScene: () => p,
                FloatingPhone: () => g,
                HOLD_STEP_MS: () => h,
                InstallRing: () => f,
                RESTART_MS: () => m,
                RestartAsk: () => j,
                RewindStack: () => x
            });
            var a = r(73365),
                t = r(1521),
                l = r(87191),
                n = r(34768),
                i = r(82161),
                c = r(57695);

            function u() {
                let e = (0, n.useStory)(),
                    s = (0, n.useSectionIndex)();
                return !e.active || e.index === s
            }
            r(48835);
            let o = e => e ? "" : void 0,
                d = [300, 1400, 2900, 4400, 5900];

            function p({
                lines: e,
                media: s,
                skip: r,
                children: h
            }) {
                let x = "edit" === (0, n.useMode)(),
                    f = (0, l.usePrefersReducedMotion)(),
                    m = u(),
                    j = (0, i.useSoundEffect)(),
                    N = (0, t.useRef)(null),
                    [v, g] = (0, t.useState)(0),
                    [k, b] = (0, t.useState)(0),
                    y = x || f ? 5 : v;
                (0, l.useReplaySignal)(N, () => {
                    g(0), b(e => e + 1)
                }), (0, t.useEffect)(() => {
                    if (x || f || !m) return;
                    let e = d.map((e, s) => setTimeout(() => g(e => Math.max(e, s + 1)), e));
                    return () => e.forEach(clearTimeout)
                }, [x, f, m, k]), (0, t.useEffect)(() => {
                    x || 0 === v || (2 === v && j("nope"), 4 === v && j("unlock"))
                }, [v, x, j]);
                let [w, M, C] = e;
                return (0, a.jsxs)("div", {
                    ref: N,
                    className: "prsu-boot",
                    "data-b1": o(y >= 1),
                    "data-b2": o(y >= 2),
                    "data-b3": o(y >= 3),
                    "data-b4": o(y >= 4),
                    "data-b5": o(y >= 5),
                    children: [(0, a.jsxs)("div", {
                        className: "prsu-boot-stage",
                        children: [(0, a.jsx)(c.n6, {
                            className: "prsu-boot-phone",
                            children: (0, a.jsxs)("div", {
                                className: "prsu-boot-screen",
                                children: [(0, a.jsx)("span", {
                                    className: "prsu-boot-logo",
                                    "aria-hidden": !0,
                                    children: (0, a.jsx)("span", {
                                        className: "prsu-boot-logo-ring"
                                    })
                                }), (0, a.jsx)("p", {
                                    className: "prsu-boot-line prsu-boot-wrong",
                                    children: x ? w : (0, a.jsxs)(a.Fragment, {
                                        children: [(0, a.jsx)("span", {
                                            className: "prsu-glitch prsu-glitch-a",
                                            "aria-hidden": !0,
                                            children: w
                                        }), (0, a.jsx)("span", {
                                            className: "prsu-glitch prsu-glitch-b",
                                            "aria-hidden": !0,
                                            children: w
                                        }), (0, a.jsx)("span", {
                                            className: "prsu-glitch-main",
                                            children: w
                                        })]
                                    })
                                }), (0, a.jsx)("p", {
                                    className: "prsu-boot-line prsu-boot-who",
                                    children: M
                                }), (0, a.jsxs)("p", {
                                    className: "prsu-boot-line prsu-boot-fix",
                                    children: [(0, a.jsx)("span", {
                                        className: "prsu-boot-check",
                                        children: (0, a.jsx)(c.Nf, {
                                            className: "block size-full"
                                        })
                                    }), (0, a.jsx)("span", {
                                        children: C
                                    })]
                                }), (0, a.jsx)("div", {
                                    className: "prsu-boot-media",
                                    children: s
                                })]
                            })
                        }), x ? (0, a.jsx)("span", {
                            className: "prsu-chip prsu-boot-skip",
                            children: r
                        }) : y < 5 ? (0, a.jsx)("button", {
                            type: "button",
                            className: "prsu-skip",
                            onClick: () => g(5),
                            children: (0, a.jsx)("span", {
                                className: "prsu-chip prsu-boot-skip",
                                children: r
                            })
                        }) : null]
                    }), (0, a.jsx)("div", {
                        className: "prsu-boot-card",
                        children: h
                    })]
                })
            }
            let h = 950;

            function x({
                now: e,
                cards: s,
                undo: r,
                after: u
            }) {
                let d = "edit" === (0, n.useMode)(),
                    p = (0, i.useSoundEffect)(),
                    f = (0, t.useRef)(null),
                    m = (0, t.useRef)(null),
                    j = (0, t.useRef)(0),
                    [N, v] = (0, t.useState)(0),
                    [g, k] = (0, t.useState)(!1),
                    b = [e, ...s],
                    y = s.length,
                    w = d || N >= y,
                    M = () => {
                        m.current && clearInterval(m.current), m.current = null, k(!1)
                    };
                (0, t.useEffect)(() => () => {
                    m.current && clearInterval(m.current)
                }, []), (0, l.useReplaySignal)(f, () => {
                    M(), j.current = 0, v(0)
                });
                let C = () => {
                    if (j.current >= y) return M();
                    j.current += 1, v(j.current), p(j.current >= y ? "reveal" : "switch"), j.current >= y && M()
                };
                return d ? (0, a.jsxs)("div", {
                    ref: f,
                    className: "prsu-rewind",
                    "data-edit": "",
                    children: [(0, a.jsx)("div", {
                        className: "prsu-rewind-flat",
                        children: b.map((e, s) => (0, a.jsx)("div", {
                            className: "prsu-mem prsu-mem-flat",
                            children: e
                        }, s))
                    }), (0, a.jsxs)("div", {
                        className: "prsu-after",
                        children: [(0, a.jsx)("span", {
                            className: "prsu-chip",
                            children: r
                        }), u]
                    })]
                }) : (0, a.jsxs)("div", {
                    ref: f,
                    className: "prsu-rewind",
                    ...w ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsx)("div", {
                        className: "prsu-stack-wrap",
                        children: (0, a.jsx)("div", {
                            className: "prsu-stack",
                            children: b.map((e, s) => {
                                let r = s - N;
                                return (0, a.jsx)("div", {
                                    className: "prsu-mem",
                                    "data-gone": o(r < 0),
                                    "aria-hidden": 0 !== r,
                                    style: {
                                        "--d": Math.max(r, 0),
                                        zIndex: b.length - s
                                    },
                                    children: e
                                }, s)
                            })
                        })
                    }), (0, a.jsx)("div", {
                        className: "prsu-undo-row",
                        children: w ? null : (0, a.jsxs)("button", {
                            type: "button",
                            className: "prsu-undo",
                            "data-holding": o(g),
                            onPointerDown: e => {
                                e.currentTarget.setPointerCapture ? .(e.pointerId), C(), k(!0), m.current && clearInterval(m.current), m.current = setInterval(C, h)
                            },
                            onPointerUp: M,
                            onPointerCancel: M,
                            onLostPointerCapture: M,
                            onClick: e => {
                                0 === e.detail && C()
                            },
                            children: [(0, a.jsx)("span", {
                                className: "prsu-undo-pulse",
                                "aria-hidden": !0
                            }), (0, a.jsxs)("span", {
                                className: "prsu-undo-face",
                                children: [(0, a.jsx)("span", {
                                    className: "prsu-undo-glyph",
                                    children: (0, a.jsx)(c.pn, {
                                        className: "block size-full"
                                    })
                                }, N), (0, a.jsx)("span", {
                                    className: "prsu-undo-label",
                                    children: r
                                })]
                            })]
                        })
                    }), (0, a.jsx)("div", {
                        className: "prsu-after",
                        children: w ? (0, a.jsx)("div", {
                            className: "prsu-rise",
                            children: u
                        }) : null
                    })]
                })
            }

            function f({
                statuses: e,
                hint: s,
                done: r
            }) {
                let o = "edit" === (0, n.useMode)(),
                    d = (0, l.usePrefersReducedMotion)(),
                    p = u(),
                    h = (0, i.useSoundEffect)(),
                    x = (0, t.useRef)(null),
                    [m, j] = (0, t.useState)(0),
                    [N, v] = (0, t.useState)(0),
                    g = o ? 100 : m,
                    k = g >= 100;
                (0, l.useReplaySignal)(x, () => {
                    j(0), v(0)
                }), (0, t.useEffect)(() => {
                    if (o || !p || m >= 100) return;
                    let e = setInterval(() => j(e => Math.min(100, e + 1)), 95);
                    return () => clearInterval(e)
                }, [o, p, m]);
                let b = (0, t.useRef)(!1);
                (0, t.useEffect)(() => {
                    !o && (m >= 100 && !b.current && (b.current = !0, h("win")), m < 100 && (b.current = !1))
                }, [m, o, h]);
                let y = Math.min(e.length - 1, Math.floor(g / 100 * e.length));
                return (0, a.jsxs)("div", {
                    ref: x,
                    className: "prsu-install",
                    ...k ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsxs)("button", {
                        type: "button",
                        className: "prsu-ring",
                        onClick: () => {
                            o || k || (j(e => Math.min(100, e + 9)), v(e => e + 1), h("tick"))
                        },
                        tabIndex: o ? -1 : void 0,
                        disabled: !o && k,
                        "aria-label": `${g}%`,
                        children: [(0, a.jsx)("span", {
                            className: "prsu-ring-glass",
                            "aria-hidden": !0
                        }), (0, a.jsx)(c.UQ, {
                            lit: (0, c.ye)(g),
                            className: "prsu-ring-ticks"
                        }), d || o || !(N > 0) ? null : (0, a.jsx)("span", {
                            className: "prsu-ring-burst",
                            "aria-hidden": !0,
                            children: (0, a.jsx)(c.Nu, {
                                className: "block size-full"
                            })
                        }, N), (0, a.jsxs)("span", {
                            className: "prsu-ring-center",
                            children: [(0, a.jsxs)("span", {
                                className: "prsu-ring-num",
                                "aria-hidden": !0,
                                children: [g, (0, a.jsx)("small", {
                                    children: "%"
                                })]
                            }), k ? (0, a.jsx)("span", {
                                className: "prsu-ring-check",
                                "aria-hidden": !0,
                                children: (0, a.jsx)(c.Nf, {
                                    className: "block size-full"
                                })
                            }) : null]
                        })]
                    }), o ? (0, a.jsx)("ol", {
                        className: "prsu-status-list",
                        children: e.map((e, s) => (0, a.jsx)("li", {
                            children: e
                        }, s))
                    }) : (0, a.jsx)("p", {
                        className: "prsu-status-line",
                        "aria-live": "polite",
                        children: k ? null : (0, a.jsxs)("span", {
                            className: "prsu-pop",
                            children: [e[y], " ", (0, a.jsxs)("b", {
                                children: [g, "%"]
                            })]
                        }, y)
                    }), (0, a.jsxs)("div", {
                        className: "prsu-after",
                        children: [o ? (0, a.jsx)("span", {
                            className: "prsu-chip",
                            children: s
                        }) : null, o || k ? null : (0, a.jsx)("span", {
                            className: "prsu-chip prsu-chip-soft",
                            children: s
                        }), k ? (0, a.jsx)("div", {
                            className: o ? "" : "prsu-rise",
                            children: r
                        }) : null]
                    })]
                })
            }
            let m = 1300;

            function j({
                yes: e,
                later: s,
                nags: r,
                reminder: c,
                answered: u
            }) {
                let d, p = "edit" === (0, n.useMode)(),
                    h = (0, l.usePrefersReducedMotion)(),
                    x = (0, i.useSoundEffect)(),
                    f = (d = (0, t.useRef)([]), (0, t.useEffect)(() => {
                        let e = d.current;
                        return () => e.forEach(clearTimeout)
                    }, []), (e, s) => {
                        d.current.push(setTimeout(e, s))
                    }),
                    N = (0, t.useRef)(null),
                    v = (0, t.useRef)(!1),
                    [g, k] = (0, t.useState)("ask"),
                    [b, y] = (0, t.useState)(0);
                (0, l.useReplaySignal)(N, () => {
                    v.current = !1, k("ask"), y(0)
                });
                let w = () => {
                        p || v.current || (v.current = !0, k("restarting"), x("boot"), f(() => {
                            k("done"), x("popper")
                        }, h ? 0 : m))
                    },
                    M = b > r.length;
                if (p) return (0, a.jsxs)("div", {
                    ref: N,
                    className: "prsu-restart",
                    "data-phase": "done",
                    children: [(0, a.jsxs)("div", {
                        className: "prsu-nags",
                        children: [r.map((e, s) => (0, a.jsx)("span", {
                            className: "prsu-nag",
                            children: e
                        }, s)), (0, a.jsx)("span", {
                            className: "prsu-nag",
                            children: c
                        })]
                    }), (0, a.jsxs)("div", {
                        className: "prsu-restart-buttons",
                        children: [(0, a.jsx)("span", {
                            className: "prsu-btn",
                            children: e
                        }), (0, a.jsx)("span", {
                            className: "prsu-btn prsu-btn-ghost",
                            children: s
                        })]
                    }), (0, a.jsx)("div", {
                        children: u
                    })]
                });
                let C = Math.min(b, r.length + 1);
                return (0, a.jsxs)("div", {
                    ref: N,
                    className: "prsu-restart",
                    "data-phase": g,
                    children: ["ask" === g ? (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("p", {
                            className: "prsu-nags",
                            "aria-live": "polite",
                            children: b > 0 ? (0, a.jsx)("span", {
                                className: "prsu-nag prsu-pop",
                                children: M ? c : r[b - 1]
                            }, b) : null
                        }), (0, a.jsxs)("div", {
                            className: "prsu-restart-buttons",
                            children: [(0, a.jsx)("button", {
                                type: "button",
                                className: "prsu-btn prsu-btn-yes",
                                onClick: w,
                                style: {
                                    "--grow": C
                                },
                                children: e
                            }), (0, a.jsx)("button", {
                                type: "button",
                                className: "prsu-btn prsu-btn-ghost prsu-later",
                                "data-gone": o(M),
                                style: {
                                    "--n": C
                                },
                                onClick: () => {
                                    if (p || "ask" !== g || M) return;
                                    let e = b + 1;
                                    y(e), x("nope"), e > r.length && f(w, 1e3)
                                },
                                tabIndex: M ? -1 : void 0,
                                children: s
                            })]
                        })]
                    }) : null, "restarting" === g ? (0, a.jsxs)("div", {
                        className: "prsu-power",
                        "aria-hidden": !0,
                        children: [(0, a.jsx)("span", {
                            className: "prsu-power-ring"
                        }), (0, a.jsx)("span", {
                            className: "prsu-power-dot"
                        })]
                    }) : null, "done" === g ? (0, a.jsx)("div", {
                        className: "prsu-rise",
                        children: u
                    }) : null]
                })
            }
            let N = [
                    [-30, 10, 90, 46, 0],
                    [94, 2, -70, 34, 1.1],
                    [104, 42, 120, 50, .5],
                    [-26, 52, -90, 30, 1.7],
                    [-16, 82, 60, 38, .9],
                    [92, 80, -40, 28, 2.2]
                ],
                v = [
                    [6, 0, 9, 24, !0],
                    [18, 2.6, 11, -18, !1],
                    [28, 5.1, 8.5, 30, !0],
                    [38, 1.2, 10, -26, !0],
                    [47, 6.4, 9.5, 18, !1],
                    [55, 3.4, 12, -22, !0],
                    [63, .6, 8, 26, !1],
                    [71, 4.4, 10.5, -30, !0],
                    [80, 7.2, 9, 20, !0],
                    [89, 2, 11.5, -16, !1],
                    [95, 5.8, 8.8, -24, !0],
                    [12, 8.1, 10, 16, !1],
                    [42, 9, 9.2, -20, !0],
                    [84, 9.6, 10.8, 22, !1]
                ];

            function g({
                screen: e,
                wallpaper: s
            }) {
                let r = "edit" === (0, n.useMode)(),
                    i = (0, l.usePrefersReducedMotion)(),
                    d = u(),
                    p = (0, t.useRef)(null),
                    h = (0, t.useRef)(null),
                    x = !r && !i && d;
                return (0, t.useEffect)(() => {
                    let e = p.current,
                        s = h.current,
                        r = e ? .ownerDocument.defaultView;
                    if (!x || !e || !s || !r) return;
                    let a = 0,
                        t = 0,
                        l = 0,
                        n = () => {
                            a = 0, s.style.transform = `rotateX(${t.toFixed(2)}deg) rotateY(${l.toFixed(2)}deg)`
                        },
                        i = () => {
                            a || (a = r.requestAnimationFrame(n))
                        },
                        c = s => {
                            let r = e.getBoundingClientRect();
                            if (!r.width || !r.height) return;
                            let a = (s.clientX - r.left) / r.width - .5,
                                n = (s.clientY - r.top) / r.height - .5;
                            l = 16 * Math.max(-1, Math.min(1, 2 * a)), t = -12 * Math.max(-1, Math.min(1, 2 * n)), i()
                        },
                        u = () => {
                            t = 0, l = 0, i()
                        },
                        o = e => {
                            null != e.gamma && null != e.beta && (l = Math.max(-18, Math.min(18, .5 * e.gamma)), t = Math.max(-12, Math.min(12, -((e.beta - 50) * .3))), i())
                        };
                    return e.addEventListener("pointermove", c), e.addEventListener("pointerleave", u), r.addEventListener("deviceorientation", o), () => {
                        e.removeEventListener("pointermove", c), e.removeEventListener("pointerleave", u), r.removeEventListener("deviceorientation", o), a && r.cancelAnimationFrame(a), s.style.transform = ""
                    }
                }, [x]), (0, a.jsxs)("div", {
                    ref: p,
                    className: "prsu-float-stage",
                    "data-live": o(x),
                    children: [x ? (0, a.jsx)("span", {
                        className: "prsu-fallers",
                        "aria-hidden": !0,
                        children: v.map(([e, s, r, t, l], n) => (0, a.jsx)("span", {
                            className: l ? "prsu-faller prsu-faller-petal" : "prsu-faller prsu-faller-spark",
                            style: {
                                left: `${e}%`,
                                animationDelay: `${s}s`,
                                animationDuration: `${r}s`,
                                "--drift": `${t}px`
                            },
                            children: (0, a.jsx)("span", {
                                className: "prsu-faller-inner",
                                children: l ? (0, a.jsx)(c.L6, {
                                    className: "block size-full"
                                }) : (0, a.jsx)(c.Nu, {
                                    className: "block size-full"
                                })
                            })
                        }, n))
                    }) : null, (0, a.jsx)("div", {
                        className: "prsu-float-sway",
                        children: (0, a.jsxs)("div", {
                            ref: h,
                            className: "prsu-float-tilt",
                            children: [N.map(([e, s, r, t, l], n) => (0, a.jsx)("span", {
                                className: "prsu-orbit-heart",
                                "aria-hidden": !0,
                                style: {
                                    left: `${e}%`,
                                    top: `${s}%`,
                                    width: `${t}px`,
                                    "--z": `${r}px`,
                                    "--delay": `${l}s`
                                },
                                children: (0, a.jsx)("span", {
                                    className: "prsu-orbit-bob",
                                    children: (0, a.jsx)(c.Ju, {
                                        className: "block size-full"
                                    })
                                })
                            }, n)), (0, a.jsx)(c.n6, {
                                className: "prsu-final-phone",
                                wallpaper: s,
                                children: e
                            })]
                        })
                    }), (0, a.jsx)("span", {
                        className: "prsu-float-shadow",
                        "aria-hidden": !0
                    })]
                })
            }
        },
        48835: () => {},
        57695: (e, s, r) => {
            "use strict";
            r.d(s, {
                AO: () => k,
                Cs: () => x,
                Ju: () => i,
                L6: () => h,
                Nf: () => o,
                Ns: () => c,
                Nu: () => p,
                UQ: () => m,
                XC: () => u,
                dz: () => n,
                n6: () => l,
                oK: () => b,
                pn: () => d,
                ye: () => j
            });
            var a = r(73365);

            function t() {
                return (0, a.jsxs)("div", {
                    className: "prsu-status",
                    "aria-hidden": !0,
                    children: [(0, a.jsxs)("svg", {
                        viewBox: "0 0 40 12",
                        className: "prsu-status-dots",
                        children: [(0, a.jsx)("circle", {
                            cx: "4",
                            cy: "6",
                            r: "2.6",
                            fill: "currentColor"
                        }), (0, a.jsx)("circle", {
                            cx: "12",
                            cy: "6",
                            r: "2.6",
                            fill: "currentColor",
                            opacity: "0.5"
                        })]
                    }), (0, a.jsxs)("svg", {
                        viewBox: "0 0 46 12",
                        className: "prsu-status-right",
                        children: [(0, a.jsx)("rect", {
                            x: "0",
                            y: "8",
                            width: "3",
                            height: "4",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, a.jsx)("rect", {
                            x: "5",
                            y: "5.5",
                            width: "3",
                            height: "6.5",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, a.jsx)("rect", {
                            x: "10",
                            y: "3",
                            width: "3",
                            height: "9",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, a.jsx)("rect", {
                            x: "15",
                            y: "0.5",
                            width: "3",
                            height: "11.5",
                            rx: "1",
                            fill: "currentColor",
                            opacity: "0.45"
                        }), (0, a.jsx)("rect", {
                            x: "24",
                            y: "1",
                            width: "18",
                            height: "10",
                            rx: "3",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "1.4"
                        }), (0, a.jsx)("rect", {
                            x: "26",
                            y: "3",
                            width: "10",
                            height: "6",
                            rx: "1.6",
                            fill: "currentColor"
                        }), (0, a.jsx)("rect", {
                            x: "43",
                            y: "4",
                            width: "2",
                            height: "4",
                            rx: "1",
                            fill: "currentColor"
                        })]
                    })]
                })
            }

            function l({
                children: e,
                wallpaper: s,
                className: r = ""
            }) {
                return (0, a.jsxs)("div", {
                    className: `prsu-phone ${r}`,
                    children: [(0, a.jsxs)("div", {
                        className: "prsu-phone-screen",
                        children: [(0, a.jsx)("div", {
                            className: "prsu-phone-wall",
                            "aria-hidden": !0,
                            children: s ? ? (0, a.jsx)("span", {
                                className: "prsu-wall-aurora"
                            })
                        }), (0, a.jsx)(t, {}), (0, a.jsx)("div", {
                            className: "prsu-phone-body",
                            children: e
                        })]
                    }), (0, a.jsx)("span", {
                        className: "prsu-phone-gloss",
                        "aria-hidden": !0
                    })]
                })
            }
            let n = "M12 21C5.4 16.4 1.5 12.6 1.5 7.6 1.5 4.3 4 1.8 7.1 1.8c2 0 3.8 1 4.9 2.7 1.1-1.7 2.9-2.7 4.9-2.7 3.1 0 5.6 2.5 5.6 5.8 0 5-3.9 8.8-10.5 13.4z";

            function i({
                className: e = ""
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 24 22",
                    "aria-hidden": !0,
                    className: `prsu-glass-heart ${e}`,
                    children: [(0, a.jsx)("path", {
                        d: n,
                        fill: "var(--prsu-heart-fill)",
                        stroke: "var(--prsu-heart-rim)",
                        strokeWidth: "0.9"
                    }), (0, a.jsx)("path", {
                        d: "M5 6.4c.4-1.6 1.6-2.6 3-2.7",
                        fill: "none",
                        stroke: "#ffffff",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        opacity: "0.85"
                    }), (0, a.jsx)("circle", {
                        cx: "17.2",
                        cy: "6.2",
                        r: "1",
                        fill: "#ffffff",
                        opacity: "0.6"
                    })]
                })
            }

            function c({
                className: e = ""
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 32 32",
                    "aria-hidden": !0,
                    className: e,
                    children: [(0, a.jsx)("path", {
                        d: "M16 3.5 30 28H2z",
                        fill: "var(--f-accent)",
                        stroke: "var(--f-accent)",
                        strokeWidth: "3",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("path", {
                        d: "M16 12v7.5",
                        stroke: "var(--f-onAccent)",
                        strokeWidth: "3",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("circle", {
                        cx: "16",
                        cy: "23.6",
                        r: "1.9",
                        fill: "var(--f-onAccent)"
                    })]
                })
            }

            function u({
                className: e = ""
            }) {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 16 16",
                    "aria-hidden": !0,
                    className: e,
                    children: (0, a.jsx)("path", {
                        d: "M4.5 4.5l7 7M11.5 4.5l-7 7",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "2.2",
                        strokeLinecap: "round"
                    })
                })
            }

            function o({
                className: e = ""
            }) {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 24 24",
                    "aria-hidden": !0,
                    className: e,
                    children: (0, a.jsx)("path", {
                        pathLength: 1,
                        className: "prsu-draw",
                        d: "M5 12.5l4.5 4.5L19 7.5",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "2.8",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                })
            }

            function d({
                className: e = ""
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 48 48",
                    "aria-hidden": !0,
                    className: e,
                    children: [(0, a.jsx)("path", {
                        d: "M14 18h17a9 9 0 0 1 0 18H18",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "4.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("path", {
                        d: "M20 10l-8 8 8 8",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "4.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })]
                })
            }

            function p({
                className: e = ""
            }) {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 20 20",
                    "aria-hidden": !0,
                    className: e,
                    children: (0, a.jsx)("path", {
                        d: "M10 0c.9 5.2 4.8 9.1 10 10-5.2.9-9.1 4.8-10 10-.9-5.2-4.8-9.1-10-10C5.2 9.1 9.1 5.2 10 0z",
                        fill: "currentColor"
                    })
                })
            }

            function h({
                className: e = ""
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 16 22",
                    "aria-hidden": !0,
                    className: e,
                    children: [(0, a.jsx)("path", {
                        d: "M8 1C13 6 14.5 12 8 21 1.5 12 3 6 8 1z",
                        fill: "currentColor"
                    }), (0, a.jsx)("path", {
                        d: "M8 5v11",
                        stroke: "#ffffff",
                        strokeWidth: "1",
                        strokeLinecap: "round",
                        opacity: "0.45"
                    })]
                })
            }

            function x({
                className: e = ""
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 52",
                    "aria-hidden": !0,
                    className: e,
                    children: [(0, a.jsx)("rect", {
                        x: "3",
                        y: "3",
                        width: "104",
                        height: "46",
                        rx: "13",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "3.5",
                        opacity: "0.9"
                    }), (0, a.jsx)("rect", {
                        x: "110",
                        y: "17",
                        width: "7",
                        height: "18",
                        rx: "3.5",
                        fill: "currentColor",
                        opacity: "0.9"
                    }), (0, a.jsx)("rect", {
                        className: "prsu-batt-fill",
                        x: "10",
                        y: "10",
                        width: "90",
                        height: "32",
                        rx: "8",
                        fill: "var(--prsu-mint)"
                    }), (0, a.jsx)("path", {
                        transform: "translate(43 13) scale(1.1)",
                        d: n,
                        fill: "var(--f-accent)",
                        stroke: "var(--f-bg)",
                        strokeWidth: "1.6",
                        strokeLinejoin: "round"
                    })]
                })
            }
            let f = Array.from({
                length: 48
            }, (e, s) => {
                let r = s / 48 * Math.PI * 2 - Math.PI / 2,
                    a = Math.cos(r),
                    t = Math.sin(r);
                return {
                    x1: (100 + 78 * a).toFixed(2),
                    y1: (100 + 78 * t).toFixed(2),
                    x2: (100 + 94 * a).toFixed(2),
                    y2: (100 + 94 * t).toFixed(2)
                }
            });

            function m({
                lit: e,
                className: s = ""
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 200 200",
                    "aria-hidden": !0,
                    className: `prsu-ticks ${s}`,
                    children: [(0, a.jsx)("g", {
                        className: "prsu-tick-base",
                        children: f.map((e, s) => (0, a.jsx)("line", { ...e,
                            strokeLinecap: "round"
                        }, s))
                    }), (0, a.jsx)("g", {
                        className: "prsu-tick-lit",
                        children: f.map((s, r) => (0, a.jsx)("line", { ...s,
                            className: "prsu-tick",
                            "data-on": r < e ? "" : void 0,
                            strokeLinecap: "round"
                        }, r))
                    })]
                })
            }

            function j(e) {
                return Math.round(Math.max(0, Math.min(100, e)) / 100 * 48)
            }
            let N = [
                    [22, 40, 1.1, -14],
                    [120, 26, .8, 12],
                    [168, 92, 1.3, -8],
                    [64, 118, .7, 18],
                    [26, 196, 1.2, 10],
                    [138, 176, .9, -16],
                    [92, 250, 1.4, 6],
                    [170, 286, .8, 20],
                    [34, 312, .9, -10],
                    [118, 352, 1.1, 14],
                    [60, 380, .7, -6]
                ],
                v = [
                    [28, 34, 1.1],
                    [150, 52, .7],
                    [96, 104, .9],
                    [178, 148, 1.2],
                    [40, 172, .6],
                    [120, 222, 1],
                    [24, 268, .9],
                    [164, 300, .7],
                    [80, 336, 1.2],
                    [150, 384, .8]
                ],
                g = [
                    [62, 22],
                    [182, 18],
                    [12, 96],
                    [134, 88],
                    [70, 150],
                    [190, 214],
                    [54, 232],
                    [146, 254],
                    [98, 292],
                    [12, 360],
                    [186, 350],
                    [110, 396]
                ];

            function k({
                kind: e
            }) {
                return "Aurora" === e ? (0, a.jsx)("span", {
                    className: "prsu-wall-aurora"
                }) : (0, a.jsx)("span", {
                    className: "prsu-wall-tint",
                    children: (0, a.jsxs)("svg", {
                        viewBox: "0 0 200 400",
                        preserveAspectRatio: "xMidYMid slice",
                        className: "block size-full",
                        children: ["Hearts" === e ? N.map(([e, s, r, t], l) => (0, a.jsx)("path", {
                            d: n,
                            transform: `translate(${e} ${s}) rotate(${t}) scale(${r})`,
                            fill: l % 3 == 0 ? "var(--prsu-mint)" : "var(--f-accent)",
                            opacity: l % 2 ? .55 : .8
                        }, l)) : null, "Stars" === e ? v.map(([e, s, r], t) => (0, a.jsx)("path", {
                            transform: `translate(${e} ${s}) scale(${r})`,
                            d: "M10 0c.9 5.2 4.8 9.1 10 10-5.2.9-9.1 4.8-10 10-.9-5.2-4.8-9.1-10-10C5.2 9.1 9.1 5.2 10 0z",
                            fill: t % 3 == 1 ? "var(--prsu-lime)" : "var(--f-fg)",
                            opacity: t % 2 ? .6 : .9
                        }, t)) : null, "Stars" === e ? g.map(([e, s], r) => (0, a.jsx)("circle", {
                            cx: e,
                            cy: s,
                            r: "1.6",
                            fill: "var(--f-fg)",
                            opacity: "0.5"
                        }, r)) : null]
                    })
                })
            }

            function b({
                kind: e
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 64 64",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "64",
                        height: "64",
                        rx: "16",
                        fill: "Spark" === e ? "var(--prsu-glow)" : "Smile" === e ? "var(--prsu-mint)" : "var(--f-accent)"
                    }), (0, a.jsx)("ellipse", {
                        cx: "32",
                        cy: "10",
                        rx: "24",
                        ry: "9",
                        fill: "#ffffff",
                        opacity: "0.18"
                    }), "Heart" === e ? (0, a.jsx)("path", {
                        transform: "translate(14 16) scale(1.5)",
                        d: n,
                        fill: "#ffffff"
                    }) : null, "Spark" === e ? (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("path", {
                            transform: "translate(14 14) scale(1.8)",
                            d: "M10 0c.9 5.2 4.8 9.1 10 10-5.2.9-9.1 4.8-10 10-.9-5.2-4.8-9.1-10-10C5.2 9.1 9.1 5.2 10 0z",
                            fill: "var(--prsu-lime)"
                        }), (0, a.jsx)("circle", {
                            cx: "48",
                            cy: "16",
                            r: "3",
                            fill: "#ffffff"
                        })]
                    }) : null, "Smile" === e ? (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("circle", {
                            cx: "23",
                            cy: "27",
                            r: "4",
                            fill: "var(--f-bg)"
                        }), (0, a.jsx)("circle", {
                            cx: "41",
                            cy: "27",
                            r: "4",
                            fill: "var(--f-bg)"
                        }), (0, a.jsx)("path", {
                            d: "M20 38c6 8 18 8 24 0",
                            fill: "none",
                            stroke: "var(--f-bg)",
                            strokeWidth: "4.5",
                            strokeLinecap: "round"
                        }), (0, a.jsx)("ellipse", {
                            cx: "17",
                            cy: "37",
                            rx: "4",
                            ry: "2.6",
                            fill: "var(--f-accent)",
                            opacity: "0.7"
                        }), (0, a.jsx)("ellipse", {
                            cx: "47",
                            cy: "37",
                            rx: "4",
                            ry: "2.6",
                            fill: "var(--f-accent)",
                            opacity: "0.7"
                        })]
                    }) : null]
                })
            }
        }
    }
]);