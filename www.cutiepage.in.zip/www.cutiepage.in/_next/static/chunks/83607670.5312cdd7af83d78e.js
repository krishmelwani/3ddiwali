"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [62460], {
        84910: (t, e, i) => {
            let s, r, n, a, h, o;
            i.d(e, {
                $EB: () => x,
                $Kf: () => rP,
                $Yl: () => W,
                $_I: () => t_,
                $ei: () => k,
                $p8: () => a8,
                A$4: () => sB,
                B69: () => iY,
                B6O: () => nC,
                BH$: () => ne,
                BKk: () => ay,
                BVL: () => t4,
                BXX: () => tQ,
                B_h: () => et,
                CSG: () => aM,
                CVz: () => t2,
                CWW: () => ev,
                Cfg: () => tb,
                CmU: () => a9,
                D$Q: () => af,
                DXC: () => nt,
                Df: () => ax,
                Dmk: () => tV,
                EAD: () => rF,
                EZo: () => b,
                EdD: () => S,
                F1T: () => a7,
                FFZ: () => eP,
                FV: () => ta,
                FXf: () => A,
                Fn: () => ed,
                GJx: () => tf,
                GOR: () => nl,
                GWd: () => tj,
                GYF: () => rR,
                G_z: () => av,
                Gc6: () => nc,
                Gu$: () => ah,
                Gwm: () => G,
                H23: () => em,
                HIg: () => tL,
                HO_: () => ex,
                HXV: () => t0,
                HiM: () => a3,
                Ho_: () => nf,
                I46: () => rN,
                I9Y: () => e6,
                IE4: () => tZ,
                IUQ: () => ig,
                Iit: () => ac,
                Jnc: () => p,
                K52: () => Q,
                KDk: () => t5,
                KLL: () => eA,
                KRh: () => tt,
                Kef: () => ef,
                Kwu: () => w,
                LAk: () => to,
                LiQ: () => N,
                LlO: () => am,
                LoY: () => sJ,
                M4G: () => he,
                MSw: () => aa,
                MW4: () => sO,
                Mjd: () => tr,
                N1A: () => r6,
                NTi: () => M,
                Nex: () => hf,
                Nt7: () => E,
                Nz6: () => tY,
                O3Y: () => ao,
                O9p: () => iI,
                ONl: () => na,
                OUM: () => tz,
                Om: () => ty,
                OtU: () => t8,
                OuU: () => R,
                PPD: () => rQ,
                PTz: () => e8,
                Pq0: () => e9,
                Q1f: () => i3,
                QCA: () => n7,
                QP0: () => d,
                Qev: () => eZ,
                Qrf: () => es,
                R3r: () => i$,
                R8M: () => eU,
                RQf: () => tO,
                Riy: () => t3,
                Rm2: () => eD,
                RoJ: () => s0,
                RrE: () => D,
                RyA: () => y,
                S$4: () => ep,
                THS: () => sk,
                TdN: () => eE,
                TiK: () => eB,
                TkQ: () => tH,
                U3G: () => Y,
                Ufg: () => as,
                V3x: () => tR,
                V9B: () => ru,
                VCu: () => nu,
                VT0: () => tU,
                Vb5: () => c,
                Vnu: () => eR,
                VxR: () => ez,
                W9U: () => ey,
                WBB: () => ae,
                WNZ: () => u,
                Wdf: () => eV,
                Wew: () => tN,
                Wk7: () => m,
                XG_: () => eg,
                XIg: () => v,
                XrR: () => te,
                YJl: () => iG,
                Yuy: () => tk,
                Z58: () => i6,
                ZLX: () => rX,
                ZQM: () => tJ,
                Zcv: () => sQ,
                Zr2: () => e_,
                ZyN: () => a6,
                _4j: () => ag,
                _QJ: () => ea,
                _Ut: () => ad,
                a55: () => e$,
                a5J: () => en,
                aEY: () => L,
                aJ8: () => tl,
                aVO: () => ab,
                amv: () => eT,
                b4q: () => no,
                bC7: () => el,
                bCz: () => _,
                bI3: () => eM,
                bdM: () => ar,
                bkx: () => tB,
                brA: () => X,
                bw0: () => $,
                c90: () => tX,
                cHt: () => tC,
                caT: () => K,
                cj9: () => e4,
                czI: () => ee,
                dYF: () => ib,
                dcC: () => tW,
                dth: () => aU,
                dwI: () => ie,
                e0p: () => U,
                eHc: () => q,
                eaF: () => rw,
                eoi: () => eO,
                er$: () => eS,
                f4X: () => I,
                fBL: () => tT,
                g7M: () => th,
                gJ2: () => tP,
                gO9: () => z,
                gPd: () => iy,
                gWB: () => eN,
                gZr: () => t6,
                ghU: () => tg,
                hB5: () => f,
                hdd: () => V,
                hgQ: () => j,
                hsX: () => g,
                hxR: () => tv,
                hy7: () => tc,
                iNn: () => nd,
                ie2: () => P,
                ix0: () => tI,
                iyt: () => sV,
                j6: () => al,
                jR7: () => tG,
                jSS: () => t9,
                jUj: () => i4,
                jej: () => eH,
                jf0: () => ew,
                jzd: () => eI,
                k6Q: () => t$,
                k6q: () => tw,
                kO0: () => ek,
                kRr: () => tS,
                kTW: () => tx,
                kTp: () => tK,
                kn4: () => iw,
                kxk: () => rs,
                kyO: () => ts,
                lGu: () => H,
                lPF: () => eL,
                lxW: () => au,
                lyL: () => eo,
                mcG: () => eq,
                mrM: () => r$,
                nNL: () => tn,
                nST: () => T,
                nWS: () => iv,
                nZQ: () => ht,
                nzx: () => ai,
                ojh: () => B,
                ojs: () => ec,
                ov9: () => J,
                pBf: () => t1,
                pHI: () => tM,
                paN: () => tq,
                ppV: () => ia,
                psI: () => er,
                qFE: () => ng,
                qU7: () => nm,
                qUd: () => a5,
                qa3: () => t7,
                qad: () => O,
                qq$: () => eF,
                qtW: () => sI,
                rFo: () => iM,
                rKP: () => an,
                rSH: () => ei,
                ri6: () => eX,
                rjZ: () => np,
                sPf: () => l,
                tBo: () => hp,
                tJf: () => tA,
                tcD: () => ny,
                uB5: () => eh,
                uV5: () => tm,
                uWO: () => rL,
                ubm: () => a1,
                vim: () => eC,
                vyJ: () => eb,
                wAk: () => nD,
                wfO: () => td,
                wn6: () => F,
                wrO: () => tF,
                xFO: () => tp,
                xSv: () => Z,
                y3Z: () => eu,
                yT7: () => tE,
                y_p: () => ti,
                ypk: () => nW,
                z3S: () => eJ,
                zdS: () => tD,
                zgK: () => iN,
                znC: () => C
            });
            let l = "186",
                u = 0,
                c = 1,
                p = 2,
                d = 1,
                m = 2,
                y = 3,
                f = 0,
                g = 1,
                x = 2,
                v = 0,
                M = 1,
                b = 2,
                w = 3,
                S = 4,
                _ = 5,
                z = 100,
                A = 101,
                T = 102,
                C = 103,
                k = 104,
                B = 200,
                O = 201,
                I = 202,
                N = 203,
                P = 204,
                R = 205,
                V = 206,
                E = 207,
                F = 208,
                L = 209,
                j = 210,
                D = 211,
                W = 212,
                U = 213,
                J = 214,
                q = 0,
                H = 1,
                X = 2,
                Z = 3,
                Y = 4,
                G = 5,
                Q = 6,
                $ = 7,
                K = 0,
                tt = 1,
                te = 2,
                ti = 0,
                ts = 1,
                tr = 2,
                tn = 3,
                ta = 4,
                th = 5,
                to = 6,
                tl = 7,
                tu = "attached",
                tc = 301,
                tp = 302,
                td = 303,
                tm = 304,
                ty = 306,
                tf = 1e3,
                tg = 1001,
                tx = 1002,
                tv = 1003,
                tM = 1004,
                tb = 1005,
                tw = 1006,
                tS = 1007,
                t_ = 1008,
                tz = 1009,
                tA = 1010,
                tT = 1011,
                tC = 1012,
                tk = 1013,
                tB = 1014,
                tO = 1015,
                tI = 1016,
                tN = 1017,
                tP = 1018,
                tR = 1020,
                tV = 35902,
                tE = 35899,
                tF = 1021,
                tL = 1022,
                tj = 1023,
                tD = 1026,
                tW = 1027,
                tU = 1028,
                tJ = 1029,
                tq = 1030,
                tH = 1031,
                tX = 1033,
                tZ = 33776,
                tY = 33777,
                tG = 33778,
                tQ = 33779,
                t$ = 35840,
                tK = 35841,
                t0 = 35842,
                t1 = 35843,
                t2 = 36196,
                t3 = 37492,
                t5 = 37496,
                t4 = 37488,
                t6 = 37489,
                t8 = 37490,
                t9 = 37491,
                t7 = 37808,
                et = 37809,
                ee = 37810,
                ei = 37811,
                es = 37812,
                er = 37813,
                en = 37814,
                ea = 37815,
                eh = 37816,
                eo = 37817,
                el = 37818,
                eu = 37819,
                ec = 37820,
                ep = 37821,
                ed = 36492,
                em = 36494,
                ey = 36495,
                ef = 36283,
                eg = 36284,
                ex = 36285,
                ev = 36286,
                eM = 0,
                eb = 1,
                ew = "",
                eS = "srgb",
                e_ = "srgb-linear",
                ez = "linear",
                eA = "srgb",
                eT = 512,
                eC = 513,
                ek = 514,
                eB = 515,
                eO = 516,
                eI = 517,
                eN = 518,
                eP = 519,
                eR = 35048,
                eV = "300 es",
                eE = 2e3;

            function eF(t) {
                return document.createElementNS("http://www.w3.org/1999/xhtml", t)
            }

            function eL() {
                let t = eF("canvas");
                return t.style.display = "block", t
            }
            Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array;
            let ej = {};

            function eD(...t) {
                console.log("THREE." + t.shift(), ...t)
            }

            function eW(t) {
                let e = t[0];
                if ("string" == typeof e && e.startsWith("TSL:")) {
                    let e = t[1];
                    e && e.isStackTrace ? t[0] += " " + e.getLocation() : t[1] = 'Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'
                }
                return t
            }

            function eU(...t) {
                let e = "THREE." + (t = eW(t)).shift(); {
                    let i = t[0];
                    i && i.isStackTrace ? console.warn(i.getError(e)) : console.warn(e, ...t)
                }
            }

            function eJ(...t) {
                let e = "THREE." + (t = eW(t)).shift(); {
                    let i = t[0];
                    i && i.isStackTrace ? console.error(i.getError(e)) : console.error(e, ...t)
                }
            }

            function eq(...t) {
                let e = t.join(" ");
                e in ej || (ej[e] = !0, eU(...t))
            }

            function eH(t, e, i) {
                return new Promise(function(s, r) {
                    setTimeout(function n() {
                        switch (t.clientWaitSync(e, t.SYNC_FLUSH_COMMANDS_BIT, 0)) {
                            case t.WAIT_FAILED:
                                r();
                                break;
                            case t.TIMEOUT_EXPIRED:
                                setTimeout(n, i);
                                break;
                            default:
                                s()
                        }
                    }, i)
                })
            }
            let eX = {
                0: 1,
                2: 6,
                4: 7,
                3: 5,
                1: 0,
                6: 2,
                7: 4,
                5: 3
            };
            class eZ {
                addEventListener(t, e) {
                    void 0 === this._listeners && (this._listeners = {});
                    let i = this._listeners;
                    void 0 === i[t] && (i[t] = []), -1 === i[t].indexOf(e) && i[t].push(e)
                }
                hasEventListener(t, e) {
                    let i = this._listeners;
                    return void 0 !== i && void 0 !== i[t] && -1 !== i[t].indexOf(e)
                }
                removeEventListener(t, e) {
                    let i = this._listeners;
                    if (void 0 === i) return;
                    let s = i[t];
                    if (void 0 !== s) {
                        let t = s.indexOf(e); - 1 !== t && s.splice(t, 1)
                    }
                }
                dispatchEvent(t) {
                    let e = this._listeners;
                    if (void 0 === e) return;
                    let i = e[t.type];
                    if (void 0 !== i) {
                        t.target = this;
                        let e = i.slice(0);
                        for (let i = 0, s = e.length; i < s; i++) e[i].call(this, t);
                        t.target = null
                    }
                }
            }
            let eY = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0a", "0b", "0c", "0d", "0e", "0f", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1a", "1b", "1c", "1d", "1e", "1f", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "2a", "2b", "2c", "2d", "2e", "2f", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "3a", "3b", "3c", "3d", "3e", "3f", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "4a", "4b", "4c", "4d", "4e", "4f", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "5a", "5b", "5c", "5d", "5e", "5f", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "6a", "6b", "6c", "6d", "6e", "6f", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "7a", "7b", "7c", "7d", "7e", "7f", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8a", "8b", "8c", "8d", "8e", "8f", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9a", "9b", "9c", "9d", "9e", "9f", "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "aa", "ab", "ac", "ad", "ae", "af", "b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "ba", "bb", "bc", "bd", "be", "bf", "c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "ca", "cb", "cc", "cd", "ce", "cf", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "da", "db", "dc", "dd", "de", "df", "e0", "e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8", "e9", "ea", "eb", "ec", "ed", "ee", "ef", "f0", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "fa", "fb", "fc", "fd", "fe", "ff"],
                eG = 1234567,
                eQ = Math.PI / 180,
                e$ = 180 / Math.PI;

            function eK() {
                let t = 0xffffffff * Math.random() | 0,
                    e = 0xffffffff * Math.random() | 0,
                    i = 0xffffffff * Math.random() | 0,
                    s = 0xffffffff * Math.random() | 0;
                return (eY[255 & t] + eY[t >> 8 & 255] + eY[t >> 16 & 255] + eY[t >> 24 & 255] + "-" + eY[255 & e] + eY[e >> 8 & 255] + "-" + eY[e >> 16 & 15 | 64] + eY[e >> 24 & 255] + "-" + eY[63 & i | 128] + eY[i >> 8 & 255] + "-" + eY[i >> 16 & 255] + eY[i >> 24 & 255] + eY[255 & s] + eY[s >> 8 & 255] + eY[s >> 16 & 255] + eY[s >> 24 & 255]).toLowerCase()
            }

            function e0(t, e, i) {
                return Math.max(e, Math.min(i, t))
            }

            function e1(t, e) {
                return (t % e + e) % e
            }

            function e2(t, e, i) {
                return (1 - i) * t + i * e
            }

            function e3(t, e) {
                switch (e.constructor) {
                    case Float32Array:
                        return t;
                    case Uint32Array:
                        return t / 0xffffffff;
                    case Uint16Array:
                        return t / 65535;
                    case Uint8Array:
                    case Uint8ClampedArray:
                        return t / 255;
                    case Int32Array:
                        return Math.max(t / 0x7fffffff, -1);
                    case Int16Array:
                        return Math.max(t / 32767, -1);
                    case Int8Array:
                        return Math.max(t / 127, -1);
                    default:
                        throw Error("THREE.MathUtils: Invalid component type.")
                }
            }

            function e5(t, e) {
                switch (e.constructor) {
                    case Float32Array:
                        return t;
                    case Uint32Array:
                        return Math.round(0xffffffff * t);
                    case Uint16Array:
                        return Math.round(65535 * t);
                    case Uint8Array:
                    case Uint8ClampedArray:
                        return Math.round(255 * t);
                    case Int32Array:
                        return Math.round(0x7fffffff * t);
                    case Int16Array:
                        return Math.round(32767 * t);
                    case Int8Array:
                        return Math.round(127 * t);
                    default:
                        throw Error("THREE.MathUtils: Invalid component type.")
                }
            }
            let e4 = {
                DEG2RAD: eQ,
                RAD2DEG: e$,
                generateUUID: eK,
                clamp: e0,
                euclideanModulo: e1,
                mapLinear: function(t, e, i, s, r) {
                    return s + (t - e) * (r - s) / (i - e)
                },
                inverseLerp: function(t, e, i) {
                    return t !== e ? (i - t) / (e - t) : 0
                },
                lerp: e2,
                damp: function(t, e, i, s) {
                    return e2(t, e, 1 - Math.exp(-i * s))
                },
                pingpong: function(t, e = 1) {
                    return e - Math.abs(e1(t, 2 * e) - e)
                },
                smoothstep: function(t, e, i) {
                    return t <= e ? 0 : t >= i ? 1 : (t = (t - e) / (i - e)) * t * (3 - 2 * t)
                },
                smootherstep: function(t, e, i) {
                    return t <= e ? 0 : t >= i ? 1 : (t = (t - e) / (i - e)) * t * t * (t * (6 * t - 15) + 10)
                },
                randInt: function(t, e) {
                    return t + Math.floor(Math.random() * (e - t + 1))
                },
                randFloat: function(t, e) {
                    return t + Math.random() * (e - t)
                },
                randFloatSpread: function(t) {
                    return t * (.5 - Math.random())
                },
                seededRandom: function(t) {
                    void 0 !== t && (eG = t);
                    let e = eG += 0x6d2b79f5;
                    return e = Math.imul(e ^ e >>> 15, 1 | e), (((e ^= e + Math.imul(e ^ e >>> 7, 61 | e)) ^ e >>> 14) >>> 0) / 0x100000000
                },
                degToRad: function(t) {
                    return t * eQ
                },
                radToDeg: function(t) {
                    return t * e$
                },
                isPowerOfTwo: function(t) {
                    return t > 0 && Number.isInteger(t) && 2 ** Math.round(Math.log2(t)) === t
                },
                ceilPowerOfTwo: function(t) {
                    return Math.pow(2, Math.ceil(Math.log(t) / Math.LN2))
                },
                floorPowerOfTwo: function(t) {
                    return Math.pow(2, Math.floor(Math.log(t) / Math.LN2))
                },
                setQuaternionFromProperEuler: function(t, e, i, s, r) {
                    let n = Math.cos,
                        a = Math.sin,
                        h = n(i / 2),
                        o = a(i / 2),
                        l = n((e + s) / 2),
                        u = a((e + s) / 2),
                        c = n((e - s) / 2),
                        p = a((e - s) / 2),
                        d = n((s - e) / 2),
                        m = a((s - e) / 2);
                    switch (r) {
                        case "XYX":
                            t.set(h * u, o * c, o * p, h * l);
                            break;
                        case "YZY":
                            t.set(o * p, h * u, o * c, h * l);
                            break;
                        case "ZXZ":
                            t.set(o * c, o * p, h * u, h * l);
                            break;
                        case "XZX":
                            t.set(h * u, o * m, o * d, h * l);
                            break;
                        case "YXY":
                            t.set(o * d, h * u, o * m, h * l);
                            break;
                        case "ZYZ":
                            t.set(o * m, o * d, h * u, h * l);
                            break;
                        default:
                            eU("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: " + r)
                    }
                },
                normalize: e5,
                denormalize: e3
            };
            class e6 {
                static {
                    e6.prototype.isVector2 = !0
                }
                constructor(t = 0, e = 0) {
                    this.x = t, this.y = e
                }
                get width() {
                    return this.x
                }
                set width(t) {
                    this.x = t
                }
                get height() {
                    return this.y
                }
                set height(t) {
                    this.y = t
                }
                set(t, e) {
                    return this.x = t, this.y = e, this
                }
                setScalar(t) {
                    return this.x = t, this.y = t, this
                }
                setX(t) {
                    return this.x = t, this
                }
                setY(t) {
                    return this.y = t, this
                }
                setComponent(t, e) {
                    switch (t) {
                        case 0:
                            this.x = e;
                            break;
                        case 1:
                            this.y = e;
                            break;
                        default:
                            throw Error("THREE.Vector2: index is out of range: " + t)
                    }
                    return this
                }
                getComponent(t) {
                    switch (t) {
                        case 0:
                            return this.x;
                        case 1:
                            return this.y;
                        default:
                            throw Error("THREE.Vector2: index is out of range: " + t)
                    }
                }
                clone() {
                    return new this.constructor(this.x, this.y)
                }
                copy(t) {
                    return this.x = t.x, this.y = t.y, this
                }
                add(t) {
                    return this.x += t.x, this.y += t.y, this
                }
                addScalar(t) {
                    return this.x += t, this.y += t, this
                }
                addVectors(t, e) {
                    return this.x = t.x + e.x, this.y = t.y + e.y, this
                }
                addScaledVector(t, e) {
                    return this.x += t.x * e, this.y += t.y * e, this
                }
                sub(t) {
                    return this.x -= t.x, this.y -= t.y, this
                }
                subScalar(t) {
                    return this.x -= t, this.y -= t, this
                }
                subVectors(t, e) {
                    return this.x = t.x - e.x, this.y = t.y - e.y, this
                }
                multiply(t) {
                    return this.x *= t.x, this.y *= t.y, this
                }
                multiplyScalar(t) {
                    return this.x *= t, this.y *= t, this
                }
                divide(t) {
                    return this.x /= t.x, this.y /= t.y, this
                }
                divideScalar(t) {
                    return this.multiplyScalar(1 / t)
                }
                applyMatrix3(t) {
                    let e = this.x,
                        i = this.y,
                        s = t.elements;
                    return this.x = s[0] * e + s[3] * i + s[6], this.y = s[1] * e + s[4] * i + s[7], this
                }
                min(t) {
                    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this
                }
                max(t) {
                    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this
                }
                clamp(t, e) {
                    return this.x = e0(this.x, t.x, e.x), this.y = e0(this.y, t.y, e.y), this
                }
                clampScalar(t, e) {
                    return this.x = e0(this.x, t, e), this.y = e0(this.y, t, e), this
                }
                clampLength(t, e) {
                    let i = this.length();
                    return this.divideScalar(i || 1).multiplyScalar(e0(i, t, e))
                }
                floor() {
                    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this
                }
                ceil() {
                    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this
                }
                round() {
                    return this.x = Math.round(this.x), this.y = Math.round(this.y), this
                }
                roundToZero() {
                    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this
                }
                negate() {
                    return this.x = -this.x, this.y = -this.y, this
                }
                dot(t) {
                    return this.x * t.x + this.y * t.y
                }
                cross(t) {
                    return this.x * t.y - this.y * t.x
                }
                lengthSq() {
                    return this.x * this.x + this.y * this.y
                }
                length() {
                    return Math.sqrt(this.x * this.x + this.y * this.y)
                }
                manhattanLength() {
                    return Math.abs(this.x) + Math.abs(this.y)
                }
                normalize() {
                    return this.divideScalar(this.length() || 1)
                }
                angle() {
                    return Math.atan2(-this.y, -this.x) + Math.PI
                }
                angleTo(t) {
                    let e = Math.sqrt(this.lengthSq() * t.lengthSq());
                    return 0 === e ? Math.PI / 2 : Math.acos(e0(this.dot(t) / e, -1, 1))
                }
                distanceTo(t) {
                    return Math.sqrt(this.distanceToSquared(t))
                }
                distanceToSquared(t) {
                    let e = this.x - t.x,
                        i = this.y - t.y;
                    return e * e + i * i
                }
                manhattanDistanceTo(t) {
                    return Math.abs(this.x - t.x) + Math.abs(this.y - t.y)
                }
                setLength(t) {
                    return this.normalize().multiplyScalar(t)
                }
                lerp(t, e) {
                    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this
                }
                lerpVectors(t, e, i) {
                    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this
                }
                equals(t) {
                    return t.x === this.x && t.y === this.y
                }
                fromArray(t, e = 0) {
                    return this.x = t[e], this.y = t[e + 1], this
                }
                toArray(t = [], e = 0) {
                    return t[e] = this.x, t[e + 1] = this.y, t
                }
                fromBufferAttribute(t, e) {
                    return this.x = t.getX(e), this.y = t.getY(e), this
                }
                rotateAround(t, e) {
                    let i = Math.cos(e),
                        s = Math.sin(e),
                        r = this.x - t.x,
                        n = this.y - t.y;
                    return this.x = r * i - n * s + t.x, this.y = r * s + n * i + t.y, this
                }
                random() {
                    return this.x = Math.random(), this.y = Math.random(), this
                }*[Symbol.iterator]() {
                    yield this.x, yield this.y
                }
            }
            class e8 {
                constructor(t = 0, e = 0, i = 0, s = 1) {
                    this.isQuaternion = !0, this._x = t, this._y = e, this._z = i, this._w = s
                }
                static slerpFlat(t, e, i, s, r, n, a) {
                    let h = i[s + 0],
                        o = i[s + 1],
                        l = i[s + 2],
                        u = i[s + 3],
                        c = r[n + 0],
                        p = r[n + 1],
                        d = r[n + 2],
                        m = r[n + 3];
                    if (u !== m || h !== c || o !== p || l !== d) {
                        let t = h * c + o * p + l * d + u * m;
                        t < 0 && (c = -c, p = -p, d = -d, m = -m, t = -t);
                        let e = 1 - a;
                        if (t < .9995) {
                            let i = Math.acos(t),
                                s = Math.sin(i);
                            h = h * (e = Math.sin(e * i) / s) + c * (a = Math.sin(a * i) / s), o = o * e + p * a, l = l * e + d * a, u = u * e + m * a
                        } else {
                            let t = 1 / Math.sqrt((h = h * e + c * a) * h + (o = o * e + p * a) * o + (l = l * e + d * a) * l + (u = u * e + m * a) * u);
                            h *= t, o *= t, l *= t, u *= t
                        }
                    }
                    t[e] = h, t[e + 1] = o, t[e + 2] = l, t[e + 3] = u
                }
                static multiplyQuaternionsFlat(t, e, i, s, r, n) {
                    let a = i[s],
                        h = i[s + 1],
                        o = i[s + 2],
                        l = i[s + 3],
                        u = r[n],
                        c = r[n + 1],
                        p = r[n + 2],
                        d = r[n + 3];
                    return t[e] = a * d + l * u + h * p - o * c, t[e + 1] = h * d + l * c + o * u - a * p, t[e + 2] = o * d + l * p + a * c - h * u, t[e + 3] = l * d - a * u - h * c - o * p, t
                }
                get x() {
                    return this._x
                }
                set x(t) {
                    this._x = t, this._onChangeCallback()
                }
                get y() {
                    return this._y
                }
                set y(t) {
                    this._y = t, this._onChangeCallback()
                }
                get z() {
                    return this._z
                }
                set z(t) {
                    this._z = t, this._onChangeCallback()
                }
                get w() {
                    return this._w
                }
                set w(t) {
                    this._w = t, this._onChangeCallback()
                }
                set(t, e, i, s) {
                    return this._x = t, this._y = e, this._z = i, this._w = s, this._onChangeCallback(), this
                }
                clone() {
                    return new this.constructor(this._x, this._y, this._z, this._w)
                }
                copy(t) {
                    return this._x = t.x, this._y = t.y, this._z = t.z, this._w = t.w, this._onChangeCallback(), this
                }
                setFromEuler(t, e = !0) {
                    let i = t._x,
                        s = t._y,
                        r = t._z,
                        n = t._order,
                        a = Math.cos,
                        h = Math.sin,
                        o = a(i / 2),
                        l = a(s / 2),
                        u = a(r / 2),
                        c = h(i / 2),
                        p = h(s / 2),
                        d = h(r / 2);
                    switch (n) {
                        case "XYZ":
                            this._x = c * l * u + o * p * d, this._y = o * p * u - c * l * d, this._z = o * l * d + c * p * u, this._w = o * l * u - c * p * d;
                            break;
                        case "YXZ":
                            this._x = c * l * u + o * p * d, this._y = o * p * u - c * l * d, this._z = o * l * d - c * p * u, this._w = o * l * u + c * p * d;
                            break;
                        case "ZXY":
                            this._x = c * l * u - o * p * d, this._y = o * p * u + c * l * d, this._z = o * l * d + c * p * u, this._w = o * l * u - c * p * d;
                            break;
                        case "ZYX":
                            this._x = c * l * u - o * p * d, this._y = o * p * u + c * l * d, this._z = o * l * d - c * p * u, this._w = o * l * u + c * p * d;
                            break;
                        case "YZX":
                            this._x = c * l * u + o * p * d, this._y = o * p * u + c * l * d, this._z = o * l * d - c * p * u, this._w = o * l * u - c * p * d;
                            break;
                        case "XZY":
                            this._x = c * l * u - o * p * d, this._y = o * p * u - c * l * d, this._z = o * l * d + c * p * u, this._w = o * l * u + c * p * d;
                            break;
                        default:
                            eU("Quaternion: .setFromEuler() encountered an unknown order: " + n)
                    }
                    return !0 === e && this._onChangeCallback(), this
                }
                setFromAxisAngle(t, e) {
                    let i = e / 2,
                        s = Math.sin(i);
                    return this._x = t.x * s, this._y = t.y * s, this._z = t.z * s, this._w = Math.cos(i), this._onChangeCallback(), this
                }
                setFromRotationMatrix(t) {
                    let e = t.elements,
                        i = e[0],
                        s = e[4],
                        r = e[8],
                        n = e[1],
                        a = e[5],
                        h = e[9],
                        o = e[2],
                        l = e[6],
                        u = e[10],
                        c = i + a + u;
                    if (c > 0) {
                        let t = .5 / Math.sqrt(c + 1);
                        this._w = .25 / t, this._x = (l - h) * t, this._y = (r - o) * t, this._z = (n - s) * t
                    } else if (i > a && i > u) {
                        let t = 2 * Math.sqrt(1 + i - a - u);
                        this._w = (l - h) / t, this._x = .25 * t, this._y = (s + n) / t, this._z = (r + o) / t
                    } else if (a > u) {
                        let t = 2 * Math.sqrt(1 + a - i - u);
                        this._w = (r - o) / t, this._x = (s + n) / t, this._y = .25 * t, this._z = (h + l) / t
                    } else {
                        let t = 2 * Math.sqrt(1 + u - i - a);
                        this._w = (n - s) / t, this._x = (r + o) / t, this._y = (h + l) / t, this._z = .25 * t
                    }
                    return this._onChangeCallback(), this
                }
                setFromUnitVectors(t, e) {
                    let i = t.dot(e) + 1;
                    return i < 1e-8 ? (i = 0, Math.abs(t.x) > Math.abs(t.z) ? (this._x = -t.y, this._y = t.x, this._z = 0) : (this._x = 0, this._y = -t.z, this._z = t.y)) : (this._x = t.y * e.z - t.z * e.y, this._y = t.z * e.x - t.x * e.z, this._z = t.x * e.y - t.y * e.x), this._w = i, this.normalize()
                }
                angleTo(t) {
                    return 2 * Math.acos(Math.abs(e0(this.dot(t), -1, 1)))
                }
                rotateTowards(t, e) {
                    let i = this.angleTo(t);
                    if (0 === i) return this;
                    let s = Math.min(1, e / i);
                    return this.slerp(t, s), this
                }
                identity() {
                    return this.set(0, 0, 0, 1)
                }
                invert() {
                    return this.conjugate()
                }
                conjugate() {
                    return this._x *= -1, this._y *= -1, this._z *= -1, this._onChangeCallback(), this
                }
                dot(t) {
                    return this._x * t._x + this._y * t._y + this._z * t._z + this._w * t._w
                }
                lengthSq() {
                    return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w
                }
                length() {
                    return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w)
                }
                normalize() {
                    let t = this.length();
                    return 0 === t ? (this._x = 0, this._y = 0, this._z = 0, this._w = 1) : (t = 1 / t, this._x = this._x * t, this._y = this._y * t, this._z = this._z * t, this._w = this._w * t), this._onChangeCallback(), this
                }
                multiply(t) {
                    return this.multiplyQuaternions(this, t)
                }
                premultiply(t) {
                    return this.multiplyQuaternions(t, this)
                }
                multiplyQuaternions(t, e) {
                    let i = t._x,
                        s = t._y,
                        r = t._z,
                        n = t._w,
                        a = e._x,
                        h = e._y,
                        o = e._z,
                        l = e._w;
                    return this._x = i * l + n * a + s * o - r * h, this._y = s * l + n * h + r * a - i * o, this._z = r * l + n * o + i * h - s * a, this._w = n * l - i * a - s * h - r * o, this._onChangeCallback(), this
                }
                slerp(t, e) {
                    let i = t._x,
                        s = t._y,
                        r = t._z,
                        n = t._w,
                        a = this.dot(t);
                    a < 0 && (i = -i, s = -s, r = -r, n = -n, a = -a);
                    let h = 1 - e;
                    if (a < .9995) {
                        let t = Math.acos(a),
                            o = Math.sin(t);
                        h = Math.sin(h * t) / o, e = Math.sin(e * t) / o, this._x = this._x * h + i * e, this._y = this._y * h + s * e, this._z = this._z * h + r * e, this._w = this._w * h + n * e, this._onChangeCallback()
                    } else this._x = this._x * h + i * e, this._y = this._y * h + s * e, this._z = this._z * h + r * e, this._w = this._w * h + n * e, this.normalize();
                    return this
                }
                slerpQuaternions(t, e, i) {
                    return this.copy(t).slerp(e, i)
                }
                random() {
                    let t = 2 * Math.PI * Math.random(),
                        e = 2 * Math.PI * Math.random(),
                        i = Math.random(),
                        s = Math.sqrt(1 - i),
                        r = Math.sqrt(i);
                    return this.set(s * Math.sin(t), s * Math.cos(t), r * Math.sin(e), r * Math.cos(e))
                }
                equals(t) {
                    return t._x === this._x && t._y === this._y && t._z === this._z && t._w === this._w
                }
                fromArray(t, e = 0) {
                    return this._x = t[e], this._y = t[e + 1], this._z = t[e + 2], this._w = t[e + 3], this._onChangeCallback(), this
                }
                toArray(t = [], e = 0) {
                    return t[e] = this._x, t[e + 1] = this._y, t[e + 2] = this._z, t[e + 3] = this._w, t
                }
                fromBufferAttribute(t, e) {
                    return this._x = t.getX(e), this._y = t.getY(e), this._z = t.getZ(e), this._w = t.getW(e), this._onChangeCallback(), this
                }
                toJSON() {
                    return this.toArray()
                }
                _onChange(t) {
                    return this._onChangeCallback = t, this
                }
                _onChangeCallback() {}*[Symbol.iterator]() {
                    yield this._x, yield this._y, yield this._z, yield this._w
                }
            }
            class e9 {
                static {
                    e9.prototype.isVector3 = !0
                }
                constructor(t = 0, e = 0, i = 0) {
                    this.x = t, this.y = e, this.z = i
                }
                set(t, e, i) {
                    return void 0 === i && (i = this.z), this.x = t, this.y = e, this.z = i, this
                }
                setScalar(t) {
                    return this.x = t, this.y = t, this.z = t, this
                }
                setX(t) {
                    return this.x = t, this
                }
                setY(t) {
                    return this.y = t, this
                }
                setZ(t) {
                    return this.z = t, this
                }
                setComponent(t, e) {
                    switch (t) {
                        case 0:
                            this.x = e;
                            break;
                        case 1:
                            this.y = e;
                            break;
                        case 2:
                            this.z = e;
                            break;
                        default:
                            throw Error("THREE.Vector3: index is out of range: " + t)
                    }
                    return this
                }
                getComponent(t) {
                    switch (t) {
                        case 0:
                            return this.x;
                        case 1:
                            return this.y;
                        case 2:
                            return this.z;
                        default:
                            throw Error("THREE.Vector3: index is out of range: " + t)
                    }
                }
                clone() {
                    return new this.constructor(this.x, this.y, this.z)
                }
                copy(t) {
                    return this.x = t.x, this.y = t.y, this.z = t.z, this
                }
                add(t) {
                    return this.x += t.x, this.y += t.y, this.z += t.z, this
                }
                addScalar(t) {
                    return this.x += t, this.y += t, this.z += t, this
                }
                addVectors(t, e) {
                    return this.x = t.x + e.x, this.y = t.y + e.y, this.z = t.z + e.z, this
                }
                addScaledVector(t, e) {
                    return this.x += t.x * e, this.y += t.y * e, this.z += t.z * e, this
                }
                sub(t) {
                    return this.x -= t.x, this.y -= t.y, this.z -= t.z, this
                }
                subScalar(t) {
                    return this.x -= t, this.y -= t, this.z -= t, this
                }
                subVectors(t, e) {
                    return this.x = t.x - e.x, this.y = t.y - e.y, this.z = t.z - e.z, this
                }
                multiply(t) {
                    return this.x *= t.x, this.y *= t.y, this.z *= t.z, this
                }
                multiplyScalar(t) {
                    return this.x *= t, this.y *= t, this.z *= t, this
                }
                multiplyVectors(t, e) {
                    return this.x = t.x * e.x, this.y = t.y * e.y, this.z = t.z * e.z, this
                }
                applyEuler(t) {
                    return this.applyQuaternion(it.setFromEuler(t))
                }
                applyAxisAngle(t, e) {
                    return this.applyQuaternion(it.setFromAxisAngle(t, e))
                }
                applyMatrix3(t) {
                    let e = this.x,
                        i = this.y,
                        s = this.z,
                        r = t.elements;
                    return this.x = r[0] * e + r[3] * i + r[6] * s, this.y = r[1] * e + r[4] * i + r[7] * s, this.z = r[2] * e + r[5] * i + r[8] * s, this
                }
                applyNormalMatrix(t) {
                    return this.applyMatrix3(t).normalize()
                }
                applyMatrix4(t) {
                    let e = this.x,
                        i = this.y,
                        s = this.z,
                        r = t.elements,
                        n = 1 / (r[3] * e + r[7] * i + r[11] * s + r[15]);
                    return this.x = (r[0] * e + r[4] * i + r[8] * s + r[12]) * n, this.y = (r[1] * e + r[5] * i + r[9] * s + r[13]) * n, this.z = (r[2] * e + r[6] * i + r[10] * s + r[14]) * n, this
                }
                applyQuaternion(t) {
                    let e = this.x,
                        i = this.y,
                        s = this.z,
                        r = t.x,
                        n = t.y,
                        a = t.z,
                        h = t.w,
                        o = 2 * (n * s - a * i),
                        l = 2 * (a * e - r * s),
                        u = 2 * (r * i - n * e);
                    return this.x = e + h * o + n * u - a * l, this.y = i + h * l + a * o - r * u, this.z = s + h * u + r * l - n * o, this
                }
                project(t) {
                    return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)
                }
                unproject(t) {
                    return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)
                }
                transformDirection(t) {
                    let e = this.x,
                        i = this.y,
                        s = this.z,
                        r = t.elements;
                    return this.x = r[0] * e + r[4] * i + r[8] * s, this.y = r[1] * e + r[5] * i + r[9] * s, this.z = r[2] * e + r[6] * i + r[10] * s, this.normalize()
                }
                divide(t) {
                    return this.x /= t.x, this.y /= t.y, this.z /= t.z, this
                }
                divideScalar(t) {
                    return this.multiplyScalar(1 / t)
                }
                min(t) {
                    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this.z = Math.min(this.z, t.z), this
                }
                max(t) {
                    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this.z = Math.max(this.z, t.z), this
                }
                clamp(t, e) {
                    return this.x = e0(this.x, t.x, e.x), this.y = e0(this.y, t.y, e.y), this.z = e0(this.z, t.z, e.z), this
                }
                clampScalar(t, e) {
                    return this.x = e0(this.x, t, e), this.y = e0(this.y, t, e), this.z = e0(this.z, t, e), this
                }
                clampLength(t, e) {
                    let i = this.length();
                    return this.divideScalar(i || 1).multiplyScalar(e0(i, t, e))
                }
                floor() {
                    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), this
                }
                ceil() {
                    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), this
                }
                round() {
                    return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), this
                }
                roundToZero() {
                    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this.z = Math.trunc(this.z), this
                }
                negate() {
                    return this.x = -this.x, this.y = -this.y, this.z = -this.z, this
                }
                dot(t) {
                    return this.x * t.x + this.y * t.y + this.z * t.z
                }
                lengthSq() {
                    return this.x * this.x + this.y * this.y + this.z * this.z
                }
                length() {
                    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z)
                }
                manhattanLength() {
                    return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z)
                }
                normalize() {
                    return this.divideScalar(this.length() || 1)
                }
                setLength(t) {
                    return this.normalize().multiplyScalar(t)
                }
                lerp(t, e) {
                    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this.z += (t.z - this.z) * e, this
                }
                lerpVectors(t, e, i) {
                    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this.z = t.z + (e.z - t.z) * i, this
                }
                cross(t) {
                    return this.crossVectors(this, t)
                }
                crossVectors(t, e) {
                    let i = t.x,
                        s = t.y,
                        r = t.z,
                        n = e.x,
                        a = e.y,
                        h = e.z;
                    return this.x = s * h - r * a, this.y = r * n - i * h, this.z = i * a - s * n, this
                }
                projectOnVector(t) {
                    let e = t.lengthSq();
                    if (0 === e) return this.set(0, 0, 0);
                    let i = t.dot(this) / e;
                    return this.copy(t).multiplyScalar(i)
                }
                projectOnPlane(t) {
                    return e7.copy(this).projectOnVector(t), this.sub(e7)
                }
                reflect(t) {
                    return this.sub(e7.copy(t).multiplyScalar(2 * this.dot(t)))
                }
                angleTo(t) {
                    let e = Math.sqrt(this.lengthSq() * t.lengthSq());
                    return 0 === e ? Math.PI / 2 : Math.acos(e0(this.dot(t) / e, -1, 1))
                }
                distanceTo(t) {
                    return Math.sqrt(this.distanceToSquared(t))
                }
                distanceToSquared(t) {
                    let e = this.x - t.x,
                        i = this.y - t.y,
                        s = this.z - t.z;
                    return e * e + i * i + s * s
                }
                manhattanDistanceTo(t) {
                    return Math.abs(this.x - t.x) + Math.abs(this.y - t.y) + Math.abs(this.z - t.z)
                }
                setFromSpherical(t) {
                    return this.setFromSphericalCoords(t.radius, t.phi, t.theta)
                }
                setFromSphericalCoords(t, e, i) {
                    let s = Math.sin(e) * t;
                    return this.x = s * Math.sin(i), this.y = Math.cos(e) * t, this.z = s * Math.cos(i), this
                }
                setFromCylindrical(t) {
                    return this.setFromCylindricalCoords(t.radius, t.theta, t.y)
                }
                setFromCylindricalCoords(t, e, i) {
                    return this.x = t * Math.sin(e), this.y = i, this.z = t * Math.cos(e), this
                }
                setFromMatrixPosition(t) {
                    let e = t.elements;
                    return this.x = e[12], this.y = e[13], this.z = e[14], this
                }
                setFromMatrixScale(t) {
                    let e = this.setFromMatrixColumn(t, 0).length(),
                        i = this.setFromMatrixColumn(t, 1).length(),
                        s = this.setFromMatrixColumn(t, 2).length();
                    return this.x = e, this.y = i, this.z = s, this
                }
                setFromMatrixColumn(t, e) {
                    return this.fromArray(t.elements, 4 * e)
                }
                setFromMatrix3Column(t, e) {
                    return this.fromArray(t.elements, 3 * e)
                }
                setFromEuler(t) {
                    return this.x = t._x, this.y = t._y, this.z = t._z, this
                }
                setFromColor(t) {
                    return this.x = t.r, this.y = t.g, this.z = t.b, this
                }
                equals(t) {
                    return t.x === this.x && t.y === this.y && t.z === this.z
                }
                fromArray(t, e = 0) {
                    return this.x = t[e], this.y = t[e + 1], this.z = t[e + 2], this
                }
                toArray(t = [], e = 0) {
                    return t[e] = this.x, t[e + 1] = this.y, t[e + 2] = this.z, t
                }
                fromBufferAttribute(t, e) {
                    return this.x = t.getX(e), this.y = t.getY(e), this.z = t.getZ(e), this
                }
                random() {
                    return this.x = Math.random(), this.y = Math.random(), this.z = Math.random(), this
                }
                randomDirection() {
                    let t = Math.random() * Math.PI * 2,
                        e = 2 * Math.random() - 1,
                        i = Math.sqrt(1 - e * e);
                    return this.x = i * Math.cos(t), this.y = e, this.z = i * Math.sin(t), this
                }*[Symbol.iterator]() {
                    yield this.x, yield this.y, yield this.z
                }
            }
            let e7 = new e9,
                it = new e8;
            class ie {
                static {
                    ie.prototype.isMatrix3 = !0
                }
                constructor(t, e, i, s, r, n, a, h, o) {
                    this.elements = [1, 0, 0, 0, 1, 0, 0, 0, 1], void 0 !== t && this.set(t, e, i, s, r, n, a, h, o)
                }
                set(t, e, i, s, r, n, a, h, o) {
                    let l = this.elements;
                    return l[0] = t, l[1] = s, l[2] = a, l[3] = e, l[4] = r, l[5] = h, l[6] = i, l[7] = n, l[8] = o, this
                }
                identity() {
                    return this.set(1, 0, 0, 0, 1, 0, 0, 0, 1), this
                }
                copy(t) {
                    let e = this.elements,
                        i = t.elements;
                    return e[0] = i[0], e[1] = i[1], e[2] = i[2], e[3] = i[3], e[4] = i[4], e[5] = i[5], e[6] = i[6], e[7] = i[7], e[8] = i[8], this
                }
                extractBasis(t, e, i) {
                    return t.setFromMatrix3Column(this, 0), e.setFromMatrix3Column(this, 1), i.setFromMatrix3Column(this, 2), this
                }
                setFromMatrix4(t) {
                    let e = t.elements;
                    return this.set(e[0], e[4], e[8], e[1], e[5], e[9], e[2], e[6], e[10]), this
                }
                multiply(t) {
                    return this.multiplyMatrices(this, t)
                }
                premultiply(t) {
                    return this.multiplyMatrices(t, this)
                }
                multiplyMatrices(t, e) {
                    let i = t.elements,
                        s = e.elements,
                        r = this.elements,
                        n = i[0],
                        a = i[3],
                        h = i[6],
                        o = i[1],
                        l = i[4],
                        u = i[7],
                        c = i[2],
                        p = i[5],
                        d = i[8],
                        m = s[0],
                        y = s[3],
                        f = s[6],
                        g = s[1],
                        x = s[4],
                        v = s[7],
                        M = s[2],
                        b = s[5],
                        w = s[8];
                    return r[0] = n * m + a * g + h * M, r[3] = n * y + a * x + h * b, r[6] = n * f + a * v + h * w, r[1] = o * m + l * g + u * M, r[4] = o * y + l * x + u * b, r[7] = o * f + l * v + u * w, r[2] = c * m + p * g + d * M, r[5] = c * y + p * x + d * b, r[8] = c * f + p * v + d * w, this
                }
                multiplyScalar(t) {
                    let e = this.elements;
                    return e[0] *= t, e[3] *= t, e[6] *= t, e[1] *= t, e[4] *= t, e[7] *= t, e[2] *= t, e[5] *= t, e[8] *= t, this
                }
                determinant() {
                    let t = this.elements,
                        e = t[0],
                        i = t[1],
                        s = t[2],
                        r = t[3],
                        n = t[4],
                        a = t[5],
                        h = t[6],
                        o = t[7],
                        l = t[8];
                    return e * n * l - e * a * o - i * r * l + i * a * h + s * r * o - s * n * h
                }
                invert() {
                    let t = this.elements,
                        e = t[0],
                        i = t[1],
                        s = t[2],
                        r = t[3],
                        n = t[4],
                        a = t[5],
                        h = t[6],
                        o = t[7],
                        l = t[8],
                        u = l * n - a * o,
                        c = a * h - l * r,
                        p = o * r - n * h,
                        d = e * u + i * c + s * p;
                    if (0 === d) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0);
                    let m = 1 / d;
                    return t[0] = u * m, t[1] = (s * o - l * i) * m, t[2] = (a * i - s * n) * m, t[3] = c * m, t[4] = (l * e - s * h) * m, t[5] = (s * r - a * e) * m, t[6] = p * m, t[7] = (i * h - o * e) * m, t[8] = (n * e - i * r) * m, this
                }
                transpose() {
                    let t, e = this.elements;
                    return t = e[1], e[1] = e[3], e[3] = t, t = e[2], e[2] = e[6], e[6] = t, t = e[5], e[5] = e[7], e[7] = t, this
                }
                getNormalMatrix(t) {
                    return this.setFromMatrix4(t).invert().transpose()
                }
                transposeIntoArray(t) {
                    let e = this.elements;
                    return t[0] = e[0], t[1] = e[3], t[2] = e[6], t[3] = e[1], t[4] = e[4], t[5] = e[7], t[6] = e[2], t[7] = e[5], t[8] = e[8], this
                }
                setUvTransform(t, e, i, s, r, n, a) {
                    let h = Math.cos(r),
                        o = Math.sin(r);
                    return this.set(i * h, i * o, -i * (h * n + o * a) + n + t, -s * o, s * h, -s * (-o * n + h * a) + a + e, 0, 0, 1), this
                }
                scale(t, e) {
                    return eq("Matrix3: .scale() is deprecated. Use .makeScale() instead."), this.premultiply(ii.makeScale(t, e)), this
                }
                rotate(t) {
                    return eq("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."), this.premultiply(ii.makeRotation(-t)), this
                }
                translate(t, e) {
                    return eq("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."), this.premultiply(ii.makeTranslation(t, e)), this
                }
                makeTranslation(t, e) {
                    return t.isVector2 ? this.set(1, 0, t.x, 0, 1, t.y, 0, 0, 1) : this.set(1, 0, t, 0, 1, e, 0, 0, 1), this
                }
                makeRotation(t) {
                    let e = Math.cos(t),
                        i = Math.sin(t);
                    return this.set(e, -i, 0, i, e, 0, 0, 0, 1), this
                }
                makeScale(t, e) {
                    return this.set(t, 0, 0, 0, e, 0, 0, 0, 1), this
                }
                equals(t) {
                    let e = this.elements,
                        i = t.elements;
                    for (let t = 0; t < 9; t++)
                        if (e[t] !== i[t]) return !1;
                    return !0
                }
                fromArray(t, e = 0) {
                    for (let i = 0; i < 9; i++) this.elements[i] = t[i + e];
                    return this
                }
                toArray(t = [], e = 0) {
                    let i = this.elements;
                    return t[e] = i[0], t[e + 1] = i[1], t[e + 2] = i[2], t[e + 3] = i[3], t[e + 4] = i[4], t[e + 5] = i[5], t[e + 6] = i[6], t[e + 7] = i[7], t[e + 8] = i[8], t
                }
                clone() {
                    return new this.constructor().fromArray(this.elements)
                }
            }
            let ii = new ie,
                is = new ie().set(.4123908, .3575843, .1804808, .212639, .7151687, .0721923, .0193308, .1191948, .9505322),
                ir = new ie().set(3.2409699, -1.5373832, -.4986108, -.9692436, 1.8759675, .0415551, .0556301, -.203977, 1.0569715),
                ia = (a = [.64, .33, .3, .6, .15, .06], h = [.2126, .7152, .0722], o = [.3127, .329], (n = {
                    enabled: !0,
                    workingColorSpace: e_,
                    spaces: {},
                    convert: function(t, e, i) {
                        return !1 !== this.enabled && e !== i && e && i && (this.spaces[e].transfer === eA && (t.r = ih(t.r), t.g = ih(t.g), t.b = ih(t.b)), this.spaces[e].primaries !== this.spaces[i].primaries && (t.applyMatrix3(this.spaces[e].toXYZ), t.applyMatrix3(this.spaces[i].fromXYZ)), this.spaces[i].transfer === eA && (t.r = io(t.r), t.g = io(t.g), t.b = io(t.b))), t
                    },
                    workingToColorSpace: function(t, e) {
                        return this.convert(t, this.workingColorSpace, e)
                    },
                    colorSpaceToWorking: function(t, e) {
                        return this.convert(t, e, this.workingColorSpace)
                    },
                    getPrimaries: function(t) {
                        return this.spaces[t].primaries
                    },
                    getTransfer: function(t) {
                        return t === ew ? ez : this.spaces[t].transfer
                    },
                    getToneMappingMode: function(t) {
                        return this.spaces[t].outputColorSpaceConfig.toneMappingMode || "standard"
                    },
                    getLuminanceCoefficients: function(t, e = this.workingColorSpace) {
                        return t.fromArray(this.spaces[e].luminanceCoefficients)
                    },
                    define: function(t) {
                        Object.assign(this.spaces, t)
                    },
                    _getMatrix: function(t, e, i) {
                        return t.copy(this.spaces[e].toXYZ).multiply(this.spaces[i].fromXYZ)
                    },
                    _getDrawingBufferColorSpace: function(t) {
                        return this.spaces[t].outputColorSpaceConfig.drawingBufferColorSpace
                    },
                    _getUnpackColorSpace: function(t = this.workingColorSpace) {
                        return this.spaces[t].workingColorSpaceConfig.unpackColorSpace
                    },
                    fromWorkingColorSpace: function(t, e) {
                        return eq("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."), n.workingToColorSpace(t, e)
                    },
                    toWorkingColorSpace: function(t, e) {
                        return eq("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."), n.colorSpaceToWorking(t, e)
                    }
                }).define({
                    [e_]: {
                        primaries: a,
                        whitePoint: o,
                        transfer: ez,
                        toXYZ: is,
                        fromXYZ: ir,
                        luminanceCoefficients: h,
                        workingColorSpaceConfig: {
                            unpackColorSpace: eS
                        },
                        outputColorSpaceConfig: {
                            drawingBufferColorSpace: eS
                        }
                    },
                    [eS]: {
                        primaries: a,
                        whitePoint: o,
                        transfer: eA,
                        toXYZ: is,
                        fromXYZ: ir,
                        luminanceCoefficients: h,
                        outputColorSpaceConfig: {
                            drawingBufferColorSpace: eS
                        }
                    }
                }), n);

            function ih(t) {
                return t < .04045 ? .0773993808 * t : Math.pow(.9478672986 * t + .0521327014, 2.4)
            }

            function io(t) {
                return t < .0031308 ? 12.92 * t : 1.055 * Math.pow(t, .41666) - .055
            }
            class il {
                static getDataURL(t, e = "image/png") {
                    let i;
                    if (/^data:/i.test(t.src) || "u" < typeof HTMLCanvasElement) return t.src;
                    if (t instanceof HTMLCanvasElement) i = t;
                    else {
                        void 0 === s && (s = eF("canvas")), s.width = t.width, s.height = t.height;
                        let e = s.getContext("2d");
                        t instanceof ImageData ? e.putImageData(t, 0, 0) : e.drawImage(t, 0, 0, t.width, t.height), i = s
                    }
                    return i.toDataURL(e)
                }
                static sRGBToLinear(t) {
                    if ("u" > typeof HTMLImageElement && t instanceof HTMLImageElement || "u" > typeof HTMLCanvasElement && t instanceof HTMLCanvasElement || "u" > typeof ImageBitmap && t instanceof ImageBitmap) {
                        let e = eF("canvas");
                        e.width = t.width, e.height = t.height;
                        let i = e.getContext("2d");
                        i.drawImage(t, 0, 0, t.width, t.height);
                        let s = i.getImageData(0, 0, t.width, t.height),
                            r = s.data;
                        for (let t = 0; t < r.length; t++) r[t] = 255 * ih(r[t] / 255);
                        return i.putImageData(s, 0, 0), e
                    }
                    if (!t.data) return eU("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."), t; {
                        let e = t.data.slice(0);
                        for (let t = 0; t < e.length; t++) e instanceof Uint8Array || e instanceof Uint8ClampedArray ? e[t] = Math.floor(255 * ih(e[t] / 255)) : e[t] = ih(e[t]);
                        return {
                            data: e,
                            width: t.width,
                            height: t.height
                        }
                    }
                }
            }
            let iu = 0;
            class ic {
                constructor(t = null) {
                    this.isTextureSource = !0, Object.defineProperty(this, "id", {
                        value: iu++
                    }), this.uuid = eK(), this.data = t, this.dataReady = !0, this.version = 0
                }
                getSize(t) {
                    let e = this.data;
                    return "u" > typeof HTMLVideoElement && e instanceof HTMLVideoElement ? t.set(e.videoWidth, e.videoHeight, 0) : "u" > typeof VideoFrame && e instanceof VideoFrame ? t.set(e.displayWidth, e.displayHeight, 0) : null !== e ? t.set(e.width, e.height, e.depth || 0) : t.set(0, 0, 0), t
                }
                set needsUpdate(t) {
                    !0 === t && this.version++
                }
                toJSON(t) {
                    let e = void 0 === t || "string" == typeof t;
                    if (!e && void 0 !== t.images[this.uuid]) return t.images[this.uuid];
                    let i = {
                            uuid: this.uuid,
                            url: ""
                        },
                        s = this.data;
                    if (null !== s) {
                        let t;
                        if (Array.isArray(s)) {
                            t = [];
                            for (let e = 0, i = s.length; e < i; e++) s[e].isDataTexture ? t.push(ip(s[e].image)) : t.push(ip(s[e]))
                        } else t = ip(s);
                        i.url = t
                    }
                    return e || (t.images[this.uuid] = i), i
                }
            }

            function ip(t) {
                return "u" > typeof HTMLImageElement && t instanceof HTMLImageElement || "u" > typeof HTMLCanvasElement && t instanceof HTMLCanvasElement || "u" > typeof ImageBitmap && t instanceof ImageBitmap ? il.getDataURL(t) : t.data ? {
                    data: Array.from(t.data),
                    width: t.width,
                    height: t.height,
                    type: t.data.constructor.name
                } : (eU("Texture: Unable to serialize Texture."), {})
            }
            let id = 0,
                im = new e9;
            class iy extends eZ {
                constructor(t = iy.DEFAULT_IMAGE, e = iy.DEFAULT_MAPPING, i = tg, s = tg, r = tw, n = t_, a = tj, h = tz, o = iy.DEFAULT_ANISOTROPY, l = ew) {
                    super(), this.isTexture = !0, Object.defineProperty(this, "id", {
                        value: id++
                    }), this.uuid = eK(), this.name = "", this.source = new ic(t), this.mipmaps = [], this.mapping = e, this.channel = 0, this.wrapS = i, this.wrapT = s, this.magFilter = r, this.minFilter = n, this.anisotropy = o, this.format = a, this.internalFormat = null, this.type = h, this.offset = new e6(0, 0), this.repeat = new e6(1, 1), this.center = new e6(0, 0), this.rotation = 0, this.matrixAutoUpdate = !0, this.matrix = new ie, this.generateMipmaps = !0, this.premultiplyAlpha = !1, this.flipY = !0, this.unpackAlignment = 4, this.colorSpace = l, this.userData = {}, this.updateRanges = [], this.version = 0, this.onUpdate = null, this.renderTarget = null, this.isRenderTargetTexture = !1, this.isArrayTexture = !!t && !!t.depth && t.depth > 1, this.pmremVersion = 0, this.normalized = !1
                }
                get width() {
                    return this.source.getSize(im).x
                }
                get height() {
                    return this.source.getSize(im).y
                }
                get depth() {
                    return this.source.getSize(im).z
                }
                get image() {
                    return this.source.data
                }
                set image(t) {
                    this.source.data = t
                }
                updateMatrix() {
                    this.matrix.setUvTransform(this.offset.x, this.offset.y, this.repeat.x, this.repeat.y, this.rotation, this.center.x, this.center.y)
                }
                addUpdateRange(t, e) {
                    this.updateRanges.push({
                        start: t,
                        count: e
                    })
                }
                clearUpdateRanges() {
                    this.updateRanges.length = 0
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                copy(t) {
                    return this.name = t.name, this.source = t.source, this.mipmaps = t.mipmaps.slice(0), this.mapping = t.mapping, this.channel = t.channel, this.wrapS = t.wrapS, this.wrapT = t.wrapT, this.magFilter = t.magFilter, this.minFilter = t.minFilter, this.anisotropy = t.anisotropy, this.format = t.format, this.internalFormat = t.internalFormat, this.type = t.type, this.normalized = t.normalized, this.offset.copy(t.offset), this.repeat.copy(t.repeat), this.center.copy(t.center), this.rotation = t.rotation, this.matrixAutoUpdate = t.matrixAutoUpdate, this.matrix.copy(t.matrix), this.generateMipmaps = t.generateMipmaps, this.premultiplyAlpha = t.premultiplyAlpha, this.flipY = t.flipY, this.unpackAlignment = t.unpackAlignment, this.colorSpace = t.colorSpace, this.renderTarget = t.renderTarget, this.isRenderTargetTexture = t.isRenderTargetTexture, this.isArrayTexture = t.isArrayTexture, this.userData = JSON.parse(JSON.stringify(t.userData)), this.needsUpdate = !0, this
                }
                setValues(t) {
                    for (let e in t) {
                        let i = t[e];
                        if (void 0 === i) {
                            eU(`Texture.setValues(): parameter '${e}' has value of undefined.`);
                            continue
                        }
                        let s = this[e];
                        if (void 0 === s) {
                            eU(`Texture.setValues(): property '${e}' does not exist.`);
                            continue
                        }
                        s && i && s.isVector2 && i.isVector2 || s && i && s.isVector3 && i.isVector3 || s && i && s.isMatrix3 && i.isMatrix3 ? s.copy(i) : this[e] = i
                    }
                }
                toJSON(t) {
                    let e = void 0 === t || "string" == typeof t;
                    if (!e && void 0 !== t.textures[this.uuid]) return t.textures[this.uuid];
                    let i = {
                        metadata: {
                            version: 4.7,
                            type: "Texture",
                            generator: "Texture.toJSON"
                        },
                        uuid: this.uuid,
                        name: this.name,
                        image: this.source.toJSON(t).uuid,
                        mapping: this.mapping,
                        channel: this.channel,
                        repeat: [this.repeat.x, this.repeat.y],
                        offset: [this.offset.x, this.offset.y],
                        center: [this.center.x, this.center.y],
                        rotation: this.rotation,
                        wrap: [this.wrapS, this.wrapT],
                        format: this.format,
                        internalFormat: this.internalFormat,
                        type: this.type,
                        normalized: this.normalized,
                        colorSpace: this.colorSpace,
                        minFilter: this.minFilter,
                        magFilter: this.magFilter,
                        anisotropy: this.anisotropy,
                        flipY: this.flipY,
                        generateMipmaps: this.generateMipmaps,
                        premultiplyAlpha: this.premultiplyAlpha,
                        unpackAlignment: this.unpackAlignment
                    };
                    return Object.keys(this.userData).length > 0 && (i.userData = this.userData), e || (t.textures[this.uuid] = i), i
                }
                dispose() {
                    this.dispatchEvent({
                        type: "dispose"
                    })
                }
                transformUv(t) {
                    if (300 !== this.mapping) return t;
                    if (t.applyMatrix3(this.matrix), t.x < 0 || t.x > 1) switch (this.wrapS) {
                        case tf:
                            t.x = t.x - Math.floor(t.x);
                            break;
                        case tg:
                            t.x = t.x < 0 ? 0 : 1;
                            break;
                        case tx:
                            1 === Math.abs(Math.floor(t.x) % 2) ? t.x = Math.ceil(t.x) - t.x : t.x = t.x - Math.floor(t.x)
                    }
                    if (t.y < 0 || t.y > 1) switch (this.wrapT) {
                        case tf:
                            t.y = t.y - Math.floor(t.y);
                            break;
                        case tg:
                            t.y = t.y < 0 ? 0 : 1;
                            break;
                        case tx:
                            1 === Math.abs(Math.floor(t.y) % 2) ? t.y = Math.ceil(t.y) - t.y : t.y = t.y - Math.floor(t.y)
                    }
                    return this.flipY && (t.y = 1 - t.y), t
                }
                set needsUpdate(t) {
                    !0 === t && (this.version++, this.source.needsUpdate = !0)
                }
                set needsPMREMUpdate(t) {
                    !0 === t && this.pmremVersion++
                }
            }
            iy.DEFAULT_IMAGE = null, iy.DEFAULT_MAPPING = 300, iy.DEFAULT_ANISOTROPY = 1;
            class ig {
                static {
                    ig.prototype.isVector4 = !0
                }
                constructor(t = 0, e = 0, i = 0, s = 1) {
                    this.x = t, this.y = e, this.z = i, this.w = s
                }
                get width() {
                    return this.z
                }
                set width(t) {
                    this.z = t
                }
                get height() {
                    return this.w
                }
                set height(t) {
                    this.w = t
                }
                set(t, e, i, s) {
                    return this.x = t, this.y = e, this.z = i, this.w = s, this
                }
                setScalar(t) {
                    return this.x = t, this.y = t, this.z = t, this.w = t, this
                }
                setX(t) {
                    return this.x = t, this
                }
                setY(t) {
                    return this.y = t, this
                }
                setZ(t) {
                    return this.z = t, this
                }
                setW(t) {
                    return this.w = t, this
                }
                setComponent(t, e) {
                    switch (t) {
                        case 0:
                            this.x = e;
                            break;
                        case 1:
                            this.y = e;
                            break;
                        case 2:
                            this.z = e;
                            break;
                        case 3:
                            this.w = e;
                            break;
                        default:
                            throw Error("THREE.Vector4: index is out of range: " + t)
                    }
                    return this
                }
                getComponent(t) {
                    switch (t) {
                        case 0:
                            return this.x;
                        case 1:
                            return this.y;
                        case 2:
                            return this.z;
                        case 3:
                            return this.w;
                        default:
                            throw Error("THREE.Vector4: index is out of range: " + t)
                    }
                }
                clone() {
                    return new this.constructor(this.x, this.y, this.z, this.w)
                }
                copy(t) {
                    return this.x = t.x, this.y = t.y, this.z = t.z, this.w = void 0 !== t.w ? t.w : 1, this
                }
                add(t) {
                    return this.x += t.x, this.y += t.y, this.z += t.z, this.w += t.w, this
                }
                addScalar(t) {
                    return this.x += t, this.y += t, this.z += t, this.w += t, this
                }
                addVectors(t, e) {
                    return this.x = t.x + e.x, this.y = t.y + e.y, this.z = t.z + e.z, this.w = t.w + e.w, this
                }
                addScaledVector(t, e) {
                    return this.x += t.x * e, this.y += t.y * e, this.z += t.z * e, this.w += t.w * e, this
                }
                sub(t) {
                    return this.x -= t.x, this.y -= t.y, this.z -= t.z, this.w -= t.w, this
                }
                subScalar(t) {
                    return this.x -= t, this.y -= t, this.z -= t, this.w -= t, this
                }
                subVectors(t, e) {
                    return this.x = t.x - e.x, this.y = t.y - e.y, this.z = t.z - e.z, this.w = t.w - e.w, this
                }
                multiply(t) {
                    return this.x *= t.x, this.y *= t.y, this.z *= t.z, this.w *= t.w, this
                }
                multiplyScalar(t) {
                    return this.x *= t, this.y *= t, this.z *= t, this.w *= t, this
                }
                applyMatrix4(t) {
                    let e = this.x,
                        i = this.y,
                        s = this.z,
                        r = this.w,
                        n = t.elements;
                    return this.x = n[0] * e + n[4] * i + n[8] * s + n[12] * r, this.y = n[1] * e + n[5] * i + n[9] * s + n[13] * r, this.z = n[2] * e + n[6] * i + n[10] * s + n[14] * r, this.w = n[3] * e + n[7] * i + n[11] * s + n[15] * r, this
                }
                divide(t) {
                    return this.x /= t.x, this.y /= t.y, this.z /= t.z, this.w /= t.w, this
                }
                divideScalar(t) {
                    return this.multiplyScalar(1 / t)
                }
                setAxisAngleFromQuaternion(t) {
                    this.w = 2 * Math.acos(t.w);
                    let e = Math.sqrt(1 - t.w * t.w);
                    return e < 1e-4 ? (this.x = 1, this.y = 0, this.z = 0) : (this.x = t.x / e, this.y = t.y / e, this.z = t.z / e), this
                }
                setAxisAngleFromRotationMatrix(t) {
                    let e, i, s, r, n = t.elements,
                        a = n[0],
                        h = n[4],
                        o = n[8],
                        l = n[1],
                        u = n[5],
                        c = n[9],
                        p = n[2],
                        d = n[6],
                        m = n[10];
                    if (.01 > Math.abs(h - l) && .01 > Math.abs(o - p) && .01 > Math.abs(c - d)) {
                        if (.1 > Math.abs(h + l) && .1 > Math.abs(o + p) && .1 > Math.abs(c + d) && .1 > Math.abs(a + u + m - 3)) return this.set(1, 0, 0, 0), this;
                        e = Math.PI;
                        let t = (a + 1) / 2,
                            n = (u + 1) / 2,
                            y = (m + 1) / 2,
                            f = (h + l) / 4,
                            g = (o + p) / 4,
                            x = (c + d) / 4;
                        return t > n && t > y ? t < .01 ? (i = 0, s = .707106781, r = .707106781) : (s = f / (i = Math.sqrt(t)), r = g / i) : n > y ? n < .01 ? (i = .707106781, s = 0, r = .707106781) : (i = f / (s = Math.sqrt(n)), r = x / s) : y < .01 ? (i = .707106781, s = .707106781, r = 0) : (i = g / (r = Math.sqrt(y)), s = x / r), this.set(i, s, r, e), this
                    }
                    let y = Math.sqrt((d - c) * (d - c) + (o - p) * (o - p) + (l - h) * (l - h));
                    return .001 > Math.abs(y) && (y = 1), this.x = (d - c) / y, this.y = (o - p) / y, this.z = (l - h) / y, this.w = Math.acos((a + u + m - 1) / 2), this
                }
                setFromMatrixPosition(t) {
                    let e = t.elements;
                    return this.x = e[12], this.y = e[13], this.z = e[14], this.w = e[15], this
                }
                min(t) {
                    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this.z = Math.min(this.z, t.z), this.w = Math.min(this.w, t.w), this
                }
                max(t) {
                    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this.z = Math.max(this.z, t.z), this.w = Math.max(this.w, t.w), this
                }
                clamp(t, e) {
                    return this.x = e0(this.x, t.x, e.x), this.y = e0(this.y, t.y, e.y), this.z = e0(this.z, t.z, e.z), this.w = e0(this.w, t.w, e.w), this
                }
                clampScalar(t, e) {
                    return this.x = e0(this.x, t, e), this.y = e0(this.y, t, e), this.z = e0(this.z, t, e), this.w = e0(this.w, t, e), this
                }
                clampLength(t, e) {
                    let i = this.length();
                    return this.divideScalar(i || 1).multiplyScalar(e0(i, t, e))
                }
                floor() {
                    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), this.w = Math.floor(this.w), this
                }
                ceil() {
                    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), this.w = Math.ceil(this.w), this
                }
                round() {
                    return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), this.w = Math.round(this.w), this
                }
                roundToZero() {
                    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this.z = Math.trunc(this.z), this.w = Math.trunc(this.w), this
                }
                negate() {
                    return this.x = -this.x, this.y = -this.y, this.z = -this.z, this.w = -this.w, this
                }
                dot(t) {
                    return this.x * t.x + this.y * t.y + this.z * t.z + this.w * t.w
                }
                lengthSq() {
                    return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w
                }
                length() {
                    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w)
                }
                manhattanLength() {
                    return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w)
                }
                normalize() {
                    return this.divideScalar(this.length() || 1)
                }
                setLength(t) {
                    return this.normalize().multiplyScalar(t)
                }
                lerp(t, e) {
                    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this.z += (t.z - this.z) * e, this.w += (t.w - this.w) * e, this
                }
                lerpVectors(t, e, i) {
                    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this.z = t.z + (e.z - t.z) * i, this.w = t.w + (e.w - t.w) * i, this
                }
                equals(t) {
                    return t.x === this.x && t.y === this.y && t.z === this.z && t.w === this.w
                }
                fromArray(t, e = 0) {
                    return this.x = t[e], this.y = t[e + 1], this.z = t[e + 2], this.w = t[e + 3], this
                }
                toArray(t = [], e = 0) {
                    return t[e] = this.x, t[e + 1] = this.y, t[e + 2] = this.z, t[e + 3] = this.w, t
                }
                fromBufferAttribute(t, e) {
                    return this.x = t.getX(e), this.y = t.getY(e), this.z = t.getZ(e), this.w = t.getW(e), this
                }
                random() {
                    return this.x = Math.random(), this.y = Math.random(), this.z = Math.random(), this.w = Math.random(), this
                }*[Symbol.iterator]() {
                    yield this.x, yield this.y, yield this.z, yield this.w
                }
            }
            class ix extends eZ {
                constructor(t = 1, e = 1, i = {}) {
                    super(), i = Object.assign({
                        generateMipmaps: !1,
                        internalFormat: null,
                        minFilter: tw,
                        depthBuffer: !0,
                        stencilBuffer: !1,
                        resolveColorBuffer: !0,
                        resolveDepthBuffer: !0,
                        resolveStencilBuffer: !0,
                        storeMultisampledColorBuffer: !0,
                        storeMultisampledDepthBuffer: !0,
                        storeMultisampledStencilBuffer: !0,
                        depthTexture: null,
                        samples: 0,
                        count: 1,
                        depth: 1,
                        multiview: !1,
                        useArrayDepthTexture: !1
                    }, i), this.isRenderTarget = !0, this.width = t, this.height = e, this.depth = i.depth, this.scissor = new ig(0, 0, t, e), this.scissorTest = !1, this.viewport = new ig(0, 0, t, e), this.textures = [];
                    const s = new iy({
                            width: t,
                            height: e,
                            depth: i.depth
                        }),
                        r = i.count;
                    for (let t = 0; t < r; t++) this.textures[t] = s.clone(), this.textures[t].isRenderTargetTexture = !0, this.textures[t].renderTarget = this;
                    this._setTextureOptions(i), this.depthBuffer = i.depthBuffer, this.stencilBuffer = i.stencilBuffer, this.resolveColorBuffer = i.resolveColorBuffer, this.resolveDepthBuffer = i.resolveDepthBuffer, this.resolveStencilBuffer = i.resolveStencilBuffer, this.storeMultisampledColorBuffer = i.storeMultisampledColorBuffer, this.storeMultisampledDepthBuffer = i.storeMultisampledDepthBuffer, this.storeMultisampledStencilBuffer = i.storeMultisampledStencilBuffer, this._depthTexture = null, this.depthTexture = i.depthTexture, this.samples = i.samples, this.multiview = i.multiview, this.useArrayDepthTexture = i.useArrayDepthTexture
                }
                _setTextureOptions(t = {}) {
                    let e = {
                        minFilter: tw,
                        generateMipmaps: !1,
                        flipY: !1,
                        internalFormat: null
                    };
                    void 0 !== t.mapping && (e.mapping = t.mapping), void 0 !== t.wrapS && (e.wrapS = t.wrapS), void 0 !== t.wrapT && (e.wrapT = t.wrapT), void 0 !== t.wrapR && (e.wrapR = t.wrapR), void 0 !== t.magFilter && (e.magFilter = t.magFilter), void 0 !== t.minFilter && (e.minFilter = t.minFilter), void 0 !== t.format && (e.format = t.format), void 0 !== t.type && (e.type = t.type), void 0 !== t.anisotropy && (e.anisotropy = t.anisotropy), void 0 !== t.colorSpace && (e.colorSpace = t.colorSpace), void 0 !== t.flipY && (e.flipY = t.flipY), void 0 !== t.generateMipmaps && (e.generateMipmaps = t.generateMipmaps), void 0 !== t.internalFormat && (e.internalFormat = t.internalFormat);
                    for (let t = 0; t < this.textures.length; t++) this.textures[t].setValues(e)
                }
                get texture() {
                    return this.textures[0]
                }
                set texture(t) {
                    this.textures[0] = t
                }
                set depthTexture(t) {
                    null !== this._depthTexture && this._depthTexture.renderTarget === this && (this._depthTexture.renderTarget = null), null !== t && null === t.renderTarget && (t.renderTarget = this), this._depthTexture = t
                }
                get depthTexture() {
                    return this._depthTexture
                }
                setSize(t, e, i = 1) {
                    if (this.width !== t || this.height !== e || this.depth !== i) {
                        this.width = t, this.height = e, this.depth = i;
                        for (let s = 0, r = this.textures.length; s < r; s++) this.textures[s].image.width = t, this.textures[s].image.height = e, this.textures[s].image.depth = i, !0 !== this.textures[s].isData3DTexture && (this.textures[s].isArrayTexture = this.textures[s].image.depth > 1);
                        this.dispose()
                    }
                    this.viewport.set(0, 0, t, e), this.scissor.set(0, 0, t, e)
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                copy(t) {
                    this.width = t.width, this.height = t.height, this.depth = t.depth, this.scissor.copy(t.scissor), this.scissorTest = t.scissorTest, this.viewport.copy(t.viewport), this.textures.length = 0;
                    for (let e = 0, i = t.textures.length; e < i; e++) {
                        this.textures[e] = t.textures[e].clone(), this.textures[e].isRenderTargetTexture = !0, this.textures[e].renderTarget = this;
                        let i = Object.assign({}, t.textures[e].image);
                        this.textures[e].source = new ic(i)
                    }
                    if (this.depthBuffer = t.depthBuffer, this.stencilBuffer = t.stencilBuffer, this.resolveColorBuffer = t.resolveColorBuffer, this.resolveDepthBuffer = t.resolveDepthBuffer, this.resolveStencilBuffer = t.resolveStencilBuffer, this.storeMultisampledColorBuffer = t.storeMultisampledColorBuffer, this.storeMultisampledDepthBuffer = t.storeMultisampledDepthBuffer, this.storeMultisampledStencilBuffer = t.storeMultisampledStencilBuffer, null !== t.depthTexture)
                        if (t.depthTexture.renderTarget === t) {
                            let e = t.depthTexture.clone();
                            e.renderTarget = null, this.depthTexture = e
                        } else this.depthTexture = t.depthTexture;
                    return this.samples = t.samples, this.multiview = t.multiview, this.useArrayDepthTexture = t.useArrayDepthTexture, this
                }
                dispose() {
                    this.dispatchEvent({
                        type: "dispose"
                    })
                }
            }
            class iv extends ix {
                constructor(t = 1, e = 1, i = {}) {
                    super(t, e, i), this.isWebGLRenderTarget = !0
                }
            }
            class iM extends iy {
                constructor(t = null, e = 1, i = 1, s = 1) {
                    super(null), this.isDataArrayTexture = !0, this.image = {
                        data: t,
                        width: e,
                        height: i,
                        depth: s
                    }, this.magFilter = tv, this.minFilter = tv, this.wrapR = tg, this.generateMipmaps = !1, this.flipY = !1, this.unpackAlignment = 1, this.layerUpdates = new Set
                }
                copy(t) {
                    return super.copy(t), this.wrapR = t.wrapR, this
                }
                addLayerUpdate(t) {
                    this.layerUpdates.add(t)
                }
                clearLayerUpdates() {
                    this.layerUpdates.clear()
                }
            }
            class ib extends iy {
                constructor(t = null, e = 1, i = 1, s = 1) {
                    super(null), this.isData3DTexture = !0, this.image = {
                        data: t,
                        width: e,
                        height: i,
                        depth: s
                    }, this.magFilter = tv, this.minFilter = tv, this.wrapR = tg, this.generateMipmaps = !1, this.flipY = !1, this.unpackAlignment = 1
                }
                copy(t) {
                    return super.copy(t), this.wrapR = t.wrapR, this
                }
            }
            class iw {
                static {
                    iw.prototype.isMatrix4 = !0
                }
                constructor(t, e, i, s, r, n, a, h, o, l, u, c, p, d, m, y) {
                    this.elements = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1], void 0 !== t && this.set(t, e, i, s, r, n, a, h, o, l, u, c, p, d, m, y)
                }
                set(t, e, i, s, r, n, a, h, o, l, u, c, p, d, m, y) {
                    let f = this.elements;
                    return f[0] = t, f[4] = e, f[8] = i, f[12] = s, f[1] = r, f[5] = n, f[9] = a, f[13] = h, f[2] = o, f[6] = l, f[10] = u, f[14] = c, f[3] = p, f[7] = d, f[11] = m, f[15] = y, this
                }
                identity() {
                    return this.set(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this
                }
                clone() {
                    return new iw().fromArray(this.elements)
                }
                copy(t) {
                    let e = this.elements,
                        i = t.elements;
                    return e[0] = i[0], e[1] = i[1], e[2] = i[2], e[3] = i[3], e[4] = i[4], e[5] = i[5], e[6] = i[6], e[7] = i[7], e[8] = i[8], e[9] = i[9], e[10] = i[10], e[11] = i[11], e[12] = i[12], e[13] = i[13], e[14] = i[14], e[15] = i[15], this
                }
                copyPosition(t) {
                    let e = this.elements,
                        i = t.elements;
                    return e[12] = i[12], e[13] = i[13], e[14] = i[14], this
                }
                setFromMatrix3(t) {
                    let e = t.elements;
                    return this.set(e[0], e[3], e[6], 0, e[1], e[4], e[7], 0, e[2], e[5], e[8], 0, 0, 0, 0, 1), this
                }
                extractBasis(t, e, i) {
                    return 0 === this.determinantAffine() ? (t.set(1, 0, 0), e.set(0, 1, 0), i.set(0, 0, 1)) : (t.setFromMatrixColumn(this, 0), e.setFromMatrixColumn(this, 1), i.setFromMatrixColumn(this, 2)), this
                }
                makeBasis(t, e, i) {
                    return this.set(t.x, e.x, i.x, 0, t.y, e.y, i.y, 0, t.z, e.z, i.z, 0, 0, 0, 0, 1), this
                }
                extractRotation(t) {
                    if (0 === t.determinantAffine()) return this.identity();
                    let e = this.elements,
                        i = t.elements,
                        s = 1 / iS.setFromMatrixColumn(t, 0).length(),
                        r = 1 / iS.setFromMatrixColumn(t, 1).length(),
                        n = 1 / iS.setFromMatrixColumn(t, 2).length();
                    return e[0] = i[0] * s, e[1] = i[1] * s, e[2] = i[2] * s, e[3] = 0, e[4] = i[4] * r, e[5] = i[5] * r, e[6] = i[6] * r, e[7] = 0, e[8] = i[8] * n, e[9] = i[9] * n, e[10] = i[10] * n, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, this
                }
                makeRotationFromEuler(t) {
                    let e = this.elements,
                        i = t.x,
                        s = t.y,
                        r = t.z,
                        n = Math.cos(i),
                        a = Math.sin(i),
                        h = Math.cos(s),
                        o = Math.sin(s),
                        l = Math.cos(r),
                        u = Math.sin(r);
                    if ("XYZ" === t.order) {
                        let t = n * l,
                            i = n * u,
                            s = a * l,
                            r = a * u;
                        e[0] = h * l, e[4] = -h * u, e[8] = o, e[1] = i + s * o, e[5] = t - r * o, e[9] = -a * h, e[2] = r - t * o, e[6] = s + i * o, e[10] = n * h
                    } else if ("YXZ" === t.order) {
                        let t = h * l,
                            i = h * u,
                            s = o * l,
                            r = o * u;
                        e[0] = t + r * a, e[4] = s * a - i, e[8] = n * o, e[1] = n * u, e[5] = n * l, e[9] = -a, e[2] = i * a - s, e[6] = r + t * a, e[10] = n * h
                    } else if ("ZXY" === t.order) {
                        let t = h * l,
                            i = h * u,
                            s = o * l,
                            r = o * u;
                        e[0] = t - r * a, e[4] = -n * u, e[8] = s + i * a, e[1] = i + s * a, e[5] = n * l, e[9] = r - t * a, e[2] = -n * o, e[6] = a, e[10] = n * h
                    } else if ("ZYX" === t.order) {
                        let t = n * l,
                            i = n * u,
                            s = a * l,
                            r = a * u;
                        e[0] = h * l, e[4] = s * o - i, e[8] = t * o + r, e[1] = h * u, e[5] = r * o + t, e[9] = i * o - s, e[2] = -o, e[6] = a * h, e[10] = n * h
                    } else if ("YZX" === t.order) {
                        let t = n * h,
                            i = n * o,
                            s = a * h,
                            r = a * o;
                        e[0] = h * l, e[4] = r - t * u, e[8] = s * u + i, e[1] = u, e[5] = n * l, e[9] = -a * l, e[2] = -o * l, e[6] = i * u + s, e[10] = t - r * u
                    } else if ("XZY" === t.order) {
                        let t = n * h,
                            i = n * o,
                            s = a * h,
                            r = a * o;
                        e[0] = h * l, e[4] = -u, e[8] = o * l, e[1] = t * u + r, e[5] = n * l, e[9] = i * u - s, e[2] = s * u - i, e[6] = a * l, e[10] = r * u + t
                    }
                    return e[3] = 0, e[7] = 0, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, this
                }
                makeRotationFromQuaternion(t) {
                    return this.compose(iz, t, iA)
                }
                lookAt(t, e, i) {
                    let s = this.elements;
                    return ik.subVectors(t, e), 0 === ik.lengthSq() && (ik.z = 1), ik.normalize(), iT.crossVectors(i, ik), 0 === iT.lengthSq() && (1 === Math.abs(i.z) ? ik.x += 1e-4 : ik.z += 1e-4, ik.normalize(), iT.crossVectors(i, ik)), iT.normalize(), iC.crossVectors(ik, iT), s[0] = iT.x, s[4] = iC.x, s[8] = ik.x, s[1] = iT.y, s[5] = iC.y, s[9] = ik.y, s[2] = iT.z, s[6] = iC.z, s[10] = ik.z, this
                }
                multiply(t) {
                    return this.multiplyMatrices(this, t)
                }
                premultiply(t) {
                    return this.multiplyMatrices(t, this)
                }
                multiplyMatrices(t, e) {
                    let i = t.elements,
                        s = e.elements,
                        r = this.elements,
                        n = i[0],
                        a = i[4],
                        h = i[8],
                        o = i[12],
                        l = i[1],
                        u = i[5],
                        c = i[9],
                        p = i[13],
                        d = i[2],
                        m = i[6],
                        y = i[10],
                        f = i[14],
                        g = i[3],
                        x = i[7],
                        v = i[11],
                        M = i[15],
                        b = s[0],
                        w = s[4],
                        S = s[8],
                        _ = s[12],
                        z = s[1],
                        A = s[5],
                        T = s[9],
                        C = s[13],
                        k = s[2],
                        B = s[6],
                        O = s[10],
                        I = s[14],
                        N = s[3],
                        P = s[7],
                        R = s[11],
                        V = s[15];
                    return r[0] = n * b + a * z + h * k + o * N, r[4] = n * w + a * A + h * B + o * P, r[8] = n * S + a * T + h * O + o * R, r[12] = n * _ + a * C + h * I + o * V, r[1] = l * b + u * z + c * k + p * N, r[5] = l * w + u * A + c * B + p * P, r[9] = l * S + u * T + c * O + p * R, r[13] = l * _ + u * C + c * I + p * V, r[2] = d * b + m * z + y * k + f * N, r[6] = d * w + m * A + y * B + f * P, r[10] = d * S + m * T + y * O + f * R, r[14] = d * _ + m * C + y * I + f * V, r[3] = g * b + x * z + v * k + M * N, r[7] = g * w + x * A + v * B + M * P, r[11] = g * S + x * T + v * O + M * R, r[15] = g * _ + x * C + v * I + M * V, this
                }
                multiplyScalar(t) {
                    let e = this.elements;
                    return e[0] *= t, e[4] *= t, e[8] *= t, e[12] *= t, e[1] *= t, e[5] *= t, e[9] *= t, e[13] *= t, e[2] *= t, e[6] *= t, e[10] *= t, e[14] *= t, e[3] *= t, e[7] *= t, e[11] *= t, e[15] *= t, this
                }
                determinant() {
                    let t = this.elements,
                        e = t[0],
                        i = t[4],
                        s = t[8],
                        r = t[12],
                        n = t[1],
                        a = t[5],
                        h = t[9],
                        o = t[13],
                        l = t[2],
                        u = t[6],
                        c = t[10],
                        p = t[14],
                        d = t[3],
                        m = t[7],
                        y = t[11],
                        f = t[15],
                        g = h * p - o * c,
                        x = a * p - o * u,
                        v = a * c - h * u,
                        M = n * p - o * l,
                        b = n * c - h * l,
                        w = n * u - a * l;
                    return e * (m * g - y * x + f * v) - i * (d * g - y * M + f * b) + s * (d * x - m * M + f * w) - r * (d * v - m * b + y * w)
                }
                determinantAffine() {
                    let t = this.elements,
                        e = t[0],
                        i = t[4],
                        s = t[8],
                        r = t[1],
                        n = t[5],
                        a = t[9],
                        h = t[2],
                        o = t[6],
                        l = t[10];
                    return e * (n * l - a * o) - i * (r * l - a * h) + s * (r * o - n * h)
                }
                transpose() {
                    let t, e = this.elements;
                    return t = e[1], e[1] = e[4], e[4] = t, t = e[2], e[2] = e[8], e[8] = t, t = e[6], e[6] = e[9], e[9] = t, t = e[3], e[3] = e[12], e[12] = t, t = e[7], e[7] = e[13], e[13] = t, t = e[11], e[11] = e[14], e[14] = t, this
                }
                setPosition(t, e, i) {
                    let s = this.elements;
                    return t.isVector3 ? (s[12] = t.x, s[13] = t.y, s[14] = t.z) : (s[12] = t, s[13] = e, s[14] = i), this
                }
                invert() {
                    let t = this.elements,
                        e = t[0],
                        i = t[1],
                        s = t[2],
                        r = t[3],
                        n = t[4],
                        a = t[5],
                        h = t[6],
                        o = t[7],
                        l = t[8],
                        u = t[9],
                        c = t[10],
                        p = t[11],
                        d = t[12],
                        m = t[13],
                        y = t[14],
                        f = t[15],
                        g = e * a - i * n,
                        x = e * h - s * n,
                        v = e * o - r * n,
                        M = i * h - s * a,
                        b = i * o - r * a,
                        w = s * o - r * h,
                        S = l * m - u * d,
                        _ = l * y - c * d,
                        z = l * f - p * d,
                        A = u * y - c * m,
                        T = u * f - p * m,
                        C = c * f - p * y,
                        k = g * C - x * T + v * A + M * z - b * _ + w * S;
                    if (0 === k) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                    let B = 1 / k;
                    return t[0] = (a * C - h * T + o * A) * B, t[1] = (s * T - i * C - r * A) * B, t[2] = (m * w - y * b + f * M) * B, t[3] = (c * b - u * w - p * M) * B, t[4] = (h * z - n * C - o * _) * B, t[5] = (e * C - s * z + r * _) * B, t[6] = (y * v - d * w - f * x) * B, t[7] = (l * w - c * v + p * x) * B, t[8] = (n * T - a * z + o * S) * B, t[9] = (i * z - e * T - r * S) * B, t[10] = (d * b - m * v + f * g) * B, t[11] = (u * v - l * b - p * g) * B, t[12] = (a * _ - n * A - h * S) * B, t[13] = (e * A - i * _ + s * S) * B, t[14] = (m * x - d * M - y * g) * B, t[15] = (l * M - u * x + c * g) * B, this
                }
                scale(t) {
                    let e = this.elements,
                        i = t.x,
                        s = t.y,
                        r = t.z;
                    return e[0] *= i, e[4] *= s, e[8] *= r, e[1] *= i, e[5] *= s, e[9] *= r, e[2] *= i, e[6] *= s, e[10] *= r, e[3] *= i, e[7] *= s, e[11] *= r, this
                }
                getMaxScaleOnAxis() {
                    let t = this.elements;
                    return Math.sqrt(Math.max(t[0] * t[0] + t[1] * t[1] + t[2] * t[2], t[4] * t[4] + t[5] * t[5] + t[6] * t[6], t[8] * t[8] + t[9] * t[9] + t[10] * t[10]))
                }
                makeTranslation(t, e, i) {
                    return t.isVector3 ? this.set(1, 0, 0, t.x, 0, 1, 0, t.y, 0, 0, 1, t.z, 0, 0, 0, 1) : this.set(1, 0, 0, t, 0, 1, 0, e, 0, 0, 1, i, 0, 0, 0, 1), this
                }
                makeRotationX(t) {
                    let e = Math.cos(t),
                        i = Math.sin(t);
                    return this.set(1, 0, 0, 0, 0, e, -i, 0, 0, i, e, 0, 0, 0, 0, 1), this
                }
                makeRotationY(t) {
                    let e = Math.cos(t),
                        i = Math.sin(t);
                    return this.set(e, 0, i, 0, 0, 1, 0, 0, -i, 0, e, 0, 0, 0, 0, 1), this
                }
                makeRotationZ(t) {
                    let e = Math.cos(t),
                        i = Math.sin(t);
                    return this.set(e, -i, 0, 0, i, e, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this
                }
                makeRotationAxis(t, e) {
                    let i = Math.cos(e),
                        s = Math.sin(e),
                        r = 1 - i,
                        n = t.x,
                        a = t.y,
                        h = t.z,
                        o = r * n,
                        l = r * a;
                    return this.set(o * n + i, o * a - s * h, o * h + s * a, 0, o * a + s * h, l * a + i, l * h - s * n, 0, o * h - s * a, l * h + s * n, r * h * h + i, 0, 0, 0, 0, 1), this
                }
                makeScale(t, e, i) {
                    return this.set(t, 0, 0, 0, 0, e, 0, 0, 0, 0, i, 0, 0, 0, 0, 1), this
                }
                makeShear(t, e, i, s, r, n) {
                    return this.set(1, i, r, 0, t, 1, n, 0, e, s, 1, 0, 0, 0, 0, 1), this
                }
                compose(t, e, i) {
                    let s = this.elements,
                        r = e._x,
                        n = e._y,
                        a = e._z,
                        h = e._w,
                        o = r + r,
                        l = n + n,
                        u = a + a,
                        c = r * o,
                        p = r * l,
                        d = r * u,
                        m = n * l,
                        y = n * u,
                        f = a * u,
                        g = h * o,
                        x = h * l,
                        v = h * u,
                        M = i.x,
                        b = i.y,
                        w = i.z;
                    return s[0] = (1 - (m + f)) * M, s[1] = (p + v) * M, s[2] = (d - x) * M, s[3] = 0, s[4] = (p - v) * b, s[5] = (1 - (c + f)) * b, s[6] = (y + g) * b, s[7] = 0, s[8] = (d + x) * w, s[9] = (y - g) * w, s[10] = (1 - (c + m)) * w, s[11] = 0, s[12] = t.x, s[13] = t.y, s[14] = t.z, s[15] = 1, this
                }
                decompose(t, e, i) {
                    let s = this.elements;
                    t.x = s[12], t.y = s[13], t.z = s[14];
                    let r = this.determinantAffine();
                    if (0 === r) return i.set(1, 1, 1), e.identity(), this;
                    let n = iS.set(s[0], s[1], s[2]).length(),
                        a = iS.set(s[4], s[5], s[6]).length(),
                        h = iS.set(s[8], s[9], s[10]).length();
                    r < 0 && (n = -n), i_.copy(this);
                    let o = 1 / n,
                        l = 1 / a,
                        u = 1 / h;
                    return i_.elements[0] *= o, i_.elements[1] *= o, i_.elements[2] *= o, i_.elements[4] *= l, i_.elements[5] *= l, i_.elements[6] *= l, i_.elements[8] *= u, i_.elements[9] *= u, i_.elements[10] *= u, e.setFromRotationMatrix(i_), i.x = n, i.y = a, i.z = h, this
                }
                makePerspective(t, e, i, s, r, n, a = eE, h = !1) {
                    let o, l, u = this.elements;
                    if (h) o = r / (n - r), l = n * r / (n - r);
                    else if (a === eE) o = -(n + r) / (n - r), l = -2 * n * r / (n - r);
                    else if (2001 === a) o = -n / (n - r), l = -n * r / (n - r);
                    else throw Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: " + a);
                    return u[0] = 2 * r / (e - t), u[4] = 0, u[8] = (e + t) / (e - t), u[12] = 0, u[1] = 0, u[5] = 2 * r / (i - s), u[9] = (i + s) / (i - s), u[13] = 0, u[2] = 0, u[6] = 0, u[10] = o, u[14] = l, u[3] = 0, u[7] = 0, u[11] = -1, u[15] = 0, this
                }
                makeOrthographic(t, e, i, s, r, n, a = eE, h = !1) {
                    let o, l, u = this.elements;
                    if (h) o = 1 / (n - r), l = n / (n - r);
                    else if (a === eE) o = -2 / (n - r), l = -(n + r) / (n - r);
                    else if (2001 === a) o = -1 / (n - r), l = -r / (n - r);
                    else throw Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: " + a);
                    return u[0] = 2 / (e - t), u[4] = 0, u[8] = 0, u[12] = -(e + t) / (e - t), u[1] = 0, u[5] = 2 / (i - s), u[9] = 0, u[13] = -(i + s) / (i - s), u[2] = 0, u[6] = 0, u[10] = o, u[14] = l, u[3] = 0, u[7] = 0, u[11] = 0, u[15] = 1, this
                }
                equals(t) {
                    let e = this.elements,
                        i = t.elements;
                    for (let t = 0; t < 16; t++)
                        if (e[t] !== i[t]) return !1;
                    return !0
                }
                fromArray(t, e = 0) {
                    for (let i = 0; i < 16; i++) this.elements[i] = t[i + e];
                    return this
                }
                toArray(t = [], e = 0) {
                    let i = this.elements;
                    return t[e] = i[0], t[e + 1] = i[1], t[e + 2] = i[2], t[e + 3] = i[3], t[e + 4] = i[4], t[e + 5] = i[5], t[e + 6] = i[6], t[e + 7] = i[7], t[e + 8] = i[8], t[e + 9] = i[9], t[e + 10] = i[10], t[e + 11] = i[11], t[e + 12] = i[12], t[e + 13] = i[13], t[e + 14] = i[14], t[e + 15] = i[15], t
                }
            }
            let iS = new e9,
                i_ = new iw,
                iz = new e9(0, 0, 0),
                iA = new e9(1, 1, 1),
                iT = new e9,
                iC = new e9,
                ik = new e9,
                iB = new iw,
                iO = new e8;
            class iI {
                constructor(t = 0, e = 0, i = 0, s = iI.DEFAULT_ORDER) {
                    this.isEuler = !0, this._x = t, this._y = e, this._z = i, this._order = s
                }
                get x() {
                    return this._x
                }
                set x(t) {
                    this._x = t, this._onChangeCallback()
                }
                get y() {
                    return this._y
                }
                set y(t) {
                    this._y = t, this._onChangeCallback()
                }
                get z() {
                    return this._z
                }
                set z(t) {
                    this._z = t, this._onChangeCallback()
                }
                get order() {
                    return this._order
                }
                set order(t) {
                    this._order = t, this._onChangeCallback()
                }
                set(t, e, i, s = this._order) {
                    return this._x = t, this._y = e, this._z = i, this._order = s, this._onChangeCallback(), this
                }
                clone() {
                    return new this.constructor(this._x, this._y, this._z, this._order)
                }
                copy(t) {
                    return this._x = t._x, this._y = t._y, this._z = t._z, this._order = t._order, this._onChangeCallback(), this
                }
                setFromRotationMatrix(t, e = this._order, i = !0) {
                    let s = t.elements,
                        r = s[0],
                        n = s[4],
                        a = s[8],
                        h = s[1],
                        o = s[5],
                        l = s[9],
                        u = s[2],
                        c = s[6],
                        p = s[10];
                    switch (e) {
                        case "XYZ":
                            this._y = Math.asin(e0(a, -1, 1)), .9999999 > Math.abs(a) ? (this._x = Math.atan2(-l, p), this._z = Math.atan2(-n, r)) : (this._x = Math.atan2(c, o), this._z = 0);
                            break;
                        case "YXZ":
                            this._x = Math.asin(-e0(l, -1, 1)), .9999999 > Math.abs(l) ? (this._y = Math.atan2(a, p), this._z = Math.atan2(h, o)) : (this._y = Math.atan2(-u, r), this._z = 0);
                            break;
                        case "ZXY":
                            this._x = Math.asin(e0(c, -1, 1)), .9999999 > Math.abs(c) ? (this._y = Math.atan2(-u, p), this._z = Math.atan2(-n, o)) : (this._y = 0, this._z = Math.atan2(h, r));
                            break;
                        case "ZYX":
                            this._y = Math.asin(-e0(u, -1, 1)), .9999999 > Math.abs(u) ? (this._x = Math.atan2(c, p), this._z = Math.atan2(h, r)) : (this._x = 0, this._z = Math.atan2(-n, o));
                            break;
                        case "YZX":
                            this._z = Math.asin(e0(h, -1, 1)), .9999999 > Math.abs(h) ? (this._x = Math.atan2(-l, o), this._y = Math.atan2(-u, r)) : (this._x = 0, this._y = Math.atan2(a, p));
                            break;
                        case "XZY":
                            this._z = Math.asin(-e0(n, -1, 1)), .9999999 > Math.abs(n) ? (this._x = Math.atan2(c, o), this._y = Math.atan2(a, r)) : (this._x = Math.atan2(-l, p), this._y = 0);
                            break;
                        default:
                            eU("Euler: .setFromRotationMatrix() encountered an unknown order: " + e)
                    }
                    return this._order = e, !0 === i && this._onChangeCallback(), this
                }
                setFromQuaternion(t, e, i) {
                    return iB.makeRotationFromQuaternion(t), this.setFromRotationMatrix(iB, e, i)
                }
                setFromVector3(t, e = this._order) {
                    return this.set(t.x, t.y, t.z, e)
                }
                reorder(t) {
                    return iO.setFromEuler(this), this.setFromQuaternion(iO, t)
                }
                equals(t) {
                    return t._x === this._x && t._y === this._y && t._z === this._z && t._order === this._order
                }
                fromArray(t) {
                    return this._x = t[0], this._y = t[1], this._z = t[2], void 0 !== t[3] && (this._order = t[3]), this._onChangeCallback(), this
                }
                toArray(t = [], e = 0) {
                    return t[e] = this._x, t[e + 1] = this._y, t[e + 2] = this._z, t[e + 3] = this._order, t
                }
                _onChange(t) {
                    return this._onChangeCallback = t, this
                }
                _onChangeCallback() {}*[Symbol.iterator]() {
                    yield this._x, yield this._y, yield this._z, yield this._order
                }
            }
            iI.DEFAULT_ORDER = "XYZ";
            class iN {
                constructor() {
                    this.mask = 1
                }
                set(t) {
                    this.mask = 1 << t >>> 0
                }
                enable(t) {
                    this.mask |= 1 << t
                }
                enableAll() {
                    this.mask = -1
                }
                toggle(t) {
                    this.mask ^= 1 << t
                }
                disable(t) {
                    this.mask &= ~(1 << t)
                }
                disableAll() {
                    this.mask = 0
                }
                test(t) {
                    return (this.mask & t.mask) != 0
                }
                isEnabled(t) {
                    return (this.mask & 1 << t) != 0
                }
            }
            let iP = 0,
                iR = new e9,
                iV = new e8,
                iE = new iw,
                iF = new e9,
                iL = new e9,
                ij = new e9,
                iD = new e8,
                iW = new e9(1, 0, 0),
                iU = new e9(0, 1, 0),
                iJ = new e9(0, 0, 1),
                iq = {
                    type: "added"
                },
                iH = {
                    type: "removed"
                },
                iX = {
                    type: "childadded",
                    child: null
                },
                iZ = {
                    type: "childremoved",
                    child: null
                };
            class iY extends eZ {
                constructor() {
                    super(), this.isObject3D = !0, Object.defineProperty(this, "id", {
                        value: iP++
                    }), this.uuid = eK(), this.name = "", this.type = "Object3D", this.parent = null, this.children = [], this.up = iY.DEFAULT_UP.clone();
                    const t = new e9,
                        e = new iI,
                        i = new e8,
                        s = new e9(1, 1, 1);
                    e._onChange(function() {
                        i.setFromEuler(e, !1)
                    }), i._onChange(function() {
                        e.setFromQuaternion(i, void 0, !1)
                    }), Object.defineProperties(this, {
                        position: {
                            configurable: !0,
                            enumerable: !0,
                            value: t
                        },
                        rotation: {
                            configurable: !0,
                            enumerable: !0,
                            value: e
                        },
                        quaternion: {
                            configurable: !0,
                            enumerable: !0,
                            value: i
                        },
                        scale: {
                            configurable: !0,
                            enumerable: !0,
                            value: s
                        },
                        modelViewMatrix: {
                            value: new iw
                        },
                        normalMatrix: {
                            value: new ie
                        }
                    }), this.matrix = new iw, this.matrixWorld = new iw, this.matrixAutoUpdate = iY.DEFAULT_MATRIX_AUTO_UPDATE, this.matrixWorldAutoUpdate = iY.DEFAULT_MATRIX_WORLD_AUTO_UPDATE, this.matrixWorldNeedsUpdate = !1, this.layers = new iN, this.visible = !0, this.castShadow = !1, this.receiveShadow = !1, this.frustumCulled = !0, this.renderOrder = 0, this.animations = [], this.customDepthMaterial = void 0, this.customDistanceMaterial = void 0, this.static = !1, this.userData = {}, this.pivot = null
                }
                onBeforeShadow() {}
                onAfterShadow() {}
                onBeforeRender() {}
                onAfterRender() {}
                applyMatrix4(t) {
                    this.matrixAutoUpdate && this.updateMatrix(), this.matrix.premultiply(t), this.matrix.decompose(this.position, this.quaternion, this.scale)
                }
                applyQuaternion(t) {
                    return this.quaternion.premultiply(t), this
                }
                setRotationFromAxisAngle(t, e) {
                    this.quaternion.setFromAxisAngle(t, e)
                }
                setRotationFromEuler(t) {
                    this.quaternion.setFromEuler(t, !0)
                }
                setRotationFromMatrix(t) {
                    this.quaternion.setFromRotationMatrix(t)
                }
                setRotationFromQuaternion(t) {
                    this.quaternion.copy(t)
                }
                rotateOnAxis(t, e) {
                    return iV.setFromAxisAngle(t, e), this.quaternion.multiply(iV), this
                }
                rotateOnWorldAxis(t, e) {
                    return iV.setFromAxisAngle(t, e), this.quaternion.premultiply(iV), this
                }
                rotateX(t) {
                    return this.rotateOnAxis(iW, t)
                }
                rotateY(t) {
                    return this.rotateOnAxis(iU, t)
                }
                rotateZ(t) {
                    return this.rotateOnAxis(iJ, t)
                }
                translateOnAxis(t, e) {
                    return iR.copy(t).applyQuaternion(this.quaternion), this.position.add(iR.multiplyScalar(e)), this
                }
                translateX(t) {
                    return this.translateOnAxis(iW, t)
                }
                translateY(t) {
                    return this.translateOnAxis(iU, t)
                }
                translateZ(t) {
                    return this.translateOnAxis(iJ, t)
                }
                localToWorld(t) {
                    return this.updateWorldMatrix(!0, !1), t.applyMatrix4(this.matrixWorld)
                }
                worldToLocal(t) {
                    return this.updateWorldMatrix(!0, !1), t.applyMatrix4(iE.copy(this.matrixWorld).invert())
                }
                lookAt(t, e, i) {
                    t.isVector3 ? iF.copy(t) : iF.set(t, e, i);
                    let s = this.parent;
                    this.updateWorldMatrix(!0, !1), iL.setFromMatrixPosition(this.matrixWorld), this.isCamera || this.isLight ? iE.lookAt(iL, iF, this.up) : iE.lookAt(iF, iL, this.up), this.quaternion.setFromRotationMatrix(iE), s && (iE.extractRotation(s.matrixWorld), iV.setFromRotationMatrix(iE), this.quaternion.premultiply(iV.invert()))
                }
                add(t) {
                    if (arguments.length > 1) {
                        for (let t = 0; t < arguments.length; t++) this.add(arguments[t]);
                        return this
                    }
                    return t === this ? eJ("Object3D.add: object can't be added as a child of itself.", t) : t && t.isObject3D ? (t.removeFromParent(), t.parent = this, this.children.push(t), t.dispatchEvent(iq), iX.child = t, this.dispatchEvent(iX), iX.child = null) : eJ("Object3D.add: object not an instance of THREE.Object3D.", t), this
                }
                remove(t) {
                    if (arguments.length > 1) {
                        for (let t = 0; t < arguments.length; t++) this.remove(arguments[t]);
                        return this
                    }
                    let e = this.children.indexOf(t);
                    return -1 !== e && (t.parent = null, this.children.splice(e, 1), t.dispatchEvent(iH), iZ.child = t, this.dispatchEvent(iZ), iZ.child = null), this
                }
                removeFromParent() {
                    let t = this.parent;
                    return null !== t && t.remove(this), this
                }
                clear() {
                    return this.remove(...this.children)
                }
                attach(t) {
                    return this.updateWorldMatrix(!0, !1), iE.copy(this.matrixWorld).invert(), null !== t.parent && (t.parent.updateWorldMatrix(!0, !1), iE.multiply(t.parent.matrixWorld)), t.applyMatrix4(iE), t.removeFromParent(), t.parent = this, this.children.push(t), t.updateWorldMatrix(!1, !0), t.dispatchEvent(iq), iX.child = t, this.dispatchEvent(iX), iX.child = null, this
                }
                getObjectById(t) {
                    return this.getObjectByProperty("id", t)
                }
                getObjectByName(t) {
                    return this.getObjectByProperty("name", t)
                }
                getObjectByProperty(t, e) {
                    if (this[t] === e) return this;
                    for (let i = 0, s = this.children.length; i < s; i++) {
                        let s = this.children[i].getObjectByProperty(t, e);
                        if (void 0 !== s) return s
                    }
                }
                getObjectsByProperty(t, e, i = []) {
                    this[t] === e && i.push(this);
                    let s = this.children;
                    for (let r = 0, n = s.length; r < n; r++) s[r].getObjectsByProperty(t, e, i);
                    return i
                }
                getWorldPosition(t) {
                    return this.updateWorldMatrix(!0, !1), t.setFromMatrixPosition(this.matrixWorld)
                }
                getWorldQuaternion(t) {
                    return this.updateWorldMatrix(!0, !1), this.matrixWorld.decompose(iL, t, ij), t
                }
                getWorldScale(t) {
                    return this.updateWorldMatrix(!0, !1), this.matrixWorld.decompose(iL, iD, t), t
                }
                getWorldDirection(t) {
                    this.updateWorldMatrix(!0, !1);
                    let e = this.matrixWorld.elements;
                    return t.set(e[8], e[9], e[10]).normalize()
                }
                raycast() {}
                intersectsFrustum() {}
                traverse(t) {
                    t(this);
                    let e = this.children;
                    for (let i = 0, s = e.length; i < s; i++) e[i].traverse(t)
                }
                traverseVisible(t) {
                    if (!1 === this.visible) return;
                    t(this);
                    let e = this.children;
                    for (let i = 0, s = e.length; i < s; i++) e[i].traverseVisible(t)
                }
                traverseAncestors(t) {
                    let e = this.parent;
                    null !== e && (t(e), e.traverseAncestors(t))
                }
                updateMatrix() {
                    this.matrix.compose(this.position, this.quaternion, this.scale);
                    let t = this.pivot;
                    if (null !== t) {
                        let e = t.x,
                            i = t.y,
                            s = t.z,
                            r = this.matrix.elements;
                        r[12] += e - r[0] * e - r[4] * i - r[8] * s, r[13] += i - r[1] * e - r[5] * i - r[9] * s, r[14] += s - r[2] * e - r[6] * i - r[10] * s
                    }
                    this.matrixWorldNeedsUpdate = !0
                }
                updateMatrixWorld(t) {
                    this.matrixAutoUpdate && this.updateMatrix(), (this.matrixWorldNeedsUpdate || t) && (!0 === this.matrixWorldAutoUpdate && (null === this.parent ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix)), this.matrixWorldNeedsUpdate = !1, t = !0);
                    let e = this.children;
                    for (let i = 0, s = e.length; i < s; i++) e[i].updateMatrixWorld(t)
                }
                updateWorldMatrix(t, e, i = !1) {
                    let s = this.parent;
                    if (!0 === t && null !== s && s.updateWorldMatrix(!0, !1), this.matrixAutoUpdate && this.updateMatrix(), (this.matrixWorldNeedsUpdate || i) && (!0 === this.matrixWorldAutoUpdate && (null === this.parent ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix)), this.matrixWorldNeedsUpdate = !1, i = !0), !0 === e) {
                        let t = this.children;
                        for (let e = 0, s = t.length; e < s; e++) t[e].updateWorldMatrix(!1, !0, i)
                    }
                }
                toJSON(t) {
                    let e = void 0 === t || "string" == typeof t,
                        i = {};
                    e && (t = {
                        geometries: {},
                        materials: {},
                        textures: {},
                        images: {},
                        shapes: {},
                        skeletons: {},
                        animations: {},
                        nodes: {}
                    }, i.metadata = {
                        version: 4.7,
                        type: "Object",
                        generator: "Object3D.toJSON"
                    });
                    let s = {};

                    function r(e, i) {
                        return void 0 === e[i.uuid] && (e[i.uuid] = i.toJSON(t)), i.uuid
                    }
                    if (s.uuid = this.uuid, s.type = this.type, s.name = this.name, s.castShadow = this.castShadow, s.receiveShadow = this.receiveShadow, s.visible = this.visible, s.frustumCulled = this.frustumCulled, s.renderOrder = this.renderOrder, s.static = this.static, s.matrixAutoUpdate = this.matrixAutoUpdate, Object.keys(this.userData).length > 0 && (s.userData = this.userData), s.layers = this.layers.mask, s.matrix = this.matrix.toArray(), s.up = this.up.toArray(), null !== this.pivot && (s.pivot = this.pivot.toArray()), void 0 !== this.morphTargetDictionary && (s.morphTargetDictionary = Object.assign({}, this.morphTargetDictionary)), void 0 !== this.morphTargetInfluences && (s.morphTargetInfluences = this.morphTargetInfluences.slice()), this.isInstancedMesh && (s.type = "InstancedMesh", s.count = this.count, s.instanceMatrix = this.instanceMatrix.toJSON(), null !== this.instanceColor && (s.instanceColor = this.instanceColor.toJSON())), this.isBatchedMesh && (s.type = "BatchedMesh", s.perObjectFrustumCulled = this.perObjectFrustumCulled, s.sortObjects = this.sortObjects, s.drawRanges = this._drawRanges, s.reservedRanges = this._reservedRanges, s.geometryInfo = this._geometryInfo.map(t => ({ ...t,
                            boundingBox: t.boundingBox ? t.boundingBox.toJSON() : void 0,
                            boundingSphere: t.boundingSphere ? t.boundingSphere.toJSON() : void 0
                        })), s.instanceInfo = this._instanceInfo.map(t => ({ ...t
                        })), s.availableInstanceIds = this._availableInstanceIds.slice(), s.availableGeometryIds = this._availableGeometryIds.slice(), s.nextIndexStart = this._nextIndexStart, s.nextVertexStart = this._nextVertexStart, s.geometryCount = this._geometryCount, s.maxInstanceCount = this._maxInstanceCount, s.maxVertexCount = this._maxVertexCount, s.maxIndexCount = this._maxIndexCount, s.geometryInitialized = this._geometryInitialized, s.matricesTexture = this._matricesTexture.toJSON(t), s.indirectTexture = this._indirectTexture.toJSON(t), null !== this._colorsTexture && (s.colorsTexture = this._colorsTexture.toJSON(t)), null !== this.boundingSphere && (s.boundingSphere = this.boundingSphere.toJSON()), null !== this.boundingBox && (s.boundingBox = this.boundingBox.toJSON())), this.isScene) this.background && (this.background.isColor ? s.background = this.background.toJSON() : this.background.isTexture && (s.background = this.background.toJSON(t).uuid)), this.environment && this.environment.isTexture && !0 !== this.environment.isRenderTargetTexture && (s.environment = this.environment.toJSON(t).uuid);
                    else if (this.isMesh || this.isLine || this.isPoints) {
                        s.geometry = r(t.geometries, this.geometry);
                        let e = this.geometry.parameters;
                        if (void 0 !== e && void 0 !== e.shapes) {
                            let i = e.shapes;
                            if (Array.isArray(i))
                                for (let e = 0, s = i.length; e < s; e++) {
                                    let s = i[e];
                                    r(t.shapes, s)
                                } else r(t.shapes, i)
                        }
                    }
                    if (this.isSkinnedMesh && (s.bindMode = this.bindMode, s.bindMatrix = this.bindMatrix.toArray(), void 0 !== this.skeleton && (r(t.skeletons, this.skeleton), s.skeleton = this.skeleton.uuid)), void 0 !== this.material)
                        if (Array.isArray(this.material)) {
                            let e = [];
                            for (let i = 0, s = this.material.length; i < s; i++) e.push(r(t.materials, this.material[i]));
                            s.material = e
                        } else s.material = r(t.materials, this.material);
                    if (this.children.length > 0) {
                        s.children = [];
                        for (let e = 0; e < this.children.length; e++) s.children.push(this.children[e].toJSON(t).object)
                    }
                    if (this.animations.length > 0) {
                        s.animations = [];
                        for (let e = 0; e < this.animations.length; e++) {
                            let i = this.animations[e];
                            s.animations.push(r(t.animations, i))
                        }
                    }
                    if (e) {
                        let e = n(t.geometries),
                            s = n(t.materials),
                            r = n(t.textures),
                            a = n(t.images),
                            h = n(t.shapes),
                            o = n(t.skeletons),
                            l = n(t.animations),
                            u = n(t.nodes);
                        e.length > 0 && (i.geometries = e), s.length > 0 && (i.materials = s), r.length > 0 && (i.textures = r), a.length > 0 && (i.images = a), h.length > 0 && (i.shapes = h), o.length > 0 && (i.skeletons = o), l.length > 0 && (i.animations = l), u.length > 0 && (i.nodes = u)
                    }
                    return i.object = s, i;

                    function n(t) {
                        let e = [];
                        for (let i in t) {
                            let s = t[i];
                            delete s.metadata, e.push(s)
                        }
                        return e
                    }
                }
                clone(t) {
                    return new this.constructor().copy(this, t)
                }
                copy(t, e = !0) {
                    if (this.name = t.name, this.up.copy(t.up), this.position.copy(t.position), this.rotation.order = t.rotation.order, this.quaternion.copy(t.quaternion), this.scale.copy(t.scale), this.pivot = null !== t.pivot ? t.pivot.clone() : null, this.matrix.copy(t.matrix), this.matrixWorld.copy(t.matrixWorld), this.matrixAutoUpdate = t.matrixAutoUpdate, this.matrixWorldAutoUpdate = t.matrixWorldAutoUpdate, this.matrixWorldNeedsUpdate = t.matrixWorldNeedsUpdate, this.layers.mask = t.layers.mask, this.visible = t.visible, this.castShadow = t.castShadow, this.receiveShadow = t.receiveShadow, this.frustumCulled = t.frustumCulled, this.renderOrder = t.renderOrder, this.static = t.static, this.animations = t.animations.slice(), this.userData = JSON.parse(JSON.stringify(t.userData)), !0 === e)
                        for (let e = 0; e < t.children.length; e++) {
                            let i = t.children[e];
                            this.add(i.clone())
                        }
                    return this
                }
                dispose() {
                    this.dispatchEvent({
                        type: "dispose"
                    })
                }
            }
            iY.DEFAULT_UP = new e9(0, 1, 0), iY.DEFAULT_MATRIX_AUTO_UPDATE = !0, iY.DEFAULT_MATRIX_WORLD_AUTO_UPDATE = !0;
            class iG extends iY {
                constructor() {
                    super(), this.isGroup = !0, this.type = "Group"
                }
            }
            let iQ = {
                type: "move"
            };
            class i$ {
                constructor() {
                    this._targetRay = null, this._grip = null, this._hand = null
                }
                getHandSpace() {
                    return null === this._hand && (this._hand = new iG, this._hand.matrixAutoUpdate = !1, this._hand.visible = !1, this._hand.joints = {}, this._hand.inputState = {
                        pinching: !1
                    }), this._hand
                }
                getTargetRaySpace() {
                    return null === this._targetRay && (this._targetRay = new iG, this._targetRay.matrixAutoUpdate = !1, this._targetRay.visible = !1, this._targetRay.hasLinearVelocity = !1, this._targetRay.linearVelocity = new e9, this._targetRay.hasAngularVelocity = !1, this._targetRay.angularVelocity = new e9), this._targetRay
                }
                getGripSpace() {
                    return null === this._grip && (this._grip = new iG, this._grip.matrixAutoUpdate = !1, this._grip.visible = !1, this._grip.hasLinearVelocity = !1, this._grip.linearVelocity = new e9, this._grip.hasAngularVelocity = !1, this._grip.angularVelocity = new e9, this._grip.eventsEnabled = !1), this._grip
                }
                dispatchEvent(t) {
                    return null !== this._targetRay && this._targetRay.dispatchEvent(t), null !== this._grip && this._grip.dispatchEvent(t), null !== this._hand && this._hand.dispatchEvent(t), this
                }
                connect(t) {
                    if (t && t.hand) {
                        let e = this._hand;
                        if (e)
                            for (let i of t.hand.values()) this._getHandJoint(e, i)
                    }
                    return this.dispatchEvent({
                        type: "connected",
                        data: t
                    }), this
                }
                disconnect(t) {
                    return this.dispatchEvent({
                        type: "disconnected",
                        data: t
                    }), null !== this._targetRay && (this._targetRay.visible = !1), null !== this._grip && (this._grip.visible = !1), null !== this._hand && (this._hand.visible = !1), this
                }
                update(t, e, i) {
                    let s = null,
                        r = null,
                        n = null,
                        a = this._targetRay,
                        h = this._grip,
                        o = this._hand;
                    if (t && "visible-blurred" !== e.session.visibilityState) {
                        if (o && t.hand) {
                            for (let s of (n = !0, t.hand.values())) {
                                let t = e.getJointPose(s, i),
                                    r = this._getHandJoint(o, s);
                                null !== t && (r.matrix.fromArray(t.transform.matrix), r.matrix.decompose(r.position, r.rotation, r.scale), r.matrixWorldNeedsUpdate = !0, r.jointRadius = t.radius), r.visible = null !== t
                            }
                            let s = o.joints["index-finger-tip"],
                                r = o.joints["thumb-tip"],
                                a = s.position.distanceTo(r.position);
                            o.inputState.pinching && a > .025 ? (o.inputState.pinching = !1, this.dispatchEvent({
                                type: "pinchend",
                                handedness: t.handedness,
                                target: this
                            })) : !o.inputState.pinching && a <= .015 && (o.inputState.pinching = !0, this.dispatchEvent({
                                type: "pinchstart",
                                handedness: t.handedness,
                                target: this
                            }))
                        } else null !== h && t.gripSpace && null !== (r = e.getPose(t.gripSpace, i)) && (h.matrix.fromArray(r.transform.matrix), h.matrix.decompose(h.position, h.rotation, h.scale), h.matrixWorldNeedsUpdate = !0, r.linearVelocity ? (h.hasLinearVelocity = !0, h.linearVelocity.copy(r.linearVelocity)) : h.hasLinearVelocity = !1, r.angularVelocity ? (h.hasAngularVelocity = !0, h.angularVelocity.copy(r.angularVelocity)) : h.hasAngularVelocity = !1, h.eventsEnabled && h.dispatchEvent({
                            type: "gripUpdated",
                            data: t,
                            target: this
                        }));
                        null !== a && (null === (s = e.getPose(t.targetRaySpace, i)) && null !== r && (s = r), null !== s && (a.matrix.fromArray(s.transform.matrix), a.matrix.decompose(a.position, a.rotation, a.scale), a.matrixWorldNeedsUpdate = !0, s.linearVelocity ? (a.hasLinearVelocity = !0, a.linearVelocity.copy(s.linearVelocity)) : a.hasLinearVelocity = !1, s.angularVelocity ? (a.hasAngularVelocity = !0, a.angularVelocity.copy(s.angularVelocity)) : a.hasAngularVelocity = !1, this.dispatchEvent(iQ)))
                    }
                    return null !== a && (a.visible = null !== s), null !== h && (h.visible = null !== r), null !== o && (o.visible = null !== n), this
                }
                _getHandJoint(t, e) {
                    if (void 0 === t.joints[e.jointName]) {
                        let i = new iG;
                        i.matrixAutoUpdate = !1, i.visible = !1, t.joints[e.jointName] = i, t.add(i)
                    }
                    return t.joints[e.jointName]
                }
            }
            let iK = {
                    aliceblue: 0xf0f8ff,
                    antiquewhite: 0xfaebd7,
                    aqua: 65535,
                    aquamarine: 8388564,
                    azure: 0xf0ffff,
                    beige: 0xf5f5dc,
                    bisque: 0xffe4c4,
                    black: 0,
                    blanchedalmond: 0xffebcd,
                    blue: 255,
                    blueviolet: 9055202,
                    brown: 0xa52a2a,
                    burlywood: 0xdeb887,
                    cadetblue: 6266528,
                    chartreuse: 8388352,
                    chocolate: 0xd2691e,
                    coral: 0xff7f50,
                    cornflowerblue: 6591981,
                    cornsilk: 0xfff8dc,
                    crimson: 0xdc143c,
                    cyan: 65535,
                    darkblue: 139,
                    darkcyan: 35723,
                    darkgoldenrod: 0xb8860b,
                    darkgray: 0xa9a9a9,
                    darkgreen: 25600,
                    darkgrey: 0xa9a9a9,
                    darkkhaki: 0xbdb76b,
                    darkmagenta: 9109643,
                    darkolivegreen: 5597999,
                    darkorange: 0xff8c00,
                    darkorchid: 0x9932cc,
                    darkred: 9109504,
                    darksalmon: 0xe9967a,
                    darkseagreen: 9419919,
                    darkslateblue: 4734347,
                    darkslategray: 3100495,
                    darkslategrey: 3100495,
                    darkturquoise: 52945,
                    darkviolet: 9699539,
                    deeppink: 0xff1493,
                    deepskyblue: 49151,
                    dimgray: 6908265,
                    dimgrey: 6908265,
                    dodgerblue: 2003199,
                    firebrick: 0xb22222,
                    floralwhite: 0xfffaf0,
                    forestgreen: 2263842,
                    fuchsia: 0xff00ff,
                    gainsboro: 0xdcdcdc,
                    ghostwhite: 0xf8f8ff,
                    gold: 0xffd700,
                    goldenrod: 0xdaa520,
                    gray: 8421504,
                    green: 32768,
                    greenyellow: 0xadff2f,
                    grey: 8421504,
                    honeydew: 0xf0fff0,
                    hotpink: 0xff69b4,
                    indianred: 0xcd5c5c,
                    indigo: 4915330,
                    ivory: 0xfffff0,
                    khaki: 0xf0e68c,
                    lavender: 0xe6e6fa,
                    lavenderblush: 0xfff0f5,
                    lawngreen: 8190976,
                    lemonchiffon: 0xfffacd,
                    lightblue: 0xadd8e6,
                    lightcoral: 0xf08080,
                    lightcyan: 0xe0ffff,
                    lightgoldenrodyellow: 0xfafad2,
                    lightgray: 0xd3d3d3,
                    lightgreen: 9498256,
                    lightgrey: 0xd3d3d3,
                    lightpink: 0xffb6c1,
                    lightsalmon: 0xffa07a,
                    lightseagreen: 2142890,
                    lightskyblue: 8900346,
                    lightslategray: 7833753,
                    lightslategrey: 7833753,
                    lightsteelblue: 0xb0c4de,
                    lightyellow: 0xffffe0,
                    lime: 65280,
                    limegreen: 3329330,
                    linen: 0xfaf0e6,
                    magenta: 0xff00ff,
                    maroon: 8388608,
                    mediumaquamarine: 6737322,
                    mediumblue: 205,
                    mediumorchid: 0xba55d3,
                    mediumpurple: 9662683,
                    mediumseagreen: 3978097,
                    mediumslateblue: 8087790,
                    mediumspringgreen: 64154,
                    mediumturquoise: 4772300,
                    mediumvioletred: 0xc71585,
                    midnightblue: 1644912,
                    mintcream: 0xf5fffa,
                    mistyrose: 0xffe4e1,
                    moccasin: 0xffe4b5,
                    navajowhite: 0xffdead,
                    navy: 128,
                    oldlace: 0xfdf5e6,
                    olive: 8421376,
                    olivedrab: 7048739,
                    orange: 0xffa500,
                    orangered: 0xff4500,
                    orchid: 0xda70d6,
                    palegoldenrod: 0xeee8aa,
                    palegreen: 0x98fb98,
                    paleturquoise: 0xafeeee,
                    palevioletred: 0xdb7093,
                    papayawhip: 0xffefd5,
                    peachpuff: 0xffdab9,
                    peru: 0xcd853f,
                    pink: 0xffc0cb,
                    plum: 0xdda0dd,
                    powderblue: 0xb0e0e6,
                    purple: 8388736,
                    rebeccapurple: 6697881,
                    red: 0xff0000,
                    rosybrown: 0xbc8f8f,
                    royalblue: 4286945,
                    saddlebrown: 9127187,
                    salmon: 0xfa8072,
                    sandybrown: 0xf4a460,
                    seagreen: 3050327,
                    seashell: 0xfff5ee,
                    sienna: 0xa0522d,
                    silver: 0xc0c0c0,
                    skyblue: 8900331,
                    slateblue: 6970061,
                    slategray: 7372944,
                    slategrey: 7372944,
                    snow: 0xfffafa,
                    springgreen: 65407,
                    steelblue: 4620980,
                    tan: 0xd2b48c,
                    teal: 32896,
                    thistle: 0xd8bfd8,
                    tomato: 0xff6347,
                    turquoise: 4251856,
                    violet: 0xee82ee,
                    wheat: 0xf5deb3,
                    white: 0xffffff,
                    whitesmoke: 0xf5f5f5,
                    yellow: 0xffff00,
                    yellowgreen: 0x9acd32
                },
                i0 = {
                    h: 0,
                    s: 0,
                    l: 0
                },
                i1 = {
                    h: 0,
                    s: 0,
                    l: 0
                };

            function i2(t, e, i) {
                return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6) ? t + (e - t) * 6 * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * 6 * (2 / 3 - i) : t
            }
            class i3 {
                constructor(t, e, i) {
                    return this.isColor = !0, this.r = 1, this.g = 1, this.b = 1, this.set(t, e, i)
                }
                set(t, e, i) {
                    return void 0 === e && void 0 === i ? t && t.isColor ? this.copy(t) : "number" == typeof t ? this.setHex(t) : "string" == typeof t && this.setStyle(t) : this.setRGB(t, e, i), this
                }
                setScalar(t) {
                    return this.r = t, this.g = t, this.b = t, this
                }
                setHex(t, e = eS) {
                    return t = Math.floor(t), this.r = (t >> 16 & 255) / 255, this.g = (t >> 8 & 255) / 255, this.b = (255 & t) / 255, ia.colorSpaceToWorking(this, e), this
                }
                setRGB(t, e, i, s = ia.workingColorSpace) {
                    return this.r = t, this.g = e, this.b = i, ia.colorSpaceToWorking(this, s), this
                }
                setHSL(t, e, i, s = ia.workingColorSpace) {
                    if (t = e1(t, 1), e = e0(e, 0, 1), i = e0(i, 0, 1), 0 === e) this.r = this.g = this.b = i;
                    else {
                        let s = i <= .5 ? i * (1 + e) : i + e - i * e,
                            r = 2 * i - s;
                        this.r = i2(r, s, t + 1 / 3), this.g = i2(r, s, t), this.b = i2(r, s, t - 1 / 3)
                    }
                    return ia.colorSpaceToWorking(this, s), this
                }
                setStyle(t, e = eS) {
                    let i;

                    function s(e) {
                        void 0 !== e && 1 > parseFloat(e) && eU("Color: Alpha component of " + t + " will be ignored.")
                    }
                    if (i = /^(\w+)\(([^\)]*)\)/.exec(t)) {
                        let r, n = i[1],
                            a = i[2];
                        switch (n) {
                            case "rgb":
                            case "rgba":
                                if (r = /^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return s(r[4]), this.setRGB(Math.min(255, parseInt(r[1], 10)) / 255, Math.min(255, parseInt(r[2], 10)) / 255, Math.min(255, parseInt(r[3], 10)) / 255, e);
                                if (r = /^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return s(r[4]), this.setRGB(Math.min(100, parseInt(r[1], 10)) / 100, Math.min(100, parseInt(r[2], 10)) / 100, Math.min(100, parseInt(r[3], 10)) / 100, e);
                                break;
                            case "hsl":
                            case "hsla":
                                if (r = /^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return s(r[4]), this.setHSL(parseFloat(r[1]) / 360, parseFloat(r[2]) / 100, parseFloat(r[3]) / 100, e);
                                break;
                            default:
                                eU("Color: Unknown color model " + t)
                        }
                    } else if (i = /^\#([A-Fa-f\d]+)$/.exec(t)) {
                        let s = i[1],
                            r = s.length;
                        if (3 === r) return this.setRGB(parseInt(s.charAt(0), 16) / 15, parseInt(s.charAt(1), 16) / 15, parseInt(s.charAt(2), 16) / 15, e);
                        if (6 === r) return this.setHex(parseInt(s, 16), e);
                        eU("Color: Invalid hex color " + t)
                    } else if (t && t.length > 0) return this.setColorName(t, e);
                    return this
                }
                setColorName(t, e = eS) {
                    let i = iK[t.toLowerCase()];
                    return void 0 !== i ? this.setHex(i, e) : eU("Color: Unknown color " + t), this
                }
                clone() {
                    return new this.constructor(this.r, this.g, this.b)
                }
                copy(t) {
                    return this.r = t.r, this.g = t.g, this.b = t.b, this
                }
                copySRGBToLinear(t) {
                    return this.r = ih(t.r), this.g = ih(t.g), this.b = ih(t.b), this
                }
                copyLinearToSRGB(t) {
                    return this.r = io(t.r), this.g = io(t.g), this.b = io(t.b), this
                }
                convertSRGBToLinear() {
                    return this.copySRGBToLinear(this), this
                }
                convertLinearToSRGB() {
                    return this.copyLinearToSRGB(this), this
                }
                getHex(t = eS) {
                    return ia.workingToColorSpace(i5.copy(this), t), 65536 * Math.round(e0(255 * i5.r, 0, 255)) + 256 * Math.round(e0(255 * i5.g, 0, 255)) + Math.round(e0(255 * i5.b, 0, 255))
                }
                getHexString(t = eS) {
                    return ("000000" + this.getHex(t).toString(16)).slice(-6)
                }
                getHSL(t, e = ia.workingColorSpace) {
                    let i, s;
                    ia.workingToColorSpace(i5.copy(this), e);
                    let r = i5.r,
                        n = i5.g,
                        a = i5.b,
                        h = Math.max(r, n, a),
                        o = Math.min(r, n, a),
                        l = (o + h) / 2;
                    if (o === h) i = 0, s = 0;
                    else {
                        let t = h - o;
                        switch (s = l <= .5 ? t / (h + o) : t / (2 - h - o), h) {
                            case r:
                                i = (n - a) / t + 6 * (n < a);
                                break;
                            case n:
                                i = (a - r) / t + 2;
                                break;
                            case a:
                                i = (r - n) / t + 4
                        }
                        i /= 6
                    }
                    return t.h = i, t.s = s, t.l = l, t
                }
                getRGB(t, e = ia.workingColorSpace) {
                    return ia.workingToColorSpace(i5.copy(this), e), t.r = i5.r, t.g = i5.g, t.b = i5.b, t
                }
                getStyle(t = eS) {
                    ia.workingToColorSpace(i5.copy(this), t);
                    let e = i5.r,
                        i = i5.g,
                        s = i5.b;
                    return t !== eS ? `color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})` : `rgb(${Math.round(255*e)},${Math.round(255*i)},${Math.round(255*s)})`
                }
                offsetHSL(t, e, i) {
                    return this.getHSL(i0), this.setHSL(i0.h + t, i0.s + e, i0.l + i)
                }
                add(t) {
                    return this.r += t.r, this.g += t.g, this.b += t.b, this
                }
                addColors(t, e) {
                    return this.r = t.r + e.r, this.g = t.g + e.g, this.b = t.b + e.b, this
                }
                addScalar(t) {
                    return this.r += t, this.g += t, this.b += t, this
                }
                sub(t) {
                    return this.r = Math.max(0, this.r - t.r), this.g = Math.max(0, this.g - t.g), this.b = Math.max(0, this.b - t.b), this
                }
                multiply(t) {
                    return this.r *= t.r, this.g *= t.g, this.b *= t.b, this
                }
                multiplyScalar(t) {
                    return this.r *= t, this.g *= t, this.b *= t, this
                }
                lerp(t, e) {
                    return this.r += (t.r - this.r) * e, this.g += (t.g - this.g) * e, this.b += (t.b - this.b) * e, this
                }
                lerpColors(t, e, i) {
                    return this.r = t.r + (e.r - t.r) * i, this.g = t.g + (e.g - t.g) * i, this.b = t.b + (e.b - t.b) * i, this
                }
                lerpHSL(t, e) {
                    this.getHSL(i0), t.getHSL(i1);
                    let i = e2(i0.h, i1.h, e),
                        s = e2(i0.s, i1.s, e),
                        r = e2(i0.l, i1.l, e);
                    return this.setHSL(i, s, r), this
                }
                setFromVector3(t) {
                    return this.r = t.x, this.g = t.y, this.b = t.z, this
                }
                applyMatrix3(t) {
                    let e = this.r,
                        i = this.g,
                        s = this.b,
                        r = t.elements;
                    return this.r = r[0] * e + r[3] * i + r[6] * s, this.g = r[1] * e + r[4] * i + r[7] * s, this.b = r[2] * e + r[5] * i + r[8] * s, this
                }
                equals(t) {
                    return t.r === this.r && t.g === this.g && t.b === this.b
                }
                fromArray(t, e = 0) {
                    return this.r = t[e], this.g = t[e + 1], this.b = t[e + 2], this
                }
                toArray(t = [], e = 0) {
                    return t[e] = this.r, t[e + 1] = this.g, t[e + 2] = this.b, t
                }
                fromBufferAttribute(t, e) {
                    return this.r = t.getX(e), this.g = t.getY(e), this.b = t.getZ(e), this
                }
                toJSON() {
                    return this.getHex()
                }*[Symbol.iterator]() {
                    yield this.r, yield this.g, yield this.b
                }
            }
            let i5 = new i3;
            i3.NAMES = iK;
            class i4 {
                constructor(t, e = 1, i = 1e3) {
                    this.isFog = !0, this.name = "", this.color = new i3(t), this.near = e, this.far = i
                }
                clone() {
                    return new i4(this.color, this.near, this.far)
                }
                toJSON() {
                    return {
                        type: "Fog",
                        name: this.name,
                        color: this.color.getHex(),
                        near: this.near,
                        far: this.far
                    }
                }
            }
            class i6 extends iY {
                constructor() {
                    super(), this.isScene = !0, this.type = "Scene", this.background = null, this.environment = null, this.fog = null, this.backgroundBlurriness = 0, this.backgroundIntensity = 1, this.backgroundRotation = new iI, this.environmentIntensity = 1, this.environmentRotation = new iI, this.overrideMaterial = null, "u" > typeof __THREE_DEVTOOLS__ && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", {
                        detail: this
                    }))
                }
                copy(t, e) {
                    return super.copy(t, e), null !== t.background && (this.background = t.background.clone()), null !== t.environment && (this.environment = t.environment.clone()), null !== t.fog && (this.fog = t.fog.clone()), this.backgroundBlurriness = t.backgroundBlurriness, this.backgroundIntensity = t.backgroundIntensity, this.backgroundRotation.copy(t.backgroundRotation), this.environmentIntensity = t.environmentIntensity, this.environmentRotation.copy(t.environmentRotation), null !== t.overrideMaterial && (this.overrideMaterial = t.overrideMaterial.clone()), this.matrixAutoUpdate = t.matrixAutoUpdate, this
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    return null !== this.fog && (e.object.fog = this.fog.toJSON()), e.object.backgroundBlurriness = this.backgroundBlurriness, e.object.backgroundIntensity = this.backgroundIntensity, e.object.backgroundRotation = this.backgroundRotation.toArray(), e.object.environmentIntensity = this.environmentIntensity, e.object.environmentRotation = this.environmentRotation.toArray(), e
                }
            }
            let i8 = new e9,
                i9 = new e9,
                i7 = new e9,
                st = new e9,
                se = new e9,
                si = new e9,
                ss = new e9,
                sr = new e9,
                sn = new e9,
                sa = new e9,
                sh = new ig,
                so = new ig,
                sl = new ig;
            class su {
                constructor(t = new e9, e = new e9, i = new e9) {
                    this.a = t, this.b = e, this.c = i
                }
                static getNormal(t, e, i, s) {
                    s.subVectors(i, e), i8.subVectors(t, e), s.cross(i8);
                    let r = s.lengthSq();
                    return r > 0 ? s.multiplyScalar(1 / Math.sqrt(r)) : s.set(0, 0, 0)
                }
                static getBarycoord(t, e, i, s, r) {
                    i8.subVectors(s, e), i9.subVectors(i, e), i7.subVectors(t, e);
                    let n = i8.dot(i8),
                        a = i8.dot(i9),
                        h = i8.dot(i7),
                        o = i9.dot(i9),
                        l = i9.dot(i7),
                        u = n * o - a * a;
                    if (0 === u) return r.set(0, 0, 0), null;
                    let c = 1 / u,
                        p = (o * h - a * l) * c,
                        d = (n * l - a * h) * c;
                    return r.set(1 - p - d, d, p)
                }
                static containsPoint(t, e, i, s) {
                    return null !== this.getBarycoord(t, e, i, s, st) && st.x >= 0 && st.y >= 0 && st.x + st.y <= 1
                }
                static getInterpolation(t, e, i, s, r, n, a, h) {
                    return null === this.getBarycoord(t, e, i, s, st) ? (h.x = 0, h.y = 0, "z" in h && (h.z = 0), "w" in h && (h.w = 0), null) : (h.setScalar(0), h.addScaledVector(r, st.x), h.addScaledVector(n, st.y), h.addScaledVector(a, st.z), h)
                }
                static getInterpolatedAttribute(t, e, i, s, r, n) {
                    return sh.setScalar(0), so.setScalar(0), sl.setScalar(0), sh.fromBufferAttribute(t, e), so.fromBufferAttribute(t, i), sl.fromBufferAttribute(t, s), n.setScalar(0), n.addScaledVector(sh, r.x), n.addScaledVector(so, r.y), n.addScaledVector(sl, r.z), n
                }
                static isFrontFacing(t, e, i, s) {
                    return i8.subVectors(i, e), i9.subVectors(t, e), 0 > i8.cross(i9).dot(s)
                }
                set(t, e, i) {
                    return this.a.copy(t), this.b.copy(e), this.c.copy(i), this
                }
                setFromPointsAndIndices(t, e, i, s) {
                    return this.a.copy(t[e]), this.b.copy(t[i]), this.c.copy(t[s]), this
                }
                setFromAttributeAndIndices(t, e, i, s) {
                    return this.a.fromBufferAttribute(t, e), this.b.fromBufferAttribute(t, i), this.c.fromBufferAttribute(t, s), this
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                copy(t) {
                    return this.a.copy(t.a), this.b.copy(t.b), this.c.copy(t.c), this
                }
                getArea() {
                    return i8.subVectors(this.c, this.b), i9.subVectors(this.a, this.b), .5 * i8.cross(i9).length()
                }
                getMidpoint(t) {
                    return t.addVectors(this.a, this.b).add(this.c).multiplyScalar(1 / 3)
                }
                getNormal(t) {
                    return su.getNormal(this.a, this.b, this.c, t)
                }
                getPlane(t) {
                    return t.setFromCoplanarPoints(this.a, this.b, this.c)
                }
                getBarycoord(t, e) {
                    return su.getBarycoord(t, this.a, this.b, this.c, e)
                }
                getInterpolation(t, e, i, s, r) {
                    return su.getInterpolation(t, this.a, this.b, this.c, e, i, s, r)
                }
                containsPoint(t) {
                    return su.containsPoint(t, this.a, this.b, this.c)
                }
                isFrontFacing(t) {
                    return su.isFrontFacing(this.a, this.b, this.c, t)
                }
                intersectsBox(t) {
                    return t.intersectsTriangle(this)
                }
                closestPointToPoint(t, e) {
                    let i, s, r = this.a,
                        n = this.b,
                        a = this.c;
                    se.subVectors(n, r), si.subVectors(a, r), sr.subVectors(t, r);
                    let h = se.dot(sr),
                        o = si.dot(sr);
                    if (h <= 0 && o <= 0) return e.copy(r);
                    sn.subVectors(t, n);
                    let l = se.dot(sn),
                        u = si.dot(sn);
                    if (l >= 0 && u <= l) return e.copy(n);
                    let c = h * u - l * o;
                    if (c <= 0 && h >= 0 && l <= 0) return i = h / (h - l), e.copy(r).addScaledVector(se, i);
                    sa.subVectors(t, a);
                    let p = se.dot(sa),
                        d = si.dot(sa);
                    if (d >= 0 && p <= d) return e.copy(a);
                    let m = p * o - h * d;
                    if (m <= 0 && o >= 0 && d <= 0) return s = o / (o - d), e.copy(r).addScaledVector(si, s);
                    let y = l * d - p * u;
                    if (y <= 0 && u - l >= 0 && p - d >= 0) return ss.subVectors(a, n), s = (u - l) / (u - l + (p - d)), e.copy(n).addScaledVector(ss, s);
                    let f = 1 / (y + m + c);
                    return i = m * f, s = c * f, e.copy(r).addScaledVector(se, i).addScaledVector(si, s)
                }
                equals(t) {
                    return t.a.equals(this.a) && t.b.equals(this.b) && t.c.equals(this.c)
                }
            }
            class sc {
                constructor(t = new e9(Infinity, Infinity, Infinity), e = new e9(-1 / 0, -1 / 0, -1 / 0)) {
                    this.isBox3 = !0, this.min = t, this.max = e
                }
                set(t, e) {
                    return this.min.copy(t), this.max.copy(e), this
                }
                setFromArray(t) {
                    this.makeEmpty();
                    for (let e = 0, i = t.length; e < i; e += 3) this.expandByPoint(sd.fromArray(t, e));
                    return this
                }
                setFromBufferAttribute(t) {
                    this.makeEmpty();
                    for (let e = 0, i = t.count; e < i; e++) this.expandByPoint(sd.fromBufferAttribute(t, e));
                    return this
                }
                setFromPoints(t) {
                    this.makeEmpty();
                    for (let e = 0, i = t.length; e < i; e++) this.expandByPoint(t[e]);
                    return this
                }
                setFromCenterAndSize(t, e) {
                    let i = sd.copy(e).multiplyScalar(.5);
                    return this.min.copy(t).sub(i), this.max.copy(t).add(i), this
                }
                setFromObject(t, e = !1) {
                    return this.makeEmpty(), this.expandByObject(t, e)
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                copy(t) {
                    return this.min.copy(t.min), this.max.copy(t.max), this
                }
                makeEmpty() {
                    return this.min.x = this.min.y = this.min.z = Infinity, this.max.x = this.max.y = this.max.z = -1 / 0, this
                }
                isEmpty() {
                    return this.max.x < this.min.x || this.max.y < this.min.y || this.max.z < this.min.z
                }
                getCenter(t) {
                    return this.isEmpty() ? t.set(0, 0, 0) : t.addVectors(this.min, this.max).multiplyScalar(.5)
                }
                getSize(t) {
                    return this.isEmpty() ? t.set(0, 0, 0) : t.subVectors(this.max, this.min)
                }
                expandByPoint(t) {
                    return this.min.min(t), this.max.max(t), this
                }
                expandByVector(t) {
                    return this.min.sub(t), this.max.add(t), this
                }
                expandByScalar(t) {
                    return this.min.addScalar(-t), this.max.addScalar(t), this
                }
                expandByObject(t, e = !1) {
                    t.updateWorldMatrix(!1, !1);
                    let i = t.geometry;
                    if (void 0 !== i) {
                        let s = i.getAttribute("position");
                        if (!0 === e && void 0 !== s && !0 !== t.isInstancedMesh)
                            for (let e = 0, i = s.count; e < i; e++) !0 === t.isMesh ? t.getVertexPosition(e, sd) : sd.fromBufferAttribute(s, e), sd.applyMatrix4(t.matrixWorld), this.expandByPoint(sd);
                        else void 0 !== t.boundingBox ? (null === t.boundingBox && t.computeBoundingBox(), sm.copy(t.boundingBox)) : (null === i.boundingBox && i.computeBoundingBox(), sm.copy(i.boundingBox)), sm.applyMatrix4(t.matrixWorld), this.union(sm)
                    }
                    let s = t.children;
                    for (let t = 0, i = s.length; t < i; t++) this.expandByObject(s[t], e);
                    return this
                }
                containsPoint(t) {
                    return t.x >= this.min.x && t.x <= this.max.x && t.y >= this.min.y && t.y <= this.max.y && t.z >= this.min.z && t.z <= this.max.z
                }
                containsBox(t) {
                    return this.min.x <= t.min.x && t.max.x <= this.max.x && this.min.y <= t.min.y && t.max.y <= this.max.y && this.min.z <= t.min.z && t.max.z <= this.max.z
                }
                getParameter(t, e) {
                    return e.set((t.x - this.min.x) / (this.max.x - this.min.x), (t.y - this.min.y) / (this.max.y - this.min.y), (t.z - this.min.z) / (this.max.z - this.min.z))
                }
                intersectsBox(t) {
                    return t.max.x >= this.min.x && t.min.x <= this.max.x && t.max.y >= this.min.y && t.min.y <= this.max.y && t.max.z >= this.min.z && t.min.z <= this.max.z
                }
                intersectsSphere(t) {
                    return this.clampPoint(t.center, sd), sd.distanceToSquared(t.center) <= t.radius * t.radius
                }
                intersectsPlane(t) {
                    let e, i;
                    return t.normal.x > 0 ? (e = t.normal.x * this.min.x, i = t.normal.x * this.max.x) : (e = t.normal.x * this.max.x, i = t.normal.x * this.min.x), t.normal.y > 0 ? (e += t.normal.y * this.min.y, i += t.normal.y * this.max.y) : (e += t.normal.y * this.max.y, i += t.normal.y * this.min.y), t.normal.z > 0 ? (e += t.normal.z * this.min.z, i += t.normal.z * this.max.z) : (e += t.normal.z * this.max.z, i += t.normal.z * this.min.z), e <= -t.constant && i >= -t.constant
                }
                intersectsTriangle(t) {
                    if (this.isEmpty()) return !1;
                    this.getCenter(sb), sw.subVectors(this.max, sb), sy.subVectors(t.a, sb), sf.subVectors(t.b, sb), sg.subVectors(t.c, sb), sx.subVectors(sf, sy), sv.subVectors(sg, sf), sM.subVectors(sy, sg);
                    let e = [0, -sx.z, sx.y, 0, -sv.z, sv.y, 0, -sM.z, sM.y, sx.z, 0, -sx.x, sv.z, 0, -sv.x, sM.z, 0, -sM.x, -sx.y, sx.x, 0, -sv.y, sv.x, 0, -sM.y, sM.x, 0];
                    return !!sz(e, sy, sf, sg, sw) && !!sz(e = [1, 0, 0, 0, 1, 0, 0, 0, 1], sy, sf, sg, sw) && (sS.crossVectors(sx, sv), sz(e = [sS.x, sS.y, sS.z], sy, sf, sg, sw))
                }
                clampPoint(t, e) {
                    return e.copy(t).clamp(this.min, this.max)
                }
                distanceToPoint(t) {
                    return this.clampPoint(t, sd).distanceTo(t)
                }
                getBoundingSphere(t) {
                    return this.isEmpty() ? t.makeEmpty() : (this.getCenter(t.center), t.radius = .5 * this.getSize(sd).length()), t
                }
                intersect(t) {
                    return this.min.max(t.min), this.max.min(t.max), this.isEmpty() && this.makeEmpty(), this
                }
                union(t) {
                    return this.min.min(t.min), this.max.max(t.max), this
                }
                applyMatrix4(t) {
                    return this.isEmpty() || (sp[0].set(this.min.x, this.min.y, this.min.z).applyMatrix4(t), sp[1].set(this.min.x, this.min.y, this.max.z).applyMatrix4(t), sp[2].set(this.min.x, this.max.y, this.min.z).applyMatrix4(t), sp[3].set(this.min.x, this.max.y, this.max.z).applyMatrix4(t), sp[4].set(this.max.x, this.min.y, this.min.z).applyMatrix4(t), sp[5].set(this.max.x, this.min.y, this.max.z).applyMatrix4(t), sp[6].set(this.max.x, this.max.y, this.min.z).applyMatrix4(t), sp[7].set(this.max.x, this.max.y, this.max.z).applyMatrix4(t), this.setFromPoints(sp)), this
                }
                translate(t) {
                    return this.min.add(t), this.max.add(t), this
                }
                equals(t) {
                    return t.min.equals(this.min) && t.max.equals(this.max)
                }
                toJSON() {
                    return {
                        min: this.min.toArray(),
                        max: this.max.toArray()
                    }
                }
                fromJSON(t) {
                    return this.min.fromArray(t.min), this.max.fromArray(t.max), this
                }
            }
            let sp = [new e9, new e9, new e9, new e9, new e9, new e9, new e9, new e9],
                sd = new e9,
                sm = new sc,
                sy = new e9,
                sf = new e9,
                sg = new e9,
                sx = new e9,
                sv = new e9,
                sM = new e9,
                sb = new e9,
                sw = new e9,
                sS = new e9,
                s_ = new e9;

            function sz(t, e, i, s, r) {
                for (let n = 0, a = t.length - 3; n <= a; n += 3) {
                    s_.fromArray(t, n);
                    let a = r.x * Math.abs(s_.x) + r.y * Math.abs(s_.y) + r.z * Math.abs(s_.z),
                        h = e.dot(s_),
                        o = i.dot(s_),
                        l = s.dot(s_);
                    if (Math.max(-Math.max(h, o, l), Math.min(h, o, l)) > a) return !1
                }
                return !0
            }
            let sA = new e9,
                sT = new e6,
                sC = 0;
            class sk extends eZ {
                constructor(t, e, i = !1) {
                    if (super(), Array.isArray(t)) throw TypeError("THREE.BufferAttribute: array should be a Typed Array.");
                    this.isBufferAttribute = !0, Object.defineProperty(this, "id", {
                        value: sC++
                    }), this.name = "", this.array = t, this.itemSize = e, this.count = void 0 !== t ? t.length / e : 0, this.normalized = i, this.usage = 35044, this.updateRanges = [], this.gpuType = tO, this.version = 0
                }
                onUploadCallback() {}
                set needsUpdate(t) {
                    !0 === t && this.version++
                }
                setUsage(t) {
                    return this.usage = t, this
                }
                addUpdateRange(t, e) {
                    this.updateRanges.push({
                        start: t,
                        count: e
                    })
                }
                clearUpdateRanges() {
                    this.updateRanges.length = 0
                }
                copy(t) {
                    return this.name = t.name, this.array = new t.array.constructor(t.array), this.itemSize = t.itemSize, this.count = t.count, this.normalized = t.normalized, this.usage = t.usage, this.gpuType = t.gpuType, this
                }
                copyAt(t, e, i) {
                    t *= this.itemSize, i *= e.itemSize;
                    for (let s = 0, r = this.itemSize; s < r; s++) this.array[t + s] = e.array[i + s];
                    return this
                }
                copyArray(t) {
                    return this.array.set(t), this
                }
                applyMatrix3(t) {
                    if (2 === this.itemSize)
                        for (let e = 0, i = this.count; e < i; e++) sT.fromBufferAttribute(this, e), sT.applyMatrix3(t), this.setXY(e, sT.x, sT.y);
                    else if (3 === this.itemSize)
                        for (let e = 0, i = this.count; e < i; e++) sA.fromBufferAttribute(this, e), sA.applyMatrix3(t), this.setXYZ(e, sA.x, sA.y, sA.z);
                    return this
                }
                applyMatrix4(t) {
                    for (let e = 0, i = this.count; e < i; e++) sA.fromBufferAttribute(this, e), sA.applyMatrix4(t), this.setXYZ(e, sA.x, sA.y, sA.z);
                    return this
                }
                applyNormalMatrix(t) {
                    for (let e = 0, i = this.count; e < i; e++) sA.fromBufferAttribute(this, e), sA.applyNormalMatrix(t), this.setXYZ(e, sA.x, sA.y, sA.z);
                    return this
                }
                transformDirection(t) {
                    for (let e = 0, i = this.count; e < i; e++) sA.fromBufferAttribute(this, e), sA.transformDirection(t), this.setXYZ(e, sA.x, sA.y, sA.z);
                    return this
                }
                set(t, e = 0) {
                    return this.array.set(t, e), this
                }
                getComponent(t, e) {
                    let i = this.array[t * this.itemSize + e];
                    return this.normalized && (i = e3(i, this.array)), i
                }
                setComponent(t, e, i) {
                    return this.normalized && (i = e5(i, this.array)), this.array[t * this.itemSize + e] = i, this
                }
                getX(t) {
                    let e = this.array[t * this.itemSize];
                    return this.normalized && (e = e3(e, this.array)), e
                }
                setX(t, e) {
                    return this.normalized && (e = e5(e, this.array)), this.array[t * this.itemSize] = e, this
                }
                getY(t) {
                    let e = this.array[t * this.itemSize + 1];
                    return this.normalized && (e = e3(e, this.array)), e
                }
                setY(t, e) {
                    return this.normalized && (e = e5(e, this.array)), this.array[t * this.itemSize + 1] = e, this
                }
                getZ(t) {
                    let e = this.array[t * this.itemSize + 2];
                    return this.normalized && (e = e3(e, this.array)), e
                }
                setZ(t, e) {
                    return this.normalized && (e = e5(e, this.array)), this.array[t * this.itemSize + 2] = e, this
                }
                getW(t) {
                    let e = this.array[t * this.itemSize + 3];
                    return this.normalized && (e = e3(e, this.array)), e
                }
                setW(t, e) {
                    return this.normalized && (e = e5(e, this.array)), this.array[t * this.itemSize + 3] = e, this
                }
                setXY(t, e, i) {
                    return t *= this.itemSize, this.normalized && (e = e5(e, this.array), i = e5(i, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this
                }
                setXYZ(t, e, i, s) {
                    return t *= this.itemSize, this.normalized && (e = e5(e, this.array), i = e5(i, this.array), s = e5(s, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this.array[t + 2] = s, this
                }
                setXYZW(t, e, i, s, r) {
                    return t *= this.itemSize, this.normalized && (e = e5(e, this.array), i = e5(i, this.array), s = e5(s, this.array), r = e5(r, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this.array[t + 2] = s, this.array[t + 3] = r, this
                }
                onUpload(t) {
                    return this.onUploadCallback = t, this
                }
                clone() {
                    return new this.constructor(this.array, this.itemSize).copy(this)
                }
                toJSON() {
                    let t = {
                        itemSize: this.itemSize,
                        type: this.array.constructor.name,
                        array: Array.from(this.array),
                        normalized: this.normalized
                    };
                    return t.name = this.name, t.usage = this.usage, t.gpuType = this.gpuType, t
                }
                dispose() {
                    this.dispatchEvent({
                        type: "dispose"
                    })
                }
            }
            class sB extends sk {
                constructor(t, e, i) {
                    super(new Uint16Array(t), e, i)
                }
            }
            class sO extends sk {
                constructor(t, e, i) {
                    super(new Uint32Array(t), e, i)
                }
            }
            class sI extends sk {
                constructor(t, e, i) {
                    super(new Float32Array(t), e, i)
                }
            }
            let sN = new sc,
                sP = new e9,
                sR = new e9;
            class sV {
                constructor(t = new e9, e = -1) {
                    this.isSphere = !0, this.center = t, this.radius = e
                }
                set(t, e) {
                    return this.center.copy(t), this.radius = e, this
                }
                setFromPoints(t, e) {
                    let i = this.center;
                    void 0 !== e ? i.copy(e) : sN.setFromPoints(t).getCenter(i);
                    let s = 0;
                    for (let e = 0, r = t.length; e < r; e++) s = Math.max(s, i.distanceToSquared(t[e]));
                    return this.radius = Math.sqrt(s), this
                }
                copy(t) {
                    return this.center.copy(t.center), this.radius = t.radius, this
                }
                isEmpty() {
                    return this.radius < 0
                }
                makeEmpty() {
                    return this.center.set(0, 0, 0), this.radius = -1, this
                }
                containsPoint(t) {
                    return t.distanceToSquared(this.center) <= this.radius * this.radius
                }
                distanceToPoint(t) {
                    return t.distanceTo(this.center) - this.radius
                }
                intersectsSphere(t) {
                    let e = this.radius + t.radius;
                    return t.center.distanceToSquared(this.center) <= e * e
                }
                intersectsBox(t) {
                    return t.intersectsSphere(this)
                }
                intersectsPlane(t) {
                    return Math.abs(t.distanceToPoint(this.center)) <= this.radius
                }
                clampPoint(t, e) {
                    let i = this.center.distanceToSquared(t);
                    return e.copy(t), i > this.radius * this.radius && (e.sub(this.center).normalize(), e.multiplyScalar(this.radius).add(this.center)), e
                }
                getBoundingBox(t) {
                    return this.isEmpty() ? t.makeEmpty() : (t.set(this.center, this.center), t.expandByScalar(this.radius)), t
                }
                applyMatrix4(t) {
                    return this.center.applyMatrix4(t), this.radius = this.radius * t.getMaxScaleOnAxis(), this
                }
                translate(t) {
                    return this.center.add(t), this
                }
                expandByPoint(t) {
                    if (this.isEmpty()) return this.center.copy(t), this.radius = 0, this;
                    sP.subVectors(t, this.center);
                    let e = sP.lengthSq();
                    if (e > this.radius * this.radius) {
                        let t = Math.sqrt(e),
                            i = (t - this.radius) * .5;
                        this.center.addScaledVector(sP, i / t), this.radius += i
                    }
                    return this
                }
                union(t) {
                    return t.isEmpty() || (this.isEmpty() ? this.copy(t) : !0 === this.center.equals(t.center) ? this.radius = Math.max(this.radius, t.radius) : (sR.subVectors(t.center, this.center).setLength(t.radius), this.expandByPoint(sP.copy(t.center).add(sR)), this.expandByPoint(sP.copy(t.center).sub(sR)))), this
                }
                equals(t) {
                    return t.center.equals(this.center) && t.radius === this.radius
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                toJSON() {
                    return {
                        radius: this.radius,
                        center: this.center.toArray()
                    }
                }
                fromJSON(t) {
                    return this.radius = t.radius, this.center.fromArray(t.center), this
                }
            }
            let sE = 0,
                sF = new iw,
                sL = new iY,
                sj = new e9,
                sD = new sc,
                sW = new sc,
                sU = new e9;
            class sJ extends eZ {
                constructor() {
                    super(), this.isBufferGeometry = !0, Object.defineProperty(this, "id", {
                        value: sE++
                    }), this.uuid = eK(), this.name = "", this.type = "BufferGeometry", this.index = null, this.indirect = null, this.indirectOffset = 0, this.attributes = {}, this.morphAttributes = {}, this.morphTargetsRelative = !1, this.groups = [], this.boundingBox = null, this.boundingSphere = null, this.drawRange = {
                        start: 0,
                        count: 1 / 0
                    }, this.userData = {}, this._transformed = !1
                }
                getIndex() {
                    return this.index
                }
                setIndex(t) {
                    return Array.isArray(t) ? this.index = new(! function(t) {
                        for (let e = t.length - 1; e >= 0; --e)
                            if (t[e] >= 65535) return !0;
                        return !1
                    }(t) ? sB : sO)(t, 1) : this.index = t, this
                }
                setIndirect(t, e = 0) {
                    return this.indirect = t, this.indirectOffset = e, this
                }
                getIndirect() {
                    return this.indirect
                }
                getAttribute(t) {
                    return this.attributes[t]
                }
                setAttribute(t, e) {
                    return this.attributes[t] = e, this
                }
                deleteAttribute(t) {
                    return delete this.attributes[t], this
                }
                hasAttribute(t) {
                    return void 0 !== this.attributes[t]
                }
                addGroup(t, e, i = 0) {
                    this.groups.push({
                        start: t,
                        count: e,
                        materialIndex: i
                    })
                }
                clearGroups() {
                    this.groups = []
                }
                setDrawRange(t, e) {
                    this.drawRange.start = t, this.drawRange.count = e
                }
                applyMatrix4(t) {
                    let e = this.attributes.position;
                    void 0 !== e && (e.applyMatrix4(t), e.needsUpdate = !0);
                    let i = this.attributes.normal;
                    if (void 0 !== i) {
                        let e = new ie().getNormalMatrix(t);
                        i.applyNormalMatrix(e), i.needsUpdate = !0
                    }
                    let s = this.attributes.tangent;
                    return void 0 !== s && (s.transformDirection(t), s.needsUpdate = !0), null !== this.boundingBox && this.computeBoundingBox(), null !== this.boundingSphere && this.computeBoundingSphere(), this._transformed = !0, this
                }
                applyQuaternion(t) {
                    return sF.makeRotationFromQuaternion(t), this.applyMatrix4(sF), this
                }
                rotateX(t) {
                    return sF.makeRotationX(t), this.applyMatrix4(sF), this
                }
                rotateY(t) {
                    return sF.makeRotationY(t), this.applyMatrix4(sF), this
                }
                rotateZ(t) {
                    return sF.makeRotationZ(t), this.applyMatrix4(sF), this
                }
                translate(t, e, i) {
                    return sF.makeTranslation(t, e, i), this.applyMatrix4(sF), this
                }
                scale(t, e, i) {
                    return sF.makeScale(t, e, i), this.applyMatrix4(sF), this
                }
                lookAt(t) {
                    return sL.lookAt(t), sL.updateMatrix(), this.applyMatrix4(sL.matrix), this
                }
                center() {
                    return this.computeBoundingBox(), this.boundingBox.getCenter(sj).negate(), this.translate(sj.x, sj.y, sj.z), this
                }
                setFromPoints(t) {
                    let e = this.getAttribute("position");
                    if (void 0 === e) {
                        let e = [];
                        for (let i = 0, s = t.length; i < s; i++) {
                            let s = t[i];
                            e.push(s.x, s.y, s.z || 0)
                        }
                        this.setAttribute("position", new sI(e, 3))
                    } else {
                        let i = Math.min(t.length, e.count);
                        for (let s = 0; s < i; s++) {
                            let i = t[s];
                            e.setXYZ(s, i.x, i.y, i.z || 0)
                        }
                        t.length > e.count && eU("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."), e.needsUpdate = !0
                    }
                    return this
                }
                computeBoundingBox() {
                    null === this.boundingBox && (this.boundingBox = new sc);
                    let t = this.attributes.position,
                        e = this.morphAttributes.position;
                    if (t && t.isGLBufferAttribute) {
                        eJ("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.", this), this.boundingBox.set(new e9(-1 / 0, -1 / 0, -1 / 0), new e9(Infinity, Infinity, Infinity));
                        return
                    }
                    if (void 0 !== t) {
                        if (this.boundingBox.setFromBufferAttribute(t), e)
                            for (let t = 0, i = e.length; t < i; t++) {
                                let i = e[t];
                                sD.setFromBufferAttribute(i), this.morphTargetsRelative ? (sU.addVectors(this.boundingBox.min, sD.min), this.boundingBox.expandByPoint(sU), sU.addVectors(this.boundingBox.max, sD.max), this.boundingBox.expandByPoint(sU)) : (this.boundingBox.expandByPoint(sD.min), this.boundingBox.expandByPoint(sD.max))
                            }
                    } else this.boundingBox.makeEmpty();
                    (isNaN(this.boundingBox.min.x) || isNaN(this.boundingBox.min.y) || isNaN(this.boundingBox.min.z)) && eJ('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.', this)
                }
                computeBoundingSphere() {
                    null === this.boundingSphere && (this.boundingSphere = new sV);
                    let t = this.attributes.position,
                        e = this.morphAttributes.position;
                    if (t && t.isGLBufferAttribute) {
                        eJ("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.", this), this.boundingSphere.set(new e9, 1 / 0);
                        return
                    }
                    if (t) {
                        let i = this.boundingSphere.center;
                        if (sD.setFromBufferAttribute(t), e)
                            for (let t = 0, i = e.length; t < i; t++) {
                                let i = e[t];
                                sW.setFromBufferAttribute(i), this.morphTargetsRelative ? (sU.addVectors(sD.min, sW.min), sD.expandByPoint(sU), sU.addVectors(sD.max, sW.max), sD.expandByPoint(sU)) : (sD.expandByPoint(sW.min), sD.expandByPoint(sW.max))
                            }
                        sD.getCenter(i);
                        let s = 0;
                        for (let e = 0, r = t.count; e < r; e++) sU.fromBufferAttribute(t, e), s = Math.max(s, i.distanceToSquared(sU));
                        if (e)
                            for (let r = 0, n = e.length; r < n; r++) {
                                let n = e[r],
                                    a = this.morphTargetsRelative;
                                for (let e = 0, r = n.count; e < r; e++) sU.fromBufferAttribute(n, e), a && (sj.fromBufferAttribute(t, e), sU.add(sj)), s = Math.max(s, i.distanceToSquared(sU))
                            }
                        this.boundingSphere.radius = Math.sqrt(s), isNaN(this.boundingSphere.radius) && eJ('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.', this)
                    }
                }
                computeTangents() {
                    let t = this.index,
                        e = this.attributes;
                    if (null === t || void 0 === e.position || void 0 === e.normal || void 0 === e.uv) return void eJ("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");
                    let i = e.position,
                        s = e.normal,
                        r = e.uv,
                        n = this.getAttribute("tangent");
                    (void 0 === n || n.count !== i.count) && (n = new sk(new Float32Array(4 * i.count), 4), this.setAttribute("tangent", n));
                    let a = [],
                        h = [];
                    for (let t = 0; t < i.count; t++) a[t] = new e9, h[t] = new e9;
                    let o = new e9,
                        l = new e9,
                        u = new e9,
                        c = new e6,
                        p = new e6,
                        d = new e6,
                        m = new e9,
                        y = new e9,
                        f = this.groups;
                    0 === f.length && (f = [{
                        start: 0,
                        count: t.count
                    }]);
                    for (let e = 0, s = f.length; e < s; ++e) {
                        let s = f[e],
                            n = s.start,
                            g = s.count;
                        for (let e = n, s = n + g; e < s; e += 3) ! function(t, e, s) {
                            o.fromBufferAttribute(i, t), l.fromBufferAttribute(i, e), u.fromBufferAttribute(i, s), c.fromBufferAttribute(r, t), p.fromBufferAttribute(r, e), d.fromBufferAttribute(r, s), l.sub(o), u.sub(o), p.sub(c), d.sub(c);
                            let n = 1 / (p.x * d.y - d.x * p.y);
                            isFinite(n) && (m.copy(l).multiplyScalar(d.y).addScaledVector(u, -p.y).multiplyScalar(n), y.copy(u).multiplyScalar(p.x).addScaledVector(l, -d.x).multiplyScalar(n), a[t].add(m), a[e].add(m), a[s].add(m), h[t].add(y), h[e].add(y), h[s].add(y))
                        }(t.getX(e + 0), t.getX(e + 1), t.getX(e + 2))
                    }
                    let g = new e9,
                        x = new e9,
                        v = new e9,
                        M = new e9;

                    function b(t) {
                        v.fromBufferAttribute(s, t), M.copy(v);
                        let e = a[t];
                        g.copy(e), g.sub(v.multiplyScalar(v.dot(e))).normalize(), x.crossVectors(M, e);
                        let i = x.dot(h[t]);
                        n.setXYZW(t, g.x, g.y, g.z, i < 0 ? -1 : 1)
                    }
                    for (let e = 0, i = f.length; e < i; ++e) {
                        let i = f[e],
                            s = i.start,
                            r = i.count;
                        for (let e = s, i = s + r; e < i; e += 3) b(t.getX(e + 0)), b(t.getX(e + 1)), b(t.getX(e + 2))
                    }
                    this._transformed = !0
                }
                computeVertexNormals() {
                    let t = this.index,
                        e = this.getAttribute("position");
                    if (void 0 !== e) {
                        let i = this.getAttribute("normal");
                        if (void 0 === i || i.count !== e.count) i = new sk(new Float32Array(3 * e.count), 3), this.setAttribute("normal", i);
                        else
                            for (let t = 0, e = i.count; t < e; t++) i.setXYZ(t, 0, 0, 0);
                        let s = new e9,
                            r = new e9,
                            n = new e9,
                            a = new e9,
                            h = new e9,
                            o = new e9,
                            l = new e9,
                            u = new e9;
                        if (t)
                            for (let c = 0, p = t.count; c < p; c += 3) {
                                let p = t.getX(c + 0),
                                    d = t.getX(c + 1),
                                    m = t.getX(c + 2);
                                s.fromBufferAttribute(e, p), r.fromBufferAttribute(e, d), n.fromBufferAttribute(e, m), l.subVectors(n, r), u.subVectors(s, r), l.cross(u), a.fromBufferAttribute(i, p), h.fromBufferAttribute(i, d), o.fromBufferAttribute(i, m), a.add(l), h.add(l), o.add(l), i.setXYZ(p, a.x, a.y, a.z), i.setXYZ(d, h.x, h.y, h.z), i.setXYZ(m, o.x, o.y, o.z)
                            } else
                                for (let t = 0, a = e.count; t < a; t += 3) s.fromBufferAttribute(e, t + 0), r.fromBufferAttribute(e, t + 1), n.fromBufferAttribute(e, t + 2), l.subVectors(n, r), u.subVectors(s, r), l.cross(u), i.setXYZ(t + 0, l.x, l.y, l.z), i.setXYZ(t + 1, l.x, l.y, l.z), i.setXYZ(t + 2, l.x, l.y, l.z);
                        this.normalizeNormals(), i.needsUpdate = !0
                    }
                }
                normalizeNormals() {
                    let t = this.attributes.normal;
                    for (let e = 0, i = t.count; e < i; e++) sU.fromBufferAttribute(t, e), sU.normalize(), t.setXYZ(e, sU.x, sU.y, sU.z)
                }
                toNonIndexed() {
                    function t(t, e) {
                        let i = t.array,
                            s = t.itemSize,
                            r = t.normalized,
                            n = new i.constructor(e.length * s),
                            a = 0,
                            h = 0;
                        for (let r = 0, o = e.length; r < o; r++) {
                            a = t.isInterleavedBufferAttribute ? e[r] * t.data.stride + t.offset : e[r] * s;
                            for (let t = 0; t < s; t++) n[h++] = i[a++]
                        }
                        return new sk(n, s, r)
                    }
                    if (null === this.index) return eU("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."), this;
                    let e = new sJ,
                        i = this.index.array,
                        s = this.attributes;
                    for (let r in s) {
                        let n = t(s[r], i);
                        e.setAttribute(r, n)
                    }
                    let r = this.morphAttributes;
                    for (let s in r) {
                        let n = [],
                            a = r[s];
                        for (let e = 0, s = a.length; e < s; e++) {
                            let s = t(a[e], i);
                            n.push(s)
                        }
                        e.morphAttributes[s] = n
                    }
                    e.morphTargetsRelative = this.morphTargetsRelative;
                    let n = this.groups;
                    for (let t = 0, i = n.length; t < i; t++) {
                        let i = n[t];
                        e.addGroup(i.start, i.count, i.materialIndex)
                    }
                    return e
                }
                toJSON() {
                    let t = {
                        metadata: {
                            version: 4.7,
                            type: "BufferGeometry",
                            generator: "BufferGeometry.toJSON"
                        }
                    };
                    if (t.uuid = this.uuid, t.type = void 0 !== this.parameters && !0 === this._transformed ? "BufferGeometry" : this.type, t.name = this.name, Object.keys(this.userData).length > 0 && (t.userData = this.userData), void 0 !== this.parameters && !0 !== this._transformed) {
                        let e = this.parameters;
                        for (let i in e) void 0 !== e[i] && (t[i] = e[i]);
                        return t
                    }
                    t.data = {
                        attributes: {}
                    };
                    let e = this.index;
                    null !== e && (t.data.index = {
                        type: e.array.constructor.name,
                        array: Array.prototype.slice.call(e.array)
                    });
                    let i = this.attributes;
                    for (let e in i) {
                        let s = i[e];
                        t.data.attributes[e] = s.toJSON(t.data)
                    }
                    let s = {},
                        r = !1;
                    for (let e in this.morphAttributes) {
                        let i = this.morphAttributes[e],
                            n = [];
                        for (let e = 0, s = i.length; e < s; e++) {
                            let s = i[e];
                            n.push(s.toJSON(t.data))
                        }
                        n.length > 0 && (s[e] = n, r = !0)
                    }
                    r && (t.data.morphAttributes = s, t.data.morphTargetsRelative = this.morphTargetsRelative);
                    let n = this.groups;
                    n.length > 0 && (t.data.groups = JSON.parse(JSON.stringify(n)));
                    let a = this.boundingSphere;
                    return null !== a && (t.data.boundingSphere = a.toJSON()), t
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                copy(t) {
                    this.index = null, this.attributes = {}, this.morphAttributes = {}, this.groups = [], this.boundingBox = null, this.boundingSphere = null;
                    let e = {};
                    this.name = t.name;
                    let i = t.index;
                    null !== i && this.setIndex(i.clone());
                    let s = t.attributes;
                    for (let t in s) {
                        let i = s[t];
                        this.setAttribute(t, i.clone(e))
                    }
                    let r = t.morphAttributes;
                    for (let t in r) {
                        let i = [],
                            s = r[t];
                        for (let t = 0, r = s.length; t < r; t++) i.push(s[t].clone(e));
                        this.morphAttributes[t] = i
                    }
                    this.morphTargetsRelative = t.morphTargetsRelative;
                    let n = t.groups;
                    for (let t = 0, e = n.length; t < e; t++) {
                        let e = n[t];
                        this.addGroup(e.start, e.count, e.materialIndex)
                    }
                    let a = t.boundingBox;
                    null !== a && (this.boundingBox = a.clone());
                    let h = t.boundingSphere;
                    return null !== h && (this.boundingSphere = h.clone()), this.drawRange.start = t.drawRange.start, this.drawRange.count = t.drawRange.count, this.userData = t.userData, this._transformed = t._transformed, this
                }
                dispose() {
                    this.dispatchEvent({
                        type: "dispose"
                    })
                }
            }
            class sq {
                constructor(t, e) {
                    this.isInterleavedBuffer = !0, this.array = t, this.stride = e, this.count = void 0 !== t ? t.length / e : 0, this.usage = 35044, this.updateRanges = [], this.version = 0, this.uuid = eK()
                }
                onUploadCallback() {}
                set needsUpdate(t) {
                    !0 === t && this.version++
                }
                setUsage(t) {
                    return this.usage = t, this
                }
                addUpdateRange(t, e) {
                    this.updateRanges.push({
                        start: t,
                        count: e
                    })
                }
                clearUpdateRanges() {
                    this.updateRanges.length = 0
                }
                copy(t) {
                    return this.array = new t.array.constructor(t.array), this.count = t.count, this.stride = t.stride, this.usage = t.usage, this
                }
                copyAt(t, e, i) {
                    t *= this.stride, i *= e.stride;
                    for (let s = 0, r = this.stride; s < r; s++) this.array[t + s] = e.array[i + s];
                    return this
                }
                set(t, e = 0) {
                    return this.array.set(t, e), this
                }
                clone(t) {
                    void 0 === t.arrayBuffers && (t.arrayBuffers = {}), void 0 === this.array.buffer._uuid && (this.array.buffer._uuid = eK()), void 0 === t.arrayBuffers[this.array.buffer._uuid] && (t.arrayBuffers[this.array.buffer._uuid] = this.array.slice(0).buffer);
                    let e = new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),
                        i = new this.constructor(e, this.stride);
                    return i.setUsage(this.usage), i
                }
                onUpload(t) {
                    return this.onUploadCallback = t, this
                }
                toJSON(t) {
                    void 0 === t.arrayBuffers && (t.arrayBuffers = {}), void 0 === this.array.buffer._uuid && (this.array.buffer._uuid = eK()), void 0 === t.arrayBuffers[this.array.buffer._uuid] && (t.arrayBuffers[this.array.buffer._uuid] = Array.from(new Uint32Array(this.array.buffer)));
                    let e = {
                        uuid: this.uuid,
                        buffer: this.array.buffer._uuid,
                        type: this.array.constructor.name,
                        stride: this.stride
                    };
                    return e.usage = this.usage, e
                }
            }
            let sH = new e9;
            class sX {
                constructor(t, e, i, s = !1) {
                    this.isInterleavedBufferAttribute = !0, this.name = "", this.data = t, this.itemSize = e, this.offset = i, this.normalized = s
                }
                get count() {
                    return this.data.count
                }
                get array() {
                    return this.data.array
                }
                set needsUpdate(t) {
                    this.data.needsUpdate = t
                }
                applyMatrix4(t) {
                    for (let e = 0, i = this.data.count; e < i; e++) sH.fromBufferAttribute(this, e), sH.applyMatrix4(t), this.setXYZ(e, sH.x, sH.y, sH.z);
                    return this
                }
                applyNormalMatrix(t) {
                    for (let e = 0, i = this.count; e < i; e++) sH.fromBufferAttribute(this, e), sH.applyNormalMatrix(t), this.setXYZ(e, sH.x, sH.y, sH.z);
                    return this
                }
                transformDirection(t) {
                    for (let e = 0, i = this.count; e < i; e++) sH.fromBufferAttribute(this, e), sH.transformDirection(t), this.setXYZ(e, sH.x, sH.y, sH.z);
                    return this
                }
                getComponent(t, e) {
                    let i = this.array[t * this.data.stride + this.offset + e];
                    return this.normalized && (i = e3(i, this.array)), i
                }
                setComponent(t, e, i) {
                    return this.normalized && (i = e5(i, this.array)), this.data.array[t * this.data.stride + this.offset + e] = i, this
                }
                setX(t, e) {
                    return this.normalized && (e = e5(e, this.array)), this.data.array[t * this.data.stride + this.offset] = e, this
                }
                setY(t, e) {
                    return this.normalized && (e = e5(e, this.array)), this.data.array[t * this.data.stride + this.offset + 1] = e, this
                }
                setZ(t, e) {
                    return this.normalized && (e = e5(e, this.array)), this.data.array[t * this.data.stride + this.offset + 2] = e, this
                }
                setW(t, e) {
                    return this.normalized && (e = e5(e, this.array)), this.data.array[t * this.data.stride + this.offset + 3] = e, this
                }
                getX(t) {
                    let e = this.data.array[t * this.data.stride + this.offset];
                    return this.normalized && (e = e3(e, this.array)), e
                }
                getY(t) {
                    let e = this.data.array[t * this.data.stride + this.offset + 1];
                    return this.normalized && (e = e3(e, this.array)), e
                }
                getZ(t) {
                    let e = this.data.array[t * this.data.stride + this.offset + 2];
                    return this.normalized && (e = e3(e, this.array)), e
                }
                getW(t) {
                    let e = this.data.array[t * this.data.stride + this.offset + 3];
                    return this.normalized && (e = e3(e, this.array)), e
                }
                setXY(t, e, i) {
                    return t = t * this.data.stride + this.offset, this.normalized && (e = e5(e, this.array), i = e5(i, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this
                }
                setXYZ(t, e, i, s) {
                    return t = t * this.data.stride + this.offset, this.normalized && (e = e5(e, this.array), i = e5(i, this.array), s = e5(s, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this.data.array[t + 2] = s, this
                }
                setXYZW(t, e, i, s, r) {
                    return t = t * this.data.stride + this.offset, this.normalized && (e = e5(e, this.array), i = e5(i, this.array), s = e5(s, this.array), r = e5(r, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this.data.array[t + 2] = s, this.data.array[t + 3] = r, this
                }
                clone(t) {
                    if (void 0 !== t) return void 0 === t.interleavedBuffers && (t.interleavedBuffers = {}), void 0 === t.interleavedBuffers[this.data.uuid] && (t.interleavedBuffers[this.data.uuid] = this.data.clone(t)), new sX(t.interleavedBuffers[this.data.uuid], this.itemSize, this.offset, this.normalized); {
                        eD("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");
                        let t = [];
                        for (let e = 0; e < this.count; e++) {
                            let i = e * this.data.stride + this.offset;
                            for (let e = 0; e < this.itemSize; e++) t.push(this.data.array[i + e])
                        }
                        return new sk(new this.array.constructor(t), this.itemSize, this.normalized)
                    }
                }
                toJSON(t) {
                    if (void 0 !== t) return void 0 === t.interleavedBuffers && (t.interleavedBuffers = {}), void 0 === t.interleavedBuffers[this.data.uuid] && (t.interleavedBuffers[this.data.uuid] = this.data.toJSON(t)), {
                        isInterleavedBufferAttribute: !0,
                        itemSize: this.itemSize,
                        data: this.data.uuid,
                        offset: this.offset,
                        normalized: this.normalized
                    }; {
                        eD("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");
                        let t = [];
                        for (let e = 0; e < this.count; e++) {
                            let i = e * this.data.stride + this.offset;
                            for (let e = 0; e < this.itemSize; e++) t.push(this.data.array[i + e])
                        }
                        return {
                            itemSize: this.itemSize,
                            type: this.array.constructor.name,
                            array: t,
                            normalized: this.normalized
                        }
                    }
                }
            }
            let sZ = new e9,
                sY = new e9,
                sG = new ie;
            class sQ {
                constructor(t = new e9(1, 0, 0), e = 0) {
                    this.isPlane = !0, this.normal = t, this.constant = e
                }
                set(t, e) {
                    return this.normal.copy(t), this.constant = e, this
                }
                setComponents(t, e, i, s) {
                    return this.normal.set(t, e, i), this.constant = s, this
                }
                setFromNormalAndCoplanarPoint(t, e) {
                    return this.normal.copy(t), this.constant = -e.dot(this.normal), this
                }
                setFromCoplanarPoints(t, e, i) {
                    let s = sZ.subVectors(i, e).cross(sY.subVectors(t, e)).normalize();
                    return this.setFromNormalAndCoplanarPoint(s, t), this
                }
                copy(t) {
                    return this.normal.copy(t.normal), this.constant = t.constant, this
                }
                normalize() {
                    let t = 1 / this.normal.length();
                    return this.normal.multiplyScalar(t), this.constant *= t, this
                }
                negate() {
                    return this.constant *= -1, this.normal.negate(), this
                }
                distanceToPoint(t) {
                    return this.normal.dot(t) + this.constant
                }
                distanceToSphere(t) {
                    return this.distanceToPoint(t.center) - t.radius
                }
                projectPoint(t, e) {
                    return e.copy(t).addScaledVector(this.normal, -this.distanceToPoint(t))
                }
                intersectLine(t, e, i = !0) {
                    let s = t.delta(sZ),
                        r = this.normal.dot(s);
                    if (0 === r) return 0 === this.distanceToPoint(t.start) ? e.copy(t.start) : null;
                    let n = -(t.start.dot(this.normal) + this.constant) / r;
                    return !0 === i && (n < 0 || n > 1) ? null : e.copy(t.start).addScaledVector(s, n)
                }
                intersectsLine(t) {
                    let e = this.distanceToPoint(t.start),
                        i = this.distanceToPoint(t.end);
                    return e < 0 && i > 0 || i < 0 && e > 0
                }
                intersectsBox(t) {
                    return t.intersectsPlane(this)
                }
                intersectsSphere(t) {
                    return t.intersectsPlane(this)
                }
                coplanarPoint(t) {
                    return t.copy(this.normal).multiplyScalar(-this.constant)
                }
                applyMatrix4(t, e) {
                    let i = e || sG.getNormalMatrix(t),
                        s = this.coplanarPoint(sZ).applyMatrix4(t),
                        r = this.normal.applyMatrix3(i).normalize();
                    return this.constant = -s.dot(r), this
                }
                translate(t) {
                    return this.constant -= t.dot(this.normal), this
                }
                equals(t) {
                    return t.normal.equals(this.normal) && t.constant === this.constant
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                toJSON() {
                    return {
                        normal: this.normal.toArray(),
                        constant: this.constant
                    }
                }
                fromJSON(t) {
                    return this.normal.fromArray(t.normal), this.constant = t.constant, this
                }
            }
            let s$ = 0;
            class sK extends eZ {
                constructor() {
                    super(), this.isMaterial = !0, Object.defineProperty(this, "id", {
                        value: s$++
                    }), this.uuid = eK(), this.name = "", this.type = "Material", this.blending = M, this.side = f, this.vertexColors = !1, this.opacity = 1, this.transparent = !1, this.alphaHash = !1, this.blendSrc = P, this.blendDst = R, this.blendEquation = z, this.blendSrcAlpha = null, this.blendDstAlpha = null, this.blendEquationAlpha = null, this.blendColor = new i3(0, 0, 0), this.blendAlpha = 0, this.depthFunc = Z, this.depthTest = !0, this.depthWrite = !0, this.stencilWriteMask = 255, this.stencilFunc = 519, this.stencilRef = 0, this.stencilFuncMask = 255, this.stencilFail = 7680, this.stencilZFail = 7680, this.stencilZPass = 7680, this.stencilWrite = !1, this.clippingPlanes = null, this.clipIntersection = !1, this.clipShadows = !1, this.shadowSide = null, this.colorWrite = !0, this.precision = null, this.polygonOffset = !1, this.polygonOffsetFactor = 0, this.polygonOffsetUnits = 0, this.dithering = !1, this.alphaToCoverage = !1, this.premultipliedAlpha = !1, this.forceSinglePass = !1, this.allowOverride = !0, this.visible = !0, this.toneMapped = !0, this.userData = {}, this.version = 0, this._alphaTest = 0
                }
                get alphaTest() {
                    return this._alphaTest
                }
                set alphaTest(t) {
                    this._alphaTest > 0 != t > 0 && this.version++, this._alphaTest = t
                }
                onBeforeRender() {}
                onBeforeCompile() {}
                customProgramCacheKey() {
                    return this.onBeforeCompile.toString()
                }
                setValues(t) {
                    if (void 0 !== t)
                        for (let e in t) {
                            let i = t[e];
                            if (void 0 === i) {
                                eU(`Material: parameter '${e}' has value of undefined.`);
                                continue
                            }
                            let s = this[e];
                            if (void 0 === s) {
                                eU(`Material: '${e}' is not a property of THREE.${this.type}.`);
                                continue
                            }
                            s && s.isColor ? s.set(i) : s && s.isVector2 && i && i.isVector2 || s && s.isEuler && i && i.isEuler || s && s.isVector3 && i && i.isVector3 ? s.copy(i) : this[e] = i
                        }
                }
                toJSON(t) {
                    let e = void 0 === t || "string" == typeof t;
                    e && (t = {
                        textures: {},
                        images: {}
                    });
                    let i = {
                        metadata: {
                            version: 4.7,
                            type: "Material",
                            generator: "Material.toJSON"
                        }
                    };

                    function s(t) {
                        let e = [];
                        for (let i in t) {
                            let s = t[i];
                            delete s.metadata, e.push(s)
                        }
                        return e
                    }
                    if (i.uuid = this.uuid, i.type = this.type, i.blending = this.blending, i.side = this.side, i.shadowSide = this.shadowSide, i.vertexColors = this.vertexColors, i.opacity = this.opacity, i.transparent = this.transparent, i.blendSrc = this.blendSrc, i.blendDst = this.blendDst, i.blendEquation = this.blendEquation, i.blendSrcAlpha = this.blendSrcAlpha, i.blendDstAlpha = this.blendDstAlpha, i.blendEquationAlpha = this.blendEquationAlpha, i.blendColor = this.blendColor.getHex(), i.blendAlpha = this.blendAlpha, i.depthFunc = this.depthFunc, i.depthTest = this.depthTest, i.depthWrite = this.depthWrite, i.colorWrite = this.colorWrite, i.clipIntersection = this.clipIntersection, i.clipShadows = this.clipShadows, i.stencilWriteMask = this.stencilWriteMask, i.stencilFunc = this.stencilFunc, i.stencilRef = this.stencilRef, i.stencilFuncMask = this.stencilFuncMask, i.stencilFail = this.stencilFail, i.stencilZFail = this.stencilZFail, i.stencilZPass = this.stencilZPass, i.stencilWrite = this.stencilWrite, i.polygonOffset = this.polygonOffset, i.polygonOffsetFactor = this.polygonOffsetFactor, i.polygonOffsetUnits = this.polygonOffsetUnits, i.dithering = this.dithering, i.alphaTest = this.alphaTest, i.alphaHash = this.alphaHash, i.alphaToCoverage = this.alphaToCoverage, i.premultipliedAlpha = this.premultipliedAlpha, i.forceSinglePass = this.forceSinglePass, i.allowOverride = this.allowOverride, i.visible = this.visible, i.toneMapped = this.toneMapped, i.name = this.name, this.color && this.color.isColor && (i.color = this.color.getHex()), void 0 !== this.roughness && (i.roughness = this.roughness), void 0 !== this.metalness && (i.metalness = this.metalness), void 0 !== this.sheen && (i.sheen = this.sheen), this.sheenColor && this.sheenColor.isColor && (i.sheenColor = this.sheenColor.getHex()), void 0 !== this.sheenRoughness && (i.sheenRoughness = this.sheenRoughness), this.emissive && this.emissive.isColor && (i.emissive = this.emissive.getHex()), void 0 !== this.emissiveIntensity && (i.emissiveIntensity = this.emissiveIntensity), this.specular && this.specular.isColor && (i.specular = this.specular.getHex()), void 0 !== this.specularIntensity && (i.specularIntensity = this.specularIntensity), this.specularColor && this.specularColor.isColor && (i.specularColor = this.specularColor.getHex()), void 0 !== this.shininess && (i.shininess = this.shininess), void 0 !== this.clearcoat && (i.clearcoat = this.clearcoat), void 0 !== this.clearcoatRoughness && (i.clearcoatRoughness = this.clearcoatRoughness), this.clearcoatMap && this.clearcoatMap.isTexture && (i.clearcoatMap = this.clearcoatMap.toJSON(t).uuid), this.clearcoatRoughnessMap && this.clearcoatRoughnessMap.isTexture && (i.clearcoatRoughnessMap = this.clearcoatRoughnessMap.toJSON(t).uuid), this.clearcoatNormalMap && this.clearcoatNormalMap.isTexture && (i.clearcoatNormalMap = this.clearcoatNormalMap.toJSON(t).uuid, i.clearcoatNormalScale = this.clearcoatNormalScale.toArray()), this.sheenColorMap && this.sheenColorMap.isTexture && (i.sheenColorMap = this.sheenColorMap.toJSON(t).uuid), this.sheenRoughnessMap && this.sheenRoughnessMap.isTexture && (i.sheenRoughnessMap = this.sheenRoughnessMap.toJSON(t).uuid), void 0 !== this.dispersion && (i.dispersion = this.dispersion), void 0 !== this.retroreflectivity && (i.retroreflectivity = this.retroreflectivity), void 0 !== this.iridescence && (i.iridescence = this.iridescence), void 0 !== this.iridescenceIOR && (i.iridescenceIOR = this.iridescenceIOR), void 0 !== this.iridescenceThicknessRange && (i.iridescenceThicknessRange = this.iridescenceThicknessRange), this.iridescenceMap && this.iridescenceMap.isTexture && (i.iridescenceMap = this.iridescenceMap.toJSON(t).uuid), this.iridescenceThicknessMap && this.iridescenceThicknessMap.isTexture && (i.iridescenceThicknessMap = this.iridescenceThicknessMap.toJSON(t).uuid), void 0 !== this.anisotropy && (i.anisotropy = this.anisotropy), void 0 !== this.anisotropyRotation && (i.anisotropyRotation = this.anisotropyRotation), this.anisotropyMap && this.anisotropyMap.isTexture && (i.anisotropyMap = this.anisotropyMap.toJSON(t).uuid), this.map && this.map.isTexture && (i.map = this.map.toJSON(t).uuid), this.matcap && this.matcap.isTexture && (i.matcap = this.matcap.toJSON(t).uuid), this.alphaMap && this.alphaMap.isTexture && (i.alphaMap = this.alphaMap.toJSON(t).uuid), this.lightMap && this.lightMap.isTexture && (i.lightMap = this.lightMap.toJSON(t).uuid, i.lightMapIntensity = this.lightMapIntensity), this.aoMap && this.aoMap.isTexture && (i.aoMap = this.aoMap.toJSON(t).uuid, i.aoMapIntensity = this.aoMapIntensity), this.bumpMap && this.bumpMap.isTexture && (i.bumpMap = this.bumpMap.toJSON(t).uuid, i.bumpScale = this.bumpScale), this.normalMap && this.normalMap.isTexture && (i.normalMap = this.normalMap.toJSON(t).uuid, i.normalMapType = this.normalMapType, i.normalScale = this.normalScale.toArray()), this.displacementMap && this.displacementMap.isTexture && (i.displacementMap = this.displacementMap.toJSON(t).uuid, i.displacementScale = this.displacementScale, i.displacementBias = this.displacementBias), this.roughnessMap && this.roughnessMap.isTexture && (i.roughnessMap = this.roughnessMap.toJSON(t).uuid), this.metalnessMap && this.metalnessMap.isTexture && (i.metalnessMap = this.metalnessMap.toJSON(t).uuid), this.emissiveMap && this.emissiveMap.isTexture && (i.emissiveMap = this.emissiveMap.toJSON(t).uuid), this.specularMap && this.specularMap.isTexture && (i.specularMap = this.specularMap.toJSON(t).uuid), this.specularIntensityMap && this.specularIntensityMap.isTexture && (i.specularIntensityMap = this.specularIntensityMap.toJSON(t).uuid), this.specularColorMap && this.specularColorMap.isTexture && (i.specularColorMap = this.specularColorMap.toJSON(t).uuid), this.envMap && this.envMap.isTexture && (i.envMap = this.envMap.toJSON(t).uuid, void 0 !== this.combine && (i.combine = this.combine)), void 0 !== this.envMapRotation && (i.envMapRotation = this.envMapRotation.toArray()), void 0 !== this.envMapIntensity && (i.envMapIntensity = this.envMapIntensity), void 0 !== this.reflectivity && (i.reflectivity = this.reflectivity), void 0 !== this.refractionRatio && (i.refractionRatio = this.refractionRatio), this.gradientMap && this.gradientMap.isTexture && (i.gradientMap = this.gradientMap.toJSON(t).uuid), void 0 !== this.transmission && (i.transmission = this.transmission), this.transmissionMap && this.transmissionMap.isTexture && (i.transmissionMap = this.transmissionMap.toJSON(t).uuid), void 0 !== this.thickness && (i.thickness = this.thickness), this.thicknessMap && this.thicknessMap.isTexture && (i.thicknessMap = this.thicknessMap.toJSON(t).uuid), void 0 !== this.attenuationDistance && (i.attenuationDistance = this.attenuationDistance), void 0 !== this.attenuationColor && (i.attenuationColor = this.attenuationColor.getHex()), void 0 !== this.size && (i.size = this.size), void 0 !== this.sizeAttenuation && (i.sizeAttenuation = this.sizeAttenuation), Array.isArray(this.clippingPlanes) && this.clippingPlanes.length > 0 && (i.clippingPlanes = this.clippingPlanes.map(t => t.toJSON())), void 0 !== this.rotation && (i.rotation = this.rotation), void 0 !== this.depthPacking && (i.depthPacking = this.depthPacking), void 0 !== this.linewidth && (i.linewidth = this.linewidth), void 0 !== this.linecap && (i.linecap = this.linecap), void 0 !== this.linejoin && (i.linejoin = this.linejoin), void 0 !== this.dashSize && (i.dashSize = this.dashSize), void 0 !== this.gapSize && (i.gapSize = this.gapSize), void 0 !== this.scale && (i.scale = this.scale), void 0 !== this.wireframe && (i.wireframe = this.wireframe), void 0 !== this.wireframeLinewidth && (i.wireframeLinewidth = this.wireframeLinewidth), void 0 !== this.wireframeLinecap && (i.wireframeLinecap = this.wireframeLinecap), void 0 !== this.wireframeLinejoin && (i.wireframeLinejoin = this.wireframeLinejoin), void 0 !== this.flatShading && (i.flatShading = this.flatShading), void 0 !== this.fog && (i.fog = this.fog), Object.keys(this.userData).length > 0 && (i.userData = this.userData), e) {
                        let e = s(t.textures),
                            r = s(t.images);
                        e.length > 0 && (i.textures = e), r.length > 0 && (i.images = r)
                    }
                    return i
                }
                fromJSON(t, e) {
                    if (void 0 !== t.uuid && (this.uuid = t.uuid), void 0 !== t.name && (this.name = t.name), void 0 !== t.color && void 0 !== this.color && this.color.setHex(t.color), void 0 !== t.roughness && (this.roughness = t.roughness), void 0 !== t.metalness && (this.metalness = t.metalness), void 0 !== t.sheen && (this.sheen = t.sheen), void 0 !== t.sheenColor && (this.sheenColor = new i3().setHex(t.sheenColor)), void 0 !== t.sheenRoughness && (this.sheenRoughness = t.sheenRoughness), void 0 !== t.emissive && void 0 !== this.emissive && this.emissive.setHex(t.emissive), void 0 !== t.specular && void 0 !== this.specular && this.specular.setHex(t.specular), void 0 !== t.specularIntensity && (this.specularIntensity = t.specularIntensity), void 0 !== t.specularColor && void 0 !== this.specularColor && this.specularColor.setHex(t.specularColor), void 0 !== t.shininess && (this.shininess = t.shininess), void 0 !== t.clearcoat && (this.clearcoat = t.clearcoat), void 0 !== t.clearcoatRoughness && (this.clearcoatRoughness = t.clearcoatRoughness), void 0 !== t.dispersion && (this.dispersion = t.dispersion), void 0 !== t.retroreflectivity && (this.retroreflectivity = t.retroreflectivity), void 0 !== t.iridescence && (this.iridescence = t.iridescence), void 0 !== t.iridescenceIOR && (this.iridescenceIOR = t.iridescenceIOR), void 0 !== t.iridescenceThicknessRange && (this.iridescenceThicknessRange = t.iridescenceThicknessRange), void 0 !== t.transmission && (this.transmission = t.transmission), void 0 !== t.thickness && (this.thickness = t.thickness), void 0 !== t.attenuationDistance && (this.attenuationDistance = t.attenuationDistance), void 0 !== t.attenuationColor && void 0 !== this.attenuationColor && this.attenuationColor.setHex(t.attenuationColor), void 0 !== t.anisotropy && (this.anisotropy = t.anisotropy), void 0 !== t.anisotropyRotation && (this.anisotropyRotation = t.anisotropyRotation), void 0 !== t.fog && (this.fog = t.fog), void 0 !== t.flatShading && (this.flatShading = t.flatShading), void 0 !== t.blending && (this.blending = t.blending), void 0 !== t.combine && (this.combine = t.combine), void 0 !== t.side && (this.side = t.side), void 0 !== t.shadowSide && (this.shadowSide = t.shadowSide), void 0 !== t.opacity && (this.opacity = t.opacity), void 0 !== t.transparent && (this.transparent = t.transparent), void 0 !== t.alphaTest && (this.alphaTest = t.alphaTest), void 0 !== t.alphaHash && (this.alphaHash = t.alphaHash), void 0 !== t.depthFunc && (this.depthFunc = t.depthFunc), void 0 !== t.depthTest && (this.depthTest = t.depthTest), void 0 !== t.depthWrite && (this.depthWrite = t.depthWrite), void 0 !== t.colorWrite && (this.colorWrite = t.colorWrite), void 0 !== t.clippingPlanes && (this.clippingPlanes = t.clippingPlanes.map(t => new sQ().fromJSON(t))), void 0 !== t.clipIntersection && (this.clipIntersection = t.clipIntersection), void 0 !== t.clipShadows && (this.clipShadows = t.clipShadows), void 0 !== t.depthPacking && (this.depthPacking = t.depthPacking), void 0 !== t.blendSrc && (this.blendSrc = t.blendSrc), void 0 !== t.blendDst && (this.blendDst = t.blendDst), void 0 !== t.blendEquation && (this.blendEquation = t.blendEquation), void 0 !== t.blendSrcAlpha && (this.blendSrcAlpha = t.blendSrcAlpha), void 0 !== t.blendDstAlpha && (this.blendDstAlpha = t.blendDstAlpha), void 0 !== t.blendEquationAlpha && (this.blendEquationAlpha = t.blendEquationAlpha), void 0 !== t.blendColor && void 0 !== this.blendColor && this.blendColor.setHex(t.blendColor), void 0 !== t.blendAlpha && (this.blendAlpha = t.blendAlpha), void 0 !== t.stencilWriteMask && (this.stencilWriteMask = t.stencilWriteMask), void 0 !== t.stencilFunc && (this.stencilFunc = t.stencilFunc), void 0 !== t.stencilRef && (this.stencilRef = t.stencilRef), void 0 !== t.stencilFuncMask && (this.stencilFuncMask = t.stencilFuncMask), void 0 !== t.stencilFail && (this.stencilFail = t.stencilFail), void 0 !== t.stencilZFail && (this.stencilZFail = t.stencilZFail), void 0 !== t.stencilZPass && (this.stencilZPass = t.stencilZPass), void 0 !== t.stencilWrite && (this.stencilWrite = t.stencilWrite), void 0 !== t.wireframe && (this.wireframe = t.wireframe), void 0 !== t.wireframeLinewidth && (this.wireframeLinewidth = t.wireframeLinewidth), void 0 !== t.wireframeLinecap && (this.wireframeLinecap = t.wireframeLinecap), void 0 !== t.wireframeLinejoin && (this.wireframeLinejoin = t.wireframeLinejoin), void 0 !== t.rotation && (this.rotation = t.rotation), void 0 !== t.linewidth && (this.linewidth = t.linewidth), void 0 !== t.linecap && (this.linecap = t.linecap), void 0 !== t.linejoin && (this.linejoin = t.linejoin), void 0 !== t.dashSize && (this.dashSize = t.dashSize), void 0 !== t.gapSize && (this.gapSize = t.gapSize), void 0 !== t.scale && (this.scale = t.scale), void 0 !== t.polygonOffset && (this.polygonOffset = t.polygonOffset), void 0 !== t.polygonOffsetFactor && (this.polygonOffsetFactor = t.polygonOffsetFactor), void 0 !== t.polygonOffsetUnits && (this.polygonOffsetUnits = t.polygonOffsetUnits), void 0 !== t.dithering && (this.dithering = t.dithering), void 0 !== t.alphaToCoverage && (this.alphaToCoverage = t.alphaToCoverage), void 0 !== t.premultipliedAlpha && (this.premultipliedAlpha = t.premultipliedAlpha), void 0 !== t.forceSinglePass && (this.forceSinglePass = t.forceSinglePass), void 0 !== t.allowOverride && (this.allowOverride = t.allowOverride), void 0 !== t.visible && (this.visible = t.visible), void 0 !== t.toneMapped && (this.toneMapped = t.toneMapped), void 0 !== t.userData && (this.userData = t.userData), void 0 !== t.vertexColors && ("number" == typeof t.vertexColors ? this.vertexColors = t.vertexColors > 0 : this.vertexColors = t.vertexColors), void 0 !== t.size && (this.size = t.size), void 0 !== t.sizeAttenuation && (this.sizeAttenuation = t.sizeAttenuation), void 0 !== t.map && (this.map = e[t.map] || null), void 0 !== t.matcap && (this.matcap = e[t.matcap] || null), void 0 !== t.alphaMap && (this.alphaMap = e[t.alphaMap] || null), void 0 !== t.bumpMap && (this.bumpMap = e[t.bumpMap] || null), void 0 !== t.bumpScale && (this.bumpScale = t.bumpScale), void 0 !== t.normalMap && (this.normalMap = e[t.normalMap] || null), void 0 !== t.normalMapType && (this.normalMapType = t.normalMapType), void 0 !== t.normalScale) {
                        let e = t.normalScale;
                        !1 === Array.isArray(e) && (e = [e, e]), this.normalScale = new e6().fromArray(e)
                    }
                    return void 0 !== t.displacementMap && (this.displacementMap = e[t.displacementMap] || null), void 0 !== t.displacementScale && (this.displacementScale = t.displacementScale), void 0 !== t.displacementBias && (this.displacementBias = t.displacementBias), void 0 !== t.roughnessMap && (this.roughnessMap = e[t.roughnessMap] || null), void 0 !== t.metalnessMap && (this.metalnessMap = e[t.metalnessMap] || null), void 0 !== t.emissiveMap && (this.emissiveMap = e[t.emissiveMap] || null), void 0 !== t.emissiveIntensity && (this.emissiveIntensity = t.emissiveIntensity), void 0 !== t.specularMap && (this.specularMap = e[t.specularMap] || null), void 0 !== t.specularIntensityMap && (this.specularIntensityMap = e[t.specularIntensityMap] || null), void 0 !== t.specularColorMap && (this.specularColorMap = e[t.specularColorMap] || null), void 0 !== t.envMap && (this.envMap = e[t.envMap] || null), void 0 !== t.envMapRotation && this.envMapRotation.fromArray(t.envMapRotation), void 0 !== t.envMapIntensity && (this.envMapIntensity = t.envMapIntensity), void 0 !== t.reflectivity && (this.reflectivity = t.reflectivity), void 0 !== t.refractionRatio && (this.refractionRatio = t.refractionRatio), void 0 !== t.lightMap && (this.lightMap = e[t.lightMap] || null), void 0 !== t.lightMapIntensity && (this.lightMapIntensity = t.lightMapIntensity), void 0 !== t.aoMap && (this.aoMap = e[t.aoMap] || null), void 0 !== t.aoMapIntensity && (this.aoMapIntensity = t.aoMapIntensity), void 0 !== t.gradientMap && (this.gradientMap = e[t.gradientMap] || null), void 0 !== t.clearcoatMap && (this.clearcoatMap = e[t.clearcoatMap] || null), void 0 !== t.clearcoatRoughnessMap && (this.clearcoatRoughnessMap = e[t.clearcoatRoughnessMap] || null), void 0 !== t.clearcoatNormalMap && (this.clearcoatNormalMap = e[t.clearcoatNormalMap] || null), void 0 !== t.clearcoatNormalScale && (this.clearcoatNormalScale = new e6().fromArray(t.clearcoatNormalScale)), void 0 !== t.iridescenceMap && (this.iridescenceMap = e[t.iridescenceMap] || null), void 0 !== t.iridescenceThicknessMap && (this.iridescenceThicknessMap = e[t.iridescenceThicknessMap] || null), void 0 !== t.transmissionMap && (this.transmissionMap = e[t.transmissionMap] || null), void 0 !== t.thicknessMap && (this.thicknessMap = e[t.thicknessMap] || null), void 0 !== t.anisotropyMap && (this.anisotropyMap = e[t.anisotropyMap] || null), void 0 !== t.sheenColorMap && (this.sheenColorMap = e[t.sheenColorMap] || null), void 0 !== t.sheenRoughnessMap && (this.sheenRoughnessMap = e[t.sheenRoughnessMap] || null), this
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                copy(t) {
                    this.name = t.name, this.blending = t.blending, this.side = t.side, this.vertexColors = t.vertexColors, this.opacity = t.opacity, this.transparent = t.transparent, this.blendSrc = t.blendSrc, this.blendDst = t.blendDst, this.blendEquation = t.blendEquation, this.blendSrcAlpha = t.blendSrcAlpha, this.blendDstAlpha = t.blendDstAlpha, this.blendEquationAlpha = t.blendEquationAlpha, this.blendColor.copy(t.blendColor), this.blendAlpha = t.blendAlpha, this.depthFunc = t.depthFunc, this.depthTest = t.depthTest, this.depthWrite = t.depthWrite, this.stencilWriteMask = t.stencilWriteMask, this.stencilFunc = t.stencilFunc, this.stencilRef = t.stencilRef, this.stencilFuncMask = t.stencilFuncMask, this.stencilFail = t.stencilFail, this.stencilZFail = t.stencilZFail, this.stencilZPass = t.stencilZPass, this.stencilWrite = t.stencilWrite;
                    let e = t.clippingPlanes,
                        i = null;
                    if (null !== e) {
                        let t = e.length;
                        i = Array(t);
                        for (let s = 0; s !== t; ++s) i[s] = e[s].clone()
                    }
                    return this.clippingPlanes = i, this.clipIntersection = t.clipIntersection, this.clipShadows = t.clipShadows, this.shadowSide = t.shadowSide, this.colorWrite = t.colorWrite, this.precision = t.precision, this.polygonOffset = t.polygonOffset, this.polygonOffsetFactor = t.polygonOffsetFactor, this.polygonOffsetUnits = t.polygonOffsetUnits, this.dithering = t.dithering, this.alphaTest = t.alphaTest, this.alphaHash = t.alphaHash, this.alphaToCoverage = t.alphaToCoverage, this.premultipliedAlpha = t.premultipliedAlpha, this.forceSinglePass = t.forceSinglePass, this.allowOverride = t.allowOverride, this.visible = t.visible, this.toneMapped = t.toneMapped, this.userData = JSON.parse(JSON.stringify(t.userData)), this
                }
                dispose() {
                    this.dispatchEvent({
                        type: "dispose"
                    })
                }
                set needsUpdate(t) {
                    !0 === t && this.version++
                }
            }
            class s0 extends sK {
                constructor(t) {
                    super(), this.isSpriteMaterial = !0, this.type = "SpriteMaterial", this.color = new i3(0xffffff), this.map = null, this.alphaMap = null, this.rotation = 0, this.sizeAttenuation = !0, this.transparent = !0, this.fog = !0, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.alphaMap = t.alphaMap, this.rotation = t.rotation, this.sizeAttenuation = t.sizeAttenuation, this.fog = t.fog, this
                }
            }
            let s1 = new e9,
                s2 = new e9,
                s3 = new e9,
                s5 = new e6,
                s4 = new e6,
                s6 = new iw,
                s8 = new e9,
                s9 = new e9,
                s7 = new e9,
                rt = new e6,
                re = new e6,
                ri = new e6;
            class rs extends iY {
                constructor(t = new s0) {
                    if (super(), this.isSprite = !0, this.type = "Sprite", void 0 === r) {
                        r = new sJ;
                        const t = new sq(new Float32Array([-.5, -.5, 0, 0, 0, .5, -.5, 0, 1, 0, .5, .5, 0, 1, 1, -.5, .5, 0, 0, 1]), 5);
                        r.setIndex([0, 1, 2, 0, 2, 3]), r.setAttribute("position", new sX(t, 3, 0, !1)), r.setAttribute("uv", new sX(t, 2, 3, !1))
                    }
                    this.geometry = r, this.material = t, this.center = new e6(.5, .5), this.count = 1
                }
                intersectsFrustum(t) {
                    return t.intersectsSprite(this)
                }
                raycast(t, e) {
                    let i, s;
                    null === t.camera && eJ('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'), s2.setFromMatrixScale(this.matrixWorld), s6.copy(t.camera.matrixWorld), this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse, this.matrixWorld), s3.setFromMatrixPosition(this.modelViewMatrix), t.camera.isPerspectiveCamera && !1 === this.material.sizeAttenuation && s2.multiplyScalar(-s3.z);
                    let r = this.material.rotation;
                    0 !== r && (s = Math.cos(r), i = Math.sin(r));
                    let n = this.center;
                    rr(s8.set(-.5, -.5, 0), s3, n, s2, i, s), rr(s9.set(.5, -.5, 0), s3, n, s2, i, s), rr(s7.set(.5, .5, 0), s3, n, s2, i, s), rt.set(0, 0), re.set(1, 0), ri.set(1, 1);
                    let a = t.ray.intersectTriangle(s8, s9, s7, !1, s1);
                    if (null === a && (rr(s9.set(-.5, .5, 0), s3, n, s2, i, s), re.set(0, 1), null === (a = t.ray.intersectTriangle(s8, s7, s9, !1, s1)))) return;
                    let h = t.ray.origin.distanceTo(s1);
                    h < t.near || h > t.far || e.push({
                        distance: h,
                        point: s1.clone(),
                        uv: su.getInterpolation(s1, s8, s9, s7, rt, re, ri, new e6),
                        face: null,
                        object: this
                    })
                }
                copy(t, e) {
                    return super.copy(t, e), void 0 !== t.center && this.center.copy(t.center), this.material = t.material, this
                }
            }

            function rr(t, e, i, s, r, n) {
                s5.subVectors(t, i).addScalar(.5).multiply(s), void 0 !== r ? (s4.x = n * s5.x - r * s5.y, s4.y = r * s5.x + n * s5.y) : s4.copy(s5), t.copy(e), t.x += s4.x, t.y += s4.y, t.applyMatrix4(s6)
            }
            let rn = new e9,
                ra = new e9,
                rh = new e9,
                ro = new e9;
            class rl {
                constructor(t = new e9, e = new e9(0, 0, -1)) {
                    this.origin = t, this.direction = e
                }
                set(t, e) {
                    return this.origin.copy(t), this.direction.copy(e), this
                }
                copy(t) {
                    return this.origin.copy(t.origin), this.direction.copy(t.direction), this
                }
                at(t, e) {
                    return e.copy(this.origin).addScaledVector(this.direction, t)
                }
                lookAt(t) {
                    return this.direction.copy(t).sub(this.origin).normalize(), this
                }
                recast(t) {
                    return this.origin.copy(this.at(t, rn)), this
                }
                closestPointToPoint(t, e) {
                    e.subVectors(t, this.origin);
                    let i = e.dot(this.direction);
                    return i < 0 ? e.copy(this.origin) : e.copy(this.origin).addScaledVector(this.direction, i)
                }
                distanceToPoint(t) {
                    return Math.sqrt(this.distanceSqToPoint(t))
                }
                distanceSqToPoint(t) {
                    let e = rn.subVectors(t, this.origin).dot(this.direction);
                    return e < 0 ? this.origin.distanceToSquared(t) : (rn.copy(this.origin).addScaledVector(this.direction, e), rn.distanceToSquared(t))
                }
                distanceSqToSegment(t, e, i, s) {
                    let r, n, a, h;
                    ra.copy(t).add(e).multiplyScalar(.5), rh.copy(e).sub(t).normalize(), ro.copy(this.origin).sub(ra);
                    let o = .5 * t.distanceTo(e),
                        l = -this.direction.dot(rh),
                        u = ro.dot(this.direction),
                        c = -ro.dot(rh),
                        p = ro.lengthSq(),
                        d = Math.abs(1 - l * l);
                    if (d > 0)
                        if (r = l * c - u, n = l * u - c, h = o * d, r >= 0)
                            if (n >= -h)
                                if (n <= h) {
                                    let t = 1 / d;
                                    r *= t, n *= t, a = r * (r + l * n + 2 * u) + n * (l * r + n + 2 * c) + p
                                } else a = -(r = Math.max(0, -(l * (n = o) + u))) * r + n * (n + 2 * c) + p;
                    else a = -(r = Math.max(0, -(l * (n = -o) + u))) * r + n * (n + 2 * c) + p;
                    else n <= -h ? (n = (r = Math.max(0, -(-l * o + u))) > 0 ? -o : Math.min(Math.max(-o, -c), o), a = -r * r + n * (n + 2 * c) + p) : n <= h ? (r = 0, a = (n = Math.min(Math.max(-o, -c), o)) * (n + 2 * c) + p) : (n = (r = Math.max(0, -(l * o + u))) > 0 ? o : Math.min(Math.max(-o, -c), o), a = -r * r + n * (n + 2 * c) + p);
                    else n = l > 0 ? -o : o, a = -(r = Math.max(0, -(l * n + u))) * r + n * (n + 2 * c) + p;
                    return i && i.copy(this.origin).addScaledVector(this.direction, r), s && s.copy(ra).addScaledVector(rh, n), a
                }
                intersectSphere(t, e) {
                    if (t.radius < 0) return null;
                    rn.subVectors(t.center, this.origin);
                    let i = rn.dot(this.direction),
                        s = rn.dot(rn) - i * i,
                        r = t.radius * t.radius;
                    if (s > r) return null;
                    let n = Math.sqrt(r - s),
                        a = i - n,
                        h = i + n;
                    return h < 0 ? null : a < 0 ? this.at(h, e) : this.at(a, e)
                }
                intersectsSphere(t) {
                    return !(t.radius < 0) && this.distanceSqToPoint(t.center) <= t.radius * t.radius
                }
                distanceToPlane(t) {
                    let e = t.normal.dot(this.direction);
                    if (0 === e) return 0 === t.distanceToPoint(this.origin) ? 0 : null;
                    let i = -(this.origin.dot(t.normal) + t.constant) / e;
                    return i >= 0 ? i : null
                }
                intersectPlane(t, e) {
                    let i = this.distanceToPlane(t);
                    return null === i ? null : this.at(i, e)
                }
                intersectsPlane(t) {
                    let e = t.distanceToPoint(this.origin);
                    return !!(0 === e || t.normal.dot(this.direction) * e < 0)
                }
                intersectBox(t, e) {
                    let i, s, r, n, a, h, o = 1 / this.direction.x,
                        l = 1 / this.direction.y,
                        u = 1 / this.direction.z,
                        c = this.origin;
                    return (o >= 0 ? (i = (t.min.x - c.x) * o, s = (t.max.x - c.x) * o) : (i = (t.max.x - c.x) * o, s = (t.min.x - c.x) * o), l >= 0 ? (r = (t.min.y - c.y) * l, n = (t.max.y - c.y) * l) : (r = (t.max.y - c.y) * l, n = (t.min.y - c.y) * l), i > n || r > s || ((r > i || isNaN(i)) && (i = r), (n < s || isNaN(s)) && (s = n), u >= 0 ? (a = (t.min.z - c.z) * u, h = (t.max.z - c.z) * u) : (a = (t.max.z - c.z) * u, h = (t.min.z - c.z) * u), i > h || a > s || ((a > i || i != i) && (i = a), (h < s || s != s) && (s = h), s < 0))) ? null : this.at(i >= 0 ? i : s, e)
                }
                intersectsBox(t) {
                    return null !== this.intersectBox(t, rn)
                }
                intersectTriangle(t, e, i, s, r) {
                    let n, a, h, o, l, u, c, p, d, m, y, f, g = this.origin,
                        x = this.direction,
                        v = x.x,
                        M = x.y,
                        b = x.z,
                        w = t.x - g.x,
                        S = t.y - g.y,
                        _ = t.z - g.z,
                        z = e.x - g.x,
                        A = e.y - g.y,
                        T = e.z - g.z,
                        C = i.x - g.x,
                        k = i.y - g.y,
                        B = i.z - g.z,
                        O = Math.abs(v),
                        I = Math.abs(M),
                        N = Math.abs(b);
                    if (O >= I && O >= N ? (h = v, u = w, d = z, f = C, v >= 0 ? (n = M, a = b, o = S, l = _, c = A, p = T, m = k, y = B) : (n = b, a = M, o = _, l = S, c = T, p = A, m = B, y = k)) : I >= N ? (h = M, u = S, d = A, f = k, M >= 0 ? (n = b, a = v, o = _, l = w, c = T, p = z, m = B, y = C) : (n = v, a = b, o = w, l = _, c = z, p = T, m = C, y = B)) : (h = b, u = _, d = T, f = B, b >= 0 ? (n = v, a = M, o = w, l = S, c = z, p = A, m = C, y = k) : (n = M, a = v, o = S, l = w, c = A, p = z, m = k, y = C)), 0 === h) return null;
                    let P = n / h,
                        R = a / h,
                        V = 1 / h,
                        E = o - P * u,
                        F = l - R * u,
                        L = c - P * d,
                        j = p - R * d,
                        D = m - P * f,
                        W = y - R * f,
                        U = D * j - W * L,
                        J = E * W - F * D,
                        q = L * F - j * E;
                    if (s) {
                        if (U < 0 || J < 0 || q < 0) return null
                    } else if ((U < 0 || J < 0 || q < 0) && (U > 0 || J > 0 || q > 0)) return null;
                    let H = U + J + q;
                    if (0 === H) return null;
                    let X = V * (U * u + J * d + q * f);
                    return (H > 0 ? X < 0 : X > 0) ? null : this.at(X / H, r)
                }
                applyMatrix4(t) {
                    return this.origin.applyMatrix4(t), this.direction.transformDirection(t), this
                }
                equals(t) {
                    return t.origin.equals(this.origin) && t.direction.equals(this.direction)
                }
                clone() {
                    return new this.constructor().copy(this)
                }
            }
            class ru extends sK {
                constructor(t) {
                    super(), this.isMeshBasicMaterial = !0, this.type = "MeshBasicMaterial", this.color = new i3(0xffffff), this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new iI, this.combine = K, this.reflectivity = 1, this.refractionRatio = .98, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.fog = !0, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.combine = t.combine, this.reflectivity = t.reflectivity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.fog = t.fog, this
                }
            }
            let rc = new iw,
                rp = new rl,
                rd = new sV,
                rm = new e9,
                ry = new e9,
                rf = new e9,
                rg = new e9,
                rx = new e9,
                rv = new e9,
                rM = new e9,
                rb = new e9;
            class rw extends iY {
                constructor(t = new sJ, e = new ru) {
                    super(), this.isMesh = !0, this.type = "Mesh", this.geometry = t, this.material = e, this.morphTargetDictionary = void 0, this.morphTargetInfluences = void 0, this.count = 1, this.updateMorphTargets()
                }
                copy(t, e) {
                    return super.copy(t, e), void 0 !== t.morphTargetInfluences && (this.morphTargetInfluences = t.morphTargetInfluences.slice()), void 0 !== t.morphTargetDictionary && (this.morphTargetDictionary = Object.assign({}, t.morphTargetDictionary)), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this
                }
                updateMorphTargets() {
                    let t = this.geometry.morphAttributes,
                        e = Object.keys(t);
                    if (e.length > 0) {
                        let i = t[e[0]];
                        if (void 0 !== i) {
                            this.morphTargetInfluences = [], this.morphTargetDictionary = {};
                            for (let t = 0, e = i.length; t < e; t++) {
                                let e = i[t].name || String(t);
                                this.morphTargetInfluences.push(0), this.morphTargetDictionary[e] = t
                            }
                        }
                    }
                }
                getVertexPosition(t, e) {
                    let i = this.geometry,
                        s = i.attributes.position,
                        r = i.morphAttributes.position,
                        n = i.morphTargetsRelative;
                    e.fromBufferAttribute(s, t);
                    let a = this.morphTargetInfluences;
                    if (r && a) {
                        rv.set(0, 0, 0);
                        for (let i = 0, s = r.length; i < s; i++) {
                            let s = a[i],
                                h = r[i];
                            0 !== s && (rx.fromBufferAttribute(h, t), n ? rv.addScaledVector(rx, s) : rv.addScaledVector(rx.sub(e), s))
                        }
                        e.add(rv)
                    }
                    return e
                }
                intersectsFrustum(t) {
                    return t.intersectsObject(this)
                }
                raycast(t, e) {
                    let i = this.geometry,
                        s = this.material,
                        r = this.matrixWorld;
                    void 0 === s || (null === i.boundingSphere && i.computeBoundingSphere(), rd.copy(i.boundingSphere), rd.applyMatrix4(r), rp.copy(t.ray).recast(t.near), !1 === rd.containsPoint(rp.origin) && (null === rp.intersectSphere(rd, rm) || rp.origin.distanceToSquared(rm) > (t.far - t.near) ** 2) || (rc.copy(r).invert(), rp.copy(t.ray).applyMatrix4(rc), (null === i.boundingBox || !1 !== rp.intersectsBox(i.boundingBox)) && this._computeIntersections(t, e, rp)))
                }
                _computeIntersections(t, e, i) {
                    let s, r = this.geometry,
                        n = this.material,
                        a = r.index,
                        h = r.attributes.position,
                        o = r.attributes.uv,
                        l = r.attributes.uv1,
                        u = r.attributes.normal,
                        c = r.groups,
                        p = r.drawRange;
                    if (null !== a)
                        if (Array.isArray(n))
                            for (let r = 0, h = c.length; r < h; r++) {
                                let h = c[r],
                                    d = n[h.materialIndex],
                                    m = Math.max(h.start, p.start),
                                    y = Math.min(a.count, Math.min(h.start + h.count, p.start + p.count));
                                for (let r = m; r < y; r += 3)(s = rS(this, d, t, i, o, l, u, a.getX(r), a.getX(r + 1), a.getX(r + 2))) && (s.faceIndex = Math.floor(r / 3), s.face.materialIndex = h.materialIndex, e.push(s))
                            } else {
                                let r = Math.max(0, p.start),
                                    h = Math.min(a.count, p.start + p.count);
                                for (let c = r; c < h; c += 3)(s = rS(this, n, t, i, o, l, u, a.getX(c), a.getX(c + 1), a.getX(c + 2))) && (s.faceIndex = Math.floor(c / 3), e.push(s))
                            } else if (void 0 !== h)
                                if (Array.isArray(n))
                                    for (let r = 0, a = c.length; r < a; r++) {
                                        let a = c[r],
                                            d = n[a.materialIndex],
                                            m = Math.max(a.start, p.start),
                                            y = Math.min(h.count, Math.min(a.start + a.count, p.start + p.count));
                                        for (let r = m; r < y; r += 3)(s = rS(this, d, t, i, o, l, u, r, r + 1, r + 2)) && (s.faceIndex = Math.floor(r / 3), s.face.materialIndex = a.materialIndex, e.push(s))
                                    } else {
                                        let r = Math.max(0, p.start),
                                            a = Math.min(h.count, p.start + p.count);
                                        for (let h = r; h < a; h += 3)(s = rS(this, n, t, i, o, l, u, h, h + 1, h + 2)) && (s.faceIndex = Math.floor(h / 3), e.push(s))
                                    }
                }
            }

            function rS(t, e, i, s, r, n, a, h, o, l) {
                t.getVertexPosition(h, ry), t.getVertexPosition(o, rf), t.getVertexPosition(l, rg);
                let u = function(t, e, i, s, r, n, a, h) {
                    if (null === (e.side === g ? s.intersectTriangle(a, n, r, !0, h) : s.intersectTriangle(r, n, a, e.side === f, h))) return null;
                    rb.copy(h), rb.applyMatrix4(t.matrixWorld);
                    let o = i.ray.origin.distanceTo(rb);
                    return o < i.near || o > i.far ? null : {
                        distance: o,
                        point: rb.clone(),
                        object: t
                    }
                }(t, e, i, s, ry, rf, rg, rM);
                if (u) {
                    let t = new e9;
                    su.getBarycoord(rM, ry, rf, rg, t), r && (u.uv = su.getInterpolatedAttribute(r, h, o, l, t, new e6)), n && (u.uv1 = su.getInterpolatedAttribute(n, h, o, l, t, new e6)), a && (u.normal = su.getInterpolatedAttribute(a, h, o, l, t, new e9), u.normal.dot(s.direction) > 0 && u.normal.multiplyScalar(-1));
                    let e = {
                        a: h,
                        b: o,
                        c: l,
                        normal: new e9,
                        materialIndex: 0
                    };
                    su.getNormal(ry, rf, rg, e.normal), u.face = e, u.barycoord = t
                }
                return u
            }
            let r_ = new ig,
                rz = new ig,
                rA = new ig,
                rT = new ig,
                rC = new iw,
                rk = new e9,
                rB = new sV,
                rO = new iw,
                rI = new rl;
            class rN extends rw {
                constructor(t, e) {
                    super(t, e), this.isSkinnedMesh = !0, this.type = "SkinnedMesh", this.bindMode = tu, this.bindMatrix = new iw, this.bindMatrixInverse = new iw, this.boundingBox = null, this.boundingSphere = null
                }
                computeBoundingBox() {
                    let t = this.geometry;
                    null === this.boundingBox && (this.boundingBox = new sc), this.boundingBox.makeEmpty();
                    let e = t.getAttribute("position");
                    for (let t = 0; t < e.count; t++) this.getVertexPosition(t, rk), this.boundingBox.expandByPoint(rk)
                }
                computeBoundingSphere() {
                    let t = this.geometry;
                    null === this.boundingSphere && (this.boundingSphere = new sV), this.boundingSphere.makeEmpty();
                    let e = t.getAttribute("position");
                    for (let t = 0; t < e.count; t++) this.getVertexPosition(t, rk), this.boundingSphere.expandByPoint(rk)
                }
                copy(t, e) {
                    return super.copy(t, e), this.bindMode = t.bindMode, this.bindMatrix.copy(t.bindMatrix), this.bindMatrixInverse.copy(t.bindMatrixInverse), this.skeleton = t.skeleton, null !== t.boundingBox && (this.boundingBox = t.boundingBox.clone()), null !== t.boundingSphere && (this.boundingSphere = t.boundingSphere.clone()), this
                }
                raycast(t, e) {
                    let i = this.material,
                        s = this.matrixWorld;
                    void 0 === i || (null === this.boundingSphere && this.computeBoundingSphere(), rB.copy(this.boundingSphere), rB.applyMatrix4(s), !1 === t.ray.intersectsSphere(rB) || (rO.copy(s).invert(), rI.copy(t.ray).applyMatrix4(rO), (null === this.boundingBox || !1 !== rI.intersectsBox(this.boundingBox)) && this._computeIntersections(t, e, rI)))
                }
                getVertexPosition(t, e) {
                    return super.getVertexPosition(t, e), this.applyBoneTransform(t, e), e
                }
                bind(t, e) {
                    this.skeleton = t, void 0 === e && (this.updateMatrixWorld(!0), this.skeleton.calculateInverses(), e = this.matrixWorld), this.bindMatrix.copy(e), this.bindMatrixInverse.copy(e).invert()
                }
                pose() {
                    this.skeleton.pose()
                }
                normalizeSkinWeights() {
                    let t = new ig,
                        e = this.geometry.attributes.skinWeight;
                    for (let i = 0, s = e.count; i < s; i++) {
                        t.fromBufferAttribute(e, i);
                        let s = 1 / t.manhattanLength();
                        s !== 1 / 0 ? t.multiplyScalar(s) : t.set(1, 0, 0, 0), e.setXYZW(i, t.x, t.y, t.z, t.w)
                    }
                }
                updateMatrixWorld(t) {
                    super.updateMatrixWorld(t), this.bindMode === tu ? this.bindMatrixInverse.copy(this.matrixWorld).invert() : "detached" === this.bindMode ? this.bindMatrixInverse.copy(this.bindMatrix).invert() : eU("SkinnedMesh: Unrecognized bindMode: " + this.bindMode)
                }
                applyBoneTransform(t, e) {
                    let i = this.skeleton,
                        s = this.geometry;
                    rz.fromBufferAttribute(s.attributes.skinIndex, t), rA.fromBufferAttribute(s.attributes.skinWeight, t), e.isVector4 ? (r_.copy(e), e.set(0, 0, 0, 0)) : (r_.set(...e, 1), e.set(0, 0, 0)), r_.applyMatrix4(this.bindMatrix);
                    for (let t = 0; t < 4; t++) {
                        let s = rA.getComponent(t);
                        if (0 !== s) {
                            let r = rz.getComponent(t);
                            rC.multiplyMatrices(i.bones[r].matrixWorld, i.boneInverses[r]), e.addScaledVector(rT.copy(r_).applyMatrix4(rC), s)
                        }
                    }
                    return e.isVector4 && (e.w = r_.w), e.applyMatrix4(this.bindMatrixInverse)
                }
            }
            class rP extends iY {
                constructor() {
                    super(), this.isBone = !0, this.type = "Bone"
                }
            }
            class rR extends iy {
                constructor(t = null, e = 1, i = 1, s, r, n, a, h, o = tv, l = tv, u, c) {
                    super(null, n, a, h, o, l, s, r, u, c), this.isDataTexture = !0, this.image = {
                        data: t,
                        width: e,
                        height: i
                    }, this.generateMipmaps = !1, this.flipY = !1, this.unpackAlignment = 1
                }
            }
            let rV = new iw,
                rE = new iw;
            class rF {
                constructor(t = [], e = []) {
                    this.uuid = eK(), this.bones = t.slice(0), this.boneInverses = e, this.boneMatrices = null, this.boneTexture = null, this.init()
                }
                init() {
                    let t = this.bones,
                        e = this.boneInverses;
                    if (this.boneMatrices = new Float32Array(16 * t.length), 0 === e.length) this.calculateInverses();
                    else if (t.length !== e.length) {
                        eU("Skeleton: Number of inverse bone matrices does not match amount of bones."), this.boneInverses = [];
                        for (let t = 0, e = this.bones.length; t < e; t++) this.boneInverses.push(new iw)
                    }
                }
                calculateInverses() {
                    this.boneInverses.length = 0;
                    for (let t = 0, e = this.bones.length; t < e; t++) {
                        let e = new iw;
                        this.bones[t] && e.copy(this.bones[t].matrixWorld).invert(), this.boneInverses.push(e)
                    }
                }
                pose() {
                    for (let t = 0, e = this.bones.length; t < e; t++) {
                        let e = this.bones[t];
                        e && e.matrixWorld.copy(this.boneInverses[t]).invert()
                    }
                    for (let t = 0, e = this.bones.length; t < e; t++) {
                        let e = this.bones[t];
                        e && (e.parent && e.parent.isBone ? (e.matrix.copy(e.parent.matrixWorld).invert(), e.matrix.multiply(e.matrixWorld)) : e.matrix.copy(e.matrixWorld), e.matrix.decompose(e.position, e.quaternion, e.scale))
                    }
                }
                update() {
                    let t = this.bones,
                        e = this.boneInverses,
                        i = this.boneMatrices,
                        s = this.boneTexture;
                    for (let s = 0, r = t.length; s < r; s++) {
                        let r = t[s] ? t[s].matrixWorld : rE;
                        rV.multiplyMatrices(r, e[s]), rV.toArray(i, 16 * s)
                    }
                    null !== s && (s.needsUpdate = !0)
                }
                clone() {
                    return new rF(this.bones, this.boneInverses)
                }
                computeBoneTexture() {
                    let t = Math.sqrt(4 * this.bones.length),
                        e = new Float32Array((t = Math.max(t = 4 * Math.ceil(t / 4), 4)) * t * 4);
                    e.set(this.boneMatrices);
                    let i = new rR(e, t, t, tj, tO);
                    return i.needsUpdate = !0, this.boneMatrices = e, this.boneTexture = i, this
                }
                getBoneByName(t) {
                    for (let e = 0, i = this.bones.length; e < i; e++) {
                        let i = this.bones[e];
                        if (i.name === t) return i
                    }
                }
                dispose() {
                    null !== this.boneTexture && (this.boneTexture.dispose(), this.boneTexture = null)
                }
                fromJSON(t, e) {
                    this.uuid = t.uuid;
                    for (let i = 0, s = t.bones.length; i < s; i++) {
                        let s = t.bones[i],
                            r = e[s];
                        void 0 === r && (eU("Skeleton: No bone found with UUID:", s), r = new rP), this.bones.push(r), this.boneInverses.push(new iw().fromArray(t.boneInverses[i]))
                    }
                    return this.init(), this
                }
                toJSON() {
                    let t = {
                        metadata: {
                            version: 4.7,
                            type: "Skeleton",
                            generator: "Skeleton.toJSON"
                        },
                        bones: [],
                        boneInverses: []
                    };
                    t.uuid = this.uuid;
                    let e = this.bones,
                        i = this.boneInverses;
                    for (let s = 0, r = e.length; s < r; s++) {
                        let r = e[s];
                        t.bones.push(r.uuid);
                        let n = i[s];
                        t.boneInverses.push(n.toArray())
                    }
                    return t
                }
            }
            class rL extends sk {
                constructor(t, e, i, s = 1) {
                    super(t, e, i), this.isInstancedBufferAttribute = !0, this.meshPerAttribute = s
                }
                copy(t) {
                    return super.copy(t), this.meshPerAttribute = t.meshPerAttribute, this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.meshPerAttribute = this.meshPerAttribute, t.isInstancedBufferAttribute = !0, t
                }
            }
            let rj = new iw,
                rD = new iw,
                rW = [],
                rU = new sc,
                rJ = new iw,
                rq = new rw,
                rH = new sV;
            class rX extends rw {
                constructor(t, e, i) {
                    super(t, e), this.isInstancedMesh = !0, this.instanceMatrix = new rL(new Float32Array(16 * i), 16), this.instanceColor = null, this.morphTexture = null, this.count = i, this.boundingBox = null, this.boundingSphere = null;
                    for (let t = 0; t < i; t++) this.setMatrixAt(t, rJ)
                }
                computeBoundingBox() {
                    let t = this.geometry,
                        e = this.count;
                    null === this.boundingBox && (this.boundingBox = new sc), null === t.boundingBox && t.computeBoundingBox(), this.boundingBox.makeEmpty();
                    for (let i = 0; i < e; i++) this.getMatrixAt(i, rj), rU.copy(t.boundingBox).applyMatrix4(rj), this.boundingBox.union(rU)
                }
                computeBoundingSphere() {
                    let t = this.geometry,
                        e = this.count;
                    null === this.boundingSphere && (this.boundingSphere = new sV), null === t.boundingSphere && t.computeBoundingSphere(), this.boundingSphere.makeEmpty();
                    for (let i = 0; i < e; i++) this.getMatrixAt(i, rj), rH.copy(t.boundingSphere).applyMatrix4(rj), this.boundingSphere.union(rH)
                }
                copy(t, e) {
                    return super.copy(t, e), this.instanceMatrix.copy(t.instanceMatrix), null !== t.morphTexture && (this.morphTexture = t.morphTexture.clone()), null !== t.instanceColor && (this.instanceColor = t.instanceColor.clone()), this.count = t.count, null !== t.boundingBox && (this.boundingBox = t.boundingBox.clone()), null !== t.boundingSphere && (this.boundingSphere = t.boundingSphere.clone()), this
                }
                getColorAt(t, e) {
                    return null === this.instanceColor ? e.setRGB(1, 1, 1) : e.fromArray(this.instanceColor.array, 3 * t)
                }
                getMatrixAt(t, e) {
                    return e.fromArray(this.instanceMatrix.array, 16 * t)
                }
                getMorphAt(t, e) {
                    let i = e.morphTargetInfluences,
                        s = this.morphTexture.source.data.data,
                        r = t * (i.length + 1) + 1;
                    for (let t = 0; t < i.length; t++) i[t] = s[r + t]
                }
                raycast(t, e) {
                    let i = this.matrixWorld,
                        s = this.count;
                    if ((rq.geometry = this.geometry, rq.material = this.material, void 0 !== rq.material) && (null === this.boundingSphere && this.computeBoundingSphere(), rH.copy(this.boundingSphere), rH.applyMatrix4(i), !1 !== t.ray.intersectsSphere(rH)))
                        for (let r = 0; r < s; r++) {
                            this.getMatrixAt(r, rj), rD.multiplyMatrices(i, rj), rq.matrixWorld = rD, rq.raycast(t, rW);
                            for (let t = 0, i = rW.length; t < i; t++) {
                                let i = rW[t];
                                i.instanceId = r, i.object = this, e.push(i)
                            }
                            rW.length = 0
                        }
                }
                setColorAt(t, e) {
                    return null === this.instanceColor && (this.instanceColor = new rL(new Float32Array(3 * this.instanceMatrix.count).fill(1), 3)), e.toArray(this.instanceColor.array, 3 * t), this
                }
                setMatrixAt(t, e) {
                    return e.toArray(this.instanceMatrix.array, 16 * t), this
                }
                setMorphAt(t, e) {
                    let i = e.morphTargetInfluences,
                        s = i.length + 1;
                    null === this.morphTexture && (this.morphTexture = new rR(new Float32Array(s * this.count), s, this.count, tU, tO));
                    let r = this.morphTexture.source.data.data,
                        n = 0;
                    for (let t = 0; t < i.length; t++) n += i[t];
                    let a = this.geometry.morphTargetsRelative ? 1 : 1 - n,
                        h = s * t;
                    return r[h] = a, r.set(i, h + 1), this
                }
                updateMorphTargets() {}
                dispose() {
                    super.dispose(), null !== this.morphTexture && (this.morphTexture.dispose(), this.morphTexture = null)
                }
            }
            let rZ = new sV,
                rY = new e6(.5, .5),
                rG = new e9;
            class rQ {
                constructor(t = new sQ, e = new sQ, i = new sQ, s = new sQ, r = new sQ, n = new sQ) {
                    this.planes = [t, e, i, s, r, n]
                }
                set(t, e, i, s, r, n) {
                    let a = this.planes;
                    return a[0].copy(t), a[1].copy(e), a[2].copy(i), a[3].copy(s), a[4].copy(r), a[5].copy(n), this
                }
                copy(t) {
                    let e = this.planes;
                    for (let i = 0; i < 6; i++) e[i].copy(t.planes[i]);
                    return this
                }
                setFromProjectionMatrix(t, e = eE, i = !1) {
                    let s = this.planes,
                        r = t.elements,
                        n = r[0],
                        a = r[1],
                        h = r[2],
                        o = r[3],
                        l = r[4],
                        u = r[5],
                        c = r[6],
                        p = r[7],
                        d = r[8],
                        m = r[9],
                        y = r[10],
                        f = r[11],
                        g = r[12],
                        x = r[13],
                        v = r[14],
                        M = r[15];
                    if (s[0].setComponents(o - n, p - l, f - d, M - g).normalize(), s[1].setComponents(o + n, p + l, f + d, M + g).normalize(), s[2].setComponents(o + a, p + u, f + m, M + x).normalize(), s[3].setComponents(o - a, p - u, f - m, M - x).normalize(), i) s[4].setComponents(h, c, y, v).normalize(), s[5].setComponents(o - h, p - c, f - y, M - v).normalize();
                    else if (s[4].setComponents(o - h, p - c, f - y, M - v).normalize(), e === eE) s[5].setComponents(o + h, p + c, f + y, M + v).normalize();
                    else if (2001 === e) s[5].setComponents(h, c, y, v).normalize();
                    else throw Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: " + e);
                    return this
                }
                intersectsObject(t) {
                    if (void 0 !== t.boundingSphere) null === t.boundingSphere && t.computeBoundingSphere(), rZ.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);
                    else {
                        let e = t.geometry;
                        null === e.boundingSphere && e.computeBoundingSphere(), rZ.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)
                    }
                    return this.intersectsSphere(rZ)
                }
                intersectsSprite(t) {
                    return rZ.center.set(0, 0, 0), rZ.radius = .7071067811865476 + rY.distanceTo(t.center), rZ.applyMatrix4(t.matrixWorld), this.intersectsSphere(rZ)
                }
                intersectsSphere(t) {
                    let e = this.planes,
                        i = t.center,
                        s = -t.radius;
                    for (let t = 0; t < 6; t++)
                        if (e[t].distanceToPoint(i) < s) return !1;
                    return !0
                }
                intersectsBox(t) {
                    let e = this.planes;
                    for (let i = 0; i < 6; i++) {
                        let s = e[i];
                        if (rG.x = s.normal.x > 0 ? t.max.x : t.min.x, rG.y = s.normal.y > 0 ? t.max.y : t.min.y, rG.z = s.normal.z > 0 ? t.max.z : t.min.z, 0 > s.distanceToPoint(rG)) return !1
                    }
                    return !0
                }
                containsPoint(t) {
                    let e = this.planes;
                    for (let i = 0; i < 6; i++)
                        if (0 > e[i].distanceToPoint(t)) return !1;
                    return !0
                }
                clone() {
                    return new this.constructor().copy(this)
                }
            }
            class r$ extends sK {
                constructor(t) {
                    super(), this.isLineBasicMaterial = !0, this.type = "LineBasicMaterial", this.color = new i3(0xffffff), this.map = null, this.linewidth = 1, this.linecap = "round", this.linejoin = "round", this.fog = !0, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.linewidth = t.linewidth, this.linecap = t.linecap, this.linejoin = t.linejoin, this.fog = t.fog, this
                }
            }
            let rK = new e9,
                r0 = new e9,
                r1 = new iw,
                r2 = new rl,
                r3 = new sV,
                r5 = new e9,
                r4 = new e9;
            class r6 extends iY {
                constructor(t = new sJ, e = new r$) {
                    super(), this.isLine = !0, this.type = "Line", this.geometry = t, this.material = e, this.morphTargetDictionary = void 0, this.morphTargetInfluences = void 0, this.updateMorphTargets()
                }
                copy(t, e) {
                    return super.copy(t, e), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this
                }
                computeLineDistances() {
                    let t = this.geometry;
                    if (null === t.index) {
                        let e = t.attributes.position,
                            i = [0];
                        for (let t = 1, s = e.count; t < s; t++) rK.fromBufferAttribute(e, t - 1), r0.fromBufferAttribute(e, t), i[t] = i[t - 1], i[t] += rK.distanceTo(r0);
                        t.setAttribute("lineDistance", new sI(i, 1))
                    } else eU("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
                    return this
                }
                intersectsFrustum(t) {
                    return t.intersectsObject(this)
                }
                raycast(t, e) {
                    let i = this.geometry,
                        s = this.matrixWorld,
                        r = t.params.Line.threshold,
                        n = i.drawRange;
                    if (null === i.boundingSphere && i.computeBoundingSphere(), r3.copy(i.boundingSphere), r3.applyMatrix4(s), r3.radius += r, !1 === t.ray.intersectsSphere(r3)) return;
                    r1.copy(s).invert(), r2.copy(t.ray).applyMatrix4(r1);
                    let a = r / ((this.scale.x + this.scale.y + this.scale.z) / 3),
                        h = a * a,
                        o = this.isLineSegments ? 2 : 1,
                        l = i.index,
                        u = i.attributes.position;
                    if (null !== l) {
                        let i = Math.max(0, n.start),
                            s = Math.min(l.count, n.start + n.count);
                        for (let r = i, n = s - 1; r < n; r += o) {
                            let i = r8(this, t, r2, h, l.getX(r), l.getX(r + 1), r);
                            i && e.push(i)
                        }
                        if (this.isLineLoop) {
                            let r = r8(this, t, r2, h, l.getX(s - 1), l.getX(i), s - 1);
                            r && e.push(r)
                        }
                    } else {
                        let i = Math.max(0, n.start),
                            s = Math.min(u.count, n.start + n.count);
                        for (let r = i, n = s - 1; r < n; r += o) {
                            let i = r8(this, t, r2, h, r, r + 1, r);
                            i && e.push(i)
                        }
                        if (this.isLineLoop) {
                            let r = r8(this, t, r2, h, s - 1, i, s - 1);
                            r && e.push(r)
                        }
                    }
                }
                updateMorphTargets() {
                    let t = this.geometry.morphAttributes,
                        e = Object.keys(t);
                    if (e.length > 0) {
                        let i = t[e[0]];
                        if (void 0 !== i) {
                            this.morphTargetInfluences = [], this.morphTargetDictionary = {};
                            for (let t = 0, e = i.length; t < e; t++) {
                                let e = i[t].name || String(t);
                                this.morphTargetInfluences.push(0), this.morphTargetDictionary[e] = t
                            }
                        }
                    }
                }
            }

            function r8(t, e, i, s, r, n, a) {
                let h = t.geometry.attributes.position;
                if (rK.fromBufferAttribute(h, r), r0.fromBufferAttribute(h, n), i.distanceSqToSegment(rK, r0, r5, r4) > s) return;
                r5.applyMatrix4(t.matrixWorld);
                let o = e.ray.origin.distanceTo(r5);
                if (!(o < e.near) && !(o > e.far)) return {
                    distance: o,
                    point: r4.clone().applyMatrix4(t.matrixWorld),
                    index: a,
                    face: null,
                    faceIndex: null,
                    barycoord: null,
                    object: t
                }
            }
            let r9 = new e9,
                r7 = new e9;
            class nt extends r6 {
                constructor(t, e) {
                    super(t, e), this.isLineSegments = !0, this.type = "LineSegments"
                }
                computeLineDistances() {
                    let t = this.geometry;
                    if (null === t.index) {
                        let e = t.attributes.position,
                            i = [];
                        for (let t = 0, s = e.count; t < s; t += 2) r9.fromBufferAttribute(e, t), r7.fromBufferAttribute(e, t + 1), i[t] = 0 === t ? 0 : i[t - 1], i[t + 1] = i[t] + r9.distanceTo(r7);
                        t.setAttribute("lineDistance", new sI(i, 1))
                    } else eU("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
                    return this
                }
            }
            class ne extends sK {
                constructor(t) {
                    super(), this.isPointsMaterial = !0, this.type = "PointsMaterial", this.color = new i3(0xffffff), this.map = null, this.alphaMap = null, this.size = 1, this.sizeAttenuation = !0, this.fog = !0, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.alphaMap = t.alphaMap, this.size = t.size, this.sizeAttenuation = t.sizeAttenuation, this.fog = t.fog, this
                }
            }
            let ni = new iw,
                ns = new rl,
                nr = new sV,
                nn = new e9;
            class na extends iY {
                constructor(t = new sJ, e = new ne) {
                    super(), this.isPoints = !0, this.type = "Points", this.geometry = t, this.material = e, this.morphTargetDictionary = void 0, this.morphTargetInfluences = void 0, this.updateMorphTargets()
                }
                copy(t, e) {
                    return super.copy(t, e), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this
                }
                intersectsFrustum(t) {
                    return t.intersectsObject(this)
                }
                raycast(t, e) {
                    let i = this.geometry,
                        s = this.matrixWorld,
                        r = t.params.Points.threshold,
                        n = i.drawRange;
                    if (null === i.boundingSphere && i.computeBoundingSphere(), nr.copy(i.boundingSphere), nr.applyMatrix4(s), nr.radius += r, !1 === t.ray.intersectsSphere(nr)) return;
                    ni.copy(s).invert(), ns.copy(t.ray).applyMatrix4(ni);
                    let a = r / ((this.scale.x + this.scale.y + this.scale.z) / 3),
                        h = a * a,
                        o = i.index,
                        l = i.attributes.position;
                    if (null !== o) {
                        let i = Math.max(0, n.start),
                            r = Math.min(o.count, n.start + n.count);
                        for (let n = i; n < r; n++) {
                            let i = o.getX(n);
                            nn.fromBufferAttribute(l, i), nh(nn, i, h, s, t, e, this)
                        }
                    } else {
                        let i = Math.max(0, n.start),
                            r = Math.min(l.count, n.start + n.count);
                        for (let n = i; n < r; n++) nn.fromBufferAttribute(l, n), nh(nn, n, h, s, t, e, this)
                    }
                }
                updateMorphTargets() {
                    let t = this.geometry.morphAttributes,
                        e = Object.keys(t);
                    if (e.length > 0) {
                        let i = t[e[0]];
                        if (void 0 !== i) {
                            this.morphTargetInfluences = [], this.morphTargetDictionary = {};
                            for (let t = 0, e = i.length; t < e; t++) {
                                let e = i[t].name || String(t);
                                this.morphTargetInfluences.push(0), this.morphTargetDictionary[e] = t
                            }
                        }
                    }
                }
            }

            function nh(t, e, i, s, r, n, a) {
                let h = ns.distanceSqToPoint(t);
                if (h < i) {
                    let i = new e9;
                    ns.closestPointToPoint(t, i), i.applyMatrix4(s);
                    let o = r.ray.origin.distanceTo(i);
                    if (o < r.near || o > r.far) return;
                    n.push({
                        distance: o,
                        distanceToRay: Math.sqrt(h),
                        point: i,
                        index: e,
                        face: null,
                        faceIndex: null,
                        barycoord: null,
                        object: a
                    })
                }
            }
            class no extends iy {
                constructor(t = [], e = tc, i, s, r, n, a, h, o, l) {
                    super(t, e, i, s, r, n, a, h, o, l), this.isCubeTexture = !0, this.flipY = !1
                }
                get images() {
                    return this.image
                }
                set images(t) {
                    this.image = t
                }
            }
            class nl extends iy {
                constructor(t, e, i, s, r, n, a, h, o) {
                    super(t, e, i, s, r, n, a, h, o), this.isCanvasTexture = !0, this.needsUpdate = !0
                }
            }
            class nu extends iy {
                constructor(t, e, i = tB, s, r, n, a = tv, h = tv, o, l = tD, u = 1) {
                    if (l !== tD && l !== tW) throw Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");
                    super({
                        width: t,
                        height: e,
                        depth: u
                    }, s, r, n, a, h, l, i, o), this.isDepthTexture = !0, this.flipY = !1, this.generateMipmaps = !1, this.compareFunction = null
                }
                copy(t) {
                    return super.copy(t), this.source = new ic(Object.assign({}, t.image)), this.compareFunction = t.compareFunction, this
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    return e.compareFunction = this.compareFunction, e
                }
            }
            class nc extends nu {
                constructor(t, e = tB, i = tc, s, r, n = tv, a = tv, h, o = tD) {
                    const l = {
                        width: t,
                        height: t,
                        depth: 1
                    };
                    super(t, t, e, i, s, r, n, a, h, o), this.image = [l, l, l, l, l, l], this.isCubeDepthTexture = !0, this.isCubeTexture = !0
                }
                get images() {
                    return this.image
                }
                set images(t) {
                    this.image = t
                }
            }
            class np extends iy {
                constructor(t = null) {
                    super(), this.sourceTexture = t, this.isExternalTexture = !0
                }
                copy(t) {
                    return super.copy(t), this.sourceTexture = t.sourceTexture, this
                }
            }
            class nd extends sJ {
                constructor(t = 1, e = 1, i = 1, s = 1, r = 1, n = 1) {
                    super(), this.type = "BoxGeometry", this.parameters = {
                        width: t,
                        height: e,
                        depth: i,
                        widthSegments: s,
                        heightSegments: r,
                        depthSegments: n
                    };
                    const a = this;
                    s = Math.floor(s), r = Math.floor(r);
                    const h = [],
                        o = [],
                        l = [],
                        u = [];
                    let c = 0,
                        p = 0;

                    function d(t, e, i, s, r, n, d, m, y, f, g) {
                        let x = n / y,
                            v = d / f,
                            M = n / 2,
                            b = d / 2,
                            w = m / 2,
                            S = y + 1,
                            _ = f + 1,
                            z = 0,
                            A = 0,
                            T = new e9;
                        for (let n = 0; n < _; n++) {
                            let a = n * v - b;
                            for (let h = 0; h < S; h++) {
                                let c = h * x - M;
                                T[t] = c * s, T[e] = a * r, T[i] = w, o.push(T.x, T.y, T.z), T[t] = 0, T[e] = 0, T[i] = m > 0 ? 1 : -1, l.push(T.x, T.y, T.z), u.push(h / y), u.push(1 - n / f), z += 1
                            }
                        }
                        for (let t = 0; t < f; t++)
                            for (let e = 0; e < y; e++) {
                                let i = c + e + S * t,
                                    s = c + e + S * (t + 1),
                                    r = c + (e + 1) + S * (t + 1),
                                    n = c + (e + 1) + S * t;
                                h.push(i, s, n), h.push(s, r, n), A += 6
                            }
                        a.addGroup(p, A, g), p += A, c += z
                    }
                    d("z", "y", "x", -1, -1, i, e, t, n = Math.floor(n), r, 0), d("z", "y", "x", 1, -1, i, e, -t, n, r, 1), d("x", "z", "y", 1, 1, t, i, e, s, n, 2), d("x", "z", "y", 1, -1, t, i, -e, s, n, 3), d("x", "y", "z", 1, -1, t, e, i, s, r, 4), d("x", "y", "z", -1, -1, t, e, -i, s, r, 5), this.setIndex(h), this.setAttribute("position", new sI(o, 3)), this.setAttribute("normal", new sI(l, 3)), this.setAttribute("uv", new sI(u, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new nd(t.width, t.height, t.depth, t.widthSegments, t.heightSegments, t.depthSegments)
                }
            }
            class nm extends sJ {
                constructor(t = 1, e = 1, i = 4, s = 8, r = 1) {
                    super(), this.type = "CapsuleGeometry", this.parameters = {
                        radius: t,
                        height: e,
                        capSegments: i,
                        radialSegments: s,
                        heightSegments: r
                    }, e = Math.max(0, e), i = Math.max(1, Math.floor(i)), s = Math.max(3, Math.floor(s));
                    const n = [],
                        a = [],
                        h = [],
                        o = [],
                        l = e / 2,
                        u = Math.PI / 2 * t,
                        c = e,
                        p = 2 * u + c,
                        d = 2 * i + (r = Math.max(1, Math.floor(r))),
                        m = s + 1,
                        y = new e9,
                        f = new e9;
                    for (let g = 0; g <= d; g++) {
                        let x = 0,
                            v = 0,
                            M = 0,
                            b = 0;
                        if (g <= i) {
                            const e = g / i,
                                s = e * Math.PI / 2;
                            v = -l - t * Math.cos(s), M = t * Math.sin(s), b = -t * Math.cos(s), x = e * u
                        } else if (g <= i + r) {
                            const s = (g - i) / r;
                            v = -l + s * e, M = t, b = 0, x = u + s * c
                        } else {
                            const e = (g - i - r) / i,
                                s = e * Math.PI / 2;
                            v = l + t * Math.sin(s), M = t * Math.cos(s), b = t * Math.sin(s), x = u + c + e * u
                        }
                        const w = Math.max(0, Math.min(1, x / p));
                        let S = 0;
                        0 === g ? S = .5 / s : g === d && (S = -.5 / s);
                        for (let t = 0; t <= s; t++) {
                            const e = t / s,
                                i = e * Math.PI * 2,
                                r = Math.sin(i),
                                n = Math.cos(i);
                            f.x = -M * n, f.y = v, f.z = M * r, a.push(f.x, f.y, f.z), y.set(-M * n, b, M * r), y.normalize(), h.push(y.x, y.y, y.z), o.push(e + S, w)
                        }
                        if (g > 0) {
                            const t = (g - 1) * m;
                            for (let e = 0; e < s; e++) {
                                const i = t + e,
                                    s = t + e + 1,
                                    r = g * m + e,
                                    a = g * m + e + 1;
                                n.push(i, s, r), n.push(s, a, r)
                            }
                        }
                    }
                    this.setIndex(n), this.setAttribute("position", new sI(a, 3)), this.setAttribute("normal", new sI(h, 3)), this.setAttribute("uv", new sI(o, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new nm(t.radius, t.height, t.capSegments, t.radialSegments, t.heightSegments)
                }
            }
            class ny extends sJ {
                constructor(t = 1, e = 32, i = 0, s = 2 * Math.PI) {
                    super(), this.type = "CircleGeometry", this.parameters = {
                        radius: t,
                        segments: e,
                        thetaStart: i,
                        thetaLength: s
                    }, e = Math.max(3, e);
                    const r = [],
                        n = [],
                        a = [],
                        h = [],
                        o = new e9,
                        l = new e6;
                    n.push(0, 0, 0), a.push(0, 0, 1), h.push(.5, .5);
                    for (let r = 0, u = 3; r <= e; r++, u += 3) {
                        const c = i + r / e * s;
                        o.x = t * Math.cos(c), o.y = t * Math.sin(c), n.push(o.x, o.y, o.z), a.push(0, 0, 1), l.x = (n[u] / t + 1) / 2, l.y = (n[u + 1] / t + 1) / 2, h.push(l.x, l.y)
                    }
                    for (let t = 1; t <= e; t++) r.push(t, t + 1, 0);
                    this.setIndex(r), this.setAttribute("position", new sI(n, 3)), this.setAttribute("normal", new sI(a, 3)), this.setAttribute("uv", new sI(h, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new ny(t.radius, t.segments, t.thetaStart, t.thetaLength)
                }
            }
            class nf extends sJ {
                constructor(t = 1, e = 1, i = 1, s = 32, r = 1, n = !1, a = 0, h = 2 * Math.PI) {
                    super(), this.type = "CylinderGeometry", this.parameters = {
                        radiusTop: t,
                        radiusBottom: e,
                        height: i,
                        radialSegments: s,
                        heightSegments: r,
                        openEnded: n,
                        thetaStart: a,
                        thetaLength: h
                    };
                    const o = this;
                    s = Math.floor(s), r = Math.floor(r);
                    const l = [],
                        u = [],
                        c = [],
                        p = [];
                    let d = 0;
                    const m = [],
                        y = i / 2;
                    let f = 0;

                    function g(i) {
                        let r = d,
                            n = new e6,
                            m = new e9,
                            g = 0,
                            x = !0 === i ? t : e,
                            v = !0 === i ? 1 : -1;
                        for (let t = 1; t <= s; t++) u.push(0, y * v, 0), c.push(0, v, 0), p.push(.5, .5), d++;
                        let M = d;
                        for (let t = 0; t <= s; t++) {
                            let e = t / s * h + a,
                                i = Math.cos(e),
                                r = Math.sin(e);
                            m.x = x * r, m.y = y * v, m.z = x * i, u.push(m.x, m.y, m.z), c.push(0, v, 0), n.x = .5 * i + .5, n.y = .5 * r * v + .5, p.push(n.x, n.y), d++
                        }
                        for (let t = 0; t < s; t++) {
                            let e = r + t,
                                s = M + t;
                            !0 === i ? l.push(s, s + 1, e) : l.push(s + 1, s, e), g += 3
                        }
                        o.addGroup(f, g, !0 === i ? 1 : 2), f += g
                    }(function() {
                        let n = new e9,
                            g = new e9,
                            x = 0,
                            v = (e - t) / i;
                        for (let o = 0; o <= r; o++) {
                            let l = [],
                                f = o / r,
                                x = f * (e - t) + t;
                            for (let t = 0; t <= s; t++) {
                                let e = t / s,
                                    r = e * h + a,
                                    o = Math.sin(r),
                                    m = Math.cos(r);
                                g.x = x * o, g.y = -f * i + y, g.z = x * m, u.push(g.x, g.y, g.z), n.set(o, v, m).normalize(), c.push(n.x, n.y, n.z), p.push(e, 1 - f), l.push(d++)
                            }
                            m.push(l)
                        }
                        for (let i = 0; i < s; i++)
                            for (let s = 0; s < r; s++) {
                                let n = m[s][i],
                                    a = m[s + 1][i],
                                    h = m[s + 1][i + 1],
                                    o = m[s][i + 1];
                                (t > 0 || 0 !== s) && (l.push(n, a, o), x += 3), (e > 0 || s !== r - 1) && (l.push(a, h, o), x += 3)
                            }
                        o.addGroup(f, x, 0), f += x
                    })(), !1 === n && (t > 0 && g(!0), e > 0 && g(!1)), this.setIndex(l), this.setAttribute("position", new sI(u, 3)), this.setAttribute("normal", new sI(c, 3)), this.setAttribute("uv", new sI(p, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new nf(t.radiusTop, t.radiusBottom, t.height, t.radialSegments, t.heightSegments, t.openEnded, t.thetaStart, t.thetaLength)
                }
            }
            class ng extends nf {
                constructor(t = 1, e = 1, i = 32, s = 1, r = !1, n = 0, a = 2 * Math.PI) {
                    super(0, t, e, i, s, r, n, a), this.type = "ConeGeometry", this.parameters = {
                        radius: t,
                        height: e,
                        radialSegments: i,
                        heightSegments: s,
                        openEnded: r,
                        thetaStart: n,
                        thetaLength: a
                    }
                }
                static fromJSON(t) {
                    return new ng(t.radius, t.height, t.radialSegments, t.heightSegments, t.openEnded, t.thetaStart, t.thetaLength)
                }
            }
            class nx extends sJ {
                constructor(t = [], e = [], i = 1, s = 0) {
                    super(), this.type = "PolyhedronGeometry", this.parameters = {
                        vertices: t,
                        indices: e,
                        radius: i,
                        detail: s
                    };
                    const r = [],
                        n = [];

                    function a(t) {
                        r.push(t.x, t.y, t.z)
                    }

                    function h(e, i) {
                        let s = 3 * e;
                        i.x = t[s + 0], i.y = t[s + 1], i.z = t[s + 2]
                    }

                    function o(t, e, i, s) {
                        s < 0 && 1 === t.x && (n[e] = t.x - 1), 0 === i.x && 0 === i.z && (n[e] = s / 2 / Math.PI + .5)
                    }

                    function l(t) {
                        return Math.atan2(t.z, -t.x)
                    }(function(t) {
                        let i = new e9,
                            s = new e9,
                            r = new e9;
                        for (let n = 0; n < e.length; n += 3) h(e[n + 0], i), h(e[n + 1], s), h(e[n + 2], r),
                            function(t, e, i, s) {
                                let r = s + 1,
                                    n = [];
                                for (let s = 0; s <= r; s++) {
                                    n[s] = [];
                                    let a = t.clone().lerp(i, s / r),
                                        h = e.clone().lerp(i, s / r),
                                        o = r - s;
                                    for (let t = 0; t <= o; t++) 0 === t && s === r ? n[s][t] = a : n[s][t] = a.clone().lerp(h, t / o)
                                }
                                for (let t = 0; t < r; t++)
                                    for (let e = 0; e < 2 * (r - t) - 1; e++) {
                                        let i = Math.floor(e / 2);
                                        e % 2 == 0 ? (a(n[t][i + 1]), a(n[t + 1][i]), a(n[t][i])) : (a(n[t][i + 1]), a(n[t + 1][i + 1]), a(n[t + 1][i]))
                                    }
                            }(i, s, r, t)
                    })(s),
                    function(t) {
                        let e = new e9;
                        for (let i = 0; i < r.length; i += 3) e.x = r[i + 0], e.y = r[i + 1], e.z = r[i + 2], e.normalize().multiplyScalar(t), r[i + 0] = e.x, r[i + 1] = e.y, r[i + 2] = e.z
                    }(i),
                    function() {
                        let t = new e9;
                        for (let i = 0; i < r.length; i += 3) {
                            var e;
                            t.x = r[i + 0], t.y = r[i + 1], t.z = r[i + 2];
                            let s = l(t) / 2 / Math.PI + .5,
                                a = Math.atan2(-(e = t).y, Math.sqrt(e.x * e.x + e.z * e.z)) / Math.PI + .5;
                            n.push(s, 1 - a)
                        }(function() {
                            let t = new e9,
                                e = new e9,
                                i = new e9,
                                s = new e9,
                                a = new e6,
                                h = new e6,
                                u = new e6;
                            for (let c = 0, p = 0; c < r.length; c += 9, p += 6) {
                                t.set(r[c + 0], r[c + 1], r[c + 2]), e.set(r[c + 3], r[c + 4], r[c + 5]), i.set(r[c + 6], r[c + 7], r[c + 8]), a.set(n[p + 0], n[p + 1]), h.set(n[p + 2], n[p + 3]), u.set(n[p + 4], n[p + 5]), s.copy(t).add(e).add(i).divideScalar(3);
                                let d = l(s);
                                o(a, p + 0, t, d), o(h, p + 2, e, d), o(u, p + 4, i, d)
                            }
                        })(),
                        function() {
                            for (let t = 0; t < n.length; t += 6) {
                                let e = n[t + 0],
                                    i = n[t + 2],
                                    s = n[t + 4],
                                    r = Math.max(e, i, s),
                                    a = Math.min(e, i, s);
                                r > .9 && a < .1 && (e < .2 && (n[t + 0] += 1), i < .2 && (n[t + 2] += 1), s < .2 && (n[t + 4] += 1))
                            }
                        }()
                    }(), this.setAttribute("position", new sI(r, 3)), this.setAttribute("normal", new sI(r.slice(), 3)), this.setAttribute("uv", new sI(n, 2)), 0 === s ? this.computeVertexNormals() : this.normalizeNormals()
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new nx(t.vertices, t.indices, t.radius, t.detail)
                }
            }
            class nv {
                constructor() {
                    this.type = "Curve", this.arcLengthDivisions = 200, this.needsUpdate = !1, this.cacheArcLengths = null
                }
                getPoint() {
                    eU("Curve: .getPoint() not implemented.")
                }
                getPointAt(t, e) {
                    let i = this.getUtoTmapping(t);
                    return this.getPoint(i, e)
                }
                getPoints(t = 5) {
                    let e = [];
                    for (let i = 0; i <= t; i++) e.push(this.getPoint(i / t));
                    return e
                }
                getSpacedPoints(t = 5) {
                    let e = [];
                    for (let i = 0; i <= t; i++) e.push(this.getPointAt(i / t));
                    return e
                }
                getLength() {
                    let t = this.getLengths();
                    return t[t.length - 1]
                }
                getLengths(t = this.arcLengthDivisions) {
                    if (this.cacheArcLengths && this.cacheArcLengths.length === t + 1 && !this.needsUpdate) return this.cacheArcLengths;
                    this.needsUpdate = !1;
                    let e = [],
                        i, s = this.getPoint(0),
                        r = 0;
                    e.push(0);
                    for (let n = 1; n <= t; n++) e.push(r += (i = this.getPoint(n / t)).distanceTo(s)), s = i;
                    return this.cacheArcLengths = e, e
                }
                updateArcLengths() {
                    this.needsUpdate = !0, this.getLengths()
                }
                getUtoTmapping(t, e = null) {
                    let i, s = this.getLengths(),
                        r = 0,
                        n = s.length;
                    i = e || t * s[n - 1];
                    let a = 0,
                        h = n - 1,
                        o;
                    for (; a <= h;)
                        if ((o = s[r = Math.floor(a + (h - a) / 2)] - i) < 0) a = r + 1;
                        else if (o > 0) h = r - 1;
                    else {
                        h = r;
                        break
                    }
                    if (s[r = h] === i) return r / (n - 1);
                    let l = s[r],
                        u = s[r + 1];
                    return (r + (i - l) / (u - l)) / (n - 1)
                }
                getTangent(t, e) {
                    let i = t - 1e-4,
                        s = t + 1e-4;
                    i < 0 && (i = 0), s > 1 && (s = 1);
                    let r = this.getPoint(i),
                        n = this.getPoint(s),
                        a = e || (r.isVector2 ? new e6 : new e9);
                    return a.copy(n).sub(r).normalize(), a
                }
                getTangentAt(t, e) {
                    let i = this.getUtoTmapping(t);
                    return this.getTangent(i, e)
                }
                computeFrenetFrames(t, e = !1) {
                    let i = new e9,
                        s = [],
                        r = [],
                        n = [],
                        a = new e9,
                        h = new iw;
                    for (let e = 0; e <= t; e++) {
                        let i = e / t;
                        s[e] = this.getTangentAt(i, new e9)
                    }
                    r[0] = new e9, n[0] = new e9;
                    let o = Number.MAX_VALUE,
                        l = Math.abs(s[0].x),
                        u = Math.abs(s[0].y),
                        c = Math.abs(s[0].z);
                    l <= o && (o = l, i.set(1, 0, 0)), u <= o && (o = u, i.set(0, 1, 0)), c <= o && i.set(0, 0, 1), a.crossVectors(s[0], i).normalize(), r[0].crossVectors(s[0], a), n[0].crossVectors(s[0], r[0]);
                    for (let e = 1; e <= t; e++) {
                        if (r[e] = r[e - 1].clone(), n[e] = n[e - 1].clone(), a.crossVectors(s[e - 1], s[e]), a.length() > Number.EPSILON) {
                            a.normalize();
                            let t = Math.acos(e0(s[e - 1].dot(s[e]), -1, 1));
                            r[e].applyMatrix4(h.makeRotationAxis(a, t))
                        }
                        n[e].crossVectors(s[e], r[e])
                    }
                    if (!0 === e) {
                        let e = Math.acos(e0(r[0].dot(r[t]), -1, 1));
                        e /= t, s[0].dot(a.crossVectors(r[0], r[t])) > 0 && (e = -e);
                        for (let i = 1; i <= t; i++) r[i].applyMatrix4(h.makeRotationAxis(s[i], e * i)), n[i].crossVectors(s[i], r[i])
                    }
                    return {
                        tangents: s,
                        normals: r,
                        binormals: n
                    }
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                copy(t) {
                    return this.arcLengthDivisions = t.arcLengthDivisions, this
                }
                toJSON() {
                    let t = {
                        metadata: {
                            version: 4.7,
                            type: "Curve",
                            generator: "Curve.toJSON"
                        }
                    };
                    return t.arcLengthDivisions = this.arcLengthDivisions, t.type = this.type, t
                }
                fromJSON(t) {
                    return this.arcLengthDivisions = t.arcLengthDivisions, this
                }
            }
            class nM extends nv {
                constructor(t = 0, e = 0, i = 1, s = 1, r = 0, n = 2 * Math.PI, a = !1, h = 0) {
                    super(), this.isEllipseCurve = !0, this.type = "EllipseCurve", this.aX = t, this.aY = e, this.xRadius = i, this.yRadius = s, this.aStartAngle = r, this.aEndAngle = n, this.aClockwise = a, this.aRotation = h
                }
                getPoint(t, e = new e6) {
                    let i = 2 * Math.PI,
                        s = this.aEndAngle - this.aStartAngle,
                        r = Math.abs(s) < Number.EPSILON;
                    for (; s < 0;) s += i;
                    for (; s > i;) s -= i;
                    s < Number.EPSILON && (s = r ? 0 : i), !0 !== this.aClockwise || r || (s === i ? s = -i : s -= i);
                    let n = this.aStartAngle + t * s,
                        a = this.aX + this.xRadius * Math.cos(n),
                        h = this.aY + this.yRadius * Math.sin(n);
                    if (0 !== this.aRotation) {
                        let t = Math.cos(this.aRotation),
                            e = Math.sin(this.aRotation),
                            i = a - this.aX,
                            s = h - this.aY;
                        a = i * t - s * e + this.aX, h = i * e + s * t + this.aY
                    }
                    return e.set(a, h)
                }
                copy(t) {
                    return super.copy(t), this.aX = t.aX, this.aY = t.aY, this.xRadius = t.xRadius, this.yRadius = t.yRadius, this.aStartAngle = t.aStartAngle, this.aEndAngle = t.aEndAngle, this.aClockwise = t.aClockwise, this.aRotation = t.aRotation, this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.aX = this.aX, t.aY = this.aY, t.xRadius = this.xRadius, t.yRadius = this.yRadius, t.aStartAngle = this.aStartAngle, t.aEndAngle = this.aEndAngle, t.aClockwise = this.aClockwise, t.aRotation = this.aRotation, t
                }
                fromJSON(t) {
                    return super.fromJSON(t), this.aX = t.aX, this.aY = t.aY, this.xRadius = t.xRadius, this.yRadius = t.yRadius, this.aStartAngle = t.aStartAngle, this.aEndAngle = t.aEndAngle, this.aClockwise = t.aClockwise, this.aRotation = t.aRotation, this
                }
            }
            class nb extends nM {
                constructor(t, e, i, s, r, n) {
                    super(t, e, i, i, s, r, n), this.isArcCurve = !0, this.type = "ArcCurve"
                }
            }

            function nw() {
                let t = 0,
                    e = 0,
                    i = 0,
                    s = 0;

                function r(r, n, a, h) {
                    t = r, e = a, i = -3 * r + 3 * n - 2 * a - h, s = 2 * r - 2 * n + a + h
                }
                return {
                    initCatmullRom: function(t, e, i, s, n) {
                        r(e, i, n * (i - t), n * (s - e))
                    },
                    initNonuniformCatmullRom: function(t, e, i, s, n, a, h) {
                        let o = (e - t) / n - (i - t) / (n + a) + (i - e) / a,
                            l = (i - e) / a - (s - e) / (a + h) + (s - i) / h;
                        r(e, i, o *= a, l *= a)
                    },
                    calc: function(r) {
                        let n = r * r;
                        return t + e * r + i * n + n * r * s
                    }
                }
            }
            let nS = new e9,
                n_ = new e9,
                nz = new nw,
                nA = new nw,
                nT = new nw;
            class nC extends nv {
                constructor(t = [], e = !1, i = "centripetal", s = .5) {
                    super(), this.isCatmullRomCurve3 = !0, this.type = "CatmullRomCurve3", this.points = t, this.closed = e, this.curveType = i, this.tension = s
                }
                getPoint(t, e = new e9) {
                    let i, s, r = this.points,
                        n = r.length,
                        a = (n - !this.closed) * t,
                        h = Math.floor(a),
                        o = a - h;
                    this.closed ? h += h > 0 ? 0 : (Math.floor(Math.abs(h) / n) + 1) * n : 0 === o && h === n - 1 && (h = n - 2, o = 1), this.closed || h > 0 ? i = r[(h - 1) % n] : (n_.subVectors(r[0], r[1]).add(r[0]), i = n_);
                    let l = r[h % n],
                        u = r[(h + 1) % n];
                    if (this.closed || h + 2 < n ? s = r[(h + 2) % n] : (nS.subVectors(r[n - 1], r[n - 2]).add(r[n - 1]), s = nS), "centripetal" === this.curveType || "chordal" === this.curveType) {
                        let t = "chordal" === this.curveType ? .5 : .25,
                            e = Math.pow(i.distanceToSquared(l), t),
                            r = Math.pow(l.distanceToSquared(u), t),
                            n = Math.pow(u.distanceToSquared(s), t);
                        r < 1e-4 && (r = 1), e < 1e-4 && (e = r), n < 1e-4 && (n = r), nz.initNonuniformCatmullRom(i.x, l.x, u.x, s.x, e, r, n), nA.initNonuniformCatmullRom(i.y, l.y, u.y, s.y, e, r, n), nT.initNonuniformCatmullRom(i.z, l.z, u.z, s.z, e, r, n)
                    } else "catmullrom" === this.curveType && (nz.initCatmullRom(i.x, l.x, u.x, s.x, this.tension), nA.initCatmullRom(i.y, l.y, u.y, s.y, this.tension), nT.initCatmullRom(i.z, l.z, u.z, s.z, this.tension));
                    return e.set(nz.calc(o), nA.calc(o), nT.calc(o)), e
                }
                copy(t) {
                    super.copy(t), this.points = [];
                    for (let e = 0, i = t.points.length; e < i; e++) {
                        let i = t.points[e];
                        this.points.push(i.clone())
                    }
                    return this.closed = t.closed, this.curveType = t.curveType, this.tension = t.tension, this
                }
                toJSON() {
                    let t = super.toJSON();
                    t.points = [];
                    for (let e = 0, i = this.points.length; e < i; e++) {
                        let i = this.points[e];
                        t.points.push(i.toArray())
                    }
                    return t.closed = this.closed, t.curveType = this.curveType, t.tension = this.tension, t
                }
                fromJSON(t) {
                    super.fromJSON(t), this.points = [];
                    for (let e = 0, i = t.points.length; e < i; e++) {
                        let i = t.points[e];
                        this.points.push(new e9().fromArray(i))
                    }
                    return this.closed = t.closed, this.curveType = t.curveType, this.tension = t.tension, this
                }
            }

            function nk(t, e, i, s, r) {
                let n = (s - e) * .5,
                    a = (r - i) * .5,
                    h = t * t;
                return t * h * (2 * i - 2 * s + n + a) + (-3 * i + 3 * s - 2 * n - a) * h + n * t + i
            }

            function nB(t, e, i, s) {
                let r;
                return (r = 1 - t) * r * e + 2 * (1 - t) * t * i + t * t * s
            }

            function nO(t, e, i, s, r) {
                let n, a;
                return (n = 1 - t) * n * n * e + 3 * (a = 1 - t) * a * t * i + 3 * (1 - t) * t * t * s + t * t * t * r
            }
            class nI extends nv {
                constructor(t = new e6, e = new e6, i = new e6, s = new e6) {
                    super(), this.isCubicBezierCurve = !0, this.type = "CubicBezierCurve", this.v0 = t, this.v1 = e, this.v2 = i, this.v3 = s
                }
                getPoint(t, e = new e6) {
                    let i = this.v0,
                        s = this.v1,
                        r = this.v2,
                        n = this.v3;
                    return e.set(nO(t, i.x, s.x, r.x, n.x), nO(t, i.y, s.y, r.y, n.y)), e
                }
                copy(t) {
                    return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this.v3.copy(t.v3), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t.v3 = this.v3.toArray(), t
                }
                fromJSON(t) {
                    return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this.v3.fromArray(t.v3), this
                }
            }
            class nN extends nv {
                constructor(t = new e9, e = new e9, i = new e9, s = new e9) {
                    super(), this.isCubicBezierCurve3 = !0, this.type = "CubicBezierCurve3", this.v0 = t, this.v1 = e, this.v2 = i, this.v3 = s
                }
                getPoint(t, e = new e9) {
                    let i = this.v0,
                        s = this.v1,
                        r = this.v2,
                        n = this.v3;
                    return e.set(nO(t, i.x, s.x, r.x, n.x), nO(t, i.y, s.y, r.y, n.y), nO(t, i.z, s.z, r.z, n.z)), e
                }
                copy(t) {
                    return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this.v3.copy(t.v3), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t.v3 = this.v3.toArray(), t
                }
                fromJSON(t) {
                    return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this.v3.fromArray(t.v3), this
                }
            }
            class nP extends nv {
                constructor(t = new e6, e = new e6) {
                    super(), this.isLineCurve = !0, this.type = "LineCurve", this.v1 = t, this.v2 = e
                }
                getPoint(t, e = new e6) {
                    return 1 === t ? e.copy(this.v2) : (e.copy(this.v2).sub(this.v1), e.multiplyScalar(t).add(this.v1)), e
                }
                getPointAt(t, e) {
                    return this.getPoint(t, e)
                }
                getTangent(t, e = new e6) {
                    return e.subVectors(this.v2, this.v1).normalize()
                }
                getTangentAt(t, e) {
                    return this.getTangent(t, e)
                }
                copy(t) {
                    return super.copy(t), this.v1.copy(t.v1), this.v2.copy(t.v2), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t
                }
                fromJSON(t) {
                    return super.fromJSON(t), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this
                }
            }
            class nR extends nv {
                constructor(t = new e9, e = new e9) {
                    super(), this.isLineCurve3 = !0, this.type = "LineCurve3", this.v1 = t, this.v2 = e
                }
                getPoint(t, e = new e9) {
                    return 1 === t ? e.copy(this.v2) : (e.copy(this.v2).sub(this.v1), e.multiplyScalar(t).add(this.v1)), e
                }
                getPointAt(t, e) {
                    return this.getPoint(t, e)
                }
                getTangent(t, e = new e9) {
                    return e.subVectors(this.v2, this.v1).normalize()
                }
                getTangentAt(t, e) {
                    return this.getTangent(t, e)
                }
                copy(t) {
                    return super.copy(t), this.v1.copy(t.v1), this.v2.copy(t.v2), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t
                }
                fromJSON(t) {
                    return super.fromJSON(t), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this
                }
            }
            class nV extends nv {
                constructor(t = new e6, e = new e6, i = new e6) {
                    super(), this.isQuadraticBezierCurve = !0, this.type = "QuadraticBezierCurve", this.v0 = t, this.v1 = e, this.v2 = i
                }
                getPoint(t, e = new e6) {
                    let i = this.v0,
                        s = this.v1,
                        r = this.v2;
                    return e.set(nB(t, i.x, s.x, r.x), nB(t, i.y, s.y, r.y)), e
                }
                copy(t) {
                    return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t
                }
                fromJSON(t) {
                    return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this
                }
            }
            class nE extends nv {
                constructor(t = new e9, e = new e9, i = new e9) {
                    super(), this.isQuadraticBezierCurve3 = !0, this.type = "QuadraticBezierCurve3", this.v0 = t, this.v1 = e, this.v2 = i
                }
                getPoint(t, e = new e9) {
                    let i = this.v0,
                        s = this.v1,
                        r = this.v2;
                    return e.set(nB(t, i.x, s.x, r.x), nB(t, i.y, s.y, r.y), nB(t, i.z, s.z, r.z)), e
                }
                copy(t) {
                    return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t
                }
                fromJSON(t) {
                    return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this
                }
            }
            class nF extends nv {
                constructor(t = []) {
                    super(), this.isSplineCurve = !0, this.type = "SplineCurve", this.points = t
                }
                getPoint(t, e = new e6) {
                    let i = this.points,
                        s = (i.length - 1) * t,
                        r = Math.floor(s),
                        n = s - r,
                        a = i[0 === r ? r : r - 1],
                        h = i[r],
                        o = i[r > i.length - 2 ? i.length - 1 : r + 1],
                        l = i[r > i.length - 3 ? i.length - 1 : r + 2];
                    return e.set(nk(n, a.x, h.x, o.x, l.x), nk(n, a.y, h.y, o.y, l.y)), e
                }
                copy(t) {
                    super.copy(t), this.points = [];
                    for (let e = 0, i = t.points.length; e < i; e++) {
                        let i = t.points[e];
                        this.points.push(i.clone())
                    }
                    return this
                }
                toJSON() {
                    let t = super.toJSON();
                    t.points = [];
                    for (let e = 0, i = this.points.length; e < i; e++) {
                        let i = this.points[e];
                        t.points.push(i.toArray())
                    }
                    return t
                }
                fromJSON(t) {
                    super.fromJSON(t), this.points = [];
                    for (let e = 0, i = t.points.length; e < i; e++) {
                        let i = t.points[e];
                        this.points.push(new e6().fromArray(i))
                    }
                    return this
                }
            }
            var nL = Object.freeze({
                __proto__: null,
                ArcCurve: nb,
                CatmullRomCurve3: nC,
                CubicBezierCurve: nI,
                CubicBezierCurve3: nN,
                EllipseCurve: nM,
                LineCurve: nP,
                LineCurve3: nR,
                QuadraticBezierCurve: nV,
                QuadraticBezierCurve3: nE,
                SplineCurve: nF
            });
            class nj extends nv {
                constructor() {
                    super(), this.type = "CurvePath", this.curves = [], this.autoClose = !1
                }
                add(t) {
                    this.curves.push(t)
                }
                closePath() {
                    let t = this.curves[0].getPoint(0),
                        e = this.curves[this.curves.length - 1].getPoint(1);
                    if (!t.equals(e)) {
                        let i = !0 === t.isVector2 ? "LineCurve" : "LineCurve3";
                        this.curves.push(new nL[i](e, t))
                    }
                    return this
                }
                getPoint(t, e) {
                    let i = t * this.getLength(),
                        s = this.getCurveLengths(),
                        r = 0;
                    for (; r < s.length;) {
                        if (s[r] >= i) {
                            let t = s[r] - i,
                                n = this.curves[r],
                                a = n.getLength(),
                                h = 0 === a ? 0 : 1 - t / a;
                            return n.getPointAt(h, e)
                        }
                        r++
                    }
                    return null
                }
                getLength() {
                    let t = this.getCurveLengths();
                    return t[t.length - 1]
                }
                updateArcLengths() {
                    this.needsUpdate = !0, this.cacheLengths = null, this.getCurveLengths()
                }
                getCurveLengths() {
                    if (this.cacheLengths && this.cacheLengths.length === this.curves.length) return this.cacheLengths;
                    let t = [],
                        e = 0;
                    for (let i = 0, s = this.curves.length; i < s; i++) t.push(e += this.curves[i].getLength());
                    return this.cacheLengths = t, t
                }
                getSpacedPoints(t = 40) {
                    let e = [];
                    for (let i = 0; i <= t; i++) e.push(this.getPoint(i / t));
                    return this.autoClose && e.push(e[0]), e
                }
                getPoints(t = 12) {
                    let e, i = [];
                    for (let s = 0, r = this.curves; s < r.length; s++) {
                        let n = r[s],
                            a = n.isEllipseCurve ? 2 * t : n.isLineCurve || n.isLineCurve3 ? 1 : n.isSplineCurve ? t * n.points.length : t,
                            h = n.getPoints(a);
                        for (let t = 0; t < h.length; t++) {
                            let s = h[t];
                            e && e.equals(s) || (i.push(s), e = s)
                        }
                    }
                    return this.autoClose && i.length > 1 && !i[i.length - 1].equals(i[0]) && i.push(i[0]), i
                }
                copy(t) {
                    super.copy(t), this.curves = [];
                    for (let e = 0, i = t.curves.length; e < i; e++) {
                        let i = t.curves[e];
                        this.curves.push(i.clone())
                    }
                    return this.autoClose = t.autoClose, this
                }
                toJSON() {
                    let t = super.toJSON();
                    t.autoClose = this.autoClose, t.curves = [];
                    for (let e = 0, i = this.curves.length; e < i; e++) {
                        let i = this.curves[e];
                        t.curves.push(i.toJSON())
                    }
                    return t
                }
                fromJSON(t) {
                    super.fromJSON(t), this.autoClose = t.autoClose, this.curves = [];
                    for (let e = 0, i = t.curves.length; e < i; e++) {
                        let i = t.curves[e];
                        this.curves.push(new nL[i.type]().fromJSON(i))
                    }
                    return this
                }
            }
            class nD extends nj {
                constructor(t) {
                    super(), this.type = "Path", this.currentPoint = new e6, t && this.setFromPoints(t)
                }
                setFromPoints(t) {
                    this.moveTo(t[0].x, t[0].y);
                    for (let e = 1, i = t.length; e < i; e++) this.lineTo(t[e].x, t[e].y);
                    return this
                }
                moveTo(t, e) {
                    return this.currentPoint.set(t, e), this
                }
                lineTo(t, e) {
                    let i = new nP(this.currentPoint.clone(), new e6(t, e));
                    return this.curves.push(i), this.currentPoint.set(t, e), this
                }
                quadraticCurveTo(t, e, i, s) {
                    let r = new nV(this.currentPoint.clone(), new e6(t, e), new e6(i, s));
                    return this.curves.push(r), this.currentPoint.set(i, s), this
                }
                bezierCurveTo(t, e, i, s, r, n) {
                    let a = new nI(this.currentPoint.clone(), new e6(t, e), new e6(i, s), new e6(r, n));
                    return this.curves.push(a), this.currentPoint.set(r, n), this
                }
                splineThru(t) {
                    let e = new nF([this.currentPoint.clone()].concat(t));
                    return this.curves.push(e), this.currentPoint.copy(t[t.length - 1]), this
                }
                arc(t, e, i, s, r, n) {
                    let a = this.currentPoint.x,
                        h = this.currentPoint.y;
                    return this.absarc(t + a, e + h, i, s, r, n), this
                }
                absarc(t, e, i, s, r, n) {
                    return this.absellipse(t, e, i, i, s, r, n), this
                }
                ellipse(t, e, i, s, r, n, a, h) {
                    let o = this.currentPoint.x,
                        l = this.currentPoint.y;
                    return this.absellipse(t + o, e + l, i, s, r, n, a, h), this
                }
                absellipse(t, e, i, s, r, n, a, h) {
                    let o = new nM(t, e, i, s, r, n, a, h);
                    if (this.curves.length > 0) {
                        let t = o.getPoint(0);
                        t.equals(this.currentPoint) || this.lineTo(t.x, t.y)
                    }
                    this.curves.push(o);
                    let l = o.getPoint(1);
                    return this.currentPoint.copy(l), this
                }
                copy(t) {
                    return super.copy(t), this.currentPoint.copy(t.currentPoint), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.currentPoint = this.currentPoint.toArray(), t
                }
                fromJSON(t) {
                    return super.fromJSON(t), this.currentPoint.fromArray(t.currentPoint), this
                }
            }
            class nW extends nD {
                constructor(t) {
                    super(t), this.uuid = eK(), this.type = "Shape", this.holes = []
                }
                getPointsHoles(t) {
                    let e = [];
                    for (let i = 0, s = this.holes.length; i < s; i++) e[i] = this.holes[i].getPoints(t);
                    return e
                }
                extractPoints(t) {
                    return {
                        shape: this.getPoints(t),
                        holes: this.getPointsHoles(t)
                    }
                }
                copy(t) {
                    super.copy(t), this.holes = [];
                    for (let e = 0, i = t.holes.length; e < i; e++) {
                        let i = t.holes[e];
                        this.holes.push(i.clone())
                    }
                    return this
                }
                toJSON() {
                    let t = super.toJSON();
                    t.uuid = this.uuid, t.holes = [];
                    for (let e = 0, i = this.holes.length; e < i; e++) {
                        let i = this.holes[e];
                        t.holes.push(i.toJSON())
                    }
                    return t
                }
                fromJSON(t) {
                    super.fromJSON(t), this.uuid = t.uuid, this.holes = [];
                    for (let e = 0, i = t.holes.length; e < i; e++) {
                        let i = t.holes[e];
                        this.holes.push(new nD().fromJSON(i))
                    }
                    return this
                }
            }

            function nU(t, e, i, s, r) {
                let n;
                if (r === function(t, e, i, s) {
                        let r = 0;
                        for (let n = e, a = i - s; n < i; n += s) r += (t[a] - t[n]) * (t[n + 1] + t[a + 1]), a = n;
                        return r
                    }(t, e, i, s) > 0)
                    for (let r = e; r < i; r += s) n = n2(r / s | 0, t[r], t[r + 1], n);
                else
                    for (let r = i - s; r >= e; r -= s) n = n2(r / s | 0, t[r], t[r + 1], n);
                return n && nG(n, n.next) && (n3(n), n = n.next), n
            }

            function nJ(t, e) {
                if (!t) return t;
                e || (e = t);
                let i = t,
                    s;
                do
                    if (s = !1, !i.steiner && (nG(i, i.next) || 0 === nY(i.prev, i, i.next))) {
                        if (n3(i), (i = e = i.prev) === i.next) break;
                        s = !0
                    } else i = i.next; while (s || i !== e);
                return e
            }

            function nq(t, e) {
                let i = t.x - e.x;
                return 0 === i && 0 == (i = t.y - e.y) && (i = (t.next.y - t.y) / (t.next.x - t.x) - (e.next.y - e.y) / (e.next.x - e.x)), i
            }

            function nH(t, e, i, s, r) {
                return (t = ((t = ((t = ((t = ((t = (t - i) * r | 0) | t << 8) & 0xff00ff) | t << 4) & 0xf0f0f0f) | t << 2) & 0x33333333) | t << 1) & 0x55555555) | (e = ((e = ((e = ((e = ((e = (e - s) * r | 0) | e << 8) & 0xff00ff) | e << 4) & 0xf0f0f0f) | e << 2) & 0x33333333) | e << 1) & 0x55555555) << 1
            }

            function nX(t, e, i, s, r, n, a, h) {
                return (r - a) * (e - h) >= (t - a) * (n - h) && (t - a) * (s - h) >= (i - a) * (e - h) && (i - a) * (n - h) >= (r - a) * (s - h)
            }

            function nZ(t, e, i, s, r, n, a, h) {
                return (t !== a || e !== h) && nX(t, e, i, s, r, n, a, h)
            }

            function nY(t, e, i) {
                return (e.y - t.y) * (i.x - e.x) - (e.x - t.x) * (i.y - e.y)
            }

            function nG(t, e) {
                return t.x === e.x && t.y === e.y
            }

            function nQ(t, e, i, s) {
                let r = nK(nY(t, e, i)),
                    n = nK(nY(t, e, s)),
                    a = nK(nY(i, s, t)),
                    h = nK(nY(i, s, e));
                return !!(r !== n && a !== h || 0 === r && n$(t, i, e) || 0 === n && n$(t, s, e) || 0 === a && n$(i, t, s) || 0 === h && n$(i, e, s))
            }

            function n$(t, e, i) {
                return e.x <= Math.max(t.x, i.x) && e.x >= Math.min(t.x, i.x) && e.y <= Math.max(t.y, i.y) && e.y >= Math.min(t.y, i.y)
            }

            function nK(t) {
                return t > 0 ? 1 : t < 0 ? -1 : 0
            }

            function n0(t, e) {
                return 0 > nY(t.prev, t, t.next) ? nY(t, e, t.next) >= 0 && nY(t, t.prev, e) >= 0 : 0 > nY(t, e, t.prev) || 0 > nY(t, t.next, e)
            }

            function n1(t, e) {
                let i = n5(t.i, t.x, t.y),
                    s = n5(e.i, e.x, e.y),
                    r = t.next,
                    n = e.prev;
                return t.next = e, e.prev = t, i.next = r, r.prev = i, s.next = i, i.prev = s, n.next = s, s.prev = n, s
            }

            function n2(t, e, i, s) {
                let r = n5(t, e, i);
                return s ? (r.next = s.next, r.prev = s, s.next.prev = r, s.next = r) : (r.prev = r, r.next = r), r
            }

            function n3(t) {
                t.next.prev = t.prev, t.prev.next = t.next, t.prevZ && (t.prevZ.nextZ = t.nextZ), t.nextZ && (t.nextZ.prevZ = t.prevZ)
            }

            function n5(t, e, i) {
                return {
                    i: t,
                    x: e,
                    y: i,
                    prev: null,
                    next: null,
                    z: 0,
                    prevZ: null,
                    nextZ: null,
                    steiner: !1
                }
            }
            class n4 {
                static triangulate(t, e, i = 2) {
                    return function(t, e, i = 2) {
                        let s, r, n, a = e && e.length,
                            h = a ? e[0] * i : t.length,
                            o = nU(t, 0, h, i, !0),
                            l = [];
                        if (!o || o.next === o.prev) return l;
                        if (a && (o = function(t, e, i, s) {
                                let r = [];
                                for (let i = 0, n = e.length; i < n; i++) {
                                    let a = e[i] * s,
                                        h = i < n - 1 ? e[i + 1] * s : t.length,
                                        o = nU(t, a, h, s, !1);
                                    o === o.next && (o.steiner = !0), r.push(function(t) {
                                        let e = t,
                                            i = t;
                                        do(e.x < i.x || e.x === i.x && e.y < i.y) && (i = e), e = e.next; while (e !== t);
                                        return i
                                    }(o))
                                }
                                r.sort(nq);
                                for (let t = 0; t < r.length; t++) i = function(t, e) {
                                    let i = function(t, e) {
                                        let i, s = e,
                                            r = t.x,
                                            n = t.y,
                                            a = -1 / 0;
                                        if (nG(t, s)) return s;
                                        do {
                                            if (nG(t, s.next)) return s.next;
                                            if (n <= s.y && n >= s.next.y && s.next.y !== s.y) {
                                                let t = s.x + (n - s.y) * (s.next.x - s.x) / (s.next.y - s.y);
                                                if (t <= r && t > a && (a = t, i = s.x < s.next.x ? s : s.next, t === r)) return i
                                            }
                                            s = s.next
                                        } while (s !== e);
                                        if (!i) return null;
                                        let h = i,
                                            o = i.x,
                                            l = i.y,
                                            u = 1 / 0;
                                        s = i;
                                        do {
                                            if (r >= s.x && s.x >= o && r !== s.x && nX(n < l ? r : a, n, o, l, n < l ? a : r, n, s.x, s.y)) {
                                                var c, p;
                                                let e = Math.abs(n - s.y) / (r - s.x);
                                                n0(s, t) && (e < u || e === u && (s.x > i.x || s.x === i.x && (c = i, p = s, 0 > nY(c.prev, c, p.prev) && 0 > nY(p.next, c, c.next)))) && (i = s, u = e)
                                            }
                                            s = s.next
                                        } while (s !== h);
                                        return i
                                    }(t, e);
                                    if (!i) return e;
                                    let s = n1(i, t);
                                    return nJ(s, s.next), nJ(i, i.next)
                                }(r[t], i);
                                return i
                            }(t, e, o, i)), t.length > 80 * i) {
                            s = t[0], r = t[1];
                            let e = s,
                                a = r;
                            for (let n = i; n < h; n += i) {
                                let i = t[n],
                                    h = t[n + 1];
                                i < s && (s = i), h < r && (r = h), i > e && (e = i), h > a && (a = h)
                            }
                            n = 0 !== (n = Math.max(e - s, a - r)) ? 32767 / n : 0
                        }
                        return function t(e, i, s, r, n, a, h) {
                            if (!e) return;
                            !h && a && function(t, e, i, s) {
                                let r = t;
                                do 0 === r.z && (r.z = nH(r.x, r.y, e, i, s)), r.prevZ = r.prev, r.nextZ = r.next, r = r.next; while (r !== t);
                                r.prevZ.nextZ = null, r.prevZ = null,
                                    function(t) {
                                        let e, i = 1;
                                        do {
                                            let s, r = t;
                                            t = null;
                                            let n = null;
                                            for (e = 0; r;) {
                                                e++;
                                                let a = r,
                                                    h = 0;
                                                for (let t = 0; t < i && (h++, a = a.nextZ); t++);
                                                let o = i;
                                                for (; h > 0 || o > 0 && a;) 0 !== h && (0 === o || !a || r.z <= a.z) ? (s = r, r = r.nextZ, h--) : (s = a, a = a.nextZ, o--), n ? n.nextZ = s : t = s, s.prevZ = n, n = s;
                                                r = a
                                            }
                                            n.nextZ = null, i *= 2
                                        } while (e > 1)
                                    }(r)
                            }(e, r, n, a);
                            let o = e;
                            for (; e.prev !== e.next;) {
                                let l = e.prev,
                                    u = e.next;
                                if (a ? function(t, e, i, s) {
                                        let r = t.prev,
                                            n = t.next;
                                        if (nY(r, t, n) >= 0) return !1;
                                        let a = r.x,
                                            h = t.x,
                                            o = n.x,
                                            l = r.y,
                                            u = t.y,
                                            c = n.y,
                                            p = Math.min(a, h, o),
                                            d = Math.min(l, u, c),
                                            m = Math.max(a, h, o),
                                            y = Math.max(l, u, c),
                                            f = nH(p, d, e, i, s),
                                            g = nH(m, y, e, i, s),
                                            x = t.prevZ,
                                            v = t.nextZ;
                                        for (; x && x.z >= f && v && v.z <= g;) {
                                            if (x.x >= p && x.x <= m && x.y >= d && x.y <= y && x !== r && x !== n && nZ(a, l, h, u, o, c, x.x, x.y) && nY(x.prev, x, x.next) >= 0 || (x = x.prevZ, v.x >= p && v.x <= m && v.y >= d && v.y <= y && v !== r && v !== n && nZ(a, l, h, u, o, c, v.x, v.y) && nY(v.prev, v, v.next) >= 0)) return !1;
                                            v = v.nextZ
                                        }
                                        for (; x && x.z >= f;) {
                                            if (x.x >= p && x.x <= m && x.y >= d && x.y <= y && x !== r && x !== n && nZ(a, l, h, u, o, c, x.x, x.y) && nY(x.prev, x, x.next) >= 0) return !1;
                                            x = x.prevZ
                                        }
                                        for (; v && v.z <= g;) {
                                            if (v.x >= p && v.x <= m && v.y >= d && v.y <= y && v !== r && v !== n && nZ(a, l, h, u, o, c, v.x, v.y) && nY(v.prev, v, v.next) >= 0) return !1;
                                            v = v.nextZ
                                        }
                                        return !0
                                    }(e, r, n, a) : function(t) {
                                        let e = t.prev,
                                            i = t.next;
                                        if (nY(e, t, i) >= 0) return !1;
                                        let s = e.x,
                                            r = t.x,
                                            n = i.x,
                                            a = e.y,
                                            h = t.y,
                                            o = i.y,
                                            l = Math.min(s, r, n),
                                            u = Math.min(a, h, o),
                                            c = Math.max(s, r, n),
                                            p = Math.max(a, h, o),
                                            d = i.next;
                                        for (; d !== e;) {
                                            if (d.x >= l && d.x <= c && d.y >= u && d.y <= p && nZ(s, a, r, h, n, o, d.x, d.y) && nY(d.prev, d, d.next) >= 0) return !1;
                                            d = d.next
                                        }
                                        return !0
                                    }(e)) {
                                    i.push(l.i, e.i, u.i), n3(e), e = u.next, o = u.next;
                                    continue
                                }
                                if ((e = u) === o) {
                                    h ? 1 === h ? t(e = function(t, e) {
                                        let i = t;
                                        do {
                                            let s = i.prev,
                                                r = i.next.next;
                                            !nG(s, r) && nQ(s, i, i.next, r) && n0(s, r) && n0(r, s) && (e.push(s.i, i.i, r.i), n3(i), n3(i.next), i = t = r), i = i.next
                                        } while (i !== t);
                                        return nJ(i)
                                    }(nJ(e), i), i, s, r, n, a, 2) : 2 === h && function(e, i, s, r, n, a) {
                                        let h = e;
                                        do {
                                            let e = h.next.next;
                                            for (; e !== h.prev;) {
                                                var o, l;
                                                if (h.i !== e.i && (o = h, l = e, o.next.i !== l.i && o.prev.i !== l.i && ! function(t, e) {
                                                        let i = t;
                                                        do {
                                                            if (i.i !== t.i && i.next.i !== t.i && i.i !== e.i && i.next.i !== e.i && nQ(i, i.next, t, e)) return !0;
                                                            i = i.next
                                                        } while (i !== t);
                                                        return !1
                                                    }(o, l) && (n0(o, l) && n0(l, o) && function(t, e) {
                                                        let i = t,
                                                            s = !1,
                                                            r = (t.x + e.x) / 2,
                                                            n = (t.y + e.y) / 2;
                                                        do i.y > n != i.next.y > n && i.next.y !== i.y && r < (i.next.x - i.x) * (n - i.y) / (i.next.y - i.y) + i.x && (s = !s), i = i.next; while (i !== t);
                                                        return s
                                                    }(o, l) && (nY(o.prev, o, l.prev) || nY(o, l.prev, l)) || nG(o, l) && nY(o.prev, o, o.next) > 0 && nY(l.prev, l, l.next) > 0))) {
                                                    let o = n1(h, e);
                                                    h = nJ(h, h.next), o = nJ(o, o.next), t(h, i, s, r, n, a, 0), t(o, i, s, r, n, a, 0);
                                                    return
                                                }
                                                e = e.next
                                            }
                                            h = h.next
                                        } while (h !== e)
                                    }(e, i, s, r, n, a) : t(nJ(e), i, s, r, n, a, 1);
                                    break
                                }
                            }
                        }(o, l, i, s, r, n, 0), l
                    }(t, e, i)
                }
            }
            class n6 {
                static area(t) {
                    let e = t.length,
                        i = 0;
                    for (let s = e - 1, r = 0; r < e; s = r++) i += t[s].x * t[r].y - t[r].x * t[s].y;
                    return .5 * i
                }
                static isClockWise(t) {
                    return 0 > n6.area(t)
                }
                static triangulateShape(t, e) {
                    let i = [],
                        s = [],
                        r = [];
                    n8(t), n9(i, t);
                    let n = t.length;
                    e.forEach(n8);
                    for (let t = 0; t < e.length; t++) s.push(n), n += e[t].length, n9(i, e[t]);
                    let a = n4.triangulate(i, s);
                    for (let t = 0; t < a.length; t += 3) r.push(a.slice(t, t + 3));
                    return r
                }
            }

            function n8(t) {
                let e = t.length;
                e > 2 && t[e - 1].equals(t[0]) && t.pop()
            }

            function n9(t, e) {
                for (let i = 0; i < e.length; i++) t.push(e[i].x), t.push(e[i].y)
            }
            class n7 extends sJ {
                constructor(t = new nW([new e6(.5, .5), new e6(-.5, .5), new e6(-.5, -.5), new e6(.5, -.5)]), e = {}) {
                    super(), this.type = "ExtrudeGeometry", this.parameters = {
                        shapes: t,
                        options: e
                    }, t = Array.isArray(t) ? t : [t];
                    const i = this,
                        s = [],
                        r = [];
                    for (let n = 0, a = t.length; n < a; n++) ! function(t) {
                        let n, a, h, o, l, u = [],
                            c = void 0 !== e.curveSegments ? e.curveSegments : 12,
                            p = void 0 !== e.steps ? e.steps : 1,
                            d = void 0 !== e.depth ? e.depth : 1,
                            m = void 0 === e.bevelEnabled || e.bevelEnabled,
                            y = void 0 !== e.bevelThickness ? e.bevelThickness : .2,
                            f = void 0 !== e.bevelSize ? e.bevelSize : y - .1,
                            g = void 0 !== e.bevelOffset ? e.bevelOffset : 0,
                            x = void 0 !== e.bevelSegments ? e.bevelSegments : 3,
                            v = e.extrudePath,
                            M = void 0 !== e.UVGenerator ? e.UVGenerator : at,
                            b, w = !1;
                        if (v) {
                            b = v.getSpacedPoints(p), w = !0, m = !1;
                            let t = !!v.isCatmullRomCurve3 && v.closed;
                            n = v.computeFrenetFrames(p, t), a = new e9, h = new e9, o = new e9
                        }
                        m || (x = 0, y = 0, f = 0, g = 0);
                        let S = t.extractPoints(c),
                            _ = S.shape,
                            z = S.holes;
                        if (!n6.isClockWise(_)) {
                            _ = _.reverse();
                            for (let t = 0, e = z.length; t < e; t++) {
                                let e = z[t];
                                n6.isClockWise(e) && (z[t] = e.reverse())
                            }
                        }

                        function A(t) {
                            let e = 1e-10 * 1e-10,
                                i = t[0];
                            for (let s = 1; s <= t.length; s++) {
                                let r = s % t.length,
                                    n = t[r],
                                    a = n.x - i.x,
                                    h = n.y - i.y,
                                    o = a * a + h * h,
                                    l = Math.max(Math.abs(n.x), Math.abs(n.y), Math.abs(i.x), Math.abs(i.y));
                                if (o <= e * l * l) {
                                    t.splice(r, 1), s--;
                                    continue
                                }
                                i = n
                            }
                        }
                        A(_), z.forEach(A);
                        let T = z.length,
                            C = _;
                        for (let t = 0; t < T; t++) {
                            let e = z[t];
                            _ = _.concat(e)
                        }

                        function k(t, e, i) {
                            return e || eJ("ExtrudeGeometry: vec does not exist"), t.clone().addScaledVector(e, i)
                        }
                        let B = _.length;

                        function O(t, e, i) {
                            let s, r, n, a = t.x - e.x,
                                h = t.y - e.y,
                                o = i.x - t.x,
                                l = i.y - t.y,
                                u = a * a + h * h;
                            if (Math.abs(a * l - h * o) > Number.EPSILON) {
                                let c = Math.sqrt(u),
                                    p = Math.sqrt(o * o + l * l),
                                    d = e.x - h / c,
                                    m = e.y + a / c,
                                    y = ((i.x - l / p - d) * l - (i.y + o / p - m) * o) / (a * l - h * o),
                                    f = (s = d + a * y - t.x) * s + (r = m + h * y - t.y) * r;
                                if (f <= 2) return new e6(s, r);
                                n = Math.sqrt(f / 2)
                            } else {
                                let t = !1;
                                a > Number.EPSILON ? o > Number.EPSILON && (t = !0) : a < -Number.EPSILON ? o < -Number.EPSILON && (t = !0) : Math.sign(h) === Math.sign(l) && (t = !0), t ? (s = -h, r = a, n = Math.sqrt(u)) : (s = a, r = h, n = Math.sqrt(u / 2))
                            }
                            return new e6(s / n, r / n)
                        }
                        let I = [];
                        for (let t = 0, e = C.length, i = e - 1, s = t + 1; t < e; t++, i++, s++) i === e && (i = 0), s === e && (s = 0), I[t] = O(C[t], C[i], C[s]);
                        let N = [],
                            P, R = I.concat();
                        for (let t = 0; t < T; t++) {
                            let e = z[t];
                            P = [];
                            for (let t = 0, i = e.length, s = i - 1, r = t + 1; t < i; t++, s++, r++) s === i && (s = 0), r === i && (r = 0), P[t] = O(e[t], e[s], e[r]);
                            N.push(P), R = R.concat(P)
                        }
                        if (0 === x) l = n6.triangulateShape(C, z);
                        else {
                            let t = [],
                                e = [];
                            for (let i = 0; i < x; i++) {
                                let s = i / x,
                                    r = y * Math.cos(s * Math.PI / 2),
                                    n = f * Math.sin(s * Math.PI / 2) + g;
                                for (let e = 0, i = C.length; e < i; e++) {
                                    let i = k(C[e], I[e], n);
                                    L(i.x, i.y, -r), 0 === s && t.push(i)
                                }
                                for (let t = 0; t < T; t++) {
                                    let i = z[t];
                                    P = N[t];
                                    let a = [];
                                    for (let t = 0, e = i.length; t < e; t++) {
                                        let e = k(i[t], P[t], n);
                                        L(e.x, e.y, -r), 0 === s && a.push(e)
                                    }
                                    0 === s && e.push(a)
                                }
                            }
                            l = n6.triangulateShape(t, e)
                        }
                        let V = l.length,
                            E = f + g;
                        for (let t = 0; t < B; t++) {
                            let e = m ? k(_[t], R[t], E) : _[t];
                            w ? (h.copy(n.normals[0]).multiplyScalar(e.x), a.copy(n.binormals[0]).multiplyScalar(e.y), o.copy(b[0]).add(h).add(a), L(o.x, o.y, o.z)) : L(e.x, e.y, 0)
                        }
                        for (let t = 1; t <= p; t++)
                            for (let e = 0; e < B; e++) {
                                let i = m ? k(_[e], R[e], E) : _[e];
                                w ? (h.copy(n.normals[t]).multiplyScalar(i.x), a.copy(n.binormals[t]).multiplyScalar(i.y), o.copy(b[t]).add(h).add(a), L(o.x, o.y, o.z)) : L(i.x, i.y, d / p * t)
                            }
                        for (let t = x - 1; t >= 0; t--) {
                            let e = t / x,
                                i = y * Math.cos(e * Math.PI / 2),
                                s = f * Math.sin(e * Math.PI / 2) + g;
                            for (let t = 0, e = C.length; t < e; t++) {
                                let e = k(C[t], I[t], s);
                                L(e.x, e.y, d + i)
                            }
                            for (let t = 0, e = z.length; t < e; t++) {
                                let e = z[t];
                                P = N[t];
                                for (let t = 0, r = e.length; t < r; t++) {
                                    let r = k(e[t], P[t], s);
                                    w ? L(r.x, r.y + b[p - 1].y, b[p - 1].x + i) : L(r.x, r.y, d + i)
                                }
                            }
                        }

                        function F(t, e) {
                            let r = t.length;
                            for (; --r >= 0;) {
                                let n = r,
                                    a = r - 1;
                                a < 0 && (a = t.length - 1);
                                for (let t = 0, r = p + 2 * x; t < r; t++) {
                                    let r = B * t,
                                        h = B * (t + 1);
                                    ! function(t, e, r, n) {
                                        D(t), D(e), D(n), D(e), D(r), D(n);
                                        let a = s.length / 3,
                                            h = M.generateSideWallUV(i, s, a - 6, a - 3, a - 2, a - 1);
                                        W(h[0]), W(h[1]), W(h[3]), W(h[1]), W(h[2]), W(h[3])
                                    }(e + n + r, e + a + r, e + a + h, e + n + h)
                                }
                            }
                        }

                        function L(t, e, i) {
                            u.push(t), u.push(e), u.push(i)
                        }

                        function j(t, e, r) {
                            D(t), D(e), D(r);
                            let n = s.length / 3,
                                a = M.generateTopUV(i, s, n - 3, n - 2, n - 1);
                            W(a[0]), W(a[1]), W(a[2])
                        }

                        function D(t) {
                            s.push(u[3 * t + 0]), s.push(u[3 * t + 1]), s.push(u[3 * t + 2])
                        }

                        function W(t) {
                            r.push(t.x), r.push(t.y)
                        }(function() {
                            let t = s.length / 3;
                            if (m) {
                                let t = 0 * B;
                                for (let e = 0; e < V; e++) {
                                    let i = l[e];
                                    j(i[2] + t, i[1] + t, i[0] + t)
                                }
                                t = B * (p + 2 * x);
                                for (let e = 0; e < V; e++) {
                                    let i = l[e];
                                    j(i[0] + t, i[1] + t, i[2] + t)
                                }
                            } else {
                                for (let t = 0; t < V; t++) {
                                    let e = l[t];
                                    j(e[2], e[1], e[0])
                                }
                                for (let t = 0; t < V; t++) {
                                    let e = l[t];
                                    j(e[0] + B * p, e[1] + B * p, e[2] + B * p)
                                }
                            }
                            i.addGroup(t, s.length / 3 - t, 0)
                        })(),
                        function() {
                            let t = s.length / 3,
                                e = 0;
                            F(C, 0), e += C.length;
                            for (let t = 0, i = z.length; t < i; t++) {
                                let i = z[t];
                                F(i, e), e += i.length
                            }
                            i.addGroup(t, s.length / 3 - t, 1)
                        }()
                    }(t[n]);
                    this.setAttribute("position", new sI(s, 3)), this.setAttribute("uv", new sI(r, 2)), this.computeVertexNormals()
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return function(t, e, i) {
                        if (i.shapes = [], Array.isArray(t))
                            for (let e = 0, s = t.length; e < s; e++) {
                                let s = t[e];
                                i.shapes.push(s.uuid)
                            } else i.shapes.push(t.uuid);
                        return i.options = Object.assign({}, e), void 0 !== e.extrudePath && (i.options.extrudePath = e.extrudePath.toJSON()), i
                    }(this.parameters.shapes, this.parameters.options, t)
                }
                static fromJSON(t, e) {
                    let i = [];
                    for (let s = 0, r = t.shapes.length; s < r; s++) {
                        let r = e[t.shapes[s]];
                        i.push(r)
                    }
                    let s = t.options.extrudePath;
                    return void 0 !== s && (t.options.extrudePath = new nL[s.type]().fromJSON(s)), new n7(i, t.options)
                }
            }
            let at = {
                generateTopUV: function(t, e, i, s, r) {
                    let n = e[3 * i],
                        a = e[3 * i + 1],
                        h = e[3 * s],
                        o = e[3 * s + 1],
                        l = e[3 * r],
                        u = e[3 * r + 1];
                    return [new e6(n, a), new e6(h, o), new e6(l, u)]
                },
                generateSideWallUV: function(t, e, i, s, r, n) {
                    let a = e[3 * i],
                        h = e[3 * i + 1],
                        o = e[3 * i + 2],
                        l = e[3 * s],
                        u = e[3 * s + 1],
                        c = e[3 * s + 2],
                        p = e[3 * r],
                        d = e[3 * r + 1],
                        m = e[3 * r + 2],
                        y = e[3 * n],
                        f = e[3 * n + 1],
                        g = e[3 * n + 2];
                    return Math.abs(h - u) < Math.abs(a - l) ? [new e6(a, 1 - o), new e6(l, 1 - c), new e6(p, 1 - m), new e6(y, 1 - g)] : [new e6(h, 1 - o), new e6(u, 1 - c), new e6(d, 1 - m), new e6(f, 1 - g)]
                }
            };
            class ae extends nx {
                constructor(t = 1, e = 0) {
                    const i = (1 + Math.sqrt(5)) / 2;
                    super([-1, i, 0, 1, i, 0, -1, -i, 0, 1, -i, 0, 0, -1, i, 0, 1, i, 0, -1, -i, 0, 1, -i, i, 0, -1, i, 0, 1, -i, 0, -1, -i, 0, 1], [0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11, 1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8, 3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9, 4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1], t, e), this.type = "IcosahedronGeometry", this.parameters = {
                        radius: t,
                        detail: e
                    }
                }
                static fromJSON(t) {
                    return new ae(t.radius, t.detail)
                }
            }
            class ai extends sJ {
                constructor(t = [new e6(0, -.5), new e6(.5, 0), new e6(0, .5)], e = 12, i = 0, s = 2 * Math.PI) {
                    super(), this.type = "LatheGeometry", this.parameters = {
                        points: t,
                        segments: e,
                        phiStart: i,
                        phiLength: s
                    }, e = Math.floor(e), s = e0(s, 0, 2 * Math.PI);
                    const r = [],
                        n = [],
                        a = [],
                        h = [],
                        o = [],
                        l = 1 / e,
                        u = new e9,
                        c = new e6,
                        p = new e9,
                        d = new e9,
                        m = new e9;
                    let y = 0,
                        f = 0;
                    for (let e = 0; e <= t.length - 1; e++) switch (e) {
                        case 0:
                            y = t[e + 1].x - t[e].x, p.x = +(f = t[e + 1].y - t[e].y), p.y = -y, p.z = 0 * f, m.copy(p), p.normalize(), h.push(p.x, p.y, p.z);
                            break;
                        case t.length - 1:
                            h.push(m.x, m.y, m.z);
                            break;
                        default:
                            y = t[e + 1].x - t[e].x, p.x = +(f = t[e + 1].y - t[e].y), p.y = -y, p.z = 0 * f, d.copy(p), p.x += m.x, p.y += m.y, p.z += m.z, p.normalize(), h.push(p.x, p.y, p.z), m.copy(d)
                    }
                    for (let r = 0; r <= e; r++) {
                        const p = i + r * l * s,
                            d = Math.sin(p),
                            m = Math.cos(p);
                        for (let i = 0; i <= t.length - 1; i++) {
                            u.x = t[i].x * d, u.y = t[i].y, u.z = t[i].x * m, n.push(u.x, u.y, u.z), c.x = r / e, c.y = i / (t.length - 1), a.push(c.x, c.y);
                            const s = h[3 * i + 0] * d,
                                l = h[3 * i + 1],
                                p = h[3 * i + 0] * m;
                            o.push(s, l, p)
                        }
                    }
                    for (let i = 0; i < e; i++)
                        for (let e = 0; e < t.length - 1; e++) {
                            const s = e + i * t.length,
                                n = s + t.length,
                                a = s + t.length + 1,
                                h = s + 1;
                            r.push(s, n, h), r.push(a, h, n)
                        }
                    this.setIndex(r), this.setAttribute("position", new sI(n, 3)), this.setAttribute("uv", new sI(a, 2)), this.setAttribute("normal", new sI(o, 3))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new ai(t.points, t.segments, t.phiStart, t.phiLength)
                }
            }
            class as extends nx {
                constructor(t = 1, e = 0) {
                    super([1, 0, 0, -1, 0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 1, 0, 0, -1], [0, 2, 4, 0, 4, 3, 0, 3, 5, 0, 5, 2, 1, 2, 5, 1, 5, 3, 1, 3, 4, 1, 4, 2], t, e), this.type = "OctahedronGeometry", this.parameters = {
                        radius: t,
                        detail: e
                    }
                }
                static fromJSON(t) {
                    return new as(t.radius, t.detail)
                }
            }
            class ar extends sJ {
                constructor(t = 1, e = 1, i = 1, s = 1) {
                    super(), this.type = "PlaneGeometry", this.parameters = {
                        width: t,
                        height: e,
                        widthSegments: i,
                        heightSegments: s
                    };
                    const r = t / 2,
                        n = e / 2,
                        a = Math.floor(i),
                        h = Math.floor(s),
                        o = a + 1,
                        l = h + 1,
                        u = t / a,
                        c = e / h,
                        p = [],
                        d = [],
                        m = [],
                        y = [];
                    for (let t = 0; t < l; t++) {
                        const e = t * c - n;
                        for (let i = 0; i < o; i++) {
                            const s = i * u - r;
                            d.push(s, -e, 0), m.push(0, 0, 1), y.push(i / a), y.push(1 - t / h)
                        }
                    }
                    for (let t = 0; t < h; t++)
                        for (let e = 0; e < a; e++) {
                            const i = e + o * t,
                                s = e + o * (t + 1),
                                r = e + 1 + o * (t + 1),
                                n = e + 1 + o * t;
                            p.push(i, s, n), p.push(s, r, n)
                        }
                    this.setIndex(p), this.setAttribute("position", new sI(d, 3)), this.setAttribute("normal", new sI(m, 3)), this.setAttribute("uv", new sI(y, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new ar(t.width, t.height, t.widthSegments, t.heightSegments)
                }
            }
            class an extends sJ {
                constructor(t = .5, e = 1, i = 32, s = 1, r = 0, n = 2 * Math.PI) {
                    super(), this.type = "RingGeometry", this.parameters = {
                        innerRadius: t,
                        outerRadius: e,
                        thetaSegments: i,
                        phiSegments: s,
                        thetaStart: r,
                        thetaLength: n
                    }, i = Math.max(3, i);
                    const a = [],
                        h = [],
                        o = [],
                        l = [];
                    let u = t;
                    const c = (e - t) / (s = Math.max(1, s)),
                        p = new e9,
                        d = new e6;
                    for (let t = 0; t <= s; t++) {
                        for (let t = 0; t <= i; t++) {
                            const s = r + t / i * n;
                            p.x = u * Math.cos(s), p.y = u * Math.sin(s), h.push(p.x, p.y, p.z), o.push(0, 0, 1), d.x = (p.x / e + 1) / 2, d.y = (p.y / e + 1) / 2, l.push(d.x, d.y)
                        }
                        u += c
                    }
                    for (let t = 0; t < s; t++) {
                        const e = t * (i + 1);
                        for (let t = 0; t < i; t++) {
                            const s = t + e,
                                r = s + i + 1,
                                n = s + i + 2,
                                h = s + 1;
                            a.push(s, r, h), a.push(r, n, h)
                        }
                    }
                    this.setIndex(a), this.setAttribute("position", new sI(h, 3)), this.setAttribute("normal", new sI(o, 3)), this.setAttribute("uv", new sI(l, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new an(t.innerRadius, t.outerRadius, t.thetaSegments, t.phiSegments, t.thetaStart, t.thetaLength)
                }
            }
            class aa extends sJ {
                constructor(t = new nW([new e6(0, .5), new e6(-.5, -.5), new e6(.5, -.5)]), e = 12) {
                    super(), this.type = "ShapeGeometry", this.parameters = {
                        shapes: t,
                        curveSegments: e
                    };
                    const i = [],
                        s = [],
                        r = [],
                        n = [];
                    let a = 0,
                        h = 0;
                    if (!1 === Array.isArray(t)) o(t);
                    else
                        for (let e = 0; e < t.length; e++) o(t[e]), this.addGroup(a, h, e), a += h, h = 0;

                    function o(t) {
                        let a = s.length / 3,
                            o = t.extractPoints(e),
                            l = o.shape,
                            u = o.holes;
                        !1 === n6.isClockWise(l) && (l = l.reverse());
                        for (let t = 0, e = u.length; t < e; t++) {
                            let e = u[t];
                            !0 === n6.isClockWise(e) && (u[t] = e.reverse())
                        }
                        let c = n6.triangulateShape(l, u);
                        for (let t = 0, e = u.length; t < e; t++) {
                            let e = u[t];
                            l = l.concat(e)
                        }
                        for (let t = 0, e = l.length; t < e; t++) {
                            let e = l[t];
                            s.push(e.x, e.y, 0), r.push(0, 0, 1), n.push(e.x, e.y)
                        }
                        for (let t = 0, e = c.length; t < e; t++) {
                            let e = c[t],
                                s = e[0] + a,
                                r = e[1] + a,
                                n = e[2] + a;
                            i.push(s, r, n), h += 3
                        }
                    }
                    this.setIndex(i), this.setAttribute("position", new sI(s, 3)), this.setAttribute("normal", new sI(r, 3)), this.setAttribute("uv", new sI(n, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return function(t, e) {
                        if (e.shapes = [], Array.isArray(t))
                            for (let i = 0, s = t.length; i < s; i++) {
                                let s = t[i];
                                e.shapes.push(s.uuid)
                            } else e.shapes.push(t.uuid);
                        return e
                    }(this.parameters.shapes, t)
                }
                static fromJSON(t, e) {
                    let i = [];
                    for (let s = 0, r = t.shapes.length; s < r; s++) {
                        let r = e[t.shapes[s]];
                        i.push(r)
                    }
                    return new aa(i, t.curveSegments)
                }
            }
            class ah extends sJ {
                constructor(t = 1, e = 32, i = 16, s = 0, r = 2 * Math.PI, n = 0, a = Math.PI) {
                    super(), this.type = "SphereGeometry", this.parameters = {
                        radius: t,
                        widthSegments: e,
                        heightSegments: i,
                        phiStart: s,
                        phiLength: r,
                        thetaStart: n,
                        thetaLength: a
                    }, e = Math.max(3, Math.floor(e)), i = Math.max(2, Math.floor(i));
                    const h = Math.min(n + a, Math.PI);
                    let o = 0;
                    const l = [],
                        u = new e9,
                        c = new e9,
                        p = [],
                        d = [],
                        m = [],
                        y = [];
                    for (let p = 0; p <= i; p++) {
                        const f = [],
                            g = p / i,
                            x = t * Math.cos(n + g * a),
                            v = Math.sqrt(t * t - x * x);
                        let M = 0;
                        0 === p && 0 === n ? M = .5 / e : p === i && h === Math.PI && (M = -.5 / e);
                        for (let t = 0; t <= e; t++) {
                            const i = t / e,
                                n = s + i * r;
                            u.x = -v * Math.cos(n), u.y = x, u.z = v * Math.sin(n), d.push(u.x, u.y, u.z), c.copy(u).normalize(), m.push(c.x, c.y, c.z), y.push(i + M, 1 - g), f.push(o++)
                        }
                        l.push(f)
                    }
                    for (let t = 0; t < i; t++)
                        for (let s = 0; s < e; s++) {
                            const e = l[t][s + 1],
                                r = l[t][s],
                                a = l[t + 1][s],
                                o = l[t + 1][s + 1];
                            (0 !== t || n > 0) && p.push(e, r, o), (t !== i - 1 || h < Math.PI) && p.push(r, a, o)
                        }
                    this.setIndex(p), this.setAttribute("position", new sI(d, 3)), this.setAttribute("normal", new sI(m, 3)), this.setAttribute("uv", new sI(y, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new ah(t.radius, t.widthSegments, t.heightSegments, t.phiStart, t.phiLength, t.thetaStart, t.thetaLength)
                }
            }
            class ao extends sJ {
                constructor(t = 1, e = .4, i = 12, s = 48, r = 2 * Math.PI, n = 0, a = 2 * Math.PI) {
                    super(), this.type = "TorusGeometry", this.parameters = {
                        radius: t,
                        tube: e,
                        radialSegments: i,
                        tubularSegments: s,
                        arc: r,
                        thetaStart: n,
                        thetaLength: a
                    }, i = Math.floor(i), s = Math.floor(s);
                    const h = [],
                        o = [],
                        l = [],
                        u = [],
                        c = new e9,
                        p = new e9,
                        d = new e9;
                    for (let h = 0; h <= i; h++) {
                        const m = n + h / i * a;
                        for (let n = 0; n <= s; n++) {
                            const a = n / s * r;
                            p.x = (t + e * Math.cos(m)) * Math.cos(a), p.y = (t + e * Math.cos(m)) * Math.sin(a), p.z = e * Math.sin(m), o.push(p.x, p.y, p.z), c.x = t * Math.cos(a), c.y = t * Math.sin(a), d.subVectors(p, c).normalize(), l.push(d.x, d.y, d.z), u.push(n / s), u.push(h / i)
                        }
                    }
                    for (let t = 1; t <= i; t++)
                        for (let e = 1; e <= s; e++) {
                            const i = (s + 1) * t + e - 1,
                                r = (s + 1) * (t - 1) + e - 1,
                                n = (s + 1) * (t - 1) + e,
                                a = (s + 1) * t + e;
                            h.push(i, r, a), h.push(r, n, a)
                        }
                    this.setIndex(h), this.setAttribute("position", new sI(o, 3)), this.setAttribute("normal", new sI(l, 3)), this.setAttribute("uv", new sI(u, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                static fromJSON(t) {
                    return new ao(t.radius, t.tube, t.radialSegments, t.tubularSegments, t.arc, t.thetaStart, t.thetaLength)
                }
            }
            class al extends sJ {
                constructor(t = new nE(new e9(-1, -1, 0), new e9(-1, 1, 0), new e9(1, 1, 0)), e = 64, i = 1, s = 8, r = !1) {
                    super(), this.type = "TubeGeometry", this.parameters = {
                        path: t,
                        tubularSegments: e,
                        radius: i,
                        radialSegments: s,
                        closed: r
                    };
                    const n = t.computeFrenetFrames(e, r);
                    this.tangents = n.tangents, this.normals = n.normals, this.binormals = n.binormals;
                    const a = new e9,
                        h = new e9,
                        o = new e6;
                    let l = new e9;
                    const u = [],
                        c = [],
                        p = [],
                        d = [];

                    function m(r) {
                        l = t.getPointAt(r / e, l);
                        let o = n.normals[r],
                            p = n.binormals[r];
                        for (let t = 0; t <= s; t++) {
                            let e = t / s * Math.PI * 2,
                                r = Math.sin(e),
                                n = -Math.cos(e);
                            h.x = n * o.x + r * p.x, h.y = n * o.y + r * p.y, h.z = n * o.z + r * p.z, h.normalize(), c.push(h.x, h.y, h.z), a.x = l.x + i * h.x, a.y = l.y + i * h.y, a.z = l.z + i * h.z, u.push(a.x, a.y, a.z)
                        }
                    }(function() {
                        for (let t = 0; t < e; t++) m(t);
                        m(!1 === r ? e : 0),
                            function() {
                                for (let t = 0; t <= e; t++)
                                    for (let i = 0; i <= s; i++) o.x = t / e, o.y = i / s, p.push(o.x, o.y)
                            }(),
                            function() {
                                for (let t = 1; t <= e; t++)
                                    for (let e = 1; e <= s; e++) {
                                        let i = (s + 1) * (t - 1) + (e - 1),
                                            r = (s + 1) * t + (e - 1),
                                            n = (s + 1) * t + e,
                                            a = (s + 1) * (t - 1) + e;
                                        d.push(i, r, a), d.push(r, n, a)
                                    }
                            }()
                    })(), this.setIndex(d), this.setAttribute("position", new sI(u, 3)), this.setAttribute("normal", new sI(c, 3)), this.setAttribute("uv", new sI(p, 2))
                }
                copy(t) {
                    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.path = this.parameters.path.toJSON(), t
                }
                static fromJSON(t) {
                    return new al(new nL[t.path.type]().fromJSON(t.path), t.tubularSegments, t.radius, t.radialSegments, t.closed)
                }
            }

            function au(t) {
                let e = {};
                for (let i in t)
                    for (let s in e[i] = {}, t[i]) {
                        let r = t[i][s];
                        if (ap(r)) r.isRenderTargetTexture ? (eU("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."), e[i][s] = null) : e[i][s] = r.clone();
                        else if (Array.isArray(r))
                            if (ap(r[0])) {
                                let t = [];
                                for (let e = 0, i = r.length; e < i; e++) t[e] = r[e].clone();
                                e[i][s] = t
                            } else e[i][s] = r.slice();
                        else e[i][s] = r
                    }
                return e
            }

            function ac(t) {
                let e = {};
                for (let i = 0; i < t.length; i++) {
                    let s = au(t[i]);
                    for (let t in s) e[t] = s[t]
                }
                return e
            }

            function ap(t) {
                return t && (t.isColor || t.isMatrix3 || t.isMatrix4 || t.isVector2 || t.isVector3 || t.isVector4 || t.isTexture || t.isQuaternion)
            }

            function ad(t) {
                let e = t.getRenderTarget();
                return null === e ? t.outputColorSpace : !0 === e.isXRRenderTarget ? e.texture.colorSpace : ia.workingColorSpace
            }
            let am = {
                clone: au,
                merge: ac
            };
            class ay extends sK {
                constructor(t) {
                    super(), this.isShaderMaterial = !0, this.type = "ShaderMaterial", this.defines = {}, this.uniforms = {}, this.uniformsGroups = [], this.vertexShader = "void main() {\n	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}", this.fragmentShader = "void main() {\n	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );\n}", this.linewidth = 1, this.wireframe = !1, this.wireframeLinewidth = 1, this.fog = !1, this.lights = !1, this.clipping = !1, this.forceSinglePass = !0, this.extensions = {
                        clipCullDistance: !1,
                        multiDraw: !1
                    }, this.defaultAttributeValues = {
                        color: [1, 1, 1],
                        uv: [0, 0],
                        uv1: [0, 0]
                    }, this.index0AttributeName = void 0, this.uniformsNeedUpdate = !1, this.glslVersion = null, void 0 !== t && this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.fragmentShader = t.fragmentShader, this.vertexShader = t.vertexShader, this.uniforms = au(t.uniforms), this.uniformsGroups = function(t) {
                        let e = [];
                        for (let i = 0; i < t.length; i++) e.push(t[i].clone());
                        return e
                    }(t.uniformsGroups), this.defines = Object.assign({}, t.defines), this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.fog = t.fog, this.lights = t.lights, this.clipping = t.clipping, this.extensions = Object.assign({}, t.extensions), this.glslVersion = t.glslVersion, this.defaultAttributeValues = Object.assign({}, t.defaultAttributeValues), this.index0AttributeName = t.index0AttributeName, this.uniformsNeedUpdate = t.uniformsNeedUpdate, this
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    for (let i in e.glslVersion = this.glslVersion, e.uniforms = {}, this.uniforms) {
                        let s = this.uniforms[i].value;
                        s && s.isTexture ? e.uniforms[i] = {
                            type: "t",
                            value: s.toJSON(t).uuid
                        } : s && s.isColor ? e.uniforms[i] = {
                            type: "c",
                            value: s.getHex()
                        } : s && s.isVector2 ? e.uniforms[i] = {
                            type: "v2",
                            value: s.toArray()
                        } : s && s.isVector3 ? e.uniforms[i] = {
                            type: "v3",
                            value: s.toArray()
                        } : s && s.isVector4 ? e.uniforms[i] = {
                            type: "v4",
                            value: s.toArray()
                        } : s && s.isMatrix3 ? e.uniforms[i] = {
                            type: "m3",
                            value: s.toArray()
                        } : s && s.isMatrix4 ? e.uniforms[i] = {
                            type: "m4",
                            value: s.toArray()
                        } : e.uniforms[i] = {
                            value: s
                        }
                    }
                    Object.keys(this.defines).length > 0 && (e.defines = this.defines), e.vertexShader = this.vertexShader, e.fragmentShader = this.fragmentShader, e.lights = this.lights, e.clipping = this.clipping;
                    let i = {};
                    for (let t in this.extensions) !0 === this.extensions[t] && (i[t] = !0);
                    return Object.keys(i).length > 0 && (e.extensions = i), e
                }
                fromJSON(t, e) {
                    if (super.fromJSON(t, e), void 0 !== t.uniforms)
                        for (let i in t.uniforms) {
                            let s = t.uniforms[i];
                            switch (this.uniforms[i] = {}, s.type) {
                                case "t":
                                    this.uniforms[i].value = e[s.value] || null;
                                    break;
                                case "c":
                                    this.uniforms[i].value = new i3().setHex(s.value);
                                    break;
                                case "v2":
                                    this.uniforms[i].value = new e6().fromArray(s.value);
                                    break;
                                case "v3":
                                    this.uniforms[i].value = new e9().fromArray(s.value);
                                    break;
                                case "v4":
                                    this.uniforms[i].value = new ig().fromArray(s.value);
                                    break;
                                case "m3":
                                    this.uniforms[i].value = new ie().fromArray(s.value);
                                    break;
                                case "m4":
                                    this.uniforms[i].value = new iw().fromArray(s.value);
                                    break;
                                default:
                                    this.uniforms[i].value = s.value
                            }
                        }
                    if (void 0 !== t.defines && (this.defines = t.defines), void 0 !== t.vertexShader && (this.vertexShader = t.vertexShader), void 0 !== t.fragmentShader && (this.fragmentShader = t.fragmentShader), void 0 !== t.glslVersion && (this.glslVersion = t.glslVersion), void 0 !== t.extensions)
                        for (let e in t.extensions) this.extensions[e] = t.extensions[e];
                    return void 0 !== t.lights && (this.lights = t.lights), void 0 !== t.clipping && (this.clipping = t.clipping), this
                }
            }
            class af extends ay {
                constructor(t) {
                    super(t), this.isRawShaderMaterial = !0, this.type = "RawShaderMaterial"
                }
            }
            class ag extends sK {
                constructor(t) {
                    super(), this.isMeshStandardMaterial = !0, this.type = "MeshStandardMaterial", this.defines = {
                        STANDARD: ""
                    }, this.color = new i3(0xffffff), this.roughness = 1, this.metalness = 0, this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new i3(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = eM, this.normalScale = new e6(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.roughnessMap = null, this.metalnessMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new iI, this.envMapIntensity = 1, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = !1, this.fog = !0, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.defines = {
                        STANDARD: ""
                    }, this.color.copy(t.color), this.roughness = t.roughness, this.metalness = t.metalness, this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.roughnessMap = t.roughnessMap, this.metalnessMap = t.metalnessMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.envMapIntensity = t.envMapIntensity, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this
                }
            }
            class ax extends sK {
                constructor(t) {
                    super(), this.isMeshToonMaterial = !0, this.defines = {
                        TOON: ""
                    }, this.type = "MeshToonMaterial", this.color = new i3(0xffffff), this.map = null, this.gradientMap = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new i3(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = eM, this.normalScale = new e6(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.alphaMap = null, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.fog = !0, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.gradientMap = t.gradientMap, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.alphaMap = t.alphaMap, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.fog = t.fog, this
                }
            }
            class av extends sK {
                constructor(t) {
                    super(), this.isMeshLambertMaterial = !0, this.type = "MeshLambertMaterial", this.color = new i3(0xffffff), this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new i3(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = eM, this.normalScale = new e6(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new iI, this.combine = K, this.reflectivity = 1, this.envMapIntensity = 1, this.refractionRatio = .98, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = !1, this.fog = !0, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.combine = t.combine, this.reflectivity = t.reflectivity, this.envMapIntensity = t.envMapIntensity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this
                }
            }
            class aM extends sK {
                constructor(t) {
                    super(), this.isMeshDepthMaterial = !0, this.type = "MeshDepthMaterial", this.depthPacking = 3200, this.map = null, this.alphaMap = null, this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.wireframe = !1, this.wireframeLinewidth = 1, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.depthPacking = t.depthPacking, this.map = t.map, this.alphaMap = t.alphaMap, this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this
                }
            }
            class ab extends sK {
                constructor(t) {
                    super(), this.isMeshDistanceMaterial = !0, this.type = "MeshDistanceMaterial", this.map = null, this.alphaMap = null, this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.setValues(t)
                }
                copy(t) {
                    return super.copy(t), this.map = t.map, this.alphaMap = t.alphaMap, this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this
                }
            }

            function aw(t, e) {
                return t && t.constructor !== e ? "number" == typeof e.BYTES_PER_ELEMENT ? new e(t) : Array.prototype.slice.call(t) : t
            }

            function aS(t) {
                return void 0 !== t && void 0 !== t.inTangents && void 0 !== t.outTangents
            }
            class a_ {
                constructor(t, e, i, s) {
                    this.parameterPositions = t, this._cachedIndex = 0, this.resultBuffer = void 0 !== s ? s : new e.constructor(i), this.sampleValues = e, this.valueSize = i, this.settings = null, this.DefaultSettings_ = {}
                }
                evaluate(t) {
                    let e = this.parameterPositions,
                        i = this._cachedIndex,
                        s = e[i],
                        r = e[i - 1];
                    t: {
                        e: {
                            let n;i: {
                                s: if (!(t < s)) {
                                    for (let n = i + 2;;) {
                                        if (void 0 === s) {
                                            if (t < r) break s;
                                            return i = e.length, this._cachedIndex = i, this.copySampleValue_(i - 1)
                                        }
                                        if (i === n) break;
                                        if (r = s, t < (s = e[++i])) break e
                                    }
                                    n = e.length;
                                    break i
                                }if (!(t >= r)) {
                                    let a = e[1];
                                    t < a && (i = 2, r = a);
                                    for (let n = i - 2;;) {
                                        if (void 0 === r) return this._cachedIndex = 0, this.copySampleValue_(0);
                                        if (i === n) break;
                                        if (s = r, t >= (r = e[--i - 1])) break e
                                    }
                                    n = i, i = 0;
                                    break i
                                }
                                break t
                            }
                            for (; i < n;) {
                                let s = i + n >>> 1;
                                t < e[s] ? n = s : i = s + 1
                            }
                            if (s = e[i], void 0 === (r = e[i - 1])) return this._cachedIndex = 0, this.copySampleValue_(0);
                            if (void 0 === s) return i = e.length, this._cachedIndex = i, this.copySampleValue_(i - 1)
                        }
                        this._cachedIndex = i,
                        this.intervalChanged_(i, r, s)
                    }
                    return this.interpolate_(i, r, t, s)
                }
                getSettings_() {
                    return this.settings || this.DefaultSettings_
                }
                copySampleValue_(t) {
                    let e = this.resultBuffer,
                        i = this.sampleValues,
                        s = this.valueSize,
                        r = t * s;
                    for (let t = 0; t !== s; ++t) e[t] = i[r + t];
                    return e
                }
                interpolate_() {
                    throw Error("THREE.Interpolant: Call to abstract method.")
                }
                intervalChanged_() {}
            }
            class az extends a_ {
                constructor(t, e, i, s) {
                    super(t, e, i, s), this._weightPrev = -0, this._offsetPrev = -0, this._weightNext = -0, this._offsetNext = -0, this.DefaultSettings_ = {
                        endingStart: 2400,
                        endingEnd: 2400
                    }
                }
                intervalChanged_(t, e, i) {
                    let s = this.parameterPositions,
                        r = t - 2,
                        n = t + 1,
                        a = s[r],
                        h = s[n];
                    if (void 0 === a) switch (this.getSettings_().endingStart) {
                        case 2401:
                            r = t, a = 2 * e - i;
                            break;
                        case 2402:
                            r = s.length - 2, a = e + s[r] - s[r + 1];
                            break;
                        default:
                            r = t, a = i
                    }
                    if (void 0 === h) switch (this.getSettings_().endingEnd) {
                        case 2401:
                            n = t, h = 2 * i - e;
                            break;
                        case 2402:
                            n = 1, h = i + s[1] - s[0];
                            break;
                        default:
                            n = t - 1, h = e
                    }
                    let o = (i - e) * .5,
                        l = this.valueSize;
                    this._weightPrev = o / (e - a), this._weightNext = o / (h - i), this._offsetPrev = r * l, this._offsetNext = n * l
                }
                interpolate_(t, e, i, s) {
                    let r = this.resultBuffer,
                        n = this.sampleValues,
                        a = this.valueSize,
                        h = t * a,
                        o = h - a,
                        l = this._offsetPrev,
                        u = this._offsetNext,
                        c = this._weightPrev,
                        p = this._weightNext,
                        d = (i - e) / (s - e),
                        m = d * d,
                        y = m * d,
                        f = -c * y + 2 * c * m - c * d,
                        g = (1 + c) * y + (-1.5 - 2 * c) * m + (-.5 + c) * d + 1,
                        x = (-1 - p) * y + (1.5 + p) * m + .5 * d,
                        v = p * y - p * m;
                    for (let t = 0; t !== a; ++t) r[t] = f * n[l + t] + g * n[o + t] + x * n[h + t] + v * n[u + t];
                    return r
                }
            }
            class aA extends a_ {
                constructor(t, e, i, s) {
                    super(t, e, i, s)
                }
                interpolate_(t, e, i, s) {
                    let r = this.resultBuffer,
                        n = this.sampleValues,
                        a = this.valueSize,
                        h = t * a,
                        o = h - a,
                        l = (i - e) / (s - e),
                        u = 1 - l;
                    for (let t = 0; t !== a; ++t) r[t] = n[o + t] * u + n[h + t] * l;
                    return r
                }
            }
            class aT extends a_ {
                constructor(t, e, i, s) {
                    super(t, e, i, s)
                }
                interpolate_(t) {
                    return this.copySampleValue_(t - 1)
                }
            }
            class aC extends a_ {
                interpolate_(t, e, i, s) {
                    let r = this.resultBuffer,
                        n = this.sampleValues,
                        a = this.valueSize,
                        h = t * a,
                        o = h - a,
                        l = this.inTangents,
                        u = this.outTangents;
                    if (!l || !u) {
                        let t = (i - e) / (s - e),
                            l = 1 - t;
                        for (let e = 0; e !== a; ++e) r[e] = n[o + e] * l + n[h + e] * t;
                        return r
                    }
                    let c = 2 * a,
                        p = t - 1;
                    for (let d = 0; d !== a; ++d) {
                        let a = n[o + d],
                            m = n[h + d],
                            y = p * c + 2 * d,
                            f = u[y],
                            g = u[y + 1],
                            x = t * c + 2 * d,
                            v = l[x],
                            M = l[x + 1],
                            b = function(t, e, i, s, r) {
                                let n = (t - e) / (r - e);
                                for (let a = 0; a < 8; a++) {
                                    let a = ak(n, e, i, s, r) - t;
                                    if (1e-10 > Math.abs(a)) break;
                                    let h = function(t, e, i, s, r) {
                                        let n = 1 - t;
                                        return 3 * n * n * (i - e) + 6 * n * t * (s - i) + 3 * t * t * (r - s)
                                    }(n, e, i, s, r);
                                    if (1e-10 > Math.abs(h)) break;
                                    n = Math.max(0, Math.min(1, n - a / h))
                                }
                                return n
                            }(i, e, f, v, s);
                        r[d] = ak(b, a, g, M, m)
                    }
                    return r
                }
            }

            function ak(t, e, i, s, r) {
                let n = 1 - t;
                return n * n * n * e + 3 * n * n * t * i + 3 * n * t * t * s + t * t * t * r
            }
            class aB {
                constructor(t, e, i, s) {
                    if (void 0 === t) throw Error("THREE.KeyframeTrack: track name is undefined");
                    if (void 0 === e || 0 === e.length) throw Error("THREE.KeyframeTrack: no keyframes in track named " + t);
                    this.name = t, this.times = aw(e, this.TimeBufferType), this.values = aw(i, this.ValueBufferType), this.setInterpolation(s || this.DefaultInterpolation)
                }
                static toJSON(t) {
                    let e, i = t.constructor;
                    if (i.toJSON !== this.toJSON) e = i.toJSON(t);
                    else {
                        e = {
                            name: t.name,
                            times: aw(t.times, Array),
                            values: aw(t.values, Array)
                        };
                        let i = t.getInterpolation();
                        i !== t.DefaultInterpolation && (e.interpolation = i), aS(t.settings) && (e.settings = {
                            inTangents: aw(t.settings.inTangents, Array),
                            outTangents: aw(t.settings.outTangents, Array)
                        })
                    }
                    return e.type = t.ValueTypeName, e
                }
                InterpolantFactoryMethodDiscrete(t) {
                    return new aT(this.times, this.values, this.getValueSize(), t)
                }
                InterpolantFactoryMethodLinear(t) {
                    return new aA(this.times, this.values, this.getValueSize(), t)
                }
                InterpolantFactoryMethodSmooth(t) {
                    return new az(this.times, this.values, this.getValueSize(), t)
                }
                InterpolantFactoryMethodBezier(t) {
                    let e = new aC(this.times, this.values, this.getValueSize(), t);
                    return this.settings && (e.inTangents = this.settings.inTangents, e.outTangents = this.settings.outTangents), e
                }
                setInterpolation(t) {
                    let e;
                    switch (t) {
                        case 2300:
                            e = this.InterpolantFactoryMethodDiscrete;
                            break;
                        case 2301:
                            e = this.InterpolantFactoryMethodLinear;
                            break;
                        case 2302:
                            e = this.InterpolantFactoryMethodSmooth;
                            break;
                        case 2303:
                            e = this.InterpolantFactoryMethodBezier
                    }
                    if (void 0 === e) {
                        let e = "unsupported interpolation for " + this.ValueTypeName + " keyframe track named " + this.name;
                        if (void 0 === this.createInterpolant)
                            if (t !== this.DefaultInterpolation) this.setInterpolation(this.DefaultInterpolation);
                            else throw Error(e);
                        return eU("KeyframeTrack:", e), this
                    }
                    return this.createInterpolant = e, this
                }
                getInterpolation() {
                    switch (this.createInterpolant) {
                        case this.InterpolantFactoryMethodDiscrete:
                            return 2300;
                        case this.InterpolantFactoryMethodLinear:
                            return 2301;
                        case this.InterpolantFactoryMethodSmooth:
                            return 2302;
                        case this.InterpolantFactoryMethodBezier:
                            return 2303
                    }
                }
                getValueSize() {
                    return this.values.length / this.times.length
                }
                shift(t) {
                    if (0 !== t) {
                        let e = this.times;
                        for (let i = 0, s = e.length; i !== s; ++i) e[i] += t
                    }
                    return this
                }
                scale(t) {
                    if (1 !== t) {
                        let e = this.times;
                        for (let i = 0, s = e.length; i !== s; ++i) e[i] *= t;
                        aS(this.settings) && (aO(this.settings.inTangents, t), aO(this.settings.outTangents, t))
                    }
                    return this
                }
                trim(t, e) {
                    let i = this.times,
                        s = i.length,
                        r = 0,
                        n = s - 1;
                    for (; r !== s && i[r] < t;) ++r;
                    for (; - 1 !== n && i[n] > e;) --n;
                    if (++n, 0 !== r || n !== s) {
                        r >= n && (r = (n = Math.max(n, 1)) - 1);
                        let t = this.getValueSize();
                        this.times = i.slice(r, n), this.values = this.values.slice(r * t, n * t)
                    }
                    return this
                }
                validate() {
                    var t;
                    let e = !0,
                        i = this.getValueSize();
                    i - Math.floor(i) != 0 && (eJ("KeyframeTrack: Invalid value size in track.", this), e = !1);
                    let s = this.times,
                        r = this.values,
                        n = s.length;
                    0 === n && (eJ("KeyframeTrack: Track is empty.", this), e = !1);
                    let a = null;
                    for (let t = 0; t !== n; t++) {
                        let i = s[t];
                        if ("number" == typeof i && isNaN(i)) {
                            eJ("KeyframeTrack: Time is not a valid number.", this, t, i), e = !1;
                            break
                        }
                        if (null !== a && a > i) {
                            eJ("KeyframeTrack: Out of order keys.", this, t, i, a), e = !1;
                            break
                        }
                        a = i
                    }
                    if (void 0 !== r && ArrayBuffer.isView(t = r) && !(t instanceof DataView))
                        for (let t = 0, i = r.length; t !== i; ++t) {
                            let i = r[t];
                            if (isNaN(i)) {
                                eJ("KeyframeTrack: Value is not a valid number.", this, t, i), e = !1;
                                break
                            }
                        }
                    return e
                }
                optimize() {
                    let t = this.times.slice(),
                        e = this.values.slice(),
                        i = this.getValueSize(),
                        s = 2302 === this.getInterpolation(),
                        r = t.length - 1,
                        n = 1;
                    for (let a = 1; a < r; ++a) {
                        let r = !1,
                            h = t[a];
                        if (h !== t[a + 1] && (1 !== a || h !== t[0]))
                            if (s) r = !0;
                            else {
                                let t = a * i,
                                    s = t - i,
                                    n = t + i;
                                for (let a = 0; a !== i; ++a) {
                                    let i = e[t + a];
                                    if (i !== e[s + a] || i !== e[n + a]) {
                                        r = !0;
                                        break
                                    }
                                }
                            }
                        if (r) {
                            if (a !== n) {
                                t[n] = t[a];
                                let s = a * i,
                                    r = n * i;
                                for (let t = 0; t !== i; ++t) e[r + t] = e[s + t]
                            }++n
                        }
                    }
                    if (r > 0) {
                        t[n] = t[r];
                        for (let t = r * i, s = n * i, a = 0; a !== i; ++a) e[s + a] = e[t + a];
                        ++n
                    }
                    return n !== t.length ? (this.times = t.slice(0, n), this.values = e.slice(0, n * i)) : (this.times = t, this.values = e), this
                }
                clone() {
                    let t = this.times.slice(),
                        e = this.values.slice(),
                        i = new this.constructor(this.name, t, e);
                    return i.createInterpolant = this.createInterpolant, aS(this.settings) && (i.settings = {
                        inTangents: this.settings.inTangents.slice(),
                        outTangents: this.settings.outTangents.slice()
                    }), i
                }
            }

            function aO(t, e) {
                for (let i = 0, s = t.length; i !== s; i += 2) t[i] *= e
            }
            aB.prototype.ValueTypeName = "", aB.prototype.TimeBufferType = Float32Array, aB.prototype.ValueBufferType = Float32Array, aB.prototype.DefaultInterpolation = 2301;
            class aI extends aB {
                constructor(t, e, i) {
                    super(t, e, i)
                }
            }
            aI.prototype.ValueTypeName = "bool", aI.prototype.ValueBufferType = Array, aI.prototype.DefaultInterpolation = 2300, aI.prototype.InterpolantFactoryMethodLinear = void 0, aI.prototype.InterpolantFactoryMethodSmooth = void 0;
            class aN extends aB {
                constructor(t, e, i, s) {
                    super(t, e, i, s)
                }
            }
            aN.prototype.ValueTypeName = "color";
            class aP extends aB {
                constructor(t, e, i, s) {
                    super(t, e, i, s)
                }
            }
            aP.prototype.ValueTypeName = "number";
            class aR extends a_ {
                constructor(t, e, i, s) {
                    super(t, e, i, s)
                }
                interpolate_(t, e, i, s) {
                    let r = this.resultBuffer,
                        n = this.sampleValues,
                        a = this.valueSize,
                        h = (i - e) / (s - e),
                        o = t * a;
                    for (let t = o + a; o !== t; o += 4) e8.slerpFlat(r, 0, n, o - a, n, o, h);
                    return r
                }
            }
            class aV extends aB {
                constructor(t, e, i, s) {
                    super(t, e, i, s)
                }
                InterpolantFactoryMethodLinear(t) {
                    return new aR(this.times, this.values, this.getValueSize(), t)
                }
            }
            aV.prototype.ValueTypeName = "quaternion", aV.prototype.InterpolantFactoryMethodSmooth = void 0;
            class aE extends aB {
                constructor(t, e, i) {
                    super(t, e, i)
                }
            }
            aE.prototype.ValueTypeName = "string", aE.prototype.ValueBufferType = Array, aE.prototype.DefaultInterpolation = 2300, aE.prototype.InterpolantFactoryMethodLinear = void 0, aE.prototype.InterpolantFactoryMethodSmooth = void 0;
            class aF extends aB {
                constructor(t, e, i, s) {
                    super(t, e, i, s)
                }
            }
            aF.prototype.ValueTypeName = "vector";
            class aL {
                constructor(t, e, i) {
                    let s;
                    const r = this;
                    let n = !1,
                        a = 0,
                        h = 0;
                    const o = [];
                    this.onStart = void 0, this.onLoad = t, this.onProgress = e, this.onError = i, this._abortController = null, this.itemStart = function(t) {
                        h++, !1 === n && void 0 !== r.onStart && r.onStart(t, a, h), n = !0
                    }, this.itemEnd = function(t) {
                        a++, void 0 !== r.onProgress && r.onProgress(t, a, h), a === h && (n = !1, void 0 !== r.onLoad && r.onLoad())
                    }, this.itemError = function(t) {
                        void 0 !== r.onError && r.onError(t)
                    }, this.resolveURL = function(t) {
                        return (t = t.normalize("NFC"), s) ? s(t) : t
                    }, this.setURLModifier = function(t) {
                        return s = t, this
                    }, this.addHandler = function(t, e) {
                        return o.push(t, e), this
                    }, this.removeHandler = function(t) {
                        let e = o.indexOf(t);
                        return -1 !== e && o.splice(e, 2), this
                    }, this.getHandler = function(t) {
                        for (let e = 0, i = o.length; e < i; e += 2) {
                            let i = o[e],
                                s = o[e + 1];
                            if (i.global && (i.lastIndex = 0), i.test(t)) return s
                        }
                        return null
                    }, this.abort = function() {
                        return this.abortController.abort(), this._abortController = null, this
                    }
                }
                get abortController() {
                    return this._abortController || (this._abortController = new AbortController), this._abortController
                }
            }
            let aj = new aL;
            class aD {
                constructor(t) {
                    this.manager = void 0 !== t ? t : aj, this.crossOrigin = "anonymous", this.withCredentials = !1, this.path = "", this.resourcePath = "", this.requestHeader = {}, "u" > typeof __THREE_DEVTOOLS__ && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", {
                        detail: this
                    }))
                }
                load() {}
                loadAsync(t, e) {
                    let i = this;
                    return new Promise(function(s, r) {
                        i.load(t, s, e, r)
                    })
                }
                parse() {}
                setCrossOrigin(t) {
                    return this.crossOrigin = t, this
                }
                setWithCredentials(t) {
                    return this.withCredentials = t, this
                }
                setPath(t) {
                    return this.path = t, this
                }
                setResourcePath(t) {
                    return this.resourcePath = t, this
                }
                setRequestHeader(t) {
                    return this.requestHeader = t, this
                }
                abort() {
                    return this
                }
            }
            aD.DEFAULT_MATERIAL_NAME = "__DEFAULT", new WeakMap;
            class aW extends iY {
                constructor(t, e = 1) {
                    super(), this.isLight = !0, this.type = "Light", this.color = new i3(t), this.intensity = e
                }
                copy(t, e) {
                    return super.copy(t, e), this.color.copy(t.color), this.intensity = t.intensity, this
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    return e.object.color = this.color.getHex(), e.object.intensity = this.intensity, e
                }
            }
            class aU extends aW {
                constructor(t, e, i) {
                    super(t, i), this.isHemisphereLight = !0, this.type = "HemisphereLight", this.position.copy(iY.DEFAULT_UP), this.updateMatrix(), this.groundColor = new i3(e)
                }
                copy(t, e) {
                    return super.copy(t, e), this.groundColor.copy(t.groundColor), this
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    return e.object.groundColor = this.groundColor.getHex(), e
                }
            }
            let aJ = new iw,
                aq = new e9,
                aH = new e9;
            class aX {
                constructor(t) {
                    this.camera = t, this.intensity = 1, this.bias = 0, this.biasNode = null, this.normalBias = 0, this.radius = 1, this.blurSamples = 8, this.mapSize = new e6(512, 512), this.mapType = tz, this.map = null, this.mapPass = null, this.matrix = new iw, this.autoUpdate = !0, this.needsUpdate = !1, this._frustum = new rQ, this._frameExtents = new e6(1, 1), this._viewportCount = 1, this._viewports = [new ig(0, 0, 1, 1)]
                }
                getViewportCount() {
                    return this._viewportCount
                }
                getCamera() {
                    return this.camera
                }
                getFrustum() {
                    return this._frustum
                }
                updateMatrices(t) {
                    let e = this.camera;
                    aq.setFromMatrixPosition(t.matrixWorld), e.position.copy(aq), aH.setFromMatrixPosition(t.target.matrixWorld), e.lookAt(aH), e.updateMatrixWorld(), this._updateMatrix(e, this.matrix, this._frustum)
                }
                _updateMatrix(t, e, i, s) {
                    aJ.multiplyMatrices(t.projectionMatrix, t.matrixWorldInverse), i.setFromProjectionMatrix(aJ, t.coordinateSystem, t.reversedDepth);
                    let r = this._frameExtents,
                        n = s ? s.z / r.x : 1,
                        a = s ? s.w / r.y : 1,
                        h = s ? s.x / r.x : 0,
                        o = s ? s.y / r.y : 0;
                    2001 === t.coordinateSystem || t.reversedDepth ? e.set(.5 * n, 0, 0, .5 * n + h, 0, .5 * a, 0, .5 * a + o, 0, 0, 1, 0, 0, 0, 0, 1) : e.set(.5 * n, 0, 0, .5 * n + h, 0, .5 * a, 0, .5 * a + o, 0, 0, .5, .5, 0, 0, 0, 1), e.multiply(aJ)
                }
                getViewport(t) {
                    return this._viewports[t]
                }
                getFrameExtents() {
                    return this._frameExtents
                }
                dispose() {
                    this.map && this.map.dispose(), this.mapPass && this.mapPass.dispose()
                }
                copy(t) {
                    return this.camera = t.camera.clone(), this.intensity = t.intensity, this.bias = t.bias, this.radius = t.radius, this.autoUpdate = t.autoUpdate, this.needsUpdate = t.needsUpdate, this.normalBias = t.normalBias, this.blurSamples = t.blurSamples, this.mapSize.copy(t.mapSize), this.biasNode = t.biasNode, this
                }
                clone() {
                    return new this.constructor().copy(this)
                }
                toJSON() {
                    let t = {};
                    return t.intensity = this.intensity, t.bias = this.bias, t.normalBias = this.normalBias, t.radius = this.radius, t.blurSamples = this.blurSamples, t.mapSize = this.mapSize.toArray(), t.camera = this.camera.toJSON(!1).object, delete t.camera.matrix, t
                }
            }
            let aZ = new e9,
                aY = new e8,
                aG = new e9;
            class aQ extends iY {
                constructor() {
                    super(), this.isCamera = !0, this.type = "Camera", this.matrixWorldInverse = new iw, this.projectionMatrix = new iw, this.projectionMatrixInverse = new iw, this.coordinateSystem = eE, this._reversedDepth = !1
                }
                get reversedDepth() {
                    return this._reversedDepth
                }
                copy(t, e) {
                    return super.copy(t, e), this.matrixWorldInverse.copy(t.matrixWorldInverse), this.projectionMatrix.copy(t.projectionMatrix), this.projectionMatrixInverse.copy(t.projectionMatrixInverse), this.coordinateSystem = t.coordinateSystem, this
                }
                getWorldDirection(t) {
                    return super.getWorldDirection(t).negate()
                }
                updateMatrixWorld(t) {
                    super.updateMatrixWorld(t), this.matrixWorld.decompose(aZ, aY, aG), 1 === aG.x && 1 === aG.y && 1 === aG.z ? this.matrixWorldInverse.copy(this.matrixWorld).invert() : this.matrixWorldInverse.compose(aZ, aY, aG.set(1, 1, 1)).invert()
                }
                updateWorldMatrix(t, e, i = !1) {
                    super.updateWorldMatrix(t, e, i), this.matrixWorld.decompose(aZ, aY, aG), 1 === aG.x && 1 === aG.y && 1 === aG.z ? this.matrixWorldInverse.copy(this.matrixWorld).invert() : this.matrixWorldInverse.compose(aZ, aY, aG.set(1, 1, 1)).invert()
                }
                clone() {
                    return new this.constructor().copy(this)
                }
            }
            let a$ = new e9,
                aK = new e6,
                a0 = new e6;
            class a1 extends aQ {
                constructor(t = 50, e = 1, i = .1, s = 2e3) {
                    super(), this.isPerspectiveCamera = !0, this.type = "PerspectiveCamera", this.fov = t, this.zoom = 1, this.near = i, this.far = s, this.focus = 10, this.aspect = e, this.view = null, this.filmGauge = 35, this.filmOffset = 0, this.updateProjectionMatrix()
                }
                copy(t, e) {
                    return super.copy(t, e), this.fov = t.fov, this.zoom = t.zoom, this.near = t.near, this.far = t.far, this.focus = t.focus, this.aspect = t.aspect, this.view = null === t.view ? null : Object.assign({}, t.view), this.filmGauge = t.filmGauge, this.filmOffset = t.filmOffset, this
                }
                setFocalLength(t) {
                    let e = .5 * this.getFilmHeight() / t;
                    this.fov = 2 * e$ * Math.atan(e), this.updateProjectionMatrix()
                }
                getFocalLength() {
                    let t = Math.tan(.5 * eQ * this.fov);
                    return .5 * this.getFilmHeight() / t
                }
                getEffectiveFOV() {
                    return 2 * e$ * Math.atan(Math.tan(.5 * eQ * this.fov) / this.zoom)
                }
                getFilmWidth() {
                    return this.filmGauge * Math.min(this.aspect, 1)
                }
                getFilmHeight() {
                    return this.filmGauge / Math.max(this.aspect, 1)
                }
                getViewBounds(t, e, i) {
                    a$.set(-1, -1, .5).applyMatrix4(this.projectionMatrixInverse), e.set(a$.x, a$.y).multiplyScalar(-t / a$.z), a$.set(1, 1, .5).applyMatrix4(this.projectionMatrixInverse), i.set(a$.x, a$.y).multiplyScalar(-t / a$.z)
                }
                getViewSize(t, e) {
                    return this.getViewBounds(t, aK, a0), e.subVectors(a0, aK)
                }
                setViewOffset(t, e, i, s, r, n) {
                    this.aspect = t / e, null === this.view && (this.view = {
                        enabled: !0,
                        fullWidth: 1,
                        fullHeight: 1,
                        offsetX: 0,
                        offsetY: 0,
                        width: 1,
                        height: 1
                    }), this.view.enabled = !0, this.view.fullWidth = t, this.view.fullHeight = e, this.view.offsetX = i, this.view.offsetY = s, this.view.width = r, this.view.height = n, this.updateProjectionMatrix()
                }
                clearViewOffset() {
                    null !== this.view && (this.view.enabled = !1), this.updateProjectionMatrix()
                }
                updateProjectionMatrix() {
                    let t = this.near,
                        e = t * Math.tan(.5 * eQ * this.fov) / this.zoom,
                        i = 2 * e,
                        s = this.aspect * i,
                        r = -.5 * s,
                        n = this.view;
                    if (null !== this.view && this.view.enabled) {
                        let t = n.fullWidth,
                            a = n.fullHeight;
                        r += n.offsetX * s / t, e -= n.offsetY * i / a, s *= n.width / t, i *= n.height / a
                    }
                    let a = this.filmOffset;
                    0 !== a && (r += t * a / this.getFilmWidth()), this.projectionMatrix.makePerspective(r, r + s, e, e - i, t, this.far, this.coordinateSystem, this.reversedDepth), this.projectionMatrixInverse.copy(this.projectionMatrix).invert()
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    return e.object.fov = this.fov, e.object.zoom = this.zoom, e.object.near = this.near, e.object.far = this.far, e.object.focus = this.focus, e.object.aspect = this.aspect, null !== this.view && (e.object.view = Object.assign({}, this.view)), e.object.filmGauge = this.filmGauge, e.object.filmOffset = this.filmOffset, e
                }
            }
            class a2 extends aX {
                constructor() {
                    super(new a1(90, 1, .5, 500)), this.isPointLightShadow = !0
                }
            }
            class a3 extends aW {
                constructor(t, e, i = 0, s = 2) {
                    super(t, e), this.isPointLight = !0, this.type = "PointLight", this.distance = i, this.decay = s, this.shadow = new a2
                }
                get power() {
                    return 4 * this.intensity * Math.PI
                }
                set power(t) {
                    this.intensity = t / (4 * Math.PI)
                }
                dispose() {
                    super.dispose(), this.shadow.dispose()
                }
                copy(t, e) {
                    return super.copy(t, e), this.distance = t.distance, this.decay = t.decay, this.shadow = t.shadow.clone(), this
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    return e.object.distance = this.distance, e.object.decay = this.decay, e.object.shadow = this.shadow.toJSON(), e
                }
            }
            class a5 extends aQ {
                constructor(t = -1, e = 1, i = 1, s = -1, r = .1, n = 2e3) {
                    super(), this.isOrthographicCamera = !0, this.type = "OrthographicCamera", this.zoom = 1, this.view = null, this.left = t, this.right = e, this.top = i, this.bottom = s, this.near = r, this.far = n, this.updateProjectionMatrix()
                }
                copy(t, e) {
                    return super.copy(t, e), this.left = t.left, this.right = t.right, this.top = t.top, this.bottom = t.bottom, this.near = t.near, this.far = t.far, this.zoom = t.zoom, this.view = null === t.view ? null : Object.assign({}, t.view), this
                }
                setViewOffset(t, e, i, s, r, n) {
                    null === this.view && (this.view = {
                        enabled: !0,
                        fullWidth: 1,
                        fullHeight: 1,
                        offsetX: 0,
                        offsetY: 0,
                        width: 1,
                        height: 1
                    }), this.view.enabled = !0, this.view.fullWidth = t, this.view.fullHeight = e, this.view.offsetX = i, this.view.offsetY = s, this.view.width = r, this.view.height = n, this.updateProjectionMatrix()
                }
                clearViewOffset() {
                    null !== this.view && (this.view.enabled = !1), this.updateProjectionMatrix()
                }
                updateProjectionMatrix() {
                    let t = (this.right - this.left) / (2 * this.zoom),
                        e = (this.top - this.bottom) / (2 * this.zoom),
                        i = (this.right + this.left) / 2,
                        s = (this.top + this.bottom) / 2,
                        r = i - t,
                        n = i + t,
                        a = s + e,
                        h = s - e;
                    if (null !== this.view && this.view.enabled) {
                        let t = (this.right - this.left) / this.view.fullWidth / this.zoom,
                            e = (this.top - this.bottom) / this.view.fullHeight / this.zoom;
                        r += t * this.view.offsetX, n = r + t * this.view.width, a -= e * this.view.offsetY, h = a - e * this.view.height
                    }
                    this.projectionMatrix.makeOrthographic(r, n, a, h, this.near, this.far, this.coordinateSystem, this.reversedDepth), this.projectionMatrixInverse.copy(this.projectionMatrix).invert()
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    return e.object.zoom = this.zoom, e.object.left = this.left, e.object.right = this.right, e.object.top = this.top, e.object.bottom = this.bottom, e.object.near = this.near, e.object.far = this.far, null !== this.view && (e.object.view = Object.assign({}, this.view)), e
                }
            }
            class a4 extends aX {
                constructor() {
                    super(new a5(-5, 5, 5, -5, .5, 500)), this.isDirectionalLightShadow = !0
                }
            }
            class a6 extends aW {
                constructor(t, e) {
                    super(t, e), this.isDirectionalLight = !0, this.type = "DirectionalLight", this.position.copy(iY.DEFAULT_UP), this.updateMatrix(), this.target = new iY, this.shadow = new a4
                }
                dispose() {
                    super.dispose(), this.shadow.dispose()
                }
                copy(t) {
                    return super.copy(t), this.target = t.target.clone(), this.shadow = t.shadow.clone(), this
                }
                toJSON(t) {
                    let e = super.toJSON(t);
                    return e.object.shadow = this.shadow.toJSON(), e.object.target = this.target.uuid, e
                }
            }
            class a8 extends aW {
                constructor(t, e) {
                    super(t, e), this.isAmbientLight = !0, this.type = "AmbientLight"
                }
            }
            class a9 extends sJ {
                constructor() {
                    super(), this.isInstancedBufferGeometry = !0, this.type = "InstancedBufferGeometry", this.instanceCount = 1 / 0
                }
                copy(t) {
                    return super.copy(t), this.instanceCount = t.instanceCount, this
                }
                toJSON() {
                    let t = super.toJSON();
                    return t.instanceCount = this.instanceCount, t.isInstancedBufferGeometry = !0, t
                }
            }
            new WeakMap;
            class a7 extends iY {
                constructor(t, e, i) {
                    super(), this.type = "CubeCamera", this.renderTarget = i, this.coordinateSystem = null, this.activeMipmapLevel = 0;
                    const s = new a1(-90, 1, t, e);
                    s.layers = this.layers, this.add(s);
                    const r = new a1(-90, 1, t, e);
                    r.layers = this.layers, this.add(r);
                    const n = new a1(-90, 1, t, e);
                    n.layers = this.layers, this.add(n);
                    const a = new a1(-90, 1, t, e);
                    a.layers = this.layers, this.add(a);
                    const h = new a1(-90, 1, t, e);
                    h.layers = this.layers, this.add(h);
                    const o = new a1(-90, 1, t, e);
                    o.layers = this.layers, this.add(o)
                }
                updateCoordinateSystem() {
                    let t = this.coordinateSystem,
                        e = this.children.concat(),
                        [i, s, r, n, a, h] = e;
                    for (let t of e) this.remove(t);
                    if (t === eE) i.up.set(0, 1, 0), i.lookAt(1, 0, 0), s.up.set(0, 1, 0), s.lookAt(-1, 0, 0), r.up.set(0, 0, -1), r.lookAt(0, 1, 0), n.up.set(0, 0, 1), n.lookAt(0, -1, 0), a.up.set(0, 1, 0), a.lookAt(0, 0, 1), h.up.set(0, 1, 0), h.lookAt(0, 0, -1);
                    else if (2001 === t) i.up.set(0, -1, 0), i.lookAt(-1, 0, 0), s.up.set(0, -1, 0), s.lookAt(1, 0, 0), r.up.set(0, 0, 1), r.lookAt(0, 1, 0), n.up.set(0, 0, -1), n.lookAt(0, -1, 0), a.up.set(0, -1, 0), a.lookAt(0, 0, 1), h.up.set(0, -1, 0), h.lookAt(0, 0, -1);
                    else throw Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: " + t);
                    for (let t of e) this.add(t), t.updateMatrixWorld()
                }
                update(t, e) {
                    null === this.parent && this.updateMatrixWorld();
                    let {
                        renderTarget: i,
                        activeMipmapLevel: s
                    } = this;
                    this.coordinateSystem !== t.coordinateSystem && (this.coordinateSystem = t.coordinateSystem, this.updateCoordinateSystem());
                    let [r, n, a, h, o, l] = this.children, u = t.getRenderTarget(), c = t.getActiveCubeFace(), p = t.getActiveMipmapLevel(), d = t.xr.enabled;
                    t.xr.enabled = !1;
                    let m = i.texture.generateMipmaps;
                    i.texture.generateMipmaps = !1;
                    let y = !1;
                    y = !0 === t.isWebGLRenderer ? t.state.buffers.depth.getReversed() : t.reversedDepthBuffer, t.setRenderTarget(i, 0, s), y && !1 === t.autoClear && t.clearDepth(), t.render(e, r), t.setRenderTarget(i, 1, s), y && !1 === t.autoClear && t.clearDepth(), t.render(e, n), t.setRenderTarget(i, 2, s), y && !1 === t.autoClear && t.clearDepth(), t.render(e, a), t.setRenderTarget(i, 3, s), y && !1 === t.autoClear && t.clearDepth(), t.render(e, h), t.setRenderTarget(i, 4, s), y && !1 === t.autoClear && t.clearDepth(), t.render(e, o), i.texture.generateMipmaps = m, t.setRenderTarget(i, 5, s), y && !1 === t.autoClear && t.clearDepth(), t.render(e, l), t.setRenderTarget(u, c, p), t.xr.enabled = d, i.texture.needsPMREMUpdate = !0
                }
            }
            class ht extends a1 {
                constructor(t = []) {
                    super(), this.isArrayCamera = !0, this.isMultiViewCamera = !1, this.cameras = t
                }
            }
            class he {
                constructor() {
                    this._previousTime = 0, this._currentTime = 0, this._startTime = performance.now(), this._delta = 0, this._elapsed = 0, this._timescale = 1, this._document = null, this._pageVisibilityHandler = null
                }
                connect(t) {
                    this._document = t, void 0 !== t.hidden && (this._pageVisibilityHandler = hi.bind(this), t.addEventListener("visibilitychange", this._pageVisibilityHandler, !1))
                }
                disconnect() {
                    null !== this._pageVisibilityHandler && (this._document.removeEventListener("visibilitychange", this._pageVisibilityHandler), this._pageVisibilityHandler = null), this._document = null
                }
                getDelta() {
                    return this._delta / 1e3
                }
                getElapsed() {
                    return this._elapsed / 1e3
                }
                getTimescale() {
                    return this._timescale
                }
                setTimescale(t) {
                    return this._timescale = t, this
                }
                reset() {
                    return this._currentTime = performance.now() - this._startTime, this
                }
                dispose() {
                    this.disconnect()
                }
                update(t) {
                    return null !== this._pageVisibilityHandler && !0 === this._document.hidden ? this._delta = 0 : (this._previousTime = this._currentTime, this._currentTime = (void 0 !== t ? t : performance.now()) - this._startTime, this._delta = (this._currentTime - this._previousTime) * this._timescale, this._elapsed += this._delta), this
                }
            }

            function hi() {
                !1 === this._document.hidden && this.reset()
            }
            let hs = "\\[\\]\\.:\\/",
                hr = RegExp("[" + hs + "]", "g"),
                hn = "[^" + hs + "]",
                ha = "[^" + hs.replace("\\.", "") + "]",
                hh = RegExp("^" + /((?:WC+[\/:])*)/.source.replace("WC", hn) + /(WCOD+)?/.source.replace("WCOD", ha) + /(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC", hn) + /\.(WC+)(?:\[(.+)\])?/.source.replace("WC", hn) + "$"),
                ho = ["material", "materials", "bones", "map"];
            class hl {
                constructor(t, e, i) {
                    const s = i || hu.parseTrackName(e);
                    this._targetGroup = t, this._bindings = t.subscribe_(e, s)
                }
                getValue(t, e) {
                    this.bind();
                    let i = this._targetGroup.nCachedObjects_,
                        s = this._bindings[i];
                    void 0 !== s && s.getValue(t, e)
                }
                setValue(t, e) {
                    let i = this._bindings;
                    for (let s = this._targetGroup.nCachedObjects_, r = i.length; s !== r; ++s) i[s].setValue(t, e)
                }
                bind() {
                    let t = this._bindings;
                    for (let e = this._targetGroup.nCachedObjects_, i = t.length; e !== i; ++e) t[e].bind()
                }
                unbind() {
                    let t = this._bindings;
                    for (let e = this._targetGroup.nCachedObjects_, i = t.length; e !== i; ++e) t[e].unbind()
                }
            }
            class hu {
                constructor(t, e, i) {
                    this.path = e, this.parsedPath = i || hu.parseTrackName(e), this.node = hu.findNode(t, this.parsedPath.nodeName), this.rootNode = t, this.getValue = this._getValue_unbound, this.setValue = this._setValue_unbound
                }
                static create(t, e, i) {
                    return t && t.isAnimationObjectGroup ? new hu.Composite(t, e, i) : new hu(t, e, i)
                }
                static sanitizeNodeName(t) {
                    return t.replace(/\s/g, "_").replace(hr, "")
                }
                static parseTrackName(t) {
                    let e = hh.exec(t);
                    if (null === e) throw Error("THREE.PropertyBinding: Cannot parse trackName: " + t);
                    let i = {
                            nodeName: e[2],
                            objectName: e[3],
                            objectIndex: e[4],
                            propertyName: e[5],
                            propertyIndex: e[6]
                        },
                        s = i.nodeName && i.nodeName.lastIndexOf(".");
                    if (void 0 !== s && -1 !== s) {
                        let t = i.nodeName.substring(s + 1); - 1 !== ho.indexOf(t) && (i.nodeName = i.nodeName.substring(0, s), i.objectName = t)
                    }
                    if (null === i.propertyName || 0 === i.propertyName.length) throw Error("THREE.PropertyBinding: can not parse propertyName from trackName: " + t);
                    return i
                }
                static findNode(t, e) {
                    if (void 0 === e || "" === e || "." === e || -1 === e || e === t.name || e === t.uuid) return t;
                    if (t.skeleton) {
                        let i = t.skeleton.getBoneByName(e);
                        if (void 0 !== i) return i
                    }
                    if (t.children) {
                        let i = function(t) {
                                for (let s = 0; s < t.length; s++) {
                                    let r = t[s];
                                    if (r.name === e || r.uuid === e) return r;
                                    let n = i(r.children);
                                    if (n) return n
                                }
                                return null
                            },
                            s = i(t.children);
                        if (s) return s
                    }
                    return null
                }
                _getValue_unavailable() {}
                _setValue_unavailable() {}
                _getValue_direct(t, e) {
                    t[e] = this.targetObject[this.propertyName]
                }
                _getValue_array(t, e) {
                    let i = this.resolvedProperty;
                    for (let s = 0, r = i.length; s !== r; ++s) t[e++] = i[s]
                }
                _getValue_arrayElement(t, e) {
                    t[e] = this.resolvedProperty[this.propertyIndex]
                }
                _getValue_toArray(t, e) {
                    this.resolvedProperty.toArray(t, e)
                }
                _setValue_direct(t, e) {
                    this.targetObject[this.propertyName] = t[e]
                }
                _setValue_direct_setNeedsUpdate(t, e) {
                    this.targetObject[this.propertyName] = t[e], this.targetObject.needsUpdate = !0
                }
                _setValue_direct_setMatrixWorldNeedsUpdate(t, e) {
                    this.targetObject[this.propertyName] = t[e], this.targetObject.matrixWorldNeedsUpdate = !0
                }
                _setValue_array(t, e) {
                    let i = this.resolvedProperty;
                    for (let s = 0, r = i.length; s !== r; ++s) i[s] = t[e++]
                }
                _setValue_array_setNeedsUpdate(t, e) {
                    let i = this.resolvedProperty;
                    for (let s = 0, r = i.length; s !== r; ++s) i[s] = t[e++];
                    this.targetObject.needsUpdate = !0
                }
                _setValue_array_setMatrixWorldNeedsUpdate(t, e) {
                    let i = this.resolvedProperty;
                    for (let s = 0, r = i.length; s !== r; ++s) i[s] = t[e++];
                    this.targetObject.matrixWorldNeedsUpdate = !0
                }
                _setValue_arrayElement(t, e) {
                    this.resolvedProperty[this.propertyIndex] = t[e]
                }
                _setValue_arrayElement_setNeedsUpdate(t, e) {
                    this.resolvedProperty[this.propertyIndex] = t[e], this.targetObject.needsUpdate = !0
                }
                _setValue_arrayElement_setMatrixWorldNeedsUpdate(t, e) {
                    this.resolvedProperty[this.propertyIndex] = t[e], this.targetObject.matrixWorldNeedsUpdate = !0
                }
                _setValue_fromArray(t, e) {
                    this.resolvedProperty.fromArray(t, e)
                }
                _setValue_fromArray_setNeedsUpdate(t, e) {
                    this.resolvedProperty.fromArray(t, e), this.targetObject.needsUpdate = !0
                }
                _setValue_fromArray_setMatrixWorldNeedsUpdate(t, e) {
                    this.resolvedProperty.fromArray(t, e), this.targetObject.matrixWorldNeedsUpdate = !0
                }
                _getValue_unbound(t, e) {
                    this.bind(), this.getValue(t, e)
                }
                _setValue_unbound(t, e) {
                    this.bind(), this.setValue(t, e)
                }
                bind() {
                    let t = this.node,
                        e = this.parsedPath,
                        i = e.objectName,
                        s = e.propertyName,
                        r = e.propertyIndex;
                    if (t || (t = hu.findNode(this.rootNode, e.nodeName), this.node = t), this.getValue = this._getValue_unavailable, this.setValue = this._setValue_unavailable, !t) return void eU("PropertyBinding: No target node found for track: " + this.path + ".");
                    if (i) {
                        let s = e.objectIndex;
                        switch (i) {
                            case "materials":
                                if (!t.material) return void eJ("PropertyBinding: Can not bind to material as node does not have a material.", this);
                                if (!t.material.materials) return void eJ("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.", this);
                                t = t.material.materials;
                                break;
                            case "bones":
                                if (!t.skeleton) return void eJ("PropertyBinding: Can not bind to bones as node does not have a skeleton.", this);
                                t = t.skeleton.bones;
                                for (let e = 0; e < t.length; e++)
                                    if (t[e].name === s) {
                                        s = e;
                                        break
                                    }
                                break;
                            case "map":
                                if ("map" in t) {
                                    t = t.map;
                                    break
                                }
                                if (!t.material) return void eJ("PropertyBinding: Can not bind to material as node does not have a material.", this);
                                if (!t.material.map) return void eJ("PropertyBinding: Can not bind to material.map as node.material does not have a map.", this);
                                t = t.material.map;
                                break;
                            default:
                                if (void 0 === t[i]) return void eJ("PropertyBinding: Can not bind to objectName of node undefined.", this);
                                t = t[i]
                        }
                        if (void 0 !== s) {
                            if (void 0 === t[s]) return void eJ("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.", this, t);
                            t = t[s]
                        }
                    }
                    let n = t[s];
                    if (void 0 === n) return void eJ("PropertyBinding: Trying to update property for track: " + e.nodeName + "." + s + " but it wasn't found.", t);
                    let a = this.Versioning.None;
                    this.targetObject = t, !0 === t.isMaterial ? a = this.Versioning.NeedsUpdate : !0 === t.isObject3D && (a = this.Versioning.MatrixWorldNeedsUpdate);
                    let h = this.BindingType.Direct;
                    if (void 0 !== r) {
                        if ("morphTargetInfluences" === s) {
                            if (!t.geometry) return void eJ("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.", this);
                            if (!t.geometry.morphAttributes) return void eJ("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.", this);
                            void 0 !== t.morphTargetDictionary[r] && (r = t.morphTargetDictionary[r])
                        }
                        h = this.BindingType.ArrayElement, this.resolvedProperty = n, this.propertyIndex = r
                    } else void 0 !== n.fromArray && void 0 !== n.toArray ? (h = this.BindingType.HasFromToArray, this.resolvedProperty = n) : Array.isArray(n) ? (h = this.BindingType.EntireArray, this.resolvedProperty = n) : this.propertyName = s;
                    this.getValue = this.GetterByBindingType[h], this.setValue = this.SetterByBindingTypeAndVersioning[h][a]
                }
                unbind() {
                    this.node = null, this.getValue = this._getValue_unbound, this.setValue = this._setValue_unbound
                }
            }
            hu.Composite = hl, hu.prototype.BindingType = {
                Direct: 0,
                EntireArray: 1,
                ArrayElement: 2,
                HasFromToArray: 3
            }, hu.prototype.Versioning = {
                None: 0,
                NeedsUpdate: 1,
                MatrixWorldNeedsUpdate: 2
            }, hu.prototype.GetterByBindingType = [hu.prototype._getValue_direct, hu.prototype._getValue_array, hu.prototype._getValue_arrayElement, hu.prototype._getValue_toArray], hu.prototype.SetterByBindingTypeAndVersioning = [
                [hu.prototype._setValue_direct, hu.prototype._setValue_direct_setNeedsUpdate, hu.prototype._setValue_direct_setMatrixWorldNeedsUpdate],
                [hu.prototype._setValue_array, hu.prototype._setValue_array_setNeedsUpdate, hu.prototype._setValue_array_setMatrixWorldNeedsUpdate],
                [hu.prototype._setValue_arrayElement, hu.prototype._setValue_arrayElement_setNeedsUpdate, hu.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],
                [hu.prototype._setValue_fromArray, hu.prototype._setValue_fromArray_setNeedsUpdate, hu.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]
            ], new Float32Array(1);
            let hc = new iw;
            class hp {
                constructor(t, e, i = 0, s = 1 / 0) {
                    this.ray = new rl(t, e), this.near = i, this.far = s, this.camera = null, this.layers = new iN, this.params = {
                        Mesh: {},
                        Line: {
                            threshold: 1
                        },
                        LOD: {},
                        Points: {
                            threshold: 1
                        },
                        Sprite: {}
                    }
                }
                set(t, e) {
                    this.ray.set(t, e)
                }
                setFromCamera(t, e) {
                    e.isPerspectiveCamera ? (this.ray.origin.setFromMatrixPosition(e.matrixWorld), this.ray.direction.set(t.x, t.y, .5).unproject(e).sub(this.ray.origin).normalize(), this.camera = e) : e.isOrthographicCamera ? (this.ray.origin.set(t.x, t.y, e.projectionMatrix.elements[14]).unproject(e), this.ray.direction.set(0, 0, -1).transformDirection(e.matrixWorld), this.camera = e) : eJ("Raycaster: Unsupported camera type: " + e.type)
                }
                setFromXRController(t) {
                    return hc.identity().extractRotation(t.matrixWorld), this.ray.origin.setFromMatrixPosition(t.matrixWorld), this.ray.direction.set(0, 0, -1).applyMatrix4(hc), this
                }
                intersectObject(t, e = !0, i = []) {
                    return hm(t, this, i, e), i.sort(hd), i
                }
                intersectObjects(t, e = !0, i = []) {
                    for (let s = 0, r = t.length; s < r; s++) hm(t[s], this, i, e);
                    return i.sort(hd), i
                }
            }

            function hd(t, e) {
                return t.distance - e.distance
            }

            function hm(t, e, i, s) {
                let r = !0;
                if (t.layers.test(e.layers) && !1 === t.raycast(e, i) && (r = !1), !0 === r && !0 === s) {
                    let s = t.children;
                    for (let t = 0, r = s.length; t < r; t++) hm(s[t], e, i, !0)
                }
            }
            class hy {
                static {
                    hy.prototype.isMatrix2 = !0
                }
                constructor(t, e, i, s) {
                    this.elements = [1, 0, 0, 1], void 0 !== t && this.set(t, e, i, s)
                }
                identity() {
                    return this.set(1, 0, 0, 1), this
                }
                fromArray(t, e = 0) {
                    for (let i = 0; i < 4; i++) this.elements[i] = t[i + e];
                    return this
                }
                set(t, e, i, s) {
                    let r = this.elements;
                    return r[0] = t, r[2] = e, r[1] = i, r[3] = s, this
                }
            }

            function hf(t, e, i, s) {
                let r = function(t) {
                    switch (t) {
                        case tz:
                        case tA:
                            return {
                                byteLength: 1,
                                components: 1
                            };
                        case tC:
                        case tT:
                        case tI:
                            return {
                                byteLength: 2,
                                components: 1
                            };
                        case tN:
                        case tP:
                            return {
                                byteLength: 2,
                                components: 4
                            };
                        case tB:
                        case tk:
                        case tO:
                            return {
                                byteLength: 4,
                                components: 1
                            };
                        case tV:
                        case tE:
                            return {
                                byteLength: 4,
                                components: 3
                            }
                    }
                    throw Error(`THREE.TextureUtils: Unknown texture type ${t}.`)
                }(s);
                switch (i) {
                    case tF:
                        return t * e;
                    case tU:
                    case tJ:
                        return t * e / r.components * r.byteLength;
                    case tq:
                    case tH:
                        return t * e * 2 / r.components * r.byteLength;
                    case tL:
                        return t * e * 3 / r.components * r.byteLength;
                    case tj:
                    case tX:
                        return t * e * 4 / r.components * r.byteLength;
                    case tZ:
                    case tY:
                        return Math.floor((t + 3) / 4) * Math.floor((e + 3) / 4) * 8;
                    case tG:
                    case tQ:
                        return Math.floor((t + 3) / 4) * Math.floor((e + 3) / 4) * 16;
                    case tK:
                    case t1:
                        return Math.max(t, 16) * Math.max(e, 8) / 4;
                    case t$:
                    case t0:
                        return Math.max(t, 8) * Math.max(e, 8) / 2;
                    case t2:
                    case t3:
                    case t4:
                    case t6:
                        return Math.floor((t + 3) / 4) * Math.floor((e + 3) / 4) * 8;
                    case t5:
                    case t8:
                    case t9:
                    case t7:
                        return Math.floor((t + 3) / 4) * Math.floor((e + 3) / 4) * 16;
                    case et:
                        return Math.floor((t + 4) / 5) * Math.floor((e + 3) / 4) * 16;
                    case ee:
                        return Math.floor((t + 4) / 5) * Math.floor((e + 4) / 5) * 16;
                    case ei:
                        return Math.floor((t + 5) / 6) * Math.floor((e + 4) / 5) * 16;
                    case es:
                        return Math.floor((t + 5) / 6) * Math.floor((e + 5) / 6) * 16;
                    case er:
                        return Math.floor((t + 7) / 8) * Math.floor((e + 4) / 5) * 16;
                    case en:
                        return Math.floor((t + 7) / 8) * Math.floor((e + 5) / 6) * 16;
                    case ea:
                        return Math.floor((t + 7) / 8) * Math.floor((e + 7) / 8) * 16;
                    case eh:
                        return Math.floor((t + 9) / 10) * Math.floor((e + 4) / 5) * 16;
                    case eo:
                        return Math.floor((t + 9) / 10) * Math.floor((e + 5) / 6) * 16;
                    case el:
                        return Math.floor((t + 9) / 10) * Math.floor((e + 7) / 8) * 16;
                    case eu:
                        return Math.floor((t + 9) / 10) * Math.floor((e + 9) / 10) * 16;
                    case ec:
                        return Math.floor((t + 11) / 12) * Math.floor((e + 9) / 10) * 16;
                    case ep:
                        return Math.floor((t + 11) / 12) * Math.floor((e + 11) / 12) * 16;
                    case ed:
                    case em:
                    case ey:
                        return Math.ceil(t / 4) * Math.ceil(e / 4) * 16;
                    case ef:
                    case eg:
                        return Math.ceil(t / 4) * Math.ceil(e / 4) * 8;
                    case ex:
                    case ev:
                        return Math.ceil(t / 4) * Math.ceil(e / 4) * 16
                }
                throw Error(`Unable to determine texture byte length for ${i} format.`)
            }
            "u" > typeof __THREE_DEVTOOLS__ && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register", {
                detail: {
                    revision: l
                }
            })), "u" > typeof window && (window.__THREE__ ? eU("WARNING: Multiple instances of Three.js being imported.") : window.__THREE__ = l)
        }
    }
]);