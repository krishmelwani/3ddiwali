"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [30494], {
        30494: (e, t, a) => {
            a.d(t, {
                G: () => es,
                _: () => ez
            });
            var l = a(84910),
                n = a(63962);
            let r = {
                    eye0: [0, 0],
                    eye1: [1, 0],
                    eye2: [2, 0],
                    eye3: [3, 0],
                    eyeHappy: [4, 0],
                    eyeBlink: [5, 0],
                    eyeSleepy: [6, 0],
                    eyeHeart: [7, 0],
                    eyeSurprised: [0, 1],
                    eyeShy: [1, 1],
                    catGreen: [2, 1],
                    catBlue: [3, 1],
                    catAmber: [4, 1],
                    petDark: [5, 1],
                    petClosed: [6, 1],
                    mouthSmile: [0, 2],
                    mouthSoft: [1, 2],
                    mouthO: [2, 2],
                    mouthWavy: [3, 2],
                    mouthSmall: [4, 2],
                    mouthCat: [5, 2],
                    mouthLove: [6, 2],
                    mouthDog: [7, 2],
                    browNormal: [0, 3],
                    browRaised: [1, 3],
                    browWorried: [2, 3],
                    browRelaxed: [3, 3],
                    blush: [4, 3],
                    empty: [7, 3],
                    nose: [0, 4],
                    mouthGrin: [1, 4],
                    mouthGentle: [2, 4],
                    eye4: [3, 4]
                },
                i = "#2a1a1e";

            function o(e, t, a, l) {
                e.beginPath(), l(e), e.lineWidth = t, e.lineCap = "round", e.lineJoin = "round", e.strokeStyle = a, e.stroke()
            }

            function s(e, t, a, l, n = 1) {
                e.beginPath(), e.ellipse(t, a, l, 1.1 * l, 0, 0, 2 * Math.PI), e.fillStyle = `rgba(255,255,255,${n})`, e.fill()
            }

            function u(e, t) {
                let a = 4 === t ? 26 : 2 === t ? 32 : 3 === t ? 28 : 30,
                    l = 4 === t ? 30 : 2 === t ? 42 : 3 === t ? 35 : 40,
                    n = 4 === t ? 76 : 3 === t ? 72 : 70;
                e.save(), e.beginPath(), e.ellipse(64, n + 1, a + 5, l + 3, 0, 0, 2 * Math.PI), e.fillStyle = "#fffaf6", e.fill();
                let r = e.createRadialGradient(64, n + .35 * l, 2, 64, n, l);
                r.addColorStop(0, 2 === t ? "#e0a860" : 3 === t ? "#b07a4c" : "#c48a52"), r.addColorStop(.55, 2 === t ? "#8a5428" : 3 === t ? "#6a3f24" : "#7a4a2a"), r.addColorStop(1, 2 === t ? "#3a2116" : "#2a170f"), e.beginPath(), e.ellipse(64, n, a, l, 0, 0, 2 * Math.PI), e.fillStyle = r, e.fill(), e.lineWidth = 3, e.strokeStyle = "rgba(30,14,10,0.85)", e.stroke(), e.strokeStyle = "rgba(255,226,180,0.18)", e.lineWidth = 1.5;
                for (let t = 0; t < 14; t++) {
                    let r = t / 14 * Math.PI * 2;
                    e.beginPath(), e.moveTo(64 + Math.cos(r) * a * .42, n + Math.sin(r) * l * .42), e.lineTo(64 + Math.cos(r) * a * .86, n + Math.sin(r) * l * .86), e.stroke()
                }
                e.beginPath(), e.ellipse(64, n - 2, .42 * a, .46 * l, 0, 0, 2 * Math.PI), e.fillStyle = "#120806", e.fill();
                let u = e.createLinearGradient(0, n - l, 0, n - .2 * l);
                u.addColorStop(0, "rgba(20,8,6,0.55)"), u.addColorStop(1, "rgba(20,8,6,0)"), e.beginPath(), e.ellipse(64, n, a, l, 0, 0, 2 * Math.PI), e.fillStyle = u, e.fill(), s(e, 64 - .36 * a, n - .4 * l, 2 === t ? 12 : 10.5), s(e, 64 + .38 * a, n + .36 * l, 4.5, .9), s(e, 64 + .05 * a, n - .62 * l, 2.2, .8);
                let d = n - l + (4 === t ? 11 : 3 === t ? 9 : 4);
                e.beginPath(), e.moveTo(64 - a - 6, d + 15), e.quadraticCurveTo(60, d - 12, 64 + a + 9, d + 7), e.quadraticCurveTo(66, d - 2, 64 - a - 6, d + 15), e.fillStyle = i, e.fill(), o(e, 5, i, e => {
                    e.moveTo(64 - a - 4, d + 13), e.quadraticCurveTo(62, d - 9, 64 + a + 8, d + 7)
                }), o(e, 2.5, "rgba(42,26,30,0.35)", e => {
                    e.moveTo(64 - .6 * a, d - 4), e.quadraticCurveTo(68, d - 16, 64 + a + 2, d - 3)
                }), (1 === t || 2 === t) && o(e, 4.5, i, e => {
                    e.moveTo(64 + a + 4, d + 8), e.quadraticCurveTo(64 + a + 13, d + 4, 64 + a + 18, d - 3), e.moveTo(64 + a - 3, d + 1), e.quadraticCurveTo(64 + a + 5, d - 5, 64 + a + 9, d - 13), e.moveTo(64 + a - 12, d - 3), e.quadraticCurveTo(64 + a - 6, d - 10, 64 + a - 3, d - 18)
                }), t >= 3 && (e.beginPath(), e.ellipse(64, n - l + 6, a + 2, 9, 0, 0, Math.PI), e.fillStyle = "rgba(42,26,30,0.3)", e.fill()), o(e, 2.5, "rgba(42,26,30,0.5)", e => {
                    e.moveTo(64 - .1 * a, n + l + 4), e.quadraticCurveTo(64 + .8 * a, n + l - 1, 64 + a + 5, n + .5 * l)
                }), e.restore()
            }

            function d(e, t, a, l) {
                e.beginPath(), e.moveTo(28, t + 2), e.quadraticCurveTo(60, a - 7, 100, l - 2), e.quadraticCurveTo(62, a + 9, 30, t + 14), e.closePath(), e.fillStyle = "#ffffff", e.fill(), e.beginPath(), e.ellipse(32, t + 8, 6.5, 6, 0, 0, 2 * Math.PI), e.fill()
            }

            function h(e, t) {
                if (t) {
                    e.beginPath(), e.ellipse(64, 66, 36, 40, 0, 0, 2 * Math.PI), e.fillStyle = i, e.fill();
                    let a = e.createRadialGradient(64, 76, 4, 64, 66, 36);
                    a.addColorStop(0, "#fff6c8"), a.addColorStop(.35, t), a.addColorStop(1, t), e.beginPath(), e.ellipse(64, 66, 31, 35, 0, 0, 2 * Math.PI), e.fillStyle = a, e.fill(), e.beginPath(), e.ellipse(64, 66, 9, 26, 0, 0, 2 * Math.PI), e.fillStyle = "#140c0e", e.fill()
                } else {
                    let t = e.createRadialGradient(56, 54, 4, 64, 66, 40);
                    t.addColorStop(0, "#4a3a3c"), t.addColorStop(1, "#140c0e"), e.beginPath(), e.ellipse(64, 66, 34, 38, 0, 0, 2 * Math.PI), e.fillStyle = t, e.fill()
                }
                s(e, 50, 50, 11), s(e, 78, 82, 5, .9)
            }

            function f(e, t, a, l, n) {
                e.beginPath(), e.moveTo(t, a + .9 * l), e.bezierCurveTo(t - 1.3 * l, a + .1 * l, t - .9 * l, a - .95 * l, t, a - .35 * l), e.bezierCurveTo(t + .9 * l, a - .95 * l, t + 1.3 * l, a + .1 * l, t, a + .9 * l), e.closePath(), e.fillStyle = n, e.fill()
            }

            function p(e, t, a, l) {
                e.beginPath(), e.moveTo(64 - t, 52), e.quadraticCurveTo(64, 60, 64 + t, 52), e.quadraticCurveTo(64 + .8 * t, 54 + a, 64, 56 + a), e.quadraticCurveTo(64 - .8 * t, 54 + a, 64 - t, 52), e.closePath(), e.fillStyle = "#6e2632", e.fill(), e.save(), e.clip(), e.fillStyle = "#fffaf4", e.fillRect(64 - t, 48, 2 * t, .3 * a + 6), l && (e.beginPath(), e.ellipse(64, 60 + a, .55 * t, .5 * a, 0, 0, 2 * Math.PI), e.fillStyle = "#ef7c8a", e.fill()), e.restore(), e.lineWidth = 4, e.strokeStyle = "#4a1f27", e.stroke(), o(e, 3, "#4a1f27", e => {
                    e.moveTo(64 - t - 4, 48), e.lineTo(64 - t + 1, 53), e.moveTo(64 + t + 4, 48), e.lineTo(64 + t - 1, 53)
                })
            }
            let c = {
                    eye0: e => u(e, 0),
                    eye1: e => u(e, 1),
                    eye2: e => u(e, 2),
                    eye3: e => u(e, 3),
                    eye4: e => u(e, 4),
                    eyeHappy: e => o(e, 10, i, e => {
                        e.moveTo(30, 80), e.quadraticCurveTo(64, 30, 98, 80)
                    }),
                    eyeBlink: e => o(e, 8, i, e => {
                        e.moveTo(28, 64), e.quadraticCurveTo(64, 84, 100, 62)
                    }),
                    eyeSleepy: e => {
                        e.save(), e.beginPath(), e.rect(0, 70, 128, 58), e.clip(), u(e, 3), e.restore(), o(e, 9, i, e => {
                            e.moveTo(28, 72), e.quadraticCurveTo(64, 64, 102, 70)
                        })
                    },
                    eyeHeart: e => {
                        f(e, 64, 66, 40, "#e8405f"), f(e, 64, 64, 30, "#ff6f8e"), s(e, 48, 50, 8)
                    },
                    eyeSurprised: e => {
                        e.beginPath(), e.ellipse(64, 66, 34, 40, 0, 0, 2 * Math.PI), e.fillStyle = "#fffaf6", e.fill(), e.lineWidth = 6, e.strokeStyle = i, e.stroke(), e.beginPath(), e.ellipse(64, 68, 13, 16, 0, 0, 2 * Math.PI), e.fillStyle = "#2b1912", e.fill(), s(e, 59, 62, 4)
                    },
                    eyeShy: e => o(e, 10, i, e => {
                        e.moveTo(94, 40), e.lineTo(38, 66), e.lineTo(94, 92)
                    }),
                    catGreen: e => h(e, "#7cc457"),
                    catBlue: e => h(e, "#6fb1f2"),
                    catAmber: e => h(e, "#f2b53a"),
                    petDark: e => h(e, null),
                    petClosed: e => o(e, 11, i, e => {
                        e.moveTo(28, 78), e.quadraticCurveTo(64, 34, 100, 78)
                    }),
                    mouthSmile: e => p(e, 27, 28, !0),
                    mouthSoft: e => o(e, 8, "#5a2830", e => {
                        e.moveTo(34, 56), e.quadraticCurveTo(64, 84, 94, 56)
                    }),
                    mouthO: e => {
                        e.beginPath(), e.ellipse(64, 66, 17, 22, 0, 0, 2 * Math.PI), e.fillStyle = "#7c2e38", e.fill(), e.lineWidth = 5, e.strokeStyle = "#4a1f27", e.stroke()
                    },
                    mouthWavy: e => o(e, 7, "#5a2830", e => {
                        e.moveTo(30, 66), e.quadraticCurveTo(39, 54, 48, 66), e.quadraticCurveTo(57, 78, 66, 66), e.quadraticCurveTo(75, 54, 84, 66), e.quadraticCurveTo(91, 74, 98, 66)
                    }),
                    mouthSmall: e => o(e, 7, "#5a2830", e => {
                        e.moveTo(50, 64), e.quadraticCurveTo(64, 74, 78, 64)
                    }),
                    mouthCat: e => o(e, 7, "#4a2a2e", e => {
                        e.moveTo(30, 52), e.quadraticCurveTo(46, 76, 64, 56), e.quadraticCurveTo(82, 76, 98, 52)
                    }),
                    mouthLove: e => p(e, 34, 40, !0),
                    mouthDog: e => {
                        o(e, 7, "#3a2226", e => {
                            e.moveTo(64, 34), e.lineTo(64, 54), e.moveTo(30, 50), e.quadraticCurveTo(46, 70, 64, 54), e.quadraticCurveTo(82, 70, 98, 50)
                        }), e.beginPath(), e.ellipse(64, 74, 14, 16, 0, 0, Math.PI), e.fillStyle = "#f27f8c", e.fill()
                    },
                    browNormal: e => d(e, 70, 58, 68),
                    browRaised: e => d(e, 56, 38, 50),
                    browWorried: e => d(e, 50, 62, 78),
                    browRelaxed: e => d(e, 74, 68, 76),
                    blush: e => {
                        e.save(), e.translate(64, 64), e.scale(1, .62);
                        let t = e.createRadialGradient(0, 0, 4, 0, 0, 58);
                        for (let a of (t.addColorStop(0, "rgba(255,112,138,0.85)"), t.addColorStop(.6, "rgba(255,130,150,0.45)"), t.addColorStop(1, "rgba(255,140,160,0)"), e.fillStyle = t, e.fillRect(-64, -104, 128, 208), e.restore(), [-18, 0, 18])) o(e, 4, "rgba(255,255,255,0.7)", e => {
                            e.moveTo(64 + a + 6, 52), e.lineTo(64 + a - 4, 74)
                        })
                    },
                    empty: () => {},
                    nose: e => {
                        let t = e.createRadialGradient(70, 74, 2, 64, 70, 34);
                        t.addColorStop(0, "rgba(150,70,60,0.45)"), t.addColorStop(1, "rgba(150,70,60,0)"), e.fillStyle = t, e.beginPath(), e.ellipse(64, 72, 30, 20, 0, 0, 2 * Math.PI), e.fill(), o(e, 5, "rgba(120,52,48,0.55)", e => {
                            e.moveTo(50, 78), e.quadraticCurveTo(64, 88, 78, 78)
                        }), s(e, 60, 58, 6, .55)
                    },
                    mouthGrin: e => {
                        e.beginPath(), e.moveTo(30, 46), e.quadraticCurveTo(64, 56, 98, 46), e.quadraticCurveTo(92, 98, 64, 100), e.quadraticCurveTo(36, 98, 30, 46), e.closePath(), e.fillStyle = "#6e2632", e.fill(), e.save(), e.clip(), e.fillStyle = "#fffaf4", e.fillRect(20, 40, 90, 22), e.beginPath(), e.ellipse(64, 96, 22, 16, 0, 0, 2 * Math.PI), e.fillStyle = "#ef7c8a", e.fill(), e.restore(), e.lineWidth = 4, e.strokeStyle = "#4a1f27", e.stroke()
                    },
                    mouthGentle: e => {
                        e.beginPath(), e.moveTo(36, 60), e.quadraticCurveTo(64, 82, 92, 60), e.quadraticCurveTo(64, 92, 36, 60), e.fillStyle = "rgba(214,110,118,0.55)", e.fill(), o(e, 6, "#5a2830", e => {
                            e.moveTo(34, 58), e.quadraticCurveTo(64, 80, 94, 58)
                        }), o(e, 3, "#5a2830", e => {
                            e.moveTo(32, 54), e.lineTo(36, 60), e.moveTo(96, 54), e.lineTo(92, 60)
                        })
                    }
                },
                y = new WeakMap;

            function m(e) {
                if (e) return e;
                let t = globalThis.document;
                return t && "function" == typeof t.createElement ? t : null
            }

            function b(e) {
                if (!e) return null;
                let t = y.get(e);
                if (t) return t.refs++, t.texture;
                let a = null;
                try {
                    a = function(e) {
                        let t = e.createElement("canvas");
                        t.width = 1024, t.height = 640;
                        let a = t.getContext("2d");
                        if (!a) return null;
                        for (let e of Object.keys(r)) {
                            let [t, l] = r[e];
                            a.save(), a.translate(128 * t, 128 * l), a.beginPath(), a.rect(0, 0, 128, 128), a.clip(), c[e](a), a.restore()
                        }
                        return t
                    }(e)
                } catch {
                    a = null
                }
                if (!a) return null;
                let n = new l.GOR(a);
                return n.colorSpace = l.er$, n.anisotropy = 4, y.set(e, {
                    texture: n,
                    refs: 1
                }), n
            }

            function M(e, t) {
                if (!e || !t) return;
                let a = y.get(e);
                a && a.texture === t && (a.refs--, a.refs <= 0 && (a.texture.dispose(), y.delete(e)))
            }

            function w(e, t, a) {
                let n = new Float32Array(9 * e.length * 3),
                    i = new Float32Array(9 * e.length * 3),
                    o = new Float32Array(9 * e.length * 2),
                    s = new Float32Array(9 * e.length * 4),
                    u = new Float32Array(9 * e.length * 2),
                    d = [];
                e.forEach((e, l) => {
                    let r = e.roll ? ? 0;
                    for (let o = 0; o <= 2; o++)
                        for (let h = 0; h <= 2; h++) {
                            let f = 9 * l + 3 * o + h,
                                p = h / 2 - .5,
                                c = o / 2 - .5,
                                y = p * e.w,
                                m = c * e.h,
                                b = e.x + y * Math.cos(r) - m * Math.sin(r),
                                M = e.y + y * Math.sin(r) + m * Math.cos(r),
                                w = 1 - (b / a.x) ** 2 - (M / a.y) ** 2,
                                g = a.z * Math.sqrt(Math.max(.02, w)),
                                v = b / (a.x * a.x),
                                x = M / (a.y * a.y),
                                k = g / (a.z * a.z),
                                z = Math.hypot(v, x, k) || 1;
                            n[3 * f] = t.x + b + v / z * e.lift, n[3 * f + 1] = t.y + M + x / z * e.lift, n[3 * f + 2] = t.z + g + k / z * e.lift, i[3 * f] = v / z, i[3 * f + 1] = x / z, i[3 * f + 2] = k / z, u[2 * f] = e.mirror ? 1 - (p + .5) : p + .5, u[2 * f + 1] = c + .5;
                            let S = e.tint ? ? [1, 1, 1];
                            if (s[4 * f] = S[0], s[4 * f + 1] = S[1], s[4 * f + 2] = S[2], s[4 * f + 3] = e.alpha ? ? 1, h < 2 && o < 2) {
                                let e = 9 * l + 3 * o + h,
                                    t = e + 1,
                                    a = e + 2 + 1,
                                    n = a + 1;
                                d.push(e, t, n, e, n, a)
                            }
                        }
                });
                let h = new l.LoY;
                h.setAttribute("position", new l.THS(n, 3)), h.setAttribute("normal", new l.THS(i, 3));
                let f = new l.THS(o, 2);
                h.setAttribute("uv", f);
                let p = new l.THS(s, 4);

                function c(e, t) {
                    let [a, l, n, i] = function(e) {
                        let [t, a] = r[e];
                        return [t / 8 + .00146484375, 1 - (a + 1) / 5 + .0029296875, (t + 1) / 8 - .00146484375, 1 - a / 5 - .0029296875]
                    }(t);
                    for (let t = 9 * e; t < (e + 1) * 9; t++) o[2 * t] = a + (n - a) * u[2 * t], o[2 * t + 1] = l + (i - l) * u[2 * t + 1];
                    f.needsUpdate = !0
                }
                return h.setAttribute("color", p), h.setIndex(d), e.forEach((e, t) => c(t, e.cell)), {
                    geometry: h,
                    setCell: c,
                    setAlpha: function(e, t) {
                        for (let a = 9 * e; a < (e + 1) * 9; a++) s[4 * a + 3] = t;
                        p.needsUpdate = !0
                    },
                    setTint: function(e, t) {
                        for (let a = 9 * e; a < (e + 1) * 9; a++) s[4 * a] = t[0], s[4 * a + 1] = t[1], s[4 * a + 2] = t[2];
                        p.needsUpdate = !0
                    }
                }
            }

            function g(e, t) {
                let a = function(e, t) {
                    let a = ["eye0", "eye1", "eye2", "eye3", "eye4"][t];
                    switch (e) {
                        case "love":
                            return {
                                eye: "eyeHeart",
                                mouth: "mouthLove",
                                brow: "browNormal",
                                blush: 1,
                                blinks: !1
                            };
                        case "shy":
                            return {
                                eye: "eyeShy",
                                mouth: "mouthWavy",
                                brow: "browWorried",
                                blush: 1,
                                blinks: !1
                            };
                        case "surprised":
                            return {
                                eye: "eyeSurprised",
                                mouth: "mouthO",
                                brow: "browRaised",
                                blush: .25,
                                blinks: !0
                            };
                        case "sleepy":
                            return {
                                eye: "eyeSleepy",
                                mouth: "mouthSmall",
                                brow: "browRelaxed",
                                blush: .4,
                                blinks: !0
                            };
                        case "laugh":
                            return {
                                eye: "eyeHappy",
                                mouth: "mouthGrin",
                                brow: "browRaised",
                                blush: .8,
                                blinks: !1
                            };
                        case "calm":
                            return {
                                eye: a,
                                mouth: "mouthGentle",
                                brow: "browRelaxed",
                                blush: .45,
                                blinks: !0
                            };
                        default:
                            return {
                                eye: a,
                                mouth: "mouthSmile",
                                brow: "browNormal",
                                blush: .6,
                                blinks: !0
                            }
                    }
                }(e, t);
                return 4 !== t ? a : { ...a,
                    mouth: "mouthSmile" === a.mouth ? "mouthGentle" : a.mouth,
                    blush: .35 * a.blush
                }
            }
            let v = `
const vec3 ZARI = vec3(0.86, 0.6, 0.2);
float trimMask(vec3 t){
  float kind = floor(t.x + 0.5);
  // a triangle between two kinds interpolates the kind: leave it plain cloth
  if (kind < 0.5 || abs(t.x - kind) > 0.02) return 0.0;
  if (kind < 1.5) {
    float v = clamp(t.z, 0.0, 1.0);
    float lines = step(v, 0.14) + step(0.86, v);
    vec2 q = vec2(fract(t.y) - 0.5, (v - 0.5) * 1.6);
    float d = abs(q.x) + abs(q.y);
    float diamond = step(d, 0.3) * (1.0 - step(d, 0.14)) + step(d, 0.07);
    return clamp(lines + diamond, 0.0, 1.0);
  }
  if (kind < 2.5) {
    vec2 g = vec2(t.y, t.z);
    g.x += 0.5 * step(0.5, fract(g.y * 0.5));
    vec2 f = fract(g) - 0.5;
    return 1.0 - smoothstep(0.13, 0.17, length(f));
  }
  if (kind < 3.5) return 1.0;
  float edge = smoothstep(0.8, 0.84, t.z);
  vec2 f = fract(vec2(t.y, t.z * 3.0)) - 0.5;
  float buti = (1.0 - smoothstep(0.12, 0.16, length(f))) * (1.0 - edge);
  return clamp(edge + buti, 0.0, 1.0);
}`;

            function x() {
                let e, t = ((e = new l.GYF(new Uint8Array([108, 172, 240, 255]), 4, 1, l.VT0)).minFilter = l.hxR, e.magFilter = l.hxR, e.generateMipmaps = !1, e.needsUpdate = !0, e),
                    a = function(e, t = .6) {
                        let a = new l.Df({
                            vertexColors: !0,
                            gradientMap: e
                        });
                        return a.onBeforeCompile = e => {
                            e.uniforms.uRim = {
                                value: t
                            }, e.vertexShader = e.vertexShader.replace("void main() {", "attribute vec3 trim;\nvarying vec3 vTrim;\nvoid main() {\n  vTrim = trim;"), e.fragmentShader = e.fragmentShader.replace("void main() {", `uniform float uRim;
varying vec3 vTrim;
${v}
void main() {`).replace("#include <color_fragment>", "#include <color_fragment>\n  float zari = trimMask(vTrim);\n  diffuseColor.rgb = mix(diffuseColor.rgb, ZARI, zari);").replace("#include <aomap_fragment>", `#include <aomap_fragment>
        {
          float rimF = 1.0 - saturate( dot( normal, normalize( vViewPosition ) ) );
          float rimM = smoothstep( 0.58, 0.82, rimF ) * uRim;
          vec3 litC = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
          reflectedLight.indirectDiffuse += litC * rimM * 0.6 + diffuseColor.rgb * rimM * 0.035;
          // zari catches the light: a little metallic lift
          reflectedLight.indirectDiffuse += litC * zari * 0.35 + ZARI * zari * 0.03;
        }`)
                        }, a.customProgramCacheKey = () => `cp-rim-toon-zari-${t}`, a
                    }(t),
                    n = function(e = .0085) {
                        let t = new l.V9B({
                            vertexColors: !0,
                            side: l.hsX
                        });
                        return t.onBeforeCompile = t => {
                            t.uniforms.uOutline = {
                                value: e
                            }, t.vertexShader = t.vertexShader.replace("void main() {", "uniform float uOutline;\nvoid main() {").replace("#include <begin_vertex>", `#include <begin_vertex>
        {
          float viewDepth = -( modelViewMatrix * vec4( position, 1.0 ) ).z;
          transformed += normalize( normal ) * uOutline * clamp( viewDepth / 3.0, 0.55, 2.4 );
        }`), t.fragmentShader = t.fragmentShader.replace("#include <color_fragment>", `#include <color_fragment>
      diffuseColor.rgb = pow( diffuseColor.rgb, vec3( 1.25 ) ) * 0.22 + vec3( 0.012, 0.006, 0.014 );`)
                        }, t.customProgramCacheKey = () => `cp-ink-${e}`, t
                    }(),
                    r = new l.Df({
                        gradientMap: t,
                        vertexColors: !0,
                        transparent: !0,
                        depthWrite: !1,
                        polygonOffset: !0,
                        polygonOffsetFactor: -2,
                        polygonOffsetUnits: -2
                    }),
                    i = function(e = 32) {
                        let t = new Uint8Array(e * e * 4);
                        for (let a = 0; a < e; a++)
                            for (let l = 0; l < e; l++) {
                                let n = (l + .5) / e - .5,
                                    r = (a + .5) / e - .5,
                                    i = Math.pow(1 - Math.min(1, 2 * Math.sqrt(n * n + r * r)), 1.6),
                                    o = (a * e + l) * 4;
                                t[o] = t[o + 1] = t[o + 2] = Math.round(255 * i), t[o + 3] = 255
                            }
                        let a = new l.GYF(t, e, e, l.GWd);
                        return a.minFilter = l.k6q, a.magFilter = l.k6q, a.needsUpdate = !0, a
                    }(),
                    o = new l.V9B({
                        color: "#1a1222",
                        transparent: !0,
                        opacity: .32,
                        alphaMap: i,
                        depthWrite: !1
                    }),
                    s = [t, a, n, r, o, i];
                return {
                    ramp: t,
                    body: a,
                    outline: n,
                    face: r,
                    blob: o,
                    blobAlpha: i,
                    dispose() {
                        for (let e of s) e.dispose()
                    }
                }
            }
            let k = new Map;

            function z(e) {
                let t = k.get(e);
                if (!t) {
                    let a = new l.Q1f(e);
                    t = [a.r, a.g, a.b], k.set(e, t)
                }
                return t
            }

            function S(e, t, a) {
                return [e[0] + (t[0] - e[0]) * a, e[1] + (t[1] - e[1]) * a, e[2] + (t[2] - e[2]) * a]
            }

            function P(e, t) {
                return [e[0] * t, e[1] * t, e[2] * t]
            }
            let C = new Set(["position", "normal"]);
            class q {
                add(e, t, a) {
                    let n = a.trim ? e.attributes.uv : void 0,
                        r = new Float32Array(3 * e.attributes.position.count);
                    if (a.trim) {
                        let i = new l.Pq0,
                            o = e.attributes.position,
                            s = t || null;
                        for (let e = 0; e < o.count; e++) {
                            i.fromBufferAttribute(o, e), s && i.applyMatrix4(s), n ? this.uv.fromBufferAttribute(n, e) : this.uv.set(0, 0);
                            let t = a.trim(i, this.uv);
                            t && r.set(t, 3 * e)
                        }
                    }
                    for (let t of Object.keys(e.attributes)) C.has(t) || e.deleteAttribute(t);
                    if (!e.index) {
                        let t = e.attributes.position.count;
                        e.setIndex(Array.from({
                            length: t
                        }, (e, t) => t))
                    }
                    t && e.applyMatrix4(t);
                    let i = e.attributes.position,
                        o = e.attributes.normal,
                        s = i.count,
                        u = new Float32Array(3 * s),
                        d = new Uint16Array(4 * s),
                        h = new Float32Array(4 * s),
                        {
                            paint: f,
                            skin: p
                        } = a;
                    for (let e = 0; e < s; e++) {
                        this.p.fromBufferAttribute(i, e), this.n.fromBufferAttribute(o, e);
                        let t = "function" == typeof f ? f(this.p, this.n) : f;
                        if (u[3 * e] = t[0], u[3 * e + 1] = t[1], u[3 * e + 2] = t[2], "number" == typeof p) d[4 * e] = p, h[4 * e] = 1;
                        else {
                            let [t, a, l] = p(this.p, e);
                            d[4 * e] = t, d[4 * e + 1] = a, h[4 * e] = 1 - l, h[4 * e + 1] = l
                        }
                    }
                    return e.setAttribute("color", new l.THS(u, 3)), e.setAttribute("skinIndex", new l.THS(d, 4)), e.setAttribute("skinWeight", new l.THS(h, 4)), e.setAttribute("trim", new l.THS(r, 3)), this.body.push(e), !1 !== a.outline && this.hull.push(e), e
                }
                build(e) {
                    let t = (0, n.pP)(this.body, !1),
                        a = e && this.hull.length ? (0, n.pP)(this.hull, !1) : null;
                    for (let e of this.body) e.dispose();
                    if (this.body = [], this.hull = [], !t) throw Error("character geometry failed to merge");
                    return {
                        body: t,
                        outline: a
                    }
                }
                constructor() {
                    this.body = [], this.hull = [], this.p = new l.Pq0, this.n = new l.Pq0, this.uv = new l.I9Y
                }
            }

            function T(e, t, a = 0, n = 2 * Math.PI) {
                let r = e.map(([e, t]) => new l.I9Y(Math.max(0, e), t)),
                    i = new l.nzx(r, t, a, n);
                i.normalizeNormals();
                let o = i.attributes.position,
                    s = i.attributes.normal;
                for (let t = 0; t < o.count; t++) {
                    let a = o.getX(t),
                        l = o.getZ(t);
                    if (1e-6 > Math.abs(a) && 1e-6 > Math.abs(l)) {
                        let a = o.getY(t),
                            l = e[0];
                        s.setXYZ(t, 0, 1e-6 > Math.abs(a - l[1]) && l[1] < e[e.length - 1][1] ? -1 : 1, 0)
                    }
                }
                return i
            }

            function A(e, t, a, n, r) {
                let i = new l.Gu$(1, n, r);
                return i.scale(e, t, a), i
            }
            let I = new l.kn4,
                F = new l.PTz,
                B = new l.O9p,
                D = new l.Pq0,
                H = new l.Pq0;

            function R(e, t, a, n = 0, r = 0, i = 0, o = 1, s = 1, u = 1) {
                return B.set(n, r, i), F.setFromEuler(B), D.set(o, s, u), H.set(e, t, a), new l.kn4().compose(H, F, D)
            }

            function Y(e, t, a, l = 6, n = !1) {
                let r = T(n ? [
                    [0, -e],
                    [.5, -(.97 * e)],
                    [.85, -(.84 * e)],
                    [1, -(.55 * e)],
                    [.93, -(.22 * e)],
                    [.75, .03 * e],
                    [0, .13 * e]
                ] : [
                    [0, -e],
                    [.18, -(.86 * e)],
                    [.55, -(.58 * e)],
                    [.86, -(.3 * e)],
                    [1, -(.1 * e)],
                    [.8, .06 * e],
                    [0, .14 * e]
                ], l);
                return r.scale(t / 2, 1, a / 2), r
            }

            function W(e, t, a, n) {
                let r = Math.cos(n) * Math.sin(a),
                    i = Math.sin(n),
                    o = Math.cos(n) * Math.cos(a);
                return {
                    p: new l.Pq0(t.x * r, t.y * i, t.z * o).add(e),
                    n: new l.Pq0(r / t.x, i / t.y, o / t.z).normalize()
                }
            }

            function O(e, t, a, n, r = 0) {
                var i;
                let o = new l.Pq0(0, 1, 0),
                    s = o.clone().sub(t.clone().multiplyScalar(o.dot(t)));
                1e-6 > s.lengthSq() && s.set(0, 0, -1), s.normalize();
                let u = t.clone(),
                    d = new l.Pq0().crossVectors(s, u).normalize();
                return (i = e.clone().add(t.clone().multiplyScalar(n)), I.clone().makeBasis(d, s, u).setPosition(i)).multiply(R(0, 0, 0, r, 0, -a))
            }

            function G(e, t) {
                let a = e.attributes.position;
                for (let e = 0; e < a.count; e++) a.getY(e) < t && a.setY(e, t);
                return X(e), e
            }

            function L(e, t, a, l, n) {
                let r = e.attributes.position;
                for (let e = 0; e < r.count; e++) {
                    let i = r.getX(e),
                        o = r.getZ(e),
                        s = r.getY(e),
                        u = Math.hypot(i, o);
                    if (u < 1e-5) continue;
                    let d = 1 + Math.cos(Math.atan2(i, o) * t) * a * Math.max(0, Math.min(1, (l - s) / (l - n))) / u;
                    r.setX(e, i * d), r.setZ(e, o * d)
                }
                return X(e), e
            }

            function N(e, t, a, l) {
                return n => {
                    let r = Math.max(0, Math.min(1, (n.y - a) / (l - a)));
                    return [e, t, r * r * (3 - 2 * r)]
                }
            }

            function X(e) {
                e.computeVertexNormals();
                let t = e.attributes.position,
                    a = e.attributes.normal,
                    n = new Map;
                for (let e = 0; e < t.count; e++) {
                    let a = `${Math.round(1e4*t.getX(e))},${Math.round(1e4*t.getY(e))},${Math.round(1e4*t.getZ(e))}`,
                        l = n.get(a);
                    l ? l.push(e) : n.set(a, [e])
                }
                let r = new l.Pq0;
                for (let e of n.values())
                    if (!(e.length < 2)) {
                        for (let t of (r.set(0, 0, 0), e)) r.set(r.x + a.getX(t), r.y + a.getY(t), r.z + a.getZ(t));
                        for (let t of (r.normalize(), e)) a.setXYZ(t, r.x, r.y, r.z)
                    }
                return e
            }
            var _ = a(28208);
            let E = [-1, 0, 1, 2, 3, 1, 2, 6, 2, 8, 1, 10, 1, 12],
                U = [
                    [0, 0, 0],
                    [0, .4, 0],
                    [0, .47, 0],
                    [0, .74, 0],
                    [0, 1.03, -.235],
                    [0, .47, 0],
                    [-.165, .665, 0],
                    [-.165, .515, 0],
                    [.165, .665, 0],
                    [.165, .515, 0],
                    [-.083, .385, 0],
                    [-.083, .22, 0],
                    [.083, .385, 0],
                    [.083, .22, 0]
                ],
                Z = z("#fffaf4"),
                V = z("#e9b94c");

            function $(e, t) {
                let a = [...e],
                    l = t => {
                        for (let a = 0; a < e.length - 1; a++) {
                            let l = e[a],
                                n = e[a + 1];
                            if (t >= l[1] && t <= n[1]) return l[0] + (n[0] - l[0]) * (t - l[1]) / (n[1] - l[1] || 1)
                        }
                        return e[e.length - 1][0]
                    },
                    n = e[0][1],
                    r = e[e.length - 1][1];
                for (let e of t) e - .0012 <= n || e + .0012 >= r || a.push([l(e - .0012), e - .0012], [l(e + .0012), e + .0012]);
                return a.sort((e, t) => e[1] - t[1]), a
            }

            function K(e, t, a, l, n) {
                let r = a(0),
                    i = a(t),
                    o = [
                        [0, e - t - .9 * i],
                        [.72 * i, e - t - .62 * i]
                    ],
                    s = new Set(l);
                for (let e of n) e > .004 && e < t - .004 && (s.add(e - .0012), s.add(e + .0012));
                for (let t of [...s].sort((e, t) => t - e)) o.push([a(t), e - t]);
                return o.push([.78 * r, e + .6 * r], [0, e + .92 * r]), o.sort((e, t) => e[1] - t[1])
            }

            function J(e, t, a, n) {
                let r = new l.B6O([...e]),
                    i = [],
                    o = [],
                    s = [],
                    u = [],
                    d = new l.Pq0,
                    h = new l.Pq0,
                    f = new l.Pq0,
                    p = new l.Pq0;
                for (let e = 0; e <= n; e++) {
                    let l = e / n,
                        u = r.getPointAt(l);
                    r.getTangentAt(l, d).normalize(), h.set(u.x, 0, u.z), 1e-6 > h.lengthSq() && h.set(0, 0, 1), h.normalize(), f.crossVectors(d, h).normalize(), p.crossVectors(f, d).normalize();
                    for (let e = 0; e <= 6; e++) {
                        let n = e / 6 * Math.PI * 2,
                            r = Math.cos(n),
                            d = Math.sin(n);
                        i.push(u.x + f.x * r * t * .5 + p.x * d * a * .5, u.y + f.y * r * t * .5 + p.y * d * a * .5, u.z + f.z * r * t * .5 + p.z * d * a * .5);
                        let h = f.clone().multiplyScalar(r * a).add(p.clone().multiplyScalar(d * t)).normalize();
                        o.push(h.x, h.y, h.z), s.push(l, Math.abs(r))
                    }
                }
                for (let e = 0; e < n; e++)
                    for (let t = 0; t < 6; t++) {
                        let a = 7 * e + t,
                            l = a + 6 + 1;
                        u.push(a, l, a + 1, l, l + 1, a + 1)
                    }
                let c = new l.LoY;
                return c.setAttribute("position", new l.qtW(i, 3)), c.setAttribute("normal", new l.qtW(o, 3)), c.setAttribute("uv", new l.qtW(s, 2)), c.setIndex(u), {
                    geometry: c,
                    length: r.getLength()
                }
            }

            function j(e, t) {
                let a = new q,
                    n = _.Cl[e.top],
                    r = _.An[e.bottom],
                    i = z(_.C7[e.skin]),
                    o = P(i, .93),
                    s = z(_.bW[e.hairColor]),
                    u = S(s, z("#fff4e6"), "Black" === e.hairColor ? .16 : .22),
                    d = z(_.D1[e.topColor]),
                    h = "Black" === e.topColor ? S(d, Z, .18) : P(d, .78),
                    f = S(d, Z, .4),
                    p = z(_.D1[e.bottomColor]),
                    c = "Black" === e.bottomColor ? S(p, Z, .15) : P(p, .8),
                    y = S(p, Z, .3),
                    m = z(_.EB[e.shoes]),
                    b = "White" === e.shoes ? z("#d8d2ca") : Z,
                    M = !n.hidesBottom,
                    g = M ? r.legs : "bare",
                    v = M && r.skirtHem > 0,
                    x = e.accessory,
                    k = "Male" === e.gender,
                    C = k ? _.x6[e.build] : _.Lb[e.build],
                    I = k ? _.x6[e.build].shoulder : 0,
                    F = n.hidesBottom,
                    B = "Crop top" === e.top,
                    D = "Hoodie" === e.top || "Sweater" === e.top,
                    H = "Saree" === e.top,
                    E = "Anarkali" === e.top,
                    j = "Sherwani" === e.top,
                    Q = "Nehru jacket" === e.top,
                    ee = "White" === e.topColor ? z("#efe2c4") : z("#f6eedc"),
                    et = H ? "Mustard" === e.topColor || "White" === e.topColor ? z("#b83a4a") : "Black" === e.topColor ? V : P(d, .62) : d,
                    ea = Q ? ee : H ? et : d,
                    el = "Shirt" === e.top ? .455 : n.hem,
                    en = !n.tunic && "Shirt" === e.top && "bare" !== r.legs,
                    er = "Hoodie" === e.top ? .01 : .006 * ("Sweater" === e.top),
                    {
                        chest: ei,
                        waist: eo,
                        hips: es
                    } = C,
                    eu = [
                        [0, .352],
                        [.07, .357],
                        [es / .151 * .118, .372],
                        [es / .151 * .143, .4],
                        [es + .5 * er, .44],
                        [eo + (es - eo) * .3 + er, .49],
                        [eo + er, .53],
                        [eo + (ei - eo) * .64 + er, .58],
                        [ei + er, .625], ...k ? [
                            [ei + .004 + .6 * I + er, .665],
                            [.142 + .5 * I + .5 * er, .695],
                            [.1, .716],
                            [.057, .737],
                            [.054, .79]
                        ] : [
                            [.147 + (ei - .155) * .6 + er, .665],
                            [.118 + .5 * er, .698],
                            [.075, .72],
                            [.047, .735],
                            [.043, .79]
                        ],
                        [0, .8]
                    ],
                    ed = e => {
                        for (let t = 0; t < eu.length - 1; t++) {
                            let [a, l] = eu[t], [n, r] = eu[t + 1];
                            if (e >= l && e <= r) return a + (n - a) * (e - l) / (r - l || 1)
                        }
                        return .15
                    },
                    eh = ed(.47) + .004,
                    ef = "scoop" === n.neck ? .704 : "band" === n.neck ? .724 : .714,
                    ep = [ef, .665, .625];
                H && ep.push(.585), (j || E) && ep.push(.47), !n.tunic && el > .36 && el < .7 && ep.push(el), D && ep.push(el + .022), B && ep.push(.455), en && ep.push(.43);
                let ec = T($(eu, ep), 20);
                ec.scale(1, 1, .8), a.add(ec, null, {
                    paint: e => e.y > ef ? i : H ? e.y > .585 ? et : d : n.tunic || e.y >= el ? D && e.y < el + .022 ? h : d : B && e.y > .455 ? i : en && e.y > .43 ? z("#5a3a2a") : M && "bare" !== r.legs ? p : v ? c : i,
                    skin: e => e.y > .7 ? N(2, 3, .72, .765)(e) : N(1, 2, .45, .53)(e),
                    trim: j || E ? (e, t) => e.y < ef && e.y > .47 ? [2, 26 * t.x, 26 * e.y] : null : void 0
                });
                let ey = (e, t, a, l, n = !1) => {
                    let r = [
                        [.72 * t, e + .02],
                        [t - .01, e - .002],
                        [t, e + .008]
                    ];
                    for (let l of [.7, .36]) r.push([eh + (t - eh) * Math.pow(l, a), .47 - (.47 - e) * l]);
                    return n ? r.push([eh - .014, .47], [.1, .48]) : r.push([eh + .002, .47], [ed(.51) + .004, .51], [.1, .515]), {
                        profile: r,
                        segments: l
                    }
                };
                if (v) {
                    let {
                        profile: t
                    } = ey(r.skirtHem, r.skirtFlare, "Lehenga" === e.bottom ? .9 : .8, 0, n.tunic), l = "Lehenga" === e.bottom, i = T($(t, l ? [r.skirtHem + .045, .455] : [.455]), Math.max(20, Math.min(27, 3 * r.pleats)));
                    r.pleats && L(i, r.pleats, l ? .01 : .008, .44, r.skirtHem), i.scale(1, 1, .9), a.add(i, null, {
                        paint: e => e.y > .455 ? c : r.border && e.y < r.skirtHem + .045 ? P(p, .7) : p,
                        skin: 5,
                        trim: l ? (e, t) => e.y < r.skirtHem + .045 ? [1, 18 * t.x, (e.y - r.skirtHem) / .045] : e.y < .455 ? [2, 22 * t.x, 22 * e.y] : null : void 0
                    })
                }
                if (n.tunic) {
                    let t = Math.max(n.flare, (t => {
                            if (!v) return 0;
                            let a = Math.max(0, Math.min(1, (.47 - t) / (.47 - r.skirtHem)));
                            return eh + (r.skirtFlare - eh) * Math.pow(a, "Lehenga" === e.bottom ? .9 : .8)
                        })(el) + (r.pleats ? .035 : .025)),
                        {
                            profile: l
                        } = ey(el, t, F ? .7 : 1.05, 0),
                        i = "Kurti" === e.top || "Kurta" === e.top || H || E || j || Q,
                        o = H ? .05 : E ? .06 : .032,
                        s = i ? [el + o] : [];
                    Q && s.push(.36), (E || j) && s.push(.44);
                    let u = T($(l, s), H || E ? 30 : 20);
                    E && L(u, 14, .011, .44, el), H && L(u, 18, .004, .36, el), u.scale(1, 1, .9);
                    let f = H || E ? 22 : 16;
                    a.add(u, null, {
                        paint: t => Q ? t.y > .36 ? d : ee : i && t.y < el + o ? "Kurta" === e.top ? h : "Kurti" === e.top ? V : P(d, .72) : d,
                        skin: 5,
                        trim: (t, a) => i && t.y < el + o && "Kurta" !== e.top ? [1, a.x * f, (t.y - el) / o] : (E || j) && t.y < .44 ? [2, a.x * (E ? 30 : 20), 24 * t.y] : Q && t.y > .36 && t.y < .372 ? [3, 0, 0] : null
                    })
                }
                let em = "full" === g ? r.loose : 0,
                    eb = e => {
                        let t = (e < .165 ? .066 - .016 * e / .165 : .05 - .009 * (e - .165) / .15) + .004 * !!k;
                        return "shorts" === g && e < .1 ? t + .014 : "full" === g && r.cuff && e > .282 ? t + em + .006 : "bare" === g ? t - .004 : t + em
                    },
                    eM = [];
                for (let e of ("shorts" === g && eM.push(.1), "full" === g && r.cuff && eM.push(.282), [-1, 1])) {
                    let t = .083 * e,
                        l = e < 0 ? 10 : 12,
                        n = e < 0 ? 11 : 13,
                        o = T(K(.385, .315, eb, [0, .08, .165, .24, .315], eM), 12);
                    o.translate(t, 0, 0), a.add(o, null, {
                        paint: e => {
                            let t = .385 - e.y;
                            return "full" === g ? r.cuff && t > .282 ? y : p : "shorts" === g && t < .1 ? p : i
                        },
                        skin: N(n, l, .2, .242)
                    });
                    let s = G(A(.054, .046, .094, 12, 8), -.03),
                        u = s.attributes.position;
                    for (let e = 0; e < u.count; e++) {
                        let t = u.getZ(e);
                        t > 0 && (u.setY(e, u.getY(e) * (1 - t / .094 * .18)), u.setX(e, u.getX(e) * (1 + t / .094 * .08)))
                    }
                    X(s), k && s.scale(1.06, 1.04, 1.1), s.translate(t, .034, .036), a.add(s, null, {
                        paint: e => e.y < .016 ? b : e.y > .058 && e.z < .02 ? S(m, Z, .2) : m,
                        skin: n
                    })
                }
                let ew = n.sleeve >= .28,
                    eg = F && n.sleeve > 0,
                    ev = e => {
                        let t = k ? .054 - .013 * e / .3 + (e < .07 ? .004 * (1 - e / .07) : 0) : .047 - .011 * e / .3;
                        return e < n.sleeve ? t + (eg ? .02 * (1 - e / n.sleeve) + .006 : ew ? .008 : .011) : t
                    },
                    ex = n.sleeve > 0 && n.sleeve < .29 ? [n.sleeve] : [];
                for (let t of ("Kurti" === e.top && ex.push(n.sleeve - .02), ew && ex.push(.268), [-1, 1])) {
                    let [l, r] = U[t < 0 ? 6 : 8], o = t < 0 ? 6 : 8, s = t < 0 ? 7 : 9, u = T(K(r, .3, ev, [0, .075, .15, .225, .3], ex), 12);
                    u.translate(l, 0, 0), a.add(u, null, {
                        paint: t => {
                            let a = r - t.y;
                            return a < n.sleeve ? ew && a > .268 ? "Kurti" === e.top ? V : Q ? ee : h : "Kurti" === e.top && a > n.sleeve - .02 ? V : ea : i
                        },
                        trim: (e, t) => {
                            let a = r - e.y;
                            return (E || j) && ew && a > .268 && a < n.sleeve ? [1, 6 * t.x, (a - .268) / (n.sleeve - .268)] : H && a < n.sleeve && a > n.sleeve - .018 ? [3, 0, 0] : null
                        },
                        skin: N(s, o, r - .15 - .025, r - .15 + .025)
                    });
                    let d = r - .3 - .032,
                        f = k ? A(.031, .048, .039, 9, 6) : A(.027, .044, .035, 9, 6);
                    f.translate(l, d, .004), a.add(f, null, {
                        paint: i,
                        skin: s
                    });
                    let p = A(.012, .021, .012, 5, 3);
                    p.applyMatrix4(R(l - .019 * t, d + .012, .022, 0, 0, .45 * t)), a.add(p, null, {
                        paint: i,
                        skin: s,
                        outline: !1
                    })
                }
                let ek = new l.Pq0(0, .99, .012),
                    ez = new l.Pq0(.262, .243, .248),
                    eS = "Male" === e.gender ? e.facialHair : "None",
                    eP = "None" === eS ? A(ez.x, ez.y, ez.z, 26, 16) : A(ez.x, ez.y, ez.z, 32, 20);
                eP.translate(ek.x, ek.y, ek.z);
                let eC = "Beard" === eS ? .8 : .45 * ("Stubble" === eS),
                    eq = P(s, "Black" === e.hairColor ? 1.25 : .92),
                    eT = "Stubble" === eS ? S(eq, z("#56607a"), .45) : eq,
                    eA = e => {
                        let t = Math.max(0, Math.min(1, e));
                        return t * t * (3 - 2 * t)
                    };
                if (a.add(eP, null, {
                        paint: eC ? e => {
                            let t;
                            return S(i, eT, eC * (eA((-.48 + .3 * (t = (e.x - ek.x) / ez.x) * t - (e.y - ek.y) / ez.y) / .05) * eA((e.z - ek.z + .03) / .06)))
                        } : i,
                        skin: 3
                    }), "Beard" === eS) {
                    let e = A(.105, .058, .062, 10, 6);
                    e.translate(0, ek.y - .2, ek.z + .112), a.add(e, null, {
                        paint: S(i, eq, eC),
                        skin: 3
                    })
                }
                if ("Moustache" === eS || "Beard" === eS) {
                    let e = Math.asin(-.103 / ez.y);
                    for (let t of [-1, 1]) {
                        let {
                            p: l,
                            n
                        } = W(ek, ez, .15 * t, e), r = A(.036, .012, .012, 8, 5);
                        r.applyMatrix4(R(l.x + .004 * n.x, l.y + .004 * n.y, l.z + .004 * n.z, 0, .15 * t, -.22 * t)), a.add(r, null, {
                            paint: P(eq, .9),
                            skin: 3,
                            outline: !1
                        })
                    }
                }
                for (let e of [-1, 1]) {
                    let t = A(.028, .046, .028, 5, 4);
                    t.applyMatrix4(R(.252 * e, ek.y - .02, 0, 0, 0, -.15 * e)), a.add(t, null, {
                        paint: o,
                        skin: 3,
                        outline: !1
                    })
                }
                let eI = A(.014, .01, .01, 6, 4);
                eI.translate(0, ek.y - .078, ek.z + .236), a.add(eI, null, {
                    paint: o,
                    skin: 3,
                    outline: !1
                });
                let eF = "Cap" === x,
                    eB = new l.Pq0(ek.x, ek.y + .012, ek.z - .008),
                    eD = new l.Pq0(.283, .268, .277),
                    eH = P(s, "Black" === e.hairColor ? .62 : .74),
                    eR = e => {
                        let t = (e.y - eB.y) / eD.y,
                            a = .5 + .5 * Math.sin(9 * Math.atan2(e.x - eB.x, e.z - eB.z) + 4 * t),
                            l = S(eH, s, Math.max(0, Math.min(1, (t + 1.6) / 1.9)));
                        return t > .46 && t < .76 && e.z > eB.z - .06 && (l = S(l, u, .55 + .4 * a)), P(l, .93 + .1 * a)
                    },
                    eY = (e, t, n, r = 0, i = 0) => {
                        let o = (e - n) / 2,
                            s = ((e + n) / 2 + t) / 2,
                            u = ((e + n) / 2 - t) / 2,
                            d = new l.Gu$(1, 24, 18),
                            h = d.attributes.position,
                            f = new l.Pq0;
                        for (let e = 0; e < h.count; e++) {
                            f.fromBufferAttribute(h, e);
                            let t = Math.atan2(f.x, f.z),
                                a = Math.max(0, Math.min(1, (Math.asin(Math.max(-1, Math.min(1, f.y))) - (s + o * Math.cos(t) + u * Math.cos(2 * t) - .1)) / .16)),
                                l = a * a * (3 - 2 * a),
                                n = 1 + i * Math.max(0, f.y) ** 2,
                                d = (eD.x + r) * n,
                                p = (eD.y + r) * n,
                                c = (eD.z + r) * n;
                            h.setXYZ(e, eB.x + f.x * (.955 * ez.x + (d - .955 * ez.x) * l), eB.y + f.y * (.955 * ez.y + (p - .955 * ez.y) * l), eB.z + f.z * (.955 * ez.z + (c - .955 * ez.z) * l))
                        }
                        X(d), a.add(d, null, {
                            paint: eR,
                            skin: 3
                        })
                    },
                    eW = (e, t, l, n, r, i, o = 0, s = {}) => {
                        if (eF && t > .95) return;
                        let {
                            p: u,
                            n: d
                        } = W(eB, eD, e, t), h = function(e, t) {
                            let a = e.attributes.position;
                            for (let e = 0; e < a.count; e++) {
                                let l = a.getY(e);
                                l < 0 && a.setZ(e, a.getZ(e) + t * l * l)
                            }
                            return X(e), e
                        }(Y(l, n, r, 8, s.round ? ? !0), -(s.hug ? ? 1) / .54);
                        h.applyMatrix4(O(u, d, i, s.lift ? ? .12 * r, o)), a.add(h, null, {
                            paint: eR,
                            skin: s.bone ? ? 3,
                            outline: s.outline
                        })
                    },
                    eO = (e, t, a, l, n = .66, r = !0) => {
                        for (let i of e) eW(i, n, t * (1 - .18 * Math.abs(i)), a, .05, l(i), .04, {
                            round: r
                        })
                    },
                    eG = (e, t, l) => {
                        let n = Y(t, .09, .052, 10, !0);
                        if (l) {
                            let e = n.attributes.position;
                            for (let t = 0; t < e.count; t++) e.setX(t, e.getX(t) + .016 * Math.sin(30 * e.getY(t)));
                            X(n)
                        }
                        n.applyMatrix4(R(.215 * e, ek.y + .02, ek.z + .05, .08, .35 * e, .08 * e)), a.add(n, null, {
                            paint: eR,
                            skin: 3
                        })
                    },
                    eL = (e, t, n, r) => {
                        let i = new l.O3Y(.03, .012, 5, 10);
                        i.applyMatrix4(R(e, t, n, r, 0, 0)), a.add(i, null, {
                            paint: d,
                            skin: 4,
                            outline: !1
                        })
                    },
                    eN = _.tY[e.hairStyle];
                switch (e.hairStyle) {
                    case "Short":
                        for (let e of (eY(.5, .02, -.8, -.002, .04), eO([-.5, -.24, .02, .28, .54], .1, .12, e => .3 + .15 * e, .72, !1), eW(.15, 1.3, .085, .045, .03, Math.PI - .5, -.5, {
                                outline: !0,
                                round: !1
                            }), [-1, 1])) eW(1.28 * e, .16, .075, .075, .04, .08 * e, 0, {
                            round: !1
                        });
                        break;
                    case "Side part":
                        for (let e of (eY(.55, .02, -.8, 0, .08), eW(.38, .92, .22, .2, .065, -1.05, .1), eW(-.6, .62, .12, .13, .05, -.3), eW(.8, .58, .11, .11, .05, .2), [-1, 1])) eW(1.28 * e, .18, .08, .075, .04, .08 * e, 0, {
                            round: !1
                        });
                        break;
                    case "Buzz cut":
                        eY(.62, .04, -.85, -.012, 0);
                        break;
                    case "Quiff":
                        if (eY(.56, .02, -.8, -.006, 0), !eF) {
                            let e = A(.2, .07, .12, 18, 10);
                            e.applyMatrix4(R(.02, ek.y + .215, ek.z + .16, -.75, .12, -.06)), a.add(e, null, {
                                paint: eR,
                                skin: 3
                            }), eW(.3, .95, .2, .18, .06, -1.15, .1)
                        }
                        for (let e of [-1, 1]) eW(1.28 * e, .16, .075, .075, .04, .08 * e, 0, {
                            round: !1
                        });
                        break;
                    case "Curly":
                        {
                            eY(.5, -.05, -.75, .006, .05);
                            let e = (e, t, l) => {
                                if (eF && t > .85) return;
                                let {
                                    p: n,
                                    n: r
                                } = W(eB, eD, e, t), i = A(l, l, l, 8, 6);
                                i.translate(n.x + r.x * l * .4, n.y + r.y * l * .4, n.z + r.z * l * .4), a.add(i, null, {
                                    paint: eR,
                                    skin: 3
                                })
                            };
                            for (let t of [-.62, -.21, .21, .62]) e(t, .66, .058);
                            for (let t = 0; t < 5; t++) e(-Math.PI + 2 * Math.PI / 5 * (t + .5), 1.05, .076);
                            for (let t = 0; t < 7; t++) {
                                let a = -2.7 + .9 * t;
                                Math.abs(a) > 1.15 && e(a, .42, .07), Math.abs(a + .45) > 1.3 && e(a + .45, .02, .062)
                            }
                            eF && (eN -= .02);
                            break
                        }
                    case "Bun":
                        {
                            for (let e of (eY(.62, 0, -.8, -.004, 0), [-1, 1])) eW(.24 * e, .76, .14, .15, .05, .62 * e, .04),
                            eW(.66 * e, .56, .12, .12, .05, .28 * e),
                            eW(1.12 * e, .12, .17, .042, .03, .04 * e, 0, {
                                outline: !1
                            });
                            let e = A(.1, .092, .098, 14, 9);e.translate(0, ek.y + .245, ek.z - .11),
                            a.add(e, null, {
                                paint: eR,
                                skin: 3
                            });
                            let t = new l.O3Y(.075, .016, 5, 12);t.applyMatrix4(R(0, ek.y + .2, ek.z - .085, -1.1, 0, 0)),
                            a.add(t, null, {
                                paint: d,
                                skin: 3,
                                outline: !1
                            }),
                            eF && (eN -= .03);
                            break
                        }
                    case "Ponytail":
                        {
                            for (let e of (eY(.55, 0, -.8, -.003, 0), eO([-.5, -.17, .17, .5], .12, .14, e => .15 + .25 * e, .72), [-1, 1])) eW(1.16 * e, .14, .16, .045, .03, .05 * e, 0, {
                                outline: !1
                            });
                            let e = T([
                                [0, -.34],
                                [.032, -.31],
                                [.058, -.23],
                                [.068, -.14],
                                [.06, -.06],
                                [.036, -.01],
                                [0, .012]
                            ], 14);e.applyMatrix4(R(0, ek.y + .075, ek.z - .272, .42, 0, 0)),
                            a.add(e, null, {
                                paint: eR,
                                skin: 4
                            }),
                            eL(0, ek.y + .075, ek.z - .27, 1.15);
                            break
                        }
                    case "Long straight":
                    case "Long wavy":
                        {
                            let t = "Long wavy" === e.hairStyle;eY(t ? .6 : .55, -.05, -.8, 0, .03),
                            t ? eO([-.56, -.24, .1, .42], .13, .15, e => .5 + .12 * e, .74) : eO([-.56, -.28, 0, .28, .56], .125, .125, () => 0, .7, !0);
                            let l = [
                                [0, .515]
                            ];
                            for (let e of t ? [.53, .58, .635, .69, .745, .8, .87, .95, 1.04, 1.12] : [.53, .58, .68, .8, .9, 1, 1.08, 1.13]) {
                                let a = e < .56 ? .16 : e < .8 ? .2 + (e - .56) * .25 : e < 1 ? .26 + (e - .8) * .06 : .272 - (e - 1) * .6;
                                t && e < .95 && e > .56 && (a += .02 * Math.sin((e - .56) * 34)), l.push([a, e])
                            }
                            l.push([0, 1.17]);
                            let n = T(l, 20);
                            for (let e of (n.scale(1, 1, .55), n.translate(0, 0, ek.z - .125), a.add(n, null, {
                                    paint: eR,
                                    skin: 3
                                }), [-1, 1])) eG(e, .34, t);
                            break
                        }
                    case "Braid":
                        {
                            for (let e of (eY(.62, 0, -.8, -.004, 0), [-1, 1])) eW(.24 * e, .76, .14, .15, .05, .62 * e, .04),
                            eW(.64 * e, .56, .12, .12, .05, .26 * e),
                            eW(1.12 * e, .1, .14, .05, .03, .05 * e, 0, {
                                outline: !1
                            });
                            for (let e = 0; e < 6; e++) {
                                let t = A(.047 - .003 * e, .046, .037, 7, 4);
                                t.applyMatrix4(R(e % 2 ? .008 : -.008, ek.y - .055 - .066 * e, ek.z - .262 + .01 * e, 0, 0, e % 2 ? .42 : -.42)), a.add(t, null, {
                                    paint: 0 === e ? s : eR,
                                    skin: 4
                                })
                            }
                            let e = new l.qFE(.026, .05, 6);e.applyMatrix4(R(0, ek.y - .055 - .396 + .012, ek.z - .262 + .07, Math.PI, 0, 0)),
                            a.add(e, null, {
                                paint: s,
                                skin: 4,
                                outline: !1
                            }),
                            eL(0, ek.y - .055 - .3663, ek.z - .262 + .066, Math.PI / 2)
                        }
                }
                if ("Shirt" === e.top) {
                    for (let e of [-1, 1]) {
                        let t = Y(.062, .05, .014, 5);
                        t.applyMatrix4(R(.03 * e, .722, .088, -.62, .3 * e, .72 * e)), a.add(t, null, {
                            paint: f,
                            skin: 2
                        })
                    }
                    for (let e of [.64, .585, .53]) {
                        let t = A(.008, .008, .004, 5, 3);
                        t.translate(0, e, .124), a.add(t, null, {
                            paint: Z,
                            skin: 2,
                            outline: !1
                        })
                    }
                }
                if ("Kurti" === e.top) {
                    for (let e of [-1, 1]) {
                        let t = A(.0065, .05, .004, 4, 3);
                        t.applyMatrix4(R(.026 * e, .672, .117, -.32, 0, .52 * e)), a.add(t, null, {
                            paint: V,
                            skin: 2,
                            outline: !1
                        })
                    }
                    let e = A(.01, .01, .005, 6, 4);
                    e.translate(0, .63, .126), a.add(e, null, {
                        paint: V,
                        skin: 2,
                        outline: !1
                    })
                }
                if ("Kurta" === e.top) {
                    let e = new l.Ho_(.05, .055, .03, 12, 1, !0);
                    for (let t of (e.translate(0, .732, 0), a.add(e, null, {
                            paint: h,
                            skin: 2,
                            outline: !1
                        }), [.69, .655, .62])) {
                        let e = A(.007, .007, .004, 5, 3);
                        e.translate(0, t, .118), a.add(e, null, {
                            paint: V,
                            skin: 2,
                            outline: !1
                        })
                    }
                }
                if ("Hoodie" === e.top) {
                    let e = A(.16, .085, .085, 8, 5);
                    e.applyMatrix4(R(0, .735, -.105, -.35, 0, 0)), a.add(e, null, {
                        paint: h,
                        skin: 2
                    });
                    let t = A(.095, .042, .028, 8, 5);
                    for (let e of (t.translate(0, .475, .103), a.add(t, null, {
                            paint: h,
                            skin: 1
                        }), [-1, 1])) {
                        let t = new l.Ho_(.005, .005, .07, 4, 1);
                        t.translate(.034 * e, .66, .128), a.add(t, null, {
                            paint: Z,
                            skin: 2,
                            outline: !1
                        })
                    }
                }
                let eX = (e, t, a, l) => a * (.8 * Math.sqrt(Math.max(0, ed(t) ** 2 - e * e)) + l);
                if (j || Q) {
                    let t = new l.Ho_(.05, .056, .034, 14, 1, !0);
                    for (let e of (t.translate(0, .733, 0), a.add(t, null, {
                            paint: Q ? h : V,
                            skin: 2,
                            outline: !1,
                            trim: j ? () => [3, 0, 0] : void 0
                        }), j ? [.69, .645, .6, .555, .51] : [.68, .62, .56, .5])) {
                        let t = A(.009, .009, .005, 6, 4);
                        t.translate(0, e, eX(0, e, 1, .002)), a.add(t, null, {
                            paint: V,
                            skin: 2,
                            outline: !1
                        })
                    }
                    if (Q) {
                        let t = new l.iNn(.006, .31, .004);
                        t.translate(.016, .57, eX(.016, .57, 1, .001)), a.add(t, null, {
                            paint: h,
                            skin: 2,
                            outline: !1
                        });
                        let n = new l.qFE(.02, .03, 3);
                        n.translate(.075, .625, eX(.075, .625, 1, .003)), a.add(n, null, {
                            paint: "Red" === e.topColor ? V : z("#d23c4c"),
                            skin: 2,
                            outline: !1
                        })
                    }
                }
                if (E || H) {
                    let e = new l.O3Y(ed(ef - .012) + .004, .008, 4, 22);
                    e.applyMatrix4(R(0, ef - .012, 0, Math.PI / 2, 0, 0, 1, .82, 1)), a.add(e, null, {
                        paint: V,
                        skin: 2,
                        outline: !1,
                        trim: () => [3, 0, 0]
                    })
                }
                if (H) {
                    let {
                        geometry: e,
                        length: t
                    } = J([new l.Pq0(-.11, .455, eX(-.11, .455, 1, .012)), new l.Pq0(-.03, .55, eX(-.03, .55, 1, .014)), new l.Pq0(.07, .66, eX(.07, .66, 1, .014)), new l.Pq0(.12, .742, 0), new l.Pq0(.13, .6, eX(.13, .6, -1, -.014)), new l.Pq0(.14, .34, -.17)], .14, .014, 20);
                    a.add(e, null, {
                        paint: d,
                        skin: 2,
                        outline: !1,
                        trim: (e, a) => [4, a.x * t * 12, a.y]
                    })
                }
                if (F && !H && !E) {
                    let e = new l.O3Y(.15, .012, 4, 16);
                    e.applyMatrix4(R(0, .485, 0, Math.PI / 2, 0, 0, 1, .82, 1)), a.add(e, null, {
                        paint: f,
                        skin: 2,
                        outline: !1
                    })
                }
                let e_ = ek.y - .035;
                switch (x) {
                    case "Glasses":
                        {
                            let e = z("#3a2a2e");
                            for (let t of [-1, 1]) {
                                let n = new l.O3Y(.052, .0065, 4, 12);
                                n.applyMatrix4(R(.094 * t, e_, ek.z + .258, 0, .32 * t, 0)), a.add(n, null, {
                                    paint: e,
                                    skin: 3,
                                    outline: !1
                                });
                                let r = new l.iNn(.007, .007, .15);
                                r.applyMatrix4(R(.2 * t, e_ + .01, ek.z + .1, 0, -(.4 * t), 0)), a.add(r, null, {
                                    paint: e,
                                    skin: 3,
                                    outline: !1
                                })
                            }
                            let t = new l.Ho_(.005, .005, .05, 4, 1);t.applyMatrix4(R(0, e_ + .012, ek.z + .262, 0, 0, Math.PI / 2)),
                            a.add(t, null, {
                                paint: e,
                                skin: 3,
                                outline: !1
                            });
                            break
                        }
                    case "Bindi":
                        {
                            let {
                                p: e,
                                n: t
                            } = W(ek, ez, 0, .17),
                            l = A(.011, .014, .005, 6, 4);l.translate(e.x + .003 * t.x, e.y + .003 * t.y, e.z + .003 * t.z),
                            a.add(l, null, {
                                paint: z("#d8243c"),
                                skin: 3,
                                outline: !1
                            });
                            break
                        }
                    case "Earrings":
                        for (let e of [-1, 1]) {
                            let t = A(.011, .011, .011, 5, 3);
                            t.translate(.258 * e, ek.y - .07, .006), a.add(t, null, {
                                paint: V,
                                skin: 3,
                                outline: !1
                            });
                            let n = new l.qFE(.019, .03, 6, 1);
                            n.translate(.258 * e, ek.y - .095, .006), a.add(n, null, {
                                paint: V,
                                skin: 3,
                                outline: !1
                            })
                        }
                        break;
                    case "Cap":
                        {
                            let t = "White" === e.topColor ? z(_.D1.Navy) : d,
                                n = new l.Gu$(1, 14, 5, 0, 2 * Math.PI, 0, 1.42),
                                r = "Curly" === e.hairStyle ? .035 : "Side part" === e.hairStyle ? .012 : .006;n.scale(.292 + r, .282 + r, .292 + r),
                            n.rotateX(-.22),
                            n.translate(ek.x, ek.y + .02, ek.z - .012),
                            a.add(n, null, {
                                paint: t,
                                skin: 3
                            });
                            let i = A(.16, .013, .13, 10, 4);i.applyMatrix4(R(0, ek.y + .135 + .6 * r, ek.z + .235 + .5 * r, .28, 0, 0)),
                            a.add(i, null, {
                                paint: P(t, .82),
                                skin: 3
                            }),
                            eN = Math.max(eN, ek.y + .3 + r);
                            break
                        }
                    case "Flower in hair":
                        {
                            let {
                                p: t,
                                n
                            } = W(eB, eD, 1.2, .5),
                            r = t.clone().add(n.clone().multiplyScalar(.02)),
                            i = "Pink" === e.hairColor ? z("#fffaf2") : z("#ff6f8f"),
                            o = new l.Pq0(0, 1, 0),
                            s = new l.Pq0().crossVectors(o, n).normalize(),
                            u = new l.Pq0().crossVectors(n, s).normalize();
                            for (let e = 0; e < 5; e++) {
                                let t = e / 5 * Math.PI * 2,
                                    o = s.clone().multiplyScalar(Math.cos(t)).add(u.clone().multiplyScalar(Math.sin(t))),
                                    d = A(.03, .02, .012, 6, 4),
                                    h = O(new l.Pq0().copy(r).add(o.clone().multiplyScalar(.028)), n, 0, 0, 0);
                                d.applyMatrix4(R(0, 0, 0, 0, 0, t)), d.applyMatrix4(h), a.add(d, null, {
                                    paint: i,
                                    skin: 3,
                                    outline: !1
                                })
                            }
                            let d = A(.014, .014, .012, 6, 4);d.translate(r.x + .008 * n.x, r.y + .008 * n.y, r.z + .008 * n.z),
                            a.add(d, null, {
                                paint: z("#ffd34d"),
                                skin: 3,
                                outline: !1
                            });
                            break
                        }
                    case "Scarf":
                        {
                            let t = "Mustard" === e.topColor ? z(_.D1.Teal) : z(_.D1.Mustard),
                                n = new l.O3Y(.092, .034, 5, 12);n.applyMatrix4(R(0, .722, 0, Math.PI / 2, 0, 0, 1, .85, 1)),
                            a.add(n, null, {
                                paint: t,
                                skin: 2
                            });
                            let r = A(.034, .085, .018, 6, 4);r.applyMatrix4(R(.07, .63, .122, .12, 0, .12)),
                            a.add(r, null, {
                                paint: P(t, .92),
                                skin: 2
                            });
                            break
                        }
                    case "Dupatta":
                        {
                            let t = "White" === e.topColor ? z(_.D1.Rose) : "Mustard" === e.topColor ? z(_.D1.Plum) : S(d, z("#fff6ec"), .5),
                                {
                                    geometry: n,
                                    length: r
                                } = J([new l.Pq0(.12, .3, -.17), new l.Pq0(.125, .52, eX(.125, .52, -1, -.02)), new l.Pq0(.13, .745, -.01), new l.Pq0(.12, .62, eX(.12, .62, 1, .02)), new l.Pq0(.05, .5, eX(.05, .5, 1, .026)), new l.Pq0(-.05, .5, eX(-.05, .5, 1, .026)), new l.Pq0(-.12, .62, eX(-.12, .62, 1, .02)), new l.Pq0(-.13, .745, -.01), new l.Pq0(-.125, .52, eX(-.125, .52, -1, -.02)), new l.Pq0(-.12, .3, -.17)], .075, .012, 20);a.add(n, null, {
                                paint: t,
                                skin: 2,
                                outline: !1,
                                trim: (e, t) => [4, t.x * r * 14, t.y]
                            })
                        }
                }
                let eE = a.build(t),
                    {
                        width: eU,
                        length: eZ,
                        chin: eV
                    } = C.face,
                    e$ = 1 !== eU || 1 !== eZ || 0 !== eV,
                    eK = (e, t) => {
                        if (t <= 0) return;
                        let a = e.y - ek.y,
                            l = a < 0 ? Math.min(1, -a / ez.y) : 0,
                            n = Math.max(0, Math.min(1, (e.z - ek.z + .12) / .2)),
                            r = ek.x + (e.x - ek.x) * eU * (1 - eV * l * l * n),
                            i = ek.y + a * eZ,
                            o = ek.z + (e.z - ek.z) * (1 - .4 * eV * l * l * n);
                        e.set(e.x + (r - e.x) * t, e.y + (i - e.y) * t, e.z + (o - e.z) * t)
                    };
                if (e$) {
                    let e = new l.Pq0;
                    for (let t of [eE.body, eE.outline]) {
                        if (!t) continue;
                        let a = t.attributes.position,
                            l = t.attributes.skinIndex,
                            n = t.attributes.skinWeight;
                        for (let t = 0; t < a.count; t++) {
                            let r = 0;
                            for (let e = 0; e < 4; e++) {
                                let a = l.getComponent(t, e);
                                (3 === a || 4 === a) && (r += n.getComponent(t, e))
                            }
                            r <= 0 || (e.fromBufferAttribute(a, t), eK(e, r), a.setXYZ(t, e.x, e.y, e.z))
                        }
                        a.needsUpdate = !0, t.computeBoundingSphere()
                    }
                    eN = ek.y + (eN - ek.y) * eZ
                }
                let eJ = U[3],
                    ej = new l.Pq0(ek.x - eJ[0], ek.y - eJ[1], ek.z - eJ[2]),
                    eQ = S(s, z("#2a1a1e"), "Grey" === e.hairColor || "Pink" === e.hairColor || "Honey" === e.hairColor ? .25 : .1),
                    e0 = k ? 4 : _.Co[e.hairStyle],
                    [e1, e2, e5] = k ? [.09, .1, -.032] : [.096, .112, -.035],
                    [e4, e6, e3, e8] = k ? [.088, .06, .05, .02] : [.078, .045, .05, .05],
                    e7 = w([{
                        x: .092,
                        y: e5,
                        w: e1,
                        h: e2,
                        mirror: !1,
                        cell: "eye0",
                        lift: .0028
                    }, {
                        x: -.092,
                        y: e5,
                        w: e1,
                        h: e2,
                        mirror: !0,
                        cell: "eye0",
                        lift: .0028
                    }, {
                        x: .096,
                        y: e3,
                        w: e4,
                        h: e6,
                        mirror: !1,
                        cell: "browNormal",
                        lift: .0034,
                        tint: eQ,
                        roll: -e8
                    }, {
                        x: -.096,
                        y: e3,
                        w: e4,
                        h: e6,
                        mirror: !0,
                        cell: "browNormal",
                        lift: .0034,
                        tint: eQ,
                        roll: e8
                    }, {
                        x: 0,
                        y: -.128,
                        w: .07,
                        h: .058,
                        mirror: !1,
                        cell: "mouthSmile",
                        lift: .0025
                    }, {
                        x: .15,
                        y: -.098,
                        w: .09,
                        h: .055,
                        mirror: !1,
                        cell: "blush",
                        lift: .0018,
                        alpha: .6
                    }, {
                        x: -.15,
                        y: -.098,
                        w: .09,
                        h: .055,
                        mirror: !0,
                        cell: "blush",
                        lift: .0018,
                        alpha: .6
                    }, {
                        x: 0,
                        y: -.082,
                        w: .052,
                        h: .04,
                        mirror: !1,
                        cell: "nose",
                        lift: .0042,
                        alpha: .85
                    }], ej, ez);
                if (e$) {
                    let e = e7.geometry.attributes.position,
                        t = new l.Pq0;
                    for (let a = 0; a < e.count; a++) t.fromBufferAttribute(e, a), t.x += eJ[0], t.y += eJ[1], t.z += eJ[2], eK(t, 1), e.setXYZ(a, t.x - eJ[0], t.y - eJ[1], t.z - eJ[2]);
                    e.needsUpdate = !0
                }
                let e9 = W(ek, ez, 0, .3);
                e$ && eK(e9.p, 1);
                let te = {
                        p: e9.p.clone().sub(new l.Pq0(eJ[0], eJ[1], eJ[2])),
                        n: e9.n.clone()
                    },
                    tt = n.tunic ? "Maxi dress" === e.top || H || E ? .1 : .08 : 0,
                    ta = v ? "Lehenga" === e.bottom ? .12 : .06 : 0;
                return {
                    body: eE.body,
                    outline: eE.outline,
                    face: e7,
                    height: (eJ[1] + (eN - eJ[1]) * C.head) * C.body,
                    armSpread: .12 + Math.max(tt, ta) + ("Hoodie" === e.top ? .03 : .02 * ("Sweater" === e.top)),
                    eyeStyle: e0,
                    longSkirt: v && "Lehenga" === e.bottom || "Maxi dress" === e.top || H || E,
                    skirted: v || n.tunic,
                    bodyScale: C.body,
                    headScale: C.head,
                    shoulder: I,
                    forehead: te
                }
            }
            let Q = new Set(["walk", "holdHandsWalk", "umbrellaHold"]);

            function ee(e, t, a, l, n) {
                e[3 * t] = a, e[3 * t + 1] = l, e[3 * t + 2] = n
            }

            function et(e, t, a, l, n) {
                e[3 * t] = (e[3 * t] ? ? 0) + a, e[3 * t + 1] = (e[3 * t + 1] ? ? 0) + l, e[3 * t + 2] = (e[3 * t + 2] ? ? 0) + n
            }

            function ea(e, t) {
                e.fill(0), e[45] = 1;
                let a = t.t;
                ee(e, 6, .02, 0, -t.spread), ee(e, 8, .02, 0, t.spread), ee(e, 7, -.14, 0, 0), ee(e, 9, -.14, 0, 0);
                let l = Math.sin(2.1 * a);
                if (et(e, 2, .012 * l, 0, 0), et(e, 6, 0, 0, -(.012 * l)), et(e, 8, 0, 0, .012 * l), et(e, 3, -(.008 * l), 0, 0), t.reduced) return;
                let n = Math.sin(.45 * a);
                e[42] = .011 * n, et(e, 1, 0, 0, .03 * n), et(e, 2, 0, 0, -(.026 * n)), et(e, 10, 0, 0, -(.03 * n)), et(e, 12, 0, 0, -(.03 * n)), et(e, 3, .02 * Math.sin(.7 * a), .1 * Math.sin(.31 * a), .045 * Math.sin(.6 * a + 1));
                let r = .03 * Math.sin(.8 * a);
                et(e, 6, r, 0, 0), et(e, 8, -r, 0, 0), et(e, 4, .03 * Math.sin(.9 * a), 0, .04 * Math.sin(.7 * a))
            }

            function el(e, t) {
                let a = t.walk;
                if (a <= .001) return;
                let l = Math.min(.62, .22 + .28 * t.speed) * (t.longSkirt ? .62 : 1) * a,
                    n = Math.sin(t.phase),
                    r = Math.cos(t.phase);
                for (let t of [1, 2, 10, 12]) e[3 * t + 2] = (e[3 * t + 2] ? ? 0) * (1 - a);
                e[42] = (e[42] ? ? 0) * (1 - a), et(e, 10, -n * l, 0, 0), et(e, 12, n * l, 0, 0), et(e, 11, Math.max(0, r) * l * 1.5 + .05 * a, 0, 0), et(e, 13, Math.max(0, -r) * l * 1.5 + .05 * a, 0, 0), e[43] = (e[43] ? ? 0) + (-.012 + .024 * Math.abs(r)) * l, et(e, 1, 0, .16 * n * l, .03 * r * l), et(e, 2, (.05 + .04 * t.speed) * a, -(.24 * n) * l, 0), et(e, 3, -.03 * a, .1 * n * l, 0), et(e, 6, n * l * .85, 0, 0), et(e, 8, -n * l * .85, 0, 0), et(e, 7, -(.12 + .4 * Math.max(0, -n)) * l, 0, 0), et(e, 9, -(.12 + .4 * Math.max(0, n)) * l, 0, 0), et(e, 5, .06 * t.speed * a, 0, .05 * n * l), et(e, 4, .12 * t.speed * a + .06 * Math.sin(2 * t.phase) * l, 0, .1 * n * l)
            }
            let en = (e, t) => {
                let a = Math.max(0, Math.min(1, e / t));
                return a * a * (3 - 2 * a)
            };

            function er(e, t, a) {
                switch (e) {
                    case "walk":
                        ea(a, t), el(a, t);
                        return;
                    case "holdHandsWalk":
                        let l, n;
                        ea(a, t), el(a, t), l = "right" === t.handSide, n = .05 * Math.sin(t.phase) * t.walk * (l ? 1 : -1), ee(a, l ? 6 : 8, -.1 + n, 0, .47 * (l ? -1 : 1)), ee(a, l ? 7 : 9, -.1, 0, 0), et(a, 3, 0, 0, l ? .05 : -.05), et(a, 2, 0, 0, l ? .02 : -.02);
                        return;
                    case "umbrellaHold":
                        ea(a, t), el(a, t), ee(a, 6, -.5, 0, -.62), ee(a, 7, -1.75, 0, .35);
                        return;
                    case "sit":
                        let r, i;
                        ea(a, { ...t,
                            reduced: !0
                        }), r = t.seat, a[43] = -.33, a[42] = 0, i = t.reduced ? 0 : .16 * Math.sin(2.3 * t.t) * r, ee(a, 10, -1.75 + .3 * r, 0, .04), ee(a, 12, -1.75 + .3 * r, 0, -.04), ee(a, 11, .55 + .9 * r + i, 0, 0), ee(a, 13, .55 + .9 * r - i, 0, 0), et(a, 2, .07, 0, 0), ee(a, 6, -.42, 0, -(.5 * t.spread)), ee(a, 8, -.42, 0, .5 * t.spread), ee(a, 7, -.8, 0, .12), ee(a, 9, -.8, 0, -.12), t.skirted && (ee(a, 5, -1.12, 0, 0), a[45] = .84), t.reduced || et(a, 3, 0, .12 * Math.sin(.4 * t.t), .05 * Math.sin(.55 * t.t));
                        return;
                    case "hug":
                        ea(a, { ...t,
                            reduced: !0
                        }), et(a, 2, .13, 0, 0), ee(a, 8, -1.1, 0, .36), ee(a, 9, 0, 0, -1.3), ee(a, 6, -1.1, 0, -.36), ee(a, 7, 0, 0, 1.3), et(a, 3, .06, .28, .22), t.reduced || et(a, 1, 0, .04 * Math.sin(1.2 * t.t), 0);
                        return;
                    case "wave":
                        let o, s, u;
                        ea(a, t), s = (o = "right" === t.handSide) ? 1 : -1, u = .42 * Math.sin(9 * t.t), ee(a, o ? 8 : 6, -.25, 0, 2.45 * s), ee(a, o ? 9 : 7, -.1, 0, s * (-.15 + .6 * u)), et(a, 3, 0, 0, -(.1 * s)), et(a, 2, 0, 0, -(.04 * s)), t.reduced || (a[43] = (a[43] ? ? 0) + .008 * Math.abs(Math.sin(4.5 * t.t)));
                        return;
                    case "swayTogether":
                        let d, h, f;
                        ea(a, { ...t,
                            reduced: !0
                        }), h = (d = "right" === t.handSide) ? 1 : -1, f = t.reduced ? .015 : .05, et(a, 0, 0, 0, Math.sin(1.3 * t.t) * f), ee(a, d ? 6 : 8, .18, 0, -(.62 * h)), ee(a, d ? 7 : 9, .9, 0, .25 * h), et(a, 3, .04, .12 * h, .2 * h), et(a, 2, 0, 0, .05 * h);
                        return;
                    case "aarti":
                        let p, c;
                        ea(a, { ...t,
                            reduced: !0
                        }), p = en(t.t, .5), ee(a, 8, (-.95 + .16 * Math.sin(c = t.reduced ? 0 : 2.2 * t.t)) * p, 0, (.18 + .13 * Math.cos(c)) * p + t.spread * (1 - p)), ee(a, 9, -1.05 * p, 0, -.35 * p), ee(a, 6, -.55 * p, 0, -.12 * p - t.spread * (1 - p)), ee(a, 7, -1.15 * p, 0, .55 * p), et(a, 2, .08 * p, 0, 0), et(a, 3, .12 * p, 0, 0);
                        return;
                    case "tilak":
                        let y, m;
                        ea(a, { ...t,
                            reduced: !0
                        }), y = en(t.t, .6), m = t.reduced ? 1 : en(t.t - .9, .6), ee(a, 6, -2.05 * y, .1 * y, -.06 * y - t.spread * (1 - y)), ee(a, 7, (-.1 - .3 * m) * y, 0, .1 * y), ee(a, 8, -.45 * y, 0, .12 * y + t.spread * (1 - y)), ee(a, 9, -1.3 * y, 0, -.3 * y), et(a, 2, .16 * y, .06 * y, 0), et(a, 3, -.04 * y, 0, 0);
                        return;
                    case "sideHug":
                        let b;
                        ea(a, t), b = en(t.t, .7), "right" === t.handSide ? (ee(a, 6, -.25 * b, 0, -1.35 * b - t.spread * (1 - b)), ee(a, 7, -.35 * b, 0, 1.25 * b), et(a, 3, 0, -.08 * b, -.16 * b), et(a, 2, 0, 0, -.05 * b)) : (ee(a, 8, .25 * b, 0, .42 * b + t.spread * (1 - b)), ee(a, 9, -.2 * b, 0, -1.1 * b), et(a, 3, 0, .08 * b, .18 * b), et(a, 2, 0, 0, .05 * b));
                        return;
                    case "reachUp":
                        let M;
                        ea(a, { ...t,
                            reduced: !0
                        }), M = en(t.t, .45), ee(a, 6, -.3 * M, 0, (-2.65 + (t.reduced ? 0 : .14 * Math.sin(7 * Math.max(0, t.t - .45)) * (1 - en(t.t - 1.6, .8)))) * M - t.spread * (1 - M)), ee(a, 7, -.25 * M, 0, .1 * M), et(a, 3, -.3 * M, 0, 0), et(a, 2, -.04 * M, 0, .04 * M);
                        return;
                    case "reach":
                        let w, g, v;
                        ea(a, { ...t,
                            reduced: !0
                        }), w = en(t.t, .5), ee(a, 6, (v = -.85 - .55 * (g = t.reduced ? 1 : en(t.t - .6, .7))) * w, 0, -.08 * w - t.spread * (1 - w)), ee(a, 8, v * w, 0, .08 * w + t.spread * (1 - w)), ee(a, 7, -.45 * w, 0, .15 * w), ee(a, 9, -.45 * w, 0, -.15 * w), et(a, 2, (.32 - .18 * g) * w, 0, 0), et(a, 3, .1 * w, 0, 0);
                        return;
                    case "clap":
                        let x, k;
                        ea(a, { ...t,
                            reduced: !0
                        }), x = en(t.t, .3), ee(a, 6, -.75 * x, 0, (-.12 - .2 * (k = t.reduced ? .5 : Math.abs(Math.sin(8 * t.t)))) * x - t.spread * (1 - x)), ee(a, 8, -.75 * x, 0, (.12 + .2 * k) * x + t.spread * (1 - x)), ee(a, 7, -1 * x, 0, .75 * x), ee(a, 9, -1 * x, 0, -.75 * x), et(a, 3, -.05 * x, 0, 0), t.reduced || (a[43] = (a[43] ? ? 0) + .006 * Math.abs(Math.sin(4 * t.t)));
                        return;
                    default:
                        ea(a, t)
                }
            }
            let ei = new Set(["idle", "walk", "holdHandsWalk", "umbrellaHold", "sit", "hug", "wave", "swayTogether", "aarti", "tilak", "sideHug", "reachUp", "reach", "clap"]),
                eo = new Set(["happy", "love", "shy", "surprised", "sleepy", "laugh", "calm"]);

            function es(e, t) {
                let a = t ? .handSide === "left" ? "left" : "right",
                    r = "left" === a ? "b" : "a",
                    i = !!t ? .reducedMotion,
                    o = t ? .quality === "low" ? "low" : "high",
                    s = (0, _.gM)(e, r),
                    u = JSON.stringify(s),
                    d = new l.YJl;
                d.name = "person";
                let h = x(),
                    f = m(t ? .doc),
                    p = b(f);
                p && (h.face.map = p);
                let c = [];
                for (let e = 0; e < 14; e++) {
                    let t = new l.$Kf,
                        a = U[e],
                        n = E[e],
                        r = n >= 0 ? U[n] : [0, 0, 0];
                    t.position.set(a[0] - r[0], a[1] - r[1], a[2] - r[2]), c.push(t), n >= 0 && c[n].add(t)
                }
                let y = c[0];
                d.add(y), d.updateMatrixWorld(!0);
                let w = new l.EAD(c),
                    v = c.map(e => e.position.clone()),
                    k = j(s, !0);

                function z() {
                    c[0].scale.setScalar(k.bodyScale), c[3].scale.setScalar(k.headScale), c[6].position.x = v[6].x - k.shoulder, c[8].position.x = v[8].x + k.shoulder
                }
                z();
                let S = new l.I46(k.body, h.body),
                    P = new l.I46(k.outline ? ? k.body, h.outline),
                    C = new l.iyt(new l.Pq0(0, .7, 0), 1.05);
                for (let e of [S, P]) e.bind(w, new l.kn4), e.boundingSphere = C.clone(), d.add(e);
                S.name = "person-body", S.userData.castOnly = !0, P.name = "person-ink", P.userData.noShadow = !0;
                let q = new l.eaF(k.face.geometry, h.face);
                q.name = "person-face", q.userData.noShadow = !0, q.renderOrder = 1, c[3].add(q);
                let T = new l.eaF(new l.tcD(.3, 20).rotateX(-Math.PI / 2), h.blob);
                T.position.y = .004, T.name = "person-blob", T.userData.noShadow = !0, T.renderOrder = -1, d.add(T);
                let A = {
                    right: new l.YJl,
                    left: new l.YJl
                };
                A.right.position.set(0, -.188, .004), A.left.position.set(0, -.188, .004), c[7].add(A.right), c[9].add(A.left);
                let I = null;

                function F() {
                    if (!I) return;
                    let {
                        p: e,
                        n: t
                    } = k.forehead;
                    I.position.copy(e).addScaledVector(t, .002), I.lookAt(I.position.clone().add(t))
                }

                function B() {
                    P.visible = "high" === o, T.visible = "low" === o, q.visible = !!p
                }
                B();
                let D = "happy",
                    H = 2 + 3 * Math.random(),
                    R = 0;

                function Y() {
                    let e = g(D, k.eyeStyle),
                        t = R > 0 && e.blinks ? "eyeBlink" : e.eye;
                    k.face.setCell(0, t), k.face.setCell(1, t), k.face.setCell(2, e.brow), k.face.setCell(3, e.brow), k.face.setCell(4, e.mouth), k.face.setAlpha(5, .9 * e.blush), k.face.setAlpha(6, .9 * e.blush)
                }
                Y();
                let W = {
                        clip: "idle",
                        t: 10 * Math.random()
                    },
                    O = null,
                    G = 0,
                    L = .25,
                    N = 0,
                    X = 0,
                    Z = 0,
                    V = new Float32Array(46),
                    $ = new Float32Array(46),
                    K = new Float32Array(46),
                    J = {
                        t: 0,
                        phase: 0,
                        speed: 0,
                        walk: 0,
                        handSide: a,
                        spread: k.armSpread,
                        longSkirt: k.longSkirt,
                        skirted: k.skirted,
                        seat: 0,
                        reduced: i
                    },
                    ee = null,
                    et = 0,
                    ea = 0,
                    el = new l.Pq0,
                    en = new l.Pq0,
                    es = new l.PTz;

                function eu(e) {
                    let t, a = Q.has(W.clip) || !!O && Q.has(O.clip),
                        l = Q.has(W.clip) && N > .05;
                    if (Z += (!!l - Z) * (1 - Math.exp(-(7 * e))), a && N > .05 && (X += e * Math.PI * 2 * (t = Math.min(.42, Math.max(.2, .22 + .12 * (n = N))) * (k.longSkirt ? .8 : 1), n / (2 * t))), W.t += e, O && (O.t += e), G += e, O && G >= L && (O = null), "sit" === W.clip && (d.getWorldPosition(en), J.seat = Math.max(0, Math.min(1, (en.y - .06) / .16))), J.phase = X, J.speed = N, J.walk = Z, J.t = W.t, er(W.clip, J, V), O) {
                        J.t = O.t, er(O.clip, J, $);
                        let e = G / L;
                        var n, r = e * e * (3 - 2 * e);
                        for (let e = 0; e < 46; e++) K[e] = ($[e] ? ? 0) + ((V[e] ? ? 0) - ($[e] ? ? 0)) * r
                    } else K.set(V);
                    let i = 0,
                        o = 0;
                    if (ee) {
                        el.copy(ee), d.worldToLocal(el);
                        let e = .99 + K[43],
                            t = Math.hypot(el.x, el.z),
                            a = Math.atan2(el.x, el.z);
                        2 > Math.abs(a) && (i = Math.max(-1, Math.min(1, a)), o = Math.max(-.35, Math.min(.4, Math.atan2(e - el.y, Math.max(.2, t)))))
                    }
                    let s = "hug" === W.clip ? .3 : "sit" === W.clip ? .8 : 1,
                        u = 1 - Math.exp(-(6 * e));
                    et += (i * s - et) * u, ea += (o * s - ea) * u, K[10] = (K[10] ? ? 0) + .7 * et, K[7] = (K[7] ? ? 0) + .3 * et, K[9] = (K[9] ? ? 0) + .8 * ea;
                    for (let e = 0; e < 14; e++) c[e].rotation.set(K[3 * e], K[3 * e + 1], K[3 * e + 2]);
                    let h = c[1],
                        f = v[1];
                    for (let [e, t, a] of (h.position.set(f.x + K[42], f.y + K[43], f.z + K[44]), c[5].scale.set(1, K[45], 1), [
                            ["right", 6, 7],
                            ["left", 8, 9]
                        ])) es.copy(c[0].quaternion).multiply(h.quaternion).multiply(c[2].quaternion).multiply(c[t].quaternion).multiply(c[a].quaternion), A[e].quaternion.copy(es.invert());
                    let p = g(D, k.eyeStyle);
                    R > 0 ? (R -= e) <= 0 && Y() : p.blinks && (H -= e) <= 0 && (R = "sleepy" === D ? .4 : .13, H = 3 + 3 * Math.random(), Y())
                }
                return eu(0), {
                    object: d,
                    get height() {
                        return k.height
                    },
                    setConfig(e) {
                        let t = (0, _.gM)(e, r),
                            a = JSON.stringify(t);
                        if (a !== u) {
                            let e;
                            s = t, u = a, e = k, S.geometry = (k = j(s, !0)).body, P.geometry = k.outline ? ? k.body, q.geometry = k.face.geometry, e.body.dispose(), e.outline ? .dispose(), e.face.geometry.dispose(), J.spread = k.armSpread, J.longSkirt = k.longSkirt, J.skirted = k.skirted, z(), Y(), F()
                        }
                    },
                    play(e, t) {
                        let a = ei.has(e) ? e : "idle";
                        if (t ? .speed !== void 0 && Number.isFinite(t.speed) && (N = Math.max(0, t.speed)), a === W.clip) return;
                        let l = t ? .fade ? ? .25;
                        O = l > 0 ? W : null, W = {
                            clip: a,
                            t: 0
                        }, G = 0, L = Math.max(1e-4, l), Q.has(a) || t ? .speed !== void 0 || (N = 0)
                    },
                    lookAt(e) {
                        ee = e ? (ee ? ? new l.Pq0).copy(e) : null
                    },
                    setExpression(e) {
                        D = eo.has(e) ? e : "happy", R = 0, Y()
                    },
                    hand: e => "left" === e ? A.left : A.right,
                    setMark(e) {
                        (e || I) && (I || (I = function() {
                            let e = [],
                                t = new l.Gu$(1, 8, 6);
                            for (let [a, n, r] of (t.scale(.0095, .03, .004), e.push([t, "#c3122c"]), [
                                    [-.006, .036, .4],
                                    [.007, .04, -.5],
                                    [0, .05, .1]
                                ])) {
                                let t = new l.Gu$(1, 5, 4);
                                t.scale(.0045, .0075, .0035), t.rotateZ(r), t.translate(a, n - .02, .002), e.push([t, "#fff8ea"])
                            }
                            let a = e.map(([e, t]) => {
                                    let a = new l.Q1f(t),
                                        n = e.attributes.position.count,
                                        r = new Float32Array(3 * n);
                                    for (let e = 0; e < n; e++) r.set([a.r, a.g, a.b], 3 * e);
                                    return e.deleteAttribute("uv"), e.setAttribute("color", new l.THS(r, 3)), e
                                }),
                                r = (0, n.pP)(a, !1);
                            for (let e of a) e.dispose();
                            let i = new l.Df({
                                    vertexColors: !0,
                                    gradientMap: h.ramp
                                }),
                                o = new l.eaF(r, i);
                            return o.name = "person-tilak", o.userData.noShadow = !0, c[3].add(o), o
                        }(), F()), I.visible = e)
                    },
                    update(e) {
                        eu(Number.isFinite(e) ? Math.min(.1, Math.max(0, e)) : 0)
                    },
                    setQuality(e) {
                        o = "low" === e ? "low" : "high", B()
                    },
                    dispose() {
                        d.removeFromParent(), k.body.dispose(), k.outline ? .dispose(), k.face.geometry.dispose(), T.geometry.dispose(), I && (I.geometry.dispose(), I.material.dispose()), w.dispose(), h.face.map = null, h.dispose(), M(f, p)
                    }
                }
            }
            let eu = `
attribute vec2 aCorner; attribute vec3 aOffset; attribute float aDelay;
uniform float uT; uniform float uSize;
varying vec2 vUv; varying float vA;
void main(){
  float life = clamp((uT - aDelay) / 1.5, 0.0, 1.0);
  float on = step(0.0001, life) * (1.0 - step(0.9999, life));
  vec3 p = aOffset * (0.35 + life) + vec3(0.0, life * 0.42, 0.0);
  p.x += sin(life * 9.0 + aDelay * 20.0) * 0.03;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  float size = uSize * (0.6 + 0.4 * sin(min(life * 6.0, 1.5708))) * on;
  mv.xy += aCorner * size;
  vUv = aCorner + 0.5;
  vA = (1.0 - smoothstep(0.65, 1.0, life)) * on;
  gl_Position = projectionMatrix * mv;
}`,
                ed = `
varying vec2 vUv; varying float vA;
float dot2(vec2 v){ return dot(v, v); }
float sdHeart(vec2 p){
  p.x = abs(p.x);
  if (p.y + p.x > 1.0) return sqrt(dot2(p - vec2(0.25, 0.75))) - sqrt(2.0) / 4.0;
  return sqrt(min(dot2(p - vec2(0.0, 1.0)), dot2(p - 0.5 * max(p.x + p.y, 0.0)))) * sign(p.x - p.y);
}
float sdPaw(vec2 p){
  float d = length((p - vec2(0.0, 0.32)) * vec2(1.0, 1.25)) - 0.3;
  d = min(d, length(p - vec2(-0.34, 0.72)) - 0.11);
  d = min(d, length(p - vec2(-0.12, 0.86)) - 0.12);
  d = min(d, length(p - vec2(0.12, 0.86)) - 0.12);
  d = min(d, length(p - vec2(0.34, 0.72)) - 0.11);
  return d;
}
void main(){
  vec2 p = (vUv - vec2(0.5, 0.18)) * 1.45;
  #ifdef PAWS
  float d = sdPaw(p);
  #else
  float d = sdHeart(p);
  #endif
  float a = smoothstep(0.03, -0.01, d) * vA;
  if (a < 0.01) discard;
  vec3 c = mix(vec3(1.0, 0.36, 0.52), vec3(1.0, 0.62, 0.72), smoothstep(-0.2, 0.0, d));
  float shine = smoothstep(0.09, 0.0, length(p - vec2(-0.22, 0.72)));
  c = mix(c, vec3(1.0), shine * 0.8);
  gl_FragColor = vec4(c, a);
  #include <colorspace_fragment>
}`,
                eh = 1,
                ef = 2,
                ep = 3,
                ec = 4,
                ey = 5,
                em = 6,
                eb = 7,
                eM = 8,
                ew = 9,
                eg = 10,
                ev = [-1, 0, 1, 2, 2, 1, 5, 1, 1, 1, 1];

            function ex(e, t) {
                let {
                    kind: a,
                    spec: n
                } = e, r = function(e, t) {
                    let a = t.size;
                    if ("Bunny" === e) {
                        let e = new l.Pq0(0, .14, -.01),
                            t = new l.Pq0(.135, .13, .16);
                        return {
                            bodyC: e,
                            bodyR: t,
                            headC: new l.Pq0(0, .29, .1),
                            headR: new l.Pq0(.122, .112, .115),
                            legLen: .07,
                            height: .6,
                            rest: [
                                [0, 0, 0],
                                [0, .14, -.01],
                                [0, .22, .08],
                                [.05, .38, .09],
                                [-.05, .38, .09],
                                [0, .12, -.16],
                                [0, .12, -.2],
                                [.055, .08, .1],
                                [-.055, .08, .1],
                                [.085, .05, -.06],
                                [-.085, .05, -.06]
                            ]
                        }
                    }
                    let n = "Dog" === e,
                        r = (n ? .15 : .13) * a,
                        i = r + (n ? .08 : .075) * a,
                        o = new l.Pq0((n ? .125 : .112) * a, (n ? .115 : .105) * a, (n ? .205 : .19) * a),
                        s = new l.Pq0(0, i, 0),
                        u = new l.Pq0((n ? .14 : .148) * a, (n ? .128 : .132) * a, .13 * a),
                        d = new l.Pq0(0, i + .135 * a, .82 * o.z),
                        h = [0, i + .06 * a, .62 * o.z],
                        f = d.y + .72 * u.y;
                    return {
                        bodyC: s,
                        bodyR: o,
                        headC: d,
                        headR: u,
                        legLen: r,
                        height: f + .08 * a,
                        rest: [
                            [0, 0, 0],
                            [0, i, 0], h, [.55 * u.x, f, d.z - .01],
                            [-(.55 * u.x), f, d.z - .01],
                            [0, i + .35 * o.y, -(.9 * o.z)],
                            [0, i + .35 * o.y + .1 * a, -(.9 * o.z) - .06 * a],
                            [.55 * o.x, r + .02, .55 * o.z],
                            [-(.55 * o.x), r + .02, .55 * o.z],
                            [.55 * o.x, r + .02, -(.55 * o.z)],
                            [-(.55 * o.x), r + .02, -(.55 * o.z)]
                        ]
                    }
                }(a, n), i = new q, o = function(e, t, a) {
                    let l = z(t.base),
                        n = z(t.accent),
                        r = z(t.third),
                        i = z(t.belly),
                        o = z("Bunny" === e || "cat" === t.ears ? "#f6a9b6" : "#e9a99a"),
                        {
                            headC: s,
                            headR: u,
                            bodyC: d
                        } = a;
                    return (h, f, p) => {
                        if ("inner" === h) return o;
                        let c = (f.z - s.z) / u.z,
                            y = f.y < s.y - .15 * u.y && c > .45;
                        switch (t.pattern) {
                            case "tabby":
                                if ("muzzle" === h || "leg" === h && f.y < .045 || "body" === h && p.y < -.35 || "head" === h && y) return i;
                                if ("head" === h && p.y > .45 && Math.sin(75 * f.x) > .35 || "body" === h && p.y > -.25 && Math.sin((f.z - d.z) * 52) > .3 || "tail" === h && Math.sin(45 * f.y + 45 * f.z) > .3 || "leg" === h && Math.sin(70 * f.y) > .5) return n;
                                return l;
                            case "calico":
                                {
                                    if ("muzzle" === h) return i;
                                    if ("ear" === h) return f.x > 0 ? n : r;
                                    let e = Math.sin(23 * f.x + 1.3) * Math.sin(17 * f.z + .4) + .6 * Math.sin(19 * f.y + 2.1);
                                    if ("head" === h) {
                                        if (f.x > .02 && f.y > s.y - .02 && !y) return n;
                                        if (f.x < -.04 && f.y > s.y + .02) return r;
                                        return l
                                    }
                                    if ("tail" === h) return f.y > d.y + .15 ? r : n;
                                    if (e > .55) return n;
                                    if (e < -.7) return r;
                                    return l
                                }
                            case "points":
                                if ("ear" === h || "muzzle" === h) return n;
                                if ("head" === h) {
                                    let e = f.x / u.x,
                                        t = (f.y - (s.y - .25 * u.y)) / u.y,
                                        a = c - .25 - .6 * Math.sqrt(e * e + t * t);
                                    return a > .35 ? n : a > .1 ? S(l, n, .5) : l
                                }
                                if ("leg" === h) return f.y < .6 * a.legLen ? n : S(l, n, .35);
                                if ("tail" === h) return S(l, n, Math.min(1, .4 + 6 * Math.max(0, f.y - d.y)));
                                return p.y < -.4 ? i : l;
                            case "mask":
                                if ("muzzle" === h || "ear" === h) return n;
                                if ("head" === h && c > .55 && f.y < s.y + .01 && Math.abs(f.x) < .55 * u.x) return S(n, l, .25);
                                if ("body" === h && p.y < -.4) return i;
                                return l;
                            case "urajiro":
                                if ("muzzle" === h || "head" === h && y || "head" === h && c > .55 && f.y > s.y + .02 && Math.abs(f.x) > .03 && .065 > Math.abs(f.x) || "body" === h && (p.y < -.2 || p.z > .55 && f.y < d.y + .04) || "leg" === h && (f.y < .06 || p.z < -.5) || "tail" === h && p.y < -.1) return n;
                                return l;
                            case "blaze":
                                if ("muzzle" === h) return S(l, n, .45);
                                if ("body" === h && p.z > .45 && f.y < d.y + .05 || "leg" === h && f.y < .05 || "tail" === h && f.y > d.y + .18) return n;
                                if ("body" === h && p.y < -.4) return i;
                                return l;
                            default:
                                if ("muzzle" === h) return "Dog" === e ? S(l, i, .6) : i;
                                if ("body" === h && p.y < -.45 || "head" === h && y && "Cat" !== e) return i;
                                if ("Dog" === e && "ear" === h) return P(l, .88);
                                return l
                        }
                    }
                }(a, n, r), s = e => (t, a) => o(e, t, a), u = n.size;
                if ("Bunny" === a) {
                    let e = A(r.bodyR.x, r.bodyR.y, r.bodyR.z, 14, 10),
                        t = e.attributes.position;
                    for (let e = 0; e < t.count; e++) {
                        let a = t.getZ(e),
                            l = t.getY(e),
                            n = 1 + (a < 0 ? .12 : -.05) * (1 - Math.abs(l) / r.bodyR.y);
                        t.setX(e, t.getX(e) * n), t.setY(e, l < 0 ? .92 * l : l)
                    }
                    e.computeVertexNormals(), e.translate(r.bodyC.x, r.bodyC.y, r.bodyC.z), i.add(e, null, {
                        paint: s("body"),
                        skin: eh
                    })
                } else {
                    let e = A(r.bodyR.x, r.bodyR.y, r.bodyR.z, 14, 10),
                        t = e.attributes.position;
                    for (let e = 0; e < t.count; e++) {
                        let a = t.getZ(e) / r.bodyR.z;
                        t.setY(e, t.getY(e) * (1 + .08 * a) + .012 * a)
                    }
                    e.computeVertexNormals(), e.translate(r.bodyC.x, r.bodyC.y, r.bodyC.z), i.add(e, null, {
                        paint: s("body"),
                        skin: eh
                    })
                }
                let d = A(r.headR.x, r.headR.y, r.headR.z, 16, 11);
                d.translate(r.headC.x, r.headC.y, r.headC.z), i.add(d, null, {
                    paint: s("head"),
                    skin: ef
                });
                let h = r.headC.z + r.headR.z;
                if ("Dog" === a && n.muzzle > .03) {
                    let e = A(.072 * u, .058 * u, n.muzzle, 10, 7);
                    e.translate(0, r.headC.y - .045 * u, h - .35 * n.muzzle), i.add(e, null, {
                        paint: s("muzzle"),
                        skin: ef
                    });
                    let t = A(.03 * u, .022 * u, .02 * u, 8, 5);
                    t.translate(0, r.headC.y - .02 * u, h + .6 * n.muzzle), i.add(t, null, {
                        paint: z(n.nose),
                        skin: ef,
                        outline: !1
                    })
                } else {
                    let e = "Dog" === a;
                    for (let t of [-1, 1]) {
                        let a = A((e ? .05 : .044) * u, (e ? .042 : .036) * u, .035 * u, 8, 5);
                        a.translate(.034 * t * u, r.headC.y - .058 * u, h - .022 * u), i.add(a, null, {
                            paint: s("muzzle"),
                            skin: ef,
                            outline: !1
                        })
                    }
                    let t = A((e ? .026 : .017) * u, (e ? .018 : .012) * u, .012 * u, 6, 4);
                    t.translate(0, r.headC.y - (e ? .03 : .035) * u, h + .008 * u), i.add(t, null, {
                        paint: z(n.nose),
                        skin: ef,
                        outline: !1
                    })
                }
                for (let [e, t] of [
                        [1, ep],
                        [-1, ec]
                    ]) {
                    let [a, o, d] = r.rest[t];
                    switch (n.ears) {
                        case "cat":
                        case "pointy":
                            {
                                let r = ("cat" === n.ears ? .09 : .095) * u,
                                    h = new l.qFE(.055 * u, r, 4, 1);h.rotateY(Math.PI / 4),
                                h.scale(1, 1, .55),
                                h.applyMatrix4(R(a, o + .38 * r, d, -.12, 0, -(.32 * e))),
                                i.add(h, null, {
                                    paint: s("ear"),
                                    skin: t
                                });
                                let f = new l.qFE(.034 * u, .7 * r, 4, 1);f.rotateY(Math.PI / 4),
                                f.scale(1, 1, .3),
                                f.applyMatrix4(R(a - .002 * e, o + .3 * r, d + .012 * u, -.12, 0, -(.32 * e))),
                                i.add(f, null, {
                                    paint: s("inner"),
                                    skin: t,
                                    outline: !1
                                });
                                break
                            }
                        case "floppy":
                            {
                                let l = A(.05 * u, .085 * u, .024 * u, 8, 6);l.applyMatrix4(R(a + .05 * e * u, o - .07 * u, d - .01, .1, .35 * e, .25 * e)),
                                i.add(l, null, {
                                    paint: s("ear"),
                                    skin: t
                                });
                                break
                            }
                        case "folded":
                            {
                                let l = A(.042 * u, .032 * u, .018 * u, 8, 5);l.applyMatrix4(R(a + .03 * e * u, o - .005, d + .03, .7, 0, -(.5 * e))),
                                i.add(l, null, {
                                    paint: s("ear"),
                                    skin: t
                                });
                                break
                            }
                        case "long":
                            {
                                let l = T([
                                    [0, 0],
                                    [.6, .02],
                                    [.95, .07],
                                    [1, .12],
                                    [.8, .18],
                                    [.4, .215],
                                    [0, .225]
                                ], 8);l.scale(.038, 1, .017),
                                l.applyMatrix4(R(a, o - .03, d - .01, -.12, 0, -(.14 * e))),
                                i.add(l, null, {
                                    paint: s("ear"),
                                    skin: t
                                });
                                let n = A(.02, .075, .006, 6, 5);n.applyMatrix4(R(a - .002 * e, o + .085, d + .002, -.12, 0, -(.14 * e))),
                                i.add(n, null, {
                                    paint: s("inner"),
                                    skin: t,
                                    outline: !1
                                })
                            }
                    }
                }
                for (let e of [eb, eM, ew, eg]) {
                    let [t, l, n] = r.rest[e];
                    if ("Bunny" === a && (e === ew || e === eg)) {
                        let a = G(A(.042, .04, .085, 8, 6), -.03);
                        a.translate(t, .03, n + .02), i.add(a, null, {
                            paint: s("leg"),
                            skin: e
                        });
                        continue
                    }
                    let o = l - .02,
                        d = "Bunny" === a ? .028 : .036 * u,
                        h = "Bunny" === a ? .024 : .03 * u,
                        f = T([
                            [0, l - o - .004],
                            [.9 * h, l - o],
                            [h, l - o + .02],
                            [(d + h) / 2, l - .5 * o],
                            [d, l - .01],
                            [.7 * d, l + .6 * d],
                            [0, l + d]
                        ], 8);
                    f.translate(t, 0, n), i.add(f, null, {
                        paint: s("leg"),
                        skin: e
                    });
                    let p = G(A(1.25 * h, .9 * h, 1.45 * h, 8, 5), -(.5 * h));
                    p.translate(t, .5 * h, n + .35 * h), i.add(p, null, {
                        paint: s("leg"),
                        skin: e
                    })
                }
                let [f, p, c] = r.rest[ey], y = new l.Pq0(f, p, c), m = r.rest[em], b = "z";
                if ("puff" === n.tail) {
                    let e = A(.048, .046, .044, 8, 6);
                    e.translate(f, p + .01, c - .01), i.add(e, null, {
                        paint: z("#fffaf4"),
                        skin: ey
                    })
                } else {
                    let e = {
                        cat: {
                            pts: [
                                [0, 0, .02],
                                [0, .02, -.04],
                                [0, .08, -.1],
                                [0, .16, -.12],
                                [0, .24, -.09],
                                [.01, .3, -.04],
                                [.015, .33, -.005]
                            ],
                            r: [0, .03, .028, .027, .026, .022, 0]
                        },
                        curl: {
                            pts: [
                                [0, 0, .02],
                                [0, .03, -.03],
                                [0, .1, -.05],
                                [.01, .15, -.01],
                                [.03, .15, .05],
                                [.04, .11, .08],
                                [.04, .08, .075]
                            ],
                            r: [0, .042, .045, .042, .036, .026, 0]
                        },
                        otter: {
                            pts: [
                                [0, 0, .02],
                                [0, 0, -.04],
                                [0, -.03, -.12],
                                [0, -.06, -.19],
                                [0, -.075, -.24],
                                [0, -.08, -.26]
                            ],
                            r: [0, .04, .034, .026, .016, 0]
                        },
                        corkscrew: {
                            pts: [
                                [0, 0, .02],
                                [0, .03, -.03],
                                [.02, .07, -.035],
                                [.04, .085, 0],
                                [.015, .075, .03],
                                [-.01, .055, .02],
                                [-.012, .045, .01]
                            ],
                            r: [0, .024, .024, .022, .02, .016, 0]
                        },
                        sickle: {
                            pts: [
                                [0, 0, .02],
                                [0, .02, -.04],
                                [0, .1, -.08],
                                [0, .18, -.07],
                                [0, .24, -.02],
                                [0, .26, .01]
                            ],
                            r: [0, .03, .028, .024, .014, 0]
                        }
                    }[n.tail];
                    b = "otter" === n.tail ? "y" : "z";
                    let t = e.pts.map(([e, t, a]) => new l.Pq0(e * u, t * u, a * u).add(y)),
                        a = function(e, t) {
                            let a = e.length,
                                n = [],
                                r = [],
                                i = [],
                                o = new l.Pq0,
                                s = new l.Pq0(1, 0, 0),
                                u = new l.Pq0,
                                d = new l.Pq0;
                            for (let l = 0; l < a; l++) {
                                let i = e[Math.max(0, l - 1)],
                                    h = e[Math.min(a - 1, l + 1)];
                                o.subVectors(h, i).normalize(), Math.abs(o.dot(s)) > .9 && s.set(0, 1, 0), u.crossVectors(o, s).normalize(), d.crossVectors(o, u).normalize();
                                let f = t[l] ? ? 0,
                                    p = e[l];
                                for (let e = 0; e <= 8; e++) {
                                    let t = e / 8 * Math.PI * 2,
                                        a = u.x * Math.cos(t) + d.x * Math.sin(t),
                                        i = u.y * Math.cos(t) + d.y * Math.sin(t),
                                        s = u.z * Math.cos(t) + d.z * Math.sin(t);
                                    if (n.push(p.x + a * f, p.y + i * f, p.z + s * f), f < 1e-5) {
                                        let e = 0 === l ? -1 : 1;
                                        r.push(o.x * e, o.y * e, o.z * e)
                                    } else r.push(a, i, s)
                                }
                            }
                            for (let e = 0; e < a - 1; e++)
                                for (let t = 0; t < 8; t++) {
                                    let a = 9 * e + t,
                                        l = a + 8 + 1;
                                    i.push(a, a + 1, l, l, a + 1, l + 1)
                                }
                            let h = new l.LoY;
                            return h.setAttribute("position", new l.THS(new Float32Array(n), 3)), h.setAttribute("normal", new l.THS(new Float32Array(r), 3)), h.setIndex(i), h
                        }(t, e.r.map(e => e * u)),
                        r = t.length,
                        o = new l.Pq0(m[0], m[1], m[2]),
                        d = t.map((e, t) => {
                            let a = e.distanceTo(y),
                                l = o.distanceTo(y);
                            return 0 === t ? 0 : Math.max(0, Math.min(1, (a - .7 * l) / (.6 * l)))
                        });
                    i.add(a, null, {
                        paint: s("tail"),
                        skin: (e, t) => [ey, em, d[Math.min(r - 1, Math.floor(t / 9))] ? ? 0]
                    })
                }
                let M = i.build(t),
                    g = r.rest[ef],
                    v = new l.Pq0(r.headC.x - g[0], r.headC.y - g[1], r.headC.z - g[2]),
                    x = "green" === n.eye ? "catGreen" : "blue" === n.eye ? "catBlue" : "amber" === n.eye ? "catAmber" : "petDark",
                    k = "Bunny" === a ? .06 : .064 * u,
                    C = "Bunny" === a ? 0 : .005 * u,
                    I = ("Cat" === a ? .074 : .066) * u,
                    F = "Dog" !== a || n.muzzle <= .03,
                    B = w([{
                        x: k,
                        y: C,
                        w: I,
                        h: 1.08 * I,
                        mirror: !1,
                        cell: x,
                        lift: .0026
                    }, {
                        x: -k,
                        y: C,
                        w: I,
                        h: 1.08 * I,
                        mirror: !0,
                        cell: x,
                        lift: .0026
                    }, {
                        x: .098 * u,
                        y: -.045 * u,
                        w: .06 * u,
                        h: .036 * u,
                        mirror: !1,
                        cell: "blush",
                        lift: .0016,
                        alpha: .75
                    }, {
                        x: -.098 * u,
                        y: -.045 * u,
                        w: .06 * u,
                        h: .036 * u,
                        mirror: !0,
                        cell: "blush",
                        lift: .0016,
                        alpha: .75
                    }, {
                        x: 0,
                        y: ("Dog" === a ? -.085 : -.082) * u,
                        w: .05 * u,
                        h: .032 * u,
                        mirror: !1,
                        cell: F ? "mouthCat" : "empty",
                        lift: .03
                    }], v, r.headR);
                return {
                    body: M.body,
                    outline: M.outline ? ? M.body,
                    face: B,
                    dims: r,
                    eye: x,
                    mouth: F,
                    wagAxis: b
                }
            }
            let ek = new Set(["idle", "trot", "sit", "sleep", "hop"]);

            function ez(e, t) {
                let a = t ? .quality === "low" ? "low" : "high",
                    n = !!t ? .reducedMotion,
                    r = (0, _.us)(e),
                    i = JSON.stringify([r.kind, r.coat]),
                    o = m(t ? .doc),
                    s = t ? .fonts ? .body || "system-ui, sans-serif",
                    u = new l.YJl;
                u.name = "pet";
                let d = x(),
                    h = b(o);
                h && (d.face.map = h);
                let f = ex(r, !0),
                    p = [],
                    c = null,
                    y = new l.YJl;
                u.add(y);
                let w = new l.I46(f.body, d.body),
                    g = new l.I46(f.outline, d.outline);
                w.name = "pet-body", w.userData.castOnly = !0, g.name = "pet-ink", g.userData.noShadow = !0;
                let v = new l.eaF(f.face.geometry, d.face);
                v.name = "pet-face", v.userData.noShadow = !0, v.renderOrder = 1;
                let k = new l.eaF(new l.tcD(.26, 18).rotateX(-Math.PI / 2), d.blob);
                k.position.y = .004, k.userData.noShadow = !0, k.renderOrder = -1, u.add(k);
                let z = t ? .charm === "paws",
                    S = function(e = .07, t = !1) {
                        let a = new l.LoY,
                            n = new Float32Array(48),
                            r = new Float32Array(72),
                            i = new Float32Array(24),
                            o = new Float32Array(72),
                            s = [],
                            u = [
                                [-.5, -.5],
                                [.5, -.5],
                                [.5, .5],
                                [-.5, .5]
                            ];
                        for (let e = 0; e < 6; e++) {
                            let t = e / 6 * Math.PI * 2 + .4,
                                a = .16 * Math.cos(t),
                                l = .1 * Math.sin(t),
                                o = .05 + e % 3 * .04;
                            for (let t = 0; t < 4; t++) {
                                let s = 4 * e + t;
                                n[2 * s] = u[t][0], n[2 * s + 1] = u[t][1], r[3 * s] = a, r[3 * s + 1] = o, r[3 * s + 2] = l, i[s] = .09 * e
                            }
                            s.push(4 * e, 4 * e + 1, 4 * e + 2, 4 * e, 4 * e + 2, 4 * e + 3)
                        }
                        a.setAttribute("position", new l.THS(o, 3)), a.setAttribute("aCorner", new l.THS(n, 2)), a.setAttribute("aOffset", new l.THS(r, 3)), a.setAttribute("aDelay", new l.THS(i, 1)), a.setIndex(s);
                        let d = {
                                uT: {
                                    value: 99
                                },
                                uSize: {
                                    value: e
                                }
                            },
                            h = new l.BKk({
                                vertexShader: eu,
                                fragmentShader: ed,
                                uniforms: d,
                                transparent: !0,
                                depthWrite: !1,
                                defines: t ? {
                                    PAWS: ""
                                } : {}
                            }),
                            f = new l.eaF(a, h);
                        return f.frustumCulled = !1, f.renderOrder = 5, f.userData.noShadow = !0, f.visible = !1, f.name = "pet-hearts", {
                            mesh: f,
                            burst() {
                                d.uT.value = 0, f.visible = !0
                            },
                            update(e) {
                                f.visible && (d.uT.value += e, d.uT.value > 2.2 && (f.visible = !1))
                            },
                            dispose() {
                                a.dispose(), h.dispose()
                            }
                        }
                    }(.07, z);

                function P() {
                    let e = u.parent,
                        t = {
                            p: u.position.clone(),
                            q: u.quaternion.clone(),
                            s: u.scale.clone()
                        };
                    for (let e of (u.position.set(0, 0, 0), u.quaternion.identity(), u.scale.set(1, 1, 1), p)) e.removeFromParent();
                    c ? .dispose(), p = [];
                    let a = f.dims.rest;
                    for (let e = 0; e < 11; e++) {
                        let t = new l.$Kf,
                            n = a[e],
                            r = ev[e],
                            i = r >= 0 ? a[r] : [0, 0, 0];
                        t.position.set(n[0] - i[0], n[1] - i[1], n[2] - i[2]), p.push(t), r >= 0 && p[r].add(t)
                    }
                    y.add(p[0]), e && u.removeFromParent(), u.updateMatrixWorld(!0), c = new l.EAD(p), w.bind(c, new l.kn4), g.bind(c, new l.kn4), e && e.add(u), u.position.copy(t.p), u.quaternion.copy(t.q), u.scale.copy(t.s), p[ef].add(v);
                    let n = new l.iyt(new l.Pq0(0, .5 * f.dims.height, 0), Math.max(.5, f.dims.height));
                    w.boundingSphere = n, g.boundingSphere = n.clone(), S.mesh.position.set(0, f.dims.headC.y + .12, f.dims.headC.z), T.position.set(0, f.dims.height + .1, .5 * f.dims.headC.z)
                }
                u.add(S.mesh);
                let C = null,
                    q = new l.RoJ({
                        transparent: !0,
                        depthWrite: !1
                    }),
                    T = new l.kxk(q);
                T.name = "pet-tag", T.userData.noShadow = !0, T.renderOrder = 6, T.visible = !1, u.add(T);
                let A = !1,
                    I = 0;

                function F(e) {
                    if (!o) return;
                    let t = C ? .image;
                    if (!t) {
                        try {
                            t = o.createElement("canvas")
                        } catch {
                            return
                        }
                        t.width = 512, t.height = 128
                    }
                    let a = t.getContext("2d");
                    if (!a) return;
                    a.clearRect(0, 0, 512, 128);
                    let n = 60,
                        r = e => `700 ${e}px ${s}`;
                    for (a.font = r(60); n > 24 && a.measureText(e).width > 380;) a.font = r(n -= 4);
                    let i = Math.min(500, a.measureText(e).width + 120),
                        u = (512 - i) / 2;
                    a.shadowColor = "rgba(60,20,40,0.25)", a.shadowBlur = 10, a.shadowOffsetY = 4, a.beginPath(), a.roundRect(u, 14, i, 96, 48), a.fillStyle = "rgba(255,255,255,0.95)", a.fill(), a.shadowColor = "transparent", a.lineWidth = 5, a.strokeStyle = z ? "#e8a35a" : "#ff8fab", a.stroke();
                    let d = u + 46;
                    if (a.beginPath(), z)
                        for (let [e, t] of (a.ellipse(d, 69, 11, 9, 0, 0, 2 * Math.PI), [
                                [-12, -7],
                                [-4, -14],
                                [4, -14],
                                [12, -7]
                            ])) a.moveTo(d + e + 4, 64 + t), a.arc(d + e, 64 + t, 4, 0, 2 * Math.PI);
                    else a.moveTo(d, 77), a.bezierCurveTo(d - 22, 62, d - 12, 44, d, 56), a.bezierCurveTo(d + 12, 44, d + 22, 62, d, 77);
                    a.fillStyle = z ? "#c9783a" : "#ff6f91", a.fill(), a.fillStyle = "#4a2638", a.textAlign = "left", a.textBaseline = "middle", a.fillText(e, d + 28, 66), C ? C.needsUpdate = !0 : ((C = new l.GOR(t)).colorSpace = l.er$, C.anisotropy = 4, q.map = C, q.needsUpdate = !0), T.scale.set(.56, .14, 1)
                }

                function B() {
                    T.visible = !!C && r.name.trim().length > 0 && (A || I > 0)
                }

                function D() {
                    g.visible = "high" === a, k.visible = "low" === a, v.visible = !!h
                }
                F(r.name), u.add(w, g), P(), D();
                let H = 2 + 3 * Math.random(),
                    R = 0,
                    Y = "";

                function W(e) {
                    if (e === Y) return;
                    Y = e;
                    let t = "open" === e ? f.eye : "happy" === e ? "petClosed" : "eyeBlink";
                    f.face.setCell(0, t), f.face.setCell(1, t)
                }
                let O = {
                        clip: "idle",
                        t: 10 * Math.random()
                    },
                    G = null,
                    L = 0,
                    N = .3,
                    X = 0,
                    E = 0,
                    U = -1,
                    Z = 0,
                    V = 1,
                    $ = 2 + 3 * Math.random(),
                    K = new Float32Array(36),
                    J = new Float32Array(36),
                    j = new Float32Array(36),
                    Q = null,
                    ee = 0,
                    et = 0,
                    ea = new l.Pq0,
                    el = (e, t, a, l, n) => {
                        e[3 * t] = a, e[3 * t + 1] = l, e[3 * t + 2] = n
                    },
                    en = (e, t, a, l, n) => {
                        e[3 * t] = (e[3 * t] ? ? 0) + a, e[3 * t + 1] = (e[3 * t + 1] ? ? 0) + l, e[3 * t + 2] = (e[3 * t + 2] ? ? 0) + n
                    },
                    er = (e, t, a, l) => {
                        let n = Math.sin(l * a) * t,
                            r = Math.sin(l * a - .9) * t * 1.2;
                        "y" === f.wagAxis ? (en(e, ey, 0, n, 0), en(e, em, 0, r, 0)) : (en(e, ey, 0, 0, n), en(e, em, 0, 0, r))
                    };

                function ei(e, t, a) {
                    a.fill(0);
                    let l = r.kind,
                        i = "Dog" === l,
                        o = "Bunny" === l,
                        s = f.dims.legLen;
                    switch (a[34] = .003 * Math.sin(2.4 * t), en(a, eh, .01 * Math.sin(2.4 * t), 0, 0), e) {
                        case "trot":
                            {
                                let e = Math.sin(E),
                                    l = Math.cos(E);
                                if (o) {
                                    let t = Math.max(0, e);
                                    a[34] = .07 * t, en(a, eh, -(.16 * l), 0, 0), el(a, ew, .5 * t, 0, 0), el(a, eg, .5 * t, 0, 0), el(a, eb, -.6 * t, 0, 0), el(a, eM, -.6 * t, 0, 0), en(a, ep, .25 * t, 0, 0), en(a, ec, .25 * t, 0, 0)
                                } else {
                                    let n = Math.min(.55, .3 + .15 * X);
                                    el(a, eb, -e * n, 0, 0), el(a, eg, -e * n, 0, 0), el(a, eM, e * n, 0, 0), el(a, ew, e * n, 0, 0), a[34] = .014 * Math.abs(l), en(a, eh, 0, .05 * e, .03 * l), en(a, ef, .04 * Math.sin(2 * E), -(.05 * e), 0), en(a, ey, i ? -.25 : -.15, 0, 0), er(a, i ? .35 : .18, i ? 14 : 6, t), en(a, ep, .15, 0, 0), en(a, ec, .15, 0, 0)
                                }
                                break
                            }
                        case "sit":
                            o ? (en(a, eh, -.45, 0, 0), a[34] = .02, en(a, ef, .35, 0, 0), el(a, eb, .45, 0, 0), el(a, eM, .45, 0, 0), el(a, ew, .45, 0, 0), el(a, eg, .45, 0, 0)) : (en(a, eh, -.55, 0, 0), a[34] = -(.32 * s), en(a, ef, .5, 0, 0), el(a, eb, .55, 0, 0), el(a, eM, .55, 0, 0), el(a, ew, -.95, 0, .05), el(a, eg, -.95, 0, -.05), en(a, ey, 1.25, .4, 0), en(a, em, 0, 1, 0), n || er(a, i ? .2 : .06, i ? 8 : 2, t));
                            break;
                        case "sleep":
                            a[34] = -(s + .005 * !o) + .004 * Math.sin(1.6 * t), en(a, eh, 0, 0, .22 * !o), el(a, eb, -1.35, 0, 0), el(a, eM, -1.35, 0, 0), el(a, ew, 1.3, 0, 0), el(a, eg, 1.3, 0, 0), o ? (en(a, ep, 1.05, 0, .2), en(a, ec, 1.05, 0, -.2), en(a, ef, .3, 0, 0)) : (en(a, ef, .55, .65, -.1), en(a, ey, 1, 1.2, 0), en(a, em, .2, 1.2, 0), en(a, ep, -.15, 0, 0), en(a, ec, -.15, 0, 0));
                            break;
                        case "hop":
                            {
                                let e = Math.sin(t % .62 / .62 * Math.PI);a[34] = e * (n ? .03 : .11),
                                el(a, eb, -.5 * e, 0, 0),
                                el(a, eM, -.5 * e, 0, 0),
                                el(a, ew, .55 * e, 0, 0),
                                el(a, eg, .55 * e, 0, 0),
                                en(a, eh, -.15 * e, 0, 0),
                                en(a, ep, -.35 * e + .15, 0, .15 * e),
                                en(a, ec, -.35 * e + .15, 0, -.15 * e),
                                o || er(a, .45, 16, t);
                                break
                            }
                        default:
                            if (o) {
                                en(a, eh, -.06, 0, 0), n || en(a, ef, 0, .25 * Math.sin(.5 * t), .1 * Math.sin(.4 * t)), en(a, ef, .1, 0, 0), n || (en(a, ep, .06 * Math.sin(1.1 * t), 0, .08 + .05 * Math.sin(.7 * t)), en(a, ec, .06 * Math.sin(1.3 * t + 1), 0, -.08 - .05 * Math.sin(.8 * t)));
                                break
                            }
                            n ? er(a, .08, 1.5, t) : (en(a, ef, .06 * Math.sin(.6 * t), .32 * Math.sin(.37 * t), .14 * Math.sin(.5 * t + .6)), er(a, i ? .28 : .22, i ? 7 : 1.6, t)), en(a, ey, i ? -.1 : .1, 0, 0)
                    }
                }

                function eo(e) {
                    if (O.t += e, G && (G.t += e), L += e, G && L >= N && (G = null), "trot" === O.clip && (E += e * Math.PI * 2 * ("Bunny" === r.kind ? 1.8 + .4 * X : Math.max(1.4, (X || 1.2) / .36))), ei(O.clip, O.t, K), G) {
                        ei(G.clip, G.t, J);
                        let e = L / N,
                            t = e * e * (3 - 2 * e);
                        for (let e = 0; e < 36; e++) j[e] = J[e] + (K[e] - J[e]) * t
                    } else j.set(K);
                    if (U >= 0) {
                        let t = Math.sin(Math.PI * Math.min(1, (U += e) / .55));
                        j[34] = (j[34] ? ? 0) + t * (n ? .03 : .12), j[3 * ew] = (j[3 * ew] ? ? 0) + .5 * t, j[3 * eg] = (j[3 * eg] ? ? 0) + .5 * t, j[3 * eb] = (j[3 * eb] ? ? 0) - .45 * t, j[3 * eM] = (j[3 * eM] ? ? 0) - .45 * t, U > 1.1 && (U = -1)
                    }
                    if (!n && "sleep" !== O.clip) {
                        ($ -= e) <= 0 && (Z = 1, V = .5 > Math.random() ? 1 : -1, $ = 2.5 + 4 * Math.random()), Z = Math.max(0, Z - 5 * e);
                        let t = V > 0 ? ep : ec;
                        j[3 * t + 2] = (j[3 * t + 2] ? ? 0) + .35 * Math.sin(Z * Math.PI) * V
                    }
                    let t = 0,
                        a = 0;
                    if (Q && "sleep" !== O.clip) {
                        ea.copy(Q), u.worldToLocal(ea);
                        let e = Math.atan2(ea.x, ea.z - f.dims.headC.z);
                        2.2 > Math.abs(e) && (t = Math.max(-.85, Math.min(.85, e)), a = Math.max(-.5, Math.min(.3, Math.atan2(f.dims.headC.y - ea.y, Math.max(.2, Math.hypot(ea.x, ea.z))))))
                    }
                    let l = 1 - Math.exp(-(5 * e));
                    ee += (t - ee) * l, et += (a - et) * l, j[3 * ef + 1] = (j[3 * ef + 1] ? ? 0) + ee, j[3 * ef] = (j[3 * ef] ? ? 0) + et;
                    for (let e = 0; e < 11; e++) p[e].rotation.set(j[3 * e], j[3 * e + 1], j[3 * e + 2]);
                    let i = f.dims.rest[eh];
                    p[eh].position.set(i[0], i[1] + j[34], i[2]), "sleep" === O.clip ? W("sleep") : "hop" === O.clip || U >= 0 ? W("happy") : R > 0 ? W((R -= e) > 0 ? "blink" : "open") : (H -= e) <= 0 ? (R = .13, H = 3 + 3 * Math.random(), W("blink")) : W("open"), S.update(e), I > 0 && (I -= e) <= 0 && B()
                }
                return eo(0), {
                    object: u,
                    get height() {
                        return f.dims.height
                    },
                    setConfig(e) {
                        let t = (0, _.us)(e),
                            a = JSON.stringify([t.kind, t.coat]),
                            l = t.name !== r.name;
                        if (r = t, a !== i) {
                            i = a;
                            let e = f;
                            w.geometry = (f = ex(r, !0)).body, g.geometry = f.outline, v.geometry = f.face.geometry, e.body.dispose(), e.outline !== e.body && e.outline.dispose(), e.face.geometry.dispose(), Y = "", P()
                        }
                        l && (F(r.name), B())
                    },
                    play(e, t) {
                        let a = ek.has(e) ? e : "idle";
                        if (t ? .speed !== void 0 && Number.isFinite(t.speed) && (X = Math.max(0, t.speed)), a === O.clip) return;
                        let l = t ? .fade ? ? .3;
                        G = l > 0 ? O : null, O = {
                            clip: a,
                            t: 0
                        }, L = 0, N = Math.max(1e-4, l)
                    },
                    lookAt(e) {
                        Q = e ? (Q ? ? new l.Pq0).copy(e) : null
                    },
                    react() {
                        U = 0, S.burst(), I = 3, B()
                    },
                    showTag(e) {
                        A = !!e, B()
                    },
                    update(e) {
                        eo(Number.isFinite(e) ? Math.min(.1, Math.max(0, e)) : 0)
                    },
                    setQuality(e) {
                        a = "low" === e ? "low" : "high", D()
                    },
                    dispose() {
                        u.removeFromParent(), f.body.dispose(), f.outline !== f.body && f.outline.dispose(), f.face.geometry.dispose(), k.geometry.dispose(), c ? .dispose(), S.dispose(), C ? .dispose(), q.dispose(), d.face.map = null, d.dispose(), M(o, h)
                    }
                }
            }
        }
    }
]);