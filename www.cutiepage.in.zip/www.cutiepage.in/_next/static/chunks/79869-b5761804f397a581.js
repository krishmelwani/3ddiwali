(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [34212, 79869], {
        2313: () => {},
        9632: () => {},
        11722: () => {},
        15799: () => {},
        28744: () => {},
        34212: (e, t, a) => {
            "use strict";
            a.d(t, {
                CA: () => v,
                FX: () => y,
                Ki: () => x,
                NE: () => j,
                O9: () => b,
                Od: () => k,
                UT: () => p,
                YQ: () => g,
                bL: () => N,
                bt: () => h,
                dA: () => c,
                e8: () => u,
                rI: () => f,
                uz: () => m
            });
            var o = a(73365),
                l = a(34768),
                i = a(87802),
                r = a(92407),
                n = a(56519),
                s = a(73327),
                d = a(78874);

            function c({
                name: e,
                className: t = "",
                priority: a = !1
            }) {
                let [l, i] = d.B[e];
                return (0, o.jsx)(r.DecorImage, {
                    src: (0, d.Y)(e),
                    width: l,
                    height: i,
                    priority: a,
                    className: `pointer-events-none block h-auto max-w-none select-none drop-shadow-[0_6px_8px_rgb(0_0_0/0.18)] ${t}`
                })
            }
            let u = {
                dancingCat: "https://cdn.cutiepage.in/template-seeds/brothers-day/cat.gif",
                catHug: "https://cdn.cutiepage.in/template-seeds/girlfriends-day/greeting2.gif",
                catCheer: "https://cdn.cutiepage.in/template-seeds/girlfriends-day/greeting1.gif",
                cake: "https://cdn.cutiepage.in/template-seeds/bday-wish1/intro.gif"
            };

            function p() {
                let e = (0, l.useAssetUrl)("introMedia");
                return !!e && !/\/template-seeds\/cp-[a-z0-9-]+\/opening-v1\.webp$/.test(e)
            }

            function h(e = u.dancingCat) {
                return (0, i.Sl)("introMedia", "Opening photo or GIF", e)
            }

            function m(e = u.catHug) {
                return (0, i.Sl)("endMedia", "Ending photo or GIF", e)
            }

            function f(e, t, a, o = a[0]) {
                return [{ ...(0, i.Qq)(e, t, o, 24),
                    options: a
                }, (0, i.Sl)(`${e}Photo`, `${t}: your own picture`, "")]
            }

            function b({
                id: e,
                art: t,
                className: a = "",
                photoClassName: i = ""
            }) {
                let r = (0, l.useText)(e);
                if ((0, l.useAssetUrl)(`${e}Photo`)) return (0, o.jsx)("span", {
                    className: a,
                    children: (0, o.jsx)(l.FImage, {
                        field: `${e}Photo`,
                        className: `block size-full object-contain ${i}`
                    })
                });
                let n = t[r] ? ? Object.values(t)[0] ? ? null;
                return (0, o.jsx)("span", {
                    className: a,
                    children: n
                })
            }

            function w() {
                return (0, o.jsxs)("svg", {
                    viewBox: "0 0 160 160",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, o.jsx)("rect", {
                        width: "160",
                        height: "160",
                        style: {
                            fill: "color-mix(in srgb, var(--f-accent) 14%, var(--f-surface))"
                        }
                    }), (0, o.jsx)("path", {
                        d: "M80 118c-26-17-40-31-40-48 0-11 9-20 20-20 8 0 15 5 20 12 5-7 12-12 20-12 11 0 20 9 20 20 0 17-14 31-40 48z",
                        fill: "var(--f-accent)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "3",
                        strokeLinejoin: "round"
                    })]
                })
            }

            function g({
                field: e,
                className: t = ""
            }) {
                let a = (0, l.useMode)(),
                    i = (0, l.useAssetUrl)(e);
                return (0, o.jsx)("div", {
                    className: `relative aspect-square overflow-hidden rounded-[calc(var(--f-radius,18)*1px)] bg-(--f-surface) shadow-[0_0_0_3px_var(--f-fg),0_8px_0_3px_var(--f-fg)] ${t}`,
                    children: i || "edit" === a ? (0, o.jsx)(l.FImage, {
                        field: e,
                        alt: "",
                        className: "block size-full object-cover",
                        priority: "introMedia" === e
                    }) : (0, o.jsx)(w, {})
                })
            }

            function y({
                template: e,
                name: t,
                className: a = "",
                priority: l = !1
            }) {
                let [i, n] = s.m[e][t];
                return (0, o.jsx)(r.DecorImage, {
                    src: (0, s.q)(e, t),
                    width: i,
                    height: n,
                    priority: l,
                    className: `pointer-events-none block h-auto max-w-none select-none ${a}`
                })
            }

            function x({
                template: e,
                name: t,
                children: a,
                className: l = "",
                holeClassName: i = "",
                flipY: n = !1,
                priority: d = !1
            }) {
                let [c, u, p] = s.m[e][t], [h, m, f, b] = p ? ? [0, 0, 100, 100], w = {
                    left: `${h-1}%`,
                    top: `${(n?100-m-b:m)-1}%`,
                    width: `${f+2}%`,
                    height: `${b+2}%`
                };
                return (0, o.jsxs)("div", {
                    className: `relative ${l}`,
                    style: {
                        aspectRatio: `${c} / ${u}`
                    },
                    children: [(0, o.jsx)("div", {
                        className: `absolute overflow-hidden ${i}`,
                        style: w,
                        children: a
                    }), (0, o.jsx)(r.DecorImage, {
                        src: (0, s.q)(e, t),
                        width: c,
                        height: u,
                        priority: d,
                        className: `pointer-events-none absolute inset-0 block size-full select-none ${n?"-scale-y-100":""}`
                    })]
                })
            }

            function k(e = "cover") {
                return {
                    id: "opening",
                    title: "Opening photo or GIF",
                    fields: [{
                        kind: "section",
                        sectionType: e,
                        fieldId: "introMedia",
                        label: "Opening photo or GIF",
                        hint: "Shows on the first page. A photo of them or a cute GIF."
                    }]
                }
            }

            function j(e = "finale") {
                return {
                    id: "ending",
                    title: "Ending photo or GIF",
                    fields: [{
                        kind: "section",
                        sectionType: e,
                        fieldId: "endMedia",
                        label: "Ending photo or GIF",
                        hint: "Shows on the last page, beside your message."
                    }]
                }
            }

            function N(e) {
                return {
                    id: "decor",
                    title: "Decorations",
                    fields: e.flatMap(e => [{
                        kind: "section",
                        sectionType: e.sectionType,
                        fieldId: e.id,
                        label: e.label,
                        hint: "Pick a style."
                    }, {
                        kind: "section",
                        sectionType: e.sectionType,
                        fieldId: `${e.id}Photo`,
                        label: `${e.label}: your own picture`,
                        hint: "Optional. Upload one and it replaces the drawing."
                    }])
                }
            }
            let v = [n.us, {
                id: "music",
                title: "Music",
                fields: [{
                    kind: "sound",
                    label: "Song",
                    hint: "Add a song if you like. It plays from the first tap."
                }]
            }]
        },
        36744: (e, t, a) => {
            "use strict";
            a.d(t, {
                Dl: () => v,
                Nw: () => b,
                Qj: () => x,
                Te: () => T,
                Vw: () => M,
                XX: () => F,
                _c: () => N,
                _v: () => g,
                b0: () => L,
                f_: () => y,
                o2: () => j,
                qf: () => $
            });
            var o = a(87802);
            let l = ["Porcelain", "Ivory", "Sand", "Honey", "Caramel", "Almond", "Cocoa", "Espresso"],
                i = ["Short", "Side part", "Curly", "Bun", "Ponytail", "Long straight", "Long wavy", "Braid", "Buzz cut", "Quiff"],
                r = ["Black", "Dark brown", "Brown", "Chestnut", "Auburn", "Honey", "Grey", "Pink"],
                n = ["Tee", "Shirt", "Kurta", "Hoodie", "Dress", "Kurti", "Short dress", "Maxi dress", "Crop top", "Sweater", "Saree", "Anarkali", "Sherwani", "Nehru jacket"],
                s = ["Jeans", "Trousers", "Skirt", "Shorts", "Lehenga", "Mini skirt"],
                d = ["Rose", "Red", "Coral", "Mustard", "Mint", "Teal", "Sky", "Navy", "Lilac", "Plum", "White", "Black"],
                c = ["White", "Black", "Brown", "Red", "Pink", "Blue"],
                u = ["None", "Glasses", "Bindi", "Earrings", "Cap", "Flower in hair", "Scarf", "Dupatta"],
                p = ["Classic", "Slim", "Curvy", "Athletic", "Broad"],
                h = ["Female", "Male"],
                m = ["None", "Stubble", "Moustache", "Beard"],
                f = ["None", "Cat", "Dog", "Bunny"],
                b = {
                    Cat: ["Orange tabby", "Black", "White", "Calico", "Siamese"],
                    Dog: ["Shiba", "Labrador", "Pug", "Indie"],
                    Bunny: ["White", "Brown"]
                },
                w = [...new Set(Object.values(b).flat())],
                g = {
                    skin: "Ivory",
                    hairStyle: "Long wavy",
                    hairColor: "Black",
                    top: "Kurti",
                    topColor: "Rose",
                    bottom: "Jeans",
                    bottomColor: "Navy",
                    shoes: "White",
                    accessory: "Earrings",
                    build: "Slim",
                    gender: "Female",
                    facialHair: "None"
                },
                y = {
                    skin: "Ivory",
                    hairStyle: "Side part",
                    hairColor: "Black",
                    top: "Shirt",
                    topColor: "Sky",
                    bottom: "Trousers",
                    bottomColor: "Navy",
                    shoes: "Brown",
                    accessory: "None",
                    build: "Athletic",
                    gender: "Male",
                    facialHair: "Stubble"
                },
                x = {
                    kind: "Cat",
                    coat: "Orange tabby",
                    name: "Mishti"
                };

            function k(e, t, a) {
                return "string" == typeof e && t.includes(e) ? e : a
            }

            function j(e, t, a) {
                return {
                    skin: k(e[`${t}Skin`], l, a.skin),
                    hairStyle: k(e[`${t}HairStyle`], i, a.hairStyle),
                    hairColor: k(e[`${t}HairColor`], r, a.hairColor),
                    top: k(e[`${t}Top`], n, a.top),
                    topColor: k(e[`${t}TopColor`], d, a.topColor),
                    bottom: k(e[`${t}Bottom`], s, a.bottom),
                    bottomColor: k(e[`${t}BottomColor`], d, a.bottomColor),
                    shoes: k(e[`${t}Shoes`], c, a.shoes),
                    accessory: k(e[`${t}Accessory`], u, a.accessory),
                    build: k(e[`${t}Build`], p, a.build),
                    gender: k(e[`${t}Gender`], h, a.gender),
                    facialHair: k(e[`${t}FacialHair`], m, a.facialHair)
                }
            }

            function N(e, t) {
                let a = k(e.petKind, f, t.kind),
                    o = "None" === a ? [] : b[a],
                    l = "None" === a ? "" : k(e.petCoat, o, o.includes(t.coat) ? t.coat : o[0]);
                return {
                    kind: a,
                    coat: l,
                    name: "string" == typeof e.petName ? e.petName.slice(0, 16) : t.name
                }
            }
            let v = ["Skin", "HairStyle", "HairColor", "Top", "TopColor", "Bottom", "BottomColor", "Shoes", "Accessory", "Build", "Gender", "FacialHair"],
                T = (e, t) => `m${e+1}${t}`,
                C = (e, t, a, l) => ({ ...(0, o.Qq)(e, t, l, 24),
                    options: a
                });

            function S(e, t, a) {
                return [C(`${e}Skin`, `${t}: skin tone`, l, a.skin), C(`${e}HairStyle`, `${t}: hair style`, i, a.hairStyle), C(`${e}HairColor`, `${t}: hair colour`, r, a.hairColor), C(`${e}Top`, `${t}: top or dress`, n, a.top), C(`${e}TopColor`, `${t}: top colour`, d, a.topColor), C(`${e}Bottom`, `${t}: bottom`, s, a.bottom), C(`${e}BottomColor`, `${t}: bottom colour`, d, a.bottomColor), C(`${e}Shoes`, `${t}: shoes`, c, a.shoes), C(`${e}Accessory`, `${t}: accessory`, u, a.accessory), C(`${e}Build`, `${t}: body shape`, p, a.build), C(`${e}Gender`, `${t}: body type`, h, a.gender), C(`${e}FacialHair`, `${t}: facial hair`, m, a.facialHair)]
            }

            function F(e) {
                let {
                    copy: t
                } = e;
                return [(0, o.Qq)("kicker", "Small line on top", t.coverKicker, 40), { ...(0, o.Qq)("toName", "Their name", e.names ? .to ? ? "Cutie", 30),
                    placeholder: `e.g. ${e.names?.to??"Cutie"}`
                }, { ...(0, o.Qq)("fromName", "Your name", e.names ? .from ? ? "Kuchupuchu", 30),
                    placeholder: `e.g. ${e.names?.from??"Kuchupuchu"}`
                }, (0, o.Qq)("toFallback", "If no name", e.names ? .toFallback ? ? "Jaan", 20), (0, o.Qq)("fromFallback", "If no name (you)", e.names ? .fromFallback ? ? "Me", 20), (0, o.Qq)("headline", "Cover line", t.headline, 70), (0, o.Qq)("lede", "Line under it", t.lede, 140), (0, o.Sl)("introMedia", "Opening photo or GIF", e.introPhoto ? ? ""), (0, o.Qq)("openLabel", "Enter button", t.openLabel, 24), (0, o.Qq)("loadingLabel", "While the world loads", t.loadingLabel, 40), ...e.voicePack ? [{ ...(0, o.Qq)("voice", "Voice", e.voicePack.options[0].id, 20),
                    hidden: !0
                }] : []]
            }

            function $(e) {
                let {
                    copy: t
                } = e, a = {
                    a: { ...g,
                        ...e.people ? .a
                    },
                    b: { ...y,
                        ...e.people ? .b
                    },
                    pet: e.pet ? ? x
                }, l = e.memories.slice(0, 10).flatMap((e, t) => [(0, o.Sl)(T(t, "Photo"), `Memory ${t+1}: photo`, e.photo ? ? ""), (0, o.Qq)(T(t, "PhotoAlt"), `Memory ${t+1}: photo description`, e.photoAlt, 120), (0, o.Qq)(T(t, "Caption"), `Memory ${t+1}: caption`, e.caption, 40), (0, o.PC)(T(t, "Line"), `Memory ${t+1}: your line`, e.line, 240)]), [i, r] = e.decorations;
                return [(0, o.Qq)("stageLabel", "World (for screen readers)", t.stageLabel, 120), (0, o.Qq)("chooseTitle", "How to see it: question", t.chooseTitle, 50), (0, o.Qq)("walkLabel", "Walk button", t.walkLabel, 24), (0, o.Qq)("tourLabel", "Tour button", t.tourLabel, 24), ...S("a", "Person 1", a.a), ...S("b", "Person 2", a.b), C("petKind", "Pet", f, a.pet.kind), C("petCoat", "Pet's coat", w, a.pet.coat), (0, o.Qq)("petName", "Pet's name", a.pet.name, 16), { ...(0, o.Qq)("decor1", i.label, i.options[0], 24),
                    options: i.options
                }, (0, o.Sl)("decor1Photo", `${i.label}: your own picture`, ""), { ...(0, o.Qq)("decor2", r.label, r.options[0], 24),
                    options: r.options
                }, (0, o.Sl)("decor2Photo", `${r.label}: your own picture`, ""), ...l, (0, o.Qq)("letterGreeting", "Letter: greeting", t.letterGreeting, 40), (0, o.PC)("letterBody", "Letter", t.letterBody, 1600), (0, o.Qq)("letterSignoff", "Letter: before your name", t.letterSignoff, 30), (0, o.Qq)("finaleLine", "Finale: big line in the sky", t.finaleLine, 40), (0, o.Qq)("finaleButton", "Finale: button", t.finaleButton, 24)]
            }

            function L(e) {
                let {
                    copy: t
                } = e;
                return [(0, o.Qq)("line", "Big line", t.endLine, 50), (0, o.Sl)("endMedia", "Ending photo or GIF", e.endPhoto ? ? ""), (0, o.PC)("message", "Your message", t.message, 320), (0, o.Qq)("signoff", "Before the signature", t.signoff, 24), (0, o.Qq)("signature", "Signature", "Me", 40), { ...(0, o.Qq)("replyNumber", "Your WhatsApp number", "", 20),
                    placeholder: "e.g. 98765 43210"
                }, (0, o.Qq)("replyMessage", "Their reply message", t.replyMessage, 120), (0, o.Qq)("replyLabel", "Reply button", t.replyLabel, 24), (0, o.Qq)("replayLabel", "Replay button", t.replayLabel, 24)]
            }
            let P = (e, t, a, o) => ({
                kind: "section",
                sectionType: e,
                fieldId: t,
                ...a ? {
                    label: a
                } : {},
                ...o ? {
                    hint: o
                } : {}
            });

            function M(e) {
                let t = e.memories.slice(0, 10);
                return [{
                    id: "names",
                    title: "Names & first page",
                    fields: [P("cover", "toName", "Their name", "Shown on the cover and the sign in the world."), ...e.voicePack ? [e.voicePack] : [], P("cover", "fromName", "Your name", "Signs the letter."), P("cover", "headline", "Cover line"), P("cover", "kicker", "Small line on top"), P("cover", "lede", "Line under it"), P("cover", "introMedia", "Opening photo or GIF", "Shows on the first page. A photo of them or a cute GIF."), P("cover", "openLabel", "Enter button")],
                    parts: [{
                        title: "If a name is left blank",
                        hint: "Shown in its place.",
                        fields: [P("cover", "toFallback", "Instead of their name"), P("cover", "fromFallback", "Instead of your name")]
                    }, {
                        title: "Buttons and small text",
                        hint: "While the world opens.",
                        fields: [P("cover", "loadingLabel", "While the world loads"), P("world", "chooseTitle", "How to see it: question"), P("world", "walkLabel", "Walk button"), P("world", "tourLabel", "Tour button"), P("world", "stageLabel", "The world, for screen readers")]
                    }]
                }, {
                    id: "characters",
                    title: "You two and your pet",
                    hint: "Dress you both and pick a pet. You see it live in 3D.",
                    widget: "worldCharacters",
                    fields: [...["a", "b"].flatMap(e => v.map(t => P("world", `${e}${t}`))), P("world", "petKind"), P("world", "petCoat"), P("world", "petName")]
                }, {
                    id: "memories",
                    title: "Your photos in the world",
                    hint: "10 photos, each placed somewhere in the 3D world. Tap a photo to swap in your own; it opens with your words when they find it.",
                    fields: [],
                    parts: t.map((e, t) => ({
                        title: `Photo ${t+1}: ${e.title}`,
                        fields: [P("world", T(t, "Photo"), "Photo"), P("world", T(t, "Caption"), "Caption"), P("world", T(t, "Line"), "Your line"), P("world", T(t, "PhotoAlt"), "Photo description", "For screen readers: what is in the photo.")]
                    }))
                }, {
                    id: "decor",
                    title: "Decorations",
                    hint: "Pick a style, or upload your own picture to replace it.",
                    fields: [],
                    parts: ["decor1", "decor2"].map((t, a) => ({
                        title: e.decorations[a].label,
                        fields: [P("world", t, "Style"), P("world", `${t}Photo`, "Your own picture", e.decorations[a].photoHint)]
                    }))
                }, {
                    id: "letter",
                    title: "The letter & finale",
                    hint: "The letter opens once every memory is found.",
                    fields: [P("world", "letterBody", "Letter", "Blank lines make new paragraphs."), P("world", "letterGreeting", "Greeting"), P("world", "letterSignoff", "Before your name")],
                    parts: [{
                        title: "The finale in the world",
                        fields: [P("world", "finaleLine", "Big line in the sky"), P("world", "finaleButton", "Button after it")]
                    }]
                }, {
                    id: "music",
                    title: "Music",
                    fields: [e.songs ? .length ? {
                        kind: "sound",
                        label: "Song",
                        hint: "Pick a song or add your own. It plays from the first tap.",
                        songs: e.songs
                    } : {
                        kind: "sound",
                        label: "Song",
                        hint: "Add a song if you like. It plays from the first tap."
                    }]
                }, {
                    id: "ending",
                    title: "Last page",
                    fields: [P("finale", "endMedia", "Ending photo or GIF", "Shows on the last page, beside your message."), P("finale", "line", "Big line"), P("finale", "message", "Your message"), P("finale", "signoff", "Before the signature"), P("finale", "signature", "Signed by")],
                    parts: [{
                        title: "Reply and replay",
                        hint: "Optional. Your number adds a button so they can reply to you on WhatsApp.",
                        fields: [P("finale", "replyNumber", "Your WhatsApp number"), P("finale", "replyMessage", "Their reply message"), P("finale", "replyLabel", "Reply button"), P("finale", "replayLabel", "Replay button")]
                    }]
                }]
            }
        },
        56519: (e, t, a) => {
            "use strict";
            a.d(t, {
                V3: () => h,
                io: () => p,
                su: () => c,
                us: () => m
            });
            var o = a(73365);
            a(15799), a(28744);
            var l = a(34768),
                i = a(82161),
                r = a(87802);

            function n() {
                return (0, o.jsxs)("svg", {
                    viewBox: "0 0 160 200",
                    "aria-hidden": !0,
                    className: "cppg-empty",
                    children: [(0, o.jsx)("rect", {
                        x: "0",
                        y: "0",
                        width: "160",
                        height: "200",
                        style: {
                            fill: "color-mix(in srgb, var(--f-accent, #ff6fae) 14%, var(--f-surface, #fff))"
                        }
                    }), (0, o.jsx)("path", {
                        d: "M80 128c-26-17-40-31-40-48 0-11 9-20 20-20 8 0 15 5 20 12 5-7 12-12 20-12 11 0 20 9 20 20 0 17-14 31-40 48z",
                        fill: "var(--f-accent, #ff6fae)",
                        stroke: "var(--f-fg, #222)",
                        strokeWidth: "3",
                        strokeLinejoin: "round"
                    }), (0, o.jsx)("circle", {
                        cx: "40",
                        cy: "40",
                        r: "4",
                        fill: "var(--f-fg, #222)",
                        opacity: "0.25"
                    }), (0, o.jsx)("circle", {
                        cx: "124",
                        cy: "152",
                        r: "5",
                        fill: "var(--f-fg, #222)",
                        opacity: "0.2"
                    })]
                })
            }

            function s() {
                let e = (0, l.useMode)(),
                    t = (0, l.useStory)(),
                    a = (0, i.useFolioSound)();
                return (0, o.jsx)("button", {
                    type: "button",
                    tabIndex: "edit" === e ? -1 : void 0,
                    onClick: () => {
                        "edit" !== e && (a.unlock(), a.playEffect("next"), t.next())
                    },
                    className: "cppg-next",
                    children: (0, o.jsx)(l.FText, {
                        field: "continueLabel"
                    })
                })
            }

            function d({
                Back: e,
                Stage: t,
                Front: a
            } = {}) {
                return function() {
                    return (0, o.jsxs)("section", {
                        className: "cppg-ground",
                        children: [e ? (0, o.jsx)("div", {
                            "aria-hidden": !0,
                            className: "cppg-art-back",
                            children: (0, o.jsx)(e, {})
                        }) : null, (0, o.jsx)(l.FText, {
                            as: "h2",
                            field: "title",
                            className: "cppg-title font-(family-name:--f-display)"
                        }), (0, o.jsxs)("div", {
                            className: "cppg-scene",
                            children: [t ? (0, o.jsx)("div", {
                                "aria-hidden": !0,
                                className: "cppg-art-stage",
                                children: (0, o.jsx)(t, {})
                            }) : null, (0, o.jsx)(l.Stack, {
                                id: "photos",
                                className: "cppg-fan"
                            })]
                        }), (0, o.jsx)(l.FText, {
                            as: "p",
                            field: "note",
                            className: "cppg-note"
                        }), (0, o.jsx)(s, {}), a ? (0, o.jsx)("div", {
                            "aria-hidden": !0,
                            className: "cppg-art-front",
                            children: (0, o.jsx)(a, {})
                        }) : null]
                    })
                }
            }
            let c = [{
                    id: "1543852786-1cf6624b9987",
                    alt: "A happy cat in a yellow bandana, smiling"
                }, {
                    id: "1533738363-b7f9aef128ce",
                    alt: "A grey cat wearing round sunglasses"
                }, {
                    id: "1592194996308-7b43878e84a6",
                    alt: "A small kitten waving one paw"
                }],
                u = (e, t) => ({
                    kind: "photo",
                    values: {
                        photo: (0, r.pM)(c[e].id, 800),
                        alt: c[e].alt,
                        caption: t
                    }
                }),
                p = {
                    label: "Our photos",
                    description: "Up to three of your photos as polaroids that sway in 3D, each with a caption.",
                    category: "gallery",
                    entrance: "rise",
                    fields: [(0, r.Qq)("title", "Title", "A few favourite moments", 40), (0, r.Qq)("note", "Line under the photos", "Some days are just too good to forget.", 80), (0, r.Qq)("continueLabel", "Next button", "Keep going", 24)],
                    items: {
                        photo: {
                            label: "Photo",
                            fields: [(0, r.Sl)("photo", "Photo", ""), (0, r.Qq)("alt", "Photo description", "A favourite photo", 120), (0, r.Qq)("caption", "Caption", "This day", 30)],
                            render: function() {
                                let e = (0, l.useMode)(),
                                    t = (0, l.useAssetUrl)("photo");
                                return (0, o.jsxs)("figure", {
                                    className: "cppg-card",
                                    children: [(0, o.jsx)("div", {
                                        className: "cppg-frame",
                                        children: t || "edit" === e ? (0, o.jsx)(l.FImage, {
                                            field: "photo",
                                            altField: "alt",
                                            className: "cppg-img"
                                        }) : (0, o.jsx)(n, {})
                                    }), (0, o.jsx)(l.FText, {
                                        as: "figcaption",
                                        field: "caption",
                                        className: "cppg-caption"
                                    })]
                                })
                            }
                        }
                    },
                    stacks: {
                        photos: {
                            label: "Photos",
                            accepts: ["photo"],
                            axis: "horizontal",
                            min: 1,
                            max: 3,
                            defaults: [u(0, "This day"), u(1, "Us, being us"), u(2, "My favourite")]
                        }
                    },
                    render: d()
                };

            function h({
                title: e,
                note: t,
                continueLabel: a,
                captions: o,
                photos: l,
                ...i
            }) {
                return { ...p,
                    fields: [(0, r.Qq)("title", "Title", e, 40), (0, r.Qq)("note", "Line under the photos", t, 80), (0, r.Qq)("continueLabel", "Next button", a, 24)],
                    stacks: {
                        photos: { ...p.stacks.photos,
                            defaults: o.map((e, t) => l ? {
                                kind: "photo",
                                values: {
                                    photo: l[t].src,
                                    alt: l[t].alt,
                                    caption: e
                                }
                            } : u(t, e))
                        }
                    },
                    render: d(i)
                }
            }
            let m = {
                id: "photos",
                title: "Photos",
                fields: [{
                    kind: "stack",
                    sectionType: "gallery",
                    stackId: "photos",
                    fieldIds: ["photo", "caption"],
                    label: "Photos",
                    hint: "Up to 3. Tap a photo to swap in your own."
                }]
            }
        },
        63054: (e, t, a) => {
            "use strict";
            a.d(t, {
                WorldEnter: () => S,
                WorldStage: () => $
            });
            var o = a(73365);
            a(91288), a(2313), a(82841), a(84135), a(9632), a(65829), a(11722);
            var l = a(1521),
                i = a(34768),
                r = a(82161),
                n = a(36744);

            function s({
                index: e,
                memory: t,
                family: a
            }) {
                let l = (0, i.useAssetUrl)((0, n.Te)(e, "Photo")),
                    r = (0, i.useText)((0, n.Te)(e, "PhotoAlt"));
                return (0, o.jsxs)("li", {
                    className: "wd-fb-card",
                    children: [(0, o.jsx)("div", {
                        className: "wd-card-photo",
                        children: l ? (0, o.jsx)("img", {
                            src: l,
                            alt: r,
                            loading: "lazy",
                            draggable: !1
                        }) : (0, o.jsx)("div", {
                            className: "wd-card-empty",
                            "aria-hidden": !0,
                            children: (0, o.jsx)("span", {
                                children: a ? "\uD83E\uDE94" : "\u2665"
                            })
                        })
                    }), (0, o.jsx)("p", {
                        className: "wd-eyebrow",
                        children: t.title
                    }), (0, o.jsx)(i.FText, {
                        as: "h3",
                        field: (0, n.Te)(e, "Caption"),
                        className: "wd-card-caption"
                    }), (0, o.jsx)(i.FText, {
                        as: "p",
                        field: (0, n.Te)(e, "Line"),
                        className: "wd-card-line"
                    })]
                })
            }

            function d({
                memories: e,
                family: t
            }) {
                let a = (0, i.useStory)(),
                    l = (0, r.useFolioSound)(),
                    n = (0, i.useSite)() ? .document.pages[0] ? .sections.find(e => "cover" === e.type) ? .values ? ? {},
                    c = [n.fromName, n.fromFallback].map(e => "string" == typeof e ? e.trim() : "").find(Boolean) ? ? "";
                return (0, o.jsxs)("div", {
                    className: "wd-fallback",
                    children: [(0, o.jsx)(i.FText, {
                        as: "p",
                        field: "chooseTitle",
                        className: "wd-fb-kicker"
                    }), (0, o.jsx)("ol", {
                        className: "wd-fb-row",
                        "aria-label": "Memories",
                        children: e.map((e, a) => (0, o.jsx)(s, {
                            index: a,
                            memory: e,
                            family: t
                        }, a))
                    }), (0, o.jsxs)("div", {
                        className: "wd-letter-paper",
                        children: [(0, o.jsx)(i.FText, {
                            as: "p",
                            field: "letterGreeting",
                            className: "wd-letter-greeting"
                        }), (0, o.jsx)(i.FText, {
                            as: "div",
                            field: "letterBody",
                            className: "wd-letter-body"
                        }), (0, o.jsxs)("div", {
                            className: "wd-letter-sign",
                            children: [(0, o.jsx)(i.FText, {
                                as: "p",
                                field: "letterSignoff",
                                className: "wd-letter-signoff"
                            }), c ? (0, o.jsx)("p", {
                                className: "wd-letter-name",
                                children: c
                            }) : null]
                        })]
                    }), (0, o.jsxs)("div", {
                        className: "wd-fb-end",
                        children: [(0, o.jsx)(i.FText, {
                            as: "p",
                            field: "finaleLine",
                            className: "wd-finale-line"
                        }), (0, o.jsx)("button", {
                            type: "button",
                            className: "wd-btn wd-btn-solid",
                            onClick: () => {
                                l.unlock(), l.playEffect("next"), a.next()
                            },
                            children: (0, o.jsx)(i.FText, {
                                field: "finaleButton"
                            })
                        })]
                    })]
                })
            }
            let c = "Continue",
                u = "Menu",
                p = "World sounds",
                h = "Quality",
                m = "The letter";

            function f({
                onMove: e
            }) {
                let t = (0, l.useRef)(null),
                    [a, i] = (0, l.useState)([0, 0]),
                    r = (0, l.useRef)(-1),
                    n = a => {
                        let o = t.current ? .getBoundingClientRect();
                        if (!o) return;
                        let l = o.width / 2,
                            r = (a.clientX - o.left - l) / l,
                            n = (a.clientY - o.top - l) / l,
                            s = Math.hypot(r, n);
                        s > 1 && (r /= s, n /= s), i([r, n]), e(r, -n)
                    },
                    s = () => {
                        r.current = -1, i([0, 0]), e(0, 0)
                    };
                return (0, o.jsx)("div", {
                    ref: t,
                    className: "wd-stick",
                    role: "presentation",
                    onPointerDown: e => {
                        r.current = e.pointerId, e.currentTarget.setPointerCapture(e.pointerId), n(e)
                    },
                    onPointerMove: e => {
                        e.pointerId === r.current && n(e)
                    },
                    onPointerUp: s,
                    onPointerCancel: s,
                    children: (0, o.jsx)("span", {
                        className: "wd-stick-knob",
                        style: {
                            transform: `translate(${34*a[0]}px, ${34*a[1]}px)`
                        }
                    })
                })
            }

            function b({
                index: e,
                memory: t,
                last: a,
                onClose: l,
                tour: r,
                family: s
            }) {
                let d = (0, i.useAssetUrl)((0, n.Te)(e, "Photo")),
                    u = (0, i.useText)((0, n.Te)(e, "PhotoAlt"));
                return (0, o.jsxs)("div", {
                    className: "wd-sheet wd-card",
                    role: "dialog",
                    "aria-modal": "false",
                    "aria-label": t.title,
                    children: [(0, o.jsx)("div", {
                        className: "wd-card-photos",
                        children: (0, o.jsx)("div", {
                            className: "wd-card-photo",
                            children: d ? (0, o.jsx)("img", {
                                src: d,
                                alt: u,
                                draggable: !1
                            }) : (0, o.jsx)("div", {
                                className: "wd-card-empty",
                                "aria-hidden": !0,
                                children: (0, o.jsx)("span", {
                                    children: s ? "\uD83E\uDE94" : "\u2665"
                                })
                            })
                        })
                    }), (0, o.jsxs)("div", {
                        className: "wd-card-body",
                        children: [(0, o.jsx)("p", {
                            className: "wd-eyebrow",
                            children: t.title
                        }), (0, o.jsx)(i.FText, {
                            as: "h3",
                            field: (0, n.Te)(e, "Caption"),
                            className: "wd-card-caption"
                        }), (0, o.jsx)(i.FText, {
                            as: "p",
                            field: (0, n.Te)(e, "Line"),
                            className: "wd-card-line"
                        }), (0, o.jsx)("button", {
                            type: "button",
                            className: "wd-btn wd-btn-solid",
                            onClick: l,
                            children: a ? c : r ? "Next memory" : "Keep exploring"
                        })]
                    })]
                })
            }

            function w({
                fromName: e,
                onDone: t
            }) {
                return (0, o.jsxs)("div", {
                    className: "wd-letter",
                    role: "dialog",
                    "aria-modal": "false",
                    "aria-label": m,
                    children: [(0, o.jsxs)("div", {
                        className: "wd-letter-paper",
                        children: [(0, o.jsx)(i.FText, {
                            as: "p",
                            field: "letterGreeting",
                            className: "wd-letter-greeting"
                        }), (0, o.jsx)(i.FText, {
                            as: "div",
                            field: "letterBody",
                            className: "wd-letter-body"
                        }), (0, o.jsxs)("div", {
                            className: "wd-letter-sign",
                            children: [(0, o.jsx)(i.FText, {
                                as: "p",
                                field: "letterSignoff",
                                className: "wd-letter-signoff"
                            }), e ? (0, o.jsx)("p", {
                                className: "wd-letter-name",
                                children: e
                            }) : null]
                        })]
                    }), (0, o.jsx)("button", {
                        type: "button",
                        className: "wd-btn wd-btn-solid",
                        onClick: t,
                        children: c
                    })]
                })
            }

            function g({
                state: e,
                actions: t,
                reduced: a,
                quality: l,
                volume: n,
                host: s,
                onClose: d
            }) {
                let c = (0, r.useFolioSound)(),
                    m = (0, i.useSite)(),
                    f = !!m ? .document.sound ? .src,
                    b = s ? .ownerDocument,
                    w = !!b ? .fullscreenEnabled && "function" == typeof s ? .requestFullscreen,
                    y = "explore" === e.phase || "card" === e.phase || "look" === e.phase || "action" === e.phase,
                    x = (e, t, a) => (0, o.jsxs)("button", {
                        type: "button",
                        className: "wd-row",
                        "aria-pressed": e,
                        onClick: () => t(!e),
                        children: [(0, o.jsx)("span", {
                            children: a
                        }), (0, o.jsx)("span", {
                            className: "wd-pill",
                            "data-on": e ? "" : void 0,
                            children: e ? "On" : "Off"
                        })]
                    });
                return (0, o.jsxs)("div", {
                    className: "wd-sheet wd-menu",
                    role: "dialog",
                    "aria-modal": "false",
                    "aria-label": u,
                    children: [(0, o.jsx)("div", {
                        className: "wd-menu-grip",
                        "aria-hidden": !0
                    }), f ? x(c.playing, () => c.toggle(), "Music") : null, (0, o.jsxs)("label", {
                        className: "wd-row",
                        children: [(0, o.jsx)("span", {
                            children: p
                        }), (0, o.jsx)("input", {
                            type: "range",
                            min: 0,
                            max: 1,
                            step: .05,
                            value: n,
                            onChange: e => t.setVolume(Number(e.target.value)),
                            "aria-label": p
                        })]
                    }), x(e.guide, t.setGuide, "Guide"), (0, o.jsxs)("div", {
                        className: "wd-row",
                        children: [(0, o.jsx)("span", {
                            children: h
                        }), (0, o.jsx)("span", {
                            className: "wd-seg",
                            role: "group",
                            "aria-label": h,
                            children: ["auto", "high", "low"].map(e => (0, o.jsx)("button", {
                                type: "button",
                                "aria-pressed": l === e,
                                onClick: () => t.setQuality(e),
                                children: "auto" === e ? "Auto" : "high" === e ? "High" : "Low"
                            }, e))
                        })]
                    }), x(a, t.setReducedMotion, "Reduce motion"), w ? (0, o.jsx)("button", {
                        type: "button",
                        className: "wd-row",
                        onClick: () => {
                            let e = s ? .parentElement ? ? s;
                            b ? .fullscreenElement ? b.exitFullscreen().catch(() => {}) : e ? .requestFullscreen().catch(() => {}), d()
                        },
                        children: (0, o.jsx)("span", {
                            children: "Full screen"
                        })
                    }) : null, y ? (0, o.jsx)("button", {
                        type: "button",
                        className: "wd-row",
                        onClick: () => {
                            t.choose("walk" === e.mode ? "tour" : "walk"), d()
                        },
                        children: (0, o.jsx)("span", {
                            children: "walk" === e.mode ? "Switch to the tour" : "Switch to walking"
                        })
                    }) : null, "letter" !== e.phase && "finale" !== e.phase ? (0, o.jsx)("button", {
                        type: "button",
                        className: "wd-row",
                        onClick: () => {
                            t.openLetter(), d()
                        },
                        children: (0, o.jsx)("span", {
                            children: "Skip to the letter"
                        })
                    }) : null, (0, o.jsx)("button", {
                        type: "button",
                        className: "wd-row",
                        onClick: () => {
                            t.replay(), d()
                        },
                        children: (0, o.jsx)("span", {
                            children: "Replay"
                        })
                    }), (0, o.jsx)("button", {
                        type: "button",
                        className: "wd-btn wd-btn-ghost",
                        onClick: d,
                        children: "Close"
                    })]
                })
            }

            function y({
                state: e,
                memories: t,
                actions: a,
                edit: r,
                reduced: n,
                quality: s,
                volume: d,
                host: p,
                family: h
            }) {
                let m, x, k, j, N, [v, T] = (0, l.useState)(!1),
                    [C, S] = (0, l.useState)(!0),
                    F = (k = (0, i.useSite)(), j = k ? .document.pages[0] ? .sections.find(e => "cover" === e.type) ? .values ? ? {}, {
                        to: (N = (e, t, a) => "string" == typeof e && e.trim() ? e.trim() : "string" == typeof t && t.trim() ? t.trim() : a)(j.toName, j.toFallback, "Jaan"),
                        from: N(j.fromName, j.fromFallback, "Me")
                    }),
                    $ = (0, i.useMode)(),
                    L = e.found.filter(Boolean).length,
                    P = t.length,
                    M = P > 0 && L === P,
                    {
                        phase: B
                    } = e;
                if ((0, l.useEffect)(() => {
                        if ("explore" !== B || "walk" !== e.mode) return;
                        let t = p ? .ownerDocument.defaultView;
                        if (!t) return;
                        let a = t.setTimeout(() => S(!1), 6e3);
                        return () => t.clearTimeout(a)
                    }, [B, e.mode, p]), r) return (0, o.jsx)("div", {
                    className: "wd-hud",
                    "data-edit": "",
                    children: (0, o.jsx)("p", {
                        className: "wd-chip wd-edit-note",
                        children: "Live 3D preview. Open the preview to walk it."
                    })
                });
                if (e.contextLost) return (0, o.jsx)("div", {
                    className: "wd-hud",
                    children: (0, o.jsx)("div", {
                        className: "wd-center",
                        children: (0, o.jsxs)("div", {
                            className: "wd-sheet wd-lost",
                            children: [(0, o.jsx)("p", {
                                children: "The world needs a moment."
                            }), (0, o.jsx)("button", {
                                type: "button",
                                className: "wd-btn wd-btn-solid",
                                onClick: a.reload,
                                children: "Tap to reload the world"
                            })]
                        })
                    })
                });
                let q = "explore" === B,
                    I = "loading" !== B && "ready" !== B && "intro" !== B,
                    Q = e.action,
                    A = null !== e.open ? t[e.open] : null;
                return (0, o.jsxs)("div", {
                    className: "wd-hud",
                    "data-mode": $,
                    children: ["loading" === B || "ready" === B ? (0, o.jsx)("div", {
                        className: "wd-center",
                        children: (0, o.jsxs)("div", {
                            className: "wd-loading",
                            children: [(0, o.jsx)("span", {
                                className: "wd-enter-bar",
                                children: (0, o.jsx)("span", {
                                    style: {
                                        transform: `scaleX(${e.progress})`
                                    }
                                })
                            }), (0, o.jsx)("p", {
                                children: "Building your world"
                            })]
                        })
                    }) : null, "intro" === B ? (0, o.jsxs)(o.Fragment, {
                        children: [(0, o.jsx)("div", {
                            className: "wd-title-card",
                            "data-reduced": n ? "" : void 0,
                            children: (0, o.jsxs)("p", {
                                className: "wd-title-names",
                                children: [F.to, " ", (0, o.jsx)("span", {
                                    "aria-hidden": !0,
                                    children: h ? "&" : "\u2665"
                                }), " ", F.from]
                            })
                        }), (0, o.jsx)("button", {
                            type: "button",
                            className: "wd-chip wd-skip",
                            onClick: a.skipIntro,
                            children: "Skip"
                        })]
                    }) : null, "choose" === B ? (0, o.jsx)("div", {
                        className: "wd-center wd-choose",
                        children: (0, o.jsxs)("div", {
                            className: "wd-sheet wd-choose-card",
                            children: [(0, o.jsx)(i.FText, {
                                as: "h2",
                                field: "chooseTitle",
                                className: "wd-choose-title"
                            }), (0, o.jsxs)("div", {
                                className: "wd-choose-buttons",
                                children: [(0, o.jsx)("button", {
                                    type: "button",
                                    className: "wd-btn wd-btn-solid",
                                    onClick: () => a.choose("walk"),
                                    children: (0, o.jsx)(i.FText, {
                                        field: "walkLabel"
                                    })
                                }), (0, o.jsx)("button", {
                                    type: "button",
                                    className: "wd-btn wd-btn-ghost",
                                    onClick: () => a.choose("tour"),
                                    children: (0, o.jsx)(i.FText, {
                                        field: "tourLabel"
                                    })
                                })]
                            })]
                        })
                    }) : null, I ? (0, o.jsxs)("div", {
                        className: "wd-top",
                        children: [P > 0 && "letter" !== B && "finale" !== B ? (0, o.jsx)("p", {
                            className: "wd-chip",
                            "aria-live": "polite",
                            children: M ? "You found them all" : (m = L, x = P, `${m} of ${x} memories`)
                        }) : (0, o.jsx)("span", {}), (0, o.jsx)("button", {
                            type: "button",
                            className: "wd-chip wd-menu-button",
                            "aria-expanded": v,
                            onClick: () => T(e => !e),
                            children: u
                        })]
                    }) : null, q && "walk" === e.mode ? (0, o.jsxs)(o.Fragment, {
                        children: [(0, o.jsx)(f, {
                            onMove: a.joystick
                        }), C ? (0, o.jsx)("p", {
                            className: "wd-hint",
                            children: "Drag to look around. Tap the ground or use the stick to walk."
                        }) : null, null !== e.near && t[e.near] ? (0, o.jsxs)("button", {
                            type: "button",
                            className: "wd-look",
                            onClick: a.look,
                            children: [(0, o.jsx)("span", {
                                className: "wd-look-title",
                                children: t[e.near].title
                            }), (0, o.jsx)("span", {
                                className: "wd-look-go",
                                children: "Look"
                            })]
                        }) : null]
                    }) : null, (q || "look" === B) && "tour" === e.mode ? (0, o.jsxs)("div", {
                        className: "wd-tourbar",
                        children: [(0, o.jsx)("button", {
                            type: "button",
                            className: "wd-btn wd-btn-ghost wd-btn-small",
                            onClick: a.tourBack,
                            children: "Back"
                        }), (0, o.jsx)("span", {
                            className: "wd-dots",
                            "aria-hidden": !0,
                            children: Array.from({
                                length: e.tourCount
                            }, (t, a) => (0, o.jsx)("span", {
                                "data-on": a === e.tourIndex ? "" : void 0
                            }, a))
                        }), (0, o.jsx)("button", {
                            type: "button",
                            className: "wd-chip wd-auto",
                            "aria-pressed": e.autoTour,
                            onClick: () => a.setAutoTour(!e.autoTour),
                            children: "Auto"
                        }), (0, o.jsx)("button", {
                            type: "button",
                            className: "wd-btn wd-btn-solid wd-btn-small",
                            onClick: a.tourNext,
                            children: "Next"
                        })]
                    }) : null, q && M ? (0, o.jsx)("button", {
                        type: "button",
                        className: "wd-btn wd-btn-solid wd-letter-cta",
                        onClick: a.openLetter,
                        children: "Read the letter"
                    }) : null, "action" === B && Q && t[Q.index] ? (0, o.jsx)("div", {
                        className: "wd-action-wrap",
                        children: (0, o.jsxs)("button", {
                            type: "button",
                            className: "wd-action",
                            onPointerDown: e => {
                                e.currentTarget.setPointerCapture(e.pointerId), a.actionDown()
                            },
                            onPointerUp: a.actionUp,
                            onPointerCancel: a.actionUp,
                            onKeyDown: e => {
                                ("Enter" === e.key || " " === e.key) && a.actionDown()
                            },
                            onKeyUp: a.actionUp,
                            children: ["hold" === Q.verb ? (0, o.jsx)("span", {
                                className: "wd-action-ring",
                                style: {
                                    "--p": Q.hold
                                },
                                "aria-hidden": !0
                            }) : null, (0, o.jsx)("span", {
                                children: t[Q.index].action ? ? c
                            })]
                        })
                    }) : null, "card" === B && null !== e.open && A ? (0, o.jsx)(b, {
                        index: e.open,
                        memory: A,
                        last: M,
                        tour: "tour" === e.mode,
                        family: h,
                        onClose: () => {
                            a.closeCard(), M && a.openLetter()
                        }
                    }) : null, "letter" === B ? (0, o.jsx)(w, {
                        fromName: F.from,
                        onDone: a.closeLetter
                    }) : null, "finale" === B && e.finaleReady ? (0, o.jsxs)("div", {
                        className: "wd-finale",
                        children: [(0, o.jsx)(i.FText, {
                            as: "p",
                            field: "finaleLine",
                            className: "wd-finale-line"
                        }), (0, o.jsx)("button", {
                            type: "button",
                            className: "wd-btn wd-btn-solid",
                            onClick: a.finish,
                            children: (0, o.jsx)(i.FText, {
                                field: "finaleButton"
                            })
                        })]
                    }) : null, v ? (0, o.jsx)(g, {
                        state: e,
                        actions: a,
                        reduced: n,
                        quality: s,
                        volume: d,
                        host: p,
                        onClose: () => T(!1)
                    }) : null]
                })
            }

            function x({
                memories: e
            }) {
                return (0, o.jsxs)("div", {
                    className: "wd-edit",
                    children: [(0, o.jsxs)("div", {
                        className: "wd-edit-choose",
                        children: [(0, o.jsx)(i.FText, {
                            as: "p",
                            field: "chooseTitle",
                            className: "wd-edit-strong"
                        }), (0, o.jsxs)("span", {
                            className: "wd-edit-pills",
                            children: [(0, o.jsx)(i.FText, {
                                field: "walkLabel",
                                className: "wd-pill"
                            }), (0, o.jsx)(i.FText, {
                                field: "tourLabel",
                                className: "wd-pill"
                            })]
                        })]
                    }), (0, o.jsx)("ol", {
                        className: "wd-edit-memories",
                        children: e.map((e, t) => {
                            let a;
                            return (0, o.jsxs)("li", {
                                className: "wd-edit-memory",
                                children: [(0, o.jsx)("div", {
                                    className: "wd-edit-photo",
                                    children: (0, o.jsx)(i.FImage, {
                                        field: (0, n.Te)(t, "Photo"),
                                        altField: (0, n.Te)(t, "PhotoAlt"),
                                        className: "block size-full object-cover"
                                    })
                                }), (0, o.jsxs)("div", {
                                    className: "wd-edit-text",
                                    children: [(0, o.jsxs)("p", {
                                        className: "wd-eyebrow",
                                        children: [(a = t + 1, `Memory ${a}`), ": ", e.title]
                                    }), (0, o.jsx)(i.FText, {
                                        as: "p",
                                        field: (0, n.Te)(t, "Caption"),
                                        className: "wd-edit-strong"
                                    }), (0, o.jsx)(i.FText, {
                                        as: "p",
                                        field: (0, n.Te)(t, "Line"),
                                        className: "wd-edit-line"
                                    })]
                                })]
                            }, t)
                        })
                    }), (0, o.jsxs)("div", {
                        className: "wd-edit-letter",
                        children: [(0, o.jsx)("p", {
                            className: "wd-eyebrow",
                            children: m
                        }), (0, o.jsx)(i.FText, {
                            as: "p",
                            field: "letterGreeting",
                            className: "wd-edit-strong"
                        }), (0, o.jsx)(i.FText, {
                            as: "div",
                            field: "letterBody",
                            className: "wd-letter-body"
                        }), (0, o.jsx)(i.FText, {
                            as: "p",
                            field: "letterSignoff",
                            className: "wd-edit-line"
                        })]
                    }), (0, o.jsxs)("div", {
                        className: "wd-edit-letter",
                        children: [(0, o.jsx)("p", {
                            className: "wd-eyebrow",
                            children: "The finale"
                        }), (0, o.jsx)(i.FText, {
                            as: "p",
                            field: "finaleLine",
                            className: "wd-edit-strong"
                        }), (0, o.jsx)(i.FText, {
                            field: "finaleButton",
                            className: "wd-pill"
                        })]
                    })]
                })
            }
            var k = a(84100);
            let j = "cp-world-progress",
                N = {
                    park: () => Promise.all([a.e(62460), a.e(63962), a.e(60724)]).then(a.bind(a, 60724)),
                    river: () => Promise.all([a.e(62460), a.e(72746), a.e(63962), a.e(73908)]).then(a.bind(a, 73908)),
                    rain: () => Promise.all([a.e(62460), a.e(72746), a.e(63962), a.e(30494), a.e(82527), a.e(57362)]).then(a.bind(a, 57362)),
                    rooftop: () => Promise.all([a.e(62460), a.e(72746), a.e(63962), a.e(23445), a.e(29703), a.e(86369)]).then(a.bind(a, 86369)),
                    diwali: () => Promise.all([a.e(62460), a.e(72746), a.e(63962), a.e(23445), a.e(29703), a.e(89539)]).then(a.bind(a, 89539)),
                    haveli: () => Promise.all([a.e(62460), a.e(63962), a.e(23445), a.e(72260)]).then(a.bind(a, 72260))
                },
                v = () => Promise.all([a.e(62460), a.e(72746), a.e(63962), a.e(94145), a.e(30494), a.e(82527), a.e(46553)]).then(a.bind(a, 46553)),
                T = n.Dl.flatMap(e => [`a${e}`, `b${e}`]);

            function C(e) {
                return !!e ? .ownerDocument.defaultView ? .matchMedia ? .("(prefers-reduced-motion: reduce)").matches
            }

            function S({
                world: e,
                label: t,
                loading: a,
                buttonClassName: n
            }) {
                let s = (0, i.useMode)(),
                    d = (0, i.useStory)(),
                    c = (0, r.useFolioSound)(),
                    u = (0, l.useRef)(null),
                    [p, h] = (0, l.useState)(0);
                (0, l.useEffect)(() => {
                    if ("edit" === s) return;
                    v().catch(() => {}), N[e]().catch(() => {});
                    let t = u.current ? .closest("[data-folio-root]");
                    if (!t) return;
                    let a = e => h(Math.max(0, Math.min(1, Number(e.detail ? .progress) || 0)));
                    return t.addEventListener(j, a), () => t.removeEventListener(j, a)
                }, [s, e]);
                let m = "edit" !== s && p > 0 && p < 1;
                return (0, o.jsxs)("div", {
                    ref: u,
                    className: "mt-7 flex flex-col items-center gap-3",
                    children: [(0, o.jsx)("button", {
                        type: "button",
                        tabIndex: "edit" === s ? -1 : void 0,
                        className: n,
                        onClick: () => {
                            "edit" !== s && (c.unlock(), c.playEffect("open"), d.next())
                        },
                        children: t
                    }), (0, o.jsxs)("div", {
                        className: "wd-enter-load",
                        "data-on": m || "edit" === s ? "" : void 0,
                        "aria-hidden": !m,
                        children: [(0, o.jsx)("span", {
                            className: "wd-enter-bar",
                            children: (0, o.jsx)("span", {
                                style: {
                                    transform: `scaleX(${"edit"===s?.6:p})`
                                }
                            })
                        }), (0, o.jsx)("span", {
                            className: "wd-enter-label",
                            children: a
                        })]
                    })]
                })
            }
            let F = {
                phase: "loading",
                mode: "walk",
                found: [],
                near: null,
                open: null,
                target: 0,
                tourIndex: 0,
                tourCount: 0,
                progress: 0,
                quality: "high",
                qualityChoice: "auto",
                fps: 60,
                drawCalls: 0,
                action: null,
                finaleReady: !1,
                contextLost: !1,
                autoTour: !0,
                guide: !0,
                walking: !1
            };

            function $({
                world: e,
                memories: t
            }) {
                var a, s;
                let c, u, p, h, m, f, b, w, g, S, L, P, M, B, q, I = "edit" === (0, i.useMode)(),
                    Q = (0, i.useStory)(),
                    A = (0, r.useFolioSound)(),
                    D = (0, l.useRef)(null),
                    E = (0, l.useRef)(null),
                    [R, G] = (0, l.useState)(null),
                    [W, H] = (0, l.useState)({ ...F,
                        found: t.map(() => !1)
                    }),
                    [_, O] = (0, l.useState)(!1),
                    [U, Y] = (0, l.useState)(0),
                    [K, z] = (0, l.useState)(null),
                    [V, X] = (0, l.useState)("auto"),
                    [J, Z] = (0, l.useState)(.7),
                    ee = (a = t.length, s = "cover", c = (0, i.useSite)(), u = (0, i.useTemplate)(), p = (0, l.useMemo)(() => {
                        let e = {};
                        for (let t of u ? .sections[s] ? .fields ? ? []) e[t.id] = t.default;
                        let t = c ? .document.pages[0] ? .sections.find(e => e.type === s);
                        return { ...e,
                            ...t ? .values ? ? {}
                        }
                    }, [c, u, s]), h = (0, i.useSite)(), m = (0, i.useTemplate)(), f = (0, i.useAssetResolver)(), b = (0, l.useMemo)(() => [...T, "petKind", "petCoat", "petName", "decor1", "decor2", "decor1Photo", "decor2Photo", "finaleLine", ...Array.from({
                        length: a
                    }, (e, t) => [(0, n.Te)(t, "Photo"), (0, n.Te)(t, "Caption")]).flat()], [a]), w = (0, i.useFieldValues)(b), L = Number.isFinite(S = Number((g = h ? .document.theme ? ? {}).mood ? ? m ? .tokens.mood ? .default ? ? 0)) ? Math.max(0, Math.min(2, Math.round(S))) : 0, P = m ? .tokens.accent ? .type === "color" ? m.tokens.accent.default : "#ff8fab", M = String(g.accent ? ? P), B = ["decor1Photo", "decor2Photo", ...Array.from({
                        length: a
                    }, (e, t) => (0, n.Te)(t, "Photo"))].map(e => f("string" == typeof w[e] ? w[e] : "")), q = JSON.stringify([p.toName, p.fromName, p.toFallback, p.fromFallback, p.voice, w, L, M, B]), (0, l.useMemo)(() => {
                        let e = e => "string" == typeof e ? e : "",
                            t = (t, a) => e(t).trim() ? e(t).trim() : a;
                        return {
                            toName: t(p.toName, t(p.toFallback, "")),
                            fromName: t(p.fromName, t(p.fromFallback, "")),
                            people: [(0, n.o2)(w, "a", n._v), (0, n.o2)(w, "b", n.f_)],
                            pet: (0, n._c)(w, n.Qj),
                            mood: L,
                            decor1: e(w.decor1),
                            decor2: e(w.decor2),
                            decor1Photo: f(e(w.decor1Photo)),
                            decor2Photo: f(e(w.decor2Photo)),
                            memoryPhotos: Array.from({
                                length: a
                            }, (t, a) => f(e(w[(0, n.Te)(a, "Photo")]))),
                            memoryCaptions: Array.from({
                                length: a
                            }, (t, a) => e(w[(0, n.Te)(a, "Caption")])),
                            finaleLine: e(w.finaleLine),
                            accent: /^#[0-9a-f]{6}$/i.test(M) ? M : "#ff8fab",
                            voice: e(p.voice)
                        }
                    }, [q])),
                    et = k.n8.find(t => t.world === e) ? .bond === "siblings",
                    ea = (0, i.useText)("stageLabel"),
                    eo = (0, l.useRef)(ee);
                (0, l.useEffect)(() => {
                    eo.current = ee
                }), (0, l.useEffect)(() => G(D.current), []);
                let el = K ? ? C(R);
                (0, l.useEffect)(() => {
                    if (!R || _) return;
                    let t = !1,
                        a = null,
                        o = R.closest("[data-folio-root]"),
                        l = e => o ? .dispatchEvent(new CustomEvent(j, {
                            detail: {
                                progress: e
                            }
                        }));
                    return l(.05), Promise.all([v(), N[e]()]).then(([e, o]) => {
                        if (!t) {
                            let i, r;
                            E.current = a = e.createWorldRuntime({
                                host: R,
                                spec: o.default,
                                values: eo.current,
                                fonts: (i = R.ownerDocument.defaultView ? .getComputedStyle(R), {
                                    display: (r = (e, t) => i ? .getPropertyValue(e).trim() || t)("--f-display", "Georgia, serif"),
                                    body: r("--f-body", "system-ui, sans-serif"),
                                    script: r("--f-script", "cursive")
                                }),
                                quality: V,
                                reducedMotion: C(R),
                                edit: I,
                                onState: e => {
                                    t || (H(e), l(e.progress))
                                },
                                onFallback: () => {
                                    t || O(!0)
                                }
                            }), a.setActive(!0)
                        }
                    }).catch(() => {
                        t || O(!0)
                    }), () => {
                        t = !0, a ? .dispose(), E.current = null
                    }
                }, [R, e, I, _, U]), (0, l.useEffect)(() => {
                    E.current ? .setValues(ee)
                }, [ee]);
                let ei = "ready" === W.phase;
                (0, l.useEffect)(() => {
                    if (I || !R || !ei) return;
                    let e = R.ownerDocument.defaultView;
                    if (!e ? .IntersectionObserver) return void E.current ? .start();
                    let t = new e.IntersectionObserver(e => {
                        e.some(e => e.isIntersecting) && (E.current ? .start(), t.disconnect())
                    });
                    return t.observe(R), () => t.disconnect()
                }, [I, R, ei]);
                let er = (0, l.useMemo)(() => ({
                    skipIntro: () => E.current ? .skipIntro(),
                    choose: e => {
                        A.unlock(), E.current ? .unlockAudio(), E.current ? .choose(e)
                    },
                    tourNext: () => E.current ? .tourNext(),
                    tourBack: () => E.current ? .tourBack(),
                    setAutoTour: e => E.current ? .setAutoTour(e),
                    look: () => E.current ? .look(),
                    closeCard: () => E.current ? .closeCard(),
                    actionDown: () => E.current ? .actionDown(),
                    actionUp: () => E.current ? .actionUp(),
                    openLetter: () => E.current ? .openLetter(),
                    closeLetter: () => E.current ? .closeLetter(),
                    replay: () => E.current ? .replay(),
                    setGuide: e => E.current ? .setGuide(e),
                    setQuality: e => {
                        X(e), E.current ? .setQuality(e)
                    },
                    setReducedMotion: e => {
                        z(e), E.current ? .setReducedMotion(e)
                    },
                    setVolume: e => {
                        Z(e), E.current ? .setVolume(e)
                    },
                    joystick: (e, t) => E.current ? .joystick(e, t),
                    reload: () => {
                        H({ ...F,
                            found: t.map(() => !1)
                        }), Y(e => e + 1)
                    },
                    finish: () => {
                        A.playEffect("next"), Q.next()
                    }
                }), [t, A, Q]);
                return _ ? (0, o.jsx)(d, {
                    memories: t,
                    family: et
                }) : (0, o.jsxs)("div", {
                    className: `wd-world${I?" wd-world-edit":""}`,
                    children: [(0, o.jsx)("div", {
                        ref: D,
                        className: "wd-stage",
                        "data-phase": W.phase,
                        "data-blur": "letter" === W.phase ? "" : void 0,
                        role: "region",
                        "aria-label": ea || void 0,
                        children: (0, o.jsx)(y, {
                            state: W,
                            memories: t,
                            actions: er,
                            edit: I,
                            reduced: el,
                            quality: V,
                            volume: J,
                            host: R,
                            family: et
                        })
                    }), I ? (0, o.jsx)(x, {
                        memories: t
                    }) : null]
                })
            }
        },
        65829: () => {},
        73327: (e, t, a) => {
            "use strict";
            a.d(t, {
                m: () => o,
                q: () => l
            });
            let o = {
                "cp-auto": {
                    "auto-chennai": [476, 332],
                    "auto-delhi": [474, 331],
                    "auto-mumbai": [277, 193],
                    birds: [68, 41],
                    cloud: [116, 57],
                    "fare-ticket": [363, 430],
                    genda: [465, 355],
                    "meter-body": [208, 233],
                    "meter-flag": [132, 190],
                    mirror: [437, 465, [26.2, 5.6, 68.2, 67.1]],
                    "nimbu-mirchi": [87, 237],
                    palm: [207, 244],
                    skyline: [512, 90],
                    "smoke-hearts": [117, 80],
                    "stop-sign": [100, 215],
                    street: [404, 92],
                    wheel: [65, 66],
                    wire: [433, 190]
                },
                "cp-antakshari": {
                    dholak: [216, 154],
                    harmonium: [223, 177],
                    mic: [164, 330],
                    record: [422, 426, [29.6, 30, 40.8, 40.6]],
                    turntable: [265, 239]
                },
                "cp-balloon-shoot": {
                    "balloon-blue": [96, 121],
                    "balloon-red": [104, 132],
                    "balloon-yellow": [96, 122],
                    canopy: [512, 173],
                    "cork-gun": [48, 30],
                    pop: [139, 145]
                },
                "cp-band-baaja": {
                    arch: [445, 512, [19.3, 18.9, 61.3, 73]],
                    dhol: [282, 202],
                    "marigold-string": [107, 514],
                    petals: [470, 477],
                    shehnai: [204, 101],
                    trumpet: [300, 128]
                },
                "cp-barf-gola": {
                    awning: [512, 164],
                    bottle: [65, 218],
                    "gola-kala": [260, 407],
                    "gola-mango": [260, 395],
                    "gola-ice": [260, 400],
                    "gola-rose": [260, 400]
                },
                "cp-bioscope": {
                    box: [451, 406, [30.2, 32.5, 39.7, 43.8]],
                    crank: [199, 119],
                    curtains: [490, 486],
                    popcorn: [165, 248],
                    slide: [466, 245, [16.3, 22.4, 67.4, 56.7]],
                    ticket: [223, 124]
                },
                "cp-carrom": {
                    board: [453, 440],
                    "coin-black": [108, 108],
                    "coin-white": [65, 65],
                    frame: [451, 454, [15.7, 15.6, 68.5, 68.5]],
                    queen: [169, 169],
                    striker: [108, 108]
                },
                "cp-cassette": {
                    headphones: [266, 343],
                    pencil: [182, 190],
                    reel: [106, 104],
                    "shell-black": [475, 307],
                    "shell-clear": [473, 305],
                    "shell-pink": [250, 163]
                },
                "cp-chaat": {
                    anaar: [191, 157],
                    dahi: [201, 168],
                    dona: [487, 443],
                    imli: [201, 172],
                    plate: [512, 445],
                    sev: [316, 271]
                },
                "cp-chai-tapri": {
                    biscuit: [188, 125],
                    "glass-empty": [342, 404],
                    "glass-full": [139, 164],
                    kettle: [324, 317],
                    kulhad: [260, 268],
                    "menu-board": [476, 410]
                },
                "cp-cycle": {
                    bell: [100, 83],
                    "cycle-black": [221, 150],
                    "cycle-pink": [210, 144],
                    "cycle-racer": [445, 321],
                    milestone: [135, 192],
                    wheel: [100, 101]
                },
                "cp-diwali-dabba": {
                    agarbatti: [296, 470],
                    anar: [302, 419],
                    chakri: [384, 280],
                    "dabba-closed": [391, 389],
                    "dabba-open": [416, 462],
                    "diya-brass": [377, 339],
                    "diya-clay": [391, 276],
                    "envelope-open": [392, 408],
                    "envelope-sealed": [424, 308],
                    ghanti: [239, 443],
                    jalebi: [447, 401],
                    jharokha: [443, 509, [23.5, 23.8, 55.3, 53.8]],
                    "kaju-katli": [434, 303],
                    "kandil-hex": [267, 512, [31.2, 33.8, 42.1, 21.6]],
                    "kandil-star": [386, 512, [30.3, 33.8, 39.8, 29.9]],
                    laddoo: [392, 387],
                    "mithai-box": [473, 483],
                    phuljhadi: [304, 431],
                    "phuljhadi-box": [453, 375],
                    polaroid: [331, 428, [7.9, 6.1, 84.3, 52.1]],
                    rangoli: [459, 455, [37.3, 37.1, 27.2, 27]],
                    rocket: [162, 465],
                    toran: [512, 208],
                    urli: [512, 346]
                },
                "cp-diya": {
                    arch: [426, 512, [20.2, 21.1, 59.6, 67]],
                    "diya-unlit": [204, 124],
                    "diya-wick": [234, 139],
                    flame: [48, 113],
                    lamp: [113, 227],
                    petals: [381, 243]
                },
                "cp-filmy-poster": {
                    badge: [206, 206],
                    "film-reel": [204, 188],
                    "paper-strip": [512, 173],
                    popcorn: [182, 247],
                    "poster-frame": [384, 512, [19.3, 22.9, 61.2, 60.7]],
                    spotlight: [287, 293]
                },
                "cp-gali-cricket": {
                    bails: [96, 32],
                    ball: [104, 104],
                    bat: [96, 508],
                    "cake-chair": [216, 294],
                    scoreboard: [428, 263],
                    stumps: [91, 164]
                },
                "cp-holi": {
                    "gulal-blue": [214, 160],
                    "gulal-green": [201, 147],
                    "gulal-pink": [227, 167],
                    "gulal-yellow": [227, 169],
                    kurta: [335, 495],
                    pichkari: [256, 145]
                },
                "cp-inland-letter": {
                    letter: [237, 190],
                    postbox: [180, 291],
                    "rubber-stamp": [156, 181],
                    "stamp-lotus": [417, 434],
                    "stamp-peacock": [184, 181],
                    "stamp-tiger": [429, 436]
                },
                "cp-jalebi": {
                    chaashni: [87, 76],
                    "gulab-jamun": [238, 212],
                    imarti: [454, 434],
                    jalebi: [197, 188],
                    kadhai: [512, 341],
                    potli: [167, 287]
                },
                "cp-jhoola": {
                    bulbs: [512, 95],
                    "cabin-pink": [96, 123],
                    "cabin-teal": [96, 123],
                    "cabin-yellow": [96, 123],
                    stand: [424, 431],
                    wheel: [450, 450]
                },
                "cp-kaan-pakad": {
                    bell: [138, 227],
                    blackboard: [489, 358],
                    chalk: [409, 311],
                    duster: [165, 124],
                    "heart-meter": [161, 400],
                    ruler: [475, 363]
                },
                "cp-kanche": {
                    frame: [467, 468, [15.2, 14.3, 70, 70.1]],
                    "marble-amber": [113, 111],
                    "marble-blue": [87, 86],
                    "marble-cats-eye": [78, 77],
                    "marble-green": [65, 64],
                    pouch: [232, 200]
                },
                "cp-lottery": {
                    coins: [255, 205],
                    "copper-coin": [259, 473],
                    frame: [468, 470, [16.9, 17.4, 66.2, 65.7]],
                    gift: [249, 257],
                    rosette: [113, 146],
                    "scratch-panel": [477, 273]
                },
                "cp-ludo": {
                    die: [143, 151],
                    frame: [411, 416, [19.7, 18.8, 61.6, 62.3]],
                    "pawn-blue": [72, 110],
                    "pawn-green": [137, 210],
                    "pawn-red": [72, 110],
                    "pawn-yellow": [72, 110]
                },
                "cp-matka-kulfi": {
                    "kulfi-gulab": [140, 271],
                    "kulfi-kesar": [195, 374],
                    "kulfi-pista": [199, 382],
                    lid: [370, 226],
                    "matka-open": [438, 434],
                    "matka-sealed": [198, 198]
                },
                "cp-patakhe": {
                    agarbatti: [76, 490],
                    anaar: [150, 211],
                    burst: [447, 440],
                    chakri: [152, 125],
                    rocket: [57, 246],
                    sparkler: [216, 342]
                },
                "cp-patang": {
                    charkhi: [182, 157],
                    "kite-pink": [199, 260],
                    "kite-rival": [188, 237],
                    "kite-torn": [188, 208],
                    "kite-yellow": [184, 242],
                    pigeon: [117, 119]
                },
                "cp-rail-gaadi": {
                    "coach-rajdhani": [491, 201],
                    "coach-sleeper": [279, 111],
                    "coach-toy": [496, 200],
                    "platform-board": [433, 393],
                    shutter: [442, 402],
                    ticket: [467, 239]
                },
                "cp-rakhi": {
                    "kaju-katli": [340, 313],
                    "rakhi-photo": [494, 308, [39.1, 32.5, 21.9, 34.1]],
                    "rakhi-plain": [303, 190],
                    roli: [169, 155],
                    thali: [324, 249],
                    thread: [251, 29]
                },
                "cp-rangoli": {
                    "bowl-blue": [139, 130],
                    "bowl-green": [139, 131],
                    "bowl-pink": [156, 146],
                    "bowl-yellow": [139, 129],
                    diya: [195, 180],
                    marigold: [117, 113]
                },
                "cp-saanp-seedhi": {
                    crown: [182, 148],
                    ladder: [121, 291],
                    "snake-green": [234, 378],
                    "snake-orange": [208, 234],
                    token: [54, 84],
                    trophy: [160, 159]
                },
                "cp-slam-book": {
                    "book-closed": [401, 475],
                    "book-open": [512, 335],
                    flower: [206, 241],
                    "gel-pen": [277, 367],
                    stickers: [152, 203],
                    washi: [178, 154]
                }
            };

            function l(e, t) {
                return `https://cdn.cutiepage.in/template-seeds/${e}/art/${t}-v2.webp`
            }
        },
        78874: (e, t, a) => {
            "use strict";
            a.d(t, {
                B: () => o,
                Y: () => l
            });
            let o = {
                anaar: [314, 474],
                "auto-black": [386, 367],
                "auto-pink": [382, 372],
                balloons: [349, 464],
                "bandhani-gift": [388, 392],
                bandmaster: [363, 498],
                bangles: [370, 331],
                bioscope: [386, 460],
                boombox: [406, 344],
                "carrom-board": [422, 362],
                "carrom-coins": [351, 337],
                "carrom-queen": [309, 299],
                cassette: [397, 347],
                chakri: [420, 332],
                charkhi: [319, 434],
                clapper: [349, 409],
                "cotton-candy": [299, 463],
                "cricket-bat": [308, 453],
                "cutting-chai": [281, 376],
                "cycle-black": [414, 343],
                "cycle-pink": [384, 380],
                "dahi-bhalla": [419, 394],
                "desi-cake": [385, 415],
                dhol: [392, 423],
                dice: [351, 335],
                "diya-brass": [363, 360],
                "diya-clay": [358, 361],
                firki: [304, 447],
                gajra: [353, 381],
                "galaxy-marble": [338, 340],
                ghodi: [400, 501],
                "giant-wheel": [360, 442],
                "gola-kala-khatta": [271, 433],
                "gola-mango": [272, 433],
                "gola-rose": [267, 433],
                "gulab-jamun": [424, 372],
                "gulal-cloud": [384, 401],
                "gulal-thali": [419, 297],
                "holi-kurta": [334, 465],
                imarti: [369, 339],
                "inland-letter": [390, 365],
                jalebi: [381, 346],
                jhumka: [407, 364],
                "kaan-pakad-kid": [295, 470],
                kabootar: [412, 368],
                kandil: [324, 491],
                kettle: [432, 490],
                "kite-pink": [360, 460],
                "kite-teal": [333, 468],
                "kulfi-malai": [300, 459],
                "kulfi-matka": [371, 391],
                "kulfi-rose": [307, 460],
                "kulhad-chai": [299, 437],
                ladder: [337, 433],
                "lottery-ticket": [424, 279],
                "ludo-board": [409, 375],
                "ludo-tokens": [388, 347],
                marbles: [388, 358],
                "marigold-heart": [411, 365],
                mic: [240, 436],
                milestone: [359, 368],
                "mithai-thali": [409, 350],
                paan: [374, 368],
                "papdi-chaat": [421, 336],
                phuljhadi: [336, 428],
                pichkari: [388, 306],
                popcorn: [340, 430],
                postbox: [226, 435],
                "rail-coach": [382, 333],
                "rakhi-cartoon": [357, 331],
                "rakhi-pearl": [375, 313],
                "rakhi-zari": [385, 309],
                rangoli: [381, 357],
                rusk: [346, 372],
                "saanp-seedhi-board": [414, 398],
                "slam-book": [362, 424],
                snake: [328, 414],
                stamp: [317, 351],
                "steam-engine": [364, 425],
                "steel-chai": [287, 381],
                stumps: [299, 425],
                "tape-ball": [346, 346],
                "taxi-meter": [330, 390],
                teddy: [343, 415],
                toran: [436, 358],
                trophy: [373, 399],
                "water-balloons": [363, 375],
                "wheel-cabin": [304, 433],
                "sorry-parcel": [400, 376],
                "sorry-scooter": [400, 396],
                "sorry-pin": [335, 400],
                "sorry-doorbell": [356, 364],
                "sorry-glass-heart": [400, 357],
                "sorry-clipboard": [358, 400],
                "sorry-stamp": [333, 400],
                "sorry-envelope": [400, 332],
                "sorry-bug": [375, 386],
                "sorry-undo": [365, 357],
                "sorry-wrench-heart": [383, 356],
                "sorry-download": [400, 317],
                "sorry-battery": [400, 250],
                "sorry-shield": [337, 369],
                "sorry-rocket": [359, 370],
                "sorry-phone": [338, 400]
            };

            function l(e) {
                return `https://cdn.cutiepage.in/static/mini-stickers/${e}-v1.webp`
            }
        },
        82841: () => {},
        84100: (e, t, a) => {
            "use strict";
            a.d(t, {
                n8: () => o
            });
            let o = [{
                key: "cp-world-park",
                exportName: "cpWorldParkTemplate",
                name: "Picnic in the Park",
                category: "Love",
                prefix: "wdpk-",
                world: "park"
            }, {
                key: "cp-world-river",
                exportName: "cpWorldRiverTemplate",
                name: "Lanterns by the River",
                category: "Love",
                prefix: "wdrv-",
                world: "river"
            }, {
                key: "cp-world-rain",
                exportName: "cpWorldRainTemplate",
                name: "Rainy Night Walk",
                category: "Love",
                prefix: "wdrn-",
                world: "rain"
            }, {
                key: "cp-world-rooftop",
                exportName: "cpWorldRooftopTemplate",
                name: "Rooftop Under the Stars",
                category: "Love",
                prefix: "wdrt-",
                world: "rooftop"
            }, {
                key: "cp-world-diwali",
                exportName: "cpWorldDiwaliTemplate",
                name: "Diwali Night in 3D",
                category: "Festival",
                prefix: "wddw-",
                world: "diwali"
            }, {
                key: "cp-world-bhai-dooj",
                exportName: "cpWorldBhaiDoojTemplate",
                name: "Diyas at the Haveli",
                category: "Family",
                prefix: "wdbd-",
                world: "haveli",
                bond: "siblings"
            }];
            o.map(e => e.key)
        },
        84135: () => {},
        91288: () => {}
    }
]);