(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [82289], {
        8643: () => {},
        15563: (e, t, s) => {
            "use strict";
            s.r(t), s.d(t, {
                DurgaIntro: () => k,
                NavratriIntro: () => m,
                parseAt: () => l
            });
            var n = s(73365),
                a = s(1521),
                c = s(34768);

            function r({
                kind: e,
                children: t
            }) {
                let [s, l] = (0, a.useState)(!1);
                return "edit" === (0, c.useMode)() ? (0, n.jsx)(i, {
                    kind: e,
                    children: t
                }) : s ? null : (0, n.jsx)("div", {
                    "aria-hidden": !0,
                    className: `cpx-intro cpx-${e}`,
                    onClick: () => l(!0),
                    onAnimationEnd: e => {
                        e.target === e.currentTarget && l(!0)
                    },
                    children: t
                })
            }

            function i({
                kind: e,
                children: t
            }) {
                let s = (0, a.useRef)(null),
                    r = (0, a.useRef)(void 0),
                    l = !1 === (0, c.useField)("introOn"),
                    [o, d] = (0, a.useState)(!1),
                    [p, x] = (0, a.useState)(!1),
                    u = (0, a.useRef)(!1),
                    h = () => s.current ? .getAnimations({
                        subtree: !0
                    }) ? ? [],
                    m = () => {
                        for (let e of h()) e.pause(), e.currentTime = 2600
                    },
                    f = () => {
                        for (let e of (clearTimeout(r.current), h())) e.currentTime = 0, e.play();
                        r.current = setTimeout(m, 2600)
                    };
                return ((0, a.useLayoutEffect)(() => {
                    d(!!s.current ? .closest("[data-phone-canvas]"))
                }, []), (0, a.useLayoutEffect)(() => {
                    if (!u.current) return m();
                    u.current = !1, f()
                }), (0, a.useEffect)(() => () => clearTimeout(r.current), []), o && !p) ? (0, n.jsx)("div", {
                    ref: s,
                    className: `cpx-intro cpx-${e} cpx-still cpx-strip`,
                    "data-off": l || void 0,
                    children: (0, n.jsxs)("div", {
                        className: "cpx-badge",
                        "data-canvas-ui": "",
                        children: [(0, n.jsxs)("span", {
                            children: ["Opening animation", l ? " \xb7 Off" : ""]
                        }), !l && (0, n.jsx)("button", {
                            type: "button",
                            onClick: () => {
                                u.current = !0, x(!0)
                            },
                            children: "\u25b6 Play"
                        }), (0, n.jsx)("button", {
                            type: "button",
                            className: "cpx-ghost",
                            onClick: () => x(!0),
                            children: "Edit"
                        })]
                    })
                }) : (0, n.jsxs)("div", {
                    ref: s,
                    className: `cpx-intro cpx-${e} cpx-still`,
                    "data-off": l || void 0,
                    children: [t, (0, n.jsxs)("div", {
                        className: "cpx-badge",
                        "data-canvas-ui": "",
                        children: [(0, n.jsxs)("span", {
                            children: ["Opening animation", l ? " \xb7 Off" : ""]
                        }), !l && (0, n.jsx)("button", {
                            type: "button",
                            onClick: f,
                            children: "\u25b6 Play"
                        }), o && (0, n.jsx)("button", {
                            type: "button",
                            className: "cpx-ghost",
                            onClick: () => x(!1),
                            children: "Done"
                        })]
                    })]
                })
            }

            function l(e) {
                let t = /^(-?\d{1,3}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?)$/.exec(e);
                if (!t) return [0, 0];
                let s = e => Math.max(-80, Math.min(80, e));
                return [s(Number(t[1])), s(Number(t[2]))]
            }
            s(8643);
            let o = ([e, t]) => e || t ? `${e}cqw ${t}cqw` : void 0;

            function d({
                at: e,
                children: t
            }) {
                let s = (0, c.useText)(e),
                    r = "edit" === (0, c.useMode)(),
                    i = (0, c.useEditDispatch)(),
                    p = (0, c.useSite)(),
                    x = (0, c.useSectionInstance)(),
                    u = (0, a.useRef)(null),
                    h = l(s),
                    m = r && i && p && x;
                return (0, n.jsxs)("div", {
                    ref: u,
                    className: "cpx-move",
                    style: {
                        translate: o(h)
                    },
                    children: [t, m ? (0, n.jsx)("button", {
                        type: "button",
                        className: "cpx-grip",
                        "data-canvas-ui": "",
                        "aria-label": "Drag to move. Double-click to put it back.",
                        title: "Drag to move. Double-click to put it back.",
                        onPointerDown: t => {
                            let s = u.current,
                                n = s ? .closest(".cpx-intro");
                            if (!s || !n || !m) return;
                            t.preventDefault(), t.stopPropagation();
                            let a = t.currentTarget;
                            a.setPointerCapture(t.pointerId);
                            let c = n.getBoundingClientRect().width / 100,
                                r = t.clientX,
                                d = t.clientY,
                                f = h,
                                j = e => {
                                    f = l(`${(h[0]+(e.clientX-r)/c).toFixed(1)},${(h[1]+(e.clientY-d)/c).toFixed(1)}`), s.style.translate = o(f) ? ? ""
                                },
                                v = () => {
                                    a.removeEventListener("pointermove", j), a.removeEventListener("pointerup", v), a.removeEventListener("pointercancel", v), f === h || i({
                                        op: "setSectionField",
                                        pageId: p.page.id,
                                        sectionId: x.id,
                                        fieldId: e,
                                        value: `${f[0]},${f[1]}`
                                    }) || (s.style.translate = o(h) ? ? "")
                                };
                            a.addEventListener("pointermove", j), a.addEventListener("pointerup", v), a.addEventListener("pointercancel", v)
                        },
                        onDoubleClick: () => {
                            m && i({
                                op: "setSectionField",
                                pageId: p.page.id,
                                sectionId: x.id,
                                fieldId: e,
                                value: ""
                            })
                        },
                        children: "\u2725"
                    }) : null]
                })
            }
            let p = [
                [8, 0, 2900, .8, "var(--cpx-marigold)"],
                [21, 380, 2600, 1, "var(--cpx-accent)"],
                [33, 120, 3100, .65, "var(--cpx-gold)"],
                [46, 620, 2700, .9, "var(--cpx-saffron)"],
                [58, 60, 3e3, .7, "var(--cpx-marigold)"],
                [70, 460, 2500, 1.05, "var(--cpx-accent)"],
                [82, 200, 2800, .75, "var(--cpx-gold)"],
                [92, 700, 2600, .85, "var(--cpx-saffron)"],
                [14, 820, 2400, .6, "var(--cpx-gold)"]
            ];

            function x() {
                return (0, n.jsxs)("svg", {
                    viewBox: "0 0 40 70",
                    className: "cpx-lantern",
                    children: [(0, n.jsx)("rect", {
                        x: "15",
                        y: "2",
                        width: "10",
                        height: "5",
                        rx: "1.5",
                        fill: "var(--cpx-gold)"
                    }), (0, n.jsx)("path", {
                        d: "M20 7 L35 19 L31 45 L9 45 L5 19 Z",
                        fill: "currentColor"
                    }), (0, n.jsx)("path", {
                        d: "M20 7 L26 19 L24 45 M20 7 L14 19 L16 45 M5 19 H35",
                        stroke: "var(--cpx-on-hero)",
                        strokeOpacity: "0.45",
                        strokeWidth: "1.2",
                        fill: "none"
                    }), (0, n.jsx)("ellipse", {
                        cx: "20",
                        cy: "31",
                        rx: "7",
                        ry: "9",
                        fill: "var(--cpx-gold)",
                        opacity: "0.55"
                    }), (0, n.jsx)("path", {
                        d: "M20 45 V58",
                        stroke: "var(--cpx-gold)",
                        strokeWidth: "1.5"
                    }), (0, n.jsx)("circle", {
                        cx: "20",
                        cy: "61",
                        r: "3",
                        fill: "var(--cpx-gold)"
                    })]
                })
            }

            function u({
                side: e
            }) {
                return (0, n.jsxs)("svg", {
                    viewBox: "0 0 14 120",
                    className: `cpx-stick cpx-stick-${e}`,
                    children: [(0, n.jsx)("rect", {
                        x: "3",
                        y: "4",
                        width: "8",
                        height: "114",
                        rx: "4",
                        fill: "var(--cpx-marigold)"
                    }), [18, 40, 62, 84].map((e, t) => (0, n.jsx)("rect", {
                        x: "3",
                        y: e,
                        width: "8",
                        height: "9",
                        fill: t % 2 ? "var(--cpx-gold)" : "var(--cpx-accent)"
                    }, e)), (0, n.jsx)("circle", {
                        cx: "7",
                        cy: "6",
                        r: "6",
                        fill: "var(--cpx-gold)"
                    })]
                })
            }

            function h({
                index: e
            }) {
                return (0, n.jsxs)("svg", {
                    viewBox: "0 0 30 26",
                    className: "cpx-diya",
                    style: {
                        "--i": e
                    },
                    children: [(0, n.jsx)("path", {
                        className: "cpx-flame",
                        d: "M15 1 C19 6 19 10 15 13 C11 10 11 6 15 1 Z",
                        fill: "var(--cpx-gold)"
                    }), (0, n.jsx)("path", {
                        d: "M2 13 H28 Q24 25 15 25 Q6 25 2 13 Z",
                        fill: "var(--cpx-saffron)"
                    }), (0, n.jsx)("path", {
                        d: "M6 16 H24",
                        stroke: "var(--cpx-gold)",
                        strokeWidth: "1.4",
                        strokeDasharray: "2 2.5"
                    })]
                })
            }

            function m() {
                let e = (0, c.useText)("introKicker"),
                    t = [...(0, c.useText)("introTitle")],
                    s = "edit" === (0, c.useMode)();
                return !1 !== (0, c.useField)("introOn") || s ? (0, n.jsxs)(r, {
                    kind: "navratri",
                    children: [(0, n.jsxs)("div", {
                        className: "cpx-stage",
                        children: [p.map(([e, t, s, a, c], r) => (0, n.jsx)("span", {
                            className: "cpx-fly",
                            style: {
                                "--x": `${e}%`,
                                "--d": `${t}ms`,
                                "--t": `${s}ms`,
                                "--s": a,
                                color: c
                            },
                            children: (0, n.jsx)(x, {})
                        }, r)), (0, n.jsxs)("div", {
                            className: "cpx-center",
                            children: [(0, n.jsx)(d, {
                                at: "introAtSticks",
                                children: (0, n.jsxs)("div", {
                                    className: "cpx-sticks",
                                    children: [(0, n.jsx)(u, {
                                        side: "l"
                                    }), (0, n.jsx)(u, {
                                        side: "r"
                                    }), (0, n.jsx)("span", {
                                        className: "cpx-spark",
                                        children: Array.from({
                                            length: 8
                                        }, (e, t) => (0, n.jsx)("i", {
                                            style: {
                                                "--a": `${45*t}deg`
                                            }
                                        }, t))
                                    })]
                                })
                            }), (0, n.jsx)(d, {
                                at: "introAtKicker",
                                children: (0, n.jsx)(c.FText, {
                                    as: "p",
                                    field: "introKicker",
                                    className: "cpx-kicker"
                                })
                            }), (0, n.jsx)(d, {
                                at: "introAtTitle",
                                children: s ? (0, n.jsx)(c.FText, {
                                    as: "p",
                                    field: "introTitle",
                                    className: "cpx-title",
                                    style: {
                                        "--n": Math.max(t.length, 8)
                                    }
                                }) : (0, n.jsx)("p", {
                                    className: "cpx-title",
                                    style: {
                                        "--n": Math.max(t.length, 8)
                                    },
                                    children: t.map((e, t) => (0, n.jsx)("span", {
                                        style: {
                                            "--i": t
                                        },
                                        children: " " === e ? "\xa0" : e
                                    }, t))
                                })
                            }), (0, n.jsx)(d, {
                                at: "introAtDiyas",
                                children: (0, n.jsx)("div", {
                                    className: "cpx-diyas",
                                    children: Array.from({
                                        length: 9
                                    }, (e, t) => (0, n.jsx)(h, {
                                        index: t
                                    }, t))
                                })
                            })]
                        })]
                    }), (0, n.jsx)("span", {
                        className: "cpx-toran"
                    })]
                }, s ? "edit" : `${e}
${t.join("")}`) : null
            }
            let f = [
                    [6, 0, 3e3, 220, .9],
                    [18, 520, 2600, -180, .7],
                    [29, 180, 3200, 260, 1],
                    [41, 900, 2400, -240, .8],
                    [55, 60, 2900, 200, .75],
                    [66, 640, 2700, -200, 1],
                    [77, 260, 3100, 240, .85],
                    [89, 780, 2500, -260, .7],
                    [95, 120, 2800, 180, .95],
                    [48, 1200, 2200, 220, .65]
                ],
                j = [
                    [2, 70, 0],
                    [9, 95, 120],
                    [16, 60, 60],
                    [24, 85, 220],
                    [31, 70, 40],
                    [39, 100, 180],
                    [61, 90, 140],
                    [68, 65, 20],
                    [76, 100, 200],
                    [83, 75, 80],
                    [90, 92, 160],
                    [97, 62, 40]
                ];

            function v() {
                return (0, n.jsxs)("svg", {
                    viewBox: "-12 -12 24 24",
                    className: "cpx-shiuli",
                    children: [
                        [0, 60, 120, 180, 240, 300].map(e => (0, n.jsx)("ellipse", {
                            cx: "0",
                            cy: "-6",
                            rx: "3.2",
                            ry: "5.6",
                            transform: `rotate(${e})`,
                            fill: "var(--cpx-kash)"
                        }, e)), (0, n.jsx)("circle", {
                            r: "2.6",
                            fill: "var(--cpx-saffron)"
                        })
                    ]
                })
            }

            function N() {
                return (0, n.jsxs)("svg", {
                    viewBox: "0 0 20 100",
                    preserveAspectRatio: "none",
                    className: "cpx-plume-art",
                    children: [(0, n.jsx)("path", {
                        d: "M10 100 Q9 60 10 34",
                        stroke: "var(--cpx-on-hero)",
                        strokeOpacity: "0.55",
                        strokeWidth: "1.4",
                        fill: "none"
                    }), (0, n.jsx)("path", {
                        d: "M10 4 C17 12 17 28 10 40 C3 28 3 12 10 4 Z",
                        fill: "var(--cpx-kash)",
                        opacity: "0.92"
                    }), (0, n.jsx)("path", {
                        d: "M10 10 C14 18 13 28 10 36 M10 14 C6 20 6 28 10 34",
                        stroke: "var(--cpx-on-hero)",
                        strokeOpacity: "0.35",
                        fill: "none"
                    })]
                })
            }
            let g = [0, 45, 90, 135, 180, 225, 270, 315];

            function y() {
                return (0, n.jsxs)("svg", {
                    viewBox: "-100 -100 200 200",
                    className: "cpx-alpana",
                    children: [(0, n.jsx)("circle", {
                        r: "30",
                        pathLength: 1
                    }), (0, n.jsx)("circle", {
                        r: "44",
                        pathLength: 1,
                        strokeDasharray: "0.012 0.02",
                        className: "cpx-dots"
                    }), g.map(e => (0, n.jsx)("path", {
                        pathLength: 1,
                        transform: `rotate(${e})`,
                        d: "M0 -48 C16 -58 14 -76 0 -86 C-14 -76 -16 -58 0 -48 Z"
                    }, e)), g.map(e => (0, n.jsx)("path", {
                        pathLength: 1,
                        transform: `rotate(${e+22.5})`,
                        d: "M0 -52 Q6 -62 0 -70 Q-6 -62 0 -52"
                    }, `s${e}`)), (0, n.jsx)("circle", {
                        r: "94",
                        pathLength: 1
                    })]
                })
            }

            function k() {
                let e = (0, c.useText)("introTitle"),
                    t = (0, c.useText)("introSub"),
                    s = "edit" === (0, c.useMode)();
                return !1 !== (0, c.useField)("introOn") || s ? (0, n.jsxs)(r, {
                    kind: "durga",
                    children: [(0, n.jsx)("span", {
                        className: "cpx-door cpx-door-l"
                    }), (0, n.jsx)("span", {
                        className: "cpx-door cpx-door-r"
                    }), (0, n.jsxs)("div", {
                        className: "cpx-stage",
                        children: [f.map(([e, t, s, a, c], r) => (0, n.jsx)("span", {
                            className: "cpx-fall",
                            style: {
                                "--x": `${e}%`,
                                "--d": `${t}ms`,
                                "--t": `${s}ms`,
                                "--r": `${a}deg`,
                                "--s": c
                            },
                            children: (0, n.jsx)(v, {})
                        }, r)), (0, n.jsx)("div", {
                            className: "cpx-kaash",
                            children: j.map(([e, t, s], a) => (0, n.jsx)("span", {
                                className: "cpx-plume",
                                style: {
                                    "--x": `${e}%`,
                                    "--h": `${t}%`,
                                    "--d": `${s}ms`,
                                    "--sd": `${1800+a%4*260}ms`
                                },
                                children: (0, n.jsx)("span", {
                                    className: "cpx-plume-sway",
                                    children: (0, n.jsx)(N, {})
                                })
                            }, a))
                        }), (0, n.jsxs)("div", {
                            className: "cpx-center",
                            children: [(0, n.jsx)(d, {
                                at: "introAtMandala",
                                children: (0, n.jsxs)("div", {
                                    className: "cpx-mandala",
                                    children: [(0, n.jsx)(y, {}), [0, 1, 2].map(e => (0, n.jsx)("span", {
                                        className: "cpx-beat",
                                        style: {
                                            "--b": e
                                        }
                                    }, e))]
                                })
                            }), (0, n.jsxs)("div", {
                                className: "cpx-words",
                                children: [(0, n.jsx)(d, {
                                    at: "introAtTitle",
                                    children: (0, n.jsx)(c.FText, {
                                        as: "p",
                                        field: "introTitle",
                                        className: "cpx-bn-title"
                                    })
                                }), (0, n.jsx)(d, {
                                    at: "introAtSub",
                                    children: (0, n.jsx)(c.FText, {
                                        as: "p",
                                        field: "introSub",
                                        className: "cpx-bn-sub"
                                    })
                                })]
                            })]
                        })]
                    })]
                }, s ? "edit" : `${e}
${t}`) : null
            }
        },
        22047: () => {},
        86655: (e, t, s) => {
            "use strict";
            let n, a;
            s.r(t), s.d(t, {
                BeatTapper: () => x.BeatTapper,
                BhogDish: () => R,
                BhogServer: () => L,
                CONCH_HOLD_MS: () => v,
                CONCH_SHORT_TAPS: () => N,
                CONCH_TAIL_SECONDS: () => g,
                ConchRsvp: () => S,
                DHAAK_BEATS: () => u,
                DHAAK_DANCER_FROM: () => h,
                DecorImage: () => x.DecorImage,
                DiyaLighter: () => x.DiyaLighter,
                SHIULI_RAIN: () => f,
                ShiuliRain: () => j,
                WarmImages: () => x.WarmImages,
                WhatsAppReply: () => x.WhatsAppReply,
                bhogServeEffects: () => w,
                conchHint: () => C,
                conchHoldDone: () => $,
                conchHoldProgress: () => k,
                conchRelease: () => M,
                conchSwellSeconds: () => y,
                conchTapCompletes: () => b,
                dhaakBeatEffect: () => m
            });
            var c = s(73365),
                r = s(1521),
                i = s(87191),
                l = s(34768),
                o = s(82161),
                d = s(78922),
                p = s(26244),
                x = s(92407);
            s(22047);
            let u = 8,
                h = 4;

            function m(e) {
                return e % 2 == 1 ? "dhaak" : "dhaakRoll"
            }
            let f = (n = 1433, a = () => {
                let e = n = n + 0x6d2b79f5 >>> 0;
                return e = Math.imul(e ^ e >>> 15, 1 | e), (((e ^= e + Math.imul(e ^ e >>> 7, 61 | e)) ^ e >>> 14) >>> 0) / 0x100000000
            }, Array.from({
                length: 28
            }, (e, t) => ({
                x: Math.round((t + a()) / 28 * 1e3) / 10,
                delay: Math.round(900 * a()),
                duration: Math.round(1900 + 1300 * a()),
                drift: Math.round((a() - .5) * 90),
                spin: Math.round(180 + 360 * a()) * (t % 2 == 0 ? 1 : -1),
                size: Math.round(16 + 12 * a())
            })));

            function j({
                flower: e
            }) {
                return (0, c.jsx)("span", {
                    "aria-hidden": !0,
                    className: "cpdi-rain",
                    children: f.map((t, s) => (0, c.jsx)("span", {
                        className: "cpdi-rain-flower",
                        style: {
                            left: `${t.x}%`,
                            width: `${t.size}px`,
                            height: `${t.size}px`,
                            "--fall-delay": `${t.delay}ms`,
                            "--fall-dur": `${t.duration}ms`,
                            "--drift": `${t.drift}px`,
                            "--spin": `${t.spin}deg`
                        },
                        children: e
                    }, s))
                })
            }
            let v = 900,
                N = 2,
                g = .5;

            function y(e = v) {
                return Math.min(d.tN.max, Math.max(d.tN.min, e / 1e3 + g))
            }

            function k(e, t = v) {
                return !(e > 0) || t <= 0 ? +(t <= 0) : Math.min(1, e / t)
            }

            function $(e, t = v) {
                return k(e, t) >= 1
            }

            function b(e, t) {
                return t || e >= N
            }

            function C(e, t) {
                return b(e, t) ? "tap" : e > 0 ? "more" : "hold"
            }

            function M(e, t, s = v) {
                return $(e, s) ? {
                    complete: !0,
                    shortTaps: t
                } : {
                    complete: !1,
                    shortTaps: t + 1
                }
            }
            let T = () => "u" > typeof performance ? performance.now() : Date.now();

            function S({
                panel: e,
                seal: t,
                sealClassName: s,
                conch: n,
                conchLabel: a,
                holdHint: l,
                moreHint: d,
                tapHint: p,
                no: u,
                confirmNote: h,
                sure: m,
                answered: f,
                declined: N,
                changeMind: g,
                flower: k,
                noClassName: $,
                className: D
            }) {
                let w = (0, o.useSoundEffect)(),
                    L = (0, i.usePrefersReducedMotion)(),
                    R = (0, r.useRef)(null),
                    {
                        editing: A,
                        state: E,
                        restored: I,
                        act: B
                    } = (0, x.useInviteRsvp)(R),
                    [O, P] = (0, r.useState)(!1),
                    [H, _] = (0, r.useState)(0),
                    [F, W] = (0, r.useState)(0),
                    K = (0, r.useRef)(null),
                    Q = (0, r.useRef)([]),
                    Z = (0, r.useCallback)(e => {
                        let t = K.current;
                        t && (clearTimeout(t.timer), e && t.stop(), K.current = null)
                    }, []);
                (0, r.useEffect)(() => () => {
                    for (let e of (Z(!0), Q.current)) clearTimeout(e)
                }, [Z]), (0, i.useReplaySignal)(R, () => {
                    Z(!0), P(!1), _(0), W(0)
                });
                let z = e => {
                        Z(!1), P(!1), "stamped" === B("stamp") && (e || w("shankh"), w("stamp"), Q.current.push(setTimeout(() => w("dhaakRoll"), 150)), W(e => e + 1))
                    },
                    U = () => {
                        if (A || "stamped" === E || "declined" === E || K.current) return;
                        if (b(H, L)) return void z(!1);
                        let e = w("shankh", {
                                length: y()
                            }),
                            t = setTimeout(() => z(!0), v);
                        K.current = {
                            start: T(),
                            stop: e,
                            timer: t
                        }, P(!0)
                    },
                    q = () => {
                        let e = K.current;
                        if (!e) return;
                        let t = M(T() - e.start, H);
                        t.complete ? z(!0) : (Z(!0), P(!1), _(t.shortTaps))
                    },
                    X = `cpdi-conch-rsvp${D?` ${D}`:""}`,
                    Y = (0, c.jsx)("span", {
                        className: `cpdi-seal${s?` ${s}`:""}`,
                        children: t
                    }),
                    V = (0, c.jsxs)("svg", {
                        viewBox: "0 0 100 100",
                        className: "cpdi-conch-ring",
                        "aria-hidden": !0,
                        children: [(0, c.jsx)("circle", {
                            cx: "50",
                            cy: "50",
                            r: "46",
                            className: "cpdi-conch-track"
                        }), (0, c.jsx)("circle", {
                            cx: "50",
                            cy: "50",
                            r: "46",
                            pathLength: 100,
                            className: "cpdi-conch-fill"
                        })]
                    });
                if (A) return (0, c.jsxs)("div", {
                    ref: R,
                    className: X,
                    children: [(0, c.jsxs)("div", {
                        className: "cpdi-conch-target",
                        children: [e, Y]
                    }), (0, c.jsxs)("div", {
                        className: "cpdi-conch-controls",
                        children: [(0, c.jsxs)("span", {
                            className: "cpdi-conch",
                            "data-full": "",
                            children: [V, (0, c.jsx)("span", {
                                className: "cpdi-conch-art",
                                children: n
                            })]
                        }), (0, c.jsx)("span", {
                            className: "cpdi-conch-hint",
                            children: l
                        }), (0, c.jsx)("span", {
                            className: "cpdi-conch-hint",
                            children: d
                        }), (0, c.jsx)("span", {
                            className: "cpdi-conch-hint",
                            children: p
                        }), (0, c.jsx)("span", {
                            className: "cpdi-conch-note",
                            children: h
                        }), (0, c.jsxs)("div", {
                            className: "cpdi-conch-buttons",
                            children: [(0, c.jsx)("span", {
                                className: $,
                                children: u
                            }), (0, c.jsx)("span", {
                                className: $,
                                children: m
                            })]
                        })]
                    }), (0, c.jsx)("div", {
                        className: "cpdi-conch-after",
                        children: f
                    }), (0, c.jsxs)("div", {
                        className: "cpdi-conch-after cpdi-conch-declined",
                        children: [N, (0, c.jsx)("span", {
                            className: $,
                            children: g
                        })]
                    })]
                });
                let G = "stamped" === E,
                    J = C(H, L),
                    ee = I ? "" : " cpi-rise-in";
                return (0, c.jsxs)("div", {
                    ref: R,
                    className: X,
                    "data-state": E,
                    ...O ? {
                        "data-holding": ""
                    } : {},
                    ...I ? {
                        "data-restored": ""
                    } : {},
                    ..."tap" === J ? {
                        "data-tap": ""
                    } : {},
                    children: [(0, c.jsxs)("div", {
                        className: "cpdi-conch-target",
                        children: [e, G ? Y : null, G && !I && F > 0 ? (0, c.jsx)(j, {
                            flower: k
                        }, F) : null, G && !I && F > 0 ? (0, c.jsx)(i.ConfettiBurst, {
                            seed: 19,
                            count: 30,
                            top: "34%"
                        }, `c-${F}`) : null]
                    }), G ? (0, c.jsx)("div", {
                        className: `cpdi-conch-after${ee}`,
                        children: f
                    }) : "declined" === E ? (0, c.jsxs)("div", {
                        className: `cpdi-conch-after cpdi-conch-declined${ee}`,
                        children: [N, (0, c.jsx)("button", {
                            type: "button",
                            className: $,
                            onClick: () => z(!1),
                            children: g
                        })]
                    }) : (0, c.jsxs)("div", {
                        className: "cpdi-conch-controls",
                        children: [(0, c.jsxs)("button", {
                            type: "button",
                            className: "cpdi-conch",
                            "aria-label": a,
                            onPointerDown: e => {
                                0 === e.button && (e.currentTarget.setPointerCapture ? .(e.pointerId), U())
                            },
                            onPointerUp: q,
                            onPointerCancel: q,
                            onLostPointerCapture: q,
                            onBlur: q,
                            onKeyDown: e => {
                                ("Enter" === e.key || " " === e.key) && (e.preventDefault(), e.repeat || U())
                            },
                            onKeyUp: e => {
                                ("Enter" === e.key || " " === e.key) && q()
                            },
                            onClick: e => {
                                0 !== e.detail || K.current || z(!1)
                            },
                            onContextMenu: e => e.preventDefault(),
                            children: [V, (0, c.jsx)("span", {
                                className: "cpdi-conch-art",
                                children: n
                            })]
                        }), (0, c.jsx)("p", {
                            className: "cpdi-conch-hint",
                            "aria-live": "polite",
                            children: "tap" === J ? p : "more" === J ? d : l
                        }), (0, c.jsx)("p", {
                            className: "cpdi-conch-note",
                            "aria-live": "polite",
                            children: "confirming" === E ? (0, c.jsx)("span", {
                                className: "cpi-rise-in",
                                children: h
                            }) : null
                        }), (0, c.jsx)("div", {
                            className: "cpdi-conch-buttons",
                            children: (0, c.jsx)("button", {
                                type: "button",
                                className: $,
                                onClick: () => {
                                    let e = B("confirming" === E ? "confirmDecline" : "decline");
                                    "confirming" === e ? w("nope") : "declined" === e && w("puff")
                                },
                                children: "confirming" === E ? m : u
                            })
                        })]
                    })]
                })
            }
            let D = (0, r.createContext)(null);

            function w(e, t) {
                return e < 1 || e > t ? [] : e === t ? [{
                    effect: "plop",
                    at: 0
                }, {
                    effect: "ghonta",
                    at: 280
                }] : [{
                    effect: "plop",
                    at: 0
                }]
            }

            function L({
                plate: e,
                dishes: t,
                count: s,
                button: n,
                done: a,
                countLabel: d,
                className: x,
                stageClassName: u,
                buttonClassName: h,
                countClassName: m
            }) {
                let f = "edit" === (0, l.useMode)(),
                    j = (0, o.useSoundEffect)(),
                    [v, N] = (0, r.useState)(0),
                    g = (0, r.useRef)(null),
                    y = (0, r.useRef)(null);
                (0, r.useEffect)(() => () => {
                    y.current && clearTimeout(y.current)
                }, []), (0, i.useReplaySignal)(g, () => N(0));
                let k = Math.max(0, s),
                    $ = f ? k : Math.min(v, k),
                    b = !f && k > 0 && $ >= k;
                return (0, c.jsxs)("div", {
                    ref: g,
                    className: `cpdi-bhog${x?` ${x}`:""}`,
                    "data-served": $,
                    ...b ? {
                        "data-done": ""
                    } : {},
                    children: [(0, c.jsxs)("div", {
                        className: `cpdi-bhog-stage${u?` ${u}`:""}`,
                        children: [e, (0, c.jsx)(D.Provider, {
                            value: {
                                served: $,
                                fresh: f ? -1 : v - 1
                            },
                            children: t
                        }), b ? (0, c.jsx)(i.ConfettiBurst, {
                            seed: 29,
                            count: 26,
                            top: "46%"
                        }) : null]
                    }), (0, c.jsxs)("p", {
                        className: `cpdi-bhog-count${m?` ${m}`:""}`,
                        "aria-live": "polite",
                        children: [d, d ? " " : null, (0, c.jsx)("span", {
                            children: (0, p.wb)(`${$}/${k}`)
                        })]
                    }), f ? (0, c.jsx)("span", {
                        className: h,
                        children: n
                    }) : b ? null : (0, c.jsx)("button", {
                        type: "button",
                        className: `cpdi-bhog-button${h?` ${h}`:""}`,
                        onClick: () => {
                            if (f || v >= k) return;
                            let e = v + 1;
                            for (let {
                                    effect: t,
                                    at: s
                                } of (N(e), w(e, k))) 0 === s ? j(t) : (y.current && clearTimeout(y.current), y.current = setTimeout(() => j(t), s))
                        },
                        children: n
                    }), (0, c.jsx)("div", {
                        className: "cpdi-bhog-after",
                        "aria-live": "polite",
                        children: f ? a : b ? (0, c.jsx)("div", {
                            className: "cpi-rise-in",
                            children: a
                        }) : null
                    })]
                })
            }

            function R({
                children: e,
                className: t
            }) {
                let s = (0, r.useContext)(D),
                    {
                        index: n
                    } = (0, l.useItemPosition)(),
                    a = !s || n < s.served,
                    i = null !== s && n === s.fresh;
                return (0, c.jsx)("div", {
                    className: `cpdi-dish${t?` ${t}`:""}`,
                    ...a ? {
                        "data-on": ""
                    } : {},
                    ...i ? {
                        "data-new": ""
                    } : {},
                    children: e
                })
            }
        }
    }
]);