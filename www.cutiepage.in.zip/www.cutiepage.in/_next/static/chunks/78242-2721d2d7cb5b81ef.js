(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [78242], {
        2245: () => {},
        78242: (e, t, a) => {
            "use strict";
            a.r(t), a.d(t, {
                DabbaCover: () => I,
                DiyaLighting: () => $,
                Kandil: () => B,
                LetterAndSky: () => L,
                MithaiBox: () => D,
                PatakhePlayground: () => V,
                RangoliPour: () => A,
                SfxToggle: () => z
            });
            var l = a(73365),
                r = a(1521),
                n = a(80579);
            let s = ["peony", "willow", "strobe", "ring", "heart", "crossette"],
                i = ["#ffd27a", "#fff3d6", "#ff7aa8", "#ff9a3c", "#5be3a1", "#b89cff", "#7fd3ff", "#ff5a5a"];

            function o(e, t) {
                return 1 - Math.pow(1 - e, 60 * t)
            }

            function d(e) {
                let t = [];
                for (let a = 0; a < e; a += 1) {
                    let l = a / e * Math.PI * 2,
                        r = 16 * Math.sin(l) ** 3,
                        n = 13 * Math.cos(l) - 5 * Math.cos(2 * l) - 2 * Math.cos(3 * l) - Math.cos(4 * l);
                    t.push([r / 17, -n / 17])
                }
                return t
            }
            let c = (e, t) => e + Math.random() * (t - e),
                u = e => e[Math.floor(Math.random() * e.length)];
            var p = a(34212),
                h = a(87191),
                f = a(34768),
                m = a(82161);
            a(2245);
            let x = "cp-diwali-dabba",
                y = e => e ? "" : void 0,
                v = (e, t) => e + Math.random() * (t - e);

            function g() {
                let e = (0, r.useRef)([]);
                return (0, r.useEffect)(() => {
                    let t = e.current;
                    return () => t.forEach(clearTimeout)
                }, []), (0, r.useMemo)(() => ({
                    at(t, a) {
                        e.current.push(setTimeout(a, t))
                    },
                    clear() {
                        e.current.forEach(clearTimeout), e.current = []
                    }
                }), [])
            }
            let M = null,
                b = !0,
                j = new Set,
                w = e => (j.add(e), () => {
                    j.delete(e)
                }),
                N = () => (0, r.useSyncExternalStore)(w, () => b, () => !0),
                k = {
                    stop() {}
                };

            function R() {
                let e = (0, m.useStandsInForPage)((0, f.useMode)()),
                    {
                        muted: t
                    } = (0, m.useFolioSound)(),
                    a = N(),
                    l = (0, r.useRef)(!1);
                return (0, r.useEffect)(() => {
                    l.current = e && a && !t
                }, [e, a, t]), (0, r.useMemo)(() => {
                    let t = () => M ? ? = (0, n.Ok)(window);
                    return {
                        play(e, a) {
                            l.current && t() ? .play(e, a)
                        },
                        loop(e, a) {
                            let r = l.current ? t() : null;
                            return r ? r.loop(e, a) : k
                        },
                        unlock() {
                            e && t() ? .unlock()
                        }
                    }
                }, [e])
            }

            function z() {
                let e = N(),
                    t = "edit" === (0, f.useMode)();
                return (0, l.jsx)("button", {
                    type: "button",
                    className: "prdd-sfx",
                    "aria-label": "Sound effects",
                    "aria-pressed": e,
                    tabIndex: t ? -1 : void 0,
                    onClick: () => {
                        t || (b = !b, j.forEach(e => e()))
                    },
                    children: (0, l.jsxs)("svg", {
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0,
                        width: "18",
                        height: "18",
                        children: [(0, l.jsx)("path", {
                            d: "M12 3a5 5 0 0 0-5 5v3.2c0 1-.4 2-1.1 2.7L5 15h14l-.9-1.1a3.9 3.9 0 0 1-1.1-2.7V8a5 5 0 0 0-5-5Z",
                            fill: "currentColor"
                        }), (0, l.jsx)("path", {
                            d: "M10 18a2 2 0 0 0 4 0",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            fill: "none",
                            strokeLinecap: "round"
                        }), e ? null : (0, l.jsx)("path", {
                            d: "M4 4l16 16",
                            stroke: "currentColor",
                            strokeWidth: "2.2",
                            strokeLinecap: "round"
                        })]
                    })
                })
            }

            function C(e) {
                return t => {
                    let a = 1.6 * t.x - .8;
                    "launch" === t.type ? e.play("whistle", {
                        volume: .4,
                        pan: a,
                        rate: v(.92, 1.1)
                    }) : (e.play("boom", {
                        volume: .75,
                        pan: a,
                        rate: v(.85, 1.12),
                        delay: v(.04, .28)
                    }), ("strobe" === t.kind || "willow" === t.kind) && e.play("crackle", {
                        volume: .45,
                        pan: a,
                        delay: v(.5, .8)
                    }))
                }
            }

            function S(e, t) {
                let a, l, n = (0, r.useRef)(null),
                    p = (0, r.useRef)(null),
                    h = (0, r.useRef)(null),
                    m = (a = (0, f.useStory)(), l = (0, f.useSectionIndex)(), !a.active || a.index === l),
                    x = (0, r.useRef)({
                        onScreen: m,
                        inView: !0
                    }),
                    y = (0, r.useRef)(t);
                return (0, r.useEffect)(() => {
                    y.current = t
                }), (0, r.useEffect)(() => {
                    let t = n.current;
                    if (!e || !t) return;
                    let a = function(e, t = {}) {
                        let a = e.ownerDocument.defaultView,
                            l = e.getContext("2d"),
                            r = t.ink ? ? null,
                            n = r ? .getContext("2d") ? ? null,
                            p = [],
                            h = [],
                            f = 1,
                            m = 0,
                            x = 0,
                            y = 1,
                            v = 1200,
                            g = !0,
                            M = 0,
                            b = 0,
                            j = 0,
                            w = 1 / 0,
                            N = 0,
                            k = Array.from({
                                length: 4 * i.length
                            }, () => []),
                            R = e.ownerDocument.createElement("canvas");
                        R.width = R.height = 64;
                        let z = R.getContext("2d");
                        if (z) {
                            let e = z.createRadialGradient(32, 32, 0, 32, 32, 32);
                            e.addColorStop(0, "rgba(255,255,255,1)"), e.addColorStop(1, "rgba(255,255,255,0)"), z.fillStyle = e, z.fillRect(0, 0, 64, 64)
                        }
                        let C = e => {
                                if (p.length >= v) return null;
                                let t = {
                                    vx: 0,
                                    vy: 0,
                                    life: 1,
                                    max: 1,
                                    color: 0,
                                    size: 2,
                                    drag: .98,
                                    gravity: 60,
                                    flags: 0,
                                    seed: Math.random(),
                                    tx: 0,
                                    ty: 0,
                                    shell: "peony",
                                    ...e
                                };
                                return t.max = t.life, p.push(t), t
                            },
                            S = (e, a, r, n = Math.floor(Math.random() * i.length)) => {
                                let s = 150 * Math.min(1.3, Math.max(.75, m / 420)),
                                    o = Math.max(0, v - p.length);
                                if ("peony" === r) {
                                    let t = (n + 2) % i.length;
                                    for (let l = 0, i = Math.min(110, o); l < i; l += 1) {
                                        let i = c(-1, 1),
                                            o = Math.sqrt(1 - i * i),
                                            d = c(0, 2 * Math.PI);
                                        C({
                                            x: e,
                                            y: a,
                                            vx: Math.cos(d) * o * s,
                                            vy: Math.sin(d) * o * s,
                                            life: c(1.3, 1.9),
                                            color: l % 5 == 0 ? t : n,
                                            size: 2.2,
                                            drag: .975,
                                            gravity: 70,
                                            shell: r
                                        })
                                    }
                                } else if ("willow" === r)
                                    for (let t = 0, l = Math.min(80, o); t < l; t += 1) {
                                        let t = c(0, 2 * Math.PI),
                                            l = s * c(.55, .95);
                                        C({
                                            x: e,
                                            y: a,
                                            vx: Math.cos(t) * l,
                                            vy: Math.sin(t) * l,
                                            life: c(2.6, 3.4),
                                            color: 0,
                                            size: 1.8,
                                            drag: .955,
                                            gravity: 42,
                                            flags: 2,
                                            shell: r
                                        })
                                    } else if ("strobe" === r)
                                        for (let t = 0, l = Math.min(70, o); t < l; t += 1) {
                                            let l = c(-1, 1),
                                                n = Math.sqrt(1 - l * l),
                                                i = c(0, 2 * Math.PI);
                                            C({
                                                x: e,
                                                y: a,
                                                vx: Math.cos(i) * n * s * .9,
                                                vy: Math.sin(i) * n * s * .9,
                                                life: c(1.6, 2.2),
                                                color: t % 2 ? 1 : 0,
                                                size: 2,
                                                drag: .97,
                                                gravity: 55,
                                                flags: 3,
                                                shell: r
                                            })
                                        } else if ("ring" === r) {
                                            let t = Math.min(64, o),
                                                l = c(.45, 1),
                                                i = c(0, Math.PI);
                                            for (let o = 0; o < t; o += 1) {
                                                let d = o / t * Math.PI * 2,
                                                    u = Math.cos(d) * s,
                                                    p = Math.sin(d) * s * l;
                                                C({
                                                    x: e,
                                                    y: a,
                                                    vx: u * Math.cos(i) - p * Math.sin(i),
                                                    vy: u * Math.sin(i) + p * Math.cos(i),
                                                    life: c(1.5, 1.8),
                                                    color: n,
                                                    size: 2.2,
                                                    drag: .975,
                                                    gravity: 50,
                                                    shell: r
                                                })
                                            }
                                            for (let t = 0, l = Math.min(16, o); t < l; t += 1) {
                                                let t = c(0, 2 * Math.PI);
                                                C({
                                                    x: e,
                                                    y: a,
                                                    vx: Math.cos(t) * s * .25,
                                                    vy: Math.sin(t) * s * .25,
                                                    life: c(.8, 1.2),
                                                    color: 1,
                                                    size: 1.6,
                                                    drag: .96,
                                                    gravity: 40,
                                                    shell: r
                                                })
                                            }
                                        } else if ("heart" === r)
                                    for (let [t, l] of d(Math.min(72, o))) C({
                                        x: e,
                                        y: a,
                                        vx: t * s * .95,
                                        vy: l * s * .95,
                                        life: c(1.5, 1.8),
                                        color: 2,
                                        size: 2.3,
                                        drag: .972,
                                        gravity: 36,
                                        shell: r
                                    });
                                else
                                    for (let t = 0, l = Math.min(14, o); t < l; t += 1) {
                                        let l = t / 14 * Math.PI * 2;
                                        C({
                                            x: e,
                                            y: a,
                                            vx: Math.cos(l) * s * .8,
                                            vy: Math.sin(l) * s * .8,
                                            life: 1.3,
                                            color: n,
                                            size: 2.6,
                                            drag: .975,
                                            gravity: 50,
                                            flags: 4,
                                            shell: r
                                        })
                                    }
                                l && (l.globalCompositeOperation = "lighter", l.globalAlpha = .55, l.drawImage(R, e - 70, a - 70, 140, 140), l.globalAlpha = 1);
                                for (let t = 0; t < 4; t += 1) C({
                                    x: e + c(-30, 30),
                                    y: a + c(-30, 30),
                                    vx: c(-8, 8),
                                    vy: c(-10, 2),
                                    life: c(2.4, 3.6),
                                    size: c(40, 80),
                                    drag: .99,
                                    gravity: -4,
                                    flags: 8
                                });
                                t.onEvent ? .({
                                    type: "burst",
                                    x: m ? e / m : .5,
                                    kind: r
                                }), I()
                            },
                            P = e => {
                                if (!l || !g) {
                                    M = 0;
                                    return
                                }
                                let t = Math.min(.05, Math.max(.001, (e - (b || e)) / 1e3 || 1 / 60));
                                for (let a of (b = e, N += t, h))
                                    if ("fountain" === a.kind)
                                        for (a.carry += 230 * t; a.carry >= 1; a.carry -= 1) {
                                            let e = -Math.PI / 2 + c(-.32, .32),
                                                t = c(260, 430) * Math.min(1.15, Math.max(.8, x / 700));
                                            C({
                                                x: a.x + c(-3, 3),
                                                y: a.y,
                                                vx: Math.cos(e) * t,
                                                vy: Math.sin(e) * t,
                                                life: c(.8, 1.3),
                                                color: u([0, 0, 1, 3]),
                                                size: 1.7,
                                                drag: .985,
                                                gravity: 420,
                                                flags: +(.12 > Math.random())
                                            })
                                        } else if ("spinner" === a.kind)
                                            for (a.angle += 15 * t, a.carry += 260 * t; a.carry >= 1; a.carry -= 1) {
                                                let e = a.angle + (a.carry % 2 ? Math.PI : 0),
                                                    t = c(150, 240);
                                                C({
                                                    x: a.x + 18 * Math.cos(e),
                                                    y: a.y + 18 * Math.sin(e),
                                                    vx: Math.cos(e + 1.3) * t,
                                                    vy: Math.sin(e + 1.3) * t,
                                                    life: c(.45, .8),
                                                    color: u([0, 4, 2, 1]),
                                                    size: 1.6,
                                                    drag: .95,
                                                    gravity: 260
                                                })
                                            } else
                                                for (a.carry += 150 * t; a.carry >= 1; a.carry -= 1) {
                                                    let e = c(0, 2 * Math.PI),
                                                        t = c(40, 170);
                                                    C({
                                                        x: a.x,
                                                        y: a.y,
                                                        vx: Math.cos(e) * t,
                                                        vy: Math.sin(e) * t,
                                                        life: c(.18, .45),
                                                        color: +(.6 > Math.random()),
                                                        size: 1.3,
                                                        drag: .9,
                                                        gravity: 90,
                                                        flags: +(.2 > Math.random())
                                                    })
                                                }
                                for (let e = p.length - 1; e >= 0; e -= 1) {
                                    let a = p[e];
                                    if (! function(e, t) {
                                            if (16 & e.flags) {
                                                let a = 1 - Math.pow(.04, t);
                                                e.x += (e.tx - e.x) * a, e.y += (e.ty - e.y) * a;
                                                return
                                            }
                                            let a = Math.pow(e.drag, 60 * t);
                                            e.vx *= a, e.vy *= a, e.vy += e.gravity * t, e.x += e.vx * t, e.y += e.vy * t, e.life -= t
                                        }(a, t), 32 & a.flags) {
                                        .9 > Math.random() && C({
                                            x: a.x + c(-1.5, 1.5),
                                            y: a.y + 4,
                                            vx: c(-14, 14),
                                            vy: c(20, 60),
                                            life: c(.3, .6),
                                            color: 0,
                                            size: 1.4,
                                            drag: .92,
                                            gravity: 60
                                        }), (a.vy >= -30 || a.life <= 0 || a.y <= a.ty) && (p[e] = p[p.length - 1], p.pop(), S(a.x, a.y, a.shell, a.color));
                                        continue
                                    }
                                    if (4 & a.flags && a.life < .5 * a.max) {
                                        a.flags &= -5;
                                        let e = c(0, Math.PI / 2);
                                        for (let t = 0; t < 4; t += 1) {
                                            let l = e + t * Math.PI / 2;
                                            C({
                                                x: a.x,
                                                y: a.y,
                                                vx: .3 * a.vx + 95 * Math.cos(l),
                                                vy: .3 * a.vy + 95 * Math.sin(l),
                                                life: c(.7, 1),
                                                color: (a.color + 1) % i.length,
                                                size: 1.8,
                                                drag: .96,
                                                gravity: 60
                                            })
                                        }
                                        a.life = 0
                                    }
                                    if (a.life <= 0) {
                                        if (2 & a.flags && .5 > Math.random())
                                            for (let e = 0; e < 3; e += 1) C({
                                                x: a.x,
                                                y: a.y,
                                                vx: c(-60, 60),
                                                vy: c(-60, 60),
                                                life: c(.06, .16),
                                                color: 1,
                                                size: 1.8,
                                                drag: .8,
                                                gravity: 0
                                            });
                                        p[e] = p[p.length - 1], p.pop()
                                    }
                                }
                                for (let e of (l.globalCompositeOperation = "destination-out", l.fillStyle = `rgba(0,0,0,${o(.2,t)})`, l.fillRect(0, 0, m, x), l.globalCompositeOperation = "source-over", p)) 8 & e.flags && (l.globalAlpha = .035 * Math.sin(Math.PI * (e.life / e.max)), l.drawImage(R, e.x - e.size, e.y - e.size, 2 * e.size, 2 * e.size));
                                for (let e of (l.globalAlpha = 1, l.globalCompositeOperation = "lighter", k)) e.length = 0;
                                for (let e of p) {
                                    if (8 & e.flags || 1 & e.flags && (18 * N + 7 * e.seed) % 1 < .45) continue;
                                    let t = Math.max(0, Math.min(3, Math.floor(4 * (16 & e.flags ? .6 + .4 * Math.sin(6 * N + 20 * e.seed) : Math.min(1, e.life / e.max * 1.6)))));
                                    k[4 * e.color + t].push(e)
                                }
                                for (let e = 0; e < k.length; e += 1) {
                                    let t = k[e];
                                    if (t.length) {
                                        for (let a of (l.globalAlpha = (e % 4 + 1) / 4, l.fillStyle = i[Math.floor(e / 4)], l.beginPath(), t)) l.rect(a.x - a.size / 2, a.y - a.size / 2, a.size, a.size);
                                        l.fill()
                                    }
                                }
                                l.globalAlpha = 1, l.globalCompositeOperation = "source-over", n && r && w < 9 && (w += t, n.globalCompositeOperation = "destination-out", n.fillStyle = `rgba(0,0,0,${o(.007,t)})`, n.fillRect(0, 0, m, x), n.globalCompositeOperation = "source-over", w >= 9 && n.clearRect(0, 0, m, x)), (j = p.length || h.length ? 0 : j + t) > 1.2 && l.clearRect(0, 0, m, x), M = 0, j <= 1.2 || w < 9 ? M = a ? .requestAnimationFrame(P) ? ? 0 : b = 0
                            };

                        function I() {
                            j = 0, !M && g && a && (M = a.requestAnimationFrame(P))
                        }
                        let F = () => {
                            let t = e.getBoundingClientRect();
                            for (let [s, i] of (m = Math.max(1, t.width), x = Math.max(1, t.height), y = Math.min(2, a ? .devicePixelRatio || 1), v = m < 640 ? 1200 : 2500, [
                                    [e, l],
                                    [r, n]
                                ])) s && i && (s.width = Math.round(m * y), s.height = Math.round(x * y), i.setTransform(y, 0, 0, y, 0, 0))
                        };
                        return F(), {
                            resize: F,
                            launch(e, a, {
                                kind: l = u(s),
                                color: r,
                                fromY: n = x + 4
                            } = {}) {
                                C({
                                    x: e,
                                    y: n,
                                    vx: c(-12, 12),
                                    vy: -(1.02 * Math.sqrt(960 * Math.max(60, n - a))),
                                    life: 3,
                                    color: r ? ? Math.floor(Math.random() * i.length),
                                    size: 2.4,
                                    drag: 1,
                                    gravity: 480,
                                    flags: 32,
                                    ty: a,
                                    shell: l
                                }), t.onEvent ? .({
                                    type: "launch",
                                    x: m ? e / m : .5
                                }), I()
                            },
                            burst: S,
                            emitter(e, t, a) {
                                let l = f++;
                                return h.push({
                                    id: l,
                                    kind: e,
                                    x: t,
                                    y: a,
                                    angle: 0,
                                    carry: 0,
                                    lx: t,
                                    ly: a
                                }), I(), l
                            },
                            moveEmitter(e, t, a) {
                                let l = h.find(t => t.id === e);
                                l && ("sparkler" === l.kind && n && (n.lineCap = "round", n.lineJoin = "round", n.globalCompositeOperation = "lighter", n.strokeStyle = "rgba(255,190,90,0.35)", n.lineWidth = 9, n.beginPath(), n.moveTo(l.lx, l.ly), n.lineTo(t, a), n.stroke(), n.strokeStyle = "rgba(255,246,220,0.95)", n.lineWidth = 2.4, n.stroke(), n.globalCompositeOperation = "source-over", w = 0), l.lx = l.x = t, l.ly = l.y = a, I())
                            },
                            stopEmitter(e) {
                                let t = h.findIndex(t => t.id === e);
                                t >= 0 && h.splice(t, 1)
                            },
                            form(e, t = 0) {
                                let a = p.filter(e => 16 & e.flags),
                                    l = v - (p.length - a.length),
                                    r = Math.min(e.length, Math.max(0, l));
                                for (let l = 0; l < r; l += 1) {
                                    let [n, s] = e[Math.floor(l * e.length / r)], i = a[l];
                                    if (i || (i = C({
                                            x: m / 2 + c(-40, 40),
                                            y: .55 * x + c(-40, 40),
                                            life: 1,
                                            flags: 16,
                                            color: t,
                                            size: 2.2
                                        })), !i) break;
                                    i.tx = n, i.ty = s, i.color = t
                                }
                                for (let e = r; e < a.length; e += 1) {
                                    let t = a[e];
                                    t.flags &= -17, t.vx = c(-40, 40), t.vy = c(-40, 10), t.life = t.max = c(.6, 1.2)
                                }
                                I()
                            },
                            release() {
                                for (let e of p) 16 & e.flags && (e.flags = -17 & e.flags | 2, e.vx = c(-30, 30), e.vy = c(-50, 0), e.gravity = 45, e.drag = .97, e.life = e.max = c(1.6, 2.6));
                                I()
                            },
                            setActive(e) {
                                g = e, !e && M ? (a ? .cancelAnimationFrame(M), M = 0, b = 0) : e && I()
                            },
                            clear() {
                                p.length = 0, h.length = 0, l ? .clearRect(0, 0, m, x), n ? .clearRect(0, 0, m, x), w = 1 / 0
                            },
                            destroy() {
                                M && a ? .cancelAnimationFrame(M), M = 0, g = !1, p.length = 0, h.length = 0
                            },
                            size: () => ({
                                width: m,
                                height: x
                            })
                        }
                    }(t, {
                        ink: p.current,
                        onEvent: e => y.current(e)
                    });
                    h.current = a;
                    let l = t.ownerDocument,
                        r = l.defaultView,
                        f = () => a.setActive(x.current.onScreen && x.current.inView && "hidden" !== l.visibilityState),
                        m = r ? .IntersectionObserver ? new r.IntersectionObserver(([e]) => {
                            x.current.inView = !!e ? .isIntersecting, x.current.inView && a.resize(), f()
                        }) : null;
                    m ? .observe(t);
                    let v = r ? .ResizeObserver ? new r.ResizeObserver(() => a.resize()) : null;
                    return v ? .observe(t), l.addEventListener("visibilitychange", f), () => {
                        m ? .disconnect(), v ? .disconnect(), l.removeEventListener("visibilitychange", f), a.destroy(), h.current = null
                    }
                }, [e]), (0, r.useEffect)(() => {
                    x.current.onScreen = m;
                    let e = h.current;
                    e && (m && e.resize(), e.setActive(m && x.current.inView))
                }, [m]), {
                    canvasRef: n,
                    inkRef: p,
                    engine: h
                }
            }

            function P(e, t, a) {
                let l = e.getBoundingClientRect();
                return {
                    x: t - l.left,
                    y: a - l.top
                }
            }

            function I({
                name: e,
                photo: t,
                hint: a,
                children: n
            }) {
                let s = "edit" === (0, f.useMode)(),
                    i = R(),
                    o = (0, m.useFolioSound)(),
                    d = (0, r.useRef)(null),
                    [c, u] = (0, r.useState)(!1),
                    v = s || c;
                return (0, h.useReplaySignal)(d, () => u(!1)), (0, l.jsxs)("div", {
                    ref: d,
                    className: "prdd-cover",
                    "data-open": y(v),
                    children: [(0, l.jsxs)("div", {
                        className: "prdd-dabba-stage",
                        children: [(0, l.jsx)("span", {
                            className: "prdd-rays",
                            "aria-hidden": !0
                        }), (0, l.jsx)("span", {
                            className: "prdd-dabba-glow",
                            "aria-hidden": !0
                        }), (0, l.jsxs)("button", {
                            type: "button",
                            className: "prdd-dabba",
                            onClick: () => {
                                s || c || (o.unlock(), i.unlock(), i.play("lid", {
                                    volume: .8
                                }), i.play("bell", {
                                    volume: .5,
                                    delay: .35
                                }), u(!0))
                            },
                            tabIndex: s ? -1 : void 0,
                            "aria-expanded": v,
                            children: [(0, l.jsx)(p.FX, {
                                template: x,
                                name: "dabba-closed",
                                priority: !0,
                                className: "prdd-dabba-closed"
                            }), (0, l.jsx)(p.FX, {
                                template: x,
                                name: "dabba-open",
                                priority: !0,
                                className: "prdd-dabba-open"
                            }), (0, l.jsx)("span", {
                                className: "prdd-dabba-light",
                                "aria-hidden": !0
                            }), t ? (0, l.jsx)("span", {
                                className: "prdd-cover-photo",
                                children: t
                            }) : null, (0, l.jsx)("span", {
                                className: "prdd-plate",
                                children: e
                            })]
                        }), (0, l.jsx)("span", {
                            className: "prdd-burst",
                            "aria-hidden": !0,
                            children: Array.from({
                                length: 12
                            }, (e, t) => (0, l.jsx)("i", {
                                style: {
                                    "--a": `${30*t}deg`
                                }
                            }, t))
                        })]
                    }), (0, l.jsx)("div", {
                        className: "prdd-cover-hint",
                        children: a
                    }), (0, l.jsx)("div", {
                        className: "prdd-cover-card",
                        children: n
                    })]
                })
            }
            let F = [1, 1.125, 1.25, 1.5, 1.667];

            function $({
                wishes: e,
                hint: t,
                done: a
            }) {
                let n = "edit" === (0, f.useMode)(),
                    s = R(),
                    i = (0, r.useRef)(null),
                    o = (0, r.useRef)([]),
                    d = (0, r.useRef)(null),
                    c = (0, r.useRef)(new Set),
                    u = (0, r.useRef)(null),
                    [m, v] = (0, r.useState)(() => e.map(() => !1)),
                    [g, M] = (0, r.useState)(null),
                    b = n ? e.map(() => !0) : m,
                    j = b.every(Boolean);
                (0, h.useReplaySignal)(i, () => {
                    c.current.clear(), v(e.map(() => !1))
                });
                let w = e => {
                        n || c.current.has(e) || (c.current.add(e), s.unlock(), s.play("flame", {
                            volume: .6
                        }), s.play("chime", {
                            volume: .55,
                            rate: F[c.current.size - 1] ? ? 1,
                            delay: .08
                        }), v(t => t.map((t, a) => t || a === e)))
                    },
                    N = () => {
                        let t = e.findIndex((e, t) => !c.current.has(t));
                        t >= 0 && w(t)
                    };
                return (0, l.jsxs)("div", {
                    ref: i,
                    className: "prdd-diyas",
                    "data-all": y(j),
                    children: [(0, l.jsx)("div", {
                        className: "prdd-diya-row",
                        children: e.map((e, t) => (0, l.jsxs)("button", {
                            type: "button",
                            className: "prdd-diya",
                            "data-lit": y(b[t]),
                            "aria-label": `Diya ${t+1}`,
                            "aria-pressed": b[t],
                            tabIndex: n ? -1 : void 0,
                            onClick: () => w(t),
                            children: [(0, l.jsx)(p.FX, {
                                template: x,
                                name: "diya-clay",
                                className: "w-full"
                            }), (0, l.jsx)("span", {
                                className: "prdd-wick",
                                ref: e => {
                                    o.current[t] = e
                                }
                            }), (0, l.jsxs)("span", {
                                className: "prdd-flame",
                                "aria-hidden": !0,
                                children: [(0, l.jsx)("i", {
                                    className: "prdd-halo"
                                }), (0, l.jsx)("i", {
                                    className: "prdd-flame-outer"
                                }), (0, l.jsx)("i", {
                                    className: "prdd-flame-core"
                                })]
                            })]
                        }, t))
                    }), (0, l.jsx)("div", {
                        className: "prdd-stick-rest",
                        children: (0, l.jsxs)("button", {
                            ref: d,
                            type: "button",
                            className: "prdd-stick",
                            "data-dragging": y(null !== g),
                            "data-hidden": y(j),
                            tabIndex: n || j ? -1 : void 0,
                            style: g ? {
                                transform: `translate(${g.x}px, ${g.y}px)`
                            } : void 0,
                            onKeyDown: e => {
                                ("Enter" === e.key || " " === e.key) && (e.preventDefault(), N())
                            },
                            ...{
                                onPointerDown(e) {
                                    if (n) return;
                                    let t = e.currentTarget.getBoundingClientRect();
                                    e.currentTarget.setPointerCapture(e.pointerId), u.current = {
                                        id: e.pointerId,
                                        x: e.clientX,
                                        y: e.clientY,
                                        tipX: t.left + .86 * t.width,
                                        tipY: t.top + .27 * t.height,
                                        moved: !1
                                    }, s.unlock(), s.play("match", {
                                        volume: .45
                                    })
                                },
                                onPointerMove(e) {
                                    let t = u.current;
                                    if (!t || t.id !== e.pointerId) return;
                                    let a = e.clientX - t.x,
                                        l = e.clientY - t.y;
                                    if (!t.moved && 6 > Math.hypot(a, l)) return;
                                    t.moved = !0, M({
                                        x: a,
                                        y: l
                                    });
                                    let r = t.tipX + a,
                                        n = t.tipY + l;
                                    o.current.forEach((e, t) => {
                                        if (!e || c.current.has(t)) return;
                                        let a = e.getBoundingClientRect();
                                        34 > Math.hypot(a.left + a.width / 2 - r, a.top + a.height / 2 - n) && w(t)
                                    })
                                },
                                onPointerUp(e) {
                                    let t = u.current;
                                    t && t.id === e.pointerId && (u.current = null, M(null), t.moved || N())
                                },
                                onPointerCancel() {
                                    u.current = null, M(null)
                                }
                            },
                            children: [(0, l.jsx)(p.FX, {
                                template: x,
                                name: "agarbatti",
                                className: "w-full"
                            }), (0, l.jsx)("span", {
                                className: "prdd-ember",
                                "aria-hidden": !0
                            })]
                        })
                    }), (0, l.jsx)("ol", {
                        className: "prdd-wishes",
                        children: e.map((e, t) => (0, l.jsx)("li", {
                            "data-on": y(b[t]),
                            children: e
                        }, t))
                    }), (0, l.jsx)("div", {
                        className: "prdd-after",
                        children: j ? a : t
                    })]
                })
            }
            let E = ["var(--f-accent)", "var(--prdd-rose)", "var(--prdd-saffron)", "var(--prdd-leaf)"],
                X = [.86, .61, .39].map((e, t) => Array.from({
                    length: 10
                }, (a, l) => {
                    let r = (36 * l + 12 * t) * Math.PI / 180;
                    return {
                        left: `${(50+50*e*Math.cos(r)).toFixed(2)}%`,
                        top: `${(50+50*e*Math.sin(r)).toFixed(2)}%`,
                        "--dx": `${(16*Math.cos(r)).toFixed(2)}px`,
                        "--dy": `${(16*Math.sin(r)).toFixed(2)}px`,
                        background: E[l % E.length]
                    }
                }));

            function A({
                photo: e,
                pourLabel: t,
                after: a
            }) {
                let n = "edit" === (0, f.useMode)(),
                    s = (0, h.usePrefersReducedMotion)(),
                    i = R(),
                    o = g(),
                    d = (0, r.useRef)(null),
                    [c, u] = (0, r.useState)(0),
                    m = n ? 4 : c;
                return (0, h.useReplaySignal)(d, () => {
                    o.clear(), u(0)
                }), (0, l.jsxs)("div", {
                    ref: d,
                    className: "prdd-rangoli-wrap",
                    children: [(0, l.jsxs)("div", {
                        className: "prdd-rangoli",
                        children: [(0, l.jsx)(p.FX, {
                            template: x,
                            name: "rangoli",
                            className: "prdd-rangoli-sketch w-full"
                        }), (0, l.jsx)("div", {
                            className: "prdd-rangoli-photo",
                            "data-on": y(m >= 4),
                            children: e
                        }), [1, 2, 3].map(e => (0, l.jsx)(p.FX, {
                            template: x,
                            name: "rangoli",
                            className: `prdd-ring prdd-ring-${e} absolute left-0 top-0 w-full ${m>=e?"prdd-ring-on":""}`
                        }, e)), X.map((e, t) => (0, l.jsx)("span", {
                            className: "prdd-puffs",
                            "data-on": y(!n && m >= t + 1),
                            "aria-hidden": !0,
                            children: e.map((e, t) => (0, l.jsx)("i", {
                                style: e
                            }, t))
                        }, t))]
                    }), (0, l.jsx)("div", {
                        className: "prdd-after",
                        children: 0 === m ? (0, l.jsx)("button", {
                            type: "button",
                            className: "prdd-btn",
                            onClick: () => {
                                if (n || c > 0) return;
                                i.unlock();
                                let e = 650 * !s;
                                [1, 2, 3, 4].forEach((t, a) => o.at(a * e, () => {
                                    u(t), t < 4 ? i.play("chime", {
                                        volume: .35,
                                        rate: 1 + .12 * a
                                    }) : i.play("bell", {
                                        volume: .45
                                    })
                                }))
                            },
                            tabIndex: n ? -1 : void 0,
                            children: t
                        }) : m >= 4 ? a : null
                    })]
                })
            }
            let T = ["kaju-katli", "laddoo", "jalebi"];

            function D({
                openLabel: e,
                sweets: t,
                hint: a,
                done: n
            }) {
                let s = "edit" === (0, f.useMode)(),
                    i = R(),
                    o = (0, r.useRef)(null),
                    [d, c] = (0, r.useState)(!1),
                    [u, m] = (0, r.useState)(null),
                    [v, g] = (0, r.useState)([!1, !1, !1]),
                    M = s || d,
                    b = s || v.every(Boolean);
                return (0, h.useReplaySignal)(o, () => {
                    c(!1), m(null), g([!1, !1, !1])
                }), (0, l.jsxs)("div", {
                    ref: o,
                    className: "prdd-mithai-wrap",
                    children: [(0, l.jsxs)("div", {
                        className: "prdd-mithai",
                        "data-open": y(M),
                        children: [(0, l.jsx)(p.FX, {
                            template: x,
                            name: "mithai-box",
                            className: "w-full"
                        }), T.map((e, t) => (0, l.jsx)("button", {
                            type: "button",
                            className: `prdd-sweet prdd-sweet-${t+1}`,
                            "data-picked": y(u === t),
                            tabIndex: s || !M ? -1 : void 0,
                            onClick: () => {
                                !s && d && (i.play("paper", {
                                    volume: .35,
                                    rate: 1.25
                                }), i.play("chime", {
                                    volume: .35,
                                    rate: F[t + 1]
                                }), m(t), g(e => e.map((e, a) => e || a === t)))
                            },
                            children: (0, l.jsx)(p.FX, {
                                template: x,
                                name: e,
                                className: "w-full"
                            })
                        }, e)), (0, l.jsx)("span", {
                            className: "prdd-paper",
                            "aria-hidden": !0,
                            children: (0, l.jsx)("i", {})
                        })]
                    }), M ? s ? (0, l.jsx)("div", {
                        className: "prdd-sweet-cards",
                        children: t.map((e, t) => (0, l.jsxs)("div", {
                            className: "prdd-card prdd-sweet-card",
                            children: [e.name, e.line]
                        }, t))
                    }) : (0, l.jsx)("div", {
                        className: "prdd-sweet-cards",
                        children: null === u ? (0, l.jsx)("div", {
                            className: "prdd-after",
                            children: a
                        }) : (0, l.jsxs)("div", {
                            className: "prdd-card prdd-sweet-card prdd-pop",
                            children: [t[u].name, t[u].line]
                        }, u)
                    }) : (0, l.jsx)("div", {
                        className: "prdd-after",
                        children: (0, l.jsx)("button", {
                            type: "button",
                            className: "prdd-btn",
                            onClick: () => {
                                s || d || (i.unlock(), i.play("lid", {
                                    volume: .7
                                }), i.play("paper", {
                                    volume: .6,
                                    delay: .15
                                }), c(!0))
                            },
                            children: e
                        })
                    }), M && b ? (0, l.jsx)("div", {
                        className: "prdd-after",
                        children: n
                    }) : null]
                })
            }
            let O = ["kandil-hex", "kandil-star", "jharokha", "polaroid"];

            function B({
                index: e,
                children: t,
                caption: a
            }) {
                let n = "edit" === (0, f.useMode)(),
                    s = R(),
                    i = (0, r.useRef)(null),
                    [o, d] = (0, r.useState)(!1),
                    c = O[e % O.length],
                    u = "kandil-hex" === c || "kandil-star" === c;
                return (0, h.useReplaySignal)(i, () => d(!1)), (0, l.jsxs)("div", {
                    ref: i,
                    className: "prdd-kandil",
                    "data-frame": c,
                    "data-lit": y(n || o),
                    style: {
                        "--sway-delay": `${-(.7*e%3).toFixed(2)}s`
                    },
                    children: [u ? (0, l.jsx)("span", {
                        className: "prdd-kandil-string",
                        "aria-hidden": !0
                    }) : null, (0, l.jsxs)("div", {
                        className: "prdd-kandil-sway",
                        children: [(0, l.jsx)("span", {
                            className: "prdd-kandil-glow",
                            "aria-hidden": !0
                        }), (0, l.jsx)(p.Ki, {
                            template: x,
                            name: c,
                            holeClassName: "kandil-star" === c ? "rounded-full" : "rounded-[4px]",
                            className: "w-full",
                            children: t
                        }), n ? null : (0, l.jsx)("button", {
                            type: "button",
                            className: "prdd-kandil-tap",
                            "aria-pressed": o,
                            "aria-label": `Photo ${e+1}`,
                            onClick: () => {
                                s.unlock(), o || s.play("chime", {
                                    volume: .4,
                                    rate: F[e % F.length]
                                }), d(!o)
                            }
                        })]
                    }), (0, l.jsx)("div", {
                        className: "prdd-kandil-caption",
                        children: a
                    })]
                })
            }

            function V({
                heading: e,
                labels: t,
                writeLabel: a,
                writingLabel: n,
                done: s
            }) {
                let i = "edit" === (0, f.useMode)(),
                    o = (0, h.usePrefersReducedMotion)(),
                    d = !i && !o,
                    c = R(),
                    u = g(),
                    m = (0, r.useRef)(null),
                    M = (0, r.useRef)({}),
                    {
                        canvasRef: b,
                        inkRef: j,
                        engine: w
                    } = S(d, C(c)),
                    [N, k] = (0, r.useState)({}),
                    [z, I] = (0, r.useState)(!1),
                    [F, $] = (0, r.useState)(null),
                    E = (0, r.useRef)(null);
                (0, h.useReplaySignal)(m, () => {
                    u.clear(), w.current ? .clear(), k({}), I(!1)
                });
                let X = (e, t, a) => {
                        let l = m.current ? .getBoundingClientRect(),
                            r = M.current[e] ? .getBoundingClientRect();
                        return l && r ? {
                            x: r.left - l.left + r.width * t,
                            y: r.top - l.top + r.height * a
                        } : null
                    },
                    A = {
                        onPointerDown(e) {
                            if (i || e.target.closest("button")) return;
                            let t = m.current,
                                a = w.current;
                            if (!t || !a) return;
                            c.unlock();
                            let l = P(t, e.clientX, e.clientY);
                            if (z) {
                                t.setPointerCapture(e.pointerId), E.current ? .fizz.stop(), E.current = {
                                    pointer: e.pointerId,
                                    emitter: a.emitter("sparkler", l.x, l.y),
                                    fizz: c.loop("fizz", {
                                        volume: .5
                                    })
                                }, $(l);
                                return
                            }
                            let {
                                height: r
                            } = a.size();
                            a.launch(l.x, Math.min(l.y, .55 * r))
                        },
                        onPointerMove(e) {
                            if (!z || !m.current) return;
                            let t = P(m.current, e.clientX, e.clientY);
                            $(t), E.current ? .pointer === e.pointerId && w.current ? .moveEmitter(E.current.emitter, t.x, t.y)
                        },
                        onPointerUp(e) {
                            E.current ? .pointer === e.pointerId && (w.current ? .stopEmitter(E.current.emitter), E.current.fizz.stop(.3), E.current = null)
                        }
                    },
                    T = () => {
                        E.current && (w.current ? .stopEmitter(E.current.emitter), E.current.fizz.stop(.3), E.current = null)
                    };
                return (0, l.jsxs)("div", {
                    ref: m,
                    className: "prdd-play",
                    "data-live": y(d),
                    "data-writing": y(z),
                    onPointerDown: A.onPointerDown,
                    onPointerMove: A.onPointerMove,
                    onPointerUp: A.onPointerUp,
                    onPointerCancel: T,
                    children: [(0, l.jsx)("canvas", {
                        ref: j,
                        className: "prdd-canvas",
                        "aria-hidden": !0
                    }), (0, l.jsx)("canvas", {
                        ref: b,
                        className: "prdd-canvas",
                        "aria-hidden": !0
                    }), d ? null : (0, l.jsxs)("span", {
                        className: "prdd-still",
                        "aria-hidden": !0,
                        children: [(0, l.jsx)("i", {}), (0, l.jsx)("i", {}), (0, l.jsx)("i", {})]
                    }), (0, l.jsx)("div", {
                        className: "prdd-play-head",
                        children: e
                    }), z && F ? (0, l.jsx)("span", {
                        className: "prdd-wand",
                        style: {
                            transform: `translate(${F.x.toFixed(1)}px, ${F.y.toFixed(1)}px)`
                        },
                        "aria-hidden": !0,
                        children: (0, l.jsx)(p.FX, {
                            template: x,
                            name: "phuljhadi",
                            className: "w-full"
                        })
                    }) : null, (0, l.jsxs)("div", {
                        className: "prdd-toys",
                        children: [
                            ["anar", "chakri", "rocket"].map(e => (0, l.jsxs)("button", {
                                ref: t => {
                                    M.current[e] = t
                                },
                                type: "button",
                                className: `prdd-toy prdd-toy-${e}`,
                                "data-on": y(!!N[e]),
                                tabIndex: i ? -1 : void 0,
                                onClick: () => (e => {
                                    if (i || N[e]) return;
                                    c.unlock(), k(t => ({ ...t,
                                        [e]: !0
                                    }));
                                    let t = w.current;
                                    if ("rocket" === e) {
                                        let e = X("rocket", .5, .05);
                                        t && e ? t.launch(e.x, t.size().height * v(.1, .28), {
                                            fromY: e.y
                                        }) : c.play("whistle", {
                                            volume: .4
                                        }), u.at(2200, () => k(e => ({ ...e,
                                            rocket: !1
                                        })));
                                        return
                                    }
                                    let a = "anar" === e ? X("anar", .5, .06) : X("chakri", .48, .45),
                                        l = t && a ? t.emitter("anar" === e ? "fountain" : "spinner", a.x, a.y) : null,
                                        r = c.loop("anar" === e ? "fountain" : "whirr", {
                                            volume: .55
                                        });
                                    u.at(3600, () => {
                                        null !== l && w.current ? .stopEmitter(l), r.stop(.4), k(t => ({ ...t,
                                            [e]: !1
                                        }))
                                    })
                                })(e),
                                children: [(0, l.jsx)("span", {
                                    className: "prdd-toy-glow",
                                    "aria-hidden": !0
                                }), "rocket" === e ? (0, l.jsxs)("span", {
                                    className: "prdd-rocket",
                                    children: [(0, l.jsx)(p.FX, {
                                        template: x,
                                        name: "rocket",
                                        className: "prdd-rocket-bottle w-full"
                                    }), (0, l.jsx)(p.FX, {
                                        template: x,
                                        name: "rocket",
                                        className: "prdd-rocket-body absolute left-0 top-0 w-full"
                                    })]
                                }) : (0, l.jsx)(p.FX, {
                                    template: x,
                                    name: e,
                                    className: "w-full"
                                }), (0, l.jsx)("span", {
                                    className: "prdd-toy-label",
                                    children: t[e]
                                })]
                            }, e)), d ? (0, l.jsxs)("button", {
                                type: "button",
                                className: "prdd-toy prdd-toy-box",
                                "data-on": y(z),
                                onClick: () => {
                                    T(), I(!z), $(null)
                                },
                                children: [(0, l.jsx)(p.FX, {
                                    template: x,
                                    name: "phuljhadi-box",
                                    className: "w-full"
                                }), (0, l.jsx)("span", {
                                    className: "prdd-toy-label",
                                    children: z ? n : a
                                })]
                            }) : (0, l.jsx)("span", {
                                className: "prdd-toy prdd-toy-box",
                                "aria-hidden": !0,
                                children: (0, l.jsx)(p.FX, {
                                    template: x,
                                    name: "phuljhadi-box",
                                    className: "w-full"
                                })
                            })
                        ]
                    }), (0, l.jsx)("div", {
                        className: "prdd-play-done",
                        children: s
                    })]
                })
            }

            function L({
                hint: e,
                letter: t,
                skyLabel: a,
                ending: n,
                againLabel: i
            }) {
                let o, c, u, m, M = "edit" === (0, f.useMode)(),
                    b = (0, h.usePrefersReducedMotion)(),
                    j = !M && !b,
                    w = R(),
                    N = g(),
                    k = (0, r.useRef)(null),
                    z = (o = (0, f.useSite)(), c = o ? .page.sections.find(e => "cover" === e.type), u = c ? .values.toName, m = c ? .values.toFallback, "string" == typeof u && u.trim() || ("string" == typeof m ? m.trim() : "")),
                    {
                        canvasRef: P,
                        engine: I
                    } = S(j, C(w)),
                    [F, $] = (0, r.useState)("open");
                (0, r.useEffect)(() => $("sealed"), []);
                let E = M ? "open" : F,
                    X = "sealed" !== E && "snap" !== E,
                    A = "sky" === E || "end" === E;
                (0, h.useReplaySignal)(k, () => {
                    N.clear(), I.current ? .clear(), $("sealed")
                });
                let T = () => {
                    if (M) return;
                    N.clear(), w.unlock(), $("sky");
                    let e = I.current,
                        t = P.current;
                    if (!e || !t) return void N.at(900, () => $("end"));
                    e.clear();
                    let {
                        width: a,
                        height: l
                    } = e.size(), r = Math.min(.3 * l, 240);
                    [0, 450, 900, 1400, 1900, 2450].forEach((t, r) => N.at(t, () => e.launch(a * v(.15, .85), l * v(.1, .3), {
                        kind: s[r % s.length]
                    })));
                    let n = 3300;
                    z && (N.at(n, () => {
                        e.burst(a / 2, r, "peony", 0);
                        let l = t.ownerDocument.defaultView ? .getComputedStyle(t).fontFamily || "serif",
                            n = function(e, t, a, l, r) {
                                let n = t.trim();
                                if (!n) return [];
                                let s = e.createElement("canvas"),
                                    i = s.getContext("2d", {
                                        willReadFrequently: !0
                                    });
                                if (!i) return [];
                                let o = 120;
                                i.font = `600 ${o}px ${l}`, o = Math.max(28, Math.min(o, Math.floor(o * a * .9 / (i.measureText(n).width || 1)))), s.width = Math.ceil(a), s.height = Math.ceil(1.4 * o), i.font = `600 ${o}px ${l}`, i.textAlign = "center", i.textBaseline = "middle", i.fillStyle = "#fff", i.fillText(n, s.width / 2, s.height / 2);
                                let d = Math.max(3, Math.round(o / 22));
                                return (function(e, t, a, l, r) {
                                    let n = [];
                                    for (let r = 0; r < a; r += l)
                                        for (let a = 0; a < t; a += l) e[(r * t + a) * 4 + 3] > 128 && n.push([a, r]);
                                    if (n.length <= r) return n;
                                    let s = [],
                                        i = n.length / r;
                                    for (let e = 0; e < r; e += 1) s.push(n[Math.floor(e * i)]);
                                    return s
                                })(i.getImageData(0, 0, s.width, s.height).data, s.width, s.height, d, r).map(([e, t]) => [e - s.width / 2, t - s.height / 2])
                            }(t.ownerDocument, z, .86 * a, l, a < 640 ? 520 : 1e3);
                        e.form(n.map(([e, t]) => [e + a / 2, t + r]), 0)
                    }), n += 3300), N.at(n, () => {
                        let t = .22 * Math.min(a, l);
                        e.form(d(a < 640 ? 240 : 420).map(([e, l]) => [a / 2 + e * t, r + l * t]), 2), w.play("chime", {
                            volume: .5,
                            rate: 1.5
                        })
                    }), N.at(n + 2600, () => {
                        e.release(), e.launch(.25 * a, .2 * l, {
                            kind: "willow"
                        }), e.launch(.75 * a, .24 * l, {
                            kind: "willow"
                        })
                    }), N.at(n + 3200, () => $("end"))
                };
                return (0, l.jsxs)("div", {
                    ref: k,
                    className: "prdd-finale",
                    "data-phase": E,
                    children: [(0, l.jsx)("div", {
                        className: "prdd-letter-stage",
                        children: X ? (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("article", {
                                className: "prdd-letter",
                                children: t
                            }), (0, l.jsx)(p.FX, {
                                template: x,
                                name: "envelope-open",
                                className: "prdd-envelope-open"
                            }), (0, l.jsx)("div", {
                                className: "prdd-after",
                                children: (0, l.jsx)("button", {
                                    type: "button",
                                    className: "prdd-btn",
                                    onClick: T,
                                    tabIndex: M ? -1 : void 0,
                                    children: a
                                })
                            })]
                        }) : (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsxs)("button", {
                                type: "button",
                                className: "prdd-envelope",
                                onClick: () => {
                                    M || "sealed" !== F || (w.unlock(), w.play("seal", {
                                        volume: .8
                                    }), $("snap"), N.at(620 * !b, () => {
                                        w.play("unfold", {
                                            volume: .7
                                        }), $("open")
                                    }))
                                },
                                tabIndex: M ? -1 : void 0,
                                children: [(0, l.jsx)(p.FX, {
                                    template: x,
                                    name: "snap" === E ? "envelope-open" : "envelope-sealed",
                                    priority: !0,
                                    className: "w-full"
                                }), "snap" === E ? (0, l.jsxs)(l.Fragment, {
                                    children: [(0, l.jsx)("span", {
                                        className: "prdd-seal-half prdd-seal-l",
                                        "aria-hidden": !0,
                                        children: (0, l.jsx)("span", {
                                            children: (0, l.jsx)(p.FX, {
                                                template: x,
                                                name: "envelope-sealed",
                                                className: "w-full"
                                            })
                                        })
                                    }), (0, l.jsx)("span", {
                                        className: "prdd-seal-half prdd-seal-r",
                                        "aria-hidden": !0,
                                        children: (0, l.jsx)("span", {
                                            children: (0, l.jsx)(p.FX, {
                                                template: x,
                                                name: "envelope-sealed",
                                                className: "w-full"
                                            })
                                        })
                                    })]
                                }) : (0, l.jsx)("span", {
                                    className: "prdd-seal-glow",
                                    "aria-hidden": !0
                                })]
                            }), (0, l.jsx)("div", {
                                className: "prdd-after",
                                children: e
                            })]
                        })
                    }), M ? (0, l.jsx)("div", {
                        className: "prdd-ending-static",
                        children: n
                    }) : null, (0, l.jsxs)("div", {
                        className: "prdd-sky",
                        "data-on": y(A),
                        "aria-hidden": !A,
                        children: [(0, l.jsx)("canvas", {
                            ref: P,
                            className: "prdd-canvas font-(family-name:--f-display)",
                            "aria-hidden": !0
                        }), !j && A && z ? (0, l.jsx)("p", {
                            className: "prdd-sky-name",
                            children: z
                        }) : null, M ? null : (0, l.jsxs)("div", {
                            className: "prdd-end",
                            "data-on": y("end" === E),
                            children: [n, (0, l.jsx)("button", {
                                type: "button",
                                className: "prdd-btn prdd-btn-ghost",
                                onClick: T,
                                children: i
                            })]
                        })]
                    })]
                })
            }
        },
        80579: (e, t, a) => {
            "use strict";
            a.d(t, {
                Ok: () => n,
                nv: () => r
            }), a(1521), a(82161);
            let l = "https://cdn.cutiepage.in/template-seeds/diwali-audio",
                r = {
                    match: `${l}/sfx/match-v1.mp3`,
                    flame: `${l}/sfx/flame-v1.mp3`,
                    chime: `${l}/sfx/chime-v1.mp3`,
                    bell: `${l}/sfx/bell-v1.mp3`,
                    fizz: `${l}/sfx/fizz-v1.mp3`,
                    fountain: `${l}/sfx/fountain-v1.mp3`,
                    whirr: `${l}/sfx/whirr-v1.mp3`,
                    whistle: `${l}/sfx/whistle-v1.mp3`,
                    boom: `${l}/sfx/boom-v1.mp3`,
                    crackle: `${l}/sfx/crackle-v1.mp3`,
                    lid: `${l}/sfx/lid-v1.mp3`,
                    paper: `${l}/sfx/paper-v1.mp3`,
                    unfold: `${l}/sfx/unfold-v1.mp3`,
                    seal: `${l}/sfx/seal-v1.mp3`
                };

            function n(e) {
                let t = e ? e.AudioContext ? ? e.webkitAudioContext : void 0,
                    a = null,
                    l = null,
                    n = !1,
                    s = new Map,
                    i = new Set,
                    o = () => {
                        if (!t) return null;
                        if (!a) {
                            (l = (a = new t).createGain()).gain.value = +!n;
                            let e = a.createDynamicsCompressor();
                            l.connect(e).connect(a.destination)
                        }
                        return "suspended" === a.state && a.resume().catch(() => {}), a
                    },
                    d = (e, t, d) => {
                        let c, u = o();
                        if (!u || !l || n) return null;
                        let p = u.createGain();
                        p.gain.value = t.volume ? ? .7;
                        let h = (void 0 !== t.pan && u.createStereoPanner ? ((c = u.createStereoPanner()).pan.value = Math.max(-1, Math.min(1, t.pan)), p.connect(c).connect(l)) : p.connect(l), p),
                            f = {
                                src: null,
                                stopped: !1,
                                gain: p
                            };
                        return (e => {
                            let t = s.get(e);
                            if (!t) {
                                let l = a;
                                t = fetch(r[e]).then(e => e.ok ? e.arrayBuffer() : Promise.reject()).then(e => l.decodeAudioData(e)).catch(() => null), s.set(e, t)
                            }
                            return t
                        })(e).then(e => {
                            if (!e || f.stopped || !a) return;
                            let l = a.createBufferSource();
                            l.buffer = e, l.loop = d, l.playbackRate.value = t.rate ? ? 1, l.connect(h), l.onended = () => i.delete(l), i.add(l), l.start(a.currentTime + (t.delay ? ? 0)), f.src = l
                        }), f
                    };
                return {
                    play(e, t = {}) {
                        d(e, t, !1)
                    },
                    loop(e, t = {}) {
                        let l = d(e, t, !0);
                        return {
                            stop(e = .25) {
                                if (!l || (l.stopped = !0, !a || !l.src)) return;
                                let t = a.currentTime;
                                l.gain.gain.setTargetAtTime(0, t, Math.max(.01, e / 3)), l.src.stop(t + e + .05)
                            }
                        }
                    },
                    unlock() {
                        o()
                    },
                    setMuted(e) {
                        if (n = e, l && a && l.gain.setTargetAtTime(+!e, a.currentTime, .05), e)
                            for (let e of i) e.loop = !1
                    },
                    dispose() {
                        for (let e of i) try {
                            e.stop()
                        } catch {}
                        i.clear(), a ? .close().catch(() => {}), a = null
                    }
                }
            }
        }
    }
]);