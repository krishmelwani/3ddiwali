"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [76077], {
        373: (t, e, i) => {
            i.d(e, {
                e: () => s
            });

            function s(t, {
                style: e,
                vars: i
            }, n, r) {
                let a, o = t.style;
                for (a in e) o[a] = e[a];
                for (a in r ? .applyProjectionStyles(o, n), i) o.setProperty(a, i[a])
            }
        },
        956: (t, e, i) => {
            i.d(e, {
                w: () => s
            });
            let s = t => e => e.test(t)
        },
        1332: (t, e, i) => {
            i.d(e, {
                D: () => o,
                Y: () => a
            });
            var s = i(7050),
                n = i(87957),
                r = i(56315);
            let a = { ...i(88667).W,
                    color: s.y,
                    backgroundColor: s.y,
                    outlineColor: s.y,
                    fill: s.y,
                    stroke: s.y,
                    borderColor: s.y,
                    borderTopColor: s.y,
                    borderRightColor: s.y,
                    borderBottomColor: s.y,
                    borderLeftColor: s.y,
                    filter: n.p,
                    WebkitFilter: n.p,
                    mask: r.d,
                    WebkitMask: r.d
                },
                o = t => a[t]
        },
        1466: (t, e, i) => {
            i.d(e, {
                X: () => r
            });
            var s = i(69377),
                n = i(79560);

            function r(t, e = 100, i) {
                let a = i({ ...t,
                        keyframes: [0, e]
                    }),
                    o = Math.min((0, n.t)(a), n.Y);
                return {
                    type: "keyframes",
                    ease: t => a.next(o * t).value / e,
                    duration: (0, s.X)(o)
                }
            }
        },
        2730: (t, e, i) => {
            i.d(e, {
                T$: () => a,
                kE: () => o,
                px: () => d,
                x6: () => l
            });
            var s = i(48592),
                n = i(43868),
                r = i(38264);

            function a(t, e, i, s, n) {
                return t -= e, t = (0, r.hq)(t, 1 / i, s), void 0 !== n && (t = (0, r.hq)(t, 1 / n, s)), t
            }

            function o(t, e = 0, i = 1, r = .5, l, h = t, u = t) {
                if (n.KN.test(e) && (e = parseFloat(e), e = (0, s.k)(u.min, u.max, e / 100) - u.min), "number" != typeof e) return;
                let d = (0, s.k)(h.min, h.max, r);
                t === h && (d -= e), t.min = a(t.min, e, i, d, l), t.max = a(t.max, e, i, d, l)
            }

            function l(t, e, [i, s, n], r, a) {
                o(t, e[i], e[s], e[n], e.scale, r, a)
            }
            let h = ["x", "scaleX", "originX"],
                u = ["y", "scaleY", "originY"];

            function d(t, e, i, s) {
                l(t.x, e, h, i ? i.x : void 0, s ? s.x : void 0), l(t.y, e, u, i ? i.y : void 0, s ? s.y : void 0)
            }
        },
        3095: (t, e, i) => {
            i.d(e, {
                X: () => s
            });
            class s {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }
        },
        3846: (t, e, i) => {
            i.d(e, {
                h: () => c,
                q: () => p
            });
            var s = i(81676),
                n = i(27578),
                r = i(86993);
            let a = new Set,
                o = !1,
                l = !1,
                h = !1;

            function u() {
                if (l) {
                    let t = Array.from(a).filter(t => t.needsMeasurement),
                        e = new Set(t.map(t => t.element)),
                        i = new Map;
                    e.forEach(t => {
                        let e = (0, n.W9)(t);
                        e.length && (i.set(t, e), t.render())
                    }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                        t.render();
                        let e = i.get(t);
                        e && e.forEach(([e, i]) => {
                            t.getValue(e) ? .set(i)
                        })
                    }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    })
                }
                l = !1, o = !1, a.forEach(t => t.complete(h)), a.clear()
            }

            function d() {
                a.forEach(t => {
                    t.readKeyframes(), t.needsMeasurement && (l = !0)
                })
            }

            function p() {
                h = !0, d(), u(), h = !1
            }
            class c {
                constructor(t, e, i, s, n, r = !1) {
                    this.state = "pending", this.isAsync = !1, this.needsMeasurement = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = s, this.element = n, this.isAsync = r
                }
                scheduleResolve() {
                    this.state = "scheduled", this.isAsync ? (a.add(this), o || (o = !0, r.Gt.read(d), r.Gt.resolveKeyframes(u))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e,
                        element: i,
                        motionValue: n
                    } = this;
                    if (null === t[0]) {
                        let s = n ? .get(),
                            r = t[t.length - 1];
                        if (void 0 !== s) t[0] = s;
                        else if (i && e) {
                            let s = i.readValue(e, r);
                            null != s && (t[0] = s)
                        }
                        void 0 === t[0] && (t[0] = r), n && void 0 === s && n.set(t[0])
                    }(0, s.D)(t)
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete(t = !1) {
                    this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, t), a.delete(this)
                }
                cancel() {
                    "scheduled" === this.state && (a.delete(this), this.state = "pending")
                }
                resume() {
                    "pending" === this.state && this.scheduleResolve()
                }
            }
        },
        4121: (t, e, i) => {
            i.d(e, {
                c: () => n,
                n: () => r
            });
            var s = i(49399);
            let n = "framerAppearId",
                r = "data-" + (0, s.I)(n)
        },
        4179: (t, e, i) => {
            i.d(e, {
                w: () => s
            });
            let s = (t, e) => !!e && (t === e || s(t, e.parentElement))
        },
        4354: (t, e, i) => {
            i.d(e, {
                K: () => c
            });
            var s = i(23395),
                n = i(71405),
                r = i(93485),
                a = i(96900),
                o = i(3846),
                l = i(77306),
                h = i(3363),
                u = i(53475);
            let d = new Set(["auto", "none", "0"]);
            var p = i(27578);
            class c extends o.h {
                constructor(t, e, i, s, n) {
                    super(t, e, i, s, n, !0)
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        element: e,
                        name: i
                    } = this;
                    if (!e || !e.current) return;
                    super.readKeyframes();
                    for (let i = 0; i < t.length; i++) {
                        let s = t[i];
                        if ("string" == typeof s && (s = s.trim(), (0, a.pG)(s))) {
                            let n = (0, r.W)(s, e.current);
                            void 0 !== n && (t[i] = n), i === t.length - 1 && (this.finalKeyframe = s)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !s.$.has(i) || 2 !== t.length) return;
                    let [o, l] = t, h = (0, n.n)(o), u = (0, n.n)(l);
                    if ((0, a.rm)(o) !== (0, a.rm)(l) && p.Hr[i]) {
                        this.needsMeasurement = !0;
                        return
                    }
                    if (h !== u)
                        if ((0, p.E4)(h) && (0, p.E4)(u))
                            for (let e = 0; e < t.length; e++) {
                                let i = t[e];
                                "string" == typeof i && (t[e] = parseFloat(i))
                            } else p.Hr[i] && (this.needsMeasurement = !0)
                }
                resolveNoneKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, i = [];
                    for (let e = 0; e < t.length; e++) {
                        var s;
                        (null === t[e] || ("number" == typeof(s = t[e]) ? 0 === s : null === s || "none" === s || "0" === s || (0, l.$)(s))) && i.push(e)
                    }
                    i.length && function(t, e, i) {
                        let s, n = 0;
                        for (; n < t.length && !s;) {
                            let e = t[n];
                            "string" == typeof e && !d.has(e) && (0, h.V)(e).values.length && (s = t[n]), n++
                        }
                        if (s && i)
                            for (let n of e) t[n] = (0, u.J)(i, s)
                    }(t, i, e)
                }
                measureInitialState() {
                    let {
                        element: t,
                        unresolvedKeyframes: e,
                        name: i
                    } = this;
                    if (!t || !t.current) return;
                    "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = p.Hr[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    let s = e[e.length - 1];
                    void 0 !== s && t.getValue(i, s).jump(s, !1)
                }
                measureEndState() {
                    let {
                        element: t,
                        name: e,
                        unresolvedKeyframes: i
                    } = this;
                    if (!t || !t.current) return;
                    let s = t.getValue(e);
                    s && s.jump(this.measuredOrigin, !1);
                    let n = i.length - 1,
                        r = i[n];
                    i[n] = p.Hr[e](t.measureViewportBox(), window.getComputedStyle(t.current)), null !== r && void 0 === this.finalKeyframe && (this.finalKeyframe = r), this.removedTransforms ? .length && this.removedTransforms.forEach(([e, i]) => {
                        t.getValue(e).set(i)
                    }), this.resolveNoneKeyframes()
                }
            }
        },
        4761: (t, e, i) => {
            i.d(e, {
                Ag: () => u,
                CQ: () => n,
                HQ: () => r,
                N: () => h,
                dW: () => a,
                jA: () => d,
                vb: () => o,
                xC: () => l
            });
            var s = i(48592);

            function n(t) {
                return t.max - t.min
            }

            function r(t, e, i) {
                return Math.abs(t - e) <= i
            }

            function a(t, e, i, r = .5) {
                t.origin = r, t.originPoint = (0, s.k)(e.min, e.max, t.origin), t.scale = n(i) / n(e), t.translate = (0, s.k)(i.min, i.max, t.origin) - t.originPoint, (t.scale >= .9999 && t.scale <= 1.0001 || isNaN(t.scale)) && (t.scale = 1), (t.translate >= -.01 && t.translate <= .01 || isNaN(t.translate)) && (t.translate = 0)
            }

            function o(t, e, i, s) {
                a(t.x, e.x, i.x, s ? s.originX : void 0), a(t.y, e.y, i.y, s ? s.originY : void 0)
            }

            function l(t, e, i, r = 0) {
                t.min = (r ? (0, s.k)(i.min, i.max, r) : i.min) + e.min, t.max = t.min + n(e)
            }

            function h(t, e, i, s) {
                l(t.x, e.x, i.x, s ? .x), l(t.y, e.y, i.y, s ? .y)
            }

            function u(t, e, i, r = 0) {
                let a = r ? (0, s.k)(i.min, i.max, r) : i.min;
                t.min = e.min - a, t.max = t.min + n(e)
            }

            function d(t, e, i, s) {
                u(t.x, e.x, i.x, s ? .x), u(t.y, e.y, i.y, s ? .y)
            }
        },
        4894: (t, e, i) => {
            i.d(e, {
                w: () => s
            });
            let s = {
                hasAnimatedSinceResize: !0,
                hasEverUpdated: !1
            }
        },
        5156: (t, e, i) => {
            i.d(e, {
                B: () => r
            });
            var s = i(56963),
                n = i(79139);

            function r({
                keyframes: t,
                velocity: e = 0,
                power: i = .8,
                timeConstant: a = 325,
                bounceDamping: o = 10,
                bounceStiffness: l = 500,
                modifyTarget: h,
                min: u,
                max: d,
                restDelta: p = .5,
                restSpeed: c
            }) {
                let m, f, y = t[0],
                    v = {
                        done: !1,
                        value: y
                    },
                    g = i * e,
                    x = y + g,
                    T = void 0 === h ? x : h(x);
                T !== x && (g = T - y);
                let w = t => -g * Math.exp(-t / a),
                    S = t => T + w(t),
                    b = t => {
                        let e = w(t),
                            i = S(t);
                        v.done = Math.abs(e) <= p, v.value = v.done ? T : i
                    },
                    k = t => {
                        let e;
                        if (e = v.value, void 0 !== u && e < u || void 0 !== d && e > d) {
                            var i;
                            m = t, f = (0, s.o)({
                                keyframes: [v.value, (i = v.value, void 0 === u ? d : void 0 === d || Math.abs(u - i) < Math.abs(d - i) ? u : d)],
                                velocity: (0, n.z)(S, t, v.value),
                                damping: o,
                                stiffness: l,
                                restDelta: p,
                                restSpeed: c
                            })
                        }
                    };
                return k(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return (f || void 0 !== m || (e = !0, b(t), k(t)), void 0 !== m && t >= m) ? f.next(t - m) : (e || b(t), v)
                    }
                }
            }
        },
        6628: (t, e, i) => {
            i.d(e, {
                H: () => r
            });
            var s = i(87113),
                n = i(43868);
            let r = {
                rotate: n.uj,
                pathRotation: n.uj,
                rotateX: n.uj,
                rotateY: n.uj,
                rotateZ: n.uj,
                scale: s.hs,
                scaleX: s.hs,
                scaleY: s.hs,
                scaleZ: s.hs,
                skew: n.uj,
                skewX: n.uj,
                skewY: n.uj,
                distance: n.px,
                translateX: n.px,
                translateY: n.px,
                translateZ: n.px,
                x: n.px,
                y: n.px,
                z: n.px,
                perspective: n.px,
                transformPerspective: n.px,
                opacity: s.X4,
                originX: n.gQ,
                originY: n.gQ,
                originZ: n.px
            }
        },
        6998: (t, e, i) => {
            i.d(e, {
                A: () => v
            });
            var s = i(16357),
                n = i(20381),
                r = i(40303),
                a = i(26713),
                o = i(30396),
                l = i(3846),
                h = i(45989),
                u = i(99296),
                d = i(64590),
                p = i(3363);
            let c = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && (p.f.test(t) || "0" === t) && !t.startsWith("url("));
            var m = i(61144),
                f = i(8320),
                y = i(95807);
            class v extends f.q {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: i = "keyframes",
                    repeat: s = 0,
                    repeatDelay: n = 0,
                    repeatType: a = "loop",
                    keyframes: o,
                    name: h,
                    motionValue: u,
                    element: d,
                    ...p
                }) {
                    super(), this.stop = () => {
                        this._animation && (this._animation.stop(), this.stopTimeline ? .()), this.keyframeResolver ? .cancel()
                    }, this.createdAt = r.k.now();
                    const c = {
                            autoplay: t,
                            delay: e,
                            type: i,
                            repeat: s,
                            repeatDelay: n,
                            repeatType: a,
                            name: h,
                            motionValue: u,
                            element: d,
                            ...p
                        },
                        m = d ? .KeyframeResolver || l.h;
                    this.keyframeResolver = new m(o, (t, e, i) => this.onKeyframesResolved(t, e, c, !i), h, u, d), this.keyframeResolver ? .scheduleResolve()
                }
                onKeyframesResolved(t, e, i, l) {
                    let p;
                    this.keyframeResolver = void 0;
                    let {
                        name: f,
                        type: v,
                        velocity: g,
                        delay: x,
                        isHandoff: T,
                        onUpdate: w
                    } = i;
                    this.resolvedAt = r.k.now();
                    let S = !0;
                    ! function(t, e, i, s) {
                        let n = t[0];
                        if (null === n) return !1;
                        if ("display" === e || "visibility" === e) return !0;
                        let r = t[t.length - 1],
                            a = c(n, e),
                            o = c(r, e);
                        return (0, u.$)(a === o, `You are trying to animate ${e} from "${n}" to "${r}". "${a?r:n}" is not an animatable value.`, "value-not-animatable"), !!a && !!o && (function(t) {
                            let e = t[0];
                            if (1 === t.length) return !0;
                            for (let i = 0; i < t.length; i++)
                                if (t[i] !== e) return !0
                        }(t) || ("spring" === i || (0, d.W)(i)) && s)
                    }(t, f, v, g) && (S = !1, (s.W.instantAnimations || !x) && w ? .((0, o.X)(t, i, e)), t[0] = t[t.length - 1], (0, m._)(i), i.repeat = 0);
                    let b = {
                            startTime: l ? this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt : void 0,
                            finalKeyframe: e,
                            ...i,
                            keyframes: t
                        },
                        k = S && !T && (0, y.R)(b),
                        P = b.motionValue ? .owner ? .current;
                    if (k) try {
                        p = new h.n({ ...b,
                            element: P
                        })
                    } catch {
                        p = new a.s(b)
                    } else p = new a.s(b);
                    p.finished.then(() => {
                        this.notifyFinished()
                    }).catch(n.l), this.pendingTimeline && (this.stopTimeline = p.attachTimeline(this.pendingTimeline), this.pendingTimeline = void 0), this._animation = p
                }
                get finished() {
                    return this._animation ? this.animation.finished : this._finished
                }
                then(t, e) {
                    return this.finished.finally(t).then(() => {})
                }
                get animation() {
                    return this._animation || (this.keyframeResolver ? .resume(), (0, l.q)()), this._animation
                }
                get duration() {
                    return this.animation.duration
                }
                get iterationDuration() {
                    return this.animation.iterationDuration
                }
                get time() {
                    return this.animation.time
                }
                set time(t) {
                    this.animation.time = t
                }
                get speed() {
                    return this.animation.speed
                }
                get state() {
                    return this.animation.state
                }
                set speed(t) {
                    this.animation.speed = t
                }
                get startTime() {
                    return this.animation.startTime
                }
                attachTimeline(t) {
                    return this._animation ? this.stopTimeline = this.animation.attachTimeline(t) : this.pendingTimeline = t, () => this.stop()
                }
                play() {
                    this.animation.play()
                }
                pause() {
                    this.animation.pause()
                }
                complete() {
                    this.animation.complete()
                }
                cancel() {
                    this._animation && this.animation.cancel(), this.keyframeResolver ? .cancel()
                }
            }
        },
        7219: (t, e, i) => {
            i.d(e, {
                P: () => r,
                q: () => n
            });
            var s = i(43868);

            function n(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            let r = {
                correct: (t, e) => {
                    if (!e.target) return t;
                    if ("string" == typeof t)
                        if (!s.px.test(t)) return t;
                        else t = parseFloat(t);
                    let i = n(t, e.target.x),
                        r = n(t, e.target.y);
                    return `${i}% ${r}%`
                }
            }
        },
        8029: (t, e, i) => {
            i.d(e, {
                c: () => f,
                L: () => m
            });
            var s = i(79393),
                n = i(77819),
                r = i(94221),
                a = i(57243),
                o = i(10489),
                l = i(82342),
                h = i(60600);

            function u(t, e) {
                if (!Array.isArray(e)) return !1;
                let i = e.length;
                if (i !== t.length) return !1;
                for (let s = 0; s < i; s++)
                    if (e[s] !== t[s]) return !1;
                return !0
            }
            var d = i(21109);
            let p = [...d.U].reverse(),
                c = d.U.length;

            function m(t) {
                let e = e => Promise.all(e.map(({
                        animation: e,
                        options: i
                    }) => (0, s._)(t, e, i))),
                    i = v(),
                    d = !0,
                    m = !1,
                    y = e => (i, s) => {
                        let n = (0, h.K)(t, s, "exit" === e ? t.presenceContext ? .custom : void 0);
                        if (n) {
                            let {
                                transition: t,
                                transitionEnd: e,
                                ...s
                            } = n;
                            i = { ...i,
                                ...s,
                                ...e
                            }
                        }
                        return i
                    };

                function g(s) {
                    let {
                        props: v
                    } = t, g = (0, r.V)(t.parent) || {}, x = [], T = new Set, w = {}, S = 1 / 0;
                    for (let e = 0; e < c; e++) {
                        let r = p[e],
                            c = i[r],
                            b = void 0 !== v[r] ? v[r] : g[r],
                            k = (0, l.w)(b),
                            P = r === s ? c.isActive : null;
                        !1 === P && (S = e);
                        let A = b === g[r] && b !== v[r] && k;
                        if (A && (d || m) && t.manuallyAnimateOnMount && (A = !1), c.protectedKeys = { ...w
                            }, !c.isActive && null === P || !b && !c.prevProp || (0, a.N)(b) || "boolean" == typeof b) continue;
                        if ("exit" === r && c.isActive && !0 !== P) {
                            c.prevResolvedValues && (w = { ...w,
                                ...c.prevResolvedValues
                            });
                            continue
                        }
                        let V = f(c.prevProp, b),
                            M = V || r === s && c.isActive && !A && k || e > S && k,
                            D = !1,
                            R = Array.isArray(b) ? b : [b],
                            C = R.reduce(y(r), {});
                        !1 === P && (C = {});
                        let {
                            prevResolvedValues: E = {}
                        } = c, B = { ...E,
                            ...C
                        }, j = e => {
                            M = !0, T.has(e) && (D = !0, T.delete(e)), c.needsAnimating[e] = !0;
                            let i = t.getValue(e);
                            i && (i.liveStyle = !1)
                        };
                        for (let t in B) {
                            let e = C[t],
                                i = E[t];
                            if (!w.hasOwnProperty(t))((0, o.p)(e) && (0, o.p)(i) ? !u(e, i) || V : e !== i) ? null != e ? j(t) : T.add(t) : void 0 !== e && T.has(t) ? j(t) : c.protectedKeys[t] = !0
                        }
                        c.prevProp = b, c.prevResolvedValues = C, c.isActive && (w = { ...w,
                            ...C
                        }), (d || m) && t.blockInitialAnimation && (M = !1);
                        let L = A && V,
                            F = !L || D;
                        M && F && x.push(...R.map(e => {
                            let i = {
                                type: r
                            };
                            if ("string" == typeof e && (d || m) && !L && t.manuallyAnimateOnMount && t.parent) {
                                let {
                                    parent: s
                                } = t, r = (0, h.K)(s, e);
                                if (s.enteringChildren && r) {
                                    let {
                                        delayChildren: e
                                    } = r.transition || {};
                                    i.delay = (0, n.L)(s.enteringChildren, t, e)
                                }
                            }
                            return {
                                animation: e,
                                options: i
                            }
                        }))
                    }
                    if (T.size) {
                        let e = {};
                        if ("boolean" != typeof v.initial) {
                            let i = (0, h.K)(t, Array.isArray(v.initial) ? v.initial[0] : v.initial);
                            i && i.transition && (e.transition = i.transition)
                        }
                        T.forEach(i => {
                            let s = t.getBaseTarget(i),
                                n = t.getValue(i);
                            n && (n.liveStyle = !0), e[i] = s ? ? null
                        }), x.push({
                            animation: e
                        })
                    }
                    let b = !!x.length;
                    return d && (!1 === v.initial || v.initial === v.animate) && !t.manuallyAnimateOnMount && (b = !1), d = !1, m = !1, b ? e(x) : Promise.resolve()
                }
                return {
                    animateChanges: g,
                    setActive: function(e, s) {
                        if (i[e].isActive === s) return Promise.resolve();
                        t.variantChildren ? .forEach(t => t.animationState ? .setActive(e, s)), i[e].isActive = s;
                        let n = g(e);
                        for (let t in i) i[t].protectedKeys = {};
                        return n
                    },
                    setAnimateFunction: function(i) {
                        e = i(t)
                    },
                    getState: () => i,
                    reset: () => {
                        i = v(), m = !0
                    }
                }
            }

            function f(t, e) {
                return "string" == typeof e ? e !== t : !!Array.isArray(e) && !u(e, t)
            }

            function y(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }

            function v() {
                return {
                    animate: y(!0),
                    whileInView: y(),
                    whileHover: y(),
                    whileTap: y(),
                    whileDrag: y(),
                    whileFocus: y(),
                    exit: y()
                }
            }
        },
        8246: (t, e, i) => {
            i.d(e, {
                E: () => o
            });
            var s = i(5156),
                n = i(91437),
                r = i(56963);
            let a = {
                decay: s.B,
                inertia: s.B,
                tween: n.i,
                keyframes: n.i,
                spring: r.o
            };

            function o(t) {
                "string" == typeof t.type && (t.type = a[t.type])
            }
        },
        8280: (t, e, i) => {
            i.d(e, {
                d: () => s
            });
            let s = ([t, e, i, s]) => `cubic-bezier(${t}, ${e}, ${i}, ${s})`
        },
        8320: (t, e, i) => {
            i.d(e, {
                q: () => s
            });
            class s {
                constructor() {
                    this.updateFinished()
                }
                get finished() {
                    return this._finished
                }
                updateFinished() {
                    this._finished = new Promise(t => {
                        this.resolve = t
                    })
                }
                notifyFinished() {
                    this.resolve()
                }
                then(t, e) {
                    return this.finished.then(t, e)
                }
            }
        },
        8915: (t, e, i) => {
            i.d(e, {
                U: () => a
            });
            var s = i(61624),
                n = i(60600),
                r = i(10489);

            function a(t, e) {
                let {
                    transitionEnd: i = {},
                    transition: a = {},
                    ...o
                } = (0, n.K)(t, e) || {};
                for (let e in o = { ...o,
                        ...i
                    }) {
                    var l;
                    let i = (l = o[e], (0, r.p)(l) ? l[l.length - 1] || 0 : l);
                    t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, (0, s.OQ)(i))
                }
            }
        },
        9385: (t, e, i) => {
            i.d(e, {
                P: () => a,
                i: () => r
            });
            var s = i(46858),
                n = i(62505);
            let r = {
                    current: void 0
                },
                a = (0, s.u0)({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!r.current) {
                            let t = new n.B({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), r.current = t
                        }
                        return r.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
                })
        },
        9627: (t, e, i) => {
            i.d(e, {
                I: () => s
            });

            function s(t, e, i) {
                let s = "",
                    n = t.x.translate / e.x,
                    r = t.y.translate / e.y,
                    a = i ? .z || 0;
                if ((n || r || a) && (s = `translate3d(${n}px, ${r}px, ${a}px) `), (1 !== e.x || 1 !== e.y) && (s += `scale(${1/e.x}, ${1/e.y}) `), i) {
                    let {
                        transformPerspective: t,
                        rotate: e,
                        pathRotation: n,
                        rotateX: r,
                        rotateY: a,
                        skewX: o,
                        skewY: l
                    } = i;
                    t && (s = `perspective(${t}px) ${s}`), e && (s += `rotate(${e}deg) `), n && (s += `rotate(${n}deg) `), r && (s += `rotateX(${r}deg) `), a && (s += `rotateY(${a}deg) `), o && (s += `skewX(${o}deg) `), l && (s += `skewY(${l}deg) `)
                }
                let o = t.x.scale * e.x,
                    l = t.y.scale * e.y;
                return (1 !== o || 1 !== l) && (s += `scale(${o}, ${l})`), s || "none"
            }
        },
        10489: (t, e, i) => {
            i.d(e, {
                p: () => s
            });
            let s = t => Array.isArray(t)
        },
        12166: (t, e, i) => {
            i.d(e, {
                zK: () => r
            });
            var s = i(53716),
                n = i(33172);

            function r(t, {
                layout: e,
                layoutId: i
            }) {
                return s.f.has(t) || t.startsWith("origin") || (e || void 0 !== i) && (!!n.H[t] || "opacity" === t)
            }
        },
        13970: (t, e, i) => {
            i.d(e, {
                Sz: () => a,
                ZZ: () => l,
                dg: () => o
            });
            var s = i(79765),
                n = i(45779),
                r = i(55638);
            let a = (0, s.A)(.33, 1.53, .69, .99),
                o = (0, r.G)(a),
                l = (0, n.V)(o)
        },
        14746: (t, e, i) => {
            i.d(e, {
                k: () => n
            });
            var s = i(81425);

            function n(t) {
                return !!((0, s.S)(t) && t.add)
            }
        },
        15002: (t, e, i) => {
            i.d(e, {
                O: () => l
            });
            var s = i(49894),
                n = i(88667),
                r = i(53716),
                a = i(96900),
                o = i(37862);

            function l(t, e, i) {
                let {
                    style: l,
                    vars: h,
                    transformOrigin: u
                } = t, d = !1, p = !1;
                for (let t in e) {
                    let i = e[t];
                    if (r.f.has(t)) {
                        d = !0;
                        continue
                    }
                    if ((0, a.j4)(t)) {
                        h[t] = i;
                        continue
                    } {
                        let e = (0, s.e)(i, n.W[t]);
                        t.startsWith("origin") ? (p = !0, u[t] = e) : l[t] = e
                    }
                }
                if (!e.transform && (d || i ? l.transform = (0, o.d)(e, t.transform, i) : l.transform && (l.transform = "none")), p) {
                    let {
                        originX: t = "50%",
                        originY: e = "50%",
                        originZ: i = 0
                    } = u;
                    l.transformOrigin = `${t} ${e} ${i}`
                }
            }
        },
        16492: (t, e, i) => {
            i.d(e, {
                M: () => s
            });
            let s = new Set(["opacity", "clipPath", "filter", "transform"])
        },
        16623: (t, e, i) => {
            i.d(e, {
                k: () => s
            });

            function s(t, e, i, n = {
                passive: !0
            }) {
                return t.addEventListener(e, i, n), () => t.removeEventListener(e, i)
            }
        },
        16960: (t, e, i) => {
            i.d(e, {
                x: () => a
            });
            var s = i(81425),
                n = i(53716),
                r = i(74423);

            function a(t, e, i) {
                let a = (0, r.x)(t, e, i);
                for (let i in t)((0, s.S)(t[i]) || (0, s.S)(e[i])) && (a[-1 !== n.U.indexOf(i) ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i] = t[i]);
                return a
            }
        },
        18647: (t, e, i) => {
            i.d(e, {
                B: () => a
            });
            var s = i(15002),
                n = i(22535);
            let r = ["offsetDistance", "offsetPath", "offsetRotate", "offsetAnchor"];

            function a(t, {
                attrX: e,
                attrY: i,
                attrScale: o,
                pathLength: l,
                pathSpacing: h = 1,
                pathOffset: u = 0,
                ...d
            }, p, c, m) {
                if ((0, s.O)(t, d, c), p) {
                    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
                    return
                }
                t.attrs = t.style, t.style = {};
                let {
                    attrs: f,
                    style: y
                } = t;
                for (let t of (f.transform && (y.transform = f.transform, delete f.transform), (y.transform || f.transformOrigin) && (y.transformOrigin = f.transformOrigin ? ? "50% 50%", delete f.transformOrigin), y.transform && (y.transformBox = m ? .transformBox ? ? "fill-box", delete f.transformBox), r)) void 0 !== f[t] && (y[t] = f[t], delete f[t]);
                void 0 !== e && (f.x = e), void 0 !== i && (f.y = i), void 0 !== o && (f.scale = o), void 0 !== l && (0, n.C)(f, l, h, u, !1)
            }
        },
        19503: (t, e, i) => {
            function s(t) {
                return void 0 === t || 1 === t
            }

            function n({
                scale: t,
                scaleX: e,
                scaleY: i
            }) {
                return !s(t) || !s(e) || !s(i)
            }

            function r(t) {
                return n(t) || a(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function a(t) {
                var e, i;
                return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
            }
            i.d(e, {
                HD: () => r,
                vF: () => a,
                vk: () => n
            })
        },
        20719: (t, e, i) => {
            i.d(e, {
                D: () => n,
                I: () => s
            });
            let s = {
                x: !1,
                y: !1
            };

            function n() {
                return s.x || s.y
            }
        },
        21109: (t, e, i) => {
            i.d(e, {
                U: () => s,
                _: () => n
            });
            let s = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                n = ["initial", ...s]
        },
        21962: (t, e, i) => {
            function s(t, e) {
                t.min = e.min, t.max = e.max
            }

            function n(t, e) {
                s(t.x, e.x), s(t.y, e.y)
            }

            function r(t, e) {
                t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin
            }
            i.d(e, {
                Hy: () => n,
                be: () => s,
                xD: () => r
            })
        },
        22171: (t, e, i) => {
            i.d(e, {
                Uu: () => r
            });
            var s = i(29736);
            let n = "u" > typeof window;

            function r() {
                if (s.r.current = !0, n)
                    if (window.matchMedia) {
                        let t = window.matchMedia("(prefers-reduced-motion)"),
                            e = () => s.O.current = t.matches;
                        t.addEventListener("change", e), e()
                    } else s.O.current = !1
            }
        },
        22535: (t, e, i) => {
            i.d(e, {
                C: () => r
            });
            let s = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                n = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function r(t, e, i = 1, a = 0, o = !0) {
                t.pathLength = 1;
                let l = o ? s : n;
                t[l.offset] = `${-a}`, t[l.array] = `${e} ${i}`
            }
        },
        23395: (t, e, i) => {
            i.d(e, {
                $: () => s
            });
            let s = new Set(["width", "height", "top", "left", "right", "bottom", ...i(53716).U])
        },
        23680: (t, e, i) => {
            i.d(e, {
                n: () => s
            });
            let s = t => "string" == typeof t && "svg" === t.toLowerCase()
        },
        24700: (t, e, i) => {
            function s(t) {
                let e = [{}, {}];
                return t ? .values.forEach((t, i) => {
                    e[0][i] = t.get(), e[1][i] = t.getVelocity()
                }), e
            }

            function n(t, e, i, n) {
                if ("function" == typeof e) {
                    let [r, a] = s(n);
                    e = e(void 0 !== i ? i : t.custom, r, a)
                }
                if ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e) {
                    let [r, a] = s(n);
                    e = e(void 0 !== i ? i : t.custom, r, a)
                }
                return e
            }
            i.d(e, {
                a: () => n
            })
        },
        24756: (t, e, i) => {
            i.d(e, {
                O: () => o,
                e: () => a
            });
            var s = i(57243),
                n = i(82342),
                r = i(21109);

            function a(t) {
                return (0, s.N)(t.animate) || r._.some(e => (0, n.w)(t[e]))
            }

            function o(t) {
                return !!(a(t) || t.variants)
            }
        },
        25051: (t, e, i) => {
            i.d(e, {
                u: () => n
            });
            var s = i(81425);

            function n(t) {
                return (0, s.S)(t) ? t.get() : t
            }
        },
        26713: (t, e, i) => {
            i.d(e, {
                s: () => x,
                L: () => T
            });
            var s = i(69413),
                n = i(32796),
                r = i(69377),
                a = i(40303),
                o = i(48846),
                l = i(21487),
                h = i(86993);
            let u = t => {
                let e = ({
                    timestamp: e
                }) => t(e);
                return {
                    start: (t = !0) => h.Gt.update(e, t),
                    stop: () => (0, h.WG)(e),
                    now: () => h.uv.isProcessing ? h.uv.timestamp : a.k.now()
                }
            };
            var d = i(5156),
                p = i(91437),
                c = i(79560),
                m = i(79139),
                f = i(30396),
                y = i(8246),
                v = i(8320);
            let g = t => t / 100;
            class x extends v.q {
                constructor(t) {
                    super(), this.state = "idle", this.startTime = null, this.isStopped = !1, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.delayState = {
                        done: !1,
                        value: void 0
                    }, this.stop = () => {
                        let {
                            motionValue: t
                        } = this.options;
                        t && t.updatedAt !== a.k.now() && this.tick(a.k.now()), this.isStopped = !0, "idle" !== this.state && (this.teardown(), this.options.onStop ? .())
                    }, o.q.mainThread++, this.options = t, this.initAnimation(), this.play(), !1 === t.autoplay && this.pause()
                }
                initAnimation() {
                    let {
                        options: t
                    } = this;
                    (0, y.E)(t);
                    let {
                        type: e = p.i,
                        repeat: i = 0,
                        repeatDelay: n = 0,
                        repeatType: r,
                        velocity: a = 0
                    } = t, {
                        keyframes: o
                    } = t, h = e || p.i;
                    h !== p.i && "number" != typeof o[0] && (this.mixKeyframes = (0, s.F)(g, (0, l.j)(o[0], o[1])), o = [0, 100]);
                    let u = h({ ...t,
                        keyframes: o
                    });
                    "mirror" === r && (this.mirroredGenerator = h({ ...t,
                        keyframes: [...o].reverse(),
                        velocity: -a
                    })), null === u.calculatedDuration && (u.calculatedDuration = (0, c.t)(u));
                    let {
                        calculatedDuration: d
                    } = u;
                    this.calculatedDuration = d, this.resolvedDuration = d + n, this.totalDuration = this.resolvedDuration * (i + 1) - n, this.generator = u
                }
                updateTime(t) {
                    let e = Math.round(t - this.startTime) * this.playbackSpeed;
                    null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = e
                }
                tick(t, e = !1) {
                    let i, {
                        generator: s,
                        totalDuration: r,
                        mixKeyframes: a,
                        mirroredGenerator: o,
                        resolvedDuration: l,
                        calculatedDuration: h
                    } = this;
                    if (null === this.startTime) return s.next(0);
                    let {
                        delay: u = 0,
                        keyframes: p,
                        repeat: c,
                        repeatType: m,
                        repeatDelay: y,
                        type: v,
                        onUpdate: g,
                        finalKeyframe: x
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - r / this.speed, this.startTime)), e ? this.currentTime = t : this.updateTime(t);
                    let T = this.currentTime - u * (this.playbackSpeed >= 0 ? 1 : -1),
                        w = this.playbackSpeed >= 0 ? T < 0 : T > r;
                    this.currentTime = Math.max(T, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = r);
                    let S = this.currentTime,
                        b = s;
                    if (c) {
                        let t = Math.min(this.currentTime, r) / l,
                            e = Math.floor(t),
                            i = t % 1;
                        !i && t >= 1 && (i = 1), 1 === i && e--, (e = Math.min(e, c + 1)) % 2 && ("reverse" === m ? (i = 1 - i, y && (i -= y / l)) : "mirror" === m && (b = o)), S = (0, n.q)(0, 1, i) * l
                    }
                    w ? (this.delayState.value = p[0], i = this.delayState) : i = b.next(S), a && !w && (i.value = a(i.value));
                    let {
                        done: k
                    } = i;
                    w || null === h || (k = this.playbackSpeed >= 0 ? this.currentTime >= r : this.currentTime <= 0);
                    let P = null === this.holdTime && ("finished" === this.state || "running" === this.state && k);
                    return P && v !== d.B && (i.value = (0, f.X)(p, this.options, x, this.speed)), g && g(i.value), P && this.finish(), i
                }
                then(t, e) {
                    return this.finished.then(t, e)
                }
                get duration() {
                    return (0, r.X)(this.calculatedDuration)
                }
                get iterationDuration() {
                    let {
                        delay: t = 0
                    } = this.options || {};
                    return this.duration + (0, r.X)(t)
                }
                get time() {
                    return (0, r.X)(this.currentTime)
                }
                set time(t) {
                    t = (0, r.f)(t), this.currentTime = t, null === this.startTime || null !== this.holdTime || 0 === this.playbackSpeed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.playbackSpeed), this.driver ? this.driver.start(!1) : (this.startTime = 0, this.state = "paused", this.holdTime = t, this.tick(t))
                }
                getGeneratorVelocity() {
                    let t = this.currentTime;
                    if (t <= 0) return this.options.velocity || 0;
                    if (this.generator.velocity) return this.generator.velocity(t);
                    let e = this.generator.next(t).value;
                    return (0, m.z)(t => this.generator.next(t).value, t, e)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    let e = this.playbackSpeed !== t;
                    e && this.driver && this.updateTime(a.k.now()), this.playbackSpeed = t, e && this.driver && (this.time = (0, r.X)(this.currentTime))
                }
                play() {
                    if (this.isStopped) return;
                    let {
                        driver: t = u,
                        startTime: e
                    } = this.options;
                    this.driver || (this.driver = t(t => this.tick(t))), this.options.onPlay ? .();
                    let i = this.driver.now();
                    "finished" === this.state ? (this.updateFinished(), this.startTime = i) : null !== this.holdTime ? this.startTime = i - this.holdTime : this.startTime || (this.startTime = e ? ? i), "finished" === this.state && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    this.state = "paused", this.updateTime(a.k.now()), this.holdTime = this.currentTime
                }
                complete() {
                    "running" !== this.state && this.play(), this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.notifyFinished(), this.teardown(), this.state = "finished", this.options.onComplete ? .()
                }
                cancel() {
                    this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), this.options.onCancel ? .()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.startTime = this.holdTime = null, o.q.mainThread--
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
                attachTimeline(t) {
                    return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), this.driver ? .stop(), t.observe(this)
                }
            }

            function T(t) {
                return new x(t)
            }
        },
        27578: (t, e, i) => {
            i.d(e, {
                E4: () => o,
                Hr: () => d,
                W9: () => u
            });
            var s = i(95214),
                n = i(53716),
                r = i(87113),
                a = i(43868);
            let o = t => t === r.ai || t === a.px,
                l = new Set(["x", "y", "z"]),
                h = n.U.filter(t => !l.has(t));

            function u(t) {
                let e = [];
                return h.forEach(i => {
                    let s = t.getValue(i);
                    void 0 !== s && (e.push([i, s.get()]), s.set(+!!i.startsWith("scale")))
                }), e
            }
            let d = {
                width: ({
                    x: t
                }, {
                    paddingLeft: e = "0",
                    paddingRight: i = "0",
                    boxSizing: s
                }) => {
                    let n = t.max - t.min;
                    return "border-box" === s ? n : n - parseFloat(e) - parseFloat(i)
                },
                height: ({
                    y: t
                }, {
                    paddingTop: e = "0",
                    paddingBottom: i = "0",
                    boxSizing: s
                }) => {
                    let n = t.max - t.min;
                    return "border-box" === s ? n : n - parseFloat(e) - parseFloat(i)
                },
                top: (t, {
                    top: e
                }) => parseFloat(e),
                left: (t, {
                    left: e
                }) => parseFloat(e),
                bottom: ({
                    y: t
                }, {
                    top: e
                }) => parseFloat(e) + (t.max - t.min),
                right: ({
                    x: t
                }, {
                    left: e
                }) => parseFloat(e) + (t.max - t.min),
                x: (t, {
                    transform: e
                }) => (0, s.ry)(e, "x"),
                y: (t, {
                    transform: e
                }) => (0, s.ry)(e, "y")
            };
            d.translateX = d.x, d.translateY = d.y
        },
        28110: (t, e, i) => {
            i.d(e, {
                T: () => function t(e, i) {
                    if (e) return "function" == typeof e ? (0, n.n)() ? (0, r.K)(e, i) : "ease-out" : (0, s.D)(e) ? (0, a.d)(e) : Array.isArray(e) ? e.map(e => t(e, i) || o.e.easeOut) : o.e[e]
                }
            });
            var s = i(41983),
                n = i(81220),
                r = i(54655),
                a = i(8280),
                o = i(52130)
        },
        29736: (t, e, i) => {
            i.d(e, {
                O: () => s,
                r: () => n
            });
            let s = {
                    current: null
                },
                n = {
                    current: !1
                }
        },
        30286: (t, e, i) => {
            i.d(e, {
                R: () => a
            });
            var s = i(48846),
                n = i(78754),
                r = i(28110);

            function a(t, e, i, {
                delay: o = 0,
                duration: l = 300,
                repeat: h = 0,
                repeatType: u = "loop",
                ease: d = "easeOut",
                times: p
            } = {}, c) {
                let m = {
                    [e]: i
                };
                p && (m.offset = p);
                let f = (0, r.T)(d, l);
                Array.isArray(f) && (m.easing = f), n.Q.value && s.q.waapi++;
                let y = {
                    delay: o,
                    duration: l,
                    easing: Array.isArray(f) ? "linear" : f,
                    fill: "both",
                    iterations: h + 1,
                    direction: "reverse" === u ? "alternate" : "normal"
                };
                c && (y.pseudoElement = c);
                let v = t.animate(m, y);
                return n.Q.value && v.finished.finally(() => {
                    s.q.waapi--
                }), v
            }
        },
        30396: (t, e, i) => {
            i.d(e, {
                X: () => n
            });
            let s = t => null !== t;

            function n(t, {
                repeat: e,
                repeatType: i = "loop"
            }, r, a = 1) {
                let o = t.filter(s),
                    l = a < 0 || e && "loop" !== i && e % 2 == 1 ? 0 : o.length - 1;
                return l && void 0 !== r ? r : o[l]
            }
        },
        30537: (t, e, i) => {
            function s({
                top: t,
                left: e,
                right: i,
                bottom: n
            }) {
                return {
                    x: {
                        min: e,
                        max: i
                    },
                    y: {
                        min: t,
                        max: n
                    }
                }
            }

            function n({
                x: t,
                y: e
            }) {
                return {
                    top: e.min,
                    right: t.max,
                    bottom: e.max,
                    left: t.min
                }
            }

            function r(t, e) {
                if (!e) return t;
                let i = e({
                        x: t.left,
                        y: t.top
                    }),
                    s = e({
                        x: t.right,
                        y: t.bottom
                    });
                return {
                    top: i.y,
                    left: i.x,
                    bottom: s.y,
                    right: s.x
                }
            }
            i.d(e, {
                FY: () => s,
                bS: () => r,
                pA: () => n
            })
        },
        33172: (t, e, i) => {
            i.d(e, {
                $: () => o,
                H: () => a
            });
            var s = i(96900),
                n = i(7219),
                r = i(46652);
            let a = {
                borderRadius: { ...n.P,
                    applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                },
                borderTopLeftRadius: n.P,
                borderTopRightRadius: n.P,
                borderBottomLeftRadius: n.P,
                borderBottomRightRadius: n.P,
                boxShadow: r._
            };

            function o(t) {
                for (let e in t) a[e] = t[e], (0, s.j4)(e) && (a[e].isCSSVariable = !0)
            }
        },
        33882: (t, e, i) => {
            i.d(e, {
                i: () => r
            });
            var s = i(81220),
                n = i(64590);

            function r({
                type: t,
                ...e
            }) {
                return (0, n.W)(t) && (0, s.n)() ? t.applyToOptions(e) : (e.duration ? ? (e.duration = 300), e.ease ? ? (e.ease = "easeOut"), e)
            }
        },
        33950: (t, e, i) => {
            i.d(e, {
                po: () => r,
                tn: () => o,
                yT: () => a
            });
            var s = i(45779),
                n = i(55638);
            let r = t => 1 - Math.sin(Math.acos(t)),
                a = (0, n.G)(r),
                o = (0, s.V)(r)
        },
        33987: (t, e, i) => {
            i.d(e, {
                K: () => p
            });
            var s = i(99296),
                n = i(20381),
                r = i(63251),
                a = i(13970),
                o = i(33950),
                l = i(79765),
                h = i(37789),
                u = i(41983);
            let d = {
                    linear: n.l,
                    easeIn: h.a6,
                    easeInOut: h.am,
                    easeOut: h.vT,
                    circIn: o.po,
                    circInOut: o.tn,
                    circOut: o.yT,
                    backIn: a.dg,
                    backInOut: a.ZZ,
                    backOut: a.Sz,
                    anticipate: r.b
                },
                p = t => {
                    if ((0, u.D)(t)) {
                        (0, s.V)(4 === t.length, "Cubic bezier arrays must contain four numerical values.", "cubic-bezier-length");
                        let [e, i, n, r] = t;
                        return (0, l.A)(e, i, n, r)
                    }
                    return "string" == typeof t ? ((0, s.V)(void 0 !== d[t], `Invalid easing type '${t}'`, "invalid-easing-type"), d[t]) : t
                }
        },
        34859: (t, e, i) => {
            i.d(e, {
                X: () => s
            });

            function s(t) {
                return [t("x"), t("y")]
            }
        },
        37789: (t, e, i) => {
            i.d(e, {
                a6: () => n,
                am: () => a,
                vT: () => r
            });
            var s = i(79765);
            let n = (0, s.A)(.42, 0, 1, 1),
                r = (0, s.A)(0, 0, .58, 1),
                a = (0, s.A)(.42, 0, .58, 1)
        },
        37862: (t, e, i) => {
            i.d(e, {
                d: () => l
            });
            var s = i(49894),
                n = i(88667),
                r = i(53716);
            let a = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                o = r.U.length;

            function l(t, e, i) {
                let l = "",
                    h = !0;
                for (let u = 0; u < o; u++) {
                    let o = r.U[u],
                        d = t[o];
                    if (void 0 === d) continue;
                    let p = !0;
                    if ("number" == typeof d) p = d === +!!o.startsWith("scale");
                    else {
                        let t = parseFloat(d);
                        p = o.startsWith("scale") ? 1 === t : 0 === t
                    }
                    if (!p || i) {
                        let t = (0, s.e)(d, n.W[o]);
                        if (!p) {
                            h = !1;
                            let e = a[o] || o;
                            l += `${e}(${t}) `
                        }
                        i && (e[o] = t)
                    }
                }
                let u = t.pathRotation;
                return u && (h = !1, l += `rotate(${(0,s.e)(u,n.W.pathRotation)}) `), l = l.trim(), i ? l = i(e, h ? "" : l) : h && (l = "none"), l
            }
        },
        38264: (t, e, i) => {
            i.d(e, {
                OU: () => h,
                Ql: () => u,
                TA: () => a,
                Ww: () => c,
                hq: () => r,
                mH: () => d,
                o4: () => l,
                yK: () => o
            });
            var s = i(48592),
                n = i(19503);

            function r(t, e, i) {
                return i + e * (t - i)
            }

            function a(t, e, i, s, n) {
                return void 0 !== n && (t = s + n * (t - s)), s + i * (t - s) + e
            }

            function o(t, e = 0, i = 1, s, n) {
                t.min = a(t.min, e, i, s, n), t.max = a(t.max, e, i, s, n)
            }

            function l(t, {
                x: e,
                y: i
            }) {
                o(t.x, e.translate, e.scale, e.originPoint), o(t.y, i.translate, i.scale, i.originPoint)
            }

            function h(t, e, i, s = !1) {
                let r, a, o = i.length;
                if (o) {
                    e.x = e.y = 1;
                    for (let h = 0; h < o; h++) {
                        a = (r = i[h]).projectionDelta;
                        let {
                            visualElement: o
                        } = r.options;
                        (!o || !o.props.style || "contents" !== o.props.style.display) && (s && r.options.layoutScroll && r.scroll && r !== r.root && (u(t.x, -r.scroll.offset.x), u(t.y, -r.scroll.offset.y)), a && (e.x *= a.x.scale, e.y *= a.y.scale, l(t, a)), s && (0, n.HD)(r.latestValues) && c(t, r.latestValues, r.layout ? .layoutBox))
                    }
                    e.x < 1.0000000000001 && e.x > .999999999999 && (e.x = 1), e.y < 1.0000000000001 && e.y > .999999999999 && (e.y = 1)
                }
            }

            function u(t, e) {
                t.min += e, t.max += e
            }

            function d(t, e, i, n, r = .5) {
                let a = (0, s.k)(t.min, t.max, r);
                o(t, e, i, a, n)
            }

            function p(t, e) {
                return "string" == typeof t ? parseFloat(t) / 100 * (e.max - e.min) : t
            }

            function c(t, e, i) {
                let s = i ? ? t;
                d(t.x, p(e.x, s.x), e.scaleX, e.scale, e.originX), d(t.y, p(e.y, s.y), e.scaleY, e.scale, e.originY)
            }
        },
        40233: (t, e, i) => {
            i.d(e, {
                BX: () => R,
                lr: () => M,
                vK: () => D
            });
            var s = i(69377),
                n = i(69032),
                r = i(77306),
                a = i(11424),
                o = i(3846),
                l = i(89916),
                h = i(16492),
                u = i(27597),
                d = i(40303),
                p = i(40699),
                c = i(61624),
                m = i(3363),
                f = i(53475),
                y = i(94219),
                v = i(81425),
                g = i(56514),
                x = i(24756),
                T = i(53716),
                w = i(83122),
                S = i(22171),
                b = i(24700),
                k = i(29736),
                P = i(86993);
            let A = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"],
                V = {};

            function M(t) {
                V = t
            }

            function D() {
                return V
            }
            class R {
                scrapeMotionValuesFromProps(t, e, i) {
                    return {}
                }
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: i,
                    reducedMotionConfig: s,
                    skipAnimations: n,
                    blockInitialAnimation: r,
                    visualState: a
                }, l = {}) {
                    this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.shouldSkipAnimations = !1, this.values = new Map, this.KeyframeResolver = o.h, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.hasBeenMounted = !1, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.renderScheduledAt = 0, this.scheduleRender = () => {
                        let t = d.k.now();
                        this.renderScheduledAt < t && (this.renderScheduledAt = t, P.Gt.render(this.render, !1, !0))
                    };
                    const {
                        latestValues: h,
                        renderState: u
                    } = a;
                    this.latestValues = h, this.baseTarget = { ...h
                    }, this.initialValues = e.initial ? { ...h
                    } : {}, this.renderState = u, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = s, this.skipAnimationsConfig = n, this.options = l, this.blockInitialAnimation = !!r, this.isControllingVariants = (0, x.e)(e), this.isVariantNode = (0, x.O)(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
                    const {
                        willChange: p,
                        ...c
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (const t in c) {
                        const e = c[t];
                        void 0 !== h[t] && (0, v.S)(e) && e.set(h[t])
                    }
                }
                mount(t) {
                    if (this.hasBeenMounted)
                        for (let t in this.initialValues) this.values.get(t) ? .jump(this.initialValues[t]), this.latestValues[t] = this.initialValues[t];
                    this.current = t, g.C.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), "never" === this.reducedMotionConfig ? this.shouldReduceMotion = !1 : "always" === this.reducedMotionConfig ? this.shouldReduceMotion = !0 : (k.r.current || (0, S.Uu)(), this.shouldReduceMotion = k.O.current), this.shouldSkipAnimations = this.skipAnimationsConfig ? ? !1, this.parent ? .addChild(this), this.update(this.props, this.presenceContext), this.hasBeenMounted = !0
                }
                unmount() {
                    for (let t in this.projection && this.projection.unmount(), (0, P.WG)(this.notifyUpdate), (0, P.WG)(this.render), this.valueSubscriptions.forEach(t => t()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent ? .removeChild(this), this.events) this.events[t].clear();
                    for (let t in this.features) {
                        let e = this.features[t];
                        e && (e.unmount(), e.isMounted = !1)
                    }
                    this.current = null
                }
                addChild(t) {
                    this.children.add(t), this.enteringChildren ? ? (this.enteringChildren = new Set), this.enteringChildren.add(t)
                }
                removeChild(t) {
                    this.children.delete(t), this.enteringChildren && this.enteringChildren.delete(t)
                }
                bindToMotionValue(t, e) {
                    let i;
                    if (this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)(), e.accelerate && h.M.has(t) && this.current instanceof HTMLElement) {
                        let {
                            factory: i,
                            keyframes: n,
                            times: r,
                            ease: a,
                            duration: o
                        } = e.accelerate, h = new l.m({
                            element: this.current,
                            name: t,
                            keyframes: n,
                            times: r,
                            ease: a,
                            duration: (0, s.f)(o)
                        }), u = i(h);
                        this.valueSubscriptions.set(t, () => {
                            u(), h.cancel()
                        });
                        return
                    }
                    let n = T.f.has(t);
                    n && this.onBindTransform && this.onBindTransform();
                    let r = e.on("change", e => {
                        this.latestValues[t] = e, this.props.onUpdate && P.Gt.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0), this.scheduleRender()
                    });
                    "u" > typeof window && window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, t, e)), this.valueSubscriptions.set(t, () => {
                        r(), i && i()
                    })
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                updateFeatures() {
                    let t = "animation";
                    for (t in V) {
                        let e = V[t];
                        if (!e) continue;
                        let {
                            isEnabled: i,
                            Feature: s
                        } = e;
                        if (!this.features[t] && s && i(this.props) && (this.features[t] = new s(this)), this.features[t]) {
                            let e = this.features[t];
                            e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                        }
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : (0, p.ge)()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < A.length; e++) {
                        let i = A[e];
                        this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                        let s = t["on" + i];
                        s && (this.propEventSubscriptions[i] = this.on(i, s))
                    }
                    this.prevMotionValues = (0, w.U)(this, this.scrapeMotionValuesFromProps(t, this.prevProps || {}, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                addVariantChild(t) {
                    let e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    let i = this.values.get(t);
                    e !== i && (i && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
                }
                removeValue(t) {
                    this.values.delete(t);
                    let e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let i = this.values.get(t);
                    return void 0 === i && void 0 !== e && (i = (0, c.OQ)(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, i)), i
                }
                readValue(t, e) {
                    let i = void 0 === this.latestValues[t] && this.current ? this.getBaseTargetFromProps(this.props, t) ? ? this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    return null != i && ("string" == typeof i && ((0, n.i)(i) || (0, r.$)(i)) ? i = parseFloat(i) : !(0, y.t)(i) && m.f.test(e) && (i = (0, f.J)(t, e)), this.setBaseTarget(t, (0, v.S)(i) ? i.get() : i)), (0, v.S)(i) ? i.get() : i
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    let e, {
                        initial: i
                    } = this.props;
                    if ("string" == typeof i || "object" == typeof i) {
                        let s = (0, b.a)(this.props, i, this.presenceContext ? .custom);
                        s && (e = s[t])
                    }
                    if (i && void 0 !== e) return e;
                    let s = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === s || (0, v.S)(s) ? void 0 !== this.initialValues[t] && void 0 === e ? void 0 : this.baseTarget[t] : s
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new a.v), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
                scheduleRenderMicrotask() {
                    u.k.render(this.render)
                }
            }
        },
        40603: (t, e, i) => {
            i.d(e, {
                g: () => r
            });
            var s = i(16357),
                n = i(14746);

            function r(t, e) {
                let i = t.getValue("willChange");
                if ((0, n.k)(i)) return i.add(e);
                if (!i && s.W.WillChange) {
                    let i = new s.W.WillChange("auto");
                    t.addValue("willChange", i), i.add(e)
                }
            }
        },
        40699: (t, e, i) => {
            i.d(e, {
                _W: () => r,
                c6: () => s,
                ge: () => a,
                xU: () => n
            });
            let s = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                n = () => ({
                    x: s(),
                    y: s()
                }),
                r = () => ({
                    min: 0,
                    max: 0
                }),
                a = () => ({
                    x: r(),
                    y: r()
                })
        },
        41983: (t, e, i) => {
            i.d(e, {
                D: () => s
            });
            let s = t => Array.isArray(t) && "number" == typeof t[0]
        },
        42702: (t, e, i) => {
            i.d(e, {
                e: () => s
            });
            let s = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"])
        },
        45393: (t, e, i) => {
            i.d(e, {
                U: () => o,
                c: () => a
            });
            var s = i(40303),
                n = i(69377),
                r = i(86993);

            function a(t, e) {
                let i = s.k.now(),
                    n = ({
                        timestamp: s
                    }) => {
                        let a = s - i;
                        a >= e && ((0, r.WG)(n), t(a - e))
                    };
                return r.Gt.setup(n, !0), () => (0, r.WG)(n)
            }

            function o(t, e) {
                return a(t, (0, n.f)(e))
            }
        },
        45779: (t, e, i) => {
            i.d(e, {
                V: () => s
            });
            let s = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2
        },
        45989: (t, e, i) => {
            i.d(e, {
                n: () => c
            });
            var s = i(32796),
                n = i(40303),
                r = i(99672),
                a = i(26713),
                o = i(89916),
                l = i(8246),
                h = i(63251),
                u = i(13970),
                d = i(33950);
            let p = {
                anticipate: h.b,
                backInOut: u.ZZ,
                circInOut: d.tn
            };
            class c extends o.m {
                constructor(t) {
                    ! function(t) {
                        "string" == typeof t.ease && t.ease in p && (t.ease = p[t.ease])
                    }(t), (0, l.E)(t), super(t), void 0 !== t.startTime && !1 !== t.autoplay && (this.startTime = t.startTime), this.options = t
                }
                updateMotionValue(t) {
                    let {
                        motionValue: e,
                        onUpdate: i,
                        onComplete: o,
                        element: l,
                        ...h
                    } = this.options;
                    if (!e) return;
                    if (void 0 !== t) return void e.set(t);
                    let u = new a.s({ ...h,
                            autoplay: !1
                        }),
                        d = Math.max(10, n.k.now() - this.startTime),
                        p = (0, s.q)(0, 10, d - 10),
                        c = u.sample(d).value,
                        {
                            name: m
                        } = this.options;
                    l && m && (0, r.e)(l, m, c), e.setWithVelocity(u.sample(Math.max(0, d - p)).value, c, p), u.stop()
                }
            }
        },
        46652: (t, e, i) => {
            i.d(e, {
                _: () => r
            });
            var s = i(3363),
                n = i(48592);
            let r = {
                correct: (t, {
                    treeScale: e,
                    projectionDelta: i
                }) => {
                    let r = s.f.parse(t);
                    if (r.length > 5) return t;
                    let a = s.f.createTransformer(t),
                        o = +("number" != typeof r[0]),
                        l = i.x.scale * e.x,
                        h = i.y.scale * e.y;
                    r[0 + o] /= l, r[1 + o] /= h;
                    let u = (0, n.k)(l, h, .5);
                    return "number" == typeof r[2 + o] && (r[2 + o] /= u), "number" == typeof r[3 + o] && (r[3 + o] /= u), a(r)
                }
            }
        },
        46818: (t, e, i) => {
            i.d(e, {
                Y: () => r
            });
            var s = i(96062),
                n = i(83523);
            class r {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    (0, s.Kq)(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    (0, s.Ai)(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(n.u), this.isDirty = !1, this.children.forEach(t)
                }
            }
        },
        46858: (t, e, i) => {
            i.d(e, {
                ho: () => $,
                rq: () => W,
                u0: () => I
            });
            var s = i(11424),
                n = i(32796),
                r = i(20381),
                a = i(87261),
                o = i(78675),
                l = i(47795),
                h = i(27597),
                u = i(40303),
                d = i(33172),
                p = i(48846),
                c = i(78754),
                m = i(45393),
                f = i(18120),
                y = i(59813),
                v = i(48592),
                g = i(61624),
                x = i(25051),
                T = i(76216),
                w = i(21962),
                S = i(38264),
                b = i(4761),
                k = i(2730),
                P = i(40699),
                A = i(82322),
                V = i(82014),
                M = i(9627),
                D = i(34859),
                R = i(46818),
                C = i(19503),
                E = i(4894),
                B = i(86993);
            let j = {
                    nodes: 0,
                    calculatedTargetDeltas: 0,
                    calculatedProjections: 0
                },
                L = ["", "X", "Y", "Z"],
                F = 0;

            function O(t, e, i, s) {
                let {
                    latestValues: n
                } = e;
                n[t] && (i[t] = n[t], e.setStaticValue(t, 0), s && (s[t] = 0))
            }

            function I({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: i,
                checkIsScrollRoot: r,
                resetTransform: D
            }) {
                return class {
                    constructor(t = {}, i = e ? .()) {
                        this.id = F++, this.animationId = 0, this.animationCommitId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.layoutVersion = 0, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, c.Q.value && (j.nodes = j.calculatedTargetDeltas = j.calculatedProjections = 0), this.nodes.forEach($), this.nodes.forEach(Q), this.nodes.forEach(_), this.nodes.forEach(W), c.Q.addProjectionMetrics && c.Q.addProjectionMetrics(j)
                        }, this.resolvedRelativeTargetAt = 0, this.linkedParentVersion = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new R.Y)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new s.v), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        let i = this.eventHandlers.get(t);
                        i && i.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e) {
                        if (this.instance) return;
                        this.isSVG = (0, f.x)(e) && !(0, y.h)(e), this.instance = e;
                        let {
                            layoutId: i,
                            layout: s,
                            visualElement: n
                        } = this.options;
                        if (n && !n.current && n.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), this.root.hasTreeAnimated && (s || i) && (this.isLayoutDirty = !0), t) {
                            let i, s = 0,
                                n = () => this.root.updateBlockedByResize = !1;
                            B.Gt.read(() => {
                                s = window.innerWidth
                            }), t(e, () => {
                                let t = window.innerWidth;
                                t !== s && (s = t, this.root.updateBlockedByResize = !0, i && i(), i = (0, m.c)(n, 250), E.w.hasAnimatedSinceResize && (E.w.hasAnimatedSinceResize = !1, this.nodes.forEach(q)))
                            })
                        }
                        i && this.root.registerSharedNode(i, this), !1 !== this.options.animate && n && (i || s) && this.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeLayoutChanged: i,
                            layout: s
                        }) => {
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let r = this.options.transition || n.getDefaultTransition() || ts,
                                {
                                    onLayoutAnimationStart: a,
                                    onLayoutAnimationComplete: o
                                } = n.getProps(),
                                h = !this.targetLayout || !(0, A.mG)(this.targetLayout, s),
                                u = !e && i;
                            if (this.options.layoutRoot || this.resumeFrom || u || e && (h || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
                                let e = { ...(0, l.r)(r, "layout"),
                                    onPlay: a,
                                    onComplete: o
                                };
                                (n.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e), this.setAnimationOrigin(t, u, e.path)
                            } else e || q(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = s
                        })
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        let t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), (0, B.WG)(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(Z), this.animationId++)
                    }
                    getTransformTemplate() {
                        let {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                            this.options.onExitComplete && this.options.onExitComplete();
                            return
                        }
                        if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && function t(e) {
                                if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
                                let {
                                    visualElement: i
                                } = e.options;
                                if (!i) return;
                                let s = (0, o.P)(i);
                                if (window.MotionHasOptimisedAnimation(s, "transform")) {
                                    let {
                                        layout: t,
                                        layoutId: i
                                    } = e.options;
                                    window.MotionCancelOptimisedAnimation(s, "transform", B.Gt, !(t || i))
                                }
                                let {
                                    parent: n
                                } = e;
                                n && !n.hasCheckedOptimisedAppear && t(n)
                            }(this), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            let e = this.path[t];
                            e.shouldResetTransform = !0, ("string" == typeof e.latestValues.x || "string" == typeof e.latestValues.y) && (e.isLayoutDirty = !0), e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        let {
                            layoutId: e,
                            layout: i
                        } = this.options;
                        if (void 0 === e && !i) return;
                        let s = this.getTransformTemplate();
                        this.prevTransformTemplateValue = s ? s(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                            let t = this.updateBlockedByResize;
                            this.unblockUpdate(), this.updateBlockedByResize = !1, this.clearAllSnapshots(), t && this.nodes.forEach(H), this.nodes.forEach(K);
                            return
                        }
                        if (this.animationId <= this.animationCommitId) return void this.nodes.forEach(z);
                        this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = !1, this.nodes.forEach(Y), this.nodes.forEach(G), this.nodes.forEach(U), this.nodes.forEach(X)) : this.nodes.forEach(z), this.clearAllSnapshots();
                        let t = u.k.now();
                        B.uv.delta = (0, n.q)(0, 1e3 / 60, t - B.uv.timestamp), B.uv.timestamp = t, B.uv.isProcessing = !0, B.PP.update.process(B.uv), B.PP.preRender.process(B.uv), B.PP.render.process(B.uv), B.uv.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, h.k.read(this.scheduleUpdate))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(N), this.sharedNodes.forEach(J)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, B.Gt.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        B.Gt.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure(), !this.snapshot || (0, b.CQ)(this.snapshot.measuredBox.x) || (0, b.CQ)(this.snapshot.measuredBox.y) || (this.snapshot = void 0))
                    }
                    updateLayout() {
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                        let t = this.layout;
                        this.layout = this.measure(!1), this.layoutVersion++, this.layoutCorrected || (this.layoutCorrected = (0, P.ge)()), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        let {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = !!(this.options.layoutScroll && this.instance);
                        if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e && this.instance) {
                            let e = r(this.instance);
                            this.scroll = {
                                animationId: this.root.animationId,
                                phase: t,
                                isRoot: e,
                                offset: i(this.instance),
                                wasRoot: this.scroll ? this.scroll.isRoot : e
                            }
                        }
                    }
                    resetTransform() {
                        if (!D) return;
                        let t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                            e = this.projectionDelta && !(0, A.XY)(this.projectionDelta),
                            i = this.getTransformTemplate(),
                            s = i ? i(this.latestValues, "") : void 0,
                            n = s !== this.prevTransformTemplateValue;
                        t && this.instance && (e || (0, C.HD)(this.latestValues) || n) && (D(this.instance, s), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        var e;
                        let i = this.measurePageBox(),
                            s = this.removeElementScroll(i);
                        return t && (s = this.removeTransform(s)), ta((e = s).x), ta(e.y), {
                            animationId: this.root.animationId,
                            measuredBox: i,
                            layoutBox: s,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return (0, P.ge)();
                        let e = t.measureViewportBox();
                        if (!(this.scroll ? .wasRoot || this.path.some(tl))) {
                            let {
                                scroll: t
                            } = this.root;
                            t && ((0, S.Ql)(e.x, t.offset.x), (0, S.Ql)(e.y, t.offset.y))
                        }
                        return e
                    }
                    removeElementScroll(t) {
                        let e = (0, P.ge)();
                        if ((0, w.Hy)(e, t), this.scroll ? .wasRoot) return e;
                        for (let i = 0; i < this.path.length; i++) {
                            let s = this.path[i],
                                {
                                    scroll: n,
                                    options: r
                                } = s;
                            s !== this.root && n && r.layoutScroll && (n.wasRoot && (0, w.Hy)(e, t), (0, S.Ql)(e.x, n.offset.x), (0, S.Ql)(e.y, n.offset.y))
                        }
                        return e
                    }
                    applyTransform(t, e = !1, i) {
                        let s = i || (0, P.ge)();
                        (0, w.Hy)(s, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let i = this.path[t];
                            !e && i.options.layoutScroll && i.scroll && i !== i.root && ((0, S.Ql)(s.x, -i.scroll.offset.x), (0, S.Ql)(s.y, -i.scroll.offset.y)), (0, C.HD)(i.latestValues) && (0, S.Ww)(s, i.latestValues, i.layout ? .layoutBox)
                        }
                        return (0, C.HD)(this.latestValues) && (0, S.Ww)(s, this.latestValues, this.layout ? .layoutBox), s
                    }
                    removeTransform(t) {
                        let e = (0, P.ge)();
                        (0, w.Hy)(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let i, s = this.path[t];
                            (0, C.HD)(s.latestValues) && (s.instance && ((0, C.vk)(s.latestValues) && s.updateSnapshot(), i = (0, P.ge)(), (0, w.Hy)(i, s.measurePageBox())), (0, k.px)(e, s.latestValues, s.snapshot ? .layoutBox, i))
                        }
                        return (0, C.HD)(this.latestValues) && (0, k.px)(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== B.uv.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        let e = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = e.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = e.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = e.isSharedProjectionDirty);
                        let i = !!this.resumingFrom || this !== e;
                        if (!(t || i && this.isSharedProjectionDirty || this.isProjectionDirty || this.parent ? .isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                        let {
                            layout: s,
                            layoutId: n
                        } = this.options;
                        if (!this.layout || !(s || n)) return;
                        this.resolvedRelativeTargetAt = B.uv.timestamp;
                        let r = this.getClosestProjectingParent();
                        r && this.linkedParentVersion !== r.layoutVersion && !r.options.layoutRoot && this.removeRelativeTarget(), this.targetDelta || this.relativeTarget || (!1 !== this.options.layoutAnchor && r && r.layout ? this.createRelativeTarget(r, this.layout.layoutBox, r.layout.layoutBox) : this.removeRelativeTarget()), (this.relativeTarget || this.targetDelta) && (this.target || (this.target = (0, P.ge)(), this.targetWithTransforms = (0, P.ge)()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), (0, b.N)(this.target, this.relativeTarget, this.relativeParent.target, this.options.layoutAnchor || void 0)) : this.targetDelta ? (this.resumingFrom ? this.applyTransform(this.layout.layoutBox, !1, this.target) : (0, w.Hy)(this.target, this.layout.layoutBox), (0, S.o4)(this.target, this.targetDelta)) : (0, w.Hy)(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget && (this.attemptToResolveRelativeTarget = !1, !1 !== this.options.layoutAnchor && r && !!r.resumingFrom == !!this.resumingFrom && !r.options.layoutScroll && r.target && 1 !== this.animationProgress ? this.createRelativeTarget(r, this.target, r.target) : this.relativeParent = this.relativeTarget = void 0), c.Q.value && j.calculatedTargetDeltas++)
                    }
                    getClosestProjectingParent() {
                        if (!(!this.parent || (0, C.vk)(this.parent.latestValues) || (0, C.vF)(this.parent.latestValues)))
                            if (this.parent.isProjecting()) return this.parent;
                            else return this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    createRelativeTarget(t, e, i) {
                        this.relativeParent = t, this.linkedParentVersion = t.layoutVersion, this.forceRelativeParentToResolveTarget(), this.relativeTarget = (0, P.ge)(), this.relativeTargetOrigin = (0, P.ge)(), (0, b.jA)(this.relativeTargetOrigin, e, i, this.options.layoutAnchor || void 0), (0, w.Hy)(this.relativeTarget, this.relativeTargetOrigin)
                    }
                    removeRelativeTarget() {
                        this.relativeParent = this.relativeTarget = void 0
                    }
                    calcProjection() {
                        let t = this.getLead(),
                            e = !!this.resumingFrom || this !== t,
                            i = !0;
                        if ((this.isProjectionDirty || this.parent ? .isProjectionDirty) && (i = !1), e && (this.isSharedProjectionDirty || this.isTransformDirty) && (i = !1), this.resolvedRelativeTargetAt === B.uv.timestamp && (i = !1), i) return;
                        let {
                            layout: s,
                            layoutId: n
                        } = this.options;
                        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(s || n)) return;
                        (0, w.Hy)(this.layoutCorrected, this.layout.layoutBox);
                        let r = this.treeScale.x,
                            a = this.treeScale.y;
                        (0, S.OU)(this.layoutCorrected, this.treeScale, this.path, e), t.layout && !t.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (t.target = t.layout.layoutBox, t.targetWithTransforms = (0, P.ge)());
                        let {
                            target: o
                        } = t;
                        if (!o) {
                            this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                            return
                        }
                        this.projectionDelta && this.prevProjectionDelta ? ((0, w.xD)(this.prevProjectionDelta.x, this.projectionDelta.x), (0, w.xD)(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), (0, b.vb)(this.projectionDelta, this.layoutCorrected, o, this.latestValues), this.treeScale.x === r && this.treeScale.y === a && (0, A.t$)(this.projectionDelta.x, this.prevProjectionDelta.x) && (0, A.t$)(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", o)), c.Q.value && j.calculatedProjections++
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        if (this.options.visualElement ? .scheduleRender(), t) {
                            let t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    createProjectionDeltas() {
                        this.prevProjectionDelta = (0, P.xU)(), this.projectionDelta = (0, P.xU)(), this.projectionDeltaWithTransform = (0, P.xU)()
                    }
                    setAnimationOrigin(t, e = !1, i) {
                        let s, n = this.snapshot,
                            r = n ? n.latestValues : {},
                            a = { ...this.latestValues
                            },
                            o = (0, P.xU)();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        let l = (0, P.ge)(),
                            h = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            u = this.getStack(),
                            d = !u || u.members.length <= 1,
                            p = !!(h && !d && !0 === this.options.crossfade && !this.path.some(ti));
                        this.animationProgress = 0;
                        let c = i ? .interpolateProjection(t);
                        this.mixTargetDelta = e => {
                            var i, n, u, m;
                            let f = e / 1e3,
                                y = c ? .(f);
                            y ? (o.x.translate = y.x, o.x.scale = (0, v.k)(t.x.scale, 1, f), o.x.origin = t.x.origin, o.x.originPoint = t.x.originPoint, o.y.translate = y.y, o.y.scale = (0, v.k)(t.y.scale, 1, f), o.y.origin = t.y.origin, o.y.originPoint = t.y.originPoint) : (tt(o.x, t.x, f), tt(o.y, t.y, f)), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && ((0, b.jA)(l, this.layout.layoutBox, this.relativeParent.layout.layoutBox, this.options.layoutAnchor || void 0), i = this.relativeTarget, n = this.relativeTargetOrigin, u = l, m = f, te(i.x, n.x, u.x, m), te(i.y, n.y, u.y, m), s && (0, A.zo)(this.relativeTarget, s) && (this.isProjectionDirty = !1), s || (s = (0, P.ge)()), (0, w.Hy)(s, this.relativeTarget)), h && (this.animationValues = a, (0, T.v)(a, r, this.latestValues, f, p, d)), y && void 0 !== y.rotate && (this.animationValues || (this.animationValues = a), this.animationValues.pathRotation = y.rotate), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = f
                        }, this.mixTargetDelta(1e3 * !!this.options.layoutRoot)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation ? .stop(), this.resumingFrom ? .currentAnimation ? .stop(), this.pendingAnimation && ((0, B.WG)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = B.Gt.update(() => {
                            E.w.hasAnimatedSinceResize = !0, p.q.layout++, this.motionValue || (this.motionValue = (0, g.OQ)(0)), this.motionValue.jump(0, !1), this.currentAnimation = (0, a.z)(this.motionValue, [0, 1e3], { ...t,
                                velocity: 0,
                                isSync: !0,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onStop: () => {
                                    p.q.layout--
                                },
                                onComplete: () => {
                                    p.q.layout--, t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        let t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let t = this.getLead(),
                            {
                                targetWithTransforms: e,
                                target: i,
                                layout: s,
                                latestValues: n
                            } = t;
                        if (e && i && s) {
                            if (this !== t && this.layout && s && to(this.options.animationType, this.layout.layoutBox, s.layoutBox)) {
                                i = this.target || (0, P.ge)();
                                let e = (0, b.CQ)(this.layout.layoutBox.x);
                                i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                                let s = (0, b.CQ)(this.layout.layoutBox.y);
                                i.y.min = t.target.y.min, i.y.max = i.y.min + s
                            }(0, w.Hy)(e, i), (0, S.Ww)(e, n), (0, b.vb)(this.projectionDeltaWithTransform, this.layoutCorrected, e, n)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new V.P), this.sharedNodes.get(t).add(e);
                        let i = e.options.initialPromotionConfig;
                        e.promote({
                            transition: i ? i.transition : void 0,
                            preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        let t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        let {
                            layoutId: t
                        } = this.options;
                        return t && this.getStack() ? .lead || this
                    }
                    getPrevLead() {
                        let {
                            layoutId: t
                        } = this.options;
                        return t ? this.getStack() ? .prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: i
                    } = {}) {
                        let s = this.getStack();
                        s && s.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        let t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1,
                            {
                                latestValues: i
                            } = t;
                        if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                        let s = {};
                        i.z && O("z", t, s, this.animationValues);
                        for (let e = 0; e < L.length; e++) O(`rotate${L[e]}`, t, s, this.animationValues), O(`skew${L[e]}`, t, s, this.animationValues);
                        for (let e in t.render(), s) t.setStaticValue(e, s[e]), this.animationValues && (this.animationValues[e] = s[e]);
                        t.scheduleRender()
                    }
                    applyProjectionStyles(t, e) {
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) {
                            t.visibility = "hidden";
                            return
                        }
                        let i = this.getTransformTemplate();
                        if (this.needsReset) {
                            this.needsReset = !1, t.visibility = "", t.opacity = "", t.pointerEvents = (0, x.u)(e ? .pointerEvents) || "", t.transform = i ? i(this.latestValues, "") : "none";
                            return
                        }
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            this.options.layoutId && (t.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, t.pointerEvents = (0, x.u)(e ? .pointerEvents) || ""), this.hasProjected && !(0, C.HD)(this.latestValues) && (t.transform = i ? i({}, "") : "none", this.hasProjected = !1);
                            return
                        }
                        t.visibility = "";
                        let n = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget();
                        let r = (0, M.I)(this.projectionDeltaWithTransform, this.treeScale, n);
                        i && (r = i(n, r)), t.transform = r;
                        let {
                            x: a,
                            y: o
                        } = this.projectionDelta;
                        for (let e in t.transformOrigin = `${100*a.origin}% ${100*o.origin}% 0`, s.animationValues ? t.opacity = s === this ? n.opacity ? ? this.latestValues.opacity ? ? 1 : this.preserveOpacity ? this.latestValues.opacity : n.opacityExit : t.opacity = s === this ? void 0 !== n.opacity ? n.opacity : "" : void 0 !== n.opacityExit ? n.opacityExit : 0, d.H) {
                            if (void 0 === n[e]) continue;
                            let {
                                correct: i,
                                applyTo: a,
                                isCSSVariable: o
                            } = d.H[e], l = "none" === r ? n[e] : i(n[e], s);
                            if (a) {
                                let e = a.length;
                                for (let i = 0; i < e; i++) t[a[i]] = l
                            } else o ? this.options.visualElement.renderState.vars[e] = l : t[e] = l
                        }
                        this.options.layoutId && (t.pointerEvents = s === this ? (0, x.u)(e ? .pointerEvents) || "" : "none")
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(t => t.currentAnimation ? .stop()), this.root.nodes.forEach(K), this.root.sharedNodes.clear()
                    }
                }
            }

            function U(t) {
                t.updateLayout()
            }

            function X(t) {
                let e = t.resumeFrom ? .snapshot || t.snapshot;
                if (t.isLead() && t.layout && e && t.hasListeners("didUpdate")) {
                    let {
                        layoutBox: i,
                        measuredBox: s
                    } = t.layout, {
                        animationType: n
                    } = t.options, r = e.source !== t.layout.source;
                    if ("size" === n)(0, D.X)(t => {
                        let s = r ? e.measuredBox[t] : e.layoutBox[t],
                            n = (0, b.CQ)(s);
                        s.min = i[t].min, s.max = s.min + n
                    });
                    else if ("x" === n || "y" === n) {
                        let t = "x" === n ? "y" : "x";
                        (0, w.be)(r ? e.measuredBox[t] : e.layoutBox[t], i[t])
                    } else to(n, e.layoutBox, i) && (0, D.X)(s => {
                        let n = r ? e.measuredBox[s] : e.layoutBox[s],
                            a = (0, b.CQ)(i[s]);
                        n.max = n.min + a, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[s].max = t.relativeTarget[s].min + a)
                    });
                    let a = (0, P.xU)();
                    (0, b.vb)(a, i, e.layoutBox);
                    let o = (0, P.xU)();
                    r ? (0, b.vb)(o, t.applyTransform(s, !0), e.measuredBox) : (0, b.vb)(o, i, e.layoutBox);
                    let l = !(0, A.XY)(a),
                        h = !1;
                    if (!t.resumeFrom) {
                        let s = t.getClosestProjectingParent();
                        if (s && !s.resumeFrom) {
                            let {
                                snapshot: n,
                                layout: r
                            } = s;
                            if (n && r) {
                                let a = t.options.layoutAnchor || void 0,
                                    o = (0, P.ge)();
                                (0, b.jA)(o, e.layoutBox, n.layoutBox, a);
                                let l = (0, P.ge)();
                                (0, b.jA)(l, i, r.layoutBox, a), (0, A.mG)(o, l) || (h = !0), s.options.layoutRoot && (t.relativeTarget = l, t.relativeTargetOrigin = o, t.relativeParent = s)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: i,
                        snapshot: e,
                        delta: o,
                        layoutDelta: a,
                        hasLayoutChanged: l,
                        hasRelativeLayoutChanged: h
                    })
                } else if (t.isLead()) {
                    let {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function $(t) {
                c.Q.value && j.nodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function W(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function N(t) {
                t.clearSnapshot()
            }

            function K(t) {
                t.clearMeasurements()
            }

            function H(t) {
                t.isLayoutDirty = !0, t.updateLayout()
            }

            function z(t) {
                t.isLayoutDirty = !1
            }

            function Y(t) {
                t.isAnimationBlocked && t.layout && !t.isLayoutDirty && (t.snapshot = t.layout, t.isLayoutDirty = !0)
            }

            function G(t) {
                let {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function q(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function Q(t) {
                t.resolveTargetDelta()
            }

            function _(t) {
                t.calcProjection()
            }

            function Z(t) {
                t.resetSkewAndRotation()
            }

            function J(t) {
                t.removeLeadSnapshot()
            }

            function tt(t, e, i) {
                t.translate = (0, v.k)(e.translate, 0, i), t.scale = (0, v.k)(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function te(t, e, i, s) {
                t.min = (0, v.k)(e.min, i.min, s), t.max = (0, v.k)(e.max, i.max, s)
            }

            function ti(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            let ts = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                tn = t => "u" > typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                tr = tn("applewebkit/") && !tn("chrome/") ? Math.round : r.l;

            function ta(t) {
                t.min = tr(t.min), t.max = tr(t.max)
            }

            function to(t, e, i) {
                return "position" === t || "preserve-aspect" === t && !(0, b.HQ)((0, A.cH)(e), (0, A.cH)(i), .2)
            }

            function tl(t) {
                return t !== t.root && t.scroll ? .wasRoot
            }
        },
        47114: (t, e, i) => {
            i.d(e, {
                M: () => d
            });
            var s = i(96900),
                n = i(53716),
                r = i(95214),
                a = i(89172),
                o = i(60062),
                l = i(15002),
                h = i(373),
                u = i(74423);
            class d extends o.b {
                constructor() {
                    super(...arguments), this.type = "html", this.renderInstance = h.e
                }
                readValueFromInstance(t, e) {
                    if (n.f.has(e)) return this.projection ? .isProjecting ? (0, r.zs)(e) : (0, r.Ib)(t, e); {
                        let i = window.getComputedStyle(t),
                            n = ((0, s.j4)(e) ? i.getPropertyValue(e) : i[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return (0, a.m)(t, e)
                }
                build(t, e, i) {
                    (0, l.O)(t, e, i.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return (0, u.x)(t, e, i)
                }
            }
        },
        47795: (t, e, i) => {
            i.d(e, {
                r: () => n
            });
            var s = i(81999);

            function n(t, e) {
                let i = t ? .[e] ? ? t ? .default ? ? t;
                return i !== t ? (0, s.K)(i, t) : i
            }
        },
        48336: (t, e, i) => {
            i.d(e, {
                v: () => s
            });
            let s = t => t.startsWith("--")
        },
        48350: (t, e, i) => {
            i.d(e, {
                d: () => a
            });
            var s = i(49399),
                n = i(373),
                r = i(42702);

            function a(t, e, i, a) {
                for (let i in (0, n.e)(t, e, void 0, a), e.attrs) t.setAttribute(r.e.has(i) ? i : (0, s.I)(i), e.attrs[i])
            }
        },
        48846: (t, e, i) => {
            i.d(e, {
                q: () => s
            });
            let s = {
                layout: 0,
                mainThread: 0,
                waapi: 0
            }
        },
        49399: (t, e, i) => {
            i.d(e, {
                I: () => s
            });

            function s(t) {
                return t.replace(/([A-Z])/g, t => `-${t.toLowerCase()}`)
            }
        },
        49894: (t, e, i) => {
            i.d(e, {
                e: () => s
            });
            let s = (t, e) => e && "number" == typeof t ? e.transform(t) : t
        },
        50536: (t, e, i) => {
            i.d(e, {
                c: () => m
            });
            var s = i(85545),
                n = i(20719),
                r = i(4179),
                a = i(70518),
                o = i(84180),
                l = i(84050);
            let h = new WeakSet;

            function u(t) {
                return e => {
                    "Enter" === e.key && t(e)
                }
            }

            function d(t, e) {
                t.dispatchEvent(new PointerEvent("pointer" + e, {
                    isPrimary: !0,
                    bubbles: !0
                }))
            }

            function p(t) {
                return (0, a.M)(t) && !(0, n.D)()
            }
            let c = new WeakSet;

            function m(t, e, i = {}) {
                let [n, a, f] = (0, o.V)(t, i), y = t => {
                    let s = t.currentTarget;
                    if (!p(t) || c.has(t)) return;
                    h.add(s), i.stopPropagation && c.add(t);
                    let n = e(s, t),
                        o = (t, e) => {
                            window.removeEventListener("pointerup", l), window.removeEventListener("pointercancel", u), h.has(s) && h.delete(s), p(t) && "function" == typeof n && n(t, {
                                success: e
                            })
                        },
                        l = t => {
                            o(t, s === window || s === document || i.useGlobalTarget || (0, r.w)(s, t.target))
                        },
                        u = t => {
                            o(t, !1)
                        };
                    window.addEventListener("pointerup", l, a), window.addEventListener("pointercancel", u, a)
                };
                return n.forEach(t => {
                    (i.useGlobalTarget ? window : t).addEventListener("pointerdown", y, a), (0, s.s)(t) && (t.addEventListener("focus", t => ((t, e) => {
                        let i = t.currentTarget;
                        if (!i) return;
                        let s = u(() => {
                            if (h.has(i)) return;
                            d(i, "down");
                            let t = u(() => {
                                d(i, "up")
                            });
                            i.addEventListener("keyup", t, e), i.addEventListener("blur", () => d(i, "cancel"), e)
                        });
                        i.addEventListener("keydown", s, e), i.addEventListener("blur", () => i.removeEventListener("keydown", s), e)
                    })(t, a)), (0, l.c)(t) || t.hasAttribute("tabindex") || (t.tabIndex = 0))
                }), f
            }
        },
        52130: (t, e, i) => {
            i.d(e, {
                e: () => n
            });
            var s = i(8280);
            let n = {
                linear: "linear",
                ease: "ease",
                easeIn: "ease-in",
                easeOut: "ease-out",
                easeInOut: "ease-in-out",
                circIn: (0, s.d)([0, .65, .55, 1]),
                circOut: (0, s.d)([.55, 0, 1, .45]),
                backIn: (0, s.d)([.31, .01, .66, -.59]),
                backOut: (0, s.d)([.33, 1.53, .69, .99])
            }
        },
        53475: (t, e, i) => {
            i.d(e, {
                J: () => l
            });
            var s = i(3363),
                n = i(87957),
                r = i(56315),
                a = i(1332);
            let o = new Set([n.p, r.d]);

            function l(t, e) {
                let i = (0, a.D)(t);
                return o.has(i) || (i = s.f), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
            }
        },
        53716: (t, e, i) => {
            i.d(e, {
                U: () => s,
                f: () => n
            });
            let s = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                n = new Set([...s, "pathRotation"])
        },
        54655: (t, e, i) => {
            i.d(e, {
                K: () => s
            });
            let s = (t, e, i = 10) => {
                let s = "",
                    n = Math.max(Math.round(e / i), 2);
                for (let e = 0; e < n; e++) s += Math.round(1e4 * t(e / (n - 1))) / 1e4 + ", ";
                return `linear(${s.substring(0,s.length-2)})`
            }
        },
        55469: (t, e, i) => {
            i.d(e, {
                W: () => n
            });
            var s = i(20719);

            function n(t) {
                if ("x" === t || "y" === t)
                    if (s.I[t]) return null;
                    else return s.I[t] = !0, () => {
                        s.I[t] = !1
                    };
                return s.I.x || s.I.y ? null : (s.I.x = s.I.y = !0, () => {
                    s.I.x = s.I.y = !1
                })
            }
        },
        55638: (t, e, i) => {
            i.d(e, {
                G: () => s
            });
            let s = t => e => 1 - t(1 - e)
        },
        56315: (t, e, i) => {
            i.d(e, {
                d: () => n
            });
            var s = i(3363);
            let n = { ...s.f,
                getAnimatableNone: t => {
                    let e = s.f.parse(t);
                    return s.f.createTransformer(t)(e.map(t => "number" == typeof t ? 0 : "object" == typeof t ? { ...t,
                        alpha: 1
                    } : t))
                }
            }
        },
        56514: (t, e, i) => {
            i.d(e, {
                C: () => s
            });
            let s = new WeakMap
        },
        56963: (t, e, i) => {
            i.d(e, {
                o: () => v
            });
            var s = i(99296),
                n = i(69377),
                r = i(32796),
                a = i(54655),
                o = i(79560),
                l = i(1466);
            let h = .01,
                u = 2,
                d = .005,
                p = .5;

            function c(t, e) {
                return t * Math.sqrt(1 - e * e)
            }
            let m = ["duration", "bounce"],
                f = ["stiffness", "damping", "mass"];

            function y(t, e) {
                return e.some(e => void 0 !== t[e])
            }

            function v(t = .3, e = .3) {
                let i, l, g, x, T, w, S = "object" != typeof t ? {
                        visualDuration: t,
                        keyframes: [0, 1],
                        bounce: e
                    } : t,
                    {
                        restSpeed: b,
                        restDelta: k
                    } = S,
                    P = S.keyframes[0],
                    A = S.keyframes[S.keyframes.length - 1],
                    V = {
                        done: !1,
                        value: P
                    },
                    {
                        stiffness: M,
                        damping: D,
                        mass: R,
                        duration: C,
                        velocity: E,
                        isResolvedFromDuration: B
                    } = function(t) {
                        let e = {
                            velocity: 0,
                            stiffness: 100,
                            damping: 10,
                            mass: 1,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!y(t, f) && y(t, m))
                            if (e.velocity = 0, t.visualDuration) {
                                let i = 2 * Math.PI / (1.2 * t.visualDuration),
                                    s = i * i,
                                    n = 2 * (0, r.q)(.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(s);
                                e = { ...e,
                                    mass: 1,
                                    stiffness: s,
                                    damping: n
                                }
                            } else {
                                let i = function({
                                    duration: t = 800,
                                    bounce: e = .3,
                                    velocity: i = 0,
                                    mass: a = 1
                                }) {
                                    let o, l;
                                    (0, s.$)(t <= (0, n.f)(10), "Spring duration must be 10 seconds or less", "spring-duration-limit");
                                    let h = 1 - e;
                                    h = (0, r.q)(.05, 1, h), t = (0, r.q)(.01, 10, (0, n.X)(t)), h < 1 ? (o = e => {
                                        let s = e * h,
                                            n = s * t;
                                        return .001 - (s - i) / c(e, h) * Math.exp(-n)
                                    }, l = e => {
                                        let s = e * h * t,
                                            n = Math.pow(h, 2) * Math.pow(e, 2) * t,
                                            r = Math.exp(-s),
                                            a = c(Math.pow(e, 2), h);
                                        return (s * i + i - n) * r * (-o(e) + .001 > 0 ? -1 : 1) / a
                                    }) : (o = e => -.001 + Math.exp(-e * t) * ((e - i) * t + 1), l = e => t * t * (i - e) * Math.exp(-e * t));
                                    let u = function(t, e, i) {
                                        let s = i;
                                        for (let i = 1; i < 12; i++) s -= t(s) / e(s);
                                        return s
                                    }(o, l, 5 / t);
                                    if (t = (0, n.f)(t), isNaN(u)) return {
                                        stiffness: 100,
                                        damping: 10,
                                        duration: t
                                    }; {
                                        let e = Math.pow(u, 2) * a;
                                        return {
                                            stiffness: e,
                                            damping: 2 * h * Math.sqrt(a * e),
                                            duration: t
                                        }
                                    }
                                }({ ...t,
                                    velocity: 0
                                });
                                (e = { ...e,
                                    ...i,
                                    mass: 1
                                }).isResolvedFromDuration = !0
                            }
                        return e
                    }({ ...S,
                        velocity: -(0, n.X)(S.velocity || 0)
                    }),
                    j = E || 0,
                    L = D / (2 * Math.sqrt(M * R)),
                    F = A - P,
                    O = (0, n.X)(Math.sqrt(M / R)),
                    I = 5 > Math.abs(F);
                if (b || (b = I ? h : u), k || (k = I ? d : p), L < 1) g = c(O, L), x = (j + L * O * F) / g, i = t => A - Math.exp(-L * O * t) * (x * Math.sin(g * t) + F * Math.cos(g * t)), T = L * O * x + F * g, w = L * O * F - x * g, l = t => Math.exp(-L * O * t) * (T * Math.sin(g * t) + w * Math.cos(g * t));
                else if (1 === L) {
                    i = t => A - Math.exp(-O * t) * (F + (j + O * F) * t);
                    let t = j + O * F;
                    l = e => Math.exp(-O * e) * (O * t * e - j)
                } else {
                    let t = O * Math.sqrt(L * L - 1);
                    i = e => {
                        let i = Math.exp(-L * O * e),
                            s = Math.min(t * e, 300);
                        return A - i * ((j + L * O * F) * Math.sinh(s) + t * F * Math.cosh(s)) / t
                    };
                    let e = (j + L * O * F) / t,
                        s = L * O * e - F * t,
                        n = L * O * F - e * t;
                    l = e => {
                        let i = Math.exp(-L * O * e),
                            r = Math.min(t * e, 300);
                        return i * (s * Math.sinh(r) + n * Math.cosh(r))
                    }
                }
                let U = {
                    calculatedDuration: B && C || null,
                    velocity: t => (0, n.f)(l(t)),
                    next: t => {
                        if (!B && L < 1) {
                            let e = Math.exp(-L * O * t),
                                i = Math.sin(g * t),
                                s = Math.cos(g * t),
                                r = A - e * (x * i + F * s);
                            return V.done = Math.abs((0, n.f)(e * (T * i + w * s))) <= b && Math.abs(A - r) <= k, V.value = V.done ? A : r, V
                        }
                        let e = i(t);
                        return B ? V.done = t >= C : V.done = Math.abs((0, n.f)(l(t))) <= b && Math.abs(A - e) <= k, V.value = V.done ? A : e, V
                    },
                    toString: () => {
                        let t = Math.min((0, o.t)(U), o.Y),
                            e = (0, a.K)(e => U.next(t * e).value, t, 30);
                        return t + "ms " + e
                    },
                    toTransition: () => {}
                };
                return U
            }
            v.applyToOptions = t => {
                let e = (0, l.X)(t, 100, v);
                return t.ease = e.ease, t.duration = (0, n.f)(e.duration), t.type = "keyframes", t
            }
        },
        57243: (t, e, i) => {
            i.d(e, {
                N: () => s
            });

            function s(t) {
                return null !== t && "object" == typeof t && "function" == typeof t.start
            }
        },
        58647: (t, e, i) => {
            i.d(e, {
                P: () => r
            });
            var s = i(20719),
                n = i(84180);

            function r(t, e, i = {}) {
                let [a, o, l] = (0, n.V)(t, i);
                return a.forEach(t => {
                    let i, n = !1,
                        r = !1,
                        a = e => {
                            i && (i(e), i = void 0), t.removeEventListener("pointerleave", h)
                        },
                        l = t => {
                            n = !1, window.removeEventListener("pointerup", l), window.removeEventListener("pointercancel", l), r && (r = !1, a(t))
                        },
                        h = t => {
                            if ("touch" !== t.pointerType) {
                                if (n) {
                                    r = !0;
                                    return
                                }
                                a(t)
                            }
                        };
                    t.addEventListener("pointerenter", n => {
                        if ("touch" === n.pointerType || (0, s.D)()) return;
                        r = !1;
                        let a = e(t, n);
                        "function" == typeof a && (i = a, t.addEventListener("pointerleave", h, o))
                    }, o), t.addEventListener("pointerdown", () => {
                        n = !0, window.addEventListener("pointerup", l, o), window.addEventListener("pointercancel", l, o)
                    }, o)
                }), l
            }
        },
        59029: (t, e, i) => {
            i.d(e, {
                l: () => function t(e, i, a = {}) {
                    let o = (0, s.K)(e, i, "exit" === a.type ? e.presenceContext ? .custom : void 0),
                        {
                            transition: l = e.getDefaultTransition() || {}
                        } = o || {};
                    a.transitionOverride && (l = a.transitionOverride);
                    let h = o ? () => Promise.all((0, r.$)(e, o, a)) : () => Promise.resolve(),
                        u = e.variantChildren && e.variantChildren.size ? (s = 0) => {
                            let {
                                delayChildren: r = 0,
                                staggerChildren: o,
                                staggerDirection: h
                            } = l;
                            return function(e, i, s = 0, r = 0, a = 0, o = 1, l) {
                                let h = [];
                                for (let u of e.variantChildren) u.notify("AnimationStart", i), h.push(t(u, i, { ...l,
                                    delay: s + ("function" == typeof r ? 0 : r) + (0, n.L)(e.variantChildren, u, r, a, o)
                                }).then(() => u.notify("AnimationComplete", i)));
                                return Promise.all(h)
                            }(e, i, s, r, o, h, a)
                        } : () => Promise.resolve(),
                        {
                            when: d
                        } = l;
                    if (!d) return Promise.all([h(), u(a.delay)]); {
                        let [t, e] = "beforeChildren" === d ? [h, u] : [u, h];
                        return t().then(() => e())
                    }
                }
            });
            var s = i(60600),
                n = i(77819),
                r = i(59215)
        },
        59215: (t, e, i) => {
            i.d(e, {
                $: () => d
            });
            var s = i(47795),
                n = i(81999),
                r = i(23395),
                a = i(8915),
                o = i(40603),
                l = i(78675),
                h = i(59316),
                u = i(86993);

            function d(t, e, {
                delay: i = 0,
                transitionOverride: p,
                type: c
            } = {}) {
                let {
                    transition: m,
                    transitionEnd: f,
                    ...y
                } = e, v = t.getDefaultTransition();
                m = m ? (0, n.K)(m, v) : v;
                let g = m ? .reduceMotion,
                    x = m ? .skipAnimations;
                p && (m = p);
                let T = [],
                    w = c && t.animationState && t.animationState.getState()[c],
                    S = m ? .path;
                for (let e in S && S.animateVisualElement(t, y, m, i, T), y) {
                    let n = t.getValue(e, t.latestValues[e] ? ? null),
                        a = y[e];
                    if (void 0 === a || w && function({
                            protectedKeys: t,
                            needsAnimating: e
                        }, i) {
                            let s = t.hasOwnProperty(i) && !0 !== e[i];
                            return e[i] = !1, s
                        }(w, e)) continue;
                    let d = {
                        delay: i,
                        ...(0, s.r)(m || {}, e)
                    };
                    x && (d.skipAnimations = !0);
                    let p = n.get();
                    if (void 0 !== p && !n.isAnimating() && !Array.isArray(a) && a === p && !d.velocity) {
                        u.Gt.update(() => n.set(a));
                        continue
                    }
                    let c = !1;
                    if (window.MotionHandoffAnimation) {
                        let i = (0, l.P)(t);
                        if (i) {
                            let t = window.MotionHandoffAnimation(i, e, u.Gt);
                            null !== t && (d.startTime = t, c = !0)
                        }
                    }(0, o.g)(t, e);
                    let f = g ? ? t.shouldReduceMotion;
                    n.start((0, h.f)(e, n, a, f && r.$.has(e) ? {
                        type: !1
                    } : d, t, c));
                    let v = n.animation;
                    v && T.push(v)
                }
                if (f) {
                    let e = () => u.Gt.update(() => {
                        f && (0, a.U)(t, f)
                    });
                    T.length ? Promise.all(T).then(e) : e()
                }
                return T
            }
        },
        59316: (t, e, i) => {
            i.d(e, {
                f: () => c
            });
            var s = i(69377),
                n = i(16357),
                r = i(6998),
                a = i(26713),
                o = i(47795),
                l = i(61144),
                h = i(76155),
                u = i(30396),
                d = i(60635),
                p = i(86993);
            let c = (t, e, i, c = {}, m, f) => y => {
                let v = (0, o.r)(c, t) || {},
                    g = v.delay || c.delay || 0,
                    {
                        elapsed: x = 0
                    } = c;
                x -= (0, s.f)(g);
                let T = {
                    keyframes: Array.isArray(i) ? i : [null, i],
                    ease: "easeOut",
                    velocity: e.getVelocity(),
                    ...v,
                    delay: -x,
                    onUpdate: t => {
                        e.set(t), v.onUpdate && v.onUpdate(t)
                    },
                    onComplete: () => {
                        y(), v.onComplete && v.onComplete()
                    },
                    name: t,
                    motionValue: e,
                    element: f ? void 0 : m
                };
                (0, d.D)(v) || Object.assign(T, (0, h.x)(t, T)), T.duration && (T.duration = (0, s.f)(T.duration)), T.repeatDelay && (T.repeatDelay = (0, s.f)(T.repeatDelay)), void 0 !== T.from && (T.keyframes[0] = T.from);
                let w = !1;
                if (!1 !== T.type && (0 !== T.duration || T.repeatDelay) || ((0, l._)(T), 0 === T.delay && (w = !0)), (n.W.instantAnimations || n.W.skipAnimations || m ? .shouldSkipAnimations || v.skipAnimations) && (w = !0, (0, l._)(T), T.delay = 0), T.allowFlatten = !v.type && !v.ease, w && !f && void 0 !== e.get()) {
                    let t = (0, u.X)(T.keyframes, v);
                    if (void 0 !== t) return void p.Gt.update(() => {
                        T.onUpdate(t), T.onComplete()
                    })
                }
                return v.isSync ? new a.s(T) : new r.A(T)
            }
        },
        59813: (t, e, i) => {
            i.d(e, {
                h: () => n
            });
            var s = i(18120);

            function n(t) {
                return (0, s.x)(t) && "svg" === t.tagName
            }
        },
        60062: (t, e, i) => {
            i.d(e, {
                b: () => a
            });
            var s = i(81425),
                n = i(4354),
                r = i(40233);
            class a extends r.BX {
                constructor() {
                    super(...arguments), this.KeyframeResolver = n.K
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    let i = t.style;
                    return i ? i[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: i
                }) {
                    delete e[t], delete i[t]
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    let {
                        children: t
                    } = this.props;
                    (0, s.S)(t) && (this.childSubscription = t.on("change", t => {
                        this.current && (this.current.textContent = `${t}`)
                    }))
                }
            }
        },
        60600: (t, e, i) => {
            i.d(e, {
                K: () => n
            });
            var s = i(24700);

            function n(t, e, i) {
                let n = t.getProps();
                return (0, s.a)(n, e, void 0 !== i ? i : n.custom, t)
            }
        },
        60635: (t, e, i) => {
            i.d(e, {
                D: () => n
            });
            let s = new Set(["when", "delay", "delayChildren", "staggerChildren", "staggerDirection", "repeat", "repeatType", "repeatDelay", "from", "elapsed"]);

            function n(t) {
                for (let e in t)
                    if (!s.has(e)) return !0;
                return !1
            }
        },
        60806: (t, e, i) => {
            i.d(e, {
                l: () => c
            });
            var s = i(53716),
                n = i(1332),
                r = i(40699),
                a = i(60062),
                o = i(49399),
                l = i(18647),
                h = i(42702),
                u = i(23680),
                d = i(48350),
                p = i(16960);
            class c extends a.b {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = r.ge
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (s.f.has(e)) {
                        let t = (0, n.D)(e);
                        return t && t.default || 0
                    }
                    return e = h.e.has(e) ? e : (0, o.I)(e), t.getAttribute(e)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return (0, p.x)(t, e, i)
                }
                build(t, e, i) {
                    (0, l.B)(t, e, this.isSVGTag, i.transformTemplate, i.style)
                }
                renderInstance(t, e, i, s) {
                    (0, d.d)(t, e, i, s)
                }
                mount(t) {
                    this.isSVGTag = (0, u.n)(t.tagName), super.mount(t)
                }
            }
        },
        61144: (t, e, i) => {
            i.d(e, {
                _: () => s
            });

            function s(t) {
                t.duration = 0, t.type = "keyframes"
            }
        },
        62505: (t, e, i) => {
            i.d(e, {
                B: () => n
            });
            var s = i(16623);
            let n = (0, i(46858).u0)({
                attachResizeListener: (t, e) => (0, s.k)(t, "resize", e),
                measureScroll: () => ({
                    x: document.documentElement.scrollLeft || document.body ? .scrollLeft || 0,
                    y: document.documentElement.scrollTop || document.body ? .scrollTop || 0
                }),
                checkIsScrollRoot: () => !0
            })
        },
        63251: (t, e, i) => {
            i.d(e, {
                b: () => n
            });
            var s = i(13970);
            let n = t => t >= 1 ? 1 : (t *= 2) < 1 ? .5 * (0, s.dg)(t) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
        },
        64059: (t, e, i) => {
            i.d(e, {
                A: () => s
            });

            function s(t, e) {
                return t.map(t => t * e)
            }
        },
        64590: (t, e, i) => {
            i.d(e, {
                W: () => s
            });

            function s(t) {
                return "function" == typeof t && "applyToOptions" in t
            }
        },
        69032: (t, e, i) => {
            i.d(e, {
                i: () => s
            });
            let s = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t)
        },
        69377: (t, e, i) => {
            i.d(e, {
                X: () => n,
                f: () => s
            });
            let s = t => 1e3 * t,
                n = t => t / 1e3
        },
        70518: (t, e, i) => {
            i.d(e, {
                M: () => s
            });
            let s = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary
        },
        71405: (t, e, i) => {
            i.d(e, {
                T: () => a,
                n: () => o
            });
            var s = i(87113),
                n = i(43868),
                r = i(956);
            let a = [s.ai, n.px, n.KN, n.uj, n.vw, n.vh, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                o = t => a.find((0, r.w)(t))
        },
        74423: (t, e, i) => {
            i.d(e, {
                x: () => r
            });
            var s = i(81425),
                n = i(12166);

            function r(t, e, i) {
                let r = t.style,
                    a = e ? .style,
                    o = {};
                if (!r) return o;
                for (let e in r)((0, s.S)(r[e]) || a && (0, s.S)(a[e]) || (0, n.zK)(e, t) || i ? .getValue(e) ? .liveStyle !== void 0) && (o[e] = r[e]);
                return o
            }
        },
        76155: (t, e, i) => {
            i.d(e, {
                x: () => o
            });
            var s = i(53716);
            let n = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                r = {
                    type: "keyframes",
                    duration: .8
                },
                a = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                o = (t, {
                    keyframes: e
                }) => e.length > 2 ? r : s.f.has(t) ? t.startsWith("scale") ? {
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === e[1] ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                } : n : a
        },
        76216: (t, e, i) => {
            i.d(e, {
                v: () => p
            });
            var s = i(48592),
                n = i(43868),
                r = i(33950),
                a = i(20381),
                o = i(7e4);
            let l = ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"],
                h = l.length,
                u = t => "string" == typeof t ? parseFloat(t) : t,
                d = t => "number" == typeof t || n.px.test(t);

            function p(t, e, i, r, a, o) {
                a ? (t.opacity = (0, s.k)(0, i.opacity ? ? 1, m(r)), t.opacityExit = (0, s.k)(e.opacity ? ? 1, 0, f(r))) : o && (t.opacity = (0, s.k)(e.opacity ? ? 1, i.opacity ? ? 1, r));
                for (let a = 0; a < h; a++) {
                    let o = l[a],
                        h = c(e, o),
                        p = c(i, o);
                    (void 0 !== h || void 0 !== p) && (h || (h = 0), p || (p = 0), 0 === h || 0 === p || d(h) === d(p) ? (t[o] = Math.max((0, s.k)(u(h), u(p), r), 0), (n.KN.test(p) || n.KN.test(h)) && (t[o] += "%")) : t[o] = p)
                }(e.rotate || i.rotate) && (t.rotate = (0, s.k)(e.rotate || 0, i.rotate || 0, r))
            }

            function c(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            let m = y(0, .5, r.yT),
                f = y(.5, .95, a.l);

            function y(t, e, i) {
                return s => s < t ? 0 : s > e ? 1 : i((0, o.q)(t, e, s))
            }
        },
        77306: (t, e, i) => {
            i.d(e, {
                $: () => s
            });
            let s = t => /^0[^.\s]+$/u.test(t)
        },
        77504: (t, e, i) => {
            i.d(e, {
                I: () => s,
                w: () => n
            });
            let s = (t, e) => Math.abs(t - e);

            function n(t, e) {
                return Math.sqrt(s(t.x, e.x) ** 2 + s(t.y, e.y) ** 2)
            }
        },
        77819: (t, e, i) => {
            i.d(e, {
                L: () => s
            });

            function s(t, e, i, n = 0, r = 1) {
                let a = Array.from(t).sort((t, e) => t.sortNodePosition(e)).indexOf(e),
                    o = t.size,
                    l = (o - 1) * n;
                return "function" == typeof i ? i(a, o) : 1 === r ? a * n : l - a * n
            }
        },
        77975: (t, e, i) => {
            i.d(e, {
                h: () => s
            });
            let s = t => Array.isArray(t) && "number" != typeof t[0]
        },
        78675: (t, e, i) => {
            i.d(e, {
                P: () => n
            });
            var s = i(4121);

            function n(t) {
                return t.props[s.n]
            }
        },
        79139: (t, e, i) => {
            i.d(e, {
                z: () => n
            });
            var s = i(91461);

            function n(t, e, i) {
                let n = Math.max(e - 5, 0);
                return (0, s.f)(i - t(n), e - n)
            }
        },
        79393: (t, e, i) => {
            i.d(e, {
                _: () => a
            });
            var s = i(60600),
                n = i(59215),
                r = i(59029);

            function a(t, e, i = {}) {
                let o;
                if (t.notify("AnimationStart", e), Array.isArray(e)) o = Promise.all(e.map(e => (0, r.l)(t, e, i)));
                else if ("string" == typeof e) o = (0, r.l)(t, e, i);
                else {
                    let r = "function" == typeof e ? (0, s.K)(t, e, i.custom) : e;
                    o = Promise.all((0, n.$)(t, r, i))
                }
                return o.then(() => {
                    t.notify("AnimationComplete", e)
                })
            }
        },
        79560: (t, e, i) => {
            i.d(e, {
                Y: () => s,
                t: () => n
            });
            let s = 2e4;

            function n(t) {
                let e = 0,
                    i = t.next(e);
                for (; !i.done && e < s;) e += 50, i = t.next(e);
                return e >= s ? 1 / 0 : e
            }
        },
        79765: (t, e, i) => {
            i.d(e, {
                A: () => r
            });
            var s = i(20381);
            let n = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t;

            function r(t, e, i, r) {
                return t === e && i === r ? s.l : s => 0 === s || 1 === s ? s : n(function(t, e, i, s, r) {
                    let a, o, l = 0;
                    do(a = n(o = e + (i - e) / 2, s, r) - t) > 0 ? i = o : e = o; while (Math.abs(a) > 1e-7 && ++l < 12);
                    return o
                }(s, 0, 1, t, i), e, r)
            }
        },
        81220: (t, e, i) => {
            i.d(e, {
                n: () => s
            });
            let s = (0, i(34905).J)(() => {
                try {
                    document.createElement("div").animate({
                        opacity: 0
                    }, {
                        easing: "linear(0, 1)"
                    })
                } catch (t) {
                    return !1
                }
                return !0
            }, "linearEasing")
        },
        81425: (t, e, i) => {
            i.d(e, {
                S: () => s
            });
            let s = t => !!(t && t.getVelocity)
        },
        81676: (t, e, i) => {
            i.d(e, {
                D: () => s
            });

            function s(t) {
                for (let e = 1; e < t.length; e++) t[e] ? ? (t[e] = t[e - 1])
            }
        },
        81999: (t, e, i) => {
            i.d(e, {
                K: () => s
            });

            function s(t, e) {
                if (t ? .inherit && e) {
                    let {
                        inherit: i,
                        ...s
                    } = t;
                    return { ...e,
                        ...s
                    }
                }
                return t
            }
        },
        82014: (t, e, i) => {
            i.d(e, {
                P: () => n
            });
            var s = i(96062);
            class n {
                constructor() {
                    this.members = []
                }
                add(t) {
                    (0, s.Kq)(this.members, t);
                    for (let e = this.members.length - 1; e >= 0; e--) {
                        let i = this.members[e];
                        if (i === t || i === this.lead || i === this.prevLead) continue;
                        let n = i.instance;
                        n && !1 !== n.isConnected || i.snapshot || ((0, s.Ai)(this.members, i), i.unmount())
                    }
                    t.scheduleRender()
                }
                remove(t) {
                    if ((0, s.Ai)(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        let t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    for (let e = this.members.indexOf(t) - 1; e >= 0; e--) {
                        let t = this.members[e];
                        if (!1 !== t.isPresent && t.instance ? .isConnected !== !1) return this.promote(t), !0
                    }
                    return !1
                }
                promote(t, e) {
                    let i = this.lead;
                    if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                        i.updateSnapshot(), t.scheduleRender();
                        let {
                            layoutDependency: s
                        } = i.options, {
                            layoutDependency: n
                        } = t.options;
                        (void 0 === s || s !== n) && (t.resumeFrom = i, e && (i.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root ? .isUpdating && (t.isLayoutDirty = !0)), !1 === t.options.crossfade && i.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(t => {
                        t.options.onExitComplete ? .(), t.resumingFrom ? .options.onExitComplete ? .()
                    })
                }
                scheduleRender() {
                    this.members.forEach(t => t.instance && t.scheduleRender(!1))
                }
                removeLeadSnapshot() {
                    this.lead ? .snapshot && (this.lead.snapshot = void 0)
                }
            }
        },
        82322: (t, e, i) => {
            i.d(e, {
                XY: () => r,
                cH: () => u,
                mG: () => h,
                t$: () => d,
                ul: () => l,
                zL: () => a,
                zo: () => o
            });
            var s = i(4761);

            function n(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function r(t) {
                return n(t.x) && n(t.y)
            }

            function a(t, e) {
                return t.min === e.min && t.max === e.max
            }

            function o(t, e) {
                return a(t.x, e.x) && a(t.y, e.y)
            }

            function l(t, e) {
                return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max)
            }

            function h(t, e) {
                return l(t.x, e.x) && l(t.y, e.y)
            }

            function u(t) {
                return (0, s.CQ)(t.x) / (0, s.CQ)(t.y)
            }

            function d(t, e) {
                return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint
            }
        },
        82342: (t, e, i) => {
            i.d(e, {
                w: () => s
            });

            function s(t) {
                return "string" == typeof t || Array.isArray(t)
            }
        },
        83122: (t, e, i) => {
            i.d(e, {
                U: () => r
            });
            var s = i(61624),
                n = i(81425);

            function r(t, e, i) {
                for (let r in e) {
                    let a = e[r],
                        o = i[r];
                    if ((0, n.S)(a)) t.addValue(r, a);
                    else if ((0, n.S)(o)) t.addValue(r, (0, s.OQ)(a, {
                        owner: t
                    }));
                    else if (o !== a)
                        if (t.hasValue(r)) {
                            let e = t.getValue(r);
                            !0 === e.liveStyle ? e.jump(a) : e.hasAnimated || e.set(a)
                        } else {
                            let e = t.getStaticValue(r);
                            t.addValue(r, (0, s.OQ)(void 0 !== e ? e : a, {
                                owner: t
                            }))
                        }
                }
                for (let s in i) void 0 === e[s] && t.removeValue(s);
                return e
            }
        },
        83523: (t, e, i) => {
            i.d(e, {
                u: () => s
            });
            let s = (t, e) => t.depth - e.depth
        },
        84050: (t, e, i) => {
            i.d(e, {
                a: () => a,
                c: () => n
            });
            let s = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);

            function n(t) {
                return s.has(t.tagName) || !0 === t.isContentEditable
            }
            let r = new Set(["INPUT", "SELECT", "TEXTAREA"]);

            function a(t) {
                return r.has(t.tagName) || !0 === t.isContentEditable
            }
        },
        84180: (t, e, i) => {
            i.d(e, {
                V: () => n
            });
            var s = i(40348);

            function n(t, e) {
                let i = (0, s.K)(t),
                    n = new AbortController;
                return [i, {
                    passive: !0,
                    ...e,
                    signal: n.signal
                }, () => n.abort()]
            }
        },
        87261: (t, e, i) => {
            i.d(e, {
                z: () => a
            });
            var s = i(59316),
                n = i(61624),
                r = i(81425);

            function a(t, e, i) {
                let a = (0, r.S)(t) ? t : (0, n.OQ)(t);
                return a.start((0, s.f)("", a, e, i)), a.animation
            }
        },
        87957: (t, e, i) => {
            i.d(e, {
                p: () => l
            });
            var s = i(3363),
                n = i(59064);
            let r = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function a(t) {
                let [e, i] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                let [s] = i.match(n.S) || [];
                if (!s) return t;
                let a = i.replace(s, ""),
                    o = +!!r.has(e);
                return s !== i && (o *= 100), e + "(" + o + a + ")"
            }
            let o = /\b([a-z-]*)\(.*?\)/gu,
                l = { ...s.f,
                    getAnimatableNone: t => {
                        let e = t.match(o);
                        return e ? e.map(a).join(" ") : t
                    }
                }
        },
        88667: (t, e, i) => {
            i.d(e, {
                W: () => o
            });
            var s = i(87113);
            let n = { ...s.ai,
                transform: Math.round
            };
            var r = i(43868),
                a = i(6628);
            let o = {
                borderWidth: r.px,
                borderTopWidth: r.px,
                borderRightWidth: r.px,
                borderBottomWidth: r.px,
                borderLeftWidth: r.px,
                borderRadius: r.px,
                borderTopLeftRadius: r.px,
                borderTopRightRadius: r.px,
                borderBottomRightRadius: r.px,
                borderBottomLeftRadius: r.px,
                width: r.px,
                maxWidth: r.px,
                height: r.px,
                maxHeight: r.px,
                top: r.px,
                right: r.px,
                bottom: r.px,
                left: r.px,
                inset: r.px,
                insetBlock: r.px,
                insetBlockStart: r.px,
                insetBlockEnd: r.px,
                insetInline: r.px,
                insetInlineStart: r.px,
                insetInlineEnd: r.px,
                padding: r.px,
                paddingTop: r.px,
                paddingRight: r.px,
                paddingBottom: r.px,
                paddingLeft: r.px,
                paddingBlock: r.px,
                paddingBlockStart: r.px,
                paddingBlockEnd: r.px,
                paddingInline: r.px,
                paddingInlineStart: r.px,
                paddingInlineEnd: r.px,
                margin: r.px,
                marginTop: r.px,
                marginRight: r.px,
                marginBottom: r.px,
                marginLeft: r.px,
                marginBlock: r.px,
                marginBlockStart: r.px,
                marginBlockEnd: r.px,
                marginInline: r.px,
                marginInlineStart: r.px,
                marginInlineEnd: r.px,
                fontSize: r.px,
                backgroundPositionX: r.px,
                backgroundPositionY: r.px,
                ...a.H,
                zIndex: n,
                fillOpacity: s.X4,
                strokeOpacity: s.X4,
                numOctaves: n
            }
        },
        89172: (t, e, i) => {
            i.d(e, {
                L: () => a,
                m: () => r
            });
            var s = i(30537),
                n = i(38264);

            function r(t, e) {
                return (0, s.FY)((0, s.bS)(t.getBoundingClientRect(), e))
            }

            function a(t, e, i) {
                let s = r(t, i),
                    {
                        scroll: a
                    } = e;
                return a && ((0, n.Ql)(s.x, a.offset.x), (0, n.Ql)(s.y, a.offset.y)), s
            }
        },
        89916: (t, e, i) => {
            i.d(e, {
                m: () => p
            });
            var s = i(99296),
                n = i(69377),
                r = i(20381),
                a = i(99672),
                o = i(20154),
                l = i(30396),
                h = i(8320),
                u = i(30286),
                d = i(33882);
            class p extends h.q {
                constructor(t) {
                    if (super(), this.finishedTime = null, this.isStopped = !1, this.manualStartTime = null, !t) return;
                    const {
                        element: e,
                        name: i,
                        keyframes: n,
                        pseudoElement: r,
                        allowFlatten: o = !1,
                        finalKeyframe: h,
                        onComplete: p
                    } = t;
                    this.isPseudoElement = !!r, this.allowFlatten = o, this.options = t, (0, s.V)("string" != typeof t.type, 'Mini animate() doesn\'t support "type" as a string.', "mini-spring");
                    const c = (0, d.i)(t);
                    this.animation = (0, u.R)(e, i, n, c, r), !1 === c.autoplay && this.animation.pause(), this.animation.onfinish = () => {
                        if (this.finishedTime = this.time, !r) {
                            let t = (0, l.X)(n, this.options, h, this.speed);
                            this.updateMotionValue && this.updateMotionValue(t), (0, a.e)(e, i, t), this.animation.cancel()
                        }
                        p ? .(), this.notifyFinished()
                    }
                }
                play() {
                    this.isStopped || (this.manualStartTime = null, this.animation.play(), "finished" === this.state && this.updateFinished())
                }
                pause() {
                    this.animation.pause()
                }
                complete() {
                    this.animation.finish ? .()
                }
                cancel() {
                    try {
                        this.animation.cancel()
                    } catch (t) {}
                }
                stop() {
                    if (this.isStopped) return;
                    this.isStopped = !0;
                    let {
                        state: t
                    } = this;
                    "idle" !== t && "finished" !== t && (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel())
                }
                commitStyles() {
                    let t = this.options ? .element;
                    !this.isPseudoElement && t ? .isConnected && this.animation.commitStyles ? .()
                }
                get duration() {
                    let t = this.animation.effect ? .getComputedTiming ? .().duration || 0;
                    return (0, n.X)(Number(t))
                }
                get iterationDuration() {
                    let {
                        delay: t = 0
                    } = this.options || {};
                    return this.duration + (0, n.X)(t)
                }
                get time() {
                    return (0, n.X)(Number(this.animation.currentTime) || 0)
                }
                set time(t) {
                    let e = null !== this.finishedTime;
                    this.manualStartTime = null, this.finishedTime = null, this.animation.currentTime = (0, n.f)(t), e && this.animation.pause()
                }
                get speed() {
                    return this.animation.playbackRate
                }
                set speed(t) {
                    t < 0 && (this.finishedTime = null), this.animation.playbackRate = t
                }
                get state() {
                    return null !== this.finishedTime ? "finished" : this.animation.playState
                }
                get startTime() {
                    return this.manualStartTime ? ? Number(this.animation.startTime)
                }
                set startTime(t) {
                    this.manualStartTime = this.animation.startTime = t
                }
                attachTimeline({
                    timeline: t,
                    rangeStart: e,
                    rangeEnd: i,
                    observe: s
                }) {
                    return (this.allowFlatten && this.animation.effect ? .updateTiming({
                        easing: "linear"
                    }), this.animation.onfinish = null, t && (0, o.J)()) ? (this.animation.timeline = t, e && (this.animation.rangeStart = e), i && (this.animation.rangeEnd = i), r.l) : s(this)
                }
            }
        },
        91437: (t, e, i) => {
            i.d(e, {
                i: () => u,
                l: () => h
            });
            var s = i(37789),
                n = i(77975),
                r = i(33987),
                a = i(66749),
                o = i(73941),
                l = i(64059);

            function h(t, e) {
                return t.map(() => e || s.am).splice(0, t.length - 1)
            }

            function u({
                duration: t = 300,
                keyframes: e,
                times: i,
                ease: s = "easeInOut"
            }) {
                let d = (0, n.h)(s) ? s.map(r.K) : (0, r.K)(s),
                    p = {
                        done: !1,
                        value: e[0]
                    },
                    c = (0, l.A)(i && i.length === e.length ? i : (0, o.Z)(e), t),
                    m = (0, a.G)(c, e, {
                        ease: Array.isArray(d) ? d : h(e, d)
                    });
                return {
                    calculatedDuration: t,
                    next: e => (p.value = m(e), p.done = e >= t, p)
                }
            }
        },
        93485: (t, e, i) => {
            i.d(e, {
                W: () => function t(e, i, a = 1) {
                    (0, s.V)(a <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`, "max-css-var-depth");
                    let [l, h] = o(e);
                    if (!l) return;
                    let u = window.getComputedStyle(i).getPropertyValue(l);
                    if (u) {
                        let t = u.trim();
                        return (0, n.i)(t) ? parseFloat(t) : t
                    }
                    return (0, r.pG)(h) ? t(h, i, a + 1) : h
                },
                t: () => o
            });
            var s = i(99296),
                n = i(69032),
                r = i(96900);
            let a = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;

            function o(t) {
                let e = a.exec(t);
                if (!e) return [, ];
                let [, i, s, n] = e;
                return [`--${i??s}`, n]
            }
        },
        94219: (t, e, i) => {
            i.d(e, {
                t: () => l
            });
            var s = i(7050),
                n = i(3363),
                r = i(71405),
                a = i(956);
            let o = [...r.T, s.y, n.f],
                l = t => o.find((0, a.w)(t))
        },
        94221: (t, e, i) => {
            i.d(e, {
                V: () => function t(e) {
                    if (!e) return;
                    if (!e.isControllingVariants) {
                        let i = e.parent && t(e.parent) || {};
                        return void 0 !== e.props.initial && (i.initial = e.props.initial), i
                    }
                    let i = {};
                    for (let t = 0; t < r; t++) {
                        let r = n._[t],
                            a = e.props[r];
                        ((0, s.w)(a) || !1 === a) && (i[r] = a)
                    }
                    return i
                }
            });
            var s = i(82342),
                n = i(21109);
            let r = n._.length
        },
        95214: (t, e, i) => {
            i.d(e, {
                Ib: () => p,
                ry: () => d,
                zs: () => u
            });
            let s = t => 180 * t / Math.PI,
                n = t => a(s(Math.atan2(t[1], t[0]))),
                r = {
                    x: 4,
                    y: 5,
                    translateX: 4,
                    translateY: 5,
                    scaleX: 0,
                    scaleY: 3,
                    scale: t => (Math.abs(t[0]) + Math.abs(t[3])) / 2,
                    rotate: n,
                    rotateZ: n,
                    skewX: t => s(Math.atan(t[1])),
                    skewY: t => s(Math.atan(t[2])),
                    skew: t => (Math.abs(t[1]) + Math.abs(t[2])) / 2
                },
                a = t => ((t %= 360) < 0 && (t += 360), t),
                o = t => Math.sqrt(t[0] * t[0] + t[1] * t[1]),
                l = t => Math.sqrt(t[4] * t[4] + t[5] * t[5]),
                h = {
                    x: 12,
                    y: 13,
                    z: 14,
                    translateX: 12,
                    translateY: 13,
                    translateZ: 14,
                    scaleX: o,
                    scaleY: l,
                    scale: t => (o(t) + l(t)) / 2,
                    rotateX: t => a(s(Math.atan2(t[6], t[5]))),
                    rotateY: t => a(s(Math.atan2(-t[2], t[0]))),
                    rotateZ: n,
                    rotate: n,
                    skewX: t => s(Math.atan(t[4])),
                    skewY: t => s(Math.atan(t[1])),
                    skew: t => (Math.abs(t[1]) + Math.abs(t[4])) / 2
                };

            function u(t) {
                return +!!t.includes("scale")
            }

            function d(t, e) {
                let i, s;
                if (!t || "none" === t) return u(e);
                let n = t.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
                if (n) i = h, s = n;
                else {
                    let e = t.match(/^matrix\(([-\d.e\s,]+)\)$/u);
                    i = r, s = e
                }
                if (!s) return u(e);
                let a = i[e],
                    o = s[1].split(",").map(c);
                return "function" == typeof a ? a(o) : o[a]
            }
            let p = (t, e) => {
                let {
                    transform: i = "none"
                } = getComputedStyle(t);
                return d(i, e)
            };

            function c(t) {
                return parseFloat(t.trim())
            }
        },
        95807: (t, e, i) => {
            i.d(e, {
                R: () => l
            });
            var s = i(99007),
                n = i(16492);
            let r = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/,
                a = new Set(["color", "backgroundColor", "outlineColor", "fill", "stroke", "borderColor", "borderTopColor", "borderRightColor", "borderBottomColor", "borderLeftColor"]),
                o = (0, s.p)(() => Object.hasOwnProperty.call(Element.prototype, "animate"));

            function l(t) {
                let {
                    motionValue: e,
                    name: i,
                    repeatDelay: s,
                    repeatType: l,
                    damping: h,
                    type: u,
                    keyframes: d
                } = t;
                if (!(e ? .owner ? .current instanceof HTMLElement)) return !1;
                let {
                    onUpdate: p,
                    transformTemplate: c
                } = e.owner.getProps();
                return o() && i && (n.M.has(i) || a.has(i) && function(t) {
                    for (let e = 0; e < t.length; e++)
                        if ("string" == typeof t[e] && r.test(t[e])) return !0;
                    return !1
                }(d)) && ("transform" !== i || !c) && !p && !s && "mirror" !== l && 0 !== h && "inertia" !== u
            }
        },
        99672: (t, e, i) => {
            i.d(e, {
                e: () => n
            });
            var s = i(48336);

            function n(t, e, i) {
                (0, s.v)(e) ? t.style.setProperty(e, i): t.style[e] = i
            }
        }
    }
]);