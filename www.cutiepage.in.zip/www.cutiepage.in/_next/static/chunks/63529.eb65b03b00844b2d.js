"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [11062, 63529], {
        11062: (e, o, r) => {
            r.r(o), r.d(o, {
                createSupabaseBrowserClient: () => a
            });
            var t = r(38787),
                n = r(55365),
                i = r(21381),
                _ = r(41786);

            function a() {
                let e = (0, n.jb)();
                if (!e.NEXT_PUBLIC_SUPABASE_URL || !e.NEXT_PUBLIC_SUPABASE_ANON_KEY) throw Error("Supabase browser environment variables are missing.");
                let o = (0, i.y)(window.location.host);
                return o && function() {
                    if ("u" > typeof document)
                        for (let e of (0, _.Bz)((0, _.MB)(document.cookie))) document.cookie = `${e}=; Path=/; Max-Age=0`
                }(), (0, t.k)(e.NEXT_PUBLIC_SUPABASE_URL, e.NEXT_PUBLIC_SUPABASE_ANON_KEY, o ? {
                    cookieOptions: {
                        domain: o
                    }
                } : void 0)
            }
        },
        58560: (e, o, r) => {
            r.d(o, {
                ai: () => i
            });
            var t = r(76724),
                n = r(19071);

            function i(e) {
                return t.qG(n.rS, e)
            }
        }
    }
]);