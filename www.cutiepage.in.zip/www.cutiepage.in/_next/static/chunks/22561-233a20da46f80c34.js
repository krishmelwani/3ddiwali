"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [22561], {
        5438: (e, t, n) => {
            n.d(t, {
                BN: () => f,
                Gl: () => u,
                IY: () => m,
                hj: () => p,
                nQ: () => h
            });
            var l = n(73365),
                i = n(11429),
                r = n(93576),
                s = n(2911),
                o = n(1521),
                a = n(87404),
                c = n(54872),
                d = n(89503);

            function u(e) {
                return e.copy ? ? d.ur
            }

            function p({
                field: e,
                ctx: t,
                compact: n = !1
            }) {
                let i = (0, o.useId)(),
                    [r, s] = function(e) {
                        let t = "string" == typeof e ? e : "",
                            [n, l] = (0, o.useState)(t),
                            [i, r] = (0, o.useState)(t);
                        return t !== i && (r(t), l(t)), [n, l]
                    }(e.value),
                    [c, d] = (0, o.useState)(null),
                    f = "textarea" === e.field.type,
                    m = n => {
                        var l;
                        s(n), d(t.commit(e.target, n) ? null : (l = u(t), "link" === e.field.type ? l.badLink : e.field.maxLength ? l.tooLong(e.field.maxLength) : l.didNotFit))
                    },
                    h = {
                        id: i,
                        value: r,
                        maxLength: e.field.maxLength,
                        placeholder: e.field.placeholder,
                        invalid: !!c,
                        onFocus: () => t.onFocusSection ? .(e.target.sectionId)
                    };
                return (0, l.jsx)(a.D0, {
                    label: n ? (0, l.jsx)("span", {
                        className: "sr-only",
                        children: e.label
                    }) : e.label,
                    htmlFor: i,
                    hint: n ? void 0 : e.hint,
                    error: c,
                    children: f ? (0, l.jsx)(a.TM, { ...h,
                        rows: 3,
                        className: "min-h-20 rounded-xl px-3.5 py-2.5 text-[15px] leading-6",
                        onChange: e => m(e.target.value)
                    }) : (0, l.jsx)(a.pd, { ...h,
                        type: "link" === e.field.type ? "url" : "text",
                        inputMode: "link" === e.field.type ? "url" : void 0,
                        inputSize: n ? "sm" : "md",
                        className: n ? "h-10 rounded-lg px-3 text-[13px]" : "h-11 rounded-xl px-3.5 text-[15px]",
                        onChange: e => m(e.target.value)
                    })
                })
            }

            function f({
                field: e,
                ctx: t
            }) {
                let n = e.field.options ? ? [];
                return (0, l.jsxs)("div", {
                    role: "radiogroup",
                    "aria-label": e.label,
                    className: "flex flex-col gap-1.5",
                    children: [(0, l.jsx)("span", {
                        className: "text-[13px] text-cp-muted",
                        children: e.label
                    }), (0, l.jsx)("div", {
                        className: "flex flex-wrap gap-2",
                        children: n.map(n => {
                            let i = e.value === n;
                            return (0, l.jsx)("button", {
                                type: "button",
                                role: "radio",
                                "aria-checked": i,
                                onFocus: () => t.onFocusSection ? .(e.target.sectionId),
                                onClick: () => t.commit(e.target, n),
                                className: `min-h-10 rounded-xl px-3.5 text-[14px] font-medium transition-colors duration-150 motion-reduce:transition-none ${i?"bg-cp-primary text-white":"bg-cp-subtle text-cp-ink hover:bg-cp-hover"}`,
                                children: n
                            }, n)
                        })
                    })]
                })
            }

            function m({
                field: e,
                ctx: t
            }) {
                let n = (0, o.useId)(),
                    i = e.field.choice;
                return i ? (0, l.jsxs)("div", {
                    role: "radiogroup",
                    "aria-label": e.label,
                    className: "flex items-center gap-2 text-[14px] text-cp-ink",
                    children: [(0, l.jsx)("span", {
                        className: "shrink-0 pr-1 text-[13px] text-cp-muted",
                        children: e.label
                    }), [!0, !1].map((n, r) => {
                        let s = !0 === e.value === n;
                        return (0, l.jsx)("button", {
                            type: "button",
                            role: "radio",
                            "aria-checked": s,
                            onFocus: () => t.onFocusSection ? .(e.target.sectionId),
                            onClick: () => t.commit(e.target, n),
                            className: `min-h-10 flex-1 rounded-xl px-3 font-medium transition-colors duration-150 motion-reduce:transition-none ${s?"bg-cp-primary text-white":"bg-cp-subtle hover:bg-cp-hover"}`,
                            children: i[r]
                        }, i[r])
                    })]
                }) : (0, l.jsxs)("label", {
                    htmlFor: n,
                    className: "flex min-h-11 cursor-pointer items-center gap-3 rounded-xl bg-cp-subtle px-3.5 text-[14px] text-cp-ink transition-colors duration-150 hover:bg-cp-hover motion-reduce:transition-none",
                    children: [(0, l.jsx)("input", {
                        id: n,
                        type: "checkbox",
                        checked: !0 === e.value,
                        onFocus: () => t.onFocusSection ? .(e.target.sectionId),
                        onChange: n => t.commit(e.target, n.target.checked),
                        className: "size-[18px] shrink-0 accent-cp-primary"
                    }), e.label]
                })
            }

            function h({
                field: e,
                ctx: t,
                shape: n = "wide",
                name: a
            }) {
                let d = (0, o.useRef)(null),
                    [p, f] = (0, o.useState)(!1),
                    [m, x] = (0, o.useState)(null),
                    g = "string" == typeof e.value ? e.value : "",
                    b = g ? t.resolveAsset(g) : null,
                    y = a ? ? e.label,
                    k = u(t),
                    v = async n => {
                        f(!0), x(null);
                        try {
                            let l = await n();
                            if (!l) return;
                            if (!l.ok) return void x(l.message);
                            t.commit(e.target, l.url) || x(k.photoNotUsed)
                        } finally {
                            f(!1), d.current && (d.current.value = "")
                        }
                    },
                    j = async n => {
                        n && await v(() => t.upload(n, e.target))
                    },
                    w = t.pick,
                    N = w ? () => void v(() => w(e.target, "image")) : () => d.current ? .click();
                return (0, l.jsxs)("div", {
                    className: "flex flex-col gap-1.5",
                    children: ["wide" === n ? (0, l.jsx)("span", {
                        className: "text-[12px] font-medium text-cp-ink",
                        children: e.label
                    }) : null, (0, l.jsxs)("button", {
                        type: "button",
                        onClick: N,
                        onFocus: () => t.onFocusSection ? .(e.target.sectionId),
                        disabled: p,
                        "aria-label": b ? k.replaceLabel(y) : k.addLabel(y),
                        className: (0, c.cn)("group relative flex w-full items-center justify-center overflow-hidden rounded-xl border border-dashed border-cp-line-strong bg-cp-subtle text-cp-muted", "transition-[border-color,color,box-shadow] duration-150 hover:border-cp-select hover:text-cp-ink motion-reduce:transition-none", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", "wide" === n ? "h-40" : "aspect-square", b && "border-solid border-cp-line hover:border-cp-line-strong"),
                        children: [b ? (0, l.jsx)("img", {
                            src: b,
                            alt: "",
                            className: "size-full object-cover transition-transform duration-200 group-hover:scale-[1.03] motion-reduce:transition-none motion-reduce:group-hover:scale-100"
                        }) : (0, l.jsxs)("span", {
                            className: "flex flex-col items-center gap-1.5 text-[12px] font-medium",
                            children: [(0, l.jsx)("span", {
                                className: "flex size-9 items-center justify-center rounded-full bg-cp-bg text-cp-primary shadow-[0_1px_3px_rgba(20,12,60,0.12)]",
                                children: (0, l.jsx)(i.A, {
                                    className: "size-4",
                                    strokeWidth: 1.75,
                                    "aria-hidden": !0
                                })
                            }), k.addPhoto]
                        }), b ? (0, l.jsxs)("span", {
                            className: "absolute right-1.5 bottom-1.5 flex h-7 items-center gap-1 rounded-full bg-cp-bg/95 px-2.5 text-[11px] font-semibold text-cp-ink shadow-[0_1px_4px_rgba(20,12,60,0.2)]",
                            children: [(0, l.jsx)(r.A, {
                                className: "size-3.5",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            }), k.replace]
                        }) : null, p ? (0, l.jsxs)("span", {
                            className: "absolute inset-0 flex items-center justify-center bg-cp-bg/70",
                            children: [(0, l.jsx)(s.A, {
                                className: "size-5 animate-spin text-cp-muted",
                                strokeWidth: 1.75,
                                "aria-hidden": !0
                            }), (0, l.jsx)("span", {
                                className: "sr-only",
                                children: k.addingPhoto
                            })]
                        }) : null]
                    }), m ? (0, l.jsx)("p", {
                        role: "alert",
                        className: "text-[12px] text-cp-danger-ink",
                        children: m
                    }) : null, (0, l.jsx)("input", {
                        ref: d,
                        type: "file",
                        accept: t.imageAccept,
                        className: "hidden",
                        tabIndex: -1,
                        "aria-hidden": !0,
                        onChange: e => void j(e.target.files ? .[0])
                    })]
                })
            }
        },
        6127: (e, t, n) => {
            n.d(t, {
                BL: () => m,
                Hx: () => h,
                Ix: () => c,
                ND: () => d,
                Q0: () => j,
                dh: () => y,
                gp: () => b,
                lV: () => u,
                mC: () => x,
                mc: () => p,
                wA: () => g,
                xw: () => f,
                zr: () => k
            });
            var l = n(77420);
            let i = new Set(["text", "textarea", "image", "link", "boolean"]),
                r = new Set(["text", "textarea", "image", "link"]);

            function s(e) {
                return r.has(e.type) && !e.hidden && !e.options
            }

            function o(e, t, n) {
                let l = e.pages[0];
                if (!l || !t.sections[n]) return null;
                let i = l.sections.find(e => e.type === n);
                return !i || i.hidden ? null : {
                    pageId: l.id,
                    section: i
                }
            }

            function a(e) {
                return "section" === e.kind ? `${e.sectionId}.${e.fieldId}` : `${e.sectionId}.${e.stackId}.${e.itemId}.${e.fieldId}`
            }

            function c(e, t) {
                let n = e.simpleEditor;
                if (!n || t.template !== e.key) return [];
                let l = [],
                    r = n => n.map(n => (function(e, t, n) {
                        if ("sound" === n.kind) {
                            let l = t.sound ? .src ? t.sound : null,
                                i = n.songs ? .length ? n.songs.map(e => ({ ...t.sound,
                                    src: e.src,
                                    title: e.title
                                })) : l ? [l] : [];
                            return {
                                kind: "sound",
                                key: "sound",
                                label: n.label ? ? "Song",
                                hint: n.hint,
                                sound: e.sound ? ? null,
                                defaultSound: l,
                                songs: i
                            }
                        }
                        if ("copyPack" === n.kind) {
                            var l = e,
                                r = t,
                                s = n;
                            let i = o(l, r, s.sectionType);
                            if (!i || !r.sections[s.sectionType].fields.some(e => e.id === s.fieldId)) return null;
                            let a = i.section.values[s.fieldId],
                                c = "string" == typeof a && s.options.some(e => e.id === a) ? a : null;
                            return {
                                kind: "copyPack",
                                key: `${i.section.id}.${s.fieldId}`,
                                sectionId: i.section.id,
                                label: s.label ? ? "",
                                hint: s.hint,
                                value: c,
                                options: s.options.map(e => ({
                                    id: e.id,
                                    label: e.label,
                                    sub: e.sub,
                                    ops: function(e, t, n, l) {
                                        let i = n.options.find(e => e.id === l),
                                            r = o(e, t, n.sectionType);
                                        if (!i || !r) return [];
                                        let s = [],
                                            a = n.options.filter(e => e.id !== i.id);
                                        r.section.values[n.fieldId] !== l && (s.push({
                                            op: "setSectionField",
                                            pageId: r.pageId,
                                            sectionId: r.section.id,
                                            fieldId: n.fieldId,
                                            value: l
                                        }), i.presetId && s.push({
                                            op: "applyPreset",
                                            presetId: i.presetId
                                        }));
                                        let c = e.sound ? .src;
                                        for (let [n, l] of (i.song && e.sound && c !== i.song.src && a.some(e => e.song ? .src === c) && s.push({
                                                op: "setSound",
                                                sound: { ...e.sound,
                                                    src: i.song.src,
                                                    title: i.song.title
                                                }
                                            }), Object.entries(i.items ? ? {}))) {
                                            let i = o(e, t, n);
                                            if (!i) continue;
                                            let r = t.sections[n];
                                            for (let [e, t] of Object.entries(l))(i.section.stacks[e] ? ? []).filter(e => !e.hidden).forEach((l, o) => {
                                                let c = r.items[l.kind] ? .fields ? ? [];
                                                for (let [r, d] of Object.entries(t[o] ? ? {})) {
                                                    let t = c.find(e => e.id === r);
                                                    if (!t) continue;
                                                    let u = l.values[r] ? ? t.default;
                                                    if (u === d) continue;
                                                    let p = a.map(t => t.items ? .[n] ? .[e] ? .[o] ? .[r]);
                                                    ("" === u || p.includes(u)) && s.push({
                                                        op: "setItemField",
                                                        pageId: i.pageId,
                                                        sectionId: i.section.id,
                                                        stackId: e,
                                                        itemId: l.id,
                                                        fieldId: r,
                                                        value: d
                                                    })
                                                }
                                            })
                                        }
                                        for (let [l, r] of Object.entries(i.values)) {
                                            let a = o(e, t, l);
                                            if (!a) continue;
                                            let c = t.sections[l];
                                            for (let [e, t] of Object.entries(r)) {
                                                let r = c.fields.find(t => t.id === e);
                                                if (!r) continue;
                                                let o = a.section.values[e] ? ? r.default;
                                                if (o === t) continue;
                                                let d = n.options.filter(e => e.id !== i.id).map(t => t.values[l] ? .[e]).filter(e => "string" == typeof e);
                                                ("" === o || d.includes(o)) && s.push({
                                                    op: "setSectionField",
                                                    pageId: a.pageId,
                                                    sectionId: a.section.id,
                                                    fieldId: e,
                                                    value: t
                                                })
                                            }
                                        }
                                        return s
                                    }(l, r, s, e.id)
                                }))
                            }
                        }
                        let c = o(e, t, n.sectionType);
                        if (!c) return null;
                        let {
                            pageId: d,
                            section: u
                        } = c, p = t.sections[u.type];
                        if ("section" === n.kind) {
                            let e = p.fields.find(e => e.id === n.fieldId);
                            if (!e || !i.has(e.type)) return null;
                            let t = {
                                    kind: "section",
                                    pageId: d,
                                    sectionId: u.id,
                                    fieldId: e.id
                                },
                                l = a(t);
                            return {
                                kind: "field",
                                key: l,
                                sectionId: u.id,
                                field: {
                                    key: l,
                                    target: t,
                                    field: e,
                                    label: n.label ? ? e.label,
                                    hint: n.hint,
                                    value: u.values[e.id] ? ? e.default
                                }
                            }
                        }
                        let f = p.stacks[n.stackId];
                        if (!f) return null;
                        let m = (u.stacks[n.stackId] ? ? []).filter(e => !e.hidden),
                            h = [];
                        return (m.forEach((e, t) => {
                            let l = p.items[e.kind];
                            if (!l) return;
                            let r = (n.fieldIds ? n.fieldIds.map(e => l.fields.find(t => t.id === e)).filter(e => !!e) : l.fields).filter(e => i.has(e.type)).map(t => {
                                let l = {
                                    kind: "item",
                                    pageId: d,
                                    sectionId: u.id,
                                    stackId: n.stackId,
                                    itemId: e.id,
                                    fieldId: t.id
                                };
                                return {
                                    key: a(l),
                                    target: l,
                                    field: t,
                                    label: t.label,
                                    value: e.values[t.id] ? ? t.default
                                }
                            });
                            r.length > 0 && h.push({
                                itemId: e.id,
                                label: `${l.label} ${t+1}`,
                                itemLabel: l.label,
                                position: t + 1,
                                fields: r
                            })
                        }), 0 === h.length) ? null : {
                            kind: "stack",
                            key: `${u.id}.${n.stackId}`,
                            sectionId: u.id,
                            label: n.label ? ? f.label,
                            hint: n.hint,
                            entries: h
                        }
                    })(t, e, n)).filter(e => null !== e);
                for (let e of n.groups) {
                    let t = (e.parts ? ? []).map((t, n) => ({
                            key: `${e.id}.part${n}`,
                            title: t.title,
                            hint: t.hint,
                            controls: r(t.fields)
                        })).filter(e => e.controls.length > 0),
                        n = [...r(e.fields), ...t.flatMap(e => e.controls)];
                    n.length > 0 && l.push({
                        id: e.id,
                        title: e.title,
                        hint: e.hint,
                        controls: n,
                        ...e.widget ? {
                            widget: e.widget
                        } : {},
                        ...t.length > 0 ? {
                            parts: t
                        } : {}
                    })
                }
                return [...l, ... function(e, t, n) {
                    let l = new Set;
                    for (let e of n)
                        for (let t of e.controls)
                            if ("field" === t.kind && l.add(t.field.key), "stack" === t.kind)
                                for (let e of t.entries)
                                    for (let t of e.fields) l.add(t.key);
                    let i = e.pages[0];
                    if (!i) return [];
                    let r = [];
                    for (let e of i.sections) {
                        let n = t.sections[e.type];
                        if (!n || e.hidden) continue;
                        let o = [];
                        for (let t of n.fields) {
                            if (!s(t)) continue;
                            let n = {
                                    kind: "section",
                                    pageId: i.id,
                                    sectionId: e.id,
                                    fieldId: t.id
                                },
                                r = a(n);
                            l.has(r) || o.push({
                                kind: "field",
                                key: r,
                                sectionId: e.id,
                                field: {
                                    key: r,
                                    target: n,
                                    field: t,
                                    label: t.label,
                                    value: e.values[t.id] ? ? t.default
                                }
                            })
                        }
                        for (let [t, r] of Object.entries(n.stacks)) {
                            let c = [];
                            (e.stacks[t] ? ? []).filter(e => !e.hidden).forEach((r, o) => {
                                let d = n.items[r.kind];
                                if (!d) return;
                                let u = d.fields.filter(s).flatMap(n => {
                                    let s = {
                                            kind: "item",
                                            pageId: i.id,
                                            sectionId: e.id,
                                            stackId: t,
                                            itemId: r.id,
                                            fieldId: n.id
                                        },
                                        o = a(s);
                                    return l.has(o) ? [] : [{
                                        key: o,
                                        target: s,
                                        field: n,
                                        label: n.label,
                                        value: r.values[n.id] ? ? n.default
                                    }]
                                });
                                u.length > 0 && c.push({
                                    itemId: r.id,
                                    label: `${d.label} ${o+1}`,
                                    itemLabel: d.label,
                                    position: o + 1,
                                    fields: u
                                })
                            }), c.length > 0 && o.push({
                                kind: "stack",
                                key: `${e.id}.${t}`,
                                sectionId: e.id,
                                label: r.label,
                                entries: c
                            })
                        }
                        o.length > 0 && r.push({
                            id: `rest-${e.id}`,
                            title: n.label,
                            controls: o,
                            collapsed: !0
                        })
                    }
                    return r
                }(t, e, l)]
            }

            function d(e, t) {
                let n = new Map((t.pages[0] ? .sections ? ? []).map((e, t) => [e.id, t])),
                    l = -1;
                return e.map(e => {
                    let t = e.controls.flatMap(e => "sectionId" in e && n.has(e.sectionId) ? [n.get(e.sectionId)] : []);
                    return {
                        group: e,
                        rank: l = t.length > 0 ? Math.min(...t) : l
                    }
                }).sort((e, t) => e.rank - t.rank).map(({
                    group: e
                }) => e)
            }

            function u(e) {
                return (e.simpleEditor ? .looks ? ? !0) && e.presets.length > 1
            }

            function p(e, t) {
                return "section" === e.kind ? {
                    op: "setSectionField",
                    pageId: e.pageId,
                    sectionId: e.sectionId,
                    fieldId: e.fieldId,
                    value: t
                } : {
                    op: "setItemField",
                    pageId: e.pageId,
                    sectionId: e.sectionId,
                    stackId: e.stackId,
                    itemId: e.itemId,
                    fieldId: e.fieldId,
                    value: t
                }
            }

            function f(e) {
                return {
                    op: "applyPreset",
                    presetId: e
                }
            }

            function m(e) {
                return {
                    op: "setSound",
                    sound: e
                }
            }

            function h(e, t, n = []) {
                return e ? .src ? t && e.src === t.src || n.some(t => t.src === e.src) ? "default" : "custom" : "none"
            }

            function x(e, t, n, l) {
                let i = e ? ? t;
                return {
                    src: n,
                    ...l ? {
                        title: l
                    } : {},
                    loop: i ? .loop ? ? !0,
                    ...i ? .volume !== void 0 ? {
                        volume: i.volume
                    } : {},
                    ...i ? .effects !== void 0 ? {
                        effects: i.effects
                    } : {}
                }
            }

            function g(e, t) {
                return { ...t,
                    ...e ? .effects !== void 0 ? {
                        effects: e.effects
                    } : {}
                }
            }

            function b(e) {
                let t = e ? .effects;
                return t && "none" !== t ? {
                    src: "",
                    effects: t
                } : null
            }

            function y(e, t, n, i) {
                let r = (0, l.Lx)(e, n, t, i);
                return r.ok ? r.doc : null
            }

            function k(e, t) {
                for (let n of e.presets) {
                    let e = Object.entries(n.values);
                    if (e.length > 0 && e.every(([e, n]) => t[e] === n)) return n.id
                }
                return null
            }
            let v = ["bg", "accent", "fg", "surface"];

            function j(e, t, n = 4) {
                let l = Object.entries(e.tokens).filter(([, e]) => "color" === e.type).map(([e]) => e),
                    i = [...v.filter(e => l.includes(e)), ...l.filter(e => !v.includes(e))],
                    r = [];
                for (let e of i) {
                    let l = t.values[e];
                    if ("string" != typeof l || r.includes(l) || r.push(l), r.length >= n) break
                }
                return r
            }
        },
        7368: (e, t, n) => {
            n.d(t, {
                lw: () => g,
                HS: () => h,
                Zh: () => x
            });
            var l = n(73365),
                i = n(39255),
                r = n(26821),
                s = n(86714),
                o = n(1521),
                a = n(74871),
                c = n(54872),
                d = n(5438);

            function u({
                control: e,
                ctx: t
            }) {
                let n = (0, o.useRef)([]),
                    [i, s] = (0, o.useState)(null),
                    a = e.options,
                    p = e.value ? ? a[0] ? .id ? ? null,
                    f = e => {
                        let n = a[e];
                        n && 0 !== n.ops.length && s(t.commitOps ? .(n.ops) ? null : (0, d.Gl)(t).didNotFit)
                    };
                return (0, l.jsxs)("div", {
                    className: "flex flex-col gap-1.5",
                    children: [e.label ? (0, l.jsx)("p", {
                        className: "text-[12px] font-medium text-cp-ink",
                        children: e.label
                    }) : null, (0, l.jsx)("div", {
                        role: "radiogroup",
                        "aria-label": e.label || void 0,
                        onKeyDown: e => {
                            if (!["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp", "Home", "End"].includes(e.key) || 0 === a.length) return;
                            e.preventDefault();
                            let t = Math.max(0, a.findIndex(e => e.id === p)),
                                l = "Home" === e.key ? 0 : "End" === e.key ? a.length - 1 : (t + ("ArrowRight" === e.key || "ArrowDown" === e.key ? 1 : -1) + a.length) % a.length;
                            f(l), n.current[l] ? .focus()
                        },
                        className: "grid grid-cols-2 gap-2",
                        children: a.map((i, s) => {
                            let o = i.id === p;
                            return (0, l.jsxs)("button", {
                                ref: e => {
                                    n.current[s] = e
                                },
                                type: "button",
                                role: "radio",
                                "aria-checked": o,
                                tabIndex: o ? 0 : -1,
                                onFocus: () => t.onFocusSection ? .(e.sectionId),
                                onClick: () => f(s),
                                className: (0, c.cn)("relative flex min-h-[64px] flex-col items-start justify-center rounded-xl border px-3.5 py-2.5 text-left", "transition-[background-color,border-color] duration-150 motion-reduce:transition-none", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", o ? "border-cp-primary bg-cp-primary-soft" : "border-cp-line bg-cp-bg hover:border-cp-line-strong"),
                                children: [(0, l.jsx)("span", {
                                    className: "pr-6 text-[16px] font-semibold leading-snug text-cp-ink",
                                    children: i.label
                                }), i.sub ? (0, l.jsx)("span", {
                                    className: "mt-0.5 text-[12px] leading-snug text-cp-muted",
                                    children: i.sub
                                }) : null, (0, l.jsx)("span", {
                                    "aria-hidden": !0,
                                    className: (0, c.cn)("absolute top-2.5 right-2.5 flex size-4 items-center justify-center rounded-full border", o ? "border-cp-primary bg-cp-primary text-white" : "border-cp-line-strong"),
                                    children: o ? (0, l.jsx)(r.A, {
                                        className: "size-3",
                                        strokeWidth: 3
                                    }) : null
                                })]
                            }, i.id)
                        })
                    }), e.hint ? (0, l.jsx)("p", {
                        className: "text-[12px] leading-5 text-cp-muted",
                        children: e.hint
                    }) : null, i ? (0, l.jsx)("p", {
                        role: "alert",
                        className: "text-[12px] text-cp-danger-ink",
                        children: i
                    }) : null]
                })
            }
            var p = n(6127),
                f = n(25250);
            let m = (0, s.default)(() => n.e(52999).then(n.bind(n, 52999)).then(e => e.WorldCharactersCard), {
                    loadableGenerated: {
                        webpack: () => [52999]
                    },
                    ssr: !1
                }),
                h = "rounded-2xl border border-cp-line/70 bg-cp-bg p-4 sm:p-5",
                x = "text-[15px] font-semibold tracking-[-0.01em] text-cp-ink";

            function g({
                template: e,
                doc: t,
                ctx: n,
                onPickLook: r,
                groupSlots: s,
                collapsible: a = !1
            }) {
                let u = (0, o.useMemo)(() => {
                    let l = e => ("sound" !== e.kind || n.sound) && ("copyPack" !== e.kind || n.commitOps);
                    return (0, p.ND)((0, p.Ix)(e, t), t).map(e => ({ ...e,
                        controls: e.controls.filter(l),
                        ...e.parts ? {
                            parts: e.parts.map(e => ({ ...e,
                                controls: e.controls.filter(l)
                            })).filter(e => e.controls.length > 0)
                        } : {}
                    })).filter(e => e.controls.length > 0)
                }, [e, t, n.sound, n.commitOps]);
                return (0, l.jsxs)("div", {
                    className: "flex flex-col gap-3",
                    children: [(0, p.lV)(e) ? (0, l.jsx)(w, {
                        template: e,
                        doc: t,
                        onPick: r,
                        title: (0, d.Gl)(n).pickLook
                    }) : null, Object.entries(s ? ? {}).filter(([e]) => !u.some(t => t.id === e)).map(([e, t]) => (0, l.jsx)(o.Fragment, {
                        children: t
                    }, `slot-${e}`)), u.map((e, t) => {
                        let r = s ? .[e.id];
                        if (r) return (0, l.jsx)(o.Fragment, {
                            children: r
                        }, e.id);
                        let d = `simple-group-${e.id}`;
                        return "worldCharacters" === e.widget ? (0, l.jsx)(m, {
                            title: e.title,
                            hint: e.hint,
                            controls: e.controls,
                            ctx: n
                        }, e.id) : e.controls.every(e => "field" === e.kind && e.field.field.cutout) ? (0, l.jsx)(k, {
                            title: e.title,
                            hint: e.hint,
                            controls: e.controls,
                            ctx: n
                        }, e.id) : e.collapsed || a ? (0, l.jsxs)("details", {
                            className: (0, c.cn)(h, "cp-smooth-details group/rest"),
                            open: a && 0 === t,
                            children: [(0, l.jsxs)("summary", {
                                className: "flex cursor-pointer list-none items-center justify-between gap-3 [&::-webkit-details-marker]:hidden",
                                children: [(0, l.jsx)("span", {
                                    className: x,
                                    children: e.title
                                }), (0, l.jsx)(i.A, {
                                    "aria-hidden": !0,
                                    className: "size-4 shrink-0 text-cp-muted transition-transform duration-300 group-open/rest:rotate-180 motion-reduce:transition-none"
                                })]
                            }), e.hint ? (0, l.jsx)("p", {
                                className: "mt-1 text-[13px] leading-5 text-cp-muted",
                                children: e.hint
                            }) : null, (0, l.jsx)(b, {
                                group: e,
                                ctx: n
                            })]
                        }, e.id) : (0, l.jsxs)("section", {
                            "aria-labelledby": d,
                            className: h,
                            children: [(0, l.jsx)("h3", {
                                id: d,
                                className: x,
                                children: e.title
                            }), e.hint ? (0, l.jsx)("p", {
                                className: "mt-1 text-[13px] leading-5 text-cp-muted",
                                children: e.hint
                            }) : null, (0, l.jsx)(b, {
                                group: e,
                                ctx: n
                            })]
                        }, e.id)
                    })]
                })
            }

            function b({
                group: e,
                ctx: t
            }) {
                let n = new Set(e.parts ? .flatMap(e => e.controls.map(e => e.key))),
                    i = e.controls.filter(e => !n.has(e.key));
                return (0, l.jsxs)("div", {
                    className: "mt-3.5 flex flex-col gap-4",
                    children: [i.map(e => (0, l.jsx)(v, {
                        control: e,
                        ctx: t
                    }, e.key)), e.parts ? .map(e => (0, l.jsx)(y, {
                        part: e,
                        ctx: t
                    }, e.key))]
                })
            }

            function y({
                part: e,
                ctx: t
            }) {
                let n = (0, d.Gl)(t),
                    i = e => "field" === e.kind && "image" === e.field.field.type,
                    r = e.controls.filter(i),
                    s = e.controls.filter(e => !i(e)),
                    o = e => e.map(e => (0, l.jsx)(v, {
                        control: e,
                        ctx: t
                    }, e.key));
                return (0, l.jsxs)("div", {
                    role: "group",
                    "aria-label": e.title,
                    className: "flex flex-col gap-3 border-t border-cp-line/70 pt-4",
                    children: [(0, l.jsxs)("div", {
                        children: [(0, l.jsx)("p", {
                            className: "text-[13px] font-semibold text-cp-ink",
                            children: e.title
                        }), e.hint ? (0, l.jsx)("p", {
                            className: "mt-0.5 text-[12px] leading-5 text-cp-muted",
                            children: e.hint
                        }) : null]
                    }), r.length > 0 && s.length > 0 ? (0, l.jsxs)("div", {
                        className: "grid grid-cols-[5.5rem_minmax(0,1fr)] gap-3 sm:grid-cols-[7rem_minmax(0,1fr)]",
                        children: [(0, l.jsx)("div", {
                            className: "flex flex-col gap-2",
                            children: r.map(i => "field" === i.kind ? (0, l.jsx)(d.nQ, {
                                field: i.field,
                                ctx: t,
                                shape: "square",
                                name: n.entryFieldLabel(e.title, i.field.label)
                            }, i.key) : null)
                        }), (0, l.jsx)("div", {
                            className: "flex min-w-0 flex-col gap-3",
                            children: o(s)
                        })]
                    }) : (0, l.jsx)("div", {
                        className: "flex flex-col gap-4",
                        children: o(e.controls)
                    })]
                })
            }

            function k({
                title: e,
                hint: t,
                controls: n,
                ctx: i
            }) {
                let [r, s] = (0, o.useState)(!1), c = (0, d.Gl)(i).characters, u = n.flatMap(e => "field" === e.kind && "section" === e.field.target.kind ? [{
                    pageId: e.field.target.pageId,
                    sectionId: e.field.target.sectionId,
                    field: e.field.field,
                    value: "string" == typeof e.field.value ? e.field.value : ""
                }] : []), p = e => ({
                    kind: "section",
                    pageId: e.pageId,
                    sectionId: e.sectionId,
                    fieldId: e.field.id
                });
                return (0, l.jsxs)("section", {
                    className: h,
                    children: [(0, l.jsx)("h3", {
                        className: x,
                        children: e
                    }), t ? (0, l.jsx)("p", {
                        className: "mt-1 text-[13px] leading-5 text-cp-muted",
                        children: t
                    }) : null, (0, l.jsx)(a.hG, {
                        words: c,
                        onClick: () => s(!0),
                        className: "mt-3.5 w-full"
                    }), (0, l.jsx)(a.jn, {
                        open: r,
                        onClose: () => s(!1),
                        slots: u,
                        resolve: e => i.resolveAsset(e) ? ? "",
                        upload: (e, t) => i.upload(t, p(e)),
                        commit: (e, t) => i.commit(p(e), t),
                        words: c
                    })]
                })
            }

            function v({
                control: e,
                ctx: t
            }) {
                if ("field" === e.kind) return (0, l.jsx)(j, {
                    field: e.field,
                    ctx: t
                });
                if ("sound" === e.kind) return t.sound ? (0, l.jsx)(f.R, {
                    control: e,
                    ctx: t.sound,
                    resolveAsset: t.resolveAsset,
                    copy: (0, d.Gl)(t)
                }) : null;
                if ("copyPack" === e.kind) return (0, l.jsx)(u, {
                    control: e,
                    ctx: t
                });
                let n = (0, d.Gl)(t),
                    i = e.entries.every(e => e.fields.every(e => "image" !== e.field.type));
                return (0, l.jsxs)("div", {
                    className: "flex flex-col gap-2",
                    children: [(0, l.jsx)("p", {
                        className: "text-[12px] font-medium text-cp-ink",
                        children: e.label
                    }), e.hint ? (0, l.jsx)("p", {
                        className: "-mt-1 text-[12px] text-cp-muted",
                        children: e.hint
                    }) : null, (0, l.jsx)("ul", {
                        className: i ? "flex flex-col gap-2" : "grid grid-cols-3 gap-2",
                        children: e.entries.map(e => {
                            let r = i && e.fields.length > 1;
                            return (0, l.jsxs)("li", {
                                className: r ? "flex min-w-0 flex-col gap-2.5 rounded-2xl border border-cp-line p-3" : "flex min-w-0 flex-col gap-1.5",
                                "aria-label": n.entryLabel(e.itemLabel, e.position),
                                children: [r ? (0, l.jsx)("p", {
                                    className: "text-[12px] font-semibold text-cp-ink",
                                    children: n.entryLabel(e.itemLabel, e.position)
                                }) : null, e.fields.map(i => "image" === i.field.type ? (0, l.jsx)(d.nQ, {
                                    field: i,
                                    ctx: t,
                                    shape: "square",
                                    name: n.entryFieldLabel(n.entryLabel(e.itemLabel, e.position), i.label)
                                }, i.key) : "boolean" === i.field.type ? (0, l.jsx)(d.IY, {
                                    field: i,
                                    ctx: t
                                }, i.key) : (0, l.jsx)(d.hj, {
                                    field: r ? i : { ...i,
                                        label: n.entryFieldLabel(n.entryLabel(e.itemLabel, e.position), i.label)
                                    },
                                    ctx: t,
                                    compact: !r
                                }, i.key))]
                            }, e.itemId)
                        })
                    })]
                })
            }

            function j({
                field: e,
                ctx: t
            }) {
                return "image" === e.field.type ? (0, l.jsx)(d.nQ, {
                    field: e,
                    ctx: t
                }) : "boolean" === e.field.type ? (0, l.jsx)(d.IY, {
                    field: e,
                    ctx: t
                }) : e.field.options ? (0, l.jsx)(d.BN, {
                    field: e,
                    ctx: t
                }) : (0, l.jsx)(d.hj, {
                    field: e,
                    ctx: t
                })
            }

            function w({
                template: e,
                doc: t,
                onPick: n,
                title: i
            }) {
                let r = (0, p.zr)(e, t.theme),
                    s = (0, o.useRef)(null),
                    a = (0, o.useRef)([]),
                    d = e.presets,
                    u = d.findIndex(e => e.id === r),
                    f = Math.max(0, u),
                    m = u >= 0 ? d[u].label : null;
                return (0, o.useEffect)(() => {
                    let e = s.current,
                        t = u >= 0 ? a.current[u] : null;
                    if (!e || !t) return;
                    let n = t.offsetLeft - e.offsetLeft;
                    (n < e.scrollLeft || n + t.offsetWidth > e.scrollLeft + e.clientWidth) && e.scrollTo({
                        left: Math.max(0, n - (e.clientWidth - t.offsetWidth) / 2)
                    })
                }, [u]), (0, l.jsxs)("section", {
                    "aria-labelledby": "simple-looks",
                    className: "rounded-2xl border border-cp-line/70 bg-cp-bg px-4 pt-3.5 pb-2.5 sm:px-5",
                    children: [(0, l.jsxs)("div", {
                        className: "flex items-baseline justify-between gap-3",
                        children: [(0, l.jsx)("h3", {
                            id: "simple-looks",
                            className: "text-[14px] font-semibold tracking-[-0.01em] text-cp-ink",
                            children: i
                        }), m ? (0, l.jsx)("span", {
                            "aria-hidden": !0,
                            className: "truncate text-[12px] text-cp-muted",
                            children: m
                        }) : null]
                    }), (0, l.jsx)("div", {
                        ref: s,
                        role: "radiogroup",
                        "aria-labelledby": "simple-looks",
                        onKeyDown: e => {
                            if (!["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp", "Home", "End"].includes(e.key) || 0 === d.length) return;
                            e.preventDefault();
                            let t = Math.max(0, a.current.findIndex(e => e === document.activeElement)),
                                l = "Home" === e.key ? 0 : "End" === e.key ? d.length - 1 : (t + ("ArrowRight" === e.key || "ArrowDown" === e.key ? 1 : -1) + d.length) % d.length;
                            n(d[l].id), a.current[l] ? .focus({
                                preventScroll: !0
                            })
                        },
                        className: "-mx-1 mt-2.5 flex snap-x snap-mandatory scroll-px-1 gap-2 overflow-x-auto pt-1 pr-2 pb-1.5 pl-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
                        children: d.map((t, i) => {
                            let s = t.id === r;
                            return (0, l.jsxs)("button", {
                                ref: e => {
                                    a.current[i] = e
                                },
                                type: "button",
                                role: "radio",
                                "aria-checked": s,
                                "aria-label": t.label,
                                title: t.label,
                                tabIndex: i === f ? 0 : -1,
                                onClick: () => n(t.id),
                                className: (0, c.cn)("group flex w-16 shrink-0 snap-start flex-col items-center gap-1.5 rounded-xl pt-0.5 pb-0.5 text-center", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select"),
                                children: [(0, l.jsx)(N, {
                                    swatches: (0, p.Q0)(e, t),
                                    selected: s
                                }), (0, l.jsx)("span", {
                                    "aria-hidden": !0,
                                    className: (0, c.cn)("line-clamp-2 w-full text-[11px] leading-tight transition-colors duration-150 motion-reduce:transition-none", s ? "font-semibold text-cp-ink" : "text-cp-muted group-hover:text-cp-ink"),
                                    children: t.label
                                })]
                            }, t.id)
                        })
                    })]
                })
            }

            function N({
                swatches: e,
                selected: t
            }) {
                let [n, i = n, s = i] = e, o = e => e ? {
                    backgroundColor: e
                } : {};
                return (0, l.jsxs)("span", {
                    "aria-hidden": !0,
                    className: "relative block size-14 shrink-0",
                    children: [(0, l.jsxs)("span", {
                        className: (0, c.cn)("absolute inset-0 overflow-hidden rounded-2xl bg-cp-subtle transition-shadow duration-150 motion-reduce:transition-none", t ? "ring-2 ring-cp-select ring-offset-2 ring-offset-cp-bg" : "ring-1 ring-cp-ink/10 group-hover:ring-cp-ink/25"),
                        style: o(n),
                        children: [(0, l.jsx)("span", {
                            className: "absolute -right-3 -bottom-3 size-10 rounded-full",
                            style: o(i)
                        }), (0, l.jsx)("span", {
                            className: "absolute top-3 left-2.5 h-1.5 w-6 rounded-full",
                            style: o(s)
                        }), (0, l.jsx)("span", {
                            className: "absolute top-[22px] left-2.5 h-1 w-4 rounded-full opacity-60",
                            style: o(s)
                        })]
                    }), t ? (0, l.jsx)("span", {
                        className: "absolute -top-1.5 -right-1.5 flex size-[18px] items-center justify-center rounded-full bg-cp-primary text-white shadow-[0_1px_3px_rgba(20,12,60,0.25)]",
                        children: (0, l.jsx)(r.A, {
                            className: "size-3",
                            strokeWidth: 3
                        })
                    }) : null]
                })
            }
        },
        17701: (e, t, n) => {
            n.d(t, {
                EH: () => f,
                HJ: () => u,
                N5: () => c,
                eb: () => d,
                r9: () => p
            });
            var l = n(51801),
                i = n(70704),
                r = n(47060);
            let s = "cp_guest_draft_shelf_v1:";

            function o() {
                try {
                    return window.localStorage
                } catch {
                    return null
                }
            }

            function a(e) {
                return `${s}${e}`
            }

            function c(e, t = Date.now()) {
                let n = o();
                if (!n) return {
                    ok: !1,
                    reason: "unavailable"
                };
                let l = { ...e,
                    version: 1,
                    updatedAt: t
                };
                try {
                    return n.setItem(a(e.templateSlug), JSON.stringify(l)), {
                        ok: !0
                    }
                } catch {
                    return {
                        ok: !1,
                        reason: "quota"
                    }
                }
            }

            function d(e, t = Date.now()) {
                let n, l, i = o();
                if (!i) return null;
                try {
                    n = i.getItem(a(e))
                } catch {
                    return null
                }
                if (!n) return null;
                try {
                    l = JSON.parse(n)
                } catch {
                    return u(e), null
                }
                return !(0, r.iB)(l) || l.templateSlug !== e || t - l.updatedAt > r.jM ? (u(e), null) : l
            }

            function u(e) {
                let t = o();
                if (t) try {
                    t.removeItem(a(e))
                } catch {}
            }

            function p(e, t = Date.now()) {
                let n = (0, r.wU)(t);
                return n ? .templateSlug === e ? n : d(e, t)
            }
            async function f(e, {
                exceptActiveSlot: t = !1
            } = {}) {
                if (e) try {
                    let n = (0, l.ri)(e.draftContent);
                    if (0 === n.length) return;
                    let a = function({
                        includeActive: e
                    }) {
                        let t = function(e = Date.now()) {
                            let t = o();
                            if (!t) return [];
                            let n = [];
                            try {
                                for (let e = 0; e < t.length; e += 1) {
                                    let l = t.key(e);
                                    l ? .startsWith(s) && n.push(l.slice(s.length))
                                }
                            } catch {
                                return []
                            }
                            return n.map(t => d(t, e)).filter(e => null !== e)
                        }();
                        if (e) {
                            let e = (0, r.wU)();
                            e && t.push(e)
                        }
                        return new Set(t.flatMap(e => (0, l.ri)(e.draftContent)))
                    }({
                        includeActive: !t
                    });
                    await Promise.all(n.filter(e => !a.has(e)).map(e => (0, i.qf)(e)))
                } catch {}
            }
        },
        25250: (e, t, n) => {
            n.d(t, {
                R: () => g
            });
            var l = n(73365),
                i = n(60895),
                r = n(7303),
                s = n(71192),
                o = n(26821),
                a = n(61798),
                c = n(1521),
                d = n(87404),
                u = n(2572),
                p = n(54872),
                f = n(89503),
                m = n(6127);
            let h = [{
                    badge: "bg-orange-100 text-orange-600",
                    badgeOn: "bg-orange-500 text-white",
                    row: "border-orange-200 bg-orange-50/60 hover:bg-orange-50",
                    rowOn: "border-orange-500 bg-orange-50 ring-1 ring-orange-500",
                    check: "text-orange-600",
                    play: "bg-orange-500 hover:bg-orange-600"
                }, {
                    badge: "bg-rose-100 text-rose-600",
                    badgeOn: "bg-rose-500 text-white",
                    row: "border-rose-200 bg-rose-50/60 hover:bg-rose-50",
                    rowOn: "border-rose-500 bg-rose-50 ring-1 ring-rose-500",
                    check: "text-rose-600",
                    play: "bg-rose-500 hover:bg-rose-600"
                }, {
                    badge: "bg-sky-100 text-sky-600",
                    badgeOn: "bg-sky-500 text-white",
                    row: "border-sky-200 bg-sky-50/60 hover:bg-sky-50",
                    rowOn: "border-sky-500 bg-sky-50 ring-1 ring-sky-500",
                    check: "text-sky-600",
                    play: "bg-sky-500 hover:bg-sky-600"
                }],
                x = e => h[e % h.length];

            function g({
                control: e,
                ctx: t,
                resolveAsset: n,
                copy: h = f.ur
            }) {
                let b = h.song,
                    {
                        sound: y,
                        defaultSound: k,
                        songs: v
                    } = e,
                    j = (0, m.Hx)(y, k, v),
                    w = v.length > 1,
                    N = w ? v.findIndex(e => e.src === y ? .src) : -1,
                    I = N >= 0 ? x(N) : null,
                    S = y ? .src ? n(y.src) : null,
                    A = (0, c.useRef)(null),
                    C = (0, c.useRef)(null),
                    [$, P] = (0, c.useState)(!1),
                    [z, L] = (0, c.useState)(!1),
                    [R, O] = (0, c.useState)(null),
                    M = (0, c.useId)();
                (0, c.useEffect)(() => {
                    let e = A.current;
                    return () => {
                        e ? .pause()
                    }
                }, [S]);
                let E = "none" === j ? b.noMusic : y ? .title ? .trim() || ("default" === j ? b.defaultSong : b.yourSong),
                    F = "custom" === j && y ? .src ? t.sizeOf ? .(y.src) ? ? null : null,
                    W = "default" === j ? b.captionDefault : "custom" === j ? null !== F ? `${b.captionCustom} \xb7 ${b.size(F)}` : b.captionCustom : b.captionNone,
                    _ = (e, n) => {
                        O(t.commit(e) ? null : n)
                    },
                    B = async (e, t) => {
                        L(!0), O(null);
                        try {
                            let n = await e();
                            if (!n) return;
                            if (!n.ok) return void O(n.message);
                            let l = (0, u.r0)(t, 120) || b.fallbackTitle;
                            _((0, m.mC)(y, k, n.url, l), b.cannotUse)
                        } finally {
                            L(!1), C.current && (C.current.value = "")
                        }
                    },
                    T = async e => {
                        e && await B(() => t.upload(e), e.name)
                    },
                    D = t.pick,
                    U = D ? () => void B(D, "") : () => C.current ? .click();
                return (0, l.jsxs)("div", {
                    className: "flex flex-col gap-3",
                    children: [(0, l.jsxs)("div", {
                        className: "flex items-center gap-3 rounded-xl bg-cp-subtle p-3",
                        children: [S ? (0, l.jsx)("button", {
                            type: "button",
                            onClick: () => {
                                let e = A.current;
                                if (e) {
                                    if (!e.paused) return void e.pause();
                                    for (let t of Array.from(document.querySelectorAll("audio"))) t !== e && t.pause();
                                    e.play().catch(() => {
                                        P(!1), O(b.cannotPlay)
                                    })
                                }
                            },
                            "aria-label": $ ? b.pause(E) : b.play(E),
                            "aria-pressed": $,
                            className: (0, p.cn)("flex size-11 shrink-0 items-center justify-center rounded-full text-white", "transition-colors duration-150 motion-reduce:transition-none", I ? I.play : "bg-cp-primary hover:bg-cp-primary-hover", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select"),
                            children: $ ? (0, l.jsx)(i.A, {
                                className: "size-4",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            }) : (0, l.jsx)(r.A, {
                                className: "size-4 translate-x-px",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            })
                        }) : (0, l.jsx)("span", {
                            "aria-hidden": !0,
                            className: "flex size-11 shrink-0 items-center justify-center rounded-full bg-cp-bg text-cp-muted",
                            children: (0, l.jsx)(s.A, {
                                className: "size-4",
                                strokeWidth: 1.75
                            })
                        }), (0, l.jsxs)("div", {
                            className: "min-w-0",
                            children: [(0, l.jsx)("p", {
                                className: "truncate text-[14px] font-medium text-cp-ink",
                                children: E
                            }), (0, l.jsx)("p", {
                                className: "text-[12px] text-cp-muted",
                                children: W
                            })]
                        }), S ? (0, l.jsx)("audio", {
                            ref: A,
                            src: S,
                            preload: "none",
                            onPlay: () => P(!0),
                            onPause: () => P(!1),
                            onEnded: () => P(!1)
                        }) : null]
                    }), w ? (0, l.jsxs)("div", {
                        role: "group",
                        "aria-label": b.pickSong,
                        className: "flex flex-col gap-1.5",
                        children: [(0, l.jsx)("p", {
                            className: "text-[12px] font-medium text-cp-muted",
                            children: b.pickSong
                        }), v.map((e, t) => {
                            let n = y ? .src === e.src,
                                i = x(t);
                            return (0, l.jsxs)("button", {
                                type: "button",
                                "aria-pressed": n,
                                onClick: () => {
                                    n || _((0, m.wA)(y, e), b.cannotSwitchBack)
                                },
                                className: (0, p.cn)("flex min-h-12 items-center gap-3 rounded-xl border px-2.5 py-2 text-left text-[14px] text-cp-ink", "transition-colors duration-150 motion-reduce:transition-none", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", n ? i.rowOn : i.row),
                                children: [(0, l.jsx)("span", {
                                    "aria-hidden": !0,
                                    className: (0, p.cn)("flex size-8 shrink-0 items-center justify-center rounded-lg transition-colors duration-150 motion-reduce:transition-none", n ? i.badgeOn : i.badge),
                                    children: (0, l.jsx)(s.A, {
                                        className: "size-4",
                                        strokeWidth: 2
                                    })
                                }), (0, l.jsx)("span", {
                                    className: (0, p.cn)("min-w-0 flex-1 truncate", n && "font-medium"),
                                    children: e.title
                                }), n ? (0, l.jsx)(o.A, {
                                    "aria-hidden": !0,
                                    className: (0, p.cn)("size-4 shrink-0", i.check),
                                    strokeWidth: 2.5
                                }) : null]
                            }, e.src)
                        })]
                    }) : null, (0, l.jsxs)("div", {
                        className: "flex flex-wrap gap-2",
                        children: [(0, l.jsx)(d.$n, {
                            type: "button",
                            variant: "secondary",
                            size: "sm",
                            loading: z,
                            iconLeading: (0, l.jsx)(a.A, {
                                strokeWidth: 1.75,
                                "aria-hidden": !0
                            }),
                            "aria-describedby": M,
                            onClick: U,
                            children: z ? b.uploading : b.upload
                        }), k && !w && "default" !== j ? (0, l.jsx)(d.$n, {
                            type: "button",
                            variant: "ghost",
                            size: "sm",
                            onClick: () => _((0, m.wA)(y, k), b.cannotSwitchBack),
                            children: b.useDefault
                        }) : null, "none" !== j ? (0, l.jsx)(d.$n, {
                            type: "button",
                            variant: "ghost",
                            size: "sm",
                            onClick: () => _((0, m.gp)(y), b.cannotRemove),
                            children: b.removeSong
                        }) : null]
                    }), (0, l.jsxs)("p", {
                        id: M,
                        className: "-mt-1 text-[12px] text-cp-muted",
                        children: [e.hint ? `${e.hint} ` : "", t.limits ? ? ""]
                    }), R ? (0, l.jsx)("p", {
                        role: "alert",
                        className: "text-[12px] text-cp-danger-ink",
                        children: R
                    }) : null, (0, l.jsx)("input", {
                        ref: C,
                        type: "file",
                        accept: t.accept,
                        className: "hidden",
                        tabIndex: -1,
                        "aria-hidden": !0,
                        onChange: e => void T(e.target.files ? .[0])
                    })]
                })
            }
        },
        32104: (e, t, n) => {
            n.d(t, {
                P: () => o
            });
            var l = n(73365),
                i = n(1521),
                r = n(94296);
            let s = (0, r.RA)();

            function o({
                fluid: e
            } = {}) {
                let t = e ? r.Pm / e * 100 + "% auto" : r.Pm + "px " + r.WH + "px",
                    n = e ? "center top 10px" : "center top 20px",
                    a = (0, i.useRef)(null);
                return (0, i.useEffect)(() => {
                    let e = a.current;
                    if (!e) return;
                    let l = () => {
                        let l = e.querySelector("[data-wm-tile]");
                        l || ((l = e.ownerDocument.createElement("div")).setAttribute("data-wm-tile", ""), e.appendChild(l));
                        let i = l.style;
                        i.setProperty("position", "absolute", "important"), i.setProperty("inset", "0", "important"), i.setProperty("display", "block", "important"), i.setProperty("visibility", "visible", "important"), i.setProperty("opacity", "1", "important"), i.setProperty("pointer-events", "none", "important"), i.setProperty("background-image", s, "important"), i.setProperty("background-repeat", "no-repeat", "important"), i.setProperty("background-position", n, "important"), i.setProperty("background-size", t, "important");
                        let r = e.style;
                        r.setProperty("display", "block", "important"), r.setProperty("visibility", "visible", "important"), r.setProperty("opacity", "1", "important")
                    };
                    l();
                    let i = new MutationObserver(l);
                    i.observe(e, {
                        childList: !0,
                        subtree: !0,
                        attributes: !0,
                        attributeFilter: ["style", "class", "hidden"]
                    });
                    let r = e.parentElement,
                        o = null;
                    return r && (o = new MutationObserver(() => {
                        e.isConnected || r.appendChild(e), l()
                    })).observe(r, {
                        childList: !0
                    }), () => {
                        i.disconnect(), o ? .disconnect()
                    }
                }, [t, n]), (0, l.jsx)("div", {
                    ref: a,
                    "aria-hidden": !0,
                    "data-wm": "",
                    className: "pointer-events-none absolute inset-0 z-20 select-none",
                    children: (0, l.jsx)("div", {
                        "data-wm-tile": "",
                        className: "absolute inset-0",
                        style: {
                            backgroundImage: s,
                            backgroundRepeat: "no-repeat",
                            backgroundPosition: n,
                            backgroundSize: t
                        }
                    })
                })
            }
        },
        47060: (e, t, n) => {
            n.d(t, {
                iB: () => u,
                jC: () => c,
                jM: () => i,
                l2: () => d,
                lH: () => o,
                nw: () => s,
                wU: () => a
            });
            let l = "cp_guest_draft_v1",
                i = 2592e6;

            function r() {
                try {
                    return window.localStorage
                } catch {
                    return null
                }
            }

            function s() {
                let e = r();
                if (!e) return !1;
                try {
                    let t = "__cp_probe__";
                    return e.setItem(t, "1"), e.removeItem(t), !0
                } catch {
                    return !1
                }
            }

            function o(e, t = Date.now()) {
                let n = r();
                if (!n) return {
                    ok: !1,
                    reason: "unavailable"
                };
                let i = { ...e,
                    version: 1,
                    updatedAt: t
                };
                try {
                    return n.setItem(l, JSON.stringify(i)), {
                        ok: !0
                    }
                } catch {
                    return {
                        ok: !1,
                        reason: "quota"
                    }
                }
            }

            function a(e = Date.now()) {
                let t, n, s = r();
                if (!s) return null;
                try {
                    t = s.getItem(l)
                } catch {
                    return null
                }
                if (!t) return null;
                try {
                    n = JSON.parse(t)
                } catch {
                    return d(), null
                }
                return !u(n) || e - n.updatedAt > i ? (d(), null) : n
            }

            function c(e, t = Date.now()) {
                let n = a(t);
                return n && n.templateSlug === e ? n : null
            }

            function d(e) {
                let t = r();
                if (t) try {
                    if (void 0 !== e && a() ? .templateSlug !== e) return;
                    t.removeItem(l)
                } catch {}
            }

            function u(e) {
                return !!e && "object" == typeof e && 1 === e.version && "string" == typeof e.templateSlug && e.templateSlug.length > 0 && "string" == typeof e.templateVersionId && "string" == typeof e.name && "number" == typeof e.updatedAt && Number.isFinite(e.updatedAt) && "object" == typeof e.draftContent && null !== e.draftContent
            }
        },
        49688: (e, t, n) => {
            n.d(t, {
                CU: () => o,
                Dk: () => s,
                cE: () => i,
                rG: () => l,
                vV: () => r
            });
            let l = 2560,
                i = 2621440,
                r = [.82, .72, .62, .5],
                s = 0xa00000,
                o = 0x2800000
        },
        50762: (e, t, n) => {
            n.d(t, {
                hM: () => v,
                Ih: () => a,
                lw: () => w.lw,
                dh: () => j.dh,
                mc: () => j.mc,
                gl: () => d,
                xw: () => j.xw,
                Ix: () => j.Ix,
                Rl: () => c,
                HS: () => w.HS,
                Zh: () => w.Zh,
                BL: () => j.BL,
                gS: () => I,
                LQ: () => S
            });
            var l = n(85319),
                i = n(51801),
                r = n(47060),
                s = n(17701),
                o = n(69177);
            let a = {
                allowAssetRef: i.wn
            };

            function c(e, t) {
                if (!e) return null;
                let n = (0, o.aH)(e.draftContent);
                if (!n || n.template !== t.key) return null;
                let r = (0, l.mv)(n, t, {
                    allowAssetRef: i.wn
                });
                return r.ok ? (0, l.ES)(t, r.doc) : null
            }

            function d(e, t, n) {
                let l = {
                        templateSlug: e.templateSlug,
                        templateVersionId: e.templateVersionId,
                        name: n,
                        draftContent: (0, o.K0)(t),
                        themeTokens: {}
                    },
                    i = (0, r.lH)(l);
                return !i.ok && "unavailable" === i.reason || !!i.ok && (0, s.N5)(l).ok
            }
            n(5438);
            var u = n(73365),
                p = n(1521);
            n(64033);
            var f = n(32104),
                m = n(34768),
                h = n(82161),
                x = n(36254),
                g = n(54872),
                b = n(25200),
                y = n(37609),
                k = n(17082);
            let v = (0, p.memo)(function({
                template: e,
                doc: t,
                resolveAsset: n,
                inviteeName: l = null,
                focusSectionId: i = null,
                label: r,
                className: s,
                screenClassName: o,
                watermark: a = !0,
                deviceWidth: c = 390
            }) {
                let d = (0, p.useRef)(null),
                    v = (0, p.useRef)(null),
                    j = (0, p.useRef)(null),
                    [w, N] = (0, p.useState)(null),
                    [I, S] = (0, p.useState)(null),
                    A = (0, y.sM)(t);
                (0, p.useEffect)(() => {
                    let e = j.current;
                    if (!e) return;
                    let t = () => {
                        let {
                            width: t,
                            height: n
                        } = e.getBoundingClientRect();
                        t > 0 && n > 0 && S({
                            width: t,
                            height: n
                        })
                    };
                    t();
                    let n = new ResizeObserver(t);
                    return n.observe(e), () => n.disconnect()
                }, []);
                let C = I ? I.width / c : 1;
                return (0, p.useEffect)(() => {
                    if (!i) return;
                    let e = d.current,
                        t = v.current;
                    if (!e || !t) return;
                    let n = e.getBoundingClientRect();
                    if (n.top < 0 || n.bottom > window.innerHeight) return;
                    t.scrollTop = 0;
                    let l = setTimeout(() => N(i), 0);
                    return () => clearTimeout(l)
                }, [i]), (0, u.jsxs)("div", {
                    ref: d,
                    role: "region",
                    "aria-label": r,
                    className: (0, g.cn)("relative isolate rounded-3xl bg-cp-ink p-2.5 shadow-[0_24px_60px_-20px_rgba(20,12,60,0.45)]", s),
                    children: [(0, u.jsx)("div", {
                        ref: j,
                        className: (0, g.cn)("relative overflow-hidden rounded-2xl bg-cp-bg", o),
                        children: (0, u.jsx)("div", {
                            ref: v,
                            className: (0, g.cn)("no-scrollbar overflow-x-hidden overflow-y-auto overscroll-contain bg-cp-bg", x.x),
                            style: I ? {
                                width: c,
                                height: I.height / C,
                                transform: `scale(${C})`,
                                transformOrigin: "top left"
                            } : {
                                width: "100%",
                                height: "100%"
                            },
                            children: (0, u.jsx)(k.InviteeNameProvider, {
                                name: l,
                                children: (0, u.jsx)(h.FolioPreviewSound, {
                                    children: (0, u.jsx)(y.OQ, {
                                        css: A,
                                        logic: t.logic,
                                        logicEnabled: !0,
                                        builder: e.key === b.$_,
                                        children: (0, u.jsx)(m.FolioRenderer, {
                                            template: e,
                                            document: t,
                                            mode: "preview",
                                            resolveAsset: n,
                                            storyFocus: w,
                                            className: "min-h-full"
                                        })
                                    })
                                })
                            })
                        })
                    }), a ? (0, u.jsx)("div", {
                        className: "pointer-events-none absolute inset-2.5 overflow-hidden rounded-2xl",
                        children: (0, u.jsx)(f.P, {
                            fluid: c
                        })
                    }) : null]
                })
            });
            n(25250);
            var j = n(6127),
                w = n(7368),
                N = n(70704);

            function I(e) {
                let [t, n] = (0, p.useState)(() => new Map), l = (0, p.useRef)(new Map), r = (0, p.useRef)([]), s = (0, p.useRef)(new Set), a = (0, p.useRef)(!0), c = (0, p.useCallback)((e, t) => {
                    l.current.set(e, t.size);
                    let i = URL.createObjectURL(t);
                    r.current.push(i), s.current.add(e), n(t => new Map(t).set(e, i))
                }, []);
                return (0, p.useEffect)(() => {
                    let t = (0, i.ri)((0, o.K0)(e)).map(e => [e, (0, i.BI)(e)]).filter(([, e]) => !s.current.has(e));
                    for (let [, e] of t) s.current.add(e);
                    Promise.all(t.map(async ([e, t]) => {
                        let i = await (0, N.LW)(e);
                        if (!a.current || !i) return;
                        l.current.set(t, i.blob.size);
                        let s = URL.createObjectURL(i.blob);
                        r.current.push(s), n(e => new Map(e).set(t, s))
                    }))
                }, [e]), (0, p.useEffect)(() => {
                    a.current = !0;
                    let e = r.current;
                    return () => {
                        a.current = !1, e.forEach(e => URL.revokeObjectURL(e))
                    }
                }, []), {
                    resolveAsset: (0, p.useCallback)(e => (0, i.wn)(e) ? t.get(e) ? ? null : e, [t]),
                    remember: c,
                    sizeOf: (0, p.useCallback)(e => t.has(e) ? l.current.get(e) ? ? null : null, [t])
                }
            }

            function S({
                template: e,
                defaultDocument: t,
                identity: n,
                defaultName: l
            }) {
                let [i, r] = (0, p.useState)(t), [o, u] = (0, p.useState)(!1), [f, m] = (0, p.useState)("idle"), h = (0, p.useRef)(i), x = (0, p.useRef)(l), g = (0, p.useRef)(!1), b = (0, p.useRef)(null), y = (0, p.useRef)(n);
                (0, p.useEffect)(() => {
                    y.current = n
                }, [n]), (0, p.useEffect)(() => {
                    let t = (0, s.r9)(y.current.templateSlug),
                        n = c(t, e),
                        l = setTimeout(() => {
                            t ? .name && (x.current = t.name), n && (h.current = n, r(n)), u(!0)
                        }, 0);
                    return () => clearTimeout(l)
                }, [e]);
                let k = (0, p.useCallback)(() => {
                        b.current && (clearTimeout(b.current), b.current = null);
                        let e = d(y.current, h.current, x.current);
                        return g.current = !e, m(e ? "saved" : "error"), e
                    }, []),
                    v = (0, p.useCallback)(() => {
                        g.current = !0, b.current && clearTimeout(b.current), b.current = setTimeout(() => {
                            b.current = null, k()
                        }, 400)
                    }, [k]),
                    w = (0, p.useCallback)(t => {
                        let n = (0, j.dh)(h.current, e, t, a);
                        return !!n && (h.current = n, r(n), v(), !0)
                    }, [e, v]),
                    N = (0, p.useCallback)((e, t) => {
                        t && (x.current = t), h.current = e, g.current = !1, r(e)
                    }, []);
                return (0, p.useEffect)(() => {
                    let e = () => {
                            g.current && k()
                        },
                        t = () => {
                            "hidden" === document.visibilityState && e()
                        };
                    return window.addEventListener("pagehide", e), document.addEventListener("visibilitychange", t), () => {
                        window.removeEventListener("pagehide", e), document.removeEventListener("visibilitychange", t), e()
                    }
                }, [k]), {
                    doc: i,
                    restored: o,
                    saveState: f,
                    apply: w,
                    adopt: N,
                    flush: k,
                    docRef: h,
                    nameRef: x
                }
            }
        },
        51801: (e, t, n) => {
            n.d(t, {
                BI: () => i,
                TP: () => c,
                nj: () => d,
                qG: () => s,
                ri: () => o,
                tM: () => l,
                wn: () => r
            });
            let l = "guest-asset:";

            function i(e) {
                return `${l}${e}`
            }

            function r(e) {
                return "string" == typeof e && e.startsWith(l)
            }

            function s(e) {
                return e.slice(l.length)
            }

            function o(e) {
                let t = [];
                if (!e || "object" != typeof e) return t;
                if ("folio" === e.engine) return u(e.document, e => (r(e) && t.push(s(e)), e)), t;
                let n = e.sections;
                if (!Array.isArray(n)) return t;
                for (let e of n) {
                    if (!e || "object" != typeof e) continue;
                    let n = e.values;
                    if (n && "object" == typeof n)
                        for (let e of Object.values(n)) {
                            if (r(e)) {
                                t.push(s(e));
                                continue
                            }
                            for (let n of a(e)) r(n.src) && t.push(s(n.src))
                        }
                }
                return t
            }

            function a(e) {
                if ("string" != typeof e) return [];
                let t = e.trim();
                if (!t.startsWith("[")) return [];
                try {
                    let e = JSON.parse(t);
                    if (!Array.isArray(e)) return [];
                    return e.filter(e => !!e && "object" == typeof e && "string" == typeof e.src)
                } catch {
                    return []
                }
            }

            function c(e, t) {
                if (!e || "object" != typeof e) return e;
                if ("folio" === e.engine) {
                    if (!e.document || "object" != typeof e.document) return e;
                    let n = structuredClone(e.document);
                    return u(n, e => r(e) ? t[s(e)] ? ? e : e), { ...e,
                        document: n
                    }
                }
                return Array.isArray(e.sections) ? { ...e,
                    sections: e.sections.map(e => {
                        if (!e || "object" != typeof e) return e;
                        let n = e.values;
                        if (!n || "object" != typeof n) return e;
                        let l = {};
                        for (let [e, i] of Object.entries(n)) {
                            if (r(i)) {
                                let n = t[s(i)];
                                l[e] = n ? ? i;
                                continue
                            }
                            let n = a(i);
                            if (n.length > 0) {
                                let i = n.map(e => r(e.src) ? { ...e,
                                    src: t[s(e.src)] ? ? e.src
                                } : e);
                                l[e] = JSON.stringify(i);
                                continue
                            }
                            l[e] = i
                        }
                        return { ...e,
                            values: l
                        }
                    })
                } : e
            }

            function d(e, t) {
                return "sound" === e ? t ? `folio/sound@${t}` : "folio/sound" : `folio/${e.sectionId}/${e.itemId??"-"}/${e.fieldId}`
            }

            function u(e, t) {
                if (!e || "object" != typeof e) return;
                let n = e => {
                        if (e && "object" == typeof e)
                            for (let [n, l] of Object.entries(e)) "string" == typeof l && (e[n] = t(l))
                    },
                    l = e => {
                        n(e.values);
                        let t = e.items;
                        if (Array.isArray(t))
                            for (let e of t) e && "object" == typeof e && n(e.values)
                    };
                if (Array.isArray(e.pages))
                    for (let t of e.pages) {
                        let e = t ? .sections;
                        if (Array.isArray(e))
                            for (let t of e) {
                                if (!t || "object" != typeof t) continue;
                                n(t.values);
                                let e = t.elements;
                                if (Array.isArray(e))
                                    for (let t of e) t && "object" == typeof t && l(t);
                                let i = t.stacks;
                                if (i && "object" == typeof i) {
                                    for (let e of Object.values(i))
                                        if (Array.isArray(e))
                                            for (let t of e) t && "object" == typeof t && l(t)
                                }
                            }
                    }
                if (e.sound && "object" == typeof e.sound) {
                    let n = e.sound;
                    "string" == typeof n.src && (n.src = t(n.src))
                }
            }
        },
        69177: (e, t, n) => {
            n.d(t, {
                K0: () => s,
                aH: () => o
            });
            var l = n(19071),
                i = n(1533);
            let r = l.Ik({
                engine: l.eu("folio"),
                document: i.Wq,
                sections: l.YO(l.Zm()).max(0).default([])
            });

            function s(e) {
                return {
                    engine: "folio",
                    document: e,
                    sections: []
                }
            }

            function o(e) {
                if (!(e && "object" == typeof e && !Array.isArray(e) && "folio" === e.engine)) return null;
                let t = r.safeParse(e);
                return t.success ? t.data.document : null
            }
        },
        70704: (e, t, n) => {
            n.d(t, {
                $n: () => c,
                Ai: () => o,
                Gz: () => p,
                LW: () => a,
                _G: () => i,
                qf: () => d,
                tu: () => r
            });
            let l = "assets";

            function i(e, t) {
                return `${t}@${e}`
            }

            function r(e) {
                return e.kind ? e.kind : e.blob.type.startsWith("audio/") || e.fileName.toLowerCase().endsWith(".mp3") ? "audio" : "image"
            }

            function s(e, t) {
                return new Promise(n => {
                    new Promise(e => {
                        try {
                            if ("u" < typeof indexedDB) return void e(null);
                            let t = indexedDB.open("cp_guest_assets_v1", 1);
                            t.onupgradeneeded = () => {
                                let e = t.result;
                                e.objectStoreNames.contains(l) || e.createObjectStore(l, {
                                    keyPath: "fieldPath"
                                })
                            }, t.onsuccess = () => e(t.result), t.onerror = () => e(null), t.onblocked = () => e(null)
                        } catch {
                            e(null)
                        }
                    }).then(i => {
                        if (!i) return void n(null);
                        try {
                            let r = i.transaction(l, e),
                                s = t(r.objectStore(l)),
                                o = null;
                            s.onsuccess = () => {
                                o = s.result ? ? null
                            }, s.onerror = () => {
                                o = null
                            }, r.oncomplete = () => {
                                i.close(), n(o)
                            }, r.onerror = () => {
                                i.close(), n(null)
                            }, r.onabort = () => {
                                i.close(), n(null)
                            }
                        } catch {
                            n(null)
                        }
                    })
                })
            }
            async function o(e) {
                let t;
                try {
                    t = await e.blob.arrayBuffer()
                } catch {
                    return !1
                }
                let {
                    blob: n,
                    ...l
                } = e;
                return null !== await s("readwrite", e => e.put({ ...l,
                    bytes: t,
                    type: n.type,
                    updatedAt: Date.now()
                }))
            }
            async function a(e) {
                let t = await s("readonly", t => t.get(e));
                return t ? function(e) {
                    let {
                        bytes: t,
                        type: n,
                        blob: l,
                        ...i
                    } = e;
                    return { ...i,
                        blob: t ? new Blob([t], {
                            type: n ? ? ""
                        }) : l
                    }
                }(t) : null
            }
            async function c() {
                return (await s("readonly", e => e.getAllKeys()) ? ? []).filter(e => "string" == typeof e)
            }
            async function d(e) {
                await s("readwrite", t => t.delete(e))
            }
            let u = !1;

            function p() {
                if (!u) {
                    u = !0;
                    try {
                        navigator.storage ? .persist ? .().catch(() => !1)
                    } catch {}
                }
            }
        },
        74871: (e, t, n) => {
            n.d(t, {
                TV: () => x,
                Uj: () => h,
                hG: () => g,
                jn: () => b
            });
            var l = n(73365),
                i = n(44165),
                r = n(4355),
                s = n(33434),
                o = n(2911),
                a = n(26821),
                c = n(80894),
                d = n(63814),
                u = n(1521),
                p = n(98196),
                f = n(87404),
                m = n(54872);
            let h = {
                button: "Upload your characters",
                short: "Characters",
                title: "Upload your characters",
                description: "Turn the two of you into cute stickers. We put them in every scene of your page.",
                steps: ["Copy the ChatGPT prompt", "Paste it in ChatGPT with a clear photo", "Crop the picture and upload it here"],
                copyPrompt: "Copy prompt",
                copied: "Copied!",
                upload: "Upload",
                replace: "Replace",
                remove: "Remove",
                working: "Removing the background\u2026",
                together: "Only one? We draw the other one in for now.",
                done: "Done",
                couldNotUse: "We could not use that picture. Try another one."
            };

            function x(e, t) {
                let n = [],
                    l = new Set;
                for (let i of t.pages)
                    for (let t of i.sections)
                        if (!l.has(t.type))
                            for (let r of (l.add(t.type), e.sections[t.type] ? .fields ? ? [])) {
                                if ("image" !== r.type || !r.cutout || !r.prompt) continue;
                                let e = t.values[r.id];
                                n.push({
                                    pageId: i.id,
                                    sectionId: t.id,
                                    field: r,
                                    value: "string" == typeof e ? e : ""
                                })
                            }
                return n
            }

            function g({
                words: e,
                onClick: t,
                className: n,
                short: r = !1
            }) {
                return (0, l.jsxs)("button", {
                    type: "button",
                    onClick: t,
                    className: (0, m.cn)("flex h-11 items-center justify-center gap-2 rounded-xl bg-[linear-gradient(100deg,#ff7a59,#e0457b)] px-4 text-[14px] font-semibold text-white shadow-[0_2px_8px_rgba(224,69,123,0.35)] active:opacity-85", n),
                    children: [(0, l.jsx)(i.A, {
                        size: 18,
                        strokeWidth: 2,
                        "aria-hidden": !0
                    }), r ? e.short : e.button]
                })
            }

            function b({
                open: e,
                onClose: t,
                slots: n,
                resolve: i,
                upload: r,
                commit: s,
                words: o
            }) {
                let a = (0, u.useId)(),
                    c = n.filter(e => e.value).length;
                return e ? (0, p.createPortal)((0, l.jsx)("div", {
                    className: "relative z-[200]",
                    children: (0, l.jsx)(f.lG, {
                        open: e,
                        onClose: t,
                        labelledBy: a,
                        size: "lg",
                        children: (0, l.jsxs)("div", {
                            className: "p-5",
                            children: [(0, l.jsx)("h2", {
                                id: a,
                                className: "text-[17px] font-semibold tracking-[-0.01em]",
                                children: o.title
                            }), (0, l.jsx)("p", {
                                className: "mt-1 text-[13px] leading-relaxed text-cp-muted",
                                children: o.description
                            }), (0, l.jsx)("ol", {
                                className: "mt-3 grid gap-1.5 text-[12.5px] sm:grid-cols-3",
                                children: o.steps.map((e, t) => (0, l.jsxs)("li", {
                                    className: "flex items-center gap-2 rounded-lg bg-cp-subtle px-2.5 py-2",
                                    children: [(0, l.jsx)("span", {
                                        className: "flex size-5 shrink-0 items-center justify-center rounded-full bg-cp-primary text-[11px] font-bold text-white",
                                        children: t + 1
                                    }), e]
                                }, e))
                            }), (0, l.jsx)("div", {
                                className: "mt-4 grid grid-cols-2 gap-3",
                                children: n.map(e => (0, l.jsx)(y, {
                                    slot: e,
                                    resolve: i,
                                    upload: r,
                                    commit: s,
                                    words: o
                                }, `${e.sectionId}:${e.field.id}`))
                            }), n.length > 1 && c < n.length ? (0, l.jsx)("p", {
                                className: "mt-3 text-[12.5px] text-cp-muted",
                                children: o.together
                            }) : null, (0, l.jsx)("div", {
                                className: "mt-4 flex justify-end",
                                children: (0, l.jsx)("button", {
                                    type: "button",
                                    onClick: t,
                                    className: "h-10 rounded-xl bg-cp-primary px-5 text-[14px] font-semibold text-white active:opacity-85",
                                    children: o.done
                                })
                            })]
                        })
                    })
                }), document.body) : null
            }

            function y({
                slot: e,
                resolve: t,
                upload: n,
                commit: i,
                words: p
            }) {
                let f = (0, u.useRef)(null),
                    [m, h] = (0, u.useState)(!1),
                    [x, g] = (0, u.useState)(null),
                    [b, k] = (0, u.useState)(!1),
                    v = e.value ? t(e.value) : "",
                    j = async t => {
                        if (t) {
                            h(!0), g(null);
                            try {
                                let l = await n(e, t);
                                l.ok ? i(e, l.url) || g(p.couldNotUse) : g(l.message)
                            } finally {
                                h(!1), f.current && (f.current.value = "")
                            }
                        }
                    },
                    w = async () => {
                        try {
                            await navigator.clipboard.writeText(e.field.prompt ? ? ""), k(!0), setTimeout(() => k(!1), 2e3)
                        } catch {}
                    };
                return (0, l.jsxs)("div", {
                    className: "flex min-w-0 flex-col gap-2 rounded-xl border border-cp-line p-2.5",
                    children: [(0, l.jsx)("p", {
                        className: "truncate text-[13px] font-semibold",
                        children: e.field.label
                    }), (0, l.jsxs)("button", {
                        type: "button",
                        onClick: () => f.current ? .click(),
                        disabled: m,
                        "aria-label": v ? `${p.replace}: ${e.field.label}` : `${p.upload}: ${e.field.label}`,
                        className: "relative flex h-44 w-full items-center justify-center overflow-hidden rounded-lg sm:h-56",
                        style: {
                            background: "repeating-conic-gradient(#f1eef7 0% 25%, #ffffff 0% 50%) 50% / 16px 16px"
                        },
                        children: [v ? (0, l.jsx)("img", {
                            src: v,
                            alt: "",
                            className: "size-full object-contain p-2"
                        }) : (0, l.jsxs)("span", {
                            className: "flex flex-col items-center gap-1 text-cp-muted",
                            children: [(0, l.jsx)(r.A, {
                                size: 40,
                                strokeWidth: 1.25,
                                "aria-hidden": !0
                            }), (0, l.jsx)(s.A, {
                                size: 16,
                                strokeWidth: 1.75,
                                "aria-hidden": !0
                            })]
                        }), m ? (0, l.jsxs)("span", {
                            className: "absolute inset-0 flex flex-col items-center justify-center gap-1.5 bg-white/80 px-2 text-center text-[11.5px] font-medium",
                            children: [(0, l.jsx)(o.A, {
                                size: 20,
                                className: "animate-spin",
                                "aria-hidden": !0
                            }), p.working]
                        }) : null]
                    }), x ? (0, l.jsx)("p", {
                        role: "alert",
                        className: "text-[12px] text-cp-danger-ink",
                        children: x
                    }) : null, e.field.prompt ? (0, l.jsxs)("button", {
                        type: "button",
                        onClick: () => void w(),
                        className: "flex h-9 items-center justify-center gap-1.5 rounded-lg border border-cp-line px-2 text-[12.5px] font-medium active:bg-cp-subtle",
                        children: [b ? (0, l.jsx)(a.A, {
                            size: 14,
                            "aria-hidden": !0
                        }) : (0, l.jsx)(c.A, {
                            size: 14,
                            "aria-hidden": !0
                        }), b ? p.copied : p.copyPrompt]
                    }) : null, (0, l.jsxs)("div", {
                        className: "flex gap-1.5",
                        children: [(0, l.jsxs)("button", {
                            type: "button",
                            onClick: () => f.current ? .click(),
                            disabled: m,
                            className: "flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg bg-cp-primary px-2 text-[12.5px] font-semibold text-white active:opacity-85 disabled:opacity-60",
                            children: [(0, l.jsx)(s.A, {
                                size: 14,
                                "aria-hidden": !0
                            }), v ? p.replace : p.upload]
                        }), v ? (0, l.jsx)("button", {
                            type: "button",
                            "aria-label": `${p.remove}: ${e.field.label}`,
                            onClick: () => g(i(e, "") ? null : p.couldNotUse),
                            className: "flex size-9 items-center justify-center rounded-lg border border-cp-line active:bg-cp-subtle",
                            children: (0, l.jsx)(d.A, {
                                size: 14,
                                "aria-hidden": !0
                            })
                        }) : null]
                    }), (0, l.jsx)("input", {
                        ref: f,
                        type: "file",
                        accept: "image/png,image/jpeg,image/webp",
                        className: "hidden",
                        tabIndex: -1,
                        "aria-hidden": !0,
                        onChange: e => void j(e.target.files ? .[0])
                    })]
                })
            }
        },
        80178: (e, t, n) => {
            n.d(t, {
                ru: () => d,
                w4: () => u
            });
            var l = n(49688);
            let i = l.rG,
                r = l.vV,
                s = l.cE,
                o = l.CU;
            async function a(e) {
                try {
                    let t = new Uint8Array(await e.slice(0, 21).arrayBuffer()),
                        n = e => String.fromCharCode(...t.subarray(e, e + 4));
                    return 21 === t.length && "RIFF" === n(0) && "WEBP" === n(8) && "VP8X" === n(12) && (2 & t[20]) != 0
                } catch {
                    return !1
                }
            }
            let c = null,
                d = {
                    longEdge: 1280,
                    maxBytes: 409600
                };
            async function u(e, t = {}) {
                var n, d;
                let p, f = t.longEdge ? ? i,
                    m = t.maxBytes ? ? s,
                    h = e.type.startsWith("image/") && await a(e);
                if ("image/gif" === (n = e.type) || "image/svg+xml" === n || h) {
                    let t = "image/gif" === e.type || h ? l.Dk : m;
                    return e.size > t ? {
                        ok: !1,
                        reason: "too-large"
                    } : {
                        ok: !0,
                        file: e,
                        originalBytes: e.size,
                        compressedBytes: e.size
                    }
                }
                if (!e.type.startsWith("image/")) return {
                    ok: !1,
                    reason: "unsupported"
                };
                if (e.size > o) return {
                    ok: !1,
                    reason: "too-large"
                };
                try {
                    p = await createImageBitmap(e)
                } catch {
                    return {
                        ok: !1,
                        reason: "failed"
                    }
                }
                try {
                    let t, n = Math.max(p.width, p.height),
                        l = n > f ? f / n : 1,
                        i = document.createElement("canvas");
                    i.width = Math.max(1, Math.round(p.width * l)), i.height = Math.max(1, Math.round(p.height * l));
                    let s = i.getContext("2d");
                    if (!s) return {
                        ok: !1,
                        reason: "failed"
                    };
                    s.drawImage(p, 0, 0, i.width, i.height);
                    let o = await (c ? ? = new Promise(e => {
                            try {
                                let t = document.createElement("canvas");
                                t.width = 1, t.height = 1, t.toBlob(t => e(!!t && "image/webp" === t.type), "image/webp", .5)
                            } catch {
                                e(!1)
                            }
                        }).then(e => e ? "image/webp" : "image/jpeg")),
                        a = null;
                    for (let e of r)
                        if ((a = await
                                function(e, t, n) {
                                    return new Promise(l => {
                                        try {
                                            e.toBlob(e => l(e), t, n)
                                        } catch {
                                            l(null)
                                        }
                                    })
                                }(i, o, e)) && a.size <= m) break;
                    if (!a) return {
                        ok: !1,
                        reason: "failed"
                    };
                    if (a.size > m) return {
                        ok: !1,
                        reason: "too-large"
                    };
                    if (a.size >= e.size && e.size <= m) return {
                        ok: !0,
                        file: e,
                        originalBytes: e.size,
                        compressedBytes: e.size
                    };
                    return {
                        ok: !0,
                        file: new File([a], (d = e.name, t = d.replace(/\.[a-z0-9]+$/i, "") || "image", `${t}.${"image/webp"===o?"webp":"jpg"}`), {
                            type: o
                        }),
                        originalBytes: e.size,
                        compressedBytes: a.size
                    }
                } catch {
                    return {
                        ok: !1,
                        reason: "failed"
                    }
                } finally {
                    p.close()
                }
            }
        },
        89503: (e, t, n) => {
            n.d(t, {
                ur: () => s,
                yM: () => a
            });
            var l = n(74871),
                i = n(26244);
            let r = e => (e / 1048576).toFixed(1),
                s = {
                    pickLook: "Pick a look",
                    addPhoto: "Add photo",
                    replace: "Replace",
                    addingPhoto: "Adding your photo",
                    addLabel: e => `Add ${e}`,
                    replaceLabel: e => `Replace ${e}`,
                    photoNotUsed: "We could not use that photo. Try another one.",
                    badLink: "That link does not look right. Use an https:// address.",
                    tooLong: e => `Keep it under ${e} characters.`,
                    didNotFit: "That did not fit. Try something shorter.",
                    entryLabel: (e, t) => `${e} ${t}`,
                    entryFieldLabel: (e, t) => `${e} ${t.toLowerCase()}`,
                    song: {
                        noMusic: "No music",
                        defaultSong: "Default song",
                        yourSong: "Your song",
                        captionDefault: "Default song",
                        captionCustom: "Your song",
                        captionNone: "Your invite plays no song",
                        upload: "Upload your song",
                        uploading: "Adding your song",
                        useDefault: "Use the default song",
                        pickSong: "Pick a song",
                        removeSong: "No music",
                        play: e => `Play ${e}`,
                        pause: e => `Pause ${e}`,
                        cannotPlay: "This song could not play here. Try another file.",
                        cannotUse: "We could not use that song. Try another one.",
                        cannotSwitchBack: "We could not switch the song back.",
                        cannotRemove: "We could not remove the song.",
                        fallbackTitle: "Our song",
                        limits: "MP3, up to 3 MB.",
                        size: e => `${r(e)} MB`
                    },
                    characters: l.Uj
                },
                o = {
                    pickLook: "\u09b0\u0982 \u09ac\u09c7\u099b\u09c7 \u09a8\u09be\u0993 \xb7 Look",
                    addPhoto: "\u099b\u09ac\u09bf \u09a6\u09be\u0993",
                    replace: "\u09ac\u09a6\u09b2\u09be\u0993",
                    addingPhoto: "\u099b\u09ac\u09bf \u09af\u09cb\u0997 \u09b9\u099a\u09cd\u099b\u09c7",
                    addLabel: e => `${e} \u09af\u09cb\u0997 \u0995\u09b0\u09cb`,
                    replaceLabel: e => `${e} \u09ac\u09a6\u09b2\u09be\u0993`,
                    photoNotUsed: "\u098f\u0987 \u099b\u09ac\u09bf\u099f\u09be \u09a8\u09c7\u0993\u09af\u09bc\u09be \u0997\u09c7\u09b2 \u09a8\u09be\u0964 \u0985\u09a8\u09cd\u09af \u098f\u0995\u099f\u09be \u09a6\u09be\u0993\u0964",
                    badLink: "\u09b2\u09bf\u0982\u0995\u099f\u09be \u09a0\u09bf\u0995 \u09b2\u09be\u0997\u099b\u09c7 \u09a8\u09be\u0964 https:// \u09a6\u09bf\u09af\u09bc\u09c7 \u09b6\u09c1\u09b0\u09c1 \u09b9\u0993\u09af\u09bc\u09be \u09b2\u09bf\u0982\u0995 \u09a6\u09be\u0993\u0964",
                    tooLong: e => `${(0,i.wb)(e)} \u0985\u0995\u09cd\u09b7\u09b0\u09c7\u09b0 \u09ae\u09a7\u09cd\u09af\u09c7 \u09b0\u09be\u0996\u09cb\u0964`,
                    didNotFit: "\u098f\u099f\u09be \u0986\u0981\u099f\u09b2 \u09a8\u09be\u0964 \u098f\u0995\u099f\u09c1 \u099b\u09cb\u099f \u0995\u09b0\u09c7 \u09b2\u09c7\u0996\u09cb\u0964",
                    entryLabel: (e, t) => `${e} ${(0,i.wb)(t)}`,
                    entryFieldLabel: (e, t) => `${e}: ${t}`,
                    song: {
                        noMusic: "\u0997\u09be\u09a8 \u09a8\u09c7\u0987",
                        defaultSong: "\u0986\u09ae\u09be\u09a6\u09c7\u09b0 \u0997\u09be\u09a8",
                        yourSong: "\u09a4\u09cb\u09ae\u09be\u09b0 \u0997\u09be\u09a8",
                        captionDefault: "\u0986\u09ae\u09be\u09a6\u09c7\u09b0 \u09ac\u09be\u099b\u09be\u0987 \u0995\u09b0\u09be \u0997\u09be\u09a8",
                        captionCustom: "\u09a4\u09cb\u09ae\u09be\u09b0 \u09a6\u09c7\u0993\u09af\u09bc\u09be \u0997\u09be\u09a8",
                        captionNone: "\u0995\u09cb\u09a8\u09cb \u0997\u09be\u09a8 \u09ac\u09be\u099c\u09ac\u09c7 \u09a8\u09be, \u09b6\u09c1\u09a7\u09c1 \u09a2\u09be\u0995\u09c7\u09b0 \u09b6\u09ac\u09cd\u09a6",
                        upload: "\u09a8\u09bf\u099c\u09c7\u09b0 \u0997\u09be\u09a8 \u09a6\u09be\u0993 \xb7 Upload MP3",
                        uploading: "\u0997\u09be\u09a8 \u09af\u09cb\u0997 \u09b9\u099a\u09cd\u099b\u09c7\u2026",
                        useDefault: "\u0986\u09ae\u09be\u09a6\u09c7\u09b0 \u0997\u09be\u09a8\u099f\u09be\u0987 \u09a5\u09be\u0995",
                        pickSong: "\u098f\u0995\u099f\u09be \u0997\u09be\u09a8 \u09ac\u09c7\u099b\u09c7 \u09a8\u09be\u0993 \xb7 Pick a song",
                        removeSong: "\u0997\u09be\u09a8 \u099b\u09be\u09a1\u09bc\u09be",
                        play: e => `${e} \u099a\u09be\u09b2\u09be\u0993`,
                        pause: e => `${e} \u09a5\u09be\u09ae\u09be\u0993`,
                        cannotPlay: "\u098f\u0987 \u0997\u09be\u09a8\u099f\u09be \u098f\u0996\u09be\u09a8\u09c7 \u099a\u09b2\u09b2 \u09a8\u09be\u0964 \u0985\u09a8\u09cd\u09af \u09ab\u09be\u0987\u09b2 \u09a6\u09be\u0993\u0964",
                        cannotUse: "\u098f\u0987 \u0997\u09be\u09a8\u099f\u09be \u09a8\u09c7\u0993\u09af\u09bc\u09be \u0997\u09c7\u09b2 \u09a8\u09be\u0964 \u0985\u09a8\u09cd\u09af \u098f\u0995\u099f\u09be \u09a6\u09be\u0993\u0964",
                        cannotSwitchBack: "\u0997\u09be\u09a8\u099f\u09be \u09ab\u09c7\u09b0\u09be\u09a8\u09cb \u0997\u09c7\u09b2 \u09a8\u09be\u0964",
                        cannotRemove: "\u0997\u09be\u09a8\u099f\u09be \u09b8\u09b0\u09be\u09a8\u09cb \u0997\u09c7\u09b2 \u09a8\u09be\u0964",
                        fallbackTitle: "\u0986\u09ae\u09be\u09a6\u09c7\u09b0 \u0997\u09be\u09a8",
                        limits: "\u09b6\u09c1\u09a7\u09c1 MP3, \u09e9 MB \u09aa\u09b0\u09cd\u09af\u09a8\u09cd\u09a4\u0964 WhatsApp-\u098f\u09b0 \u0997\u09be\u09a8 \u09b9\u09b2\u09c7 \u0986\u0997\u09c7 \u09ab\u09be\u0987\u09b2\u099f\u09be \u09ab\u09cb\u09a8\u09c7 \u09b8\u09c7\u09ad \u0995\u09b0\u09c7 \u09a8\u09be\u0993\u0964",
                        size: e => `${(0,i.wb)(r(e))} MB`
                    },
                    characters: {
                        button: "\u09a4\u09cb\u09ae\u09be\u09a6\u09c7\u09b0 \u099a\u09b0\u09bf\u09a4\u09cd\u09b0 \u0986\u09aa\u09b2\u09cb\u09a1 \u0995\u09b0\u09cb",
                        short: "\u099a\u09b0\u09bf\u09a4\u09cd\u09b0",
                        title: "\u09a4\u09cb\u09ae\u09be\u09a6\u09c7\u09b0 \u099a\u09b0\u09bf\u09a4\u09cd\u09b0 \xb7 Your characters",
                        description: "\u09a6\u09c1\u099c\u09a8\u0995\u09c7 \u09ae\u09bf\u09b7\u09cd\u099f\u09bf \u09b8\u09cd\u099f\u09bf\u0995\u09be\u09b0 \u09ac\u09be\u09a8\u09bf\u09af\u09bc\u09c7 \u09a6\u09be\u0993\u0964 \u09aa\u09c7\u099c\u09c7\u09b0 \u09aa\u09cd\u09b0\u09a4\u09bf\u099f\u09be \u099b\u09ac\u09bf\u09a4\u09c7 \u09a4\u09cb\u09ae\u09b0\u09be\u0987 \u09a5\u09be\u0995\u09ac\u09c7\u0964",
                        steps: ["ChatGPT-\u09b0 \u09b2\u09c7\u0996\u09be\u099f\u09be \u0995\u09aa\u09bf \u0995\u09b0\u09cb", "\u098f\u0995\u099f\u09be \u09aa\u09b0\u09bf\u09b7\u09cd\u0995\u09be\u09b0 \u099b\u09ac\u09bf\u09b0 \u09b8\u0999\u09cd\u0997\u09c7 ChatGPT-\u09a4\u09c7 \u09aa\u09c7\u09b8\u09cd\u099f \u0995\u09b0\u09cb", "\u099b\u09ac\u09bf\u099f\u09be \u0995\u09c7\u099f\u09c7 (crop) \u098f\u0996\u09be\u09a8\u09c7 \u0986\u09aa\u09b2\u09cb\u09a1 \u0995\u09b0\u09cb"],
                        copyPrompt: "\u09b2\u09c7\u0996\u09be\u099f\u09be \u0995\u09aa\u09bf \u0995\u09b0\u09cb",
                        copied: "\u0995\u09aa\u09bf \u09b9\u09af\u09bc\u09c7\u099b\u09c7!",
                        upload: "\u0986\u09aa\u09b2\u09cb\u09a1",
                        replace: "\u09ac\u09a6\u09b2\u09be\u0993",
                        remove: "\u09b8\u09b0\u09be\u0993",
                        working: "\u09ac\u09cd\u09af\u09be\u0995\u0997\u09cd\u09b0\u09be\u0989\u09a8\u09cd\u09a1 \u09b8\u09b0\u09be\u09a8\u09cb \u09b9\u099a\u09cd\u099b\u09c7\u2026",
                        together: "\u098f\u0995\u099f\u09be \u09a6\u09bf\u09b2\u09c7 \u0985\u09a8\u09cd\u09af\u099c\u09a8\u0995\u09c7 \u098f\u0996\u09a8\u0995\u09be\u09b0 \u09ae\u09a4\u09cb \u0986\u09ae\u09b0\u09be\u0987 \u098f\u0981\u0995\u09c7 \u09a6\u09c7\u09ac\u0964",
                        done: "\u09b9\u09af\u09bc\u09c7 \u0997\u09c7\u099b\u09c7",
                        couldNotUse: "\u098f\u0987 \u099b\u09ac\u09bf\u099f\u09be \u09a8\u09c7\u0993\u09af\u09bc\u09be \u0997\u09c7\u09b2 \u09a8\u09be\u0964 \u0985\u09a8\u09cd\u09af \u098f\u0995\u099f\u09be \u09a6\u09be\u0993\u0964"
                    }
                };

            function a(e) {
                return "bn" === e ? o : s
            }
        }
    }
]);