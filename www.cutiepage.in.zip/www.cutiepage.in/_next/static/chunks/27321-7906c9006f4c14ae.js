"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [27321], {
        14856: (e, i, t) => {
            t.d(i, {
                Bi: () => a,
                FS: () => p,
                Rv: () => o,
                bt: () => n,
                dn: () => l,
                xB: () => s
            });
            let a = 30,
                n = 29,
                o = 150,
                r = {
                    "cp-bhai-dooj-mini": 7
                };

            function s(e) {
                return (e && Object.hasOwn(r, e) ? r[e] : void 0) ? ? a
            }
            let l = "9999-12-31T00:00:00.000Z",
                p = 24
        },
        21196: (e, i, t) => {
            t.r(i), t.d(i, {
                RevealSection: () => r
            });
            var a = t(73365),
                n = t(1521),
                o = t(54872);

            function r({
                children: e,
                className: i,
                delayMs: t = 0
            }) {
                let s = (0, n.useRef)(null),
                    [l, p] = (0, n.useState)(!0);
                return (0, n.useEffect)(() => {
                    let e = s.current;
                    if (!e || "u" < typeof IntersectionObserver || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
                    let i = e.getBoundingClientRect();
                    if (i.top <= .92 * window.innerHeight) return;
                    let t = 0,
                        a = window.innerWidth;
                    for (let i = e.parentElement; i; i = i.parentElement)
                        if ("visible" !== getComputedStyle(i).overflowX) {
                            let e = i.getBoundingClientRect();
                            t = Math.max(t, e.left), a = Math.min(a, e.right)
                        }
                    if (i.left >= a - 8 || i.right <= t + 8) return;
                    p(!1);
                    let n = new IntersectionObserver(e => {
                        e.some(e => e.isIntersecting) && (p(!0), n.disconnect())
                    }, {
                        rootMargin: "0px 0px -8% 0px"
                    });
                    return n.observe(e), () => n.disconnect()
                }, []), (0, a.jsx)("div", {
                    ref: s,
                    className: (0, o.cn)("reveal-section", l && "is-visible", i),
                    style: {
                        transitionDelay: `${t}ms`
                    },
                    children: e
                })
            }
        },
        67344: (e, i, t) => {
            t.d(i, {
                Ei: () => g,
                J7: () => p,
                Mw: () => s,
                Vt: () => r,
                c0: () => u,
                sY: () => d,
                uo: () => l
            });
            var a = t(82055),
                n = t(14856),
                o = t(95928);
            let r = {
                    slug: "bhai-dooj",
                    presentation: "grid",
                    path: "/collections/bhai-dooj",
                    name: "Bhai Dooj",
                    byline: "templates",
                    tagline: "",
                    title: "Bhai Dooj Gift Ideas 2026: Personalised Gift Websites for Brother and Sister",
                    metaDescription: "Bhai Dooj 2026 gifts for your brother or sister: a page with the tilak, your childhood photos and a promise. Made on your phone in minutes, sent as a link to any city.",
                    intro: "Make your brother or sister a page for Bhai Dooj. Pick a design, add your photos and memories, and send them the link, even if you're in different cities.",
                    emptyState: {
                        title: "New Bhai Dooj pages are on the way.",
                        description: "Until they land, every family template is ready to personalise."
                    },
                    templateSlugs: ["cp-bhai-dooj-mini", "cp-bhai-dooj-genz", "cp-bhai-dooj", "cp-bhai-dooj-letter", "cp-world-bhai-dooj", "brothers-day", "cp-know-me-quiz", "cp-compliment-machine"],
                    keywords: ["bhai dooj gift", "bhai dooj gift for brother", "bhai dooj gift for sister", "bhai dooj online gift", "bhai dooj wishes", "bhai dooj gift ideas 2026", "last minute bhai dooj gift", "bhai dooj gift for brother far away", "bhai phonta gift", "bhau beej gift", "bhai dooj video with photos"]
                },
                s = {
                    slug: "diwali",
                    presentation: "grid",
                    path: "/collections/diwali",
                    name: "Diwali",
                    byline: "templates",
                    tagline: "",
                    title: "Diwali Gift Ideas 2026: Personalised Diwali Gift Websites with Diyas, Rangoli and Fireworks",
                    metaDescription: "Unique Diwali 2026 gifts: a page where they light diyas, colour a rangoli and watch fireworks write their name, with your photos inside. Made in minutes, sent as a link.",
                    intro: "Send someone a Diwali they can open. Pick a design, add your photos and a few words, and send them the link, wherever they are celebrating.",
                    emptyState: {
                        title: "New Diwali pages are on the way.",
                        description: "Until they land, every festival template is ready to personalise."
                    },
                    templateSlugs: ["cp-diwali-dabba", "cp-world-diwali", "cp-diya", "cp-patakhe", "cp-rangoli", "cp-party-invite"],
                    keywords: ["diwali gift", "diwali gift for girlfriend", "diwali gift for boyfriend", "diwali online gift", "diwali wishes website", "digital diwali greeting", "diwali gift ideas 2026", "unique diwali gift", "last minute diwali gift", "diwali gift for parents", "diwali gift for family abroad", "personalised diwali gift"]
                },
                l = {
                    slug: "navratri",
                    presentation: "editor",
                    editor: {
                        templateSlug: "cp-navratri-proposal",
                        headline: "Navratri proposal",
                        switcher: {
                            current: "proposal",
                            options: [{
                                id: "proposal",
                                label: "\uD83D\uDC8C Proposal",
                                sub: "Ask them to garba",
                                path: "/collections/navratri",
                                templateSlug: "cp-navratri-proposal"
                            }, {
                                id: "invite",
                                label: "\uD83E\uDE94 Invite",
                                sub: "Invite 5 guests",
                                path: "/collections/navratri-invite",
                                templateSlug: "cp-navratri-invite"
                            }]
                        },
                        copy: o.fs
                    },
                    path: "/collections/navratri",
                    name: "Navratri Proposal",
                    byline: "proposal",
                    tagline: "Ask them to be your garba partner.",
                    title: "Navratri Proposal Website: Ask Them to Be Your Garba Partner",
                    metaDescription: "Make a Navratri proposal page in a minute: a garba night map, pani puri, a dandiya dance and your photos, then the big question. Send one link on WhatsApp.",
                    intro: "Add their name, your words, the garba night plan and a few photos, then send them one link.",
                    emptyState: {
                        title: "The Navratri proposal opens soon.",
                        description: "Until then, every festival template is ready to personalise."
                    },
                    templateSlugs: ["cp-navratri-proposal"],
                    keywords: ["navratri proposal", "garba partner proposal", "navratri proposal website", "dandiya night date", "garba date idea"]
                },
                p = {
                    slug: "durgapuja",
                    presentation: "editor",
                    editor: {
                        templateSlug: "cp-durga-proposal",
                        headline: "\u09aa\u09c1\u099c\u09cb\u09b0 \u09aa\u09cd\u09b0\u09b8\u09cd\u09a4\u09be\u09ac",
                        switcher: {
                            current: "proposal",
                            options: [{
                                id: "proposal",
                                label: "\uD83D\uDC8C \u09aa\u09cd\u09b0\u09b8\u09cd\u09a4\u09be\u09ac",
                                sub: "Ashtami date",
                                path: "/collections/durgapuja",
                                templateSlug: "cp-durga-proposal"
                            }, {
                                id: "invite",
                                label: "\uD83E\uDE94 \u09a8\u09bf\u09ae\u09a8\u09cd\u09a4\u09cd\u09b0\u09a3",
                                sub: "Invite 5 guests",
                                path: "/collections/durgapuja-invite",
                                templateSlug: "cp-durga-invite"
                            }]
                        },
                        copy: o.gp
                    },
                    path: "/collections/durgapuja",
                    name: "\u09aa\u09c1\u099c\u09cb\u09b0 \u09aa\u09cd\u09b0\u09b8\u09cd\u09a4\u09be\u09ac",
                    byline: "Durga Puja",
                    tagline: "\u0985\u09b7\u09cd\u099f\u09ae\u09c0\u09b0 \u09b8\u09a8\u09cd\u09a7\u09c7\u09b0 \u099c\u09a8\u09cd\u09af \u098f\u0995\u099f\u09be \u09aa\u09cd\u09b0\u09b6\u09cd\u09a8\u0964",
                    title: "Durga Puja Proposal Website in Bengali: Ask Them Out for Ashtami",
                    metaDescription: "\u098f\u09ac\u09be\u09b0\u09c7\u09b0 \u09aa\u09c1\u099c\u09cb\u09af\u09bc \u09ae\u09a8\u09c7\u09b0 \u0995\u09a5\u09be\u099f\u09be \u09ac\u09b2\u09cb\u0964 Make a Bengali Durga Puja proposal page with your photos and your Ashtami plan, then send one link on WhatsApp.",
                    intro: "\u09a4\u09cb\u09ae\u09be\u09b0 \u0995\u09a5\u09be, \u099b\u09ac\u09bf \u0986\u09b0 \u0985\u09b7\u09cd\u099f\u09ae\u09c0\u09b0 \u09aa\u09cd\u09b2\u09cd\u09af\u09be\u09a8 \u09a6\u09bf\u09af\u09bc\u09c7 \u09b8\u09be\u099c\u09bf\u09af\u09bc\u09c7 \u09a8\u09be\u0993, \u09a4\u09be\u09b0\u09aa\u09b0 \u098f\u0995\u099f\u09be \u09b2\u09bf\u0982\u0995\u09c7 \u09aa\u09be\u09a0\u09be\u0993\u0964",
                    emptyState: {
                        title: "\u09b6\u09bf\u0997\u0997\u09bf\u09b0\u0987 \u0996\u09c1\u09b2\u099b\u09c7\u0964",
                        description: "\u09aa\u09c1\u099c\u09cb\u09b0 \u09aa\u09cd\u09b0\u09b8\u09cd\u09a4\u09be\u09ac \u0996\u09c1\u09ac \u09a4\u09be\u09a1\u09bc\u09be\u09a4\u09be\u09a1\u09bc\u09bf \u0986\u09b8\u099b\u09c7\u0964"
                    },
                    templateSlugs: ["cp-durga-proposal"],
                    keywords: ["pujo proposal", "ashtami date", "durga puja proposal website", "bengali proposal website", "\u09aa\u09c1\u099c\u09cb\u09b0 \u09aa\u09cd\u09b0\u09b8\u09cd\u09a4\u09be\u09ac"]
                };
            o.gp, o.Bp;
            let d = {
                slug: "wedding-invite",
                presentation: "editor",
                editor: {
                    templateSlug: "cp-wedding-invite",
                    headline: "Wedding invite",
                    copy: o.ne
                },
                path: "/collections/wedding-invite",
                name: "Wedding Invite",
                byline: "invites",
                tagline: "Indian wedding invites online, with every event and an RSVP.",
                title: "Wedding Invitation Website: Indian Wedding E-Invite with RSVP",
                metaDescription: "Make an Indian wedding invitation website: your story and photos, Haldi, Mehendi, Sangeet, the wedding and the reception, and a personal link for every guest that greets them by name and RSVPs with how many are coming.",
                intro: "Add your names, your story and every event. Once your page is live, every guest gets their own link that greets them by name. Send it on WhatsApp or anywhere.",
                emptyState: {
                    title: "Wedding invites open soon.",
                    description: "Until then, every template is ready to personalise."
                },
                templateSlugs: ["cp-wedding-invite"],
                keywords: ["wedding invitation website", "indian wedding e-invite", "online wedding invitation with rsvp", "wedding invite link for whatsapp", "haldi mehendi sangeet invitation"]
            };
            o.AT;
            let g = {
                slug: "mini-cutiepages",
                presentation: "grid",
                path: "/collections/mini-cutiepages",
                name: "Mini CutiePages",
                byline: "templates",
                tagline: "Mini CutiePages",
                title: "Mini CutiePages: Budget Website Gifts",
                metaDescription: `Mini CutiePages from \u20b929: budget website gifts like carrom, barf ka gola, patang, chai tapri and ludo. Add your words, photos and a song, send one link. Live for ${n.Bi} days, keep it forever if you love it.`,
                intro: "",
                emptyState: {
                    title: "Mini CutiePages under \u20b929 are on the way.",
                    description: "Until they land, every occasion is ready to personalise."
                },
                templateSlugs: [],
                pricingModel: "live_pass",
                keywords: ["mini cutiepages", "website gift under 29", "website gift under 49", "cheap website gift", "funny website for friend", "small surprise website"]
            };

            function h(e) {
                return {
                    slug: 49 === e ? "templates-49" : "templates-99",
                    presentation: "grid",
                    path: `/collections/templates-${e}`,
                    name: `\u20b9${e} Templates`,
                    byline: "by CutiePage",
                    tagline: `\u20b9${e} templates`,
                    title: `\u20b9${e} Website Gift Templates for Birthdays, Love and More`,
                    metaDescription: `Cute website gift templates at \u20b9${e}: add your photos, words and a song, then send one link they open on their phone.`,
                    intro: "",
                    emptyState: {
                        title: `New \u20b9${e} templates are on the way.`,
                        description: "Until they land, every occasion is ready to personalise."
                    },
                    templateSlugs: [],
                    priceInr: e,
                    keywords: [`website gift under ${e}`, `\u20b9${e} website template`, "cheap website gift", "cute website for friend"]
                }
            }

            function u(e, i) {
                if (void 0 !== e.priceInr) return i.filter(i => i.priceInr === e.priceInr && !i.slug.startsWith("cp-vid-"));
                if (e.pricingModel) return i.filter(i => (i.pricingModel ? ? "one_time") === e.pricingModel);
                let t = new Map(i.map(e => [e.slug, e])),
                    a = [];
                for (let i of e.templateSlugs) {
                    let e = t.get(i);
                    e && a.push(e)
                }
                return a
            }
            a.dP.map(e => e.key), h(49), h(99)
        }
    }
]);