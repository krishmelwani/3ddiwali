(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [15165, 28600, 61805, 64151, 67785, 69809, 85264, 85831], {
        4525: (e, t, r) => {
            "use strict";
            r.d(t, {
                default: () => l
            });
            var i = r(1521),
                s = {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 24,
                    height: 24,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: 2,
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                },
                o = r(5695);
            let n = (0, i.createContext)({}),
                l = (0, i.forwardRef)(({
                    color: e,
                    size: t,
                    strokeWidth: r,
                    absoluteStrokeWidth: l,
                    className: a = "",
                    children: h,
                    iconNode: d,
                    ...u
                }, c) => {
                    let {
                        size: m = 24,
                        strokeWidth: k = 2,
                        absoluteStrokeWidth: w = !1,
                        color: f = "currentColor",
                        className: b = ""
                    } = (0, i.useContext)(n) ? ? {}, v = l ? ? w ? 24 * Number(r ? ? k) / Number(t ? ? m) : r ? ? k;
                    return (0, i.createElement)("svg", {
                        ref: c,
                        ...s,
                        width: t ? ? m ? ? s.width,
                        height: t ? ? m ? ? s.height,
                        stroke: e ? ? f,
                        strokeWidth: v,
                        className: (0, o.z)("lucide", b, a),
                        ...!h && !(e => {
                            for (let t in e)
                                if (t.startsWith("aria-") || "role" === t || "title" === t) return !0;
                            return !1
                        })(u) && {
                            "aria-hidden": "true"
                        },
                        ...u
                    }, [...d.map(([e, t]) => (0, i.createElement)(e, t)), ...Array.isArray(h) ? h : [h]])
                })
        },
        5695: (e, t, r) => {
            "use strict";
            r.d(t, {
                z: () => i
            });
            let i = (...e) => e.filter((e, t, r) => !!e && "" !== e.trim() && r.indexOf(e) === t).join(" ").trim()
        },
        30480: (e, t, r) => {
            Promise.resolve().then(r.bind(r, 4525)), Promise.resolve().then(r.t.bind(r, 99568, 23)), Promise.resolve().then(r.t.bind(r, 38137, 23))
        }
    },
    e => {
        e.O(0, [99568, 38137, 2347, 15158, 77358], () => e(e.s = 30480)), _N_E = e.O()
    }
]);