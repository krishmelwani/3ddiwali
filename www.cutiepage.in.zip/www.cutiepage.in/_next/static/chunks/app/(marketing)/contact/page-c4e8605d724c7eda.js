(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [74461], {
        8152: (e, t, n) => {
            Promise.resolve().then(n.bind(n, 46788)), Promise.resolve().then(n.bind(n, 21185)), Promise.resolve().then(n.bind(n, 27700))
        },
        9388: (e, t, n) => {
            "use strict";
            n.d(t, {
                $: () => p
            });
            var r = n(73365),
                a = n(1521),
                i = n(92166),
                s = n(16168),
                l = n(54872);
            let o = (0, s.F)(["inline-flex shrink-0 cursor-pointer items-center justify-center gap-1.5 whitespace-nowrap rounded-full font-medium", "transition-[background-color,color,border-color,box-shadow,transform] duration-150", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", "disabled:cursor-not-allowed disabled:opacity-50 aria-disabled:cursor-not-allowed aria-disabled:opacity-50", "motion-reduce:transition-none"], {
                    variants: {
                        variant: {
                            primary: "border-0 bg-cp-primary text-white hover:bg-cp-primary-hover active:scale-[0.98] motion-reduce:active:scale-100",
                            secondary: "border-0 bg-cp-subtle text-cp-ink hover:bg-cp-hover active:scale-[0.98] motion-reduce:active:scale-100",
                            outline: "border border-cp-primary bg-cp-bg text-cp-primary hover:bg-cp-primary-soft active:scale-[0.98] motion-reduce:active:scale-100",
                            ghost: "border-0 bg-transparent text-cp-ink hover:bg-cp-subtle active:bg-cp-hover",
                            "ghost-dark": "border-0 bg-transparent text-white/80 hover:bg-white/10 hover:text-white",
                            danger: "border-0 bg-cp-danger-strong text-white hover:bg-cp-danger-strong/90 active:scale-[0.98] motion-reduce:active:scale-100"
                        },
                        size: {
                            xs: "h-8 px-3 text-[13px]",
                            sm: "h-9 px-3.5 text-[13px]",
                            md: "h-11 px-4 text-[14px]",
                            lg: "h-14 px-6 text-[15px] font-semibold"
                        },
                        iconOnly: {
                            true: "px-0",
                            false: ""
                        }
                    },
                    compoundVariants: [{
                        iconOnly: !0,
                        size: "xs",
                        className: "w-8"
                    }, {
                        iconOnly: !0,
                        size: "sm",
                        className: "w-9"
                    }, {
                        iconOnly: !0,
                        size: "md",
                        className: "w-11"
                    }, {
                        iconOnly: !0,
                        size: "lg",
                        className: "w-14"
                    }],
                    defaultVariants: {
                        variant: "primary",
                        size: "md",
                        iconOnly: !1
                    }
                }),
                c = {
                    xs: "size-4",
                    sm: "size-4",
                    md: "size-4",
                    lg: "size-[18px]"
                };

            function d({
                className: e
            }) {
                return (0, r.jsxs)("svg", {
                    className: (0, l.cn)("animate-spin motion-reduce:animate-none", e),
                    viewBox: "0 0 24 24",
                    fill: "none",
                    "aria-hidden": "true",
                    children: [(0, r.jsx)("circle", {
                        className: "opacity-25",
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "currentColor",
                        strokeWidth: "3"
                    }), (0, r.jsx)("path", {
                        className: "opacity-90",
                        d: "M12 2a10 10 0 0 1 10 10",
                        stroke: "currentColor",
                        strokeWidth: "3",
                        strokeLinecap: "round"
                    })]
                })
            }

            function u(e, t) {
                return e ? a.isValidElement(e) ? a.cloneElement(e, {
                    className: (0, l.cn)(t, "shrink-0", e.props.className)
                }) : e : null
            }
            let p = a.forwardRef(({
                className: e,
                variant: t,
                size: n,
                iconOnly: s = !1,
                iconLeading: p,
                iconTrailing: m,
                loading: x = !1,
                asChild: h = !1,
                disabled: f,
                children: v,
                type: b,
                ...g
            }, y) => {
                let j = n ? ? "md",
                    w = c[j],
                    N = f || x,
                    k = x ? (0, r.jsx)(d, {
                        className: w
                    }) : u(p, w),
                    O = x && !p ? null : u(m, w),
                    C = s && x ? null : s ? u(v, w) : v,
                    E = (0, l.cn)(o({
                        variant: t,
                        size: j,
                        iconOnly: s
                    }), x && "pointer-events-none", e);
                return h ? (0, r.jsx)(i.DX, {
                    className: E,
                    "data-cp-button": "",
                    "aria-busy": x || void 0,
                    "aria-disabled": N || void 0,
                    "data-disabled": N || void 0,
                    ref: y,
                    ...g,
                    children: a.isValidElement(v) ? a.cloneElement(v, void 0, (0, r.jsxs)(r.Fragment, {
                        children: [k, (0, r.jsx)(i.xV, {
                            children: v.props.children
                        }), O]
                    })) : v
                }) : (0, r.jsxs)("button", {
                    "data-cp-button": "",
                    className: E,
                    ref: y,
                    type: b ? ? "button",
                    disabled: N,
                    "aria-busy": x || void 0,
                    "aria-disabled": N || void 0,
                    ...g,
                    children: [k, (0, r.jsx)(i.xV, {
                        children: C
                    }), O]
                })
            });
            p.displayName = "Button"
        },
        16168: (e, t, n) => {
            "use strict";
            n.d(t, {
                F: () => s
            });
            var r = n(68662);
            let a = e => "boolean" == typeof e ? `${e}` : 0 === e ? "0" : e,
                i = r.$,
                s = (e, t) => n => {
                    var r;
                    if ((null == t ? void 0 : t.variants) == null) return i(e, null == n ? void 0 : n.class, null == n ? void 0 : n.className);
                    let {
                        variants: s,
                        defaultVariants: l
                    } = t, o = Object.keys(s).map(e => {
                        let t = null == n ? void 0 : n[e],
                            r = null == l ? void 0 : l[e];
                        if (null === t) return null;
                        let i = a(t) || a(r);
                        return s[e][i]
                    }), c = n && Object.entries(n).reduce((e, t) => {
                        let [n, r] = t;
                        return void 0 === r || (e[n] = r), e
                    }, {});
                    return i(e, o, null == t || null == (r = t.compoundVariants) ? void 0 : r.reduce((e, t) => {
                        let {
                            class: n,
                            className: r,
                            ...a
                        } = t;
                        return Object.entries(a).every(e => {
                            let [t, n] = e;
                            return Array.isArray(n) ? n.includes({ ...l,
                                ...c
                            }[t]) : ({ ...l,
                                ...c
                            })[t] === n
                        }) ? [...e, n, r] : e
                    }, []), null == n ? void 0 : n.class, null == n ? void 0 : n.className)
                }
        },
        17001: (e, t, n) => {
            "use strict";
            n.d(t, {
                D0: () => c,
                N_: () => s,
                c8: () => l,
                pd: () => o
            });
            var r = n(73365),
                a = n(1521),
                i = n(54872);
            let s = (0, i.cn)("w-full min-w-0 rounded-lg border border-transparent bg-cp-subtle text-cp-ink outline-none", "transition-[background-color,border-color,box-shadow] duration-150 motion-reduce:transition-none", "placeholder:text-cp-faint hover:border-cp-line", "focus:border-cp-select focus:bg-cp-bg focus:ring-3 focus:ring-cp-select/15", "aria-invalid:border-cp-danger aria-invalid:focus:ring-cp-danger/15", "disabled:cursor-not-allowed disabled:text-cp-faint disabled:hover:border-transparent"),
                l = {
                    sm: "h-9 px-3 text-[13px]",
                    md: "h-11 px-3.5 text-[14px]"
                },
                o = a.forwardRef(({
                    className: e,
                    inputSize: t = "md",
                    invalid: n,
                    ...a
                }, o) => (0, r.jsx)("input", {
                    ref: o,
                    "aria-invalid": n || a["aria-invalid"] || void 0,
                    className: (0, i.cn)("flex", s, l[t], e),
                    ...a
                }));

            function c({
                label: e,
                htmlFor: t,
                hint: n,
                error: s,
                children: l,
                className: o
            }) {
                let d = s ? `${t}-error` : n ? `${t}-hint` : void 0,
                    u = d && a.isValidElement(l) ? a.cloneElement(l, {
                        "aria-describedby": l.props["aria-describedby"] ? ? d
                    }) : l;
                return (0, r.jsxs)("div", {
                    className: (0, i.cn)("flex flex-col gap-1.5", o),
                    children: [(0, r.jsx)("label", {
                        htmlFor: t,
                        className: "text-[12px] font-medium text-cp-ink",
                        children: e
                    }), u, s ? (0, r.jsx)("p", {
                        id: `${t}-error`,
                        className: "text-[12px] text-cp-danger-ink",
                        children: s
                    }) : n ? (0, r.jsx)("p", {
                        id: `${t}-hint`,
                        className: "text-[12px] text-cp-muted",
                        children: n
                    }) : null]
                })
            }
            o.displayName = "Input"
        },
        21185: (e, t, n) => {
            "use strict";
            n.d(t, {
                ContactSection: () => o
            });
            var r = n(73365),
                a = n(17001),
                i = n(1521),
                s = n(26752),
                l = n(9388);

            function o() {
                let [e, t] = (0, i.useState)("idle"), [n, o] = (0, i.useState)(null), [c, d] = (0, i.useState)({
                    name: "",
                    email: "",
                    message: ""
                }), u = async e => {
                    e.preventDefault(), t("sending"), o(null);
                    try {
                        let e = await fetch("/api/contact", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify(c)
                            }),
                            n = await e.json().catch(() => ({}));
                        if (!e.ok) throw Error(n && "string" == typeof n.error && n.error || "Something went wrong. Please try again.");
                        t("sent"), d({
                            name: "",
                            email: "",
                            message: ""
                        }), setTimeout(() => t("idle"), 4e3)
                    } catch (e) {
                        t("idle"), o(e instanceof Error ? e.message : "Something went wrong. Please try again.")
                    }
                };
                return (0, r.jsx)("section", {
                    id: "contact",
                    className: "relative bg-cp-canvas pb-24 pt-10",
                    children: (0, r.jsxs)("div", {
                        className: "relative mx-auto max-w-3xl px-4 sm:px-6",
                        children: [(0, r.jsx)("div", {
                            className: "border-t border-cp-line pt-12",
                            children: (0, r.jsx)("h2", {
                                className: "font-semibold text-2xl tracking-[-0.02em] text-cp-ink md:text-3xl",
                                children: s.O.contact.title
                            })
                        }), (0, r.jsxs)("div", {
                            className: "mt-10 space-y-10",
                            children: [(0, r.jsxs)("div", {
                                children: [(0, r.jsx)("div", {
                                    className: "grid gap-4 sm:grid-cols-3",
                                    children: [{
                                        icon: (0, r.jsx)("svg", {
                                            className: "size-5",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            strokeWidth: 1.5,
                                            children: (0, r.jsx)("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"
                                            })
                                        }),
                                        label: s.O.contact.infoCards[0].label,
                                        value: s.O.contact.infoCards[0].value
                                    }, {
                                        icon: (0, r.jsx)("svg", {
                                            className: "size-5",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            strokeWidth: 1.5,
                                            children: (0, r.jsx)("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
                                            })
                                        }),
                                        label: s.O.contact.infoCards[1].label,
                                        value: s.O.contact.infoCards[1].value
                                    }, {
                                        icon: (0, r.jsxs)("svg", {
                                            className: "size-5",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            strokeWidth: 1.5,
                                            children: [(0, r.jsx)("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M15 10.5a3 3 0 11-6 0 3 3 0 016 0z"
                                            }), (0, r.jsx)("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 0115 0z"
                                            })]
                                        }),
                                        label: s.O.contact.infoCards[2].label,
                                        value: s.O.contact.infoCards[2].value
                                    }].map(e => (0, r.jsxs)("div", {
                                        className: "flex items-center gap-3",
                                        children: [(0, r.jsx)("div", {
                                            className: "flex size-10 shrink-0 items-center justify-center rounded-lg bg-cp-primary-soft text-cp-primary",
                                            children: e.icon
                                        }), (0, r.jsxs)("div", {
                                            className: "min-w-0",
                                            children: [(0, r.jsx)("div", {
                                                className: "text-xs text-cp-muted",
                                                children: e.label
                                            }), (0, r.jsx)("div", {
                                                className: "truncate text-sm font-medium text-cp-ink",
                                                children: e.value
                                            })]
                                        })]
                                    }, e.label))
                                }), (0, r.jsx)("p", {
                                    className: "mt-4 text-sm text-cp-muted",
                                    children: s.O.contact.legalEntity
                                })]
                            }), (0, r.jsx)("div", {
                                className: "rounded-xl border border-cp-line bg-cp-bg p-5 sm:p-8",
                                children: "sent" === e ? (0, r.jsxs)("div", {
                                    className: "flex flex-col items-center justify-center py-12 text-center",
                                    children: [(0, r.jsx)("div", {
                                        className: "flex size-16 items-center justify-center rounded-full bg-cp-success/15 mb-4",
                                        children: (0, r.jsx)("svg", {
                                            className: "size-8 text-cp-success-ink",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            strokeWidth: 2,
                                            children: (0, r.jsx)("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                d: "M5 13l4 4L19 7"
                                            })
                                        })
                                    }), (0, r.jsx)("h3", {
                                        className: "text-[20px] font-semibold tracking-[-0.01em] text-cp-ink",
                                        children: s.O.contact.sentTitle
                                    }), (0, r.jsx)("p", {
                                        className: "mt-2 text-sm text-cp-muted",
                                        children: s.O.contact.sentDescription
                                    })]
                                }) : (0, r.jsxs)("form", {
                                    onSubmit: u,
                                    className: "space-y-6",
                                    children: [(0, r.jsxs)("div", {
                                        children: [(0, r.jsx)("label", {
                                            htmlFor: "contact-name",
                                            className: "mb-1.5 block text-[13px] font-medium text-cp-ink",
                                            children: s.O.contact.form.nameLabel
                                        }), (0, r.jsx)("input", {
                                            id: "contact-name",
                                            type: "text",
                                            required: !0,
                                            value: c.name,
                                            onChange: e => d({ ...c,
                                                name: e.target.value
                                            }),
                                            className: `${a.N_} px-3.5 py-2.5 text-[14px]`,
                                            placeholder: s.O.contact.form.namePlaceholder
                                        })]
                                    }), (0, r.jsxs)("div", {
                                        children: [(0, r.jsx)("label", {
                                            htmlFor: "contact-email",
                                            className: "mb-1.5 block text-[13px] font-medium text-cp-ink",
                                            children: s.O.contact.form.emailLabel
                                        }), (0, r.jsx)("input", {
                                            id: "contact-email",
                                            type: "email",
                                            required: !0,
                                            value: c.email,
                                            onChange: e => d({ ...c,
                                                email: e.target.value
                                            }),
                                            className: `${a.N_} px-3.5 py-2.5 text-[14px]`,
                                            placeholder: s.O.contact.form.emailPlaceholder
                                        })]
                                    }), (0, r.jsxs)("div", {
                                        children: [(0, r.jsx)("label", {
                                            htmlFor: "contact-message",
                                            className: "mb-1.5 block text-[13px] font-medium text-cp-ink",
                                            children: s.O.contact.form.messageLabel
                                        }), (0, r.jsx)("textarea", {
                                            id: "contact-message",
                                            required: !0,
                                            rows: 5,
                                            value: c.message,
                                            onChange: e => d({ ...c,
                                                message: e.target.value
                                            }),
                                            className: `${a.N_} resize-none px-3.5 py-2.5 text-[14px]`,
                                            placeholder: s.O.contact.form.messagePlaceholder
                                        })]
                                    }), n ? (0, r.jsx)("div", {
                                        className: "rounded-xl border border-cp-danger/30 bg-cp-danger/10 px-4 py-3 text-sm text-cp-danger-ink",
                                        children: n
                                    }) : null, (0, r.jsx)(l.$, {
                                        type: "submit",
                                        variant: "primary",
                                        size: "lg",
                                        className: "w-full",
                                        loading: "sending" === e,
                                        children: "sending" === e ? s.O.contact.form.sendingCta : s.O.contact.form.sendCta
                                    })]
                                })
                            })]
                        })]
                    })
                })
            }
        },
        27700: (e, t, n) => {
            "use strict";
            n.d(t, {
                SupportAskNow: () => l
            });
            var r = n(73365),
                a = n(1521),
                i = n(9388),
                s = n(67972);

            function l({
                compact: e = !1
            }) {
                let [t, n] = (0, a.useState)(!1);
                if ((0, a.useEffect)(() => {
                        if (!(0, s.IO)(window.location)) return;
                        let e = !1,
                            t = (0, s.dV)(() => {
                                (0, s.KD)().then(t => {
                                    !e && t.enabled && n(!0)
                                })
                            });
                        return () => {
                            e = !0, t()
                        }
                    }, []), !t) return null;
                let o = () => {
                    window.dispatchEvent(new CustomEvent(s.Qy, {
                        detail: {}
                    }))
                };
                return e ? (0, r.jsx)("button", {
                    type: "button",
                    onClick: o,
                    className: "inline-flex h-10 cursor-pointer items-center rounded-full px-3 text-[14px] font-medium text-cp-muted transition-colors hover:text-cp-ink lg:hidden",
                    children: "Help"
                }) : (0, r.jsx)("div", {
                    className: "mx-auto max-w-3xl px-4 pt-10 sm:px-6",
                    children: (0, r.jsxs)("div", {
                        className: "flex flex-col gap-4 rounded-xl border border-cp-line bg-cp-bg p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6",
                        children: [(0, r.jsxs)("div", {
                            className: "min-w-0",
                            children: [(0, r.jsx)("p", {
                                className: "text-[15px] font-semibold text-cp-ink",
                                children: "Need a quick answer?"
                            }), (0, r.jsx)("p", {
                                className: "mt-1 text-[13.5px] leading-relaxed text-cp-muted",
                                children: "Kiara, our assistant, can help with templates, payments and your pages right away. You can still write to us below."
                            })]
                        }), (0, r.jsx)(i.$, {
                            variant: "secondary",
                            size: "sm",
                            onClick: o,
                            className: "self-start sm:self-auto",
                            children: "Ask Kiara"
                        })]
                    })
                })
            }
        },
        29267: (e, t, n) => {
            "use strict";
            n.d(t, {
                Zc: () => a,
                mv: () => i
            });
            let r = new Set(["www.cutiepage.in", "dash.cutiepage.in"]);

            function a(e) {
                let t;
                if ("u" < typeof location) return null;
                let n = location.hostname;
                return r.has(n) || "/api/analytics/collect" === e && "https:" === location.protocol && (t = /^([a-z0-9-]+)\.cutiepage\.app$/.exec(n) ? .[1]) && "render" !== t && "ads" !== t ? "https://chat.cutiepage.in" + e : null
            }

            function i(e) {
                return !e.ok && 429 !== e.status
            }
        },
        46788: (e, t, n) => {
            "use strict";
            n.d(t, {
                ContactFaq: () => s
            });
            var r = n(73365),
                a = n(1521),
                i = n(26752);

            function s() {
                let e = i.O.contact.faq,
                    [t, n] = (0, a.useState)(null);
                return (0, r.jsx)("section", {
                    id: "contact-faq",
                    className: "relative bg-cp-canvas pb-6 pt-4",
                    children: (0, r.jsxs)("div", {
                        className: "relative mx-auto max-w-3xl px-4 sm:px-6",
                        children: [(0, r.jsx)("div", {
                            className: "mb-10 max-w-2xl",
                            children: (0, r.jsx)("h1", {
                                className: "font-semibold text-3xl tracking-[-0.02em] text-cp-ink md:text-4xl",
                                children: e.title
                            })
                        }), (0, r.jsx)("div", {
                            className: "space-y-3",
                            children: e.items.map((e, a) => {
                                let i = t === a;
                                return (0, r.jsxs)("div", {
                                    className: `overflow-hidden rounded-2xl border bg-cp-bg transition-colors duration-300 ${i?"border-cp-ink/15":"border-cp-ink/8 hover:border-cp-ink/15"}`,
                                    children: [(0, r.jsxs)("button", {
                                        type: "button",
                                        onClick: () => n(i ? null : a),
                                        "aria-expanded": i,
                                        className: "flex w-full items-center justify-between gap-4 px-5 py-4 text-left md:px-6 md:py-5",
                                        children: [(0, r.jsx)("span", {
                                            className: "text-[15px] font-medium text-cp-ink md:text-base",
                                            children: e.question
                                        }), (0, r.jsx)("span", {
                                            className: `flex size-7 shrink-0 items-center justify-center rounded-full transition-all duration-300 ${i?"rotate-180 bg-cp-ink text-white":"bg-cp-ink/5 text-cp-ink/50"}`,
                                            children: (0, r.jsx)("svg", {
                                                className: "size-4",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                strokeWidth: 2.5,
                                                children: (0, r.jsx)("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    d: "M19.5 8.25l-7.5 7.5-7.5-7.5"
                                                })
                                            })
                                        })]
                                    }), (0, r.jsx)("div", {
                                        className: `grid transition-[grid-template-rows,opacity] duration-300 ease-out ${i?"grid-rows-[1fr] opacity-100":"grid-rows-[0fr] opacity-0"}`,
                                        children: (0, r.jsx)("div", {
                                            className: "overflow-hidden",
                                            children: (0, r.jsx)("p", {
                                                className: "px-5 pb-4 text-sm leading-7 text-cp-ink/65 md:px-6 md:pb-5 md:text-[15px]",
                                                children: e.answer
                                            })
                                        })
                                    })]
                                }, e.question)
                            })
                        })]
                    })
                })
            }
        },
        54872: (e, t, n) => {
            "use strict";
            n.d(t, {
                cn: () => i
            });
            var r = n(68662),
                a = n(35490);

            function i(...e) {
                return (0, a.QP)((0, r.$)(e))
            }
        },
        67972: (e, t, n) => {
            "use strict";
            n.d(t, {
                Ar: () => b,
                EI: () => y,
                FS: () => $,
                IO: () => f,
                KD: () => E,
                On: () => s,
                QB: () => l,
                Qy: () => a,
                RY: () => v,
                Te: () => I,
                ZM: () => p,
                dV: () => L,
                h2: () => u,
                hT: () => _,
                if: () => g,
                j7: () => h,
                mx: () => c,
                pI: () => o,
                x6: () => z
            });
            var r = n(29267);
            let a = "cp-support:open",
                i = "cp_support_status_v1",
                s = "cp_support_conversation_v1",
                l = "(max-width: 639px)",
                o = {
                    default: "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(1rem,env(safe-area-inset-bottom))+4.75rem)] max-h-[calc(100dvh-12rem)]",
                    editor: "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(0.75rem,env(safe-area-inset-bottom))+10.25rem)] max-h-[calc(100dvh-11.5rem)] lg:right-5 lg:bottom-[9.75rem] lg:max-h-[calc(100dvh-10.75rem)]",
                    "editor-v2": "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(0.75rem,env(safe-area-inset-bottom))+10.25rem)] max-h-[calc(100dvh-11.5rem)] lg:right-[calc(var(--cp-kiara-editor-right,300px)+1.25rem)] lg:bottom-24 lg:max-h-[calc(100dvh-7rem)]",
                    "app-shell": "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(env(safe-area-inset-bottom)+9.75rem)] max-h-[calc(100dvh-15rem)] md:bottom-[calc(max(1rem,env(safe-area-inset-bottom))+4.75rem)] md:max-h-[calc(100dvh-12rem)]",
                    checkout: "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(1rem,env(safe-area-inset-bottom))+4.75rem)] max-h-[calc(100dvh-12rem)]"
                },
                c = {
                    cache: "no-store",
                    credentials: "same-origin",
                    headers: {
                        accept: "application/json"
                    }
                },
                d = null;

            function u(e) {
                let t = e ? .now ? ? Date.now();
                if (d && t - d.at < 15e3) return;
                let n = e ? .fetchImpl ? ? ("function" == typeof fetch ? fetch : null);
                if (!n) return;
                let r = n("/api/support/history", c);
                r.catch(() => {}), d = {
                    at: t,
                    response: r
                }
            }

            function p(e = Date.now()) {
                let t = d;
                return d = null, t && e - t.at < 15e3 ? t.response : null
            }
            let m = new Set(["www.cutiepage.in", "cutiepage.in", "dash.cutiepage.in", "localhost", "127.0.0.1"]),
                x = ["/preview", "/pv"];

            function h(e) {
                let t = (e || "/").toLowerCase();
                for (let e of x)
                    if (t === e || t.startsWith(`${e}/`)) return !1;
                return !0
            }

            function f(e) {
                var t;
                return t = e.hostname, m.has(t.trim().toLowerCase().replace(/\.$/, "")) && h(e.pathname)
            }

            function v() {
                try {
                    return window.sessionStorage
                } catch {
                    return null
                }
            }

            function b() {
                try {
                    return window.localStorage
                } catch {
                    return null
                }
            }

            function g(e, t) {
                if (!e) return null;
                try {
                    return e.getItem(t)
                } catch {
                    return null
                }
            }

            function y(e, t, n) {
                if (e) try {
                    e.setItem(t, n)
                } catch {}
            }

            function j(e, t) {
                if (e ? .removeItem) try {
                    e.removeItem(t)
                } catch {}
            }
            let w = {
                enabled: !1,
                signedIn: !1,
                pageEdits: !1
            };

            function N(e) {
                return "string" == typeof e && e.startsWith("https://") ? {
                    chatUrl: e
                } : {}
            }

            function k(e) {
                let t = "string" == typeof e ? e.trim().slice(0, 24) : "";
                return t ? {
                    firstName: t
                } : {}
            }

            function O(e, t, n) {
                y(e, i, JSON.stringify({
                    at: n,
                    enabled: t.enabled,
                    signedIn: t.signedIn,
                    pageEdits: !0 === t.pageEdits,
                    ...N(t.chatUrl),
                    ...k(t.firstName)
                }))
            }
            let C = null;

            function E(e) {
                let t = e ? .storage === void 0 ? v() : e.storage,
                    n = e ? .now ? ? Date.now,
                    a = function(e, t) {
                        let n = g(e, i);
                        if (!n) return null;
                        try {
                            let e = JSON.parse(n);
                            if ("number" != typeof e.at || "boolean" != typeof e.enabled) return null;
                            let r = t - e.at,
                                a = e.enabled ? 3e5 : 6e4;
                            if (r < 0 || r >= a) return null;
                            return {
                                enabled: e.enabled,
                                signedIn: !0 === e.signedIn,
                                pageEdits: !0 === e.pageEdits,
                                ...N(e.chatUrl),
                                ...k(e.firstName)
                            }
                        } catch {
                            return null
                        }
                    }(t, n());
                if (a) return Promise.resolve(a);
                if (C) return C;
                let s = e ? .fetchImpl ? ? ("function" == typeof fetch ? fetch : null);
                return s ? C = (async () => {
                    try {
                        var e;
                        let a = (0, r.Zc)("/api/support/status"),
                            i = (e, t) => s(e, {
                                cache: "no-store",
                                credentials: t,
                                headers: {
                                    accept: "application/json"
                                }
                            }),
                            l = a ? await i(a, "include").catch(() => null) : null;
                        if ((!l || (0, r.mv)(l)) && (l = await i("/api/support/status", "same-origin")), 404 === l.status) return O(t, w, n()), w;
                        if (!l.ok) return w;
                        let o = (e = await l.json().catch(() => null)) && "object" == typeof e ? {
                            enabled: !0 === e.enabled,
                            signedIn: !0 === e.signedIn,
                            pageEdits: !0 === e.pageEdits,
                            ...N(e.chatUrl),
                            ...k(e.firstName)
                        } : w;
                        return O(t, o, n()), o
                    } catch {
                        return w
                    } finally {
                        C = null
                    }
                })() : Promise.resolve(w)
            }

            function I(e = v()) {
                j(e, i)
            }
            let S = "cp_support_human";

            function _(e, t) {
                y(e, S, JSON.stringify(t))
            }

            function z(e) {
                j(e, S)
            }
            async function $(e) {
                let t = e ? .storage === void 0 ? b() : e.storage;
                try {
                    if (!g(t, S)) return !1;
                    let n = function(e) {
                        let t = g(e, S);
                        if (!t) return null;
                        try {
                            let e = JSON.parse(t);
                            if ("string" != typeof e.conversationId || !e.conversationId || e.conversationId.length > 64 || "string" != typeof e.seenAt || Number.isNaN(Date.parse(e.seenAt))) return null;
                            return {
                                conversationId: e.conversationId,
                                seenAt: e.seenAt
                            }
                        } catch {
                            return null
                        }
                    }(t);
                    if (!n) return z(t), !1;
                    let r = e ? .fetchImpl ? ? ("function" == typeof fetch ? fetch : null);
                    if (!r) return !1;
                    let a = new URLSearchParams({
                            conversationId: n.conversationId,
                            after: n.seenAt
                        }),
                        i = await r(`/api/support/history?${a.toString()}`, {
                            cache: "no-store",
                            credentials: "same-origin",
                            headers: {
                                accept: "application/json"
                            }
                        });
                    if (!i.ok) return (403 === i.status || 404 === i.status) && z(t), !1;
                    let s = await i.json().catch(() => null);
                    if (!s || "object" != typeof s) return !1;
                    if (s.conversationId !== n.conversationId) return z(t), !1;
                    return !0 !== s.humanActive && z(t), Array.isArray(s.items) && s.items.some(e => !!e && "object" == typeof e && "agent" === e.kind)
                } catch {
                    return !1
                }
            }

            function L(e, t = 2e3) {
                let n = window;
                if ("function" == typeof n.requestIdleCallback) {
                    let r = n.requestIdleCallback(e, {
                        timeout: t
                    });
                    return () => n.cancelIdleCallback ? .(r)
                }
                let r = window.setTimeout(e, t);
                return () => window.clearTimeout(r)
            }
        },
        92166: (e, t, n) => {
            "use strict";
            let r, a;
            n.d(t, {
                DX: () => c,
                xV: () => u
            });
            var i, s = n(1521),
                l = n.t(s, 2);

            function o(e, t) {
                if ("function" == typeof e) return e(t);
                null != e && (e.current = t)
            }
            var c = (i = "Slot", (r = s.forwardRef((e, t) => {
                    var n;
                    let r, a, {
                            children: l,
                            ...c
                        } = e,
                        u = null,
                        m = !1,
                        b = [];
                    x(l) && "function" == typeof v && (l = v(l._payload)), s.Children.forEach(l, e => {
                        var t;
                        if (t = e, s.isValidElement(t) && "function" == typeof t.type && "__radixId" in t.type && t.type.__radixId === d) {
                            m = !0;
                            let t = "child" in e.props ? e.props.child : e.props.children;
                            x(t) && "function" == typeof v && (t = v(t._payload)), u = p(e, t), b.push(u ? .props ? .children)
                        } else b.push(e)
                    }), u ? u = s.cloneElement(u, void 0, b) : !m && 1 === s.Children.count(l) && s.isValidElement(l) && (u = l);
                    let g = u ? (n = u, (a = (r = Object.getOwnPropertyDescriptor(n.props, "ref") ? .get) && "isReactWarning" in r && r.isReactWarning) ? n.ref : (a = (r = Object.getOwnPropertyDescriptor(n, "ref") ? .get) && "isReactWarning" in r && r.isReactWarning) ? n.props.ref : n.props.ref || n.ref) : void 0,
                        y = function(...e) {
                            return s.useCallback(function(...e) {
                                return t => {
                                    let n = !1,
                                        r = e.map(e => {
                                            let r = o(e, t);
                                            return n || "function" != typeof r || (n = !0), r
                                        });
                                    if (n) return () => {
                                        for (let t = 0; t < r.length; t++) {
                                            let n = r[t];
                                            "function" == typeof n ? n() : o(e[t], null)
                                        }
                                    }
                                }
                            }(...e), e)
                        }(t, g);
                    if (!u) {
                        if (l || 0 === l) throw Error(m ? f(i) : h(i));
                        return l
                    }
                    let j = function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let a = e[r],
                                i = t[r];
                            /^on[A-Z]/.test(r) ? a && i ? n[r] = (...e) => {
                                let t = i(...e);
                                return a(...e), t
                            } : a && (n[r] = a) : "style" === r ? n[r] = { ...a,
                                ...i
                            } : "className" === r && (n[r] = [a, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(c, u.props ? ? {});
                    return u.type !== s.Fragment && (j.ref = t ? y : g), s.cloneElement(u, j)
                })).displayName = `${i}.Slot`, r),
                d = Symbol.for("radix.slottable"),
                u = ((a = e => "child" in e ? e.children(e.child) : e.children).displayName = "Slottable.Slottable", a.__radixId = d, a),
                p = (e, t) => {
                    if ("child" in e.props) {
                        let t = e.props.child;
                        return s.isValidElement(t) ? s.cloneElement(t, void 0, e.props.children(t.props.children)) : null
                    }
                    return s.isValidElement(t) ? t : null
                },
                m = Symbol.for("react.lazy");

            function x(e) {
                var t;
                return null != e && "object" == typeof e && "$$typeof" in e && e.$$typeof === m && "_payload" in e && "object" == typeof(t = e._payload) && null !== t && "then" in t
            }
            var h = e => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`,
                f = e => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`,
                v = l[" use ".trim().toString()]
        }
    },
    e => {
        e.O(0, [84327, 26752, 2347, 15158, 77358], () => e(e.s = 8152)), _N_E = e.O()
    }
]);