(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [36391], {
        3779: (e, t, s) => {
            "use strict";
            s.d(t, {
                $H: () => r,
                D4: () => n,
                UE: () => i
            });
            let r = "view",
                i = "category";

            function n(e) {
                return !!(e.has("category") || e.has("price")) || e.get(r) !== i
            }
        },
        9411: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => r
            });
            let r = (0, s(96296).A)("arrow-up-right", [
                ["path", {
                    d: "M7 7h10v10",
                    key: "1tivn9"
                }],
                ["path", {
                    d: "M7 17 17 7",
                    key: "1vkiza"
                }]
            ])
        },
        9943: (e, t, s) => {
            "use strict";
            s.d(t, {
                M: () => i
            });
            var r = s(1521);

            function i(e) {
                let t = (0, r.useRef)(null);
                return null === t.current && (t.current = e()), t.current
            }
        },
        17264: (e, t, s) => {
            "use strict";
            s.d(t, {
                AuraFilmLayer: () => x
            });
            var r = s(73365),
                i = s(1521),
                n = s(54872);

            function a({
                film: e,
                className: t
            }) {
                let [s, i, l] = e.placeholder.gradient;
                return (0, r.jsx)("div", {
                    "aria-hidden": !0,
                    className: (0, n.cn)("pointer-events-none absolute inset-0 overflow-hidden", t),
                    style: {
                        backgroundColor: i,
                        backgroundImage: `linear-gradient(180deg, ${s}, ${i}, ${l})`
                    },
                    children: (0, r.jsx)("div", {
                        className: "absolute -inset-10 bg-cover bg-center",
                        style: {
                            backgroundImage: `url("${e.placeholder.lqip}")`,
                            filter: "blur(28px)",
                            transform: "scale(1.08)"
                        }
                    })
                })
            }
            var l = s(91466),
                o = s(96220);

            function c() {
                return navigator.connection
            }

            function d() {
                let e = c();
                if (!e) return !1;
                if (e.saveData) return !0;
                let t = e.effectiveType;
                return "slow-2g" === t || "2g" === t || "3g" === t
            }

            function p(e) {
                let t = c();
                return t ? .addEventListener ? .("change", e), () => t ? .removeEventListener ? .("change", e)
            }

            function u() {
                return () => {}
            }
            let m = "(max-aspect-ratio: 4/5)";

            function x({
                className: e
            }) {
                let t = (0, i.useRef)(null),
                    s = (0, i.useSyncExternalStore)(u, () => !0, () => !1),
                    c = (0, o.Ub)(m),
                    f = (0, o.Ub)("(prefers-reduced-motion: reduce)"),
                    g = (0, i.useSyncExternalStore)(p, d, () => !1),
                    b = function(e = 600) {
                        let [t, s] = (0, i.useState)(!1);
                        return (0, i.useEffect)(() => {
                            let t = 0,
                                r = () => {
                                    t = window.setTimeout(() => s(!0), e)
                                };
                            return "complete" === document.readyState ? (r(), () => window.clearTimeout(t)) : (window.addEventListener("load", r, {
                                once: !0
                            }), () => {
                                window.removeEventListener("load", r), window.clearTimeout(t)
                            })
                        }, [e]), t
                    }(),
                    v = function(e) {
                        let [t, s] = (0, i.useState)(() => "u" < typeof IntersectionObserver);
                        return (0, i.useEffect)(() => {
                            let t = e.current;
                            if (!t || "u" < typeof IntersectionObserver) return;
                            let r = new IntersectionObserver(e => {
                                e.some(e => e.isIntersecting) && (s(!0), r.disconnect())
                            }, {
                                rootMargin: "600px"
                            });
                            return r.observe(t), () => r.disconnect()
                        }, [e]), t
                    }(t),
                    y = c ? "mobile" : "desktop",
                    {
                        desktop: w,
                        mobile: j
                    } = l.dk;
                return (0, r.jsxs)("div", {
                    ref: t,
                    className: (0, n.cn)("absolute inset-0", e),
                    children: [(0, r.jsx)(a, {
                        film: j,
                        className: "hidden [@media(max-aspect-ratio:4/5)]:block"
                    }), (0, r.jsx)(a, {
                        film: w,
                        className: "[@media(max-aspect-ratio:4/5)]:hidden"
                    }), (0, r.jsxs)("picture", {
                        className: "contents",
                        children: [(0, r.jsx)("source", {
                            media: m,
                            type: "image/avif",
                            srcSet: j.posterAvif
                        }), (0, r.jsx)("source", {
                            media: m,
                            type: "image/webp",
                            srcSet: j.posterWebp
                        }), (0, r.jsx)("source", {
                            type: "image/avif",
                            srcSet: w.posterAvif
                        }), (0, r.jsx)("source", {
                            type: "image/webp",
                            srcSet: w.posterWebp
                        }), (0, r.jsx)("img", {
                            src: w.posterJpg,
                            width: w.width,
                            height: w.height,
                            alt: "",
                            loading: "lazy",
                            decoding: "async",
                            draggable: !1,
                            className: "absolute inset-0 h-full w-full object-cover object-center"
                        })]
                    }), s && b && v && !f && !g ? (0, r.jsx)(h, {
                        variant: y
                    }, y) : null]
                })
            }

            function h({
                variant: e
            }) {
                let t = (0, i.useRef)(null),
                    [s, a] = (0, i.useState)(!1),
                    [o, c] = (0, i.useState)(!1),
                    d = l.dk[e];
                if ((0, i.useEffect)(() => {
                        let e = t.current;
                        if (!e || "u" < typeof IntersectionObserver) return;
                        let s = new IntersectionObserver(t => {
                            let s = t[t.length - 1];
                            s && (s.isIntersecting && s.intersectionRatio >= .05 ? e.play().catch(() => {}) : e.pause())
                        }, {
                            threshold: .05
                        });
                        return s.observe(e), () => s.disconnect()
                    }, []), o) return null;
                let p = () => c(!0);
                return (0, r.jsxs)("video", {
                    ref: t,
                    autoPlay: !0,
                    muted: !0,
                    loop: !0,
                    playsInline: !0,
                    preload: "none",
                    disablePictureInPicture: !0,
                    "aria-hidden": !0,
                    tabIndex: -1,
                    onPlaying: () => a(!0),
                    onError: p,
                    className: (0, n.cn)("absolute inset-0 h-full w-full object-cover object-center transition-opacity duration-1000", s ? "opacity-100" : "opacity-0"),
                    children: [(0, r.jsx)("source", {
                        src: d.webm,
                        type: "video/webm"
                    }), (0, r.jsx)("source", {
                        src: d.mp4,
                        type: "video/mp4",
                        onError: p
                    })]
                })
            }
        },
        17615: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => r
            });
            let r = (0, s(96296).A)("layers", [
                ["path", {
                    d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",
                    key: "zw3jo"
                }],
                ["path", {
                    d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",
                    key: "1wduqc"
                }],
                ["path", {
                    d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",
                    key: "kqbvx6"
                }]
            ])
        },
        22868: (e, t, s) => {
            "use strict";
            s.d(t, {
                L: () => h
            });
            var r = s(61624),
                i = s(27597),
                n = s(20154),
                a = s(99296),
                l = s(1521),
                o = s(94600),
                c = s(95778),
                d = s(9943),
                p = s(31011);
            let u = () => ({
                    scrollX: (0, r.OQ)(0),
                    scrollY: (0, r.OQ)(0),
                    scrollXProgress: (0, r.OQ)(0),
                    scrollYProgress: (0, r.OQ)(0)
                }),
                m = e => !!e && !e.current;

            function x(e, t, s, r) {
                return {
                    factory: n => {
                        let a, l = () => {
                            m(s) || m(r) ? i.k.read(l) : a = (0, o.W)(n, { ...t,
                                axis: e,
                                container: s ? .current || void 0,
                                target: r ? .current || void 0
                            })
                        };
                        return i.k.read(l), () => {
                            (0, i.c)(l), a ? .()
                        }
                    },
                    times: [0, 1],
                    keyframes: [0, 1],
                    ease: e => e,
                    duration: 1
                }
            }

            function h({
                container: e,
                target: t,
                ...s
            } = {}) {
                var r;
                let f = (0, d.M)(u);
                r = s.offset, !("u" < typeof window) && (t ? (0, n.d)() && !!(0, c.G)(r) : (0, n.J)()) && (f.scrollXProgress.accelerate = x("x", s, e, t), f.scrollYProgress.accelerate = x("y", s, e, t));
                let g = (0, l.useRef)(null),
                    b = (0, l.useRef)(!1),
                    v = (0, l.useCallback)(() => (g.current = (0, o.W)((e, {
                        x: t,
                        y: s
                    }) => {
                        f.scrollX.set(t.current), f.scrollXProgress.set(t.progress), f.scrollY.set(s.current), f.scrollYProgress.set(s.progress)
                    }, { ...s,
                        container: e ? .current || void 0,
                        target: t ? .current || void 0
                    }), () => {
                        g.current ? .()
                    }), [e, t, JSON.stringify(s.offset)]);
                return (0, p.E)(() => {
                    if (b.current = !1, !(m(e) || m(t))) return v();
                    b.current = !0
                }, [v]), (0, l.useEffect)(() => {
                    let s;
                    if (!b.current) return;
                    let r = () => {
                        let r = m(e),
                            i = m(t);
                        (0, a.V)(!r, "Container ref is defined but not hydrated", "use-scroll-ref"), (0, a.V)(!i, "Target ref is defined but not hydrated", "use-scroll-ref"), r || i || (s = v())
                    };
                    return i.k.read(r), () => {
                        (0, i.c)(r), s ? .()
                    }
                }, [v]), f
            }
        },
        26821: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => r
            });
            let r = (0, s(96296).A)("check", [
                ["path", {
                    d: "M20 6 9 17l-5-5",
                    key: "1gmf2c"
                }]
            ])
        },
        29717: (e, t, s) => {
            "use strict";
            var r = s(21505);
            s.o(r, "usePathname") && s.d(t, {
                usePathname: function() {
                    return r.usePathname
                }
            }), s.o(r, "useRouter") && s.d(t, {
                useRouter: function() {
                    return r.useRouter
                }
            }), s.o(r, "useSearchParams") && s.d(t, {
                useSearchParams: function() {
                    return r.useSearchParams
                }
            })
        },
        31011: (e, t, s) => {
            "use strict";
            s.d(t, {
                E: () => i
            });
            var r = s(1521);
            let i = "u" > typeof window ? r.useLayoutEffect : r.useEffect
        },
        31690: (e, t, s) => {
            Promise.resolve().then(s.bind(s, 17264)), Promise.resolve().then(s.bind(s, 26613)), Promise.resolve().then(s.bind(s, 93406)), Promise.resolve().then(s.bind(s, 76777)), Promise.resolve().then(s.bind(s, 65859)), Promise.resolve().then(s.bind(s, 99719)), Promise.resolve().then(s.bind(s, 42876)), Promise.resolve().then(s.bind(s, 90024)), Promise.resolve().then(s.bind(s, 21196)), Promise.resolve().then(s.bind(s, 55684)), Promise.resolve().then(s.bind(s, 51342)), Promise.resolve().then(s.bind(s, 94612)), Promise.resolve().then(s.bind(s, 4525)), Promise.resolve().then(s.t.bind(s, 99568, 23)), Promise.resolve().then(s.t.bind(s, 38137, 23))
        },
        34913: (e, t, s) => {
            "use strict";
            s.d(t, {
                X: () => o,
                s: () => l
            });
            var r = s(73365),
                i = s(99568),
                n = s.n(i),
                a = s(54872);

            function l({
                title: e,
                options: t,
                activeValue: s,
                allValue: i = "all",
                hrefFor: o,
                defaultOpen: c = !0
            }) {
                let d = s === i ? null : t.find(e => e.value === s) ? .label;
                return (0, r.jsxs)("details", {
                    open: c || null != d,
                    className: "group/filter [interpolate-size:allow-keywords] details-content:-mx-1 details-content:h-0 details-content:overflow-hidden details-content:px-1 details-content:pb-1 details-content:opacity-0 details-content:transition-[height,opacity,content-visibility] details-content:duration-200 details-content:ease-out details-content:[transition-behavior:allow-discrete] open:details-content:h-auto open:details-content:opacity-100 motion-reduce:details-content:transition-none",
                    children: [(0, r.jsxs)("summary", {
                        className: "flex cursor-pointer list-none items-center gap-1.5 rounded-md py-1 text-[12px] font-semibold text-cp-ink focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-cp-select [&::-webkit-details-marker]:hidden",
                        children: [(0, r.jsx)("span", {
                            children: e
                        }), d ? (0, r.jsxs)("span", {
                            className: "min-w-0 truncate font-medium text-cp-primary",
                            children: ["\xb7 ", d]
                        }) : null, (0, r.jsx)("svg", {
                            "aria-hidden": !0,
                            viewBox: "0 0 12 12",
                            className: "ml-auto h-3 w-3 shrink-0 text-cp-muted transition-transform duration-150 group-open/filter:rotate-180 motion-reduce:transition-none",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "1.6",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            children: (0, r.jsx)("path", {
                                d: "M3 4.5l3 3 3-3"
                            })
                        })]
                    }), (0, r.jsx)("div", {
                        className: "mt-1.5 flex flex-wrap gap-1",
                        children: t.map(e => {
                            if (e.value === i) return null;
                            let t = s === e.value;
                            return 0 !== e.count || t ? (0, r.jsxs)(n(), {
                                href: t ? o(i) : o(e.value),
                                scroll: !1,
                                prefetch: !1,
                                "aria-current": t ? "true" : void 0,
                                className: (0, a.cn)("inline-flex h-7 items-center gap-1 rounded-full border px-2.5 text-[12.5px] transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-cp-select", t ? "border-cp-select/40 bg-cp-primary-soft font-medium text-cp-primary" : "border-cp-line bg-cp-bg text-cp-muted hover:bg-cp-subtle hover:text-cp-ink"),
                                children: [(0, r.jsx)("span", {
                                    children: e.label
                                }), t ? (0, r.jsx)("svg", {
                                    "aria-hidden": !0,
                                    viewBox: "0 0 12 12",
                                    className: "h-2.5 w-2.5 shrink-0",
                                    fill: "none",
                                    stroke: "currentColor",
                                    strokeWidth: "1.8",
                                    strokeLinecap: "round",
                                    children: (0, r.jsx)("path", {
                                        d: "M2.5 2.5l7 7M9.5 2.5l-7 7"
                                    })
                                }) : (0, r.jsx)("span", {
                                    className: "text-[11px] tabular-nums text-cp-faint",
                                    children: e.count
                                })]
                            }, e.value) : null
                        })
                    })]
                })
            }

            function o({
                value: e,
                onChange: t,
                placeholder: s,
                className: i
            }) {
                return (0, r.jsxs)("div", {
                    className: (0, a.cn)("relative", i),
                    children: [(0, r.jsxs)("svg", {
                        "aria-hidden": "true",
                        viewBox: "0 0 24 24",
                        className: "pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-cp-muted",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "1.8",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        children: [(0, r.jsx)("circle", {
                            cx: "11",
                            cy: "11",
                            r: "7"
                        }), (0, r.jsx)("line", {
                            x1: "21",
                            y1: "21",
                            x2: "16.65",
                            y2: "16.65"
                        })]
                    }), (0, r.jsx)("input", {
                        type: "text",
                        value: e,
                        onChange: e => t(e.target.value),
                        placeholder: s,
                        "aria-label": s,
                        className: "h-10 w-full rounded-full border border-cp-line bg-cp-bg pr-9 pl-10 text-[14px] text-cp-ink outline-none transition-colors duration-150 placeholder:text-cp-faint focus:border-cp-line-strong focus:ring-2 focus:ring-cp-select/30"
                    }), e ? (0, r.jsx)("button", {
                        type: "button",
                        "aria-label": "Clear search",
                        onClick: () => t(""),
                        className: "absolute right-2.5 top-1/2 flex size-5 -translate-y-1/2 items-center justify-center rounded-full text-cp-muted transition-colors duration-150 hover:bg-cp-subtle hover:text-cp-ink",
                        children: (0, r.jsxs)("svg", {
                            "aria-hidden": "true",
                            viewBox: "0 0 24 24",
                            className: "h-3.5 w-3.5",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            children: [(0, r.jsx)("line", {
                                x1: "6",
                                y1: "6",
                                x2: "18",
                                y2: "18"
                            }), (0, r.jsx)("line", {
                                x1: "18",
                                y1: "6",
                                x2: "6",
                                y2: "18"
                            })]
                        })
                    }) : null]
                })
            }
        },
        37731: (e, t, s) => {
            "use strict";

            function r(e) {
                let t = e / 100;
                return `\u20b9${t.toLocaleString("en-IN",{minimumFractionDigits:2*(t%1!=0),maximumFractionDigits:2})}`
            }

            function i(e, t) {
                return !t || t <= e ? 0 : Math.floor((t - e) / t * 100)
            }
            s.d(t, {
                N9: () => i,
                ym: () => r
            })
        },
        38277: (e, t, s) => {
            "use strict";
            s.d(t, {
                Hz: () => d,
                Ur: () => j
            });
            var r = s(73365),
                i = s(1521),
                n = s(99568),
                a = s.n(n),
                l = s(69580),
                o = s(54872);
            let c = "gifts:cart-updated";

            function d() {
                window.dispatchEvent(new CustomEvent(c))
            }
            let p = "gifts:cart-count",
                u = 0,
                m = 0,
                x = null,
                h = new Set,
                f = !1;

            function g(e) {
                return h.add(e), () => h.delete(e)
            }

            function b() {
                if (!f && (f = !0, 0 === u)) {
                    let e = function() {
                        try {
                            let e = window.sessionStorage.getItem(p);
                            if (!e) return null;
                            let t = JSON.parse(e);
                            if ("number" == typeof t ? .value && "number" == typeof t ? .at) return t
                        } catch {}
                        return null
                    }();
                    e && (u = e.value, m = e.at)
                }
                return u
            }

            function v() {
                return 0
            }

            function y(e) {
                let t = Date.now();
                return !e && t - m < 6e4 ? Promise.resolve() : x || (x = (async () => {
                    try {
                        let e = await fetch("/api/gifts/cart?count=1", {
                            cache: "no-store"
                        });
                        if (!e.ok) return;
                        let t = await e.json().catch(() => null),
                            s = t ? .data ? .itemCount;
                        "number" == typeof s && function(e, t) {
                            u = e, m = t;
                            try {
                                window.sessionStorage.setItem(p, JSON.stringify({
                                    value: e,
                                    at: t
                                }))
                            } catch {}
                            h.forEach(e => e())
                        }(s, Date.now())
                    } catch {} finally {
                        x = null
                    }
                })())
            }

            function w({
                count: e,
                className: t
            }) {
                return 0 === e ? null : (0, r.jsx)("span", {
                    className: (0, o.cn)("pointer-events-none absolute flex min-w-[16px] items-center justify-center rounded-full bg-cp-primary px-1 py-px text-[10px] font-bold leading-[14px] text-white", t),
                    "aria-hidden": !0,
                    children: e > 9 ? "9+" : e
                })
            }

            function j({
                variant: e,
                size: t = "md",
                collapsed: s = !1,
                onNavigate: n
            }) {
                let d, p = (d = (0, i.useSyncExternalStore)(g, b, v), (0, i.useEffect)(() => {
                        y(!1);
                        let e = () => void y(!0);
                        return window.addEventListener(c, e), () => window.removeEventListener(c, e)
                    }, []), d),
                    u = p > 0 ? `Cart, ${p} item${1===p?"":"s"}` : "Cart";
                if ("header" === e) return (0, r.jsxs)(a(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    "aria-label": u,
                    onClick: n,
                    className: "relative inline-flex size-10 items-center justify-center rounded-full text-cp-ink/80 transition-colors duration-150 hover:bg-white/70 hover:text-cp-ink",
                    children: [(0, r.jsx)(l.A, {
                        className: "size-[21px]",
                        strokeWidth: 1.9,
                        "aria-hidden": !0
                    }), (0, r.jsx)(w, {
                        count: p,
                        className: "right-0.5 top-0.5"
                    })]
                });
                if ("topbar" === e) return (0, r.jsxs)(a(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    "aria-label": u,
                    className: "relative ml-auto inline-flex size-10 items-center justify-center text-cp-ink/80 transition-colors duration-150 hover:text-cp-ink",
                    children: [(0, r.jsx)(l.A, {
                        className: "size-[21px]",
                        strokeWidth: 1.9,
                        "aria-hidden": !0
                    }), (0, r.jsx)(w, {
                        count: p,
                        className: "right-0 top-0.5"
                    })]
                });
                let m = "lg" === t;
                return (0, r.jsxs)(a(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    onClick: n,
                    title: s ? u : void 0,
                    "aria-label": s ? u : void 0,
                    className: (0, o.cn)("group flex items-center rounded-xl transition-colors duration-150", "font-medium text-cp-ink/80 hover:bg-cp-subtle hover:text-cp-ink", s ? "justify-center px-0 py-3" : m ? "gap-4 px-4 py-3.5 text-[16px]" : "gap-3.5 px-3.5 py-3 text-[14px]"),
                    children: [(0, r.jsxs)("span", {
                        className: "relative shrink-0",
                        children: [(0, r.jsx)(l.A, {
                            className: (0, o.cn)("shrink-0 text-cp-muted", m ? "size-[20px]" : "size-[17px]"),
                            strokeWidth: 1.6,
                            "aria-hidden": !0
                        }), s ? (0, r.jsx)(w, {
                            count: p,
                            className: "-right-2 -top-1.5"
                        }) : null]
                    }), (0, r.jsx)("span", {
                        className: (0, o.cn)("truncate", s && "hidden"),
                        children: "Cart"
                    }), !s && p > 0 ? (0, r.jsx)("span", {
                        className: "ml-auto inline-flex min-w-[20px] items-center justify-center rounded-full bg-cp-primary-soft px-1.5 py-0.5 text-[11px] font-semibold text-cp-primary",
                        "aria-label": `${p} item${1===p?"":"s"} in cart`,
                        children: p > 9 ? "9+" : p
                    }) : null]
                })
            }
        },
        42876: (e, t, s) => {
            "use strict";
            s.d(t, {
                ProductsListing: () => S
            });
            var r = s(73365),
                i = s(99568),
                n = s.n(i),
                a = s(29717),
                l = s(1521),
                o = s(34913),
                c = s(67344),
                d = s(36037),
                p = s(9411),
                u = s(54872);
            let m = ["bg-cp-pastel-butter text-cp-pastel-butter-ink", "bg-cp-pastel-lilac text-cp-pastel-lilac-ink", "bg-cp-primary-soft text-cp-ink", "bg-cp-canvas text-cp-ink"];

            function x({
                stores: e,
                className: t
            }) {
                return e.length ? (0, r.jsx)("ul", {
                    "aria-label": "More templates by price",
                    className: (0, u.cn)("grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4 xl:gap-3", t),
                    children: e.map((e, t) => (0, r.jsx)("li", {
                        children: (0, r.jsxs)(n(), {
                            href: e.href,
                            className: (0, u.cn)("group flex h-full min-h-[148px] flex-col justify-between rounded-3xl p-4 ring-1 ring-cp-line transition-[translate] duration-150 hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-primary motion-reduce:transition-none sm:min-h-[168px] sm:p-5", m[t % m.length]),
                            children: [(0, r.jsx)("span", {
                                className: "text-[12px] font-semibold opacity-80",
                                children: "Explore"
                            }), (0, r.jsxs)("span", {
                                children: [(0, r.jsx)("span", {
                                    className: "block font-display text-[34px] italic leading-none sm:text-[40px]",
                                    children: e.price
                                }), (0, r.jsx)("span", {
                                    className: "mt-1.5 block text-[14px] font-semibold leading-5 sm:text-[15px]",
                                    children: e.name
                                }), (0, r.jsxs)("span", {
                                    className: "mt-0.5 flex items-center justify-between gap-2 text-[12.5px] opacity-80",
                                    children: [e.count, " ", e.unit, (0, r.jsx)("span", {
                                        className: "flex size-7 items-center justify-center rounded-full bg-cp-bg text-cp-primary transition-transform duration-150 group-hover:rotate-45",
                                        children: (0, r.jsx)(p.A, {
                                            "aria-hidden": !0,
                                            className: "size-3.5",
                                            strokeWidth: 2.25
                                        })
                                    })]
                                })]
                            })]
                        })
                    }, e.href))
                }) : null
            }
            var h = s(94505),
                f = s(79151),
                g = s(17615),
                b = s(94612),
                v = s(9388),
                y = s(45421),
                w = s(67892);

            function j({
                eligibleTemplateCount: e,
                amountInr: t = w.bn,
                catalogValueInr: s = 0
            }) {
                let i = Math.max(0, s - t);
                return (0, r.jsxs)(y.Zp, {
                    className: "group flex h-full flex-col overflow-hidden rounded-3xl border border-cp-select/30 bg-cp-bg shadow-none transition-colors duration-150 hover:border-cp-select/50",
                    children: [(0, r.jsxs)(n(), {
                        href: "/products/cutie-pack",
                        className: "block rounded-t-3xl p-2 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-cp-select",
                        children: [(0, r.jsxs)("div", {
                            className: "relative aspect-[16/11] overflow-hidden rounded-2xl bg-cp-canvas",
                            children: [(0, r.jsx)(b.BlurImage, {
                                src: w.c9,
                                alt: `Cutie Pack: all ${e} templates under \u20b9${w.gq} + upcoming templates, five pages each`,
                                fill: !0,
                                sizes: "(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw",
                                className: "object-cover transition-transform duration-300 ease-out group-hover:scale-[1.03] motion-reduce:transition-none"
                            }), (0, r.jsxs)("span", {
                                className: "absolute top-2 left-2 inline-flex items-center gap-1 rounded-full bg-cp-bg px-2 py-0.5 text-[11px] font-semibold text-cp-primary",
                                children: [(0, r.jsx)(g.A, {
                                    className: "size-3",
                                    strokeWidth: 1.75,
                                    "aria-hidden": !0
                                }), "Bundle"]
                            })]
                        }), (0, r.jsx)(y.aR, {
                            className: "flex-1 space-y-0 px-3 pt-3 pb-1 sm:px-4 sm:pt-4",
                            children: (0, r.jsx)("div", {
                                children: (0, r.jsxs)("div", {
                                    className: "min-w-0",
                                    children: [(0, r.jsx)(y.ZB, {
                                        className: "font-sans text-[14px] leading-5 font-semibold tracking-[-0.01em] text-cp-ink transition-colors duration-150 group-hover:text-cp-primary sm:text-[15px]",
                                        children: "Cutie Pack"
                                    }), (0, r.jsxs)(y.BT, {
                                        className: "mt-1 line-clamp-2 text-[12px] leading-5 text-cp-muted sm:text-[13px]",
                                        children: ["All ", e, " templates under \u20b9", w.gq, " + upcoming templates"]
                                    })]
                                })
                            })
                        })]
                    }), (0, r.jsxs)(y.Wu, {
                        className: "@container mt-auto space-y-3 px-3 pt-1 pb-3 sm:px-4 sm:pb-4",
                        children: [(0, r.jsxs)("div", {
                            className: "flex flex-wrap items-baseline gap-x-1.5 gap-y-1",
                            children: [(0, r.jsxs)("span", {
                                className: "text-[15px] font-semibold tracking-[-0.01em] text-cp-ink sm:text-[17px]",
                                children: ["\u20b9", t.toLocaleString("en-IN")]
                            }), i > 0 ? (0, r.jsxs)("span", {
                                className: "text-[12px] text-cp-muted line-through sm:text-[13px]",
                                children: ["\u20b9", s.toLocaleString("en-IN")]
                            }) : null, (0, r.jsx)("span", {
                                className: "text-[11px] text-cp-muted",
                                children: "one-time"
                            }), i > 0 ? (0, r.jsxs)("span", {
                                className: "rounded-full bg-cp-success/10 px-1.5 py-0.5 text-[10px] font-semibold text-cp-success-ink sm:text-[11px]",
                                children: ["Save \u20b9", i.toLocaleString("en-IN")]
                            }) : null]
                        }), (0, r.jsxs)("div", {
                            className: "grid gap-2 @[15rem]:grid-cols-2",
                            children: [(0, r.jsx)(v.$, {
                                asChild: !0,
                                variant: "secondary",
                                size: "sm",
                                className: "h-10 w-full min-w-0 rounded-full border border-cp-line-strong bg-cp-bg px-3 text-[13px] font-medium whitespace-nowrap text-cp-ink hover:bg-cp-subtle hover:text-cp-ink",
                                children: (0, r.jsx)(n(), {
                                    href: "/products/cutie-pack",
                                    children: "See details"
                                })
                            }), (0, r.jsx)(v.$, {
                                asChild: !0,
                                variant: "secondary",
                                size: "sm",
                                className: "h-10 w-full min-w-0 rounded-full border-0 bg-cp-select px-3 text-[13px] font-medium whitespace-nowrap text-white hover:bg-cp-primary hover:text-white",
                                children: (0, r.jsxs)(n(), {
                                    href: "/products/cutie-pack#get-pack",
                                    children: [(0, r.jsx)(g.A, {
                                        className: "size-4",
                                        strokeWidth: 1.75,
                                        "aria-hidden": !0
                                    }), "Get the pack"]
                                })
                            })]
                        })]
                    })]
                })
            }
            var k = s(80304),
                N = s(26752),
                A = s(50068);

            function P(e) {
                return e < 90 ? "under-100" : e <= 310 ? "100-300" : "above-300"
            }

            function S({
                templates: e,
                packEligibleCount: t = 0,
                packAmountInr: s,
                packCatalogValueInr: i = 0,
                hrefs: p,
                underStorePicks: u = [],
                miniCount: m,
                priceStores: g = []
            }) {
                let b, v, y, w = (0, a.useRouter)(),
                    C = (0, a.useSearchParams)(),
                    O = C.get("category") ? ? void 0,
                    L = C.get("price") ? ? void 0,
                    M = N.O.productsPage.listing,
                    [$, T] = (0, l.useState)(""),
                    E = (0, l.useDeferredValue)($).trim().toLowerCase(),
                    z = (0, l.useMemo)(() => Array.from(new Set(e.map(e => e.category))).sort(), [e]),
                    R = O && z.includes(O) ? O : "all",
                    I = "under-100" === L || "100-300" === L || "above-300" === L ? L : "all",
                    W = e.filter(e => {
                        let t = "all" === R || e.category === R,
                            s = "all" === I || P(e.priceInr) === I,
                            r = "" === E || e.name.toLowerCase().includes(E) || e.category.toLowerCase().includes(E) || e.description.toLowerCase().includes(E);
                        return t && s && r
                    }),
                    B = t > 0 && "all" === R && "under-100" !== I && "100-300" !== I && "" === E,
                    F = ({
                        nextCategory: e = R,
                        nextPrice: t = I
                    }) => {
                        let s = new URLSearchParams;
                        "all" !== e && s.set("category", e), "all" !== t && s.set("price", t);
                        let r = C.get(A.T$);
                        r && s.set(A.T$, r);
                        let i = s.toString();
                        return i ? `/products?${i}` : "/products"
                    },
                    U = F({
                        nextCategory: "all",
                        nextPrice: "all"
                    }),
                    q = e.filter(e => "" === E || e.name.toLowerCase().includes(E) || e.category.toLowerCase().includes(E) || e.description.toLowerCase().includes(E)),
                    G = [{
                        label: M.categoryOptions.all,
                        value: "all",
                        count: q.length
                    }, ...z.map(e => ({
                        label: e,
                        value: e,
                        count: q.filter(t => t.category === e).length
                    }))],
                    H = [{
                        label: M.priceOptions.all,
                        value: "all",
                        count: q.length
                    }, {
                        label: M.priceOptions.under100,
                        value: "under-100",
                        count: q.filter(e => "under-100" === P(e.priceInr)).length
                    }, {
                        label: M.priceOptions.between100And300,
                        value: "100-300",
                        count: q.filter(e => "100-300" === P(e.priceInr)).length
                    }, {
                        label: M.priceOptions.above300,
                        value: "above-300",
                        count: q.filter(e => "above-300" === P(e.priceInr)).length
                    }],
                    V = "all" !== R || "all" !== I,
                    Q = V || E ? null : (b = e.slice(0, 12), v = e.slice(12), y = e => e.priceInr > 0 && e.priceInr <= 99, {
                        head: [...b, ...v.filter(y)],
                        tail: v.filter(e => !y(e))
                    }),
                    J = Q ? Math.min((+!!B + Q.head.length + u.length) % 4, Q.head.length) : 0,
                    D = e => (0, r.jsx)(k.TemplateCard, {
                        template: e,
                        minimal: !0,
                        href: p ? .[e.slug]
                    }, e.id),
                    X = (0, r.jsxs)("div", {
                        className: "space-y-3 p-0.5",
                        children: [(0, r.jsx)(o.X, {
                            value: $,
                            onChange: T,
                            placeholder: M.searchPlaceholder
                        }), (0, r.jsx)(o.s, {
                            title: M.categoryTitle,
                            options: G,
                            activeValue: R,
                            hrefFor: e => F({
                                nextCategory: e
                            })
                        }), (0, r.jsx)(o.s, {
                            title: M.priceTitle,
                            defaultOpen: !1,
                            options: H,
                            activeValue: I,
                            hrefFor: e => F({
                                nextPrice: e
                            })
                        }), V ? (0, r.jsx)(n(), {
                            href: U,
                            scroll: !1,
                            prefetch: !1,
                            className: "inline-flex rounded-md px-1 text-[13px] font-medium text-cp-primary transition-colors duration-150 hover:text-cp-primary-hover",
                            children: M.resetFiltersCta
                        }) : null, (0, r.jsxs)("div", {
                            children: [(0, r.jsx)("p", {
                                className: "py-1 text-[12px] font-semibold text-cp-ink",
                                children: "Collections"
                            }), (0, r.jsx)("div", {
                                className: "mt-1.5 flex flex-wrap gap-1",
                                children: ["Mini pages", "Desi"].map(e => (0, r.jsxs)(n(), {
                                    href: c.Ei.path,
                                    prefetch: !1,
                                    className: "inline-flex h-7 items-center gap-1 rounded-full border border-cp-line bg-cp-bg px-2.5 text-[12.5px] text-cp-muted transition-colors duration-150 hover:bg-cp-subtle hover:text-cp-ink focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-cp-select",
                                    children: [e, (0, r.jsx)("img", {
                                        src: "/ui/arrow-go-v1.webp",
                                        alt: "",
                                        "aria-hidden": !0,
                                        decoding: "async",
                                        className: "size-4"
                                    })]
                                }, e))
                            })]
                        })]
                    });
                return (0, r.jsxs)("div", {
                    className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
                    children: [E ? null : (0, r.jsx)(h.M, {
                        miniCount: m,
                        className: "mb-5 sm:mb-6"
                    }), (0, r.jsxs)("div", {
                        className: "mb-5 flex items-center justify-between gap-3 sm:mb-6 lg:hidden",
                        children: [(0, r.jsx)(o.X, {
                            value: $,
                            onChange: T,
                            placeholder: M.searchPlaceholder,
                            className: "flex-1 sm:w-64 sm:flex-none"
                        }), (0, r.jsx)(f.h, {
                            categoryOptions: G,
                            priceOptions: H,
                            activeCategory: R,
                            activePrice: I,
                            buildFilterHref: F,
                            resetHref: U,
                            filtersTitle: M.filtersTitle,
                            categoryTitle: M.categoryTitle,
                            priceTitle: M.priceTitle,
                            resetCta: M.resetFiltersCta
                        })]
                    }), (0, r.jsxs)("div", {
                        className: "grid gap-8 lg:grid-cols-[200px_minmax(0,1fr)] lg:gap-6",
                        children: [(0, r.jsx)("aside", {
                            className: "hidden rounded-2xl border border-cp-line bg-cp-bg p-2.5 lg:sticky lg:top-28 lg:block lg:self-start",
                            children: X
                        }), (0, r.jsxs)("div", {
                            children: ["under-100" === I && g.length ? (0, r.jsx)(x, {
                                stores: g,
                                className: "mb-4"
                            }) : null, W.length > 0 || B ? (0, r.jsxs)("div", {
                                className: "grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4 xl:gap-3",
                                children: [B ? (0, r.jsx)(j, {
                                    eligibleTemplateCount: t,
                                    amountInr: s,
                                    catalogValueInr: i
                                }) : null, Q ? (0, r.jsxs)(r.Fragment, {
                                    children: [Q.head.slice(0, Q.head.length - J).map(D), u.map(D), (0, r.jsx)("div", {
                                        className: "col-span-full py-3 sm:py-5",
                                        children: g.length ? (0, r.jsx)(x, {
                                            stores: g
                                        }) : (0, r.jsx)(d.k, {
                                            count: m
                                        })
                                    }), Q.head.slice(Q.head.length - J).map(D), Q.tail.map(D)]
                                }) : W.map(D)]
                            }) : "under-100" === I && g.length ? null : (0, r.jsxs)("div", {
                                className: "rounded-3xl border border-dashed border-cp-line-strong bg-cp-bg p-8 text-center sm:p-12",
                                children: [(0, r.jsx)("p", {
                                    className: "text-[17px] font-semibold tracking-[-0.01em] text-cp-ink",
                                    children: M.emptyState.title
                                }), (0, r.jsx)("p", {
                                    className: "mx-auto mt-2 max-w-md text-[14px] leading-6 text-cp-muted",
                                    children: M.emptyState.description
                                }), (0, r.jsx)("button", {
                                    type: "button",
                                    onClick: () => {
                                        T(""), w.push(U, {
                                            scroll: !1
                                        })
                                    },
                                    className: "mt-5 inline-flex h-10 items-center rounded-full bg-cp-subtle px-4 text-[14px] font-medium text-cp-ink transition-colors duration-150 hover:bg-cp-hover",
                                    children: M.emptyState.clearCta
                                })]
                            })]
                        })]
                    })]
                })
            }
        },
        44616: (e, t, s) => {
            "use strict";
            s.d(t, {
                ON: () => n,
                df: () => l,
                fw: () => a,
                t7: () => o
            });
            let r = ["all", "under-499", "500-999", "1000-1999", "2000-plus"],
                i = {
                    "under-499": {
                        minPaise: 0,
                        maxPaise: 49899
                    },
                    "500-999": {
                        minPaise: 49900,
                        maxPaise: 99899
                    },
                    "1000-1999": {
                        minPaise: 99900,
                        maxPaise: 199899
                    },
                    "2000-plus": {
                        minPaise: 199900,
                        maxPaise: Number.MAX_SAFE_INTEGER
                    }
                };

            function n(e) {
                return r.includes(e ? ? "")
            }

            function a(e, t) {
                if ("all" === t) return !0;
                let s = i[t];
                return e >= s.minPaise && e <= s.maxPaise
            }

            function l(e) {
                return "gifts" === e ? "gifts" : "digital"
            }
            let o = 7
        },
        48523: (e, t, s) => {
            "use strict";
            s.d(t, {
                G: () => function e(t, s, n, a) {
                    if ("function" == typeof t) {
                        let e;
                        return c.bt.current = [], t(), e = o(c.bt.current, t), c.bt.current = void 0, e
                    }
                    if (void 0 !== n && !Array.isArray(n) && "function" != typeof s) {
                        var l = t,
                            p = s,
                            u = n,
                            m = a;
                        let r = (0, i.M)(() => Object.keys(u)),
                            o = (0, i.M)(() => ({}));
                        for (let t of r) o[t] = e(l, p, u[t], m);
                        return o
                    }
                    let x = "function" == typeof s ? s : (0, r.p)(s, n, a),
                        h = Array.isArray(t) ? d(t, x) : d([t], ([e]) => x(e)),
                        f = Array.isArray(t) ? void 0 : t.accelerate;
                    return f && !f.isTransformed && "function" != typeof s && Array.isArray(n) && a ? .clamp !== !1 && (h.accelerate = { ...f,
                        times: s,
                        keyframes: n,
                        isTransformed: !0,
                        ...a ? .ease ? {
                            ease: a.ease
                        } : {}
                    }), h
                }
            });
            var r = s(60544),
                i = s(9943),
                n = s(86993),
                a = s(31011),
                l = s(62857);

            function o(e, t) {
                let s = (0, l.d)(t()),
                    r = () => s.set(t());
                return r(), (0, a.E)(() => {
                    let t = () => n.Gt.preRender(r, !1, !0),
                        s = e.map(e => e.on("change", t));
                    return () => {
                        s.forEach(e => e()), (0, n.WG)(r)
                    }
                }), s
            }
            var c = s(61624);

            function d(e, t) {
                let s = (0, i.M)(() => []);
                return o(e, () => {
                    s.length = 0;
                    let r = e.length;
                    for (let t = 0; t < r; t++) s[t] = e[t].get();
                    return t(s)
                })
            }
        },
        51342: (e, t, s) => {
            "use strict";
            s.d(t, {
                TrendingProductsCarousel: () => o
            });
            var r = s(73365),
                i = s(1521),
                n = s(21196),
                a = s(80304),
                l = s(54872);

            function o({
                templates: e,
                detailLabel: t,
                hidePagination: s = !1,
                hideOffer: c = !1,
                minimal: d = !1
            }) {
                let p = (0, i.useRef)(null),
                    [u, m] = (0, i.useState)(1),
                    [x, h] = (0, i.useState)(0);
                return (0, i.useEffect)(() => {
                    let e = p.current;
                    if (!e) return;
                    let t = () => Math.max(1, Math.ceil(e.scrollWidth / e.clientWidth)),
                        s = () => {
                            let s = t(),
                                r = Math.min(s - 1, Math.round(e.scrollLeft / e.clientWidth));
                            m(s), h(r)
                        };
                    s();
                    let r = () => {
                        h(Math.min(Math.max(0, t() - 1), Math.round(e.scrollLeft / e.clientWidth)))
                    };
                    e.addEventListener("scroll", r, {
                        passive: !0
                    });
                    let i = new ResizeObserver(s);
                    return i.observe(e), () => {
                        e.removeEventListener("scroll", r), i.disconnect()
                    }
                }, []), (0, r.jsxs)("div", {
                    children: [(0, r.jsx)("div", {
                        ref: p,
                        className: "no-scrollbar flex snap-x snap-mandatory gap-3 overflow-x-auto pb-3 scroll-smooth sm:gap-4",
                        "aria-label": "Trending products",
                        children: e.map((e, s) => (0, r.jsx)("div", {
                            className: "flex min-w-0 shrink-0 snap-start basis-[82%] sm:basis-[calc((100%-1rem)/2)] md:basis-[calc((100%-2rem)/3)] lg:basis-[calc((100%-3rem)/4)]",
                            children: (0, r.jsx)(n.RevealSection, {
                                className: "h-full w-full",
                                delayMs: 80 + 35 * s,
                                children: (0, r.jsx)(a.TemplateCard, {
                                    template: e,
                                    detailLabel: t,
                                    hideOffer: c,
                                    minimal: d,
                                    compactOnDesktop: !0
                                })
                            })
                        }, e.id))
                    }), u > 1 && !s ? (0, r.jsx)("div", {
                        className: "mt-6 flex items-center justify-center gap-2",
                        "aria-label": "Trending products pages",
                        children: Array.from({
                            length: u
                        }, (e, t) => {
                            let s = t === x;
                            return (0, r.jsx)("button", {
                                type: "button",
                                "aria-label": `Go to trending products page ${t+1}`,
                                "aria-pressed": s,
                                onClick: () => {
                                    let e;
                                    (e = p.current) && e.scrollTo({
                                        left: e.clientWidth * t,
                                        behavior: "smooth"
                                    })
                                },
                                className: (0, l.cn)("h-2 rounded-full transition-[width,background-color] duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", s ? "w-5 bg-cp-primary" : "w-2 bg-cp-line-strong hover:bg-cp-lavender")
                            }, t)
                        })
                    }) : null]
                })
            }
        },
        55684: (e, t, s) => {
            "use strict";
            s.r(t), s.d(t, {
                TopOnFreshLoad: () => i
            });
            var r = s(1521);

            function i() {
                return (0, r.useEffect)(() => {
                    let [e] = performance.getEntriesByType("navigation");
                    if (e && "navigate" !== e.type || window.location.hash || document.body.hasAttribute("data-overlay-open")) return;
                    window.scrollTo(0, 0);
                    let t = [requestAnimationFrame(() => {
                        if (document.body.hasAttribute("data-overlay-open")) return;
                        window.scrollTo(0, 0);
                        let e = requestAnimationFrame(() => {
                            document.body.hasAttribute("data-overlay-open") || window.scrollTo(0, 0)
                        });
                        t.push(e)
                    })];
                    return () => {
                        for (let e of t) cancelAnimationFrame(e)
                    }
                }, []), null
            }
        },
        62857: (e, t, s) => {
            "use strict";
            s.d(t, {
                d: () => l
            });
            var r = s(61624),
                i = s(1521),
                n = s(83246),
                a = s(9943);

            function l(e) {
                let t = (0, a.M)(() => (0, r.OQ)(e)),
                    {
                        isStatic: s
                    } = (0, i.useContext)(n.Q);
                if (s) {
                    let [, s] = (0, i.useState)(e);
                    (0, i.useEffect)(() => t.on("change", s), [])
                }
                return t
            }
        },
        65859: (e, t, s) => {
            "use strict";
            s.d(t, {
                GiftsListing: () => w
            });
            var r = s(73365),
                i = s(99568),
                n = s.n(i),
                a = s(29717),
                l = s(1521),
                o = s(84395),
                c = s(94612),
                d = s(75133),
                p = s(9388),
                u = s(45421),
                m = s(26752),
                x = s(37731),
                h = s(54872);

            function f({
                product: e
            }) {
                let t = m.O.productsPage.giftsListing.grid,
                    s = `/products/gifts/${e.slug}`,
                    i = e.maxPricePaise > e.minPricePaise,
                    a = null !== e.compareAtPricePaise && e.compareAtPricePaise > e.minPricePaise,
                    l = (0, x.N9)(e.minPricePaise, e.compareAtPricePaise),
                    g = e.hasStock ? e.variantCount > 1 ? `${e.variantCount} ${t.variantHint}` : null : t.outOfStock;
                return (0, r.jsxs)(u.Zp, {
                    className: "group flex h-full flex-col overflow-hidden rounded-3xl border border-cp-line bg-cp-bg shadow-none transition-colors duration-150 hover:border-cp-line-strong",
                    children: [(0, r.jsxs)(n(), {
                        href: s,
                        className: "block rounded-t-3xl p-1.5 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-cp-select sm:p-2",
                        children: [(0, r.jsxs)("div", {
                            className: "relative aspect-square overflow-hidden rounded-2xl bg-cp-canvas",
                            children: [e.imageUrl ? (0, r.jsx)(c.BlurImage, {
                                src: e.imageUrl,
                                alt: e.imageAlt || `${e.title} gift`,
                                fill: !0,
                                sizes: "(min-width: 1280px) 22vw, (min-width: 1024px) 28vw, (min-width: 640px) 45vw, 50vw",
                                className: (0, h.cn)("object-cover transition-transform duration-300 ease-out group-hover:scale-[1.03] motion-reduce:transition-none", !e.hasStock && "opacity-60")
                            }) : (0, r.jsx)("div", {
                                className: "flex h-full items-center justify-center text-cp-faint",
                                children: (0, r.jsx)(o.A, {
                                    className: "size-10",
                                    strokeWidth: 1.75,
                                    "aria-hidden": !0
                                })
                            }), g ? (0, r.jsx)("span", {
                                className: (0, h.cn)("absolute top-2 left-2 rounded-full px-2 py-0.5 text-[10px] leading-4 font-semibold shadow-cp-float sm:top-2.5 sm:left-2.5 sm:text-[11px]", e.hasStock ? "bg-cp-bg text-cp-ink" : "bg-cp-ink text-white"),
                                children: g
                            }) : null]
                        }), (0, r.jsx)(u.aR, {
                            className: "flex-1 space-y-0 px-1.5 pt-3 pb-0 sm:px-2 sm:pt-3.5",
                            children: (0, r.jsxs)("div", {
                                className: "min-w-0",
                                children: [(0, r.jsx)(u.ZB, {
                                    className: "line-clamp-2 h-10 font-sans text-[14px] leading-5 font-semibold tracking-[-0.015em] text-cp-ink sm:h-12 sm:text-[16px] sm:leading-6",
                                    children: e.title
                                }), (0, r.jsx)(u.BT, {
                                    className: "mt-1 line-clamp-2 min-h-[2.25rem] text-[12px] leading-[1.125rem] text-cp-muted sm:min-h-[2.5rem] sm:text-[13px] sm:leading-5",
                                    children: e.subtitle ? ? e.categoryName
                                })]
                            })
                        })]
                    }), (0, r.jsxs)(u.Wu, {
                        className: "@container mt-auto px-3 pt-2.5 pb-3 sm:px-4 sm:pb-4",
                        children: [(0, r.jsxs)("div", {
                            className: "flex flex-wrap items-baseline gap-x-2 gap-y-1",
                            children: [i ? (0, r.jsx)("span", {
                                className: "text-[11px] normal-case text-cp-muted",
                                children: t.fromPrefix
                            }) : null, (0, r.jsx)("span", {
                                className: "text-[16px] leading-6 font-semibold tracking-[-0.02em] text-cp-ink tabular-nums sm:text-[19px]",
                                children: (0, x.ym)(e.minPricePaise)
                            }), a ? (0, r.jsxs)(r.Fragment, {
                                children: [(0, r.jsx)("span", {
                                    className: "text-[12px] text-cp-muted tabular-nums line-through decoration-cp-muted/60 sm:text-[13px]",
                                    children: (0, x.ym)(e.compareAtPricePaise)
                                }), l > 0 ? (0, r.jsxs)("span", {
                                    className: "rounded-full bg-cp-success/10 px-2 py-0.5 text-[10px] leading-4 font-semibold text-cp-success-ink sm:text-[11px]",
                                    children: [l, "% off"]
                                }) : null]
                            }) : null]
                        }), (0, r.jsx)("div", {
                            className: "mt-2 flex h-5 flex-nowrap gap-1 overflow-hidden",
                            children: e.occasions.slice(0, 2).map(e => (0, r.jsx)("span", {
                                className: "shrink-0 rounded-full bg-cp-pastel-lilac px-2 py-0.5 text-[10px] font-medium text-cp-pastel-lilac-ink",
                                children: e.name
                            }, e.slug))
                        }), (0, r.jsx)("div", {
                            className: "mt-3",
                            children: e.hasStock ? (0, r.jsx)(d.GiftCardActions, {
                                href: s,
                                soleVariantId: e.soleVariantId,
                                hasStock: e.hasStock
                            }) : (0, r.jsx)(p.$, {
                                asChild: !0,
                                variant: "secondary",
                                size: "sm",
                                className: "h-10 w-full min-w-0 rounded-xl border border-cp-line-strong bg-cp-bg px-4 text-[13px] text-cp-ink hover:border-cp-ink/30 hover:bg-cp-subtle sm:h-9",
                                children: (0, r.jsx)(n(), {
                                    href: s,
                                    prefetch: !1,
                                    children: t.viewCta
                                })
                            })
                        })]
                    })]
                })
            }
            var g = s(34913),
                b = s(79151),
                v = s(44616);
            let y = "/products?type=gifts";

            function w({
                products: e
            }) {
                let t = (0, a.useRouter)(),
                    s = (0, a.useSearchParams)(),
                    i = s.get("category") ? ? void 0,
                    o = s.get("occasion") ? ? void 0,
                    c = s.get("price") ? ? void 0,
                    d = m.O.productsPage.giftsListing,
                    [u, x] = (0, l.useState)(""),
                    h = u.trim().toLowerCase(),
                    j = (0, l.useMemo)(() => Array.from(new Set(e.map(e => e.categorySlug))).sort(), [e]),
                    k = (0, l.useMemo)(() => {
                        let t = new Map;
                        for (let s of e) t.set(s.categorySlug, s.categoryName);
                        return t
                    }, [e]),
                    N = (0, l.useMemo)(() => {
                        let t = new Map;
                        for (let s of e)
                            for (let e of s.occasions) t.set(e.slug, e.name);
                        return Array.from(t.entries()).sort((e, t) => e[1].localeCompare(t[1]))
                    }, [e]),
                    A = i && j.includes(i) ? i : "all",
                    P = o && N.some(([e]) => e === o) ? o : "all",
                    S = (0, v.ON)(c) ? c : "all",
                    C = e => "" === h || e.title.toLowerCase().includes(h) || e.categoryName.toLowerCase().includes(h) || (e.subtitle ? .toLowerCase().includes(h) ? ? !1),
                    O = e.filter(e => {
                        let t = "all" === A || e.categorySlug === A,
                            s = "all" === P || e.occasions.some(e => e.slug === P),
                            r = (0, v.fw)(e.minPricePaise, S);
                        return t && s && r && C(e)
                    }),
                    L = ({
                        nextCategory: e = A,
                        nextOccasion: t = P,
                        nextPrice: s = S
                    }) => {
                        let r = new URLSearchParams({
                            type: "gifts"
                        });
                        return "all" !== e && r.set("category", e), "all" !== t && r.set("occasion", t), "all" !== s && r.set("price", s), `/products?${r.toString()}`
                    },
                    M = e.filter(C),
                    $ = [{
                        label: d.categoryOptions.all,
                        value: "all",
                        count: M.length
                    }, ...j.map(e => ({
                        label: k.get(e) ? ? e,
                        value: e,
                        count: M.filter(t => t.categorySlug === e).length
                    }))],
                    T = [{
                        label: d.occasionOptions.all,
                        value: "all",
                        count: M.length
                    }, ...N.map(([e, t]) => ({
                        label: t,
                        value: e,
                        count: M.filter(t => t.occasions.some(t => t.slug === e)).length
                    }))],
                    E = [{
                        label: d.priceOptions.all,
                        value: "all"
                    }, {
                        label: d.priceOptions.under499,
                        value: "under-499"
                    }, {
                        label: d.priceOptions.between500And999,
                        value: "500-999"
                    }, {
                        label: d.priceOptions.between1000And1999,
                        value: "1000-1999"
                    }, {
                        label: d.priceOptions.above2000,
                        value: "2000-plus"
                    }].map(e => ({ ...e,
                        count: M.filter(t => (0, v.fw)(t.minPricePaise, e.value)).length
                    })),
                    z = "all" !== A || "all" !== P || "all" !== S,
                    R = (0, r.jsxs)("div", {
                        className: "space-y-4 p-1 sm:p-1.5",
                        children: [(0, r.jsx)(g.s, {
                            title: m.O.productsPage.listing.categoryTitle,
                            options: $,
                            activeValue: A,
                            hrefFor: e => L({
                                nextCategory: e
                            })
                        }), T.length > 1 ? (0, r.jsx)(g.s, {
                            title: d.occasionTitle,
                            options: T,
                            activeValue: P,
                            hrefFor: e => L({
                                nextOccasion: e
                            })
                        }) : null, (0, r.jsx)(g.s, {
                            title: m.O.productsPage.listing.priceTitle,
                            options: E,
                            activeValue: S,
                            hrefFor: e => L({
                                nextPrice: e
                            })
                        }), z ? (0, r.jsx)(n(), {
                            href: y,
                            scroll: !1,
                            prefetch: !1,
                            className: "inline-flex px-3 text-xs font-medium text-cp-primary transition-colors duration-150 hover:text-cp-primary-hover",
                            children: m.O.productsPage.listing.resetFiltersCta
                        }) : null]
                    });
                return (0, r.jsxs)("div", {
                    className: "mx-auto max-w-7xl px-5 sm:px-6",
                    children: [(0, r.jsxs)("div", {
                        className: "mb-8 flex items-center justify-between gap-3 border-b border-cp-line pb-6",
                        children: [(0, r.jsxs)("p", {
                            className: "hidden text-sm text-cp-muted sm:block",
                            children: [d.showingPrefix, " ", O.length, " ", d.showingConnector, " ", e.length, " ", d.showingSuffix]
                        }), (0, r.jsx)(g.X, {
                            value: u,
                            onChange: x,
                            placeholder: d.searchPlaceholder,
                            className: "flex-1 sm:w-56 sm:flex-none lg:hidden"
                        }), (0, r.jsx)(b.h, {
                            categoryOptions: $,
                            priceOptions: E,
                            activeCategory: A,
                            activePrice: S,
                            buildFilterHref: ({
                                nextCategory: e,
                                nextPrice: t
                            }) => L({
                                nextCategory: e,
                                nextPrice: t
                            }),
                            resetHref: y,
                            filtersTitle: m.O.productsPage.listing.filtersTitle,
                            categoryTitle: m.O.productsPage.listing.categoryTitle,
                            priceTitle: m.O.productsPage.listing.priceTitle,
                            resetCta: m.O.productsPage.listing.resetFiltersCta
                        })]
                    }), T.length > 1 ? (0, r.jsx)("div", {
                        className: "-mt-4 mb-6 lg:hidden",
                        children: (0, r.jsx)(g.s, {
                            title: d.occasionTitle,
                            options: T,
                            activeValue: P,
                            hrefFor: e => L({
                                nextOccasion: e
                            }),
                            defaultOpen: !1
                        })
                    }) : null, (0, r.jsxs)("div", {
                        className: "grid gap-8 lg:grid-cols-[190px_minmax(0,1fr)] lg:gap-8 xl:grid-cols-[210px_minmax(0,1fr)]",
                        children: [(0, r.jsxs)("aside", {
                            className: "hidden lg:sticky lg:top-28 lg:block lg:self-start",
                            children: [(0, r.jsx)("div", {
                                className: "mb-5 hidden px-1 sm:px-1.5 lg:block",
                                children: (0, r.jsx)(g.X, {
                                    value: u,
                                    onChange: x,
                                    placeholder: d.searchPlaceholder
                                })
                            }), R]
                        }), (0, r.jsx)("div", {
                            children: O.length > 0 ? (0, r.jsx)("div", {
                                className: "grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-3 xl:grid-cols-4",
                                children: O.map(e => (0, r.jsx)(f, {
                                    product: e
                                }, e.id))
                            }) : (0, r.jsxs)("div", {
                                className: "rounded-2xl border border-dashed border-cp-line-strong bg-cp-bg p-8 text-center sm:p-12",
                                children: [(0, r.jsx)("p", {
                                    className: "text-[17px] font-semibold text-cp-ink",
                                    children: d.emptyState.title
                                }), (0, r.jsx)("p", {
                                    className: "mx-auto mt-2 max-w-md text-sm leading-6 text-cp-muted",
                                    children: d.emptyState.description
                                }), (0, r.jsx)(p.$, {
                                    type: "button",
                                    variant: "secondary",
                                    className: "mt-6",
                                    onClick: () => {
                                        x(""), t.push(y, {
                                            scroll: !1
                                        })
                                    },
                                    children: d.emptyState.clearCta
                                })]
                            })
                        })]
                    })]
                })
            }
        },
        67892: (e, t, s) => {
            "use strict";
            s.d(t, {
                Rf: () => l,
                bn: () => r,
                c9: () => o,
                gq: () => i,
                hd: () => n,
                sE: () => c,
                vf: () => a
            });
            let r = 999,
                i = 249,
                n = 5,
                a = 3,
                l = 349,
                o = "https://cdn.cutiepage.in/static/products/cutiepack499.png",
                c = "https://cdn.cutiepage.in/static/products/cutiepack.jpg"
        },
        69580: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => r
            });
            let r = (0, s(96296).A)("shopping-bag", [
                ["path", {
                    d: "M16 10a4 4 0 0 1-8 0",
                    key: "1ltviw"
                }],
                ["path", {
                    d: "M3.103 6.034h17.794",
                    key: "awc11p"
                }],
                ["path", {
                    d: "M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",
                    key: "o988cm"
                }]
            ])
        },
        75133: (e, t, s) => {
            "use strict";
            s.d(t, {
                GiftCardActions: () => d
            });
            var r = s(73365),
                i = s(29717),
                n = s(1521),
                a = s(26821),
                l = s(38277),
                o = s(9388),
                c = s(26752);

            function d({
                href: e,
                soleVariantId: t,
                hasStock: s
            }) {
                let p = c.O.productsPage.giftsListing.grid,
                    u = (0, i.useRouter)(),
                    [m, x] = (0, n.useState)(null),
                    [h, f] = (0, n.useState)(!1);
                async function g(r) {
                    if (!m) {
                        if (!t || !s) return void u.push(e);
                        x(r);
                        try {
                            if (!(await fetch("/api/gifts/cart", {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify({
                                        variantId: t,
                                        quantity: 1,
                                        personalization: {}
                                    })
                                })).ok) {
                                u.push(e), x(null);
                                return
                            }
                            if ((0, l.Hz)(), "buy" === r) return void u.push("/gifts/checkout");
                            f(!0), x(null)
                        } catch {
                            u.push(e), x(null)
                        }
                    }
                }
                return (0, r.jsxs)("div", {
                    className: "grid gap-2 @[13.5rem]:grid-cols-2",
                    children: [(0, r.jsx)(o.$, {
                        type: "button",
                        variant: "secondary",
                        size: "sm",
                        disabled: null !== m && "cart" !== m,
                        loading: "cart" === m,
                        onClick: () => void g("cart"),
                        iconLeading: h ? (0, r.jsx)(a.A, {
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }) : void 0,
                        className: h ? "h-10 w-full min-w-0 rounded-xl border border-cp-success/30 bg-cp-success/10 px-3 text-[13px] text-cp-success-ink hover:bg-cp-success/10 sm:h-9" : "h-10 w-full min-w-0 rounded-xl border border-cp-line-strong bg-cp-bg px-3 text-[13px] text-cp-ink hover:border-cp-ink/30 hover:bg-cp-subtle sm:h-9",
                        children: h ? p.addedCta : p.addToCartCta
                    }), (0, r.jsx)(o.$, {
                        type: "button",
                        variant: "primary",
                        size: "sm",
                        disabled: null !== m && "buy" !== m,
                        loading: "buy" === m,
                        onClick: () => void g("buy"),
                        className: "h-10 w-full min-w-0 rounded-xl px-3 text-[13px] font-semibold sm:h-9",
                        children: p.buyNowCta
                    })]
                })
            }
        },
        76777: (e, t, s) => {
            "use strict";
            s.d(t, {
                ProductsViewSwitch: () => l
            });
            var r = s(73365),
                i = s(29717),
                n = s(1521),
                a = s(3779);

            function l({
                browse: e,
                grid: t
            }) {
                let s = (0, i.useSearchParams)(),
                    o = (0, a.D4)(s),
                    [c] = (0, n.useState)(o),
                    [d, p] = (0, n.useState)(!1);
                return d || o === c || p(!0), (0, r.jsx)("div", {
                    className: d || o !== c ? "animate-type-switch-in motion-reduce:animate-none" : void 0,
                    children: o ? t : e
                }, o ? "grid" : "browse")
            }
        },
        79151: (e, t, s) => {
            "use strict";
            s.d(t, {
                h: () => o
            });
            var r = s(73365),
                i = s(99568),
                n = s.n(i),
                a = s(1521),
                l = s(54872);

            function o({
                categoryOptions: e,
                priceOptions: t,
                activeCategory: s,
                activePrice: i,
                buildFilterHref: c,
                resetHref: d,
                filtersTitle: p,
                categoryTitle: u,
                priceTitle: m,
                resetCta: x
            }) {
                let [h, f] = (0, a.useState)(!1), [g, b] = (0, a.useState)(!1), v = (0, a.useRef)(null);
                (0, a.useEffect)(() => {
                    if (!h) return;
                    let e = e => {
                            "Escape" === e.key && f(!1)
                        },
                        t = e => {
                            !v.current || v.current.contains(e.target) || f(!1)
                        };
                    return window.addEventListener("keydown", e), window.addEventListener("mousedown", t), window.addEventListener("touchstart", t, {
                        passive: !0
                    }), () => {
                        window.removeEventListener("keydown", e), window.removeEventListener("mousedown", t), window.removeEventListener("touchstart", t)
                    }
                }, [h]), (0, a.useEffect)(() => {
                    if (h) {
                        let e = window.requestAnimationFrame(() => b(!0));
                        return () => window.cancelAnimationFrame(e)
                    }
                    b(!1)
                }, [h]);
                let y = +("all" !== s) + +("all" !== i);
                return (0, r.jsxs)("div", {
                    ref: v,
                    className: "relative sm:hidden",
                    children: [(0, r.jsxs)("button", {
                        type: "button",
                        "aria-label": "Open filters",
                        "aria-expanded": h,
                        onClick: () => f(e => !e),
                        className: (0, l.cn)("relative flex size-9 items-center justify-center rounded-full border border-cp-line text-cp-ink transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", h ? "bg-cp-subtle" : "bg-cp-bg hover:bg-cp-subtle"),
                        children: [(0, r.jsxs)("svg", {
                            "aria-hidden": "true",
                            viewBox: "0 0 24 24",
                            className: "size-4",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "1.8",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            children: [(0, r.jsx)("line", {
                                x1: "4",
                                y1: "7",
                                x2: "20",
                                y2: "7"
                            }), (0, r.jsx)("line", {
                                x1: "4",
                                y1: "12",
                                x2: "20",
                                y2: "12"
                            }), (0, r.jsx)("line", {
                                x1: "4",
                                y1: "17",
                                x2: "20",
                                y2: "17"
                            }), (0, r.jsx)("circle", {
                                cx: "9",
                                cy: "7",
                                r: "1.8",
                                fill: "currentColor",
                                stroke: "none"
                            }), (0, r.jsx)("circle", {
                                cx: "15",
                                cy: "12",
                                r: "1.8",
                                fill: "currentColor",
                                stroke: "none"
                            }), (0, r.jsx)("circle", {
                                cx: "11",
                                cy: "17",
                                r: "1.8",
                                fill: "currentColor",
                                stroke: "none"
                            })]
                        }), y > 0 ? (0, r.jsx)("span", {
                            className: "absolute -top-1.5 -right-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-cp-primary px-1 text-[10px] leading-none font-semibold text-white",
                            children: y
                        }) : null]
                    }), h ? (0, r.jsxs)("div", {
                        className: (0, l.cn)("absolute top-[calc(100%+0.5rem)] right-0 z-30 w-[min(86vw,300px)] origin-top-right overflow-hidden rounded-2xl border border-cp-line bg-cp-bg shadow-cp-float", "transition-[opacity,transform] duration-150 ease-out motion-reduce:transition-none", g ? "translate-y-0 scale-100 opacity-100" : "-translate-y-1 scale-[0.98] opacity-0"),
                        children: [(0, r.jsxs)("div", {
                            className: "flex items-center justify-between px-4 py-3",
                            children: [(0, r.jsx)("p", {
                                className: "text-[13px] font-semibold text-cp-ink",
                                children: p
                            }), y > 0 ? (0, r.jsx)(n(), {
                                href: d,
                                scroll: !1,
                                prefetch: !1,
                                onClick: () => f(!1),
                                className: "text-[12px] font-medium text-cp-primary transition-colors duration-150 hover:text-cp-primary-hover",
                                children: x
                            }) : null]
                        }), (0, r.jsxs)("div", {
                            className: "border-t border-cp-line px-4 py-3.5",
                            children: [(0, r.jsx)("p", {
                                className: "mb-2 text-[12px] font-semibold text-cp-ink",
                                children: u
                            }), (0, r.jsx)("div", {
                                className: "flex flex-wrap gap-2",
                                children: e.map(e => {
                                    let t = s === e.value;
                                    return (0, r.jsxs)(n(), {
                                        href: c({
                                            nextCategory: e.value
                                        }),
                                        scroll: !1,
                                        prefetch: !1,
                                        onClick: () => f(!1),
                                        className: (0, l.cn)("inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-[13px] transition-colors duration-150", t ? "border-cp-select/40 bg-cp-primary-soft font-medium text-cp-primary" : "border-cp-line bg-cp-bg text-cp-ink hover:bg-cp-subtle"),
                                        children: [(0, r.jsx)("span", {
                                            className: "capitalize",
                                            children: e.label
                                        }), (0, r.jsx)("span", {
                                            className: (0, l.cn)("text-[11px] tabular-nums", t ? "text-cp-primary/70" : "text-cp-faint"),
                                            children: e.count
                                        })]
                                    }, e.value)
                                })
                            })]
                        }), (0, r.jsxs)("div", {
                            className: "border-t border-cp-line px-4 py-3.5",
                            children: [(0, r.jsx)("p", {
                                className: "mb-2 text-[12px] font-semibold text-cp-ink",
                                children: m
                            }), (0, r.jsx)("div", {
                                className: "flex flex-wrap gap-2",
                                children: t.map(e => {
                                    let t = i === e.value;
                                    return (0, r.jsxs)(n(), {
                                        href: c({
                                            nextPrice: e.value
                                        }),
                                        scroll: !1,
                                        prefetch: !1,
                                        onClick: () => f(!1),
                                        className: (0, l.cn)("inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-[13px] transition-colors duration-150", t ? "border-cp-select/40 bg-cp-primary-soft font-medium text-cp-primary" : "border-cp-line bg-cp-bg text-cp-ink hover:bg-cp-subtle"),
                                        children: [(0, r.jsx)("span", {
                                            children: e.label
                                        }), (0, r.jsx)("span", {
                                            className: (0, l.cn)("text-[11px] tabular-nums", t ? "text-cp-primary/70" : "text-cp-faint"),
                                            children: e.count
                                        })]
                                    }, e.value)
                                })
                            })]
                        })]
                    }) : null]
                })
            }
        },
        83246: (e, t, s) => {
            "use strict";
            s.d(t, {
                Q: () => r
            });
            let r = (0, s(1521).createContext)({
                transformPagePoint: e => e,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        84395: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => r
            });
            let r = (0, s(96296).A)("gift", [
                ["path", {
                    d: "M12 7v14",
                    key: "1akyts"
                }],
                ["path", {
                    d: "M20 11v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8",
                    key: "1sqzm4"
                }],
                ["path", {
                    d: "M7.5 7a1 1 0 0 1 0-5A4.8 8 0 0 1 12 7a4.8 8 0 0 1 4.5-5 1 1 0 0 1 0 5",
                    key: "kc0143"
                }],
                ["rect", {
                    x: "3",
                    y: "7",
                    width: "18",
                    height: "4",
                    rx: "1",
                    key: "1hberx"
                }]
            ])
        },
        90024: (e, t, s) => {
            "use strict";
            s.d(t, {
                ProductsTypeToggle: () => u
            });
            var r = s(73365),
                i = s(29717),
                n = s(99568),
                a = s.n(n),
                l = s(1521),
                o = s(54872);

            function c({
                activeType: e,
                digitalHref: t,
                giftsHref: s,
                label: i,
                digitalLabel: n,
                giftsLabel: d,
                className: p
            }) {
                let [u, m] = (0, l.useState)(null);
                u && u.from !== e && m(null);
                let x = u ? .type ? ? e;
                return (0, r.jsxs)("div", {
                    role: "group",
                    "aria-label": i,
                    className: (0, o.cn)("relative inline-grid shrink-0 grid-cols-2 items-center rounded-full border border-cp-line bg-white/80 p-0.5 backdrop-blur-sm", p),
                    children: [(0, r.jsx)("span", {
                        "aria-hidden": !0,
                        className: (0, o.cn)("absolute inset-y-0.5 left-0.5 w-[calc(50%-2px)] rounded-full bg-cp-primary transition-transform duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none", "gifts" === x && "translate-x-full")
                    }), [{
                        type: "digital",
                        href: t,
                        label: n
                    }, {
                        type: "gifts",
                        href: s,
                        label: d
                    }].map(t => {
                        let s = x === t.type;
                        return (0, r.jsx)(a(), {
                            href: t.href,
                            scroll: !1,
                            prefetch: !1,
                            onClick: () => m({
                                type: t.type,
                                from: e
                            }),
                            "aria-current": e === t.type ? "page" : void 0,
                            className: (0, o.cn)("group/seg relative rounded-full px-3.5 py-1.5 text-center text-[13px] font-medium sm:px-4", "outline-none focus-visible:ring-2 focus-visible:ring-cp-select focus-visible:ring-offset-1", "active:scale-[0.98] motion-reduce:active:scale-100"),
                            children: (0, r.jsx)("span", {
                                className: (0, o.cn)("relative transition-colors duration-[160ms] ease-out", s ? "text-white" : "text-cp-muted group-hover/seg:text-cp-ink"),
                                children: t.label
                            })
                        }, t.type)
                    })]
                })
            }
            var d = s(26752),
                p = s(44616);

            function u() {
                let e = (0, i.useSearchParams)(),
                    t = (0, p.df)(e.get("type") ? ? void 0),
                    s = d.O.productsPage.listing.typeToggle;
                return (0, r.jsx)(c, {
                    activeType: t,
                    digitalHref: "/products",
                    giftsHref: "/products?type=gifts",
                    label: s.label,
                    digitalLabel: s.digital,
                    giftsLabel: s.gifts
                })
            }
        },
        91466: (e, t, s) => {
            "use strict";
            s.d(t, {
                $l: () => c,
                MA: () => n,
                dk: () => a,
                k7: () => l,
                rG: () => o
            });
            let r = "https://cdn.cutiepage.in/static/home-film";

            function i(e, t, s) {
                let i, n;
                return [{
                    src: `${r}/festive-${e}-v1-av1.mp4`,
                    type: (i = t, `video/mp4; codecs="av01.0.${i}M.10"`)
                }, {
                    src: `${r}/festive-${e}-v1-hevc.mp4`,
                    type: (n = s, `video/mp4; codecs="hvc1.1.6.L${n}.90"`)
                }, {
                    src: `${r}/festive-${e}-v1-h264.mp4`,
                    type: 'video/mp4; codecs="avc1.640029"'
                }]
            }
            let n = {
                    look: "festive",
                    desktop: {
                        sources: i("desktop", "08", 120),
                        sdSources: i("desktop720", "05", 93),
                        posterAvif: `${r}/festive-desktop-v1-poster-1280.avif 1280w, ${r}/festive-desktop-v1-poster.avif 1920w`,
                        posterWebp: `${r}/festive-desktop-v1-poster-1280.webp 1280w, ${r}/festive-desktop-v1-poster.webp 1920w`,
                        posterJpg: `${r}/festive-desktop-v1-poster.jpg`,
                        width: 1920,
                        height: 1080,
                        placeholder: {
                            gradient: ["#403929", "#735e48", "#6b5b4a"],
                            lqip: "data:image/webp;base64,UklGRqwAAABXRUJQVlA4IKAAAACwBACdASoYAA4APu1iqU2ppaOiMAgBMB2JaACdMoAlsBWIfKO1bGjYST4w2igAAP7bYfBNyd277pnQ4DN+5vqhshRyhQcdI6jpU6HhKeZZEuh3iG0X/APVtwrvgtoAUSHnuhiE1hIQL/zVxTUZmVY18qJjiDgwTQm3u6S6PydlGfyOv3jgJ6j0sUsWZ9SLPdwQLwf0GcKgKez0ncbo3IAA"
                        }
                    },
                    mobile: {
                        sources: i("mobile", "04", 93),
                        posterAvif: `${r}/festive-mobile-v1-poster.avif`,
                        posterWebp: `${r}/festive-mobile-v1-poster.webp`,
                        posterJpg: `${r}/festive-mobile-v1-poster.jpg`,
                        width: 608,
                        height: 1080,
                        placeholder: {
                            gradient: ["#564532", "#a8765e", "#a38973"],
                            lqip: "data:image/webp;base64,UklGRr4AAABXRUJQVlA4ILIAAAAQBQCdASoOABkAPu1iqU2ppaOiMAgBMB2JbACdMoR3EGAPh51K0XMYNn3CMB5mSMWAAP7pRAzieY8FrtG+PL2ZS/4RDWwtUHaS9pKJTWT9XMZ/nVhSaN6xw20L9E+57m8XTt37F+EGKpTt4cL2iZ5XIJ71DGvgHMmyLQf8Ph2+tXMAJVmmZ72K/3o59Dk8vxxetp4BSnYfaN5klrh/guHg+GOGVWSSFNWtloef57xlR7wA"
                        }
                    }
                },
                a = {
                    desktop: {
                        mp4: `${r}/aura-desktop-v1.mp4`,
                        webm: `${r}/aura-desktop-v1.webm`,
                        posterAvif: `${r}/aura-desktop-v1-poster.avif`,
                        posterWebp: `${r}/aura-desktop-v1-poster.webp`,
                        posterJpg: `${r}/aura-desktop-v1-poster.jpg`,
                        width: 1280,
                        height: 720,
                        placeholder: {
                            gradient: ["#2b2f21", "#655b30", "#726434"],
                            lqip: "data:image/webp;base64,UklGRoAAAABXRUJQVlA4IHQAAADQAwCdASoYAA4APu1iqU2ppaQiMAgBMB2JZgC06CB991pM4TQVYgAA/unW990t2rIZ0Jlz95HOPFf3cMDeQbBQ5kT3HUwR61WK3so8HxjQBy4W3jWeOrIUeRrlUFdSD0y0D1B7gzPbHnOPbr7wHhB3pwAAAA=="
                        }
                    },
                    mobile: {
                        mp4: `${r}/aura-mobile-v1.mp4`,
                        webm: `${r}/aura-mobile-v1.webm`,
                        posterAvif: `${r}/aura-mobile-v1-poster.avif`,
                        posterWebp: `${r}/aura-mobile-v1-poster.webp`,
                        posterJpg: `${r}/aura-mobile-v1-poster.jpg`,
                        width: 720,
                        height: 1280,
                        placeholder: {
                            gradient: ["#383a26", "#625436", "#5a503b"],
                            lqip: "data:image/webp;base64,UklGRoYAAABXRUJQVlA4IHoAAAAwBACdASoOABkAPu1iqU2ppaOiMAgBMB2JagC7MoACn/4Tucf6F9Do6YAA/hnEZphsizCGnqbMZ4O/+rOIgaMw2PgL7VTRXOiKEvt7MnK92k2ZOW3h3tyRctjeMrYKegamnT6b/bxnbP+48zX13SIy+/HskSq2lLwAAA=="
                        }
                    }
                },
                l = {
                    occasionBirthday: {
                        name: "occasion-birthday-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    occasionAnniversary: {
                        name: "occasion-anniversary-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    occasionSorry: {
                        name: "occasion-sorry-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    occasionLongDistance: {
                        name: "occasion-long-distance-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    faqLetter: {
                        name: "faq-letter-v1",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    domainStudy: {
                        name: "domain-study-v1",
                        widths: [1200, 1920],
                        width: 1920,
                        height: 1200
                    },
                    storyDaylight: {
                        name: "story-daylight-v1",
                        widths: [1200, 1920],
                        width: 1920,
                        height: 1080
                    },
                    auraRose: {
                        name: "aura-rose-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 1600
                    },
                    closing: {
                        name: "closing-v1",
                        widths: [1200, 1920],
                        width: 1920,
                        height: 1080
                    }
                };

            function o(e, t) {
                return e.widths.map(s => `${r}/${e.name}-${s}.${t} ${s}w`).join(", ")
            }

            function c(e, t = "jpg") {
                let s = e.widths[e.widths.length - 1];
                return `${r}/${e.name}-${s}.${t}`
            }
        },
        93406: (e, t, s) => {
            "use strict";
            s.d(t, {
                ProductsBrowseToggle: () => m
            });
            var r = s(73365),
                i = s(99568),
                n = s.n(i),
                a = s(29717),
                l = s(1521),
                o = s(3779),
                c = s(26752),
                d = s(50068),
                p = s(44616),
                u = s(54872);

            function m() {
                let e = (0, a.useSearchParams)(),
                    t = c.O.productsPage.browseToggle,
                    s = (0, o.D4)(e) ? "product" : "category",
                    [i, m] = (0, l.useState)(null);
                i && i.from !== s && m(null);
                let x = i ? .view ? ? s;
                if ("gifts" === (0, p.df)(e.get("type") ? ? void 0)) return null;
                let h = [{
                    view: "product",
                    label: t.product
                }, {
                    view: "category",
                    label: t.category
                }];
                return (0, r.jsxs)("div", {
                    role: "group",
                    "aria-label": t.label,
                    className: "relative inline-grid shrink-0 grid-cols-2 items-center rounded-full border border-cp-line bg-cp-bg p-0.5",
                    children: [(0, r.jsx)("span", {
                        "aria-hidden": !0,
                        className: (0, u.cn)("absolute inset-y-0.5 left-0.5 w-[calc(50%-2px)] rounded-full bg-cp-primary transition-transform duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none", x === h[1].view && "translate-x-full")
                    }), h.map(t => {
                        var i;
                        let a, l, c, p = x === t.view;
                        return (0, r.jsx)(n(), {
                            href: (i = t.view, a = new URLSearchParams, "category" === i && a.set(o.$H, o.UE), (l = e.get(d.T$)) && a.set(d.T$, l), (c = a.toString()) ? `/products?${c}` : "/products"),
                            scroll: !1,
                            onClick: () => m({
                                view: t.view,
                                from: s
                            }),
                            "aria-current": s === t.view ? "page" : void 0,
                            className: (0, u.cn)("group/seg relative rounded-full px-3.5 py-1.5 text-center text-[13px] font-medium sm:px-4 sm:text-[14px]", "outline-none focus-visible:ring-2 focus-visible:ring-cp-select focus-visible:ring-offset-1", "active:scale-[0.98] motion-reduce:active:scale-100"),
                            children: (0, r.jsx)("span", {
                                className: (0, u.cn)("relative whitespace-nowrap transition-colors duration-[160ms] ease-out", p ? "text-white" : "text-cp-muted group-hover/seg:text-cp-ink"),
                                children: t.label
                            })
                        }, t.view)
                    })]
                })
            }
        },
        96220: (e, t, s) => {
            "use strict";
            s.d(t, {
                OY: () => d,
                RL: () => o,
                Ri: () => p,
                Ub: () => l,
                jt: () => c
            }), s(73365);
            var r = s(22868),
                i = s(60544),
                n = s(48523),
                a = s(1521);

            function l(e) {
                return (0, a.useSyncExternalStore)(t => {
                    let s = window.matchMedia(e);
                    return s.addEventListener("change", t), () => s.removeEventListener("change", t)
                }, () => window.matchMedia(e).matches, () => !1)
            }

            function o() {
                return l("(min-width: 1024px) and (pointer: fine)")
            }

            function c() {
                return l("(prefers-reduced-motion: reduce)")
            }

            function d(e, t = ["start end", "end start"]) {
                let {
                    scrollYProgress: s
                } = (0, r.L)({
                    target: e,
                    offset: t
                });
                return s
            }

            function p(e, t, s) {
                let r = (0, i.p)([...t], [...s]);
                return (0, n.G)(e, e => r(e))
            }
        },
        99719: (e, t, s) => {
            "use strict";
            s.d(t, {
                ProductsHeading: () => p,
                ProductsListingSwitch: () => m,
                ProductsPairedOffer: () => u
            });
            var r = s(73365),
                i = s(29717),
                n = s(1521),
                a = s(84395),
                l = s(26821),
                o = s(26752),
                c = s(44616);

            function d(e) {
                let t = (0, n.useRef)(e),
                    s = (0, n.useRef)(!1);
                return e !== t.current && (s.current = !0), s.current ? "animate-type-switch-in motion-reduce:animate-none" : void 0
            }

            function p() {
                let e = (0, i.useSearchParams)(),
                    t = "gifts" === (0, c.df)(e.get("type") ? ? void 0),
                    s = d(t),
                    n = o.O.productsPage.listing,
                    a = o.O.productsPage.giftsListing;
                return (0, r.jsx)("div", {
                    className: "min-w-0 flex-1 basis-[18rem]",
                    children: (0, r.jsx)("div", {
                        className: s,
                        children: (0, r.jsx)("h1", {
                            className: "min-h-[4rem] text-balance text-[28px] leading-[1.15] font-semibold tracking-[-0.02em] text-cp-ink sm:min-h-0 sm:text-[32px]",
                            children: t ? a.title : n.title
                        })
                    }, t ? "gifts" : "templates")
                })
            }

            function u() {
                let e = (0, i.useSearchParams)(),
                    t = "gifts" === (0, c.df)(e.get("type") ? ? void 0),
                    s = d(t),
                    n = o.O.productsPage.giftsListing;
                if (!t) return null;
                let p = n.pairedOffer;
                return (0, r.jsx)("div", {
                    className: `mb-8 -mt-2 ${s??""}`,
                    children: (0, r.jsx)("div", {
                        className: "rounded-2xl border border-cp-line bg-cp-pastel-butter px-5 py-5 text-cp-pastel-butter-ink sm:px-7 sm:py-6",
                        children: (0, r.jsxs)("div", {
                            className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between sm:gap-8",
                            children: [(0, r.jsxs)("div", {
                                className: "min-w-0",
                                children: [(0, r.jsxs)("span", {
                                    className: "inline-flex items-center gap-1.5 rounded-full bg-cp-bg/70 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.12em]",
                                    children: [(0, r.jsx)(a.A, {
                                        className: "size-3",
                                        strokeWidth: 1.75,
                                        "aria-hidden": "true"
                                    }), p.label]
                                }), (0, r.jsxs)("h2", {
                                    className: "mt-3 flex flex-wrap items-baseline gap-x-2 gap-y-1 text-lg font-semibold tracking-[-0.015em] text-cp-ink sm:text-2xl",
                                    children: [(0, r.jsx)("span", {
                                        children: p.buy
                                    }), (0, r.jsx)("span", {
                                        "aria-hidden": !0,
                                        className: "text-cp-pastel-butter-ink/70",
                                        children: p.connector
                                    }), (0, r.jsx)("span", {
                                        className: "text-cp-pastel-butter-ink",
                                        children: p.free
                                    })]
                                }), (0, r.jsx)("p", {
                                    className: "mt-2 text-sm leading-6",
                                    children: p.note
                                }), (0, r.jsx)("ul", {
                                    className: "mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs",
                                    children: p.points.map(e => (0, r.jsxs)("li", {
                                        className: "flex items-center gap-1.5",
                                        children: [(0, r.jsx)(l.A, {
                                            className: "size-3 shrink-0",
                                            strokeWidth: 1.75,
                                            "aria-hidden": "true"
                                        }), e]
                                    }, e))
                                })]
                            }), (0, r.jsxs)("div", {
                                className: "hidden shrink-0 flex-col items-center gap-1 sm:flex",
                                children: [(0, r.jsx)("span", {
                                    className: "text-3xl font-semibold tracking-[-0.02em]",
                                    children: "FREE"
                                }), (0, r.jsx)("span", {
                                    className: "text-[11px] uppercase tracking-[0.12em]",
                                    children: "with every gift"
                                })]
                            })]
                        })
                    })
                })
            }

            function m({
                templates: e,
                gifts: t
            }) {
                let s = (0, i.useSearchParams)(),
                    n = "gifts" === (0, c.df)(s.get("type") ? ? void 0),
                    a = d(n);
                return (0, r.jsx)("div", {
                    className: a,
                    children: n ? t : e
                }, n ? "gifts" : "templates")
            }
        }
    },
    e => {
        e.O(0, [84327, 99568, 38137, 20131, 20801, 89975, 26752, 47105, 80304, 32874, 27321, 94505, 2347, 15158, 77358], () => e(e.s = 31690)), _N_E = e.O()
    }
]);