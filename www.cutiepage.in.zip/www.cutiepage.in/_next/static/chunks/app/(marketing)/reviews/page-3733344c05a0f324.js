(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [40064], {
        21196: (e, r, t) => {
            "use strict";
            t.r(r), t.d(r, {
                RevealSection: () => i
            });
            var n = t(73365),
                o = t(1521),
                a = t(54872);

            function i({
                children: e,
                className: r,
                delayMs: t = 0
            }) {
                let s = (0, o.useRef)(null),
                    [l, c] = (0, o.useState)(!0);
                return (0, o.useEffect)(() => {
                    let e = s.current;
                    if (!e || "u" < typeof IntersectionObserver || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
                    let r = e.getBoundingClientRect();
                    if (r.top <= .92 * window.innerHeight) return;
                    let t = 0,
                        n = window.innerWidth;
                    for (let r = e.parentElement; r; r = r.parentElement)
                        if ("visible" !== getComputedStyle(r).overflowX) {
                            let e = r.getBoundingClientRect();
                            t = Math.max(t, e.left), n = Math.min(n, e.right)
                        }
                    if (r.left >= n - 8 || r.right <= t + 8) return;
                    c(!1);
                    let o = new IntersectionObserver(e => {
                        e.some(e => e.isIntersecting) && (c(!0), o.disconnect())
                    }, {
                        rootMargin: "0px 0px -8% 0px"
                    });
                    return o.observe(e), () => o.disconnect()
                }, []), (0, n.jsx)("div", {
                    ref: s,
                    className: (0, a.cn)("reveal-section", l && "is-visible", r),
                    style: {
                        transitionDelay: `${t}ms`
                    },
                    children: e
                })
            }
        },
        25896: (e, r, t) => {
            Promise.resolve().then(t.bind(t, 70154)), Promise.resolve().then(t.bind(t, 21196))
        },
        54872: (e, r, t) => {
            "use strict";
            t.d(r, {
                cn: () => a
            });
            var n = t(68662),
                o = t(35490);

            function a(...e) {
                return (0, o.QP)((0, n.$)(e))
            }
        },
        70154: (e, r, t) => {
            "use strict";
            t.d(r, {
                CreatorVideoWall: () => d,
                N: () => s,
                h: () => l
            });
            var n = t(73365),
                o = t(1521),
                a = t(78175),
                i = t(70288);

            function s() {
                if ("u" < typeof navigator) return !1;
                let e = navigator.connection;
                if (!e) return !1;
                if (e.saveData) return !0;
                let r = e.effectiveType ? ? "";
                return "slow-2g" === r || "2g" === r || "3g" === r || "number" == typeof e.downlink && e.downlink > 0 && e.downlink < 1.5
            }

            function l({
                video: e,
                index: r,
                lowBitrate: t
            }) {
                let a = (0, o.useRef)(null),
                    s = (0, o.useRef)(null),
                    [c, d] = (0, o.useState)(!1),
                    [u, p] = (0, o.useState)(!1),
                    f = t ? e.lowSrc : e.src;
                return (0, o.useEffect)(() => {
                    let e = s.current;
                    if (!e || (0, i.r)(navigator) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
                    if ("u" < typeof IntersectionObserver) return void d(!0);
                    let r = new IntersectionObserver(e => {
                        e.some(e => e.isIntersecting) && (d(!0), r.disconnect())
                    }, {
                        rootMargin: "100% 0px"
                    });
                    return r.observe(e), () => r.disconnect()
                }, []), (0, o.useEffect)(() => {
                    if (!c) return;
                    let e = a.current;
                    if (!e) return;
                    if (e.muted = !0, e.defaultMuted = !0, e.setAttribute("controlsList", "nodownload noplaybackrate noremoteplayback"), e.disablePictureInPicture = !0, "u" < typeof IntersectionObserver) return void e.play().catch(() => {});
                    let r = new IntersectionObserver(r => {
                        for (let t of r) t.isIntersecting ? e.play().catch(() => {}) : e.paused || e.pause()
                    }, {
                        threshold: .35
                    });
                    return r.observe(e), () => r.disconnect()
                }, [c]), (0, n.jsxs)("div", {
                    ref: s,
                    className: "group relative overflow-hidden rounded-[1.35rem] border border-[var(--color-border)] bg-[#EFEAE1] shadow-[0_8px_22px_rgba(15,23,42,0.06)] transition-[border-color,box-shadow] duration-300 hover:border-[var(--color-lavender)]/40 hover:shadow-[0_12px_28px_rgba(91,63,232,0.10)]",
                    style: {
                        aspectRatio: "9 / 16",
                        animationDelay: `${70*r}ms`
                    },
                    onContextMenu: e => e.preventDefault(),
                    children: [(0, n.jsx)("video", {
                        ref: a,
                        muted: !0,
                        loop: !0,
                        playsInline: !0,
                        preload: c ? "metadata" : "none",
                        onLoadedData: () => p(!0),
                        onContextMenu: e => e.preventDefault(),
                        className: `size-full object-cover transition-opacity duration-700 ${u?"opacity-100":"opacity-0"}`,
                        children: c ? (0, n.jsx)("source", {
                            src: f,
                            type: "video/mp4"
                        }) : null
                    }), (0, n.jsx)("img", {
                        src: e.poster,
                        alt: "",
                        loading: "lazy",
                        "aria-hidden": !0,
                        draggable: !1,
                        onContextMenu: e => e.preventDefault(),
                        className: `pointer-events-none absolute inset-0 size-full object-cover transition-opacity duration-700 ${u?"opacity-0":"opacity-100"}`
                    }), (0, n.jsx)("div", {
                        "aria-hidden": !0,
                        className: "absolute inset-0 z-10 select-none",
                        onContextMenu: e => e.preventDefault(),
                        style: {
                            WebkitTouchCallout: "none",
                            WebkitUserSelect: "none"
                        }
                    }), (0, n.jsx)("div", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-x-0 bottom-0 z-20 h-2/5 bg-gradient-to-t from-black/45 via-black/10 to-transparent opacity-80"
                    }), (0, n.jsxs)("div", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute bottom-2 left-2 z-20 flex items-center gap-1 rounded-full bg-black/35 px-1.5 py-0.5 text-[8px] font-semibold uppercase tracking-[0.12em] text-white/90 backdrop-blur-sm sm:bottom-3 sm:left-3 sm:gap-1.5 sm:px-2.5 sm:py-1 sm:text-[10px] sm:tracking-[0.14em]",
                        children: [(0, n.jsxs)("span", {
                            className: "relative flex size-1 sm:size-1.5",
                            children: [(0, n.jsx)("span", {
                                className: "absolute inline-flex size-full animate-ping rounded-full bg-white/70"
                            }), (0, n.jsx)("span", {
                                className: "relative inline-flex size-1 rounded-full bg-white sm:size-1.5"
                            })]
                        }), "Creator"]
                    })]
                })
            }
            let c = {
                wide: "grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-6",
                compact: "grid grid-cols-3 gap-3 sm:gap-4 sm:grid-cols-6"
            };

            function d({
                layout: e = "wide"
            }) {
                let [r, t] = (0, o.useState)(!1);
                return (0, o.useEffect)(() => {
                    t(s())
                }, []), (0, n.jsx)("div", {
                    className: c[e],
                    children: a.X.map((e, t) => (0, n.jsx)(l, {
                        video: e,
                        index: t,
                        lowBitrate: r
                    }, e.id))
                })
            }
        },
        70288: (e, r, t) => {
            "use strict";
            t.d(r, {
                HomeMotionTier: () => a,
                r: () => o
            });
            var n = t(1521);

            function o(e) {
                return !!e.connection ? .saveData || "number" == typeof e.deviceMemory && e.deviceMemory <= 2 || "number" == typeof e.hardwareConcurrency && e.hardwareConcurrency > 0 && e.hardwareConcurrency <= 2
            }

            function a() {
                return (0, n.useEffect)(() => {
                    if (!o(navigator)) return;
                    let e = document.documentElement;
                    return e.dataset.homeMotion = "lite", () => {
                        delete e.dataset.homeMotion
                    }
                }, []), null
            }
        },
        78175: (e, r, t) => {
            "use strict";
            t.d(r, {
                X: () => n
            });
            let n = [{
                id: "creator-1",
                src: "/api/creator-reels/r1h",
                lowSrc: "/api/creator-reels/r1l",
                poster: "/api/creator-reels/r1p"
            }, {
                id: "creator-2",
                src: "/api/creator-reels/r2h",
                lowSrc: "/api/creator-reels/r2l",
                poster: "/api/creator-reels/r2p"
            }, {
                id: "creator-3",
                src: "/api/creator-reels/r3h",
                lowSrc: "/api/creator-reels/r3l",
                poster: "/api/creator-reels/r3p"
            }, {
                id: "creator-4",
                src: "/api/creator-reels/r4h",
                lowSrc: "/api/creator-reels/r4l",
                poster: "/api/creator-reels/r4p"
            }, {
                id: "creator-5",
                src: "/api/creator-reels/r5h",
                lowSrc: "/api/creator-reels/r5l",
                poster: "/api/creator-reels/r5p"
            }, {
                id: "creator-6",
                src: "/api/creator-reels/r6h",
                lowSrc: "/api/creator-reels/r6l",
                poster: "/api/creator-reels/r6p"
            }]
        }
    },
    e => {
        e.O(0, [84327, 2347, 15158, 77358], () => e(e.s = 25896)), _N_E = e.O()
    }
]);