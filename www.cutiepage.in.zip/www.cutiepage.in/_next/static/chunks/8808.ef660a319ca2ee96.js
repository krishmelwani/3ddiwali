"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8808], {
        1960: (e, t, n) => {
            n.d(t, {
                b: () => i
            });
            var r = n(73365),
                a = n(96331);

            function i() {
                return (0, r.jsxs)("div", {
                    role: "status",
                    className: "absolute inset-0 flex flex-col items-center justify-center bg-cp-canvas px-6",
                    children: [(0, r.jsx)(a.k, {}), (0, r.jsx)("p", {
                        className: "mt-4 text-[14px] font-medium text-cp-muted",
                        children: "Loading preview"
                    })]
                })
            }
        },
        2911: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("loader-circle", [
                ["path", {
                    d: "M21 12a9 9 0 1 1-6.219-8.56",
                    key: "13zald"
                }]
            ])
        },
        7939: (e, t, n) => {
            n.d(t, {
                $F: () => l,
                F0: () => i,
                o2: () => a,
                zn: () => s
            });
            let r = null;

            function a(e) {
                return r = e, () => {
                    r === e && (r = null)
                }
            }

            function i() {
                return r
            }

            function s(e, t) {
                return !!e && !!t && e.kind === t.kind && ("project" === e.kind ? e.projectId === t.projectId : e.templateSlug === t.templateSlug)
            }
            let l = {
                applying: "Updating your page",
                done: "Updated on your page",
                undo: "Undo",
                undone: "Undone",
                record: "Sent a change to your page",
                notHere: "Open this page in the editor to see the change.",
                changedMeanwhile: "Your page changed while I was working, so I left it as it was. Ask me again.",
                photoFailed: "I couldn't add that photo. Please send it again and ask me once more.",
                editedSince: "You've changed it since, so I left it as it is.",
                undoFailed: "I couldn't undo that here. You can undo it in the editor.",
                failed: "I couldn't make that change in your editor. Please try again."
            }
        },
        8808: (e, t, n) => {
            n.r(t), n.d(t, {
                SupportWidget: () => tg
            });
            var r = n(73365),
                a = n(1521),
                i = n(29717),
                s = n(56855),
                l = n(7939);
            let o = ["thinking", "templates", "help", "projects", "payment", "team", "page", "writing"];
            var c = n(62727);
            let d = new Set(["image/png", "image/jpeg", "image/webp"]);

            function u(e) {
                return !!e && d.has(e.type)
            }
            let p = /^[A-Za-z0-9_-]{1,64}$/;

            function m(e) {
                return "string" == typeof e && p.test(e) ? `/api/support/attachments/${encodeURIComponent(e)}` : null
            }
            let h = {
                    phase: "none"
                },
                f = [1600, 1280, 1024],
                x = [.82, .72, .6, .5];
            async function g(e, t, n = 9e5) {
                for (let r of function(e, t) {
                        let n = [],
                            r = new Set;
                        for (let a of f) {
                            let i = function(e, t, n) {
                                let r = Math.max(e, t);
                                if (!(r > 0)) return {
                                    width: 0,
                                    height: 0
                                };
                                let a = r > n ? n / r : 1;
                                return {
                                    width: Math.max(1, Math.round(e * a)),
                                    height: Math.max(1, Math.round(t * a))
                                }
                            }(e, t, a);
                            if (0 === i.width) return [];
                            let s = `${i.width}x${i.height}`;
                            if (!r.has(s))
                                for (let e of (r.add(s), x)) n.push({ ...i,
                                    quality: e
                                })
                        }
                        return n
                    }(e.width, e.height)) {
                    let e = await t(r);
                    if (e && e.size > 0 && e.size <= n) return e
                }
                return null
            }

            function b(e, t, n) {
                return new Promise(r => {
                    try {
                        e.toBlob(e => r(e), t, n)
                    } catch {
                        r(null)
                    }
                })
            }
            async function y(e) {
                let t;
                try {
                    t = await createImageBitmap(e)
                } catch {
                    return null
                }
                try {
                    let e = document.createElement("canvas"),
                        n = e.getContext("2d");
                    if (!n) return null;
                    let r = null,
                        a = async a => {
                            if (e.width = a.width, e.height = a.height, n.fillStyle = "white", n.fillRect(0, 0, a.width, a.height), n.drawImage(t, 0, 0, a.width, a.height), !r) {
                                let t = await b(e, "image/webp", a.quality);
                                if (r = t && "image/webp" === t.type ? "image/webp" : "image/jpeg", "image/webp" === r) return t
                            }
                            return b(e, r, a.quality)
                        },
                        i = await g({
                            width: t.width,
                            height: t.height
                        }, a);
                    if (!i) return null;
                    let s = "image/webp" === i.type ? "webp" : "jpg";
                    return new File([i], `screenshot.${s}`, {
                        type: i.type || "image/jpeg"
                    })
                } catch {
                    return null
                } finally {
                    t.close()
                }
            }
            let v = new Map;

            function k(e) {
                return v.get(e) ? ? null
            }
            async function* w(e) {
                var t;
                let n, r, a = e.getReader(),
                    i = new TextDecoder,
                    s = [],
                    l = (t = e => s.push(e), n = "", r = e => {
                        let n, r = e.trim();
                        if (r) {
                            try {
                                n = JSON.parse(r)
                            } catch {
                                return
                            }
                            t(n)
                        }
                    }, {
                        push(e) {
                            let t = (n += e).indexOf("\n");
                            for (; t >= 0;) r(n.slice(0, t)), t = (n = n.slice(t + 1)).indexOf("\n")
                        },
                        flush() {
                            let e = n;
                            n = "", r(e)
                        }
                    });
                try {
                    for (;;) {
                        let {
                            done: e,
                            value: t
                        } = await a.read();
                        if (e) break;
                        for (l.push(i.decode(t, {
                                stream: !0
                            })); s.length;) yield s.shift()
                    }
                    for (l.push(i.decode()), l.flush(); s.length;) yield s.shift()
                } finally {
                    a.releaseLock()
                }
            }

            function j(e) {
                return "string" == typeof e
            }

            function N(e) {
                return !!e && "object" == typeof e && j(e.slug) && j(e.name) && j(e.imageUrl) && "number" == typeof e.priceInr && Number.isFinite(e.priceInr) && (null === e.regularPriceInr || void 0 === e.regularPriceInr || "number" == typeof e.regularPriceInr && Number.isFinite(e.regularPriceInr)) && j(e.tryUrl)
            }

            function A(e) {
                return !!e && "object" == typeof e && j(e.id) && j(e.title) && j(e.templateName) && j(e.status)
            }

            function I(e) {
                if (!e || "object" != typeof e || !j(e.label) || ! function(e) {
                        if (!e || "object" != typeof e) return !1;
                        let t = e => null === e || j(e);
                        return j(e.pageId) && j(e.sectionId) && j(e.fieldId) && t(e.stackId) && t(e.itemId)
                    }(e.address)) return null;
                let t = {
                    pageId: e.address.pageId,
                    sectionId: e.address.sectionId,
                    stackId: e.address.stackId ? ? null,
                    itemId: e.address.itemId ? ? null,
                    fieldId: e.address.fieldId
                };
                return "text" === e.kind && j(e.text) && (null === e.before || j(e.before)) ? {
                    kind: "text",
                    label: e.label,
                    address: t,
                    text: e.text,
                    before: e.before
                } : "photo" === e.kind && j(e.attachmentId) && e.attachmentId ? {
                    kind: "photo",
                    label: e.label,
                    address: t,
                    attachmentId: e.attachmentId
                } : null
            }

            function S(e) {
                if (!e || "object" != typeof e) return null;
                switch (e.type) {
                    case "meta":
                        return j(e.conversationId) && e.conversationId ? {
                            type: "meta",
                            conversationId: e.conversationId
                        } : null;
                    case "text":
                        return j(e.delta) ? {
                            type: "text",
                            delta: e.delta
                        } : null;
                    case "status":
                        return j(e.phase) && o.includes(e.phase) ? {
                            type: "status",
                            phase: e.phase
                        } : null;
                    case "templates":
                        return Array.isArray(e.items) ? {
                            type: "templates",
                            items: e.items.filter(N)
                        } : null;
                    case "project_picker":
                        return Array.isArray(e.items) ? {
                            type: "project_picker",
                            items: e.items.filter(A)
                        } : null;
                    case "access_granted":
                        return j(e.projectId) && j(e.editorUrl) ? {
                            type: "access_granted",
                            projectId: e.projectId,
                            editorUrl: e.editorUrl
                        } : null;
                    case "page_edit":
                        {
                            var t;
                            if (!Array.isArray(e.labels)) return null;
                            let n = e.labels.filter(j).slice(0, 8),
                                r = Array.isArray(e.changes) ? e.changes : [],
                                a = r.map(I),
                                i = r.length <= 8 && a.every(e => null !== e),
                                s = (t = e.target) && "object" == typeof t ? "project" === t.kind && j(t.projectId) && t.projectId ? {
                                    kind: "project",
                                    projectId: t.projectId
                                } : "guest" === t.kind && j(t.templateSlug) && t.templateSlug ? {
                                    kind: "guest",
                                    templateSlug: t.templateSlug
                                } : null : null;
                            return {
                                type: "page_edit",
                                target: i && s ? s : null,
                                changes: i && s ? a : [],
                                labels: n
                            }
                        }
                    case "escalated":
                        return {
                            type: "escalated"
                        };
                    case "limit":
                        return "rate" === e.reason || "budget" === e.reason || "length" === e.reason || "signin" === e.reason || "daily" === e.reason ? {
                            type: "limit",
                            reason: e.reason
                        } : null;
                    case "error":
                        return j(e.message) && e.message.trim() ? {
                            type: "error",
                            message: e.message
                        } : null;
                    case "human_active":
                        return {
                            type: "human_active"
                        };
                    case "done":
                        return {
                            type: "done"
                        };
                    default:
                        return null
                }
            }

            function E(e) {
                return /^\/(?![/\\])/.test(e) && !/[\s<>"]/.test(e)
            }
            let z = "Kiara",
                $ = "The cat CEO at CutiePage",
                M = "our CEO handed over the company to cats, and I'm the CEO now hehe.",
                _ = ["Birthday ideas for my partner", "Anniversary ideas for my partner", "Issue with payment", "My budget is under \u20b9150", "Show me pages under \u20b929", "What is Cutiepage and how does it work?"],
                C = "Cutiepage team",
                R = "Tell me about this template",
                F = "Help me choose",
                D = ["How do I make it live?", "Change a photo", "Add music", "Issue with payment"],
                T = "My pages",
                L = "Kiara is typing",
                P = "Sorry, Kiara could not answer just now. Please try again in a moment.";

            function U(e, t) {
                let {
                    note: n,
                    text: r
                } = function(e) {
                    switch (e) {
                        case "rate":
                            return {
                                note: "limit-rate",
                                text: "You're sending messages quickly. Please wait a few minutes and try again."
                            };
                        case "budget":
                            return {
                                note: "limit-budget",
                                text: "Kiara is resting for today."
                            };
                        case "length":
                            return {
                                note: "limit-length",
                                text: "This chat got long, so it has been closed. Send a new message to start fresh."
                            };
                        case "signin":
                            return {
                                note: "limit-signin",
                                text: "Sign in to keep chatting with Kiara. Your conversation will continue right here."
                            };
                        case "daily":
                            return {
                                note: "limit-daily",
                                text: "You've reached today's limit of messages with Kiara. You can chat again in 24 hours, or reach our team from the contact page."
                            }
                    }
                }(t), a = e[e.length - 1];
                return a && "note" === a.kind && a.note === n ? V(e) : X(e, n, r)
            }
            let W = /^\/templates\/[^/]+\/?$/i,
                O = /^\/(?:products|[a-z0-9]+(?:-[a-z0-9]+)*-templates)\/?$/i,
                Y = {
                    upload_failed: "My photo won't upload",
                    save_failed: "My changes aren't saving",
                    payment_failed: "My payment didn't go through",
                    publish_failed: "I can't make my page live",
                    slug_taken: "My link name is taken"
                },
                H = 0;

            function q(e = "m") {
                return H += 1, `${e}${H}`
            }

            function V(e) {
                let t = !1,
                    n = e.flatMap(e => {
                        if ("assistant" === e.kind && e.live) {
                            t = !0;
                            let n = B(e.text);
                            return n ? [{ ...e,
                                text: n,
                                live: !1
                            }] : []
                        }
                        return [e]
                    });
                return t ? n : e
            }
            let K = /\n[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*\n/;

            function B(e) {
                return e.replace(/\n[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*$/, "").trim()
            }

            function X(e, t, n) {
                return [...V(e), {
                    id: q("n"),
                    kind: "note",
                    note: t,
                    text: n
                }]
            }

            function Z(e) {
                return e.some(e => "note" === e.kind && "human" === e.note) ? V(e) : X(e, "human", "A person from our team is handling this chat now. Their replies will appear here.")
            }

            function J(e) {
                return null !== e.target && e.changes.length > 0
            }

            function Q(e, t, n = q("e")) {
                return [...V(e), {
                    id: n,
                    kind: "page_edit",
                    labels: t.labels.slice(0, 8),
                    status: J(t) ? "applying" : "record"
                }]
            }

            function G(e, t, n, r) {
                let a = !1,
                    i = e.map(e => e.id !== t || "page_edit" !== e.kind || "record" === e.status ? e : (a = !0, {
                        id: e.id,
                        kind: "page_edit",
                        labels: e.labels,
                        status: n,
                        ...r ? {
                            message: r
                        } : {}
                    }));
                return a ? i : e
            }

            function ee(e, t) {
                switch (t.type) {
                    case "meta":
                    case "status":
                        return e;
                    case "text":
                        {
                            if (!t.delta) return e;
                            let n = e[e.length - 1],
                                r = n && "assistant" === n.kind && n.live,
                                a = r ? e.slice(0, -1) : e,
                                i = (r ? n.text : "") + t.delta,
                                s = `
${i}`.split(K),
                                l = s.pop() ? ? "",
                                o = s.map(B).filter(Boolean).map((e, t) => ({
                                    id: 0 === t && r ? n.id : q("a"),
                                    kind: "assistant",
                                    text: e,
                                    live: !1
                                })),
                                c = (s.length > 0 ? l : i).replace(/^\n+/, "");
                            if (!c) return [...a, ...o];
                            let d = r && 0 === o.length;
                            return [...a, ...o, {
                                id: d ? n.id : q("a"),
                                kind: "assistant",
                                text: c,
                                live: !0
                            }]
                        }
                    case "templates":
                        if (0 === t.items.length) return V(e);
                        return [...V(e), {
                            id: q("t"),
                            kind: "templates",
                            items: t.items
                        }];
                    case "project_picker":
                        if (0 === t.items.length) return V(e);
                        return [...V(e), {
                            id: q("p"),
                            kind: "project_picker",
                            items: t.items,
                            picked: null,
                            locked: !1
                        }];
                    case "access_granted":
                        return [...V(e), {
                            id: q("g"),
                            kind: "granted",
                            projectId: t.projectId,
                            editorUrl: t.editorUrl,
                            fresh: !0
                        }];
                    case "page_edit":
                        return Q(e, t);
                    case "escalated":
                        return X(e, "escalated", "You're connected with our team. They'll reply here.");
                    case "limit":
                        return U(e, t.reason);
                    case "error":
                        return X(e, "error", t.message);
                    case "human_active":
                        return Z(e);
                    case "done":
                        return V(e)
                }
            }

            function et(e, t) {
                if (!t || "object" != typeof t || "event" !== t.kind && "string" != typeof t.text) return e;
                switch (t.kind) {
                    case "user":
                        {
                            let n = function(e) {
                                if (!Array.isArray(e)) return;
                                let t = [];
                                for (let n of e) {
                                    let e = "string" == typeof n ? m(n) : null;
                                    e && t.push({
                                        src: e
                                    })
                                }
                                return t.length > 0 ? t : void 0
                            }(t.attachments);
                            if (!t.text && !n) return e;
                            return [...V(e), {
                                id: q("u"),
                                kind: "user",
                                text: t.text,
                                ...n ? {
                                    attachments: n
                                } : {}
                            }]
                        }
                    case "assistant":
                        {
                            var n;
                            let r = t.text ? (n = t.text, `
${n}`.split(K).map(B).filter(Boolean)) : [];
                            return r.length > 0 ? [...V(e), ...r.map(e => ({
                                id: q("a"),
                                kind: "assistant",
                                text: e,
                                live: !1
                            }))] : e
                        }
                    case "agent":
                        return t.text ? [...V(e), {
                            id: q("s"),
                            kind: "agent",
                            text: t.text
                        }] : e;
                    case "event":
                        {
                            let n = S(t.event);
                            if (!n) return e;
                            if ("page_edit" === n.type) return Q(e, { ...n,
                                target: null,
                                changes: []
                            });
                            return ee(e, n)
                        }
                    default:
                        return e
                }
            }

            function en(e, t) {
                let n = [];
                for (let t of e) n = et(n, t);
                return t ? .signedIn && (n = n.filter(e => "note" !== e.kind || "limit-signin" !== e.note)), n = V(n).map((e, t, n) => "granted" === e.kind ? { ...e,
                    fresh: !1
                } : "project_picker" === e.kind && t !== n.length - 1 ? { ...e,
                    locked: !0
                } : e)
            }

            function er(e, t) {
                let n = new URLSearchParams({
                    conversationId: e
                });
                return t && n.set("after", t), `/api/support/history?${n.toString()}`
            }
            let ea = {
                seen: new Set,
                newestAt: null
            };

            function ei(e) {
                let t = "event" === e.kind ? `event:${e.event?.type??""}` : e.text;
                return `${e.at}|${e.kind}|${t}`
            }

            function es(e, t) {
                if (!e) return t;
                let n = Date.parse(e),
                    r = Date.parse(t);
                return Number.isNaN(r) ? e : Number.isNaN(n) || r > n ? t : e
            }

            function el(e) {
                let t = new Set,
                    n = null;
                for (let r of e) r && "string" == typeof r.at && (t.add(ei(r)), n = es(n, r.at));
                return {
                    seen: t,
                    newestAt: n
                }
            }

            function eo(e) {
                switch (e.kind) {
                    case "user":
                        return "user";
                    case "agent":
                        return "team";
                    case "note":
                        return "system";
                    default:
                        return "kiara"
                }
            }
            let ec = {
                    templates: "Looking through templates",
                    help: "Checking our help guides",
                    projects: "Finding your pages",
                    payment: "Checking your payment",
                    team: "Getting our team",
                    page: l.$F.applying
                },
                ed = [
                    [8e3, "Almost there"],
                    [5e3, "Putting it together"],
                    [2500, "Reading your message"],
                    [0, "Thinking"]
                ];

            function eu(e, t) {
                return "writing" === e ? t >= 9e3 ? "Almost there" : "Writing your answer" : "thinking" !== e ? ec[e] : ed.find(([e]) => t >= e) ? .[1] ? ? "Thinking"
            }
            var ep = n(99568),
                em = n.n(ep),
                eh = n(79225),
                ef = n(44121),
                ex = n(26821),
                eg = n(50975),
                eb = n(2911),
                ey = n(45086),
                ev = n(83078),
                ek = n(64112),
                ew = n(72705);
            let ej = (0, n(96296).A)("folder-heart", [
                ["path", {
                    d: "M10.638 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v3.417",
                    key: "10r6g4"
                }],
                ["path", {
                    d: "M14.62 18.8A2.25 2.25 0 1 1 18 15.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
                    key: "15cy7q"
                }]
            ]);
            var eN = n(27544),
                eA = n(24583),
                eI = n(9388),
                eS = n(54872);

            function eE({
                editorUrl: e,
                refreshOnMount: t
            }) {
                let n = (0, i.useRouter)(),
                    s = (0, a.useRef)(!1);
                (0, a.useEffect)(() => {
                    t && !s.current && (s.current = !0, n.refresh())
                }, [t, n]);
                let l = E(e) ? e : "/dashboard";
                return (0, r.jsxs)("div", {
                    className: "rounded-xl border border-cp-success/30 bg-cp-success/10 p-4",
                    children: [(0, r.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [(0, r.jsx)(ev.A, {
                            className: "size-4 shrink-0 text-cp-success-ink",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }), (0, r.jsx)("p", {
                            className: "text-[14px] font-semibold text-cp-success-ink",
                            children: "Your page is unlocked"
                        })]
                    }), (0, r.jsx)("p", {
                        className: "mt-1 text-[13px] leading-relaxed text-cp-ink",
                        children: "Your payment went through. You can finish your page and make it live now."
                    }), (0, r.jsx)(eI.$, {
                        asChild: !0,
                        size: "sm",
                        className: "mt-3",
                        children: (0, r.jsx)(em(), {
                            href: l,
                            prefetch: !1,
                            children: "Open the editor"
                        })
                    })]
                })
            }
            var ez = n(89622),
                e$ = n(89931),
                eM = n(56224);
            let e_ = {
                draft: {
                    label: "Draft",
                    tone: "neutral"
                },
                ready_for_checkout: {
                    label: "Not paid yet",
                    tone: "neutral"
                },
                payment_pending: {
                    label: "Payment pending",
                    tone: "warning"
                },
                paid: {
                    label: "Paid",
                    tone: "success"
                },
                published: {
                    label: "Live",
                    tone: "success"
                },
                unpublished: {
                    label: "Offline",
                    tone: "neutral"
                },
                archived: {
                    label: "Archived",
                    tone: "neutral"
                }
            };

            function eC({
                items: e,
                picked: t,
                disabled: n,
                onPick: a
            }) {
                return (0, r.jsx)("div", {
                    role: "group",
                    "aria-label": "Choose a project",
                    className: "flex flex-col gap-1.5",
                    children: e.map(e => {
                        let i = e.needsAttention ? {
                                label: "Needs attention",
                                tone: "warning"
                            } : e_[e.status] ? ? {
                                label: "Project",
                                tone: "neutral"
                            },
                            s = t === e.id;
                        return (0, r.jsxs)("button", {
                            type: "button",
                            disabled: n,
                            "aria-pressed": s,
                            onClick: () => a(e.id),
                            className: (0, eS.cn)("flex w-full items-start gap-3 rounded-xl border bg-cp-bg px-3 py-2.5 text-left transition-colors duration-150 motion-reduce:transition-none", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", s ? "border-cp-select bg-cp-primary-soft" : "border-cp-line", n ? "cursor-default" : "cursor-pointer hover:bg-cp-subtle", n && !s && "opacity-60"),
                            children: [(0, r.jsxs)("span", {
                                className: "min-w-0 flex-1",
                                children: [(0, r.jsx)("span", {
                                    className: "block truncate text-[13.5px] font-medium text-cp-ink",
                                    children: e.title || "Untitled page"
                                }), (0, r.jsx)("span", {
                                    className: "mt-0.5 block truncate text-[12px] text-cp-muted",
                                    children: e.templateName
                                }), (0, r.jsxs)("span", {
                                    className: "mt-1.5 flex flex-wrap gap-1",
                                    children: [(0, r.jsx)(eM.E, {
                                        tone: i.tone,
                                        children: i.label
                                    }), e.liveSlug && "published" !== e.status ? (0, r.jsx)(eM.E, {
                                        tone: "primary",
                                        children: "Live"
                                    }) : null]
                                })]
                            }), s ? (0, r.jsx)(ex.A, {
                                className: "mt-0.5 size-4 shrink-0 text-cp-primary",
                                strokeWidth: 1.75,
                                "aria-hidden": !0
                            }) : null]
                        }, e.id)
                    })
                })
            }
            let eR = new Set(["/contact", "/products", "/products/cutie-pack", "/dashboard", "/login", "/rewards", "/plus", "/refund-shipping-policy", "/privacy-policy", "/terms-services", "/blog", "/guides", "/reviews", "/birthday-templates", "/love-templates", "/anniversary-templates", "/wedding-templates", "/family-templates", "/friendship-templates", "/apology-templates", "/festival-templates"]),
                eF = /^\/(?:templates|try|collections|blog)\/[a-z0-9-]{1,80}$/,
                eD = {
                    "/products": new Set(["category", "for"]),
                    "/dashboard": new Set(["tab"])
                },
                eT = /^[A-Za-z0-9._%+-]{1,60}$/;

            function eL(e) {
                if ("string" != typeof e || e.length > 200 || !E(e) || /\\|\/\/|\.\.|#/.test(e)) return null;
                let t = e.indexOf("?"),
                    n = -1 === t ? e : e.slice(0, t),
                    r = -1 === t ? "" : e.slice(t + 1);
                if (!eR.has(n) && !eF.test(n)) return null;
                if (-1 === t) return e;
                let a = eD[n];
                if (!a || !r) return null;
                let i = new Set;
                for (let e of r.split("&")) {
                    let t = e.indexOf("=");
                    if (t <= 0) return null;
                    let n = e.slice(0, t),
                        r = e.slice(t + 1);
                    if (!a.has(n) || i.has(n) || !eT.test(r)) return null;
                    i.add(n)
                }
                return e
            }
            let eP = /\[([^\]\n]{1,100})\]\(([^)\s]{1,200})\)|(^|[\s(])(\/[A-Za-z0-9\-._~/?=&%+#:\\]*)/g,
                eU = /[.,;:!?)]+$/,
                eW = /^\s{0,3}[-*\u2022]\s+(.*)$/,
                eO = /^\s{0,3}(\d{1,3})[.)]\s+(.*)$/;

            function eY(e) {
                let t = e.split("**");
                if (t.length % 2 == 0) {
                    let e = t.pop();
                    t[t.length - 1] = `${t[t.length-1]}**${e}`
                }
                let n = [],
                    r = (e, t) => {
                        if (!e) return;
                        let r = n[n.length - 1];
                        r && r.bold === t ? r.text += e : n.push({
                            text: e,
                            bold: t
                        })
                    };
                t.forEach((e, t) => {
                    let n = t % 2 == 1;
                    n && "" === e.trim() ? r(`**${e}**`, !1) : r(e, n)
                });
                let a = [];
                for (let e of n)
                    for (let t of function(e) {
                            let t = [],
                                n = e => {
                                    if (!e) return;
                                    let n = t[t.length - 1];
                                    n && !n.href ? n.text += e : t.push({
                                        text: e
                                    })
                                },
                                r = 0;
                            for (let a of e.matchAll(eP)) {
                                let i = a.index ? ? 0;
                                if (void 0 !== a[1]) {
                                    n(e.slice(r, i));
                                    let s = a[2],
                                        l = eL(s);
                                    l ? t.push({
                                        text: a[1],
                                        href: l
                                    }) : n(E(s) ? a[1] : a[0]), r = i + a[0].length;
                                    continue
                                }
                                let s = a[3] ? ? "",
                                    l = a[4] ? ? "",
                                    o = eU.exec(l) ? .[0] ? ? "",
                                    c = (l = l.slice(0, l.length - o.length)).length > 1 ? eL(l) : null;
                                c && (n(e.slice(r, i) + s), t.push({
                                    text: l,
                                    href: c
                                }), r = i + s.length + l.length)
                            }
                            return n(e.slice(r)), t
                        }(e.text)) a.push(t.href ? {
                        text: t.text,
                        bold: e.bold,
                        href: t.href
                    } : {
                        text: t.text,
                        bold: e.bold
                    });
                return a
            }

            function eH({
                text: e,
                animate: t
            }) {
                return t ? (0, r.jsx)(r.Fragment, {
                    children: e.split(/(\s+)/).map((e, t) => "" === e ? null : /^\s+$/.test(e) ? (0, r.jsx)(a.Fragment, {
                        children: e
                    }, t) : (0, r.jsx)("span", {
                        className: "kiara-word",
                        children: e
                    }, t))
                }) : (0, r.jsx)(r.Fragment, {
                    children: e
                })
            }

            function eq({
                spans: e,
                animate: t
            }) {
                return (0, r.jsx)(r.Fragment, {
                    children: e.map((e, n) => e.href ? (0, r.jsx)(em(), {
                        href: e.href,
                        prefetch: !1,
                        className: (0, eS.cn)(e.bold ? "font-semibold" : "font-medium", "text-cp-primary underline decoration-cp-primary/40 underline-offset-2 hover:decoration-cp-primary", t && "kiara-word"),
                        children: e.text
                    }, n) : e.bold ? (0, r.jsx)("strong", {
                        className: "font-semibold",
                        children: (0, r.jsx)(eH, {
                            text: e.text,
                            animate: t
                        })
                    }, n) : (0, r.jsx)(a.Fragment, {
                        children: (0, r.jsx)(eH, {
                            text: e.text,
                            animate: t
                        })
                    }, n))
                })
            }

            function eV({
                text: e,
                animate: t = !1
            }) {
                let n = function(e) {
                    let t = [],
                        n = null,
                        r = () => {
                            n && t.push(n), n = null
                        };
                    for (let t of e.replace(/\r\n?/g, "\n").split("\n")) {
                        if ("" === t.trim()) {
                            r();
                            continue
                        }
                        let e = eW.exec(t);
                        if (e) {
                            n ? .type !== "ul" && (r(), n = {
                                type: "ul",
                                items: []
                            }), n.items.push(eY(e[1].trim()));
                            continue
                        }
                        let a = eO.exec(t);
                        if (a) {
                            n ? .type !== "ol" && (r(), n = {
                                type: "ol",
                                start: Number(a[1]) || 1,
                                items: []
                            }), n.items.push(eY(a[2].trim()));
                            continue
                        }
                        n ? .type !== "paragraph" && (r(), n = {
                            type: "paragraph",
                            lines: []
                        }), n.lines.push(eY(t.trim()))
                    }
                    return r(), t
                }(e);
                return (0, r.jsx)("div", {
                    className: "space-y-2",
                    children: n.map((e, n) => {
                        switch (e.type) {
                            case "paragraph":
                                return (0, r.jsx)("p", {
                                    children: e.lines.map((e, n) => (0, r.jsxs)(a.Fragment, {
                                        children: [n > 0 ? (0, r.jsx)("br", {}) : null, (0, r.jsx)(eq, {
                                            spans: e,
                                            animate: t
                                        })]
                                    }, n))
                                }, n);
                            case "ul":
                                return (0, r.jsx)("ul", {
                                    className: "space-y-1.5",
                                    children: e.items.map((e, n) => (0, r.jsxs)("li", {
                                        className: "flex gap-2.5",
                                        children: [(0, r.jsx)("span", {
                                            "aria-hidden": !0,
                                            className: "flex h-[1lh] shrink-0 items-center",
                                            children: (0, r.jsx)("span", {
                                                className: "size-1.5 rounded-full bg-cp-primary"
                                            })
                                        }), (0, r.jsx)("span", {
                                            className: "min-w-0",
                                            children: (0, r.jsx)(eq, {
                                                spans: e,
                                                animate: t
                                            })
                                        })]
                                    }, n))
                                }, n);
                            case "ol":
                                return (0, r.jsx)("ol", {
                                    start: e.start,
                                    className: "space-y-2",
                                    children: e.items.map((n, a) => (0, r.jsxs)("li", {
                                        className: "flex gap-2.5",
                                        children: [(0, r.jsx)("span", {
                                            "aria-hidden": !0,
                                            className: "flex h-[1lh] shrink-0 items-center",
                                            children: (0, r.jsx)("span", {
                                                className: "inline-flex size-5 items-center justify-center rounded-full bg-cp-primary-soft text-[11px] font-semibold text-cp-primary tabular-nums",
                                                children: e.start + a
                                            })
                                        }), (0, r.jsx)("span", {
                                            className: "min-w-0",
                                            children: (0, r.jsx)(eq, {
                                                spans: n,
                                                animate: t
                                            })
                                        })]
                                    }, a))
                                }, n)
                        }
                    })
                })
            }
            let eK = /\s/,
                eB = /\[[^\]\n]{0,120}(?:\](?:\([^)\s]{0,200})?)?$/;
            var eX = n(67972),
                eZ = n(98196),
                eJ = n(56440),
                eQ = n(13557),
                eG = n(1960),
                e0 = n(25798),
                e1 = n(70414);

            function e2({
                items: e
            }) {
                let t = e.filter(e => E(e.tryUrl)),
                    n = (0, a.useRef)(null),
                    [i, s] = (0, a.useState)({
                        prev: !1,
                        next: !1
                    }),
                    [l, o] = (0, a.useState)(null),
                    c = (0, a.useCallback)(() => {
                        o(e => (e ? .opener.focus({
                            preventScroll: !0
                        }), null))
                    }, []),
                    d = (0, a.useCallback)(() => {
                        let e = n.current;
                        if (!e) return;
                        let t = e.scrollLeft > 4,
                            r = e.scrollLeft + e.clientWidth < e.scrollWidth - 4;
                        s(e => e.prev === t && e.next === r ? e : {
                            prev: t,
                            next: r
                        })
                    }, []);
                if ((0, a.useEffect)(() => {
                        let e = n.current;
                        if (!e || "u" < typeof ResizeObserver) return;
                        let t = new ResizeObserver(() => d());
                        return t.observe(e), () => t.disconnect()
                    }, [d]), 0 === t.length) return null;
                let u = e => {
                        let t = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                        n.current ? .scrollBy({
                            left: 188 * e,
                            behavior: t ? "auto" : "smooth"
                        })
                    },
                    p = "absolute top-[60px] z-10 inline-flex size-8 -translate-y-1/2 cursor-pointer items-center justify-center rounded-full border border-cp-line bg-cp-bg text-cp-ink shadow-cp-float transition-opacity duration-150 hover:bg-cp-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none max-sm:hidden";
                return (0, r.jsxs)("div", {
                    className: "relative -mr-4",
                    children: [(0, r.jsx)("ul", {
                        ref: n,
                        onScroll: d,
                        "aria-label": "Suggested templates",
                        className: "relative flex snap-x snap-mandatory scroll-pl-0 gap-3 overflow-x-auto overscroll-x-contain pr-4 pb-1 [scrollbar-width:none]",
                        children: t.map((e, t) => {
                            if ("collection" === e.kind) return (0, r.jsx)("li", {
                                style: {
                                    animationDelay: `${60*Math.min(t,5)}ms`
                                },
                                className: "kiara-card-in flex w-48 shrink-0 snap-start",
                                children: (0, r.jsxs)(em(), {
                                    href: e.tryUrl,
                                    prefetch: !1,
                                    className: "group flex w-full flex-col overflow-hidden rounded-xl border border-cp-pastel-lilac-ink/30 bg-cp-pastel-lilac transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none",
                                    children: [(0, r.jsxs)("span", {
                                        "aria-hidden": !0,
                                        className: "flex aspect-[4/3] w-full flex-col items-center justify-center bg-cp-pastel-butter",
                                        children: [(0, r.jsx)("span", {
                                            className: "text-[22px]",
                                            children: "\uD83C\uDFAE \uD83C\uDF70 \uD83D\uDC8C"
                                        }), (0, r.jsx)("span", {
                                            className: "mt-1 font-display text-[30px] leading-none font-semibold text-cp-ink",
                                            children: e.name.replace(/\s*store$/i, "")
                                        })]
                                    }), (0, r.jsxs)("span", {
                                        className: "flex flex-1 flex-col gap-1 p-3",
                                        children: [(0, r.jsx)("span", {
                                            className: "text-[13px] leading-snug font-medium text-cp-ink",
                                            children: e.name
                                        }), (0, r.jsxs)("span", {
                                            className: "text-[12px] leading-snug text-cp-muted",
                                            children: ["Small, funny pages from ", (0, e1.Dh)(e.priceInr)]
                                        }), (0, r.jsxs)("span", {
                                            className: "mt-auto inline-flex h-9 items-center justify-center gap-1 rounded-full bg-cp-bg px-2 text-[13px] font-medium text-cp-pastel-lilac-ink transition-colors duration-150 group-hover:bg-cp-primary group-hover:text-white",
                                            children: ["See all", (0, r.jsx)(eA.A, {
                                                className: "size-4",
                                                strokeWidth: 1.75,
                                                "aria-hidden": !0
                                            })]
                                        })]
                                    })]
                                })
                            }, e.slug);
                            let n = "number" == typeof e.regularPriceInr && e.regularPriceInr > e.priceInr;
                            return (0, r.jsxs)("li", {
                                style: {
                                    animationDelay: `${60*Math.min(t,5)}ms`
                                },
                                className: "kiara-card-in flex w-48 shrink-0 snap-start flex-col overflow-hidden rounded-xl border border-cp-line bg-cp-bg shadow-cp-float",
                                children: [e.imageUrl ? (0, r.jsx)("img", {
                                    src: e.imageUrl,
                                    alt: "",
                                    width: 176,
                                    height: 132,
                                    loading: "lazy",
                                    decoding: "async",
                                    className: "aspect-[4/3] w-full bg-cp-subtle object-cover"
                                }) : (0, r.jsx)("div", {
                                    "aria-hidden": !0,
                                    className: "aspect-[4/3] w-full bg-cp-subtle"
                                }), (0, r.jsxs)("div", {
                                    className: "flex flex-1 flex-col gap-1 p-3",
                                    children: [(0, r.jsx)("p", {
                                        className: "line-clamp-2 text-[13px] leading-snug font-medium text-cp-ink",
                                        children: e.name
                                    }), (0, r.jsxs)("p", {
                                        className: "flex items-baseline gap-1.5 text-[13px]",
                                        children: [(0, r.jsx)("span", {
                                            className: "font-semibold text-cp-ink",
                                            children: e.priceInr > 0 ? (0, e1.Dh)(e.priceInr) : "Free"
                                        }), n ? (0, r.jsxs)("span", {
                                            className: "text-[12px] text-cp-faint line-through",
                                            children: [(0, r.jsx)("span", {
                                                className: "sr-only",
                                                children: "Regular price "
                                            }), (0, e1.Dh)(e.regularPriceInr)]
                                        }) : null]
                                    }), (0, r.jsxs)("div", {
                                        className: "mt-auto flex gap-1.5",
                                        children: [(0, r.jsxs)("button", {
                                            type: "button",
                                            onClick: t => o({
                                                card: e,
                                                opener: t.currentTarget
                                            }),
                                            className: "inline-flex h-9 shrink-0 cursor-pointer items-center justify-center rounded-full border border-cp-line bg-cp-bg px-3 text-[13px] font-medium whitespace-nowrap text-cp-ink transition-colors duration-150 hover:bg-cp-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none",
                                            children: ["Try it", (0, r.jsxs)("span", {
                                                className: "sr-only",
                                                children: [": ", e.name]
                                            })]
                                        }), (0, r.jsxs)(em(), {
                                            href: e.tryUrl,
                                            prefetch: !1,
                                            className: "inline-flex h-9 min-w-0 flex-1 items-center justify-center rounded-full bg-cp-primary px-2 text-[13px] font-medium whitespace-nowrap text-white transition-colors duration-150 hover:bg-cp-primary-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none",
                                            children: ["Make yours", (0, r.jsxs)("span", {
                                                className: "sr-only",
                                                children: [": ", e.name]
                                            })]
                                        })]
                                    })]
                                })]
                            }, e.slug)
                        })
                    }), t.length > 1 ? (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)("button", {
                            type: "button",
                            "aria-label": "Previous templates",
                            tabIndex: i.prev ? 0 : -1,
                            onClick: () => u(-1),
                            className: (0, eS.cn)(p, "-left-3", i.prev ? "opacity-100" : "pointer-events-none opacity-0"),
                            children: (0, r.jsx)(eJ.A, {
                                className: "size-4",
                                strokeWidth: 1.75,
                                "aria-hidden": !0
                            })
                        }), (0, r.jsx)("button", {
                            type: "button",
                            "aria-label": "More templates",
                            tabIndex: i.next ? 0 : -1,
                            onClick: () => u(1),
                            className: (0, eS.cn)(p, "right-2", i.next ? "opacity-100" : "pointer-events-none opacity-0"),
                            children: (0, r.jsx)(eQ.A, {
                                className: "size-4",
                                strokeWidth: 1.75,
                                "aria-hidden": !0
                            })
                        })]
                    }) : null, l ? (0, r.jsx)(e5, {
                        card: l.card,
                        onClose: c
                    }) : null]
                })
            }

            function e5({
                card: e,
                onClose: t
            }) {
                let n, i = (0, a.useRef)(null),
                    [l, o] = (0, a.useState)(!1),
                    c = (0, a.useRef)(t);
                (0, a.useEffect)(() => {
                    c.current = t
                }, [t]), (0, a.useEffect)(() => {
                    let e = i.current;
                    if (e) return e.querySelector("[data-close]") ? .focus({
                        preventScroll: !0
                    }), window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);

                    function t(t) {
                        if (!e) return;
                        if ("Escape" === t.key) {
                            t.stopPropagation(), t.preventDefault(), c.current();
                            return
                        }
                        if ("Tab" !== t.key) return;
                        t.stopPropagation();
                        let n = (0, s.a)(e);
                        if (0 === n.length) return;
                        let r = n[0],
                            a = n[n.length - 1],
                            i = document.activeElement;
                        t.shiftKey && (i === r || !e.contains(i)) ? (t.preventDefault(), a.focus()) : t.shiftKey || i !== a && e.contains(i) || (t.preventDefault(), r.focus())
                    }
                }, []);
                let d = "number" == typeof e.regularPriceInr && e.regularPriceInr > e.priceInr,
                    u = (0, r.jsxs)("p", {
                        className: "flex items-baseline gap-1.5",
                        children: [(0, r.jsx)("span", {
                            className: "font-semibold",
                            children: e.priceInr > 0 ? (0, e1.Dh)(e.priceInr) : "Free"
                        }), d ? (0, r.jsxs)("span", {
                            className: "text-[0.85em] line-through opacity-60",
                            children: [(0, r.jsx)("span", {
                                className: "sr-only",
                                children: "Regular price "
                            }), (0, e1.Dh)(e.regularPriceInr)]
                        }) : null]
                    }),
                    p = (0, r.jsxs)(em(), {
                        href: e.tryUrl,
                        prefetch: !1,
                        className: "inline-flex h-10 shrink-0 items-center justify-center gap-1.5 rounded-full bg-cp-primary px-5 text-[14px] font-medium text-white shadow-lg transition-colors duration-150 hover:bg-cp-primary-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white motion-reduce:transition-none",
                        children: ["Make yours", (0, r.jsx)(eA.A, {
                            className: "size-4",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        })]
                    });
                return (0, eZ.createPortal)((0, r.jsxs)("div", {
                    ref: i,
                    role: "dialog",
                    "aria-modal": "true",
                    "aria-label": `${e.name} preview`,
                    className: "fixed inset-0 z-[100] flex animate-[fade-in_180ms_ease-out] flex-col items-center gap-3 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-[max(1rem,env(safe-area-inset-bottom))] motion-reduce:animate-none sm:flex-row sm:justify-center sm:gap-12 sm:py-8",
                    children: [(0, r.jsx)("div", {
                        "aria-hidden": !0,
                        className: "absolute inset-0 bg-cp-ink/60 backdrop-blur-md",
                        onMouseDown: t
                    }), (0, r.jsx)("button", {
                        type: "button",
                        "data-close": !0,
                        onClick: t,
                        "aria-label": "Close preview",
                        className: "absolute top-[max(0.75rem,env(safe-area-inset-top))] right-4 z-10 inline-flex size-10 cursor-pointer items-center justify-center rounded-full bg-white/15 text-white ring-1 ring-white/25 backdrop-blur transition-colors duration-150 hover:bg-white/25 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white motion-reduce:transition-none sm:top-5 sm:right-5",
                        children: (0, r.jsx)(eh.A, {
                            className: "size-5",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        })
                    }), (0, r.jsxs)("div", {
                        className: "relative flex w-full max-w-[410px] items-center justify-between gap-3 pr-12 sm:hidden",
                        children: [(0, r.jsxs)("div", {
                            className: "min-w-0 text-white",
                            children: [(0, r.jsx)("p", {
                                className: "truncate text-[14px] font-medium",
                                children: e.name
                            }), (0, r.jsx)("div", {
                                className: "text-[13px] text-white/80",
                                children: u
                            })]
                        }), p]
                    }), (0, r.jsxs)(e0.M, {
                        className: "relative min-h-0 w-full max-w-[410px] flex-1 sm:aspect-[410/864] sm:h-full sm:max-h-[864px] sm:w-auto sm:flex-none",
                        children: [(0, r.jsx)("iframe", {
                            src: (n = encodeURIComponent(e.slug), e.priceInr <= 0 ? `/preview/free/${n}/embed` : `/preview/${n}/embed`),
                            title: `${e.name} preview`,
                            className: "size-full flex-1 border-0 bg-cp-bg",
                            onLoad: e => {
                                o(!0);
                                try {
                                    e.currentTarget.contentWindow ? .addEventListener("keydown", e => {
                                        "Escape" === e.key && c.current()
                                    })
                                } catch {}
                            }
                        }), l ? null : (0, r.jsx)(eG.b, {})]
                    }), (0, r.jsxs)("div", {
                        className: "relative hidden max-w-[260px] flex-col items-start gap-4 text-white sm:flex",
                        children: [(0, r.jsx)("p", {
                            className: "text-[12px] font-medium tracking-wide text-white/60",
                            children: "Live preview"
                        }), (0, r.jsx)("h2", {
                            className: "text-[26px] leading-tight font-semibold",
                            children: e.name
                        }), (0, r.jsx)("div", {
                            className: "text-[18px]",
                            children: u
                        }), (0, r.jsx)("p", {
                            className: "text-[14px] leading-relaxed text-white/75",
                            children: "Scroll and tap inside the phone. Your page gets your own photos and words."
                        }), p]
                    })]
                }), document.body)
            }
            let e3 = `
@keyframes kiara-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
@keyframes kiara-panel-in{from{opacity:0;transform:translateY(8px) scale(.97)}to{opacity:1;transform:none}}
@keyframes kiara-dot{0%,60%,100%{opacity:.35;transform:translateY(0)}30%{opacity:1;transform:translateY(-3px)}}
@keyframes kiara-msg-in{from{opacity:0;transform:translateY(8px) scale(.97)}to{opacity:1;transform:none}}
@keyframes kiara-word-in{from{opacity:0}to{opacity:1}}
@keyframes kiara-card-in{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:none}}
@keyframes kiara-icon-in{0%{opacity:0;transform:scale(.4) rotate(-25deg)}60%{opacity:1;transform:scale(1.15) rotate(6deg)}100%{opacity:1;transform:none}}
@keyframes kiara-shimmer{from{background-position:100% 0}to{background-position:-100% 0}}
@keyframes kiara-label-in{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
@keyframes kiara-orbit{to{transform:rotate(360deg)}}
@keyframes kiara-orbit-rev{to{transform:rotate(-360deg)}}
@keyframes kiara-glow{0%,100%{transform:scale(.92) rotate(0);opacity:.75}50%{transform:scale(1.05) rotate(20deg);opacity:1}}
@keyframes kiara-ripple{0%{opacity:.5;transform:scale(1)}80%,100%{opacity:0;transform:scale(1.28,1.6)}}
@keyframes kiara-emoji-in{0%{opacity:0;transform:scale(.3)}70%{opacity:1;transform:scale(1.08)}100%{opacity:1;transform:scale(1)}}
@keyframes kiara-tilt{0%,100%{transform:rotate(-6deg) translateY(0)}50%{transform:rotate(-4deg) translateY(-4px)}}
@keyframes kiara-rise{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}
@keyframes kiara-hello{from{opacity:0;transform:translateY(10px);filter:blur(6px)}to{opacity:1;transform:none;filter:none}}
@keyframes kiara-exit{to{opacity:0;transform:translateY(24px) scale(.97)}}
@keyframes kiara-ready-in{from{opacity:0;transform:translateY(18px) scale(.98)}to{opacity:1;transform:none}}
@keyframes kiara-shine{0%,55%{transform:translateX(-130%) skewX(-20deg)}100%{transform:translateX(230%) skewX(-20deg)}}
@keyframes kiara-bob{0%,100%{transform:translateY(0) rotate(-3deg)}50%{transform:translateY(-6px) rotate(-1.5deg)}}
@keyframes kiara-wave{0%,60%,100%{transform:rotate(0)}10%,30%{transform:rotate(18deg)}20%,40%{transform:rotate(-10deg)}}
.kiara-shimmer{color:var(--cp-muted)}
.kiara-ai-shimmer{color:var(--cp-primary)}
.kiara-tilt{transform:rotate(-3deg)}
@media (prefers-reduced-motion:no-preference){
.kiara-ai-shimmer{color:transparent;background:linear-gradient(90deg,var(--cp-primary) 0%,var(--cp-primary) 30%,var(--cp-rose) 50%,var(--cp-primary) 70%,var(--cp-primary) 100%);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;animation:kiara-shimmer 1.6s linear infinite}
.kiara-orbit,.kiara-orbit-rev{will-change:transform;animation:kiara-orbit 80s linear infinite}
.kiara-orbit-rev{animation-name:kiara-orbit-rev}
.kiara-stars{will-change:transform;animation:kiara-orbit-rev 120s linear infinite}
.kiara-glow{animation:kiara-glow 7s cubic-bezier(.45,0,.55,1) infinite}
.kiara-tilt{animation:kiara-bob 4.2s cubic-bezier(.45,0,.55,1) infinite}
.kiara-shine{animation:kiara-shine 3.4s ease-in-out 1s infinite}
.kiara-ripple{animation:kiara-ripple 2.8s cubic-bezier(.22,1,.36,1) 1s infinite both}
.kiara-emoji-in{animation:kiara-emoji-in .6s cubic-bezier(.34,1.56,.64,1) both}
.kiara-emoji-float{animation:kiara-float 4s cubic-bezier(.45,0,.55,1) infinite}
.kiara-wave{display:inline-block;transform-origin:70% 80%;animation:kiara-wave 1.6s ease-in-out .5s 1 both}
.kiara-exit{animation:kiara-exit .32s cubic-bezier(.4,0,1,1) forwards;pointer-events:none}
.kiara-ready-in{animation:kiara-ready-in .7s cubic-bezier(.22,1,.36,1) both}
.kiara-rise{animation:kiara-rise .7s cubic-bezier(.16,1,.3,1) both}
.kiara-hello{animation:kiara-hello .6s cubic-bezier(.16,1,.3,1) both}
.kiara-icon-in{animation:kiara-icon-in .38s cubic-bezier(.16,1,.3,1) both}
.kiara-shimmer{color:transparent;background:linear-gradient(90deg,var(--cp-muted) 0%,var(--cp-muted) 35%,var(--cp-primary) 50%,var(--cp-muted) 65%,var(--cp-muted) 100%);background-size:200% 100%;-webkit-background-clip:text;background-clip:text;animation:kiara-shimmer 1.8s linear infinite}
.kiara-label-in{animation:kiara-label-in .25s ease-out both}
.kiara-float{animation:kiara-float 4s ease-in-out infinite}
.kiara-panel-in{animation:kiara-panel-in .2s cubic-bezier(.16,1,.3,1) both;transform-origin:bottom right}
.kiara-dot{animation:kiara-dot 1.2s ease-in-out infinite}
.kiara-msg-in{animation:kiara-msg-in .32s cubic-bezier(.16,1,.3,1) both;transform-origin:top left}
.kiara-msg-in[data-speaker=user]{transform-origin:bottom right}
.kiara-msg-in[data-speaker=system]{transform-origin:center}
.kiara-word{animation:kiara-word-in .4s ease-out both}
.kiara-card-in{animation:kiara-card-in .38s cubic-bezier(.16,1,.3,1) both}
}
${e$.VN}`;

            function e4(e) {
                let {
                    titleId: t,
                    items: n,
                    streaming: i,
                    ready: s,
                    humanActive: l,
                    typing: o,
                    welcome: c,
                    blocked: d
                } = e, u = (0, a.useRef)(null), p = (0, a.useRef)(!0), [m, h] = (0, a.useState)(!0), [f, x] = (0, a.useState)(n.length);
                (0, a.useLayoutEffect)(() => {
                    let e = u.current;
                    e && p.current && n.length > 0 && (e.scrollTop = e.scrollHeight)
                }, [n, o, s]), (0, a.useEffect)(() => {
                    let e = u.current;
                    if (!e || 0 === n.length || "u" < typeof ResizeObserver) return;
                    let t = new ResizeObserver(() => {
                        p.current && (e.scrollTop = e.scrollHeight)
                    });
                    for (let n of Array.from(e.children)) t.observe(n);
                    return () => t.disconnect()
                }, [n, o, s]);
                let g = t => {
                        p.current = !0, h(!0), e.onSubmit(t)
                    },
                    b = !m && n.length > f,
                    y = s && 0 === n.length,
                    v = n.map((e, t) => {
                        let r = eo(e),
                            a = t > 0 ? eo(n[t - 1]) : null,
                            i = t < n.length - 1 ? eo(n[t + 1]) : null,
                            s = "system" !== r;
                        return {
                            item: e,
                            speaker: r,
                            first: !s || a !== r,
                            last: !s || i !== r
                        }
                    });
                return v.length > 0 && v[v.length - 1].speaker, (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsxs)("header", {
                        className: `relative flex shrink-0 items-center gap-2 px-3 pb-2.5 ${e.phone?"pt-4":"pt-2.5"}`,
                        children: [(0, r.jsx)("span", {
                            "aria-hidden": "true",
                            className: "absolute inset-x-6 bottom-0 h-px bg-linear-to-r from-transparent via-cp-lavender/60 to-transparent"
                        }), (0, r.jsx)("button", {
                            type: "button",
                            "aria-label": "Close chat",
                            onClick: e.onClose,
                            className: e9,
                            children: (0, r.jsx)(eh.A, {
                                className: "size-5",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            })
                        }), (0, r.jsxs)("div", {
                            className: "min-w-0 flex-1 text-center",
                            children: [(0, r.jsxs)("h2", {
                                id: t,
                                className: "truncate text-[15px] leading-tight font-semibold text-cp-ink",
                                children: [y ? e8(e.firstName) : z, (0, r.jsxs)("span", {
                                    className: "sr-only",
                                    children: [y ? `, ${z}` : "", ", ", $]
                                })]
                            }), y ? null : (0, r.jsx)("p", {
                                className: "mt-0.5 truncate text-[12px] text-cp-muted",
                                children: l ? `With the ${C}` : $
                            })]
                        }), (0, r.jsxs)("span", {
                            className: "relative inline-flex size-10 shrink-0 items-center justify-center",
                            children: [(0, r.jsx)(ez.W, {
                                size: 36
                            }), (0, r.jsx)("span", {
                                "aria-hidden": "true",
                                className: "absolute right-0.5 bottom-0.5 size-2.5 rounded-full bg-cp-success ring-2 ring-cp-bg"
                            })]
                        })]
                    }), (0, r.jsxs)("div", {
                        className: "relative min-h-0 flex-1",
                        children: [(0, r.jsxs)("div", {
                            ref: u,
                            onScroll: () => {
                                let e = u.current;
                                if (!e) return;
                                let t = e.scrollHeight - e.scrollTop - e.clientHeight <= 48;
                                p.current = t, t !== m && h(t), t && f !== n.length && x(n.length)
                            },
                            onClick: t => {
                                e.phone && t.target.closest ? .('a[href^="/"]') && e.onClose()
                            },
                            role: "log",
                            "aria-live": "polite",
                            "aria-relevant": "additions text",
                            "aria-busy": i || void 0,
                            className: "relative h-full overflow-x-hidden overflow-y-auto overscroll-contain px-4 py-4",
                            children: [s ? null : (0, r.jsxs)("div", {
                                className: "flex h-full items-center justify-center",
                                children: [(0, r.jsx)(e$.SF, {
                                    size: 36
                                }), (0, r.jsx)("span", {
                                    className: "sr-only",
                                    children: "Loading your chat"
                                })]
                            }), y ? (0, r.jsx)(tt, {
                                hero: e.hero,
                                chips: c.chips,
                                disabled: i || d,
                                onSend: g
                            }) : null, v.map((t, n) => (0, r.jsx)("div", {
                                "data-speaker": t.speaker,
                                className: (0, eS.cn)("kiara-msg-in", 0 === n ? "" : t.first ? "mt-4" : "mt-1.5"),
                                children: (0, r.jsx)(ti, {
                                    entry: t,
                                    streaming: i,
                                    signedIn: e.signedIn,
                                    onPick: e.onPick,
                                    onUndoPageEdit: e.onUndoPageEdit
                                })
                            }, t.item.id)), "kiara" === o ? (0, r.jsx)("div", {
                                className: (0, eS.cn)("kiara-msg-in", 0 === n.length ? "" : "mt-4"),
                                children: (0, r.jsx)(e7, {
                                    thinking: e.thinking,
                                    centred: v.length <= 1
                                })
                            }) : null, "sending" === o ? (0, r.jsx)("p", {
                                className: "mt-1.5 text-right text-[12px] text-cp-muted",
                                children: "Sending\u2026"
                            }) : null]
                        }), b ? (0, r.jsxs)("button", {
                            type: "button",
                            onClick: () => {
                                let e = u.current;
                                if (!e) return;
                                p.current = !0;
                                let t = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                                e.scrollTo({
                                    top: e.scrollHeight,
                                    behavior: t ? "auto" : "smooth"
                                })
                            },
                            className: "absolute bottom-3 left-1/2 inline-flex h-8 -translate-x-1/2 cursor-pointer items-center gap-1.5 rounded-full border border-cp-line bg-cp-bg px-3 text-[12px] font-medium text-cp-ink shadow-cp-float hover:bg-cp-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                            children: [(0, r.jsx)(ef.A, {
                                className: "size-3.5",
                                strokeWidth: 1.75,
                                "aria-hidden": !0
                            }), "New message"]
                        }) : null]
                    }), (0, r.jsx)(td, { ...e,
                        onSubmit: g
                    })]
                })
            }
            let e6 = "inline-flex size-10 shrink-0 cursor-pointer items-center justify-center rounded-full border border-cp-line bg-cp-bg text-cp-ink transition-colors duration-150 hover:bg-cp-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select disabled:cursor-not-allowed disabled:opacity-50 motion-reduce:transition-none",
                e9 = "inline-flex size-10 shrink-0 cursor-pointer items-center justify-center rounded-full bg-cp-pastel-lilac text-cp-pastel-lilac-ink transition-[background-color,transform] duration-150 hover:bg-cp-primary-soft active:scale-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none";

            function e8(e) {
                return e ? `Hi ${e}!` : "Hi there!"
            }

            function e7({
                thinking: e,
                centred: t
            }) {
                let [n, i] = (0, a.useState)(() => Date.now());
                (0, a.useEffect)(() => {
                    let e = window.setInterval(() => i(Date.now()), 250);
                    return () => window.clearInterval(e)
                }, []);
                let s = e.startedAt > 0 ? Math.max(0, n - e.startedAt) : 0,
                    l = eu(e.phase, s);
                return (0, r.jsxs)("div", {
                    className: (0, eS.cn)("flex flex-col items-center justify-center gap-2.5 py-6", t && "min-h-[55vh] sm:min-h-[340px]"),
                    children: [(0, r.jsxs)("span", {
                        "aria-hidden": "true",
                        className: "contents",
                        children: [e.done.length > 0 ? (0, r.jsx)("ul", {
                            className: "mb-1 flex flex-col items-center gap-1",
                            children: e.done.slice(-3).map((e, t) => (0, r.jsxs)("li", {
                                className: "kiara-label-in flex items-center gap-1.5 text-[12.5px] text-cp-muted",
                                children: [(0, r.jsx)(ex.A, {
                                    className: "size-3.5 text-cp-success",
                                    strokeWidth: 2.25
                                }), eu(e, 0)]
                            }, `${t}-${e}`))
                        }) : null, (0, r.jsx)(e$.SF, {
                            size: t ? 40 : 30
                        }), (0, r.jsx)("span", {
                            className: "kiara-label-in",
                            children: (0, r.jsx)("span", {
                                className: "kiara-ai-shimmer text-[14.5px] font-medium whitespace-nowrap",
                                children: "Thinking" === l ? l : `${l}\u2026`
                            })
                        }, l)]
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: L
                    })]
                })
            }
            let te = [
                ["\uD83C\uDF82", 200, !0],
                ["\uD83D\uDC8C", 262, !1],
                ["\uD83C\uDF81", 320, !0],
                ["\uD83D\uDE0D", 10, !1],
                ["\uD83D\uDC8D", 55, !0],
                ["\uD83C\uDF39", 120, !0]
            ];

            function tt({
                hero: e,
                chips: t,
                disabled: n,
                onSend: a
            }) {
                return (0, r.jsxs)("div", {
                    className: "flex min-h-full flex-col items-center justify-between gap-4 pt-2 text-center",
                    children: [(0, r.jsxs)("div", {
                        className: "kiara-rise flex w-full items-center gap-3",
                        children: [(0, r.jsx)("span", {
                            "aria-hidden": "true",
                            className: "h-px flex-1 border-t border-dashed border-cp-line-strong"
                        }), (0, r.jsxs)("p", {
                            className: "bg-linear-to-r from-cp-rose to-cp-primary bg-clip-text text-[18px] leading-snug font-semibold text-transparent sm:text-[16px]",
                            children: [e.title[0], (0, r.jsx)("br", {}), e.title[1]]
                        }), (0, r.jsx)("span", {
                            "aria-hidden": "true",
                            className: "h-px flex-1 border-t border-dashed border-cp-line-strong"
                        })]
                    }), (0, r.jsx)("div", {
                        className: "flex w-full flex-1 items-center justify-center",
                        children: (0, r.jsxs)("div", {
                            className: "kiara-rise relative aspect-square w-full max-w-[330px] sm:max-w-[250px]",
                            style: {
                                animationDelay: "90ms"
                            },
                            children: [(0, r.jsx)("div", {
                                "aria-hidden": "true",
                                className: "absolute -inset-[12%]",
                                style: {
                                    backgroundImage: "linear-gradient(var(--cp-line) 1px, transparent 1px), linear-gradient(90deg, var(--cp-line) 1px, transparent 1px)",
                                    backgroundSize: "28px 28px",
                                    maskImage: "radial-gradient(closest-side, black, transparent)",
                                    WebkitMaskImage: "radial-gradient(closest-side, black, transparent)"
                                }
                            }), (0, r.jsx)("div", {
                                "aria-hidden": "true",
                                className: "absolute inset-[22%] rounded-full border border-dashed border-cp-lavender/40"
                            }), (0, r.jsx)("div", {
                                "aria-hidden": "true",
                                className: "kiara-stars absolute inset-[22%]",
                                children: [30, 150, 270].map(e => {
                                    let t = e * Math.PI / 180;
                                    return (0, r.jsx)("span", {
                                        className: "absolute -translate-x-1/2 -translate-y-1/2 text-[13px] text-cp-lavender",
                                        style: {
                                            left: `${50+50*Math.cos(t)}%`,
                                            top: `${50+50*Math.sin(t)}%`
                                        },
                                        children: "\u2726"
                                    }, e)
                                })
                            }), (0, r.jsx)("div", {
                                "aria-hidden": "true",
                                className: "kiara-glow absolute inset-[14%] rounded-full",
                                style: {
                                    background: "radial-gradient(closest-side at 42% 58%, color-mix(in srgb, var(--cp-rose) 55%, transparent), transparent), radial-gradient(closest-side at 60% 40%, color-mix(in srgb, var(--cp-lavender) 60%, transparent), transparent)"
                                }
                            }), (0, r.jsx)("div", {
                                "aria-hidden": "true",
                                className: "kiara-orbit absolute inset-[6%] rounded-full border border-cp-rose/30",
                                children: te.map(([e, t, n], a) => {
                                    let i = t * Math.PI / 180;
                                    return (0, r.jsx)("span", {
                                        className: "kiara-emoji-in absolute -translate-x-1/2 -translate-y-1/2",
                                        style: {
                                            left: `${50+50*Math.cos(i)}%`,
                                            top: `${50+50*Math.sin(i)}%`,
                                            animationDelay: `${250+70*a}ms`
                                        },
                                        children: (0, r.jsx)("span", {
                                            className: "kiara-orbit-rev inline-flex",
                                            children: (0, r.jsx)("span", {
                                                className: (0, eS.cn)("kiara-emoji-float inline-flex items-center justify-center", n ? "size-12 rounded-full bg-cp-bg text-[24px] shadow-cp-float ring-2 ring-cp-rose/15" : "size-11 text-[30px]"),
                                                style: {
                                                    animationDelay: `${-(.7*a)}s`,
                                                    animationDuration: `${3.6+a%3*.5}s`
                                                },
                                                children: e
                                            })
                                        })
                                    }, e)
                                })
                            }), (0, r.jsx)("div", {
                                className: "absolute inset-0 flex items-center justify-center",
                                children: (0, r.jsxs)("span", {
                                    className: "kiara-tilt relative inline-flex",
                                    children: [n ? null : (0, r.jsxs)(r.Fragment, {
                                        children: [(0, r.jsx)("span", {
                                            "aria-hidden": "true",
                                            className: "kiara-ripple absolute inset-0 rounded-full border-2 border-cp-rose/70"
                                        }), (0, r.jsx)("span", {
                                            "aria-hidden": "true",
                                            className: "kiara-ripple absolute inset-0 rounded-full border-2 border-cp-lavender",
                                            style: {
                                                animationDelay: "2.4s"
                                            }
                                        })]
                                    }), (0, r.jsxs)("button", {
                                        type: "button",
                                        disabled: n,
                                        onClick: () => a(e.message),
                                        className: "group relative cursor-pointer overflow-hidden rounded-full bg-linear-to-r from-cp-rose to-cp-primary px-6 py-3.5 text-[19px] leading-none font-bold whitespace-nowrap text-white shadow-[0_14px_34px_-10px_var(--cp-rose)] ring-4 ring-cp-bg/80 transition-transform duration-200 hover:scale-[1.04] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-cp-select active:scale-95 disabled:cursor-not-allowed disabled:opacity-60 motion-reduce:transition-none",
                                        children: [(0, r.jsx)("span", {
                                            "aria-hidden": "true",
                                            className: "kiara-shine pointer-events-none absolute inset-y-0 left-0 w-1/3 bg-linear-to-r from-transparent via-white/45 to-transparent"
                                        }), (0, r.jsxs)("span", {
                                            className: "relative",
                                            children: ["\u2726 ", e.cta]
                                        })]
                                    })]
                                })
                            })]
                        })
                    }), (0, r.jsx)("div", {
                        className: "kiara-rise -mx-4 w-[calc(100%+2rem)] overflow-x-auto px-4 pb-1 [scrollbar-width:none]",
                        style: {
                            animationDelay: "180ms"
                        },
                        role: "group",
                        "aria-label": "Suggestions",
                        children: (0, r.jsx)("div", {
                            className: "flex w-max flex-col gap-2",
                            children: [0, 1, 2].map(e => (0, r.jsx)("div", {
                                className: "flex gap-2",
                                children: t.filter((t, n) => n % 3 === e).map(e => (0, r.jsx)("button", {
                                    type: "button",
                                    disabled: n,
                                    onClick: () => a(e),
                                    className: "inline-flex h-9 shrink-0 cursor-pointer items-center rounded-full border border-cp-pastel-lilac bg-cp-pastel-lilac/60 px-4 text-[13.5px] whitespace-nowrap text-cp-pastel-lilac-ink transition-colors duration-150 hover:border-cp-select hover:bg-cp-primary-soft focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select disabled:cursor-not-allowed disabled:opacity-50 motion-reduce:transition-none",
                                    children: e
                                }, e))
                            }, e))
                        })
                    })]
                })
            }

            function tn({
                firstName: e,
                line: t
            }) {
                return (0, r.jsxs)("div", {
                    className: "flex h-full flex-col items-center justify-center gap-2 px-6 text-center",
                    children: [(0, r.jsxs)("span", {
                        className: "kiara-pop relative mb-3 inline-flex",
                        style: {
                            animationDelay: "300ms"
                        },
                        children: [(0, r.jsx)("span", {
                            "aria-hidden": "true",
                            className: "kiara-aurora absolute -inset-6 rounded-full",
                            style: {
                                background: "radial-gradient(closest-side, color-mix(in srgb, var(--cp-lavender) 60%, transparent), color-mix(in srgb, var(--cp-rose) 25%, transparent) 70%, transparent)"
                            }
                        }), (0, r.jsx)(ez.W, {
                            size: 76,
                            className: "relative ring-4 ring-cp-bg"
                        })]
                    }), (0, r.jsxs)("p", {
                        className: "kiara-hello text-[18px] font-semibold text-cp-ink",
                        style: {
                            animationDelay: "450ms"
                        },
                        children: [e8(e), " ", (0, r.jsx)("span", {
                            className: "kiara-wave",
                            children: "\uD83D\uDC4B"
                        })]
                    }), (0, r.jsx)("p", {
                        className: "kiara-hello text-[16px] text-cp-muted",
                        style: {
                            animationDelay: "600ms"
                        },
                        children: t
                    })]
                })
            }

            function tr({
                showAvatar: e,
                children: t
            }) {
                return (0, r.jsxs)("div", {
                    className: "flex items-start gap-2",
                    children: [(0, r.jsx)("div", {
                        className: "w-6 shrink-0",
                        children: e ? (0, r.jsx)(ez.W, {
                            size: 24
                        }) : null
                    }), (0, r.jsx)("div", {
                        className: "min-w-0 flex-1",
                        children: t
                    })]
                })
            }
            let ta = "w-fit max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[14px] leading-relaxed break-words",
                ti = (0, a.memo)(function({
                    entry: e,
                    streaming: t,
                    signedIn: n,
                    onPick: a,
                    onUndoPageEdit: i
                }) {
                    let {
                        item: s,
                        first: l
                    } = e;
                    switch (s.kind) {
                        case "user":
                            return (0, r.jsxs)("div", {
                                className: "flex flex-col items-end gap-1.5",
                                children: [s.attachments ? .map(e => (0, r.jsx)("a", {
                                    href: e.src,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    "aria-label": "Open screenshot in a new tab",
                                    className: "block rounded-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                                    children: (0, r.jsx)("img", {
                                        src: e.src,
                                        alt: "Screenshot you sent",
                                        loading: "lazy",
                                        decoding: "async",
                                        className: "max-h-56 w-auto max-w-[200px] rounded-xl border border-cp-line bg-cp-subtle object-cover"
                                    })
                                }, e.src)), s.text ? (0, r.jsx)("div", {
                                    className: (0, eS.cn)(ta, "rounded-br-md bg-linear-to-br from-cp-primary to-cp-primary-hover whitespace-pre-wrap text-white shadow-cp-float"),
                                    children: s.text
                                }) : null]
                            });
                        case "assistant":
                            return (0, r.jsx)(tr, {
                                showAvatar: l,
                                children: (0, r.jsx)(tl, {
                                    text: s.text,
                                    live: s.live
                                })
                            });
                        case "agent":
                            return (0, r.jsxs)("div", {
                                className: "flex items-start gap-2",
                                children: [(0, r.jsx)("div", {
                                    className: "w-6 shrink-0",
                                    children: l ? (0, r.jsx)("span", {
                                        className: "inline-flex size-6 items-center justify-center rounded-full bg-cp-primary text-white",
                                        children: (0, r.jsx)(eg.A, {
                                            className: "size-3.5",
                                            strokeWidth: 1.75,
                                            "aria-hidden": !0
                                        })
                                    }) : null
                                }), (0, r.jsxs)("div", {
                                    className: "min-w-0 flex-1",
                                    children: [l ? (0, r.jsx)("p", {
                                        className: "mb-1 text-[12px] font-medium text-cp-primary",
                                        children: C
                                    }) : null, (0, r.jsxs)("div", {
                                        className: (0, eS.cn)(ta, "rounded-tl-md bg-cp-primary-soft whitespace-pre-wrap text-cp-ink"),
                                        children: [(0, r.jsxs)("span", {
                                            className: "sr-only",
                                            children: [C, ": "]
                                        }), s.text]
                                    })]
                                })]
                            });
                        case "templates":
                            return (0, r.jsx)(tr, {
                                showAvatar: l,
                                children: (0, r.jsx)(e2, {
                                    items: s.items
                                })
                            });
                        case "project_picker":
                            return (0, r.jsx)(tr, {
                                showAvatar: l,
                                children: (0, r.jsx)(eC, {
                                    items: s.items,
                                    picked: s.picked,
                                    disabled: s.locked || t,
                                    onPick: e => a(s.id, e)
                                })
                            });
                        case "granted":
                            return (0, r.jsx)(tr, {
                                showAvatar: l,
                                children: (0, r.jsx)(eE, {
                                    editorUrl: s.editorUrl,
                                    refreshOnMount: s.fresh
                                })
                            });
                        case "page_edit":
                            return (0, r.jsx)(tr, {
                                showAvatar: l,
                                children: (0, r.jsx)(ts, {
                                    item: s,
                                    onUndo: () => i(s.id)
                                })
                            });
                        case "note":
                            return (0, r.jsx)(tc, {
                                note: s.note,
                                text: s.text,
                                signedIn: n
                            })
                    }
                }, (e, t) => e.entry.item === t.entry.item && e.entry.first === t.entry.first && e.entry.last === t.entry.last && e.entry.speaker === t.entry.speaker && e.signedIn === t.signedIn && e.onPick === t.onPick && e.onUndoPageEdit === t.onUndoPageEdit && ("project_picker" !== e.entry.item.kind || e.streaming === t.streaming));

            function ts({
                item: e,
                onUndo: t
            }) {
                let {
                    status: n,
                    labels: a
                } = e, i = "failed" === e.status ? e.message || l.$F.failed : "applied" === e.status ? e.message ? ? null : null, s = "failed" === n, o = "applying" === n ? l.$F.applying : "applied" === n ? l.$F.done : "undone" === n ? l.$F.undone : "record" === n ? l.$F.record : null, c = "applying" === n ? eb.A : "undone" === n ? ey.A : ev.A;
                return (0, r.jsxs)("div", {
                    className: (0, eS.cn)("w-full rounded-xl border p-3", "applied" === n ? "border-cp-success/30 bg-cp-success/10" : "border-cp-line bg-cp-bg"),
                    children: [o ? (0, r.jsxs)("div", {
                        className: "flex items-center gap-2",
                        children: [(0, r.jsx)(c, {
                            className: (0, eS.cn)("size-4 shrink-0", "applying" === n && "animate-spin motion-reduce:animate-none", "applied" === n ? "text-cp-success-ink" : "text-cp-muted"),
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }), (0, r.jsx)("p", {
                            className: (0, eS.cn)("text-[13.5px] font-semibold", "applied" === n ? "text-cp-success-ink" : "text-cp-ink"),
                            children: o
                        })]
                    }) : null, a.length > 0 && !s ? (0, r.jsx)("ul", {
                        className: (0, eS.cn)("mt-1.5 flex flex-col gap-0.5", "undone" === n && "line-through decoration-cp-muted"),
                        children: a.slice(0, 8).map((e, t) => (0, r.jsx)("li", {
                            className: "truncate text-[12.5px] text-cp-muted",
                            children: e
                        }, `${t}-${e}`))
                    }) : null, i ? (0, r.jsxs)("p", {
                        className: (0, eS.cn)("flex items-start gap-2 text-[13px] leading-relaxed text-cp-ink", o ? "mt-2" : ""),
                        children: [s ? (0, r.jsx)(ek.A, {
                            className: "mt-0.5 size-4 shrink-0 text-cp-muted",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }) : null, (0, r.jsx)("span", {
                            children: i
                        })]
                    }) : null, "applied" !== n || e.message ? null : (0, r.jsxs)(eI.$, {
                        variant: "outline",
                        size: "sm",
                        className: "mt-2.5",
                        onClick: t,
                        children: [(0, r.jsx)(ey.A, {
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }), l.$F.undo]
                    })]
                })
            }

            function tl({
                text: e,
                live: t
            }) {
                let {
                    shown: n,
                    animated: i
                } = function(e, t) {
                    let [n] = (0, a.useState)(() => t && !window.matchMedia("(prefers-reduced-motion: reduce)").matches), [r, i] = (0, a.useState)(() => n ? 0 : e.length), s = (0, a.useRef)(n ? 0 : e.length), l = !t;
                    return ((0, a.useEffect)(() => {
                        if (!n) return;
                        let t = 0,
                            r = performance.now(),
                            a = n => {
                                let o = n - r;
                                r = n, s.current = function(e, t, n, r) {
                                    if (!(e < t)) return t;
                                    let a = Math.max(0, Math.min(n, 250)),
                                        i = Math.max((r ? 400 : 60) * a / 1e3, (t - e) * (1 - Math.exp(-a / (r ? 90 : 220))));
                                    return Math.min(t, e + i)
                                }(s.current, e.length, o, l);
                                let c = function(e, t, n) {
                                    let r = Math.min(Math.max(0, Math.floor(t)), e.length);
                                    if (n && r >= e.length) return e.length;
                                    for (let t = r - 1; t >= 0; t -= 1)
                                        if (eK.test(e[t])) return t + 1;
                                    return 0
                                }(e, s.current, l);
                                i(e => e === c ? e : c), t = s.current < e.length ? requestAnimationFrame(a) : 0
                            };
                        return t = requestAnimationFrame(a), () => cancelAnimationFrame(t)
                    }, [n, e, l]), n) ? {
                        shown: function(e, t, n) {
                            if (n && t >= e.length) return e;
                            let r = e.slice(0, Math.max(0, t)),
                                a = eB.exec(r);
                            if (a && (r = r.slice(0, a.index)), (r.match(/\*\*/g) ? .length ? ? 0) % 2 == 1) {
                                let e = r.trimEnd();
                                r = e.endsWith("**") ? e.slice(0, -2) : `${e}**`
                            }
                            return r
                        }(e, r, l && r >= e.length),
                        animated: n
                    } : {
                        shown: e,
                        animated: n
                    }
                }(e, t);
                return (0, r.jsx)("div", {
                    className: "w-fit max-w-[92%] rounded-2xl rounded-tl-md border border-cp-pastel-lilac bg-cp-bg px-3.5 py-2.5 text-[14.5px] leading-relaxed break-words text-cp-ink shadow-cp-float",
                    children: n ? (0, r.jsx)(eV, {
                        text: n,
                        animate: i
                    }) : (0, r.jsxs)("span", {
                        className: "inline-flex h-5 items-center",
                        children: [(0, r.jsx)(e$.SF, {
                            size: 18
                        }), (0, r.jsx)("span", {
                            className: "sr-only",
                            children: L
                        })]
                    })
                })
            }
            let to = "font-medium text-cp-primary underline decoration-cp-primary/30 underline-offset-2 hover:decoration-cp-primary";

            function tc({
                note: e,
                text: t,
                signedIn: n
            }) {
                return "limit-signin" === e ? (0, r.jsxs)("div", {
                    className: "flex flex-col items-center rounded-2xl border border-cp-line bg-cp-bg px-4 py-4 text-center",
                    children: [(0, r.jsx)(ez.W, {
                        size: 40
                    }), (0, r.jsx)("p", {
                        className: "mt-2 max-w-[32ch] text-[13px] leading-relaxed text-cp-ink",
                        children: t
                    }), n ? null : (0, r.jsx)(eI.$, {
                        asChild: !0,
                        size: "sm",
                        className: "mt-3",
                        children: (0, r.jsx)(em(), {
                            href: `/login?next=${encodeURIComponent(`${window.location.pathname}${window.location.search}`.slice(0,300))}`,
                            prefetch: !1,
                            onClick: () => (0, eX.Te)(),
                            children: "Sign in"
                        })
                    })]
                }) : (0, r.jsx)("div", {
                    className: "flex justify-center",
                    children: (0, r.jsxs)("p", {
                        role: "error" === e ? "status" : void 0,
                        className: (0, eS.cn)("max-w-[90%] rounded-2xl border px-3 py-1.5 text-center text-[12px] leading-relaxed", "error" === e ? "border-cp-danger/20 bg-cp-danger/10 text-cp-danger-ink" : "border-cp-line bg-cp-bg text-cp-muted"),
                        children: ["human" === e || "escalated" === e ? (0, r.jsx)(eg.A, {
                            className: "mr-1 inline size-3.5 -translate-y-px align-middle",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }) : null, t, "limit-budget" === e ? (0, r.jsxs)(r.Fragment, {
                            children: [" ", "You can still", " ", (0, r.jsx)(em(), {
                                href: "/contact",
                                prefetch: !1,
                                className: to,
                                children: "contact us"
                            }), " ", "or read the", " ", (0, r.jsx)(em(), {
                                href: "/contact#contact-faq",
                                prefetch: !1,
                                className: to,
                                children: "FAQ"
                            }), "."]
                        }) : null, "escalated" !== e || n ? null : (0, r.jsxs)(r.Fragment, {
                            children: [" ", "You can also leave your email on our", " ", (0, r.jsx)(em(), {
                                href: "/contact",
                                prefetch: !1,
                                className: to,
                                children: "contact page"
                            }), "."]
                        })]
                    })
                })
            }

            function td({
                titleId: e,
                draft: t,
                onDraftChange: n,
                ready: i,
                streaming: s,
                signedIn: l,
                phone: o,
                inEditor: c,
                humanActive: d,
                blocked: p,
                chip: m,
                attachError: h,
                canAttach: f,
                canSend: x,
                onAttachFile: g,
                onAttachInvalid: b,
                onRemoveAttachment: y,
                onSubmit: v,
                onStop: k
            }) {
                let w = (0, a.useRef)(null),
                    j = (0, a.useRef)(null);
                (0, a.useLayoutEffect)(() => {
                    let e = w.current;
                    e && (e.style.height = "auto", e.style.height = `${Math.min(e.scrollHeight,96)}px`)
                }, [t]), (0, a.useEffect)(() => {
                    o || w.current ? .focus({
                        preventScroll: !0
                    })
                }, [o]);
                let N = m.phase;
                (0, a.useEffect)(() => {
                    "uploading" === N && w.current ? .focus({
                        preventScroll: !0
                    })
                }, [N]);
                let A = () => {
                        x && v(t)
                    },
                    I = l && !d && !p;
                return (0, r.jsxs)("form", {
                    onSubmit: e => {
                        e.preventDefault(), A()
                    },
                    className: "relative shrink-0 px-3 pt-2 pb-[max(0.625rem,env(safe-area-inset-bottom))]",
                    children: [h ? (0, r.jsx)("p", {
                        role: "status",
                        className: "px-1 pb-1.5 text-[12px] leading-snug text-cp-danger-ink",
                        children: h
                    }) : null, (0, r.jsxs)("div", {
                        className: (0, eS.cn)("relative rounded-3xl", s && "overflow-hidden p-[1.5px]"),
                        children: [s ? (0, r.jsx)("span", {
                            "aria-hidden": "true",
                            className: "kiara-ring-glow absolute top-1/2 left-[-25%] -mt-[75%] aspect-square w-[150%]"
                        }) : null, (0, r.jsxs)("div", {
                            className: (0, eS.cn)("relative rounded-3xl border bg-cp-canvas transition-[border-color,box-shadow] duration-150 motion-reduce:transition-none", s ? "border-transparent" : "border-cp-line focus-within:border-cp-select focus-within:ring-2 focus-within:ring-cp-select/20"),
                            children: ["none" !== m.phase ? (0, r.jsx)("div", {
                                className: "px-3 pt-3",
                                children: (0, r.jsxs)("div", {
                                    className: "relative inline-block",
                                    children: [(0, r.jsx)("img", {
                                        src: m.previewUrl,
                                        alt: "",
                                        className: "size-16 rounded-lg border border-cp-line bg-cp-subtle object-cover"
                                    }), "uploading" === m.phase ? (0, r.jsxs)("span", {
                                        className: "absolute inset-0 inline-flex items-center justify-center rounded-lg bg-cp-ink/30",
                                        children: [(0, r.jsx)(eb.A, {
                                            className: "size-4 animate-spin text-white motion-reduce:animate-none",
                                            strokeWidth: 1.75,
                                            "aria-hidden": !0
                                        }), (0, r.jsx)("span", {
                                            className: "sr-only",
                                            children: "Uploading screenshot"
                                        })]
                                    }) : null, (0, r.jsx)("button", {
                                        type: "button",
                                        "aria-label": "Remove screenshot",
                                        onClick: y,
                                        className: "absolute -top-1.5 -right-1.5 inline-flex size-5 cursor-pointer items-center justify-center rounded-full bg-cp-ink text-white ring-2 ring-cp-bg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                                        children: (0, r.jsx)(eh.A, {
                                            className: "size-3",
                                            strokeWidth: 2,
                                            "aria-hidden": !0
                                        })
                                    })]
                                })
                            }) : null, (0, r.jsx)("label", {
                                className: "sr-only",
                                htmlFor: `${e}-input`,
                                children: "Message"
                            }), (0, r.jsx)("textarea", {
                                ref: w,
                                id: `${e}-input`,
                                value: t,
                                onChange: e => n(e.target.value),
                                onKeyDown: e => {
                                    "Enter" !== e.key || e.shiftKey || e.nativeEvent.isComposing || (e.preventDefault(), A())
                                },
                                onPaste: e => {
                                    let t = Array.from(e.clipboardData ? .files ? ? []).find(e => e.type.startsWith("image/"));
                                    !t || (e.preventDefault(), f && (u(t) ? g(t) : b()))
                                },
                                maxLength: 1e3,
                                rows: 1,
                                placeholder: p ? "Sign in to keep chatting" : d ? "Message our team\u2026" : c ? "What should I change on your page?" : "What are you celebrating?",
                                disabled: !i || p,
                                className: "block min-h-11 w-full resize-none bg-transparent px-4 pt-3.5 pb-1 text-[15px] leading-5 text-cp-ink outline-none placeholder:text-cp-muted disabled:cursor-not-allowed"
                            }), (0, r.jsxs)("div", {
                                className: "flex items-center gap-2 px-2.5 pt-1 pb-2.5",
                                children: [(0, r.jsx)("button", {
                                    type: "button",
                                    "aria-label": "Attach a screenshot",
                                    disabled: !f,
                                    onClick: () => j.current ? .click(),
                                    className: e6,
                                    children: (0, r.jsx)(ew.A, {
                                        className: "size-[18px]",
                                        strokeWidth: 1.75,
                                        "aria-hidden": !0
                                    })
                                }), (0, r.jsx)("input", {
                                    ref: j,
                                    type: "file",
                                    accept: "image/png,image/jpeg,image/webp",
                                    hidden: !0,
                                    tabIndex: -1,
                                    onChange: e => {
                                        let t = e.target.files ? .[0];
                                        e.target.value = "", t && (u(t) ? g(t) : b())
                                    }
                                }), I ? (0, r.jsx)("button", {
                                    type: "button",
                                    "aria-label": T,
                                    title: T,
                                    disabled: s || !i,
                                    onClick: () => v("Show my pages"),
                                    className: e6,
                                    children: (0, r.jsx)(ej, {
                                        className: "size-[18px]",
                                        strokeWidth: 1.75,
                                        "aria-hidden": !0
                                    })
                                }) : null, (0, r.jsx)("span", {
                                    className: "flex-1"
                                }), s ? (0, r.jsx)("button", {
                                    type: "button",
                                    "aria-label": "Stop answering",
                                    onClick: k,
                                    className: "inline-flex size-10 shrink-0 cursor-pointer items-center justify-center rounded-full bg-cp-ink text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                                    children: (0, r.jsx)(eN.A, {
                                        className: "size-3.5 fill-current",
                                        strokeWidth: 0,
                                        "aria-hidden": !0
                                    })
                                }) : (0, r.jsx)("button", {
                                    type: "submit",
                                    "aria-label": "Send message",
                                    disabled: !x,
                                    className: (0, eS.cn)(e6, x && "border-transparent bg-linear-to-br from-cp-rose to-cp-primary text-white hover:bg-transparent"),
                                    children: (0, r.jsx)(eA.A, {
                                        className: "size-[18px]",
                                        strokeWidth: 2,
                                        "aria-hidden": !0
                                    })
                                })]
                            })]
                        })]
                    }), (0, r.jsx)("p", {
                        className: "mt-1.5 text-center text-[11px] text-cp-faint",
                        children: "Cutiepage AI cat CEO, sometimes might make mistakes."
                    })]
                })
            }
            var tu = n(29579);

            function tp() {
                let e = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                return {
                    portalDone: e,
                    maxed: e,
                    helloDone: e
                }
            }

            function tm(e) {
                let t = window.matchMedia(eX.QB);
                return t.addEventListener("change", e), () => t.removeEventListener("change", e)
            }
            let th = "/api/support/chat";

            function tf(e) {
                return document.addEventListener("visibilitychange", e), () => document.removeEventListener("visibilitychange", e)
            }
            async function tx(e) {
                if (!e.ok) return null;
                let t = await e.json().catch(() => null);
                return t && "object" == typeof t && Array.isArray(t.items) ? t : null
            }

            function tg({
                open: e,
                onClose: t,
                surface: n,
                placement: s = "default",
                signedIn: o,
                pageEdits: d = !1,
                chatUrl: u,
                pendingMessage: p,
                onPendingConsumed: f,
                skipEnterAnimation: x = !1,
                firstName: g
            }) {
                var b, j, N, A, I;
                let E, z, $ = (0, a.useSyncExternalStore)(tm, () => window.matchMedia(eX.QB).matches, () => !1),
                    C = (0, a.useSyncExternalStore)(tf, () => "visible" === document.visibilityState, () => !0),
                    T = (0, i.usePathname)(),
                    L = (0, a.useId)(),
                    [H, K] = (0, a.useState)([]),
                    [B, eo] = (0, a.useState)(""),
                    [ec, ed] = (0, a.useState)(!1),
                    [eu, ep] = (0, a.useState)(!1),
                    [em, eh] = (0, a.useState)(!1),
                    [ef, ex] = (0, a.useState)(!1),
                    [eg, eb] = (0, a.useState)(null),
                    [ey, ev] = (0, a.useState)(null),
                    ek = (0, a.useRef)(null),
                    ew = (0, a.useRef)(null),
                    ej = (0, a.useRef)(!1),
                    eN = (0, a.useRef)(!1),
                    eA = (0, a.useRef)(ea),
                    eI = (0, a.useRef)([]),
                    [eS, eE] = (0, a.useState)(!1),
                    [ez, eM] = (0, a.useState)({
                        phase: "thinking",
                        startedAt: 0,
                        done: []
                    }),
                    [e_, eC] = (0, a.useState)(h),
                    eR = (0, a.useRef)(h),
                    eF = (0, a.useRef)(0),
                    [eD, eT] = (0, a.useState)(null),
                    eL = (0, a.useRef)([]),
                    eP = (0, a.useRef)(new Map),
                    eU = (0, a.useRef)(!1),
                    eW = "editor" === n,
                    [eO, eY] = (0, a.useState)(() => eW ? (0, tu.jm)() : null),
                    eH = (0, a.useRef)(eO);
                (0, a.useEffect)(() => {
                    if (!eW) return;
                    let e = e => {
                        let t = e.detail;
                        t && "object" == typeof t && (eH.current = t, eY(t))
                    };
                    return window.addEventListener(c.f, e), () => window.removeEventListener(c.f, e)
                }, [eW]);
                let eq = (0, a.useCallback)(e => {
                    let t = eR.current,
                        n = function(e, t) {
                            switch (t.type) {
                                case "start":
                                    return {
                                        phase: "uploading",
                                        token: t.token,
                                        previewUrl: t.previewUrl
                                    };
                                case "uploaded":
                                    if ("uploading" !== e.phase || e.token !== t.token) return e;
                                    return {
                                        phase: "ready",
                                        token: e.token,
                                        previewUrl: e.previewUrl,
                                        id: t.id
                                    };
                                case "failed":
                                    if ("none" === e.phase || e.token !== t.token) return e;
                                    return h;
                                case "remove":
                                case "sent":
                                    return h
                            }
                        }(t, e);
                    if (n === t) return;
                    eR.current = n, eC(n);
                    let r = "none" === t.phase || "none" !== n.phase && n.previewUrl === t.previewUrl ? null : t.previewUrl;
                    r && ("sent" === e.type ? eL.current.push(r) : URL.revokeObjectURL(r))
                }, []);
                (0, a.useEffect)(() => () => {
                    for (let e of eL.current) URL.revokeObjectURL(e);
                    eL.current = [];
                    let e = eR.current;
                    "none" !== e.phase && URL.revokeObjectURL(e.previewUrl)
                }, []);
                let eV = (0, a.useCallback)(e => {
                        ek.current = e, eb(e), (0, eX.EI)((0, eX.RY)(), eX.On, e)
                    }, []),
                    eK = (0, a.useCallback)(e => {
                        eA.current = e, ev(e.newestAt)
                    }, []),
                    eB = (0, a.useCallback)(e => {
                        eN.current = e, eh(e), e || (eI.current = [], (0, eX.x6)((0, eX.Ar)()))
                    }, []),
                    eZ = (0, a.useRef)(!1);
                (0, a.useEffect)(() => {
                    if (!e || eZ.current) return;
                    eZ.current = !0, ek.current = (0, eX.if)((0, eX.RY)(), eX.On);
                    let t = new AbortController,
                        n = !1;
                    return (async () => {
                        try {
                            let e = await ((0, eX.ZM)() ? ? fetch("/api/support/history", { ...eX.mx,
                                    signal: t.signal
                                })),
                                n = await tx(e);
                            if (t.signal.aborted || !n) return;
                            "string" == typeof n.conversationId && n.conversationId && eV(n.conversationId);
                            let r = !0 === n.humanActive;
                            if (eB(r), eK(el(n.items)), n.items.length > 0) {
                                let e = en(n.items, {
                                    signedIn: o
                                });
                                r && (e = Z(e)), !o && e.some(e => "note" === e.kind && "limit-signin" === e.note) && ex(!0), K(t => 0 === t.length ? e : t)
                            }
                        } catch {} finally {
                            n = !0, t.signal.aborted || ep(!0)
                        }
                    })(), () => {
                        n || (t.abort(), eZ.current = !1)
                    }
                }, [e, eV, eK, eB, o]);
                let [eJ, eQ] = (0, a.useState)(tp), [eG, e0] = (0, a.useState)(e), [e1, e2] = (0, a.useState)(!1);
                e !== eG && (e0(e), e && (eQ(tp()), e2(!1)));
                let e5 = (0, a.useCallback)(() => {
                    window.matchMedia("(prefers-reduced-motion: reduce)").matches ? t() : (e2(!0), window.setTimeout(t, 320))
                }, [t]);
                (0, a.useEffect)(() => {
                    if (!e) return;
                    let t = window.setTimeout(() => eQ(e => ({ ...e,
                            portalDone: !0
                        })), x ? 600 : 1350),
                        n = window.setTimeout(() => eQ(e => ({ ...e,
                            maxed: !0
                        })), 2500);
                    return () => {
                        window.clearTimeout(t), window.clearTimeout(n)
                    }
                }, [e, x]);
                let e6 = eJ.portalDone && eu || eJ.maxed ? eJ.helloDone || 0 !== H.length || p ? "ready" : "hello" : "portal";
                (0, a.useEffect)(() => {
                    if ("hello" !== e6) return;
                    let e = window.setTimeout(() => eQ(e => ({ ...e,
                        helloDone: !0
                    })), 2e3);
                    return () => window.clearTimeout(e)
                }, [e6]);
                let e9 = (0, a.useCallback)(async () => {
                        let e = ek.current;
                        if (e) try {
                            let t = await tx(await fetch(er(e, null), eX.mx));
                            if (!t || t.conversationId !== e) return;
                            eK(el(t.items)), eI.current = [];
                            let n = en(t.items, {
                                signedIn: o
                            });
                            !0 === t.humanActive ? K(Z(n)) : (K(n), eB(!1))
                        } catch {}
                    }, [eK, eB, o]),
                    e8 = (0, a.useCallback)((e, t) => {
                        let n = null;
                        try {
                            n = (0, l.F0)()
                        } catch {
                            n = null
                        }
                        if (!n || !(0, l.zn)(t.target, n.target)) return void K(t => G(t, e, "failed", l.$F.notHere));
                        let r = n,
                            a = t.changes;
                        (async () => {
                            let t;
                            try {
                                t = await r.apply(a, {
                                    photoFile: k
                                })
                            } catch {
                                t = {
                                    ok: !1,
                                    message: l.$F.failed
                                }
                            }
                            if (t.ok) eP.current.set(e, t.undo), K(t => G(t, e, "applied"));
                            else {
                                let n = t.message;
                                K(t => G(t, e, "failed", n))
                            }
                        })()
                    }, []),
                    e7 = (0, a.useCallback)(e => {
                        let t, n = eP.current.get(e);
                        try {
                            t = n ? n() : {
                                ok: !1,
                                message: l.$F.undoFailed
                            }
                        } catch {
                            t = {
                                ok: !1,
                                message: l.$F.undoFailed
                            }
                        }
                        eP.current.delete(e), K(n => t.ok ? G(n, e, "undone") : G(n, e, "applied", t.message))
                    }, []),
                    te = (0, a.useCallback)(async (e, n, r) => {
                        if (ej.current) return;
                        ej.current = !0, ed(!0), eE(!1), eM({
                            phase: "thinking",
                            startedAt: Date.now(),
                            done: []
                        });
                        let a = new AbortController;
                        ew.current = a, K(e => {
                            var t;
                            let a, i, s, l;
                            return t = V(e), a = !1, i = t.map(e => "project_picker" !== e.kind || e.locked ? e : (a = !0, { ...e,
                                locked: !0
                            })), s = a ? i : t, l = r && r.length > 0 ? [...r] : void 0, n || l ? [...s, {
                                id: q("u"),
                                kind: "user",
                                text: n ? ? "",
                                ...l ? {
                                    attachments: l
                                } : {}
                            }] : s
                        });
                        let i = eN.current;
                        i && (n || r ? .length) && eI.current.push((n ? ? "").trim());
                        let s = eW ? eH.current ? ? (0, tu.jm)() : null,
                            c = "string" != typeof e.message || e.event || eU.current ? void 0 : function(e) {
                                if (e) try {
                                    let e = (0, l.F0)();
                                    if (!e) return;
                                    let t = e.readDocument();
                                    if (null == t) return;
                                    return new TextEncoder().encode(JSON.stringify(t)).length <= 262144 ? t : void 0
                                } catch {
                                    return
                                }
                            }(eW && d),
                            p = {
                                conversationId: ek.current,
                                page: `${window.location.pathname}${window.location.search}`.slice(0, 300),
                                ...s ? {
                                    context: s
                                } : {},
                                ...e,
                                ...void 0 !== c ? {
                                    pageDocument: c
                                } : {}
                            },
                            m = (e, t) => fetch(t, {
                                method: "POST",
                                cache: "no-store",
                                credentials: t === th ? "same-origin" : "include",
                                headers: {
                                    "content-type": "application/json",
                                    accept: "application/x-ndjson",
                                    ...void 0 !== e.pageDocument ? {
                                        "x-kiara-page": "1"
                                    } : {}
                                },
                                body: JSON.stringify(e),
                                signal: a.signal
                            }),
                            h = async e => {
                                if (u && void 0 === e.pageDocument) {
                                    let t = await m(e, u);
                                    if (421 !== t.status) return t
                                }
                                return m(e, th)
                            },
                            f = 0,
                            x = !1,
                            g = !1,
                            b = !1,
                            y = [];
                        try {
                            let e = await h(p);
                            if (413 === e.status && void 0 !== p.pageDocument) {
                                eU.current = !0;
                                let t = { ...p
                                };
                                delete t.pageDocument, e = await h(t)
                            }
                            if (!e.ok || !e.body) return void K(t => 429 === e.status ? U(t, "rate") : X(t, "error", P));
                            for await (let t of w(e.body)) {
                                if (a.signal.aborted) break;
                                let e = S(t);
                                if (e) {
                                    if (f += 1, "meta" === e.type && eV(e.conversationId), "human_active" === e.type && (x = !0), ("text" === e.type || "templates" === e.type || "project_picker" === e.type || "page_edit" === e.type) && (g = !0), "limit" !== e.type || "signin" !== e.reason || o || ex(!0), "status" === e.type) {
                                        let t = e.phase;
                                        eM(e => ({ ...e,
                                            phase: t,
                                            done: e.phase !== t && "thinking" !== e.phase && "writing" !== e.phase ? [...e.done, e.phase] : e.done
                                        })), b && "thinking" !== t && (b = !1, eE(!1))
                                    }
                                    if (!b && function(e) {
                                            switch (e.type) {
                                                case "text":
                                                    return e.delta.length > 0;
                                                case "templates":
                                                case "project_picker":
                                                    return e.items.length > 0;
                                                case "access_granted":
                                                case "page_edit":
                                                case "escalated":
                                                case "limit":
                                                case "error":
                                                case "human_active":
                                                    return !0;
                                                default:
                                                    return !1
                                            }
                                        }(e) && (b = !0, eE(!0)), "page_edit" === e.type) {
                                        let t = q("e");
                                        K(n => Q(n, e, t)), J(e) && ($ ? y.push({
                                            id: t,
                                            event: e
                                        }) : e8(t, e))
                                    } else K(t => ee(t, e))
                                }
                            }
                            0 !== f || a.signal.aborted || K(e => X(e, "error", P))
                        } catch {
                            a.signal.aborted || K(e => X(e, "error", f > 0 ? P : "We couldn't reach Kiara. Check your connection and try again."))
                        } finally {
                            ew.current === a && (ew.current = null), ej.current = !1, ed(!1), K(e => V(e))
                        }
                        if (y.length > 0)
                            if (a.signal.aborted)
                                for (let {
                                        id: e,
                                        event: t
                                    } of y) e8(e, t);
                            else t(), window.requestAnimationFrame(() => {
                                for (let {
                                        id: e,
                                        event: t
                                    } of y) e8(e, t)
                            });
                        x && !i ? (eB(!0), await e9()) : i && !x && g && eB(!1)
                    }, [eW, $, u, t, d, eV, e9, eB, o, e8]);
                (0, a.useEffect)(() => {
                    let t;
                    if (!e || !em || !eg || !C) return;
                    let n = !1,
                        r = null,
                        a = 0,
                        i = () => {
                            n || (t = window.setTimeout(s, a >= 3 ? 3e4 : 8e3))
                        };
                    async function s() {
                        if (!n) {
                            if (ej.current) return void i();
                            r = new AbortController;
                            try {
                                let e = await fetch(er(eg, eA.current.newestAt), { ...eX.mx,
                                        signal: r.signal
                                    }),
                                    t = await tx(e);
                                if (n) return;
                                if (t && t.conversationId === eg) {
                                    let e = function(e, t, n) {
                                        let r = new Set(e.seen),
                                            a = [...n],
                                            i = [],
                                            s = e.newestAt,
                                            l = 0;
                                        for (let e of t) {
                                            if (!e || "object" != typeof e || "string" != typeof e.at) continue;
                                            let t = ei(e);
                                            if (!r.has(t)) {
                                                if (r.add(t), s = es(s, e.at), l += 1, "user" === e.kind && "string" == typeof e.text) {
                                                    let t = a.indexOf(e.text.trim());
                                                    if (t >= 0) {
                                                        a.splice(t, 1);
                                                        continue
                                                    }
                                                }
                                                i.push(e)
                                            }
                                        }
                                        return {
                                            fresh: i,
                                            cursor: {
                                                seen: r,
                                                newestAt: s
                                            },
                                            pendingUserTexts: a,
                                            added: l
                                        }
                                    }(eA.current, t.items, eI.current);
                                    if (eI.current = e.pendingUserTexts, eK(e.cursor), e.fresh.length > 0 && K(t => (function(e, t) {
                                            let n = e;
                                            for (let e of t) n = et(n, e);
                                            return n
                                        })(t, e.fresh)), a = e.added > 0 ? 0 : a + 1, !0 !== t.humanActive) return void eB(!1)
                                } else a += 1
                            } catch {
                                if (n) return;
                                a += 1
                            }
                            i()
                        }
                    }
                    return i(), () => {
                        n = !0, window.clearTimeout(t), r ? .abort()
                    }
                }, [e, em, eg, C, eK, eB]), (0, a.useEffect)(() => {
                    e && em && eg && ey && (0, eX.hT)((0, eX.Ar)(), {
                        conversationId: eg,
                        seenAt: ey
                    })
                }, [e, em, eg, ey]), (0, a.useEffect)(() => {
                    e || ew.current ? .abort()
                }, [e]), (0, a.useEffect)(() => () => ew.current ? .abort(), []);
                let tt = (b = {
                    signinBlocked: ef,
                    signedIn: o,
                    humanActive: em
                }).signinBlocked && !b.signedIn && !b.humanActive;
                (0, a.useEffect)(() => {
                    e && eu && p && !ec && !tt && (f(), te({
                        message: p.text.slice(0, 1e3)
                    }, p.text))
                }, [e, eu, p, ec, tt, te, f]);
                let tr = (0, a.useCallback)(e => {
                        let t, n = e.trim().slice(0, 1e3),
                            r = eR.current;
                        if (ej.current || "uploading" === r.phase) return;
                        let a = "ready" === r.phase ? [r.id] : [];
                        (n || 0 !== a.length) && (eo(""), eT(null), "ready" === r.phase && (t = [{
                            src: r.previewUrl
                        }], eq({
                            type: "sent"
                        })), te(a.length > 0 ? {
                            message: n,
                            attachmentIds: a
                        } : {
                            message: n
                        }, n || null, t))
                    }, [te, eq]),
                    ta = (0, a.useCallback)(async e => {
                        if (eT(null), "none" !== eR.current.phase) return;
                        eF.current += 1;
                        let t = eF.current;
                        eq({
                            type: "start",
                            token: t,
                            previewUrl: URL.createObjectURL(e)
                        });
                        let n = e => {
                                let n = eR.current;
                                "none" !== n.phase && n.token === t && (eq({
                                    type: "failed",
                                    token: t
                                }), eT(429 === e ? "You've attached a lot of screenshots today. Please try again later." : "That image could not be uploaded. Try a smaller screenshot."))
                            },
                            r = await y(e);
                        if (!r) return void n(null);
                        try {
                            let a = new FormData;
                            a.append("file", r, r.name);
                            let i = await fetch("/api/support/attachments", {
                                method: "POST",
                                cache: "no-store",
                                credentials: "same-origin",
                                headers: {
                                    accept: "application/json"
                                },
                                body: a
                            });
                            if (!i.ok) return void n(i.status);
                            let s = await i.json().catch(() => null),
                                l = s && "string" == typeof s.id && m(s.id) ? s.id : null;
                            if (!l) return void n(null);
                            eq({
                                type: "uploaded",
                                token: t,
                                id: l
                            });
                            let o = eR.current;
                            "ready" === o.phase && o.id === l && function(e, t) {
                                if (e && t)
                                    for (v.delete(e), v.set(e, t); v.size > 8;) {
                                        let e = v.keys().next().value;
                                        if (void 0 === e) break;
                                        v.delete(e)
                                    }
                            }(l, e)
                        } catch {
                            n(null)
                        }
                    }, [eq]),
                    ti = (0, a.useCallback)(() => {
                        eT(null), eq({
                            type: "remove"
                        })
                    }, [eq]),
                    ts = (0, a.useCallback)(() => eT("Please attach a PNG, JPEG or WebP screenshot."), []),
                    tl = (0, a.useCallback)(() => ew.current ? .abort(), []),
                    to = (0, a.useCallback)((e, t) => {
                        ej.current || (K(n => n.map(n => n.id === e && "project_picker" === n.kind ? { ...n,
                            picked: t,
                            locked: !0
                        } : n)), te({
                            event: {
                                type: "project_selected",
                                projectId: t
                            }
                        }, null))
                    }, [te]),
                    tc = (0, r.jsx)(e4, {
                        titleId: L,
                        items: H,
                        draft: B,
                        onDraftChange: eo,
                        streaming: ec,
                        ready: eu,
                        signedIn: o,
                        humanActive: em,
                        blocked: tt,
                        typing: !(j = {
                            streaming: ec,
                            humanActive: em,
                            contentThisTurn: eS
                        }).streaming || j.contentThisTurn ? "none" : j.humanActive ? "sending" : "kiara",
                        thinking: ez,
                        welcome: eW ? {
                            greeting: "Need a hand finishing your page?",
                            chips: (E = (N = eO ? .lastError) ? Y[N] : void 0) ? [E, ...D] : D
                        } : (z = T || "/", W.test(z) ? {
                            greeting: "Questions about this template? Ask me anything.",
                            chips: [R, ..._]
                        } : O.test(z) ? {
                            greeting: M,
                            chips: [F, ..._]
                        } : {
                            greeting: M,
                            chips: _
                        }),
                        hero: eW ? {
                            title: ["Stuck on your page?", "I can change it for you"],
                            cta: "Edit with me",
                            message: "Help me finish my page"
                        } : W.test(T || "/") ? {
                            title: ["Like this one?", "Ask me anything about it"],
                            cta: "Tell me more",
                            message: R
                        } : {
                            title: ["Too many cute ideas?", "Let me help you pick"],
                            cta: "Match my vibe",
                            message: F
                        },
                        firstName: g,
                        phone: $,
                        inEditor: eW,
                        onStop: tl,
                        chip: e_,
                        attachError: eD,
                        canAttach: (A = {
                            streaming: ec,
                            blocked: tt,
                            ready: eu,
                            chip: e_
                        }).ready && !A.streaming && !A.blocked && "none" === A.chip.phase,
                        canSend: !!(I = {
                            draft: B,
                            streaming: ec,
                            blocked: tt,
                            ready: eu,
                            chip: e_
                        }).ready && !I.streaming && !I.blocked && "uploading" !== I.chip.phase && (I.draft.trim().length > 0 || "ready" === I.chip.phase),
                        onAttachFile: e => void ta(e),
                        onAttachInvalid: ts,
                        onRemoveAttachment: ti,
                        onSubmit: tr,
                        onPick: to,
                        onUndoPageEdit: e7,
                        onClose: e5
                    }),
                    td = (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)("style", {
                            children: e3
                        }), (0, r.jsx)("div", {
                            "aria-hidden": "true",
                            className: `absolute inset-0 bg-cp-bg transition-opacity duration-500 ease-out motion-reduce:transition-none ${"portal"===e6?"opacity-0":"opacity-100"}`
                        }), "ready" !== e6 ? (0, r.jsx)(e$.TQ, {
                            leaving: "hello" === e6,
                            settled: x
                        }) : null, "hello" === e6 ? (0, r.jsx)("div", {
                            className: "relative min-h-0 flex-1",
                            children: (0, r.jsx)(tn, {
                                firstName: g,
                                line: "What are we celebrating today?"
                            })
                        }) : null, "ready" === e6 ? (0, r.jsx)("div", {
                            className: "kiara-ready-in relative flex min-h-0 flex-1 flex-col",
                            children: tc
                        }) : null, "portal" === e6 ? (0, r.jsx)("span", {
                            className: "sr-only",
                            children: "Loading your chat"
                        }) : null]
                    });
                return $ ? e ? (0, r.jsx)(tb, {
                    titleId: L,
                    surface: n,
                    animate: !x,
                    closing: e1,
                    onClose: e5,
                    children: td
                }) : null : e ? (0, r.jsx)(ty, {
                    titleId: L,
                    surface: n,
                    position: eX.pI[s],
                    animate: !x,
                    portal: "portal" === e6,
                    closing: e1,
                    onClose: e5,
                    children: td
                }) : null
            }

            function tb({
                titleId: e,
                surface: t,
                animate: n,
                closing: i,
                onClose: l,
                children: o
            }) {
                let c = (0, a.useRef)(null);
                return (0, s.V)({
                    open: !0,
                    panelRef: c,
                    onClose: l,
                    initialFocus: "self"
                }), (0, r.jsxs)("div", {
                    className: e$.Mw,
                    children: [(0, r.jsx)("div", {
                        "aria-hidden": "true",
                        onClick: l,
                        className: `${e$.IX} ${i?"kiara-scrim-out":n?"kiara-scrim-in":""}`
                    }), (0, r.jsx)("div", {
                        ref: c,
                        role: "dialog",
                        "aria-modal": "true",
                        "aria-labelledby": e,
                        tabIndex: -1,
                        "data-surface": t,
                        className: `${e$.RC} text-cp-ink outline-none ${i?"kiara-sheet-out":n?"kiara-sheet-in":""}`,
                        children: o
                    })]
                })
            }

            function ty({
                titleId: e,
                surface: t,
                position: n,
                animate: i,
                portal: l,
                closing: o,
                onClose: c,
                children: d
            }) {
                let u = (0, a.useRef)(null),
                    p = (0, a.useRef)(c);
                return (0, a.useEffect)(() => {
                    p.current = c
                }, [c]), (0, a.useEffect)(() => {
                    let e = u.current;
                    if (e) return (e.querySelector("textarea") ? ? (0, s.a)(e)[0] ? ? e).focus({
                        preventScroll: !0
                    }), e.addEventListener("keydown", t), () => e.removeEventListener("keydown", t);

                    function t(t) {
                        if (!e) return;
                        if ("Escape" === t.key) {
                            t.stopPropagation(), p.current();
                            return
                        }
                        if ("Tab" !== t.key || !e.contains(document.activeElement)) return;
                        let n = (0, s.a)(e);
                        if (0 === n.length) return;
                        let r = n[0],
                            a = n[n.length - 1];
                        t.shiftKey && document.activeElement === r ? (t.preventDefault(), a.focus()) : t.shiftKey || document.activeElement !== a || (t.preventDefault(), r.focus())
                    }
                }, []), (0, r.jsx)("div", {
                    ref: u,
                    role: "dialog",
                    "aria-modal": "false",
                    "aria-labelledby": e,
                    tabIndex: -1,
                    "data-surface": t,
                    className: `${i&&!o?"kiara-panel-in ":""}fixed ${n} z-40 flex h-[640px] max-h-[calc(100dvh-2rem)] w-[420px] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-3xl border text-cp-ink outline-none transition-[border-color,box-shadow] duration-300 ${l?"border-transparent":"border-cp-line shadow-cp-modal"} ${o?"kiara-exit":""}`,
                    children: d
                })
            }
        },
        9388: (e, t, n) => {
            n.d(t, {
                $: () => p
            });
            var r = n(73365),
                a = n(1521),
                i = n(92166),
                s = n(16168),
                l = n(54872);
            let o = (0, s.F)(["inline-flex shrink-0 cursor-pointer items-center justify-center gap-1.5 whitespace-nowrap rounded-full font-medium", "transition-[background-color,color,border-color,box-shadow,transform] duration-150", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", "disabled:cursor-not-allowed disabled:opacity-50 aria-disabled:cursor-not-allowed aria-disabled:opacity-50", "motion-reduce:transition-none"], {
                    variants: {
                        variant: {
                            primary: "border-0 bg-cp-primary text-white hover:bg-cp-primary-hover active:scale-[0.98] motion-reduce:active:scale-100",
                            secondary: "border-0 bg-cp-subtle text-cp-ink hover:bg-cp-hover active:scale-[0.98] motion-reduce:active:scale-100",
                            outline: "border border-cp-primary bg-cp-bg text-cp-primary hover:bg-cp-primary-soft active:scale-[0.98] motion-reduce:active:scale-100",
                            ghost: "border-0 bg-transparent text-cp-ink hover:bg-cp-subtle active:bg-cp-hover",
                            "ghost-dark": "border-0 bg-transparent text-white/80 hover:bg-white/10 hover:text-white",
                            danger: "border-0 bg-cp-danger-strong text-white hover:bg-cp-danger-strong/90 active:scale-[0.98] motion-reduce:active:scale-100"
                        },
                        size: {
                            xs: "h-8 px-3 text-[13px]",
                            sm: "h-9 px-3.5 text-[13px]",
                            md: "h-11 px-4 text-[14px]",
                            lg: "h-14 px-6 text-[15px] font-semibold"
                        },
                        iconOnly: {
                            true: "px-0",
                            false: ""
                        }
                    },
                    compoundVariants: [{
                        iconOnly: !0,
                        size: "xs",
                        className: "w-8"
                    }, {
                        iconOnly: !0,
                        size: "sm",
                        className: "w-9"
                    }, {
                        iconOnly: !0,
                        size: "md",
                        className: "w-11"
                    }, {
                        iconOnly: !0,
                        size: "lg",
                        className: "w-14"
                    }],
                    defaultVariants: {
                        variant: "primary",
                        size: "md",
                        iconOnly: !1
                    }
                }),
                c = {
                    xs: "size-4",
                    sm: "size-4",
                    md: "size-4",
                    lg: "size-[18px]"
                };

            function d({
                className: e
            }) {
                return (0, r.jsxs)("svg", {
                    className: (0, l.cn)("animate-spin motion-reduce:animate-none", e),
                    viewBox: "0 0 24 24",
                    fill: "none",
                    "aria-hidden": "true",
                    children: [(0, r.jsx)("circle", {
                        className: "opacity-25",
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "currentColor",
                        strokeWidth: "3"
                    }), (0, r.jsx)("path", {
                        className: "opacity-90",
                        d: "M12 2a10 10 0 0 1 10 10",
                        stroke: "currentColor",
                        strokeWidth: "3",
                        strokeLinecap: "round"
                    })]
                })
            }

            function u(e, t) {
                return e ? a.isValidElement(e) ? a.cloneElement(e, {
                    className: (0, l.cn)(t, "shrink-0", e.props.className)
                }) : e : null
            }
            let p = a.forwardRef(({
                className: e,
                variant: t,
                size: n,
                iconOnly: s = !1,
                iconLeading: p,
                iconTrailing: m,
                loading: h = !1,
                asChild: f = !1,
                disabled: x,
                children: g,
                type: b,
                ...y
            }, v) => {
                let k = n ? ? "md",
                    w = c[k],
                    j = x || h,
                    N = h ? (0, r.jsx)(d, {
                        className: w
                    }) : u(p, w),
                    A = h && !p ? null : u(m, w),
                    I = s && h ? null : s ? u(g, w) : g,
                    S = (0, l.cn)(o({
                        variant: t,
                        size: k,
                        iconOnly: s
                    }), h && "pointer-events-none", e);
                return f ? (0, r.jsx)(i.DX, {
                    className: S,
                    "data-cp-button": "",
                    "aria-busy": h || void 0,
                    "aria-disabled": j || void 0,
                    "data-disabled": j || void 0,
                    ref: v,
                    ...y,
                    children: a.isValidElement(g) ? a.cloneElement(g, void 0, (0, r.jsxs)(r.Fragment, {
                        children: [N, (0, r.jsx)(i.xV, {
                            children: g.props.children
                        }), A]
                    })) : g
                }) : (0, r.jsxs)("button", {
                    "data-cp-button": "",
                    className: S,
                    ref: v,
                    type: b ? ? "button",
                    disabled: j,
                    "aria-busy": h || void 0,
                    "aria-disabled": j || void 0,
                    ...y,
                    children: [N, (0, r.jsx)(i.xV, {
                        children: I
                    }), A]
                })
            });
            p.displayName = "Button"
        },
        13557: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("chevron-right", [
                ["path", {
                    d: "m9 18 6-6-6-6",
                    key: "mthhwq"
                }]
            ])
        },
        16168: (e, t, n) => {
            n.d(t, {
                F: () => s
            });
            var r = n(68662);
            let a = e => "boolean" == typeof e ? `${e}` : 0 === e ? "0" : e,
                i = r.$,
                s = (e, t) => n => {
                    var r;
                    if ((null == t ? void 0 : t.variants) == null) return i(e, null == n ? void 0 : n.class, null == n ? void 0 : n.className);
                    let {
                        variants: s,
                        defaultVariants: l
                    } = t, o = Object.keys(s).map(e => {
                        let t = null == n ? void 0 : n[e],
                            r = null == l ? void 0 : l[e];
                        if (null === t) return null;
                        let i = a(t) || a(r);
                        return s[e][i]
                    }), c = n && Object.entries(n).reduce((e, t) => {
                        let [n, r] = t;
                        return void 0 === r || (e[n] = r), e
                    }, {});
                    return i(e, o, null == t || null == (r = t.compoundVariants) ? void 0 : r.reduce((e, t) => {
                        let {
                            class: n,
                            className: r,
                            ...a
                        } = t;
                        return Object.entries(a).every(e => {
                            let [t, n] = e;
                            return Array.isArray(n) ? n.includes({ ...l,
                                ...c
                            }[t]) : ({ ...l,
                                ...c
                            })[t] === n
                        }) ? [...e, n, r] : e
                    }, []), null == n ? void 0 : n.class, null == n ? void 0 : n.className)
                }
        },
        24583: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("arrow-right", [
                ["path", {
                    d: "M5 12h14",
                    key: "1ays0h"
                }],
                ["path", {
                    d: "m12 5 7 7-7 7",
                    key: "xquz4c"
                }]
            ])
        },
        25798: (e, t, n) => {
            n.d(t, {
                M: () => i
            });
            var r = n(73365),
                a = n(54872);

            function i({
                className: e,
                statusBar: t = !1,
                children: n
            }) {
                return (0, r.jsxs)("div", {
                    className: (0, a.cn)("relative flex flex-col rounded-[46px] bg-linear-to-b from-[#4a4a52] via-[#2c2c32] to-[#3d3d44] p-[6px]", "shadow-[0_0_0_1px_rgba(255,255,255,0.22),inset_0_1px_0_rgba(255,255,255,0.18),0_30px_80px_rgba(0,0,0,0.45)]", e),
                    children: [(0, r.jsx)("span", {
                        "aria-hidden": !0,
                        className: "absolute top-[96px] -left-[3px] h-7 w-[3px] rounded-l-sm bg-[#3d3d44]"
                    }), (0, r.jsx)("span", {
                        "aria-hidden": !0,
                        className: "absolute top-[140px] -left-[3px] h-12 w-[3px] rounded-l-sm bg-[#3d3d44]"
                    }), (0, r.jsx)("span", {
                        "aria-hidden": !0,
                        className: "absolute top-[200px] -left-[3px] h-12 w-[3px] rounded-l-sm bg-[#3d3d44]"
                    }), (0, r.jsx)("span", {
                        "aria-hidden": !0,
                        className: "absolute top-[160px] -right-[3px] h-16 w-[3px] rounded-r-sm bg-[#3d3d44]"
                    }), (0, r.jsxs)("div", {
                        className: "relative flex min-h-0 flex-1 flex-col rounded-[40px] bg-black p-[4px]",
                        children: [(0, r.jsxs)("div", {
                            className: "relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-[36px] bg-white",
                            children: [t ? (0, r.jsx)("div", {
                                "aria-hidden": !0,
                                className: "h-10 shrink-0 bg-white"
                            }) : null, n]
                        }), (0, r.jsx)("span", {
                            "aria-hidden": !0,
                            className: "pointer-events-none absolute top-[11px] left-1/2 z-30 h-[24px] w-[90px] -translate-x-1/2 rounded-full bg-black"
                        })]
                    })]
                })
            }
        },
        26821: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("check", [
                ["path", {
                    d: "M20 6 9 17l-5-5",
                    key: "1gmf2c"
                }]
            ])
        },
        27544: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("square", [
                ["rect", {
                    width: "18",
                    height: "18",
                    x: "3",
                    y: "3",
                    rx: "2",
                    key: "afitv7"
                }]
            ])
        },
        29579: (e, t, n) => {
            n.d(t, {
                LF: () => o,
                jm: () => c,
                oB: () => s
            });
            var r = n(62727);
            let a = null,
                i = "";

            function s(e) {
                try {
                    if (!e || "object" != typeof e) return;
                    let t = { ...a,
                        ...e
                    };
                    if ("editor" !== t.surface && "try" !== t.surface) return;
                    "field" in e && (t.field = function(e) {
                        if ("string" != typeof e) return null;
                        let t = e.replace(/\s+/g, " ").trim();
                        return t && t.length <= 40 && /^[\p{L}\p{N} '\u2019&()./,-]+$/u.test(t) ? t : null
                    }(e.field));
                    let n = JSON.stringify(t);
                    if (n === i) return;
                    a = t, i = n, window.__cpSupportContext = t, window.dispatchEvent(new CustomEvent(r.f, {
                        detail: t
                    }))
                } catch {}
            }

            function l(e) {
                if (!e) return null;
                let t = e.replace(/[^\p{L}\p{N} '\u2019&()./,-]+/gu, " ").replace(/\s+/g, " ").trim();
                if (!t) return null;
                if (t.length <= 40) return t;
                let n = t.slice(0, 40);
                return n.slice(0, n.lastIndexOf(" ") > 0 ? n.lastIndexOf(" ") : 40).trim()
            }

            function o(e) {
                try {
                    let t = function(e) {
                        if ("u" < typeof HTMLElement || !(e instanceof HTMLElement) || !(e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement || e instanceof HTMLSelectElement || e.isContentEditable)) return null;
                        let t = (e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement || e instanceof HTMLSelectElement ? e.labels ? .[0] ? .textContent : null) ? ? e.getAttribute("aria-label");
                        if (l(t)) return l(t);
                        let n = e.parentElement;
                        for (let e = 0; n && e < 4; e += 1, n = n.parentElement) {
                            let e = n.querySelectorAll("label");
                            if (e.length > 1) break;
                            if (1 === e.length) return l(e[0].textContent)
                        }
                        return null
                    }(e);
                    t && s({
                        field: t
                    })
                } catch {}
            }

            function c() {
                try {
                    if (a) return a;
                    return window.__cpSupportContext ? ? null
                } catch {
                    return null
                }
            }
        },
        44121: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("arrow-down", [
                ["path", {
                    d: "M12 5v14",
                    key: "s699le"
                }],
                ["path", {
                    d: "m19 12-7 7-7-7",
                    key: "1idqje"
                }]
            ])
        },
        45086: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("undo-2", [
                ["path", {
                    d: "M9 14 4 9l5-5",
                    key: "102s5s"
                }],
                ["path", {
                    d: "M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",
                    key: "f3b9sd"
                }]
            ])
        },
        50975: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("headset", [
                ["path", {
                    d: "M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z",
                    key: "12oyoe"
                }],
                ["path", {
                    d: "M21 16v2a4 4 0 0 1-4 4h-5",
                    key: "1x7m43"
                }]
            ])
        },
        56224: (e, t, n) => {
            n.d(t, {
                E: () => i
            });
            var r = n(73365),
                a = n(54872);

            function i({
                className: e,
                children: t,
                variant: n = "default",
                tone: s,
                dot: l = !1
            }) {
                return s ? (0, r.jsxs)("span", {
                    "data-slot": "badge",
                    className: (0, a.cn)("inline-flex h-5 items-center gap-1 rounded-md px-1.5 text-[12px] leading-none font-medium whitespace-nowrap", {
                        neutral: "bg-cp-subtle text-cp-muted",
                        primary: "bg-cp-primary-soft text-cp-primary",
                        success: "bg-cp-success/10 text-cp-success-ink",
                        warning: "bg-cp-warning/15 text-cp-warning-ink",
                        danger: "bg-cp-danger/10 text-cp-danger-ink"
                    }[s], e),
                    children: [l ? (0, r.jsx)("span", {
                        "aria-hidden": !0,
                        className: "size-1.5 rounded-full bg-current"
                    }) : null, t]
                }) : (0, r.jsx)("span", {
                    className: (0, a.cn)("inline-flex items-center rounded-full px-3 py-1 text-xs font-medium tracking-[0.16em] uppercase", {
                        default: "border border-cp-line bg-cp-bg/70 text-cp-muted",
                        accent: "border border-cp-primary/20 bg-cp-primary-soft text-cp-primary",
                        dark: "border border-white/10 bg-white/10 text-white/90",
                        outline: "border border-cp-primary text-cp-primary"
                    }[n], e),
                    children: t
                })
            }
        },
        56440: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("chevron-left", [
                ["path", {
                    d: "m15 18-6-6 6-6",
                    key: "1wnfg3"
                }]
            ])
        },
        56855: (e, t, n) => {
            n.d(t, {
                V: () => i,
                a: () => a
            });
            var r = n(1521);

            function a(e) {
                return Array.from(e.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')).filter(e => !e.closest("[inert]") && e.getClientRects().length > 0)
            }

            function i({
                open: e,
                panelRef: t,
                onClose: n,
                initialFocus: s
            }) {
                let l = (0, r.useEffectEvent)(() => n());
                (0, r.useEffect)(() => {
                    if (!e) return;
                    let n = t.current;
                    if (!n) return;
                    let r = document.activeElement;
                    ("self" === s ? n : (s ? n.querySelector(s) : null) ? ? a(n)[0] ? ? n).focus({
                        preventScroll: !0
                    });
                    let i = document.documentElement,
                        o = i.style.overflow,
                        c = i.style.paddingRight,
                        d = window.innerWidth - i.clientWidth;

                    function u(e) {
                        if ("Escape" === e.key) {
                            e.stopPropagation(), l();
                            return
                        }
                        if ("Tab" !== e.key || !n) return;
                        let t = a(n);
                        if (0 === t.length) {
                            e.preventDefault(), n.focus();
                            return
                        }
                        let r = t[0],
                            i = t[t.length - 1],
                            s = document.activeElement;
                        e.shiftKey && (s === r || !n.contains(s)) ? (e.preventDefault(), i.focus()) : e.shiftKey || s !== i && n.contains(s) || (e.preventDefault(), r.focus())
                    }
                    return i.style.overflow = "hidden", d > 0 && (i.style.paddingRight = `${d}px`), document.addEventListener("keydown", u), () => {
                        document.removeEventListener("keydown", u), i.style.overflow = o, i.style.paddingRight = c, r ? .focus ? .({
                            preventScroll: !0
                        })
                    }
                }, [e, s, t])
            }
        },
        62727: (e, t, n) => {
            n.d(t, {
                f: () => r
            });
            let r = "cp-support:context"
        },
        64112: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("circle-alert", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["line", {
                    x1: "12",
                    x2: "12",
                    y1: "8",
                    y2: "12",
                    key: "1pkeuh"
                }],
                ["line", {
                    x1: "12",
                    x2: "12.01",
                    y1: "16",
                    y2: "16",
                    key: "4dfq90"
                }]
            ])
        },
        70414: (e, t, n) => {
            n.d(t, {
                Dh: () => s,
                G5: () => i,
                TH: () => a
            });
            let r = ["girlfriends-day"];

            function a(e, t) {
                return "live_pass" === t || !!e && r.includes(e)
            }

            function i(e) {
                var t;
                let n = Math.max(0, Math.round(e || 0)),
                    r = (t = n) >= 499 ? 499 : Math.min(499, Math.max(399, 10 * Math.round((399 + 100 * Math.min(1, Math.max(0, t / 499)) - 9) / 10) + 9)),
                    a = r - n,
                    i = {
                        priceInr: n,
                        compareAtInr: null,
                        discountPercent: null,
                        savingsInr: 0,
                        hasOffer: !1,
                        isFree: n <= 0
                    };
                if (a <= 0) return i;
                let s = Math.floor(a / r * 100);
                return s < 10 ? i : {
                    priceInr: n,
                    compareAtInr: r,
                    discountPercent: s,
                    savingsInr: a,
                    hasOffer: !0,
                    isFree: n <= 0
                }
            }

            function s(e) {
                return `\u20b9${e.toLocaleString("en-IN")}`
            }
        },
        72705: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("plus", [
                ["path", {
                    d: "M5 12h14",
                    key: "1ays0h"
                }],
                ["path", {
                    d: "M12 5v14",
                    key: "s699le"
                }]
            ])
        },
        79225: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("x", [
                ["path", {
                    d: "M18 6 6 18",
                    key: "1bl5f8"
                }],
                ["path", {
                    d: "m6 6 12 12",
                    key: "d8bk6v"
                }]
            ])
        },
        83078: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(96296).A)("circle-check", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["path", {
                    d: "m9 12 2 2 4-4",
                    key: "dzmm74"
                }]
            ])
        },
        92166: (e, t, n) => {
            let r, a;
            n.d(t, {
                DX: () => c,
                xV: () => u
            });
            var i, s = n(1521),
                l = n.t(s, 2);

            function o(e, t) {
                if ("function" == typeof e) return e(t);
                null != e && (e.current = t)
            }
            var c = (i = "Slot", (r = s.forwardRef((e, t) => {
                    var n;
                    let r, a, {
                            children: l,
                            ...c
                        } = e,
                        u = null,
                        m = !1,
                        b = [];
                    h(l) && "function" == typeof g && (l = g(l._payload)), s.Children.forEach(l, e => {
                        var t;
                        if (t = e, s.isValidElement(t) && "function" == typeof t.type && "__radixId" in t.type && t.type.__radixId === d) {
                            m = !0;
                            let t = "child" in e.props ? e.props.child : e.props.children;
                            h(t) && "function" == typeof g && (t = g(t._payload)), u = p(e, t), b.push(u ? .props ? .children)
                        } else b.push(e)
                    }), u ? u = s.cloneElement(u, void 0, b) : !m && 1 === s.Children.count(l) && s.isValidElement(l) && (u = l);
                    let y = u ? (n = u, (a = (r = Object.getOwnPropertyDescriptor(n.props, "ref") ? .get) && "isReactWarning" in r && r.isReactWarning) ? n.ref : (a = (r = Object.getOwnPropertyDescriptor(n, "ref") ? .get) && "isReactWarning" in r && r.isReactWarning) ? n.props.ref : n.props.ref || n.ref) : void 0,
                        v = function(...e) {
                            return s.useCallback(function(...e) {
                                return t => {
                                    let n = !1,
                                        r = e.map(e => {
                                            let r = o(e, t);
                                            return n || "function" != typeof r || (n = !0), r
                                        });
                                    if (n) return () => {
                                        for (let t = 0; t < r.length; t++) {
                                            let n = r[t];
                                            "function" == typeof n ? n() : o(e[t], null)
                                        }
                                    }
                                }
                            }(...e), e)
                        }(t, y);
                    if (!u) {
                        if (l || 0 === l) throw Error(m ? x(i) : f(i));
                        return l
                    }
                    let k = function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let a = e[r],
                                i = t[r];
                            /^on[A-Z]/.test(r) ? a && i ? n[r] = (...e) => {
                                let t = i(...e);
                                return a(...e), t
                            } : a && (n[r] = a) : "style" === r ? n[r] = { ...a,
                                ...i
                            } : "className" === r && (n[r] = [a, i].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(c, u.props ? ? {});
                    return u.type !== s.Fragment && (k.ref = t ? v : y), s.cloneElement(u, k)
                })).displayName = `${i}.Slot`, r),
                d = Symbol.for("radix.slottable"),
                u = ((a = e => "child" in e ? e.children(e.child) : e.children).displayName = "Slottable.Slottable", a.__radixId = d, a),
                p = (e, t) => {
                    if ("child" in e.props) {
                        let t = e.props.child;
                        return s.isValidElement(t) ? s.cloneElement(t, void 0, e.props.children(t.props.children)) : null
                    }
                    return s.isValidElement(t) ? t : null
                },
                m = Symbol.for("react.lazy");

            function h(e) {
                var t;
                return null != e && "object" == typeof e && "$$typeof" in e && e.$$typeof === m && "_payload" in e && "object" == typeof(t = e._payload) && null !== t && "then" in t
            }
            var f = e => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`,
                x = e => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`,
                g = l[" use ".trim().toString()]
        },
        96331: (e, t, n) => {
            n.d(t, {
                k: () => i
            });
            var r = n(73365),
                a = n(54872);

            function i({
                className: e
            }) {
                return (0, r.jsxs)("svg", {
                    "aria-hidden": !0,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    className: (0, a.cn)("size-7 text-cp-primary motion-safe:animate-[spin_0.9s_linear_infinite]", e),
                    children: [(0, r.jsx)("circle", {
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "var(--cp-line)",
                        strokeWidth: "2",
                        vectorEffect: "non-scaling-stroke"
                    }), (0, r.jsx)("path", {
                        d: "M22 12a10 10 0 0 0-10-10",
                        stroke: "currentColor",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        vectorEffect: "non-scaling-stroke"
                    })]
                })
            }
        }
    }
]);