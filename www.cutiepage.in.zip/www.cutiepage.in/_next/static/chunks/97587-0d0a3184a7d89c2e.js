"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [97587], {
        52550: (e, t, n) => {
            function a(e, t) {
                let n = t.trim(),
                    a = e.replace(/\D/g, ""),
                    i = n.replace(/\D/g, "").replace(/^0+/, ""),
                    s = i.length > 10 && i.startsWith(a) ? i : `${a}${i}`,
                    r = function(e) {
                        let t = String(e ? ? "").trim();
                        if (!t) return null;
                        let n = t.startsWith("+"),
                            a = n ? t.slice(1) : t;
                        if (!/^[\d\s().-]+$/.test(a)) return null;
                        let i = a.replace(/\D/g, "");
                        return !n && (/^[6-9]\d{9}$/.test(i) ? i = `91${i}` : /^0[6-9]\d{9}$/.test(i) ? i = `91${i.slice(1)}` : i.startsWith("00") && (i = i.slice(2))), /^[1-9]\d{7,14}$/.test(i) ? `+${i}` : null
                    }(n.startsWith("+") ? n : `+${s}`);
                return r && (r.startsWith("+91") ? /^\+91[6-9]\d{9}$/.test(r) : /^\+[1-9]\d{7,14}$/.test(r)) ? r : null
            }
            n.d(t, {
                dP: () => i,
                tm: () => a
            });
            let i = {
                invalidPhone: "whatsapp_invalid_phone",
                dailyLimit: "daily_code_limit",
                cooldown: "whatsapp_cooldown",
                unavailable: "whatsapp_unavailable"
            }
        },
        54582: (e, t, n) => {
            function a(e) {
                let t = "object" == typeof e ? e : null,
                    n = "string" == typeof t ? .code ? t.code : "",
                    a = "number" == typeof t ? .status ? t.status : 0,
                    i = "string" == typeof t ? .name ? t.name : "";
                return ("string" == typeof t ? .message ? t.message : "").includes("daily_code_limit") ? "daily_limit" : "otp_expired" === n || "invalid_credentials" === n ? "invalid_code" : "over_email_send_rate_limit" === n || "over_request_rate_limit" === n || 429 === a ? "rate_limited" : "captcha_failed" === n ? "captcha" : "email_address_invalid" === n || "email_address_not_authorized" === n ? "invalid_email" : "user_banned" === n ? "banned" : "signup_disabled" === n || "otp_disabled" === n || "email_provider_disabled" === n ? "not_allowed" : "AuthRetryableFetchError" === i || e instanceof TypeError && !n ? "network" : a >= 500 || "unexpected_failure" === n ? "send_failed" : "unknown"
            }

            function i(e, t) {
                let n = a(e);
                return {
                    kind: n,
                    message: function(e, t) {
                        let n = t ? "or open this page in Chrome or Safari" : "or continue with Google";
                        switch (e) {
                            case "daily_limit":
                                return `You've asked for a lot of codes today. Please try again tomorrow, ${n}.`;
                            case "invalid_code":
                                return "That code didn't work. Check it, or send a new one.";
                            case "rate_limited":
                                return "Please wait a minute before asking for another code.";
                            case "captcha":
                                return "We couldn't confirm you're a person. Please try again.";
                            case "invalid_email":
                                return "That email doesn't look right. Please check it.";
                            case "banned":
                                return "This account can't sign in.";
                            case "not_allowed":
                                return `Email sign-in isn't available right now. Please try again later, ${n}.`;
                            case "network":
                                return "You seem to be offline. Check your connection and try again.";
                            case "send_failed":
                            case "unknown":
                                return `We couldn't send your code right now. Try again in a bit, ${n}.`
                        }
                    }(n, t)
                }
            }
            n.d(t, {
                AW: () => a,
                CA: () => i
            })
        },
        60151: (e, t, n) => {
            n.d(t, {
                u: () => a
            });

            function a(e) {
                return !e || !e.startsWith("/") || e.startsWith("//") || e.startsWith("/\\") ? "/dashboard" : e
            }
        },
        88786: (e, t, n) => {
            n.d(t, {
                Ub: () => r,
                ku: () => i,
                yR: () => s
            });
            var a = n(21381);

            function i(e) {
                return "/" === e || ["/dashboard", "/editor", "/checkout", "/success"].some(t => e.startsWith(t)) ? `${(0,a.Zp)()}${"/"===e?"/dashboard":e}` : e
            }

            function s({
                chunks: e = !1
            } = {}) {
                let t = (0, a.Zp)();
                if ("u" < typeof document || t === window.location.origin) return;
                let n = (e, t) => {
                    let n = document.createElement("link");
                    n.rel = e, n.href = t, document.head.appendChild(n)
                };
                if (n("preconnect", t), e)
                    for (let e of performance.getEntriesByType("resource")) {
                        let a = new URL(e.name);
                        a.origin === window.location.origin && /^\/_next\/static\/.+\.(js|css)$/.test(a.pathname) && n("prefetch", `${t}${a.pathname}`)
                    }
            }

            function r(e, t, n = Date.now()) {
                let a, i;
                if (a = e.split("?")[0] ? .split("#")[0] ? ? "", (i = /^\/dashboard\/templates\/([a-z0-9][a-z0-9-]*)\/start$/i.exec(a)) ? i[1] : null) return null;
                if (!(n - Date.parse(t ? .email_confirmed_at ? ? t ? .phone_confirmed_at ? ? "") < 12e4)) return e;
                let s = new URL(e, "http://local.invalid");
                return s.searchParams.set("signup", "1"), `${s.pathname}${s.search}${s.hash}`
            }
        },
        97587: (e, t, n) => {
            n.d(t, {
                k: () => j,
                r: () => P
            });
            var a = n(73365),
                i = n(1521),
                s = n(2911),
                r = n(24583),
                o = n(54582),
                l = n(88786),
                c = n(60151),
                u = n(37809),
                d = n(52550),
                p = n(54872),
                h = n(69034);
            async function m() {
                let {
                    createSupabaseBrowserClient: e
                } = await Promise.all([n.e(74339), n.e(16937), n.e(88681)]).then(n.bind(n, 11062));
                return e()
            }
            let f = "cp_wa_pending",
                w = "We couldn't confirm you're a person. Please try again.",
                g = "You seem to be offline. Check your connection and try again.",
                x = "Please wait a few minutes before trying again.",
                b = "WhatsApp sign-in isn't available right now. Please use another way to sign in.",
                y = "Something went wrong. Please try again.",
                _ = "Network error. Please sign in with email instead.",
                v = "Please enter a valid WhatsApp number with its country code.";

            function k() {
                try {
                    let e = localStorage.getItem(f);
                    if (!e) return null;
                    let t = JSON.parse(e),
                        n = t ? .flow === "inbound" ? "string" == typeof t.code && "string" == typeof t.waLink && Date.parse(t.expiresAt) > Date.now() : t ? .flow === "code" && "string" == typeof t.phone && Date.now() - t.sentAt < 6e5;
                    return n || localStorage.removeItem(f), n ? t : null
                } catch {
                    return null
                }
            }

            function j() {
                let e = k();
                return null !== e && e.path === window.location.pathname
            }

            function N(e) {
                try {
                    e ? localStorage.setItem(f, JSON.stringify({ ...e,
                        path: window.location.pathname
                    })) : localStorage.removeItem(f)
                } catch {}
            }

            function S(e) {
                let t = String(e ? .message ? ? "");
                return Object.values(d.dP).find(e => t.includes(e)) ? ? null
            }

            function W(e, t) {
                let n = e ? ? {};
                return (n.data ? ? {})[t] ? ? n[t]
            }
            let A = () => () => {},
                C = () => /Android|iPhone|iPad|iPod|Mobi/i.test(navigator.userAgent);

            function P({
                nextPath: e,
                surface: t,
                inAppBrowser: f,
                onVerifyStart: j,
                onVerifyEnd: $,
                onSignedIn: E,
                sendsCode: D = !1,
                presetPhone: L,
                onChangeContact: O,
                onSendFailed: R,
                captcha: M = !0,
                onEngage: z,
                pillClassName: F
            }) {
                let I = D || !!L,
                    J = (0, c.u)(e),
                    U = !E,
                    Y = (0, i.useSyncExternalStore)(A, C, () => !1),
                    [q, G] = (0, i.useState)(L ? "phone" : "idle"),
                    [V, B] = (0, i.useState)(null),
                    [Z, Q] = (0, i.useState)(null),
                    [H, K] = (0, i.useState)("+91"),
                    [X, ee] = (0, i.useState)(L ? .replace(/^\+91/, "") ? ? ""),
                    [et, en] = (0, i.useState)(""),
                    [ea, ei] = (0, i.useState)(""),
                    [es, er] = (0, i.useState)(!1),
                    [eo, el] = (0, i.useState)(null),
                    [ec, eu] = (0, i.useState)(null),
                    [ed, ep] = (0, i.useState)(() => Date.now()),
                    [eh, em] = (0, i.useState)(!1),
                    [ef, ew] = (0, i.useState)(!1),
                    [eg, ex] = (0, i.useState)(!1),
                    eb = (0, i.useRef)(null),
                    ey = (0, i.useRef)(null),
                    e_ = (0, i.useRef)(null),
                    ev = (0, i.useRef)(null),
                    ek = (0, i.useRef)(null),
                    ej = (0, i.useRef)(() => {}),
                    eN = (0, i.useRef)(!1),
                    eS = (0, i.useRef)(!1),
                    eW = () => ek.current ? ? = m().catch(e => {
                        throw ek.current = null, e
                    }),
                    eA = (0, i.useCallback)((e, n = {}) => {
                        (0, u.G4)({
                            name: e,
                            props: {
                                surface: t,
                                in_app_browser: f,
                                auth_method: "whatsapp",
                                ...n
                            }
                        })
                    }, [t, f]);
                async function eC() {
                    el(null), G("starting");
                    let e = Date.now();
                    try {
                        let t = await fetch("/api/auth/whatsapp/start", {
                            method: "POST",
                            credentials: "same-origin"
                        });
                        if (!t.ok) {
                            eA("auth_otp_failed", {
                                stage: "start",
                                code: t.status,
                                flow: "inbound"
                            }), G("idle"), el(429 === t.status ? x : 404 === t.status || 503 === t.status ? b : y);
                            return
                        }
                        let n = await t.json(),
                            a = W(n, "code"),
                            i = W(n, "waLink");
                        if (W(n, "expiresAt"), "string" != typeof a || "string" != typeof i) throw Error("bad start answer");
                        let s = {
                            code: a,
                            waLink: i,
                            expiresAt: new Date(Date.now() + 6e5).toISOString()
                        };
                        B(s), Q(null), G("inbound"), N({
                            flow: "inbound",
                            ...s
                        }), eA("auth_otp_requested", {
                            flow: "inbound"
                        }), Y && Date.now() - e < 1e3 && window.location.assign(s.waLink)
                    } catch (e) {
                        eA("auth_otp_failed", {
                            stage: "start",
                            code: e instanceof TypeError ? "network" : "unknown",
                            flow: "inbound"
                        }), G("idle"), el(e instanceof TypeError ? g : y)
                    }
                }

                function eP() {
                    N(null), G("expired")
                }
                async function eT() {
                    el(null), j ? .();
                    try {
                        let e = await fetch("/api/auth/whatsapp/complete", {
                            method: "POST",
                            headers: {
                                "content-type": "application/json"
                            },
                            credentials: "same-origin",
                            body: JSON.stringify({
                                next: J
                            }),
                            signal: AbortSignal.timeout(2e4)
                        });
                        if (e.ok) {
                            if (N(null), (0, u.Sm)(!0), E) {
                                eO(), G("idle"), E();
                                return
                            }
                            window.location.assign((0, l.ku)(await eO())), window.setTimeout(() => {
                                $ ? .(), ez(), el(_)
                            }, 2e4);
                            return
                        }
                        if (eA("auth_otp_failed", {
                                stage: "complete",
                                code: e.status,
                                flow: "inbound"
                            }), 409 === e.status && !eN.current) return eN.current = !0, eT();
                        if ($ ? .(), 401 === e.status || 403 === e.status || 410 === e.status) return void eP();
                        ez(), el(429 === e.status ? x : "We couldn't finish signing you in. Please try again.")
                    } catch (e) {
                        if (!(e instanceof DOMException) && !eN.current) return eN.current = !0, eT();
                        $ ? .(), eA("auth_otp_failed", {
                            stage: "complete",
                            code: e instanceof DOMException ? e.name : "network",
                            flow: "inbound"
                        }), ez(), el(e instanceof DOMException && "TimeoutError" === e.name ? _ : g)
                    }
                }(0, i.useEffect)(() => {
                    let e = k();
                    if (!e || L && "code" === e.flow && e.phone !== L) {
                        L && !eS.current && (eS.current = !0, eL(!1, L));
                        return
                    }
                    "inbound" === e.flow ? (B({
                        code: e.code,
                        waLink: e.waLink,
                        expiresAt: e.expiresAt
                    }), G("inbound")) : (en(e.phone), eu(e.sentAt), G("code"))
                }, []), (0, i.useEffect)(() => {
                    ej.current = () => void eT()
                });
                let e$ = V ? .expiresAt;
                (0, i.useEffect)(() => {
                    if ("inbound" !== q || !e$) return;
                    (0, l.yR)({
                        chunks: U
                    });
                    let e = Math.min(Date.parse(e$) || 1 / 0, Date.now() + 6e5),
                        t = !1,
                        n = 0,
                        a = !1;
                    async function i() {
                        if (!t && !a) {
                            a = !0;
                            try {
                                await s()
                            } finally {
                                a = !1
                            }
                        }
                    }
                    async function s() {
                        if (Date.now() > e) return eP();
                        try {
                            let e = await fetch("/api/auth/whatsapp/status", {
                                credentials: "same-origin",
                                cache: "no-store"
                            });
                            if (t) return;
                            if (e.ok) {
                                let n = W(await e.json(), "status");
                                if (t) return;
                                if ("verified" === n) {
                                    eA("auth_otp_verified", {
                                        flow: "inbound"
                                    }), eN.current = !1, t = !0, G("finishing"), ej.current();
                                    return
                                }
                                if ("expired" === n) return eP()
                            } else if (e.status >= 400 && e.status < 500 && 429 !== e.status) return eP()
                        } catch {}
                        n = window.setTimeout(i, 1e3)
                    }
                    n = window.setTimeout(i, 1e3);
                    let r = () => {
                        "visible" !== document.visibilityState || t || (window.clearTimeout(n), i())
                    };
                    return document.addEventListener("visibilitychange", r), window.addEventListener("focus", r), window.addEventListener("pageshow", r), () => {
                        t = !0, window.clearTimeout(n), document.removeEventListener("visibilitychange", r), window.removeEventListener("focus", r), window.removeEventListener("pageshow", r)
                    }
                }, [q, e$, eA, U]);
                let eE = V ? .waLink;

                function eD(e, t) {
                    let n = S(e);
                    if (n && n !== d.dP.dailyLimit) {
                        eA("auth_otp_failed", {
                            stage: t,
                            code: n,
                            flow: "code"
                        });
                        let e = n === d.dP.invalidPhone ? v : n === d.dP.cooldown ? x : b;
                        return el(e), e
                    }
                    let a = (0, o.AW)(e);
                    if (eA("auth_otp_failed", {
                            stage: t,
                            code: a,
                            flow: "code"
                        }), "banned" === a) return window.location.assign("/login?error=auth_callback_failed&reason=user_banned"), null;
                    let i = "invalid_code" === a ? "That code didn't work. Check it, or send a new one." : "rate_limited" === a || "daily_limit" === a ? x : "captcha" === a ? w : "invalid_email" === a ? v : "network" === a ? g : "We couldn't send a code on WhatsApp right now. Try again in a bit, or use another way to sign in.";
                    return el(i), i
                }
                async function eL(e, t = X) {
                    let n = e ? et : (0, d.tm)(H, t);
                    if (!n) return void el(v);
                    er(!0), el(null);
                    let a = await
                    function() {
                        em(!0), z ? .();
                        let e = e => (e && window.setTimeout(() => eb.current ? .reset(), 0), e);
                        if (ey.current) {
                            let t = ey.current;
                            return ey.current = null, Promise.resolve(e(t))
                        }
                        return ew(!0), new Promise(t => {
                            let n = n => {
                                    window.clearTimeout(a), ew(!1), t(e(n))
                                },
                                a = window.setTimeout(() => {
                                    e_.current === n && (e_.current = null), ew(!1), t(null)
                                }, 2e4);
                            e_.current = n
                        })
                    }();
                    if (er(!1), !a) {
                        eA("auth_otp_failed", {
                            stage: "code_send",
                            code: "captcha",
                            flow: "code_send".startsWith("code") ? "code" : "inbound"
                        }), el(w), !e && R && R(w);
                        return
                    }
                    let i = Date.now();
                    en(n), eu(i), ep(i), ei(""), G("code");
                    try {
                        let t = await fetch("/api/auth/whatsapp/send-code", {
                            method: "POST",
                            headers: {
                                "content-type": "application/json"
                            },
                            credentials: "same-origin",
                            body: JSON.stringify({
                                phone: n,
                                captchaToken: a
                            })
                        });
                        if (!t.ok) {
                            let e = await t.json().catch(() => null);
                            throw {
                                status: t.status,
                                code: e ? .error ? .code ? ? "",
                                message: e ? .error ? .message ? ? ""
                            }
                        }(0, l.yR)({
                            chunks: !E
                        }), eW().catch(() => {}), N({
                            flow: "code",
                            phone: n,
                            sentAt: i
                        }), eA("auth_otp_requested", {
                            flow: "code",
                            resend: e
                        })
                    } catch (a) {
                        if (a ? .code === "code_recently_sent" || S(a) === d.dP.cooldown) {
                            eA("auth_otp_failed", {
                                stage: "send",
                                code: "recently_sent",
                                flow: "code"
                            }), e ? eu(ec) : N({
                                flow: "code",
                                phone: n,
                                sentAt: i
                            }), el(e ? "You can get a new code in a minute. Please enter the last one we sent." : "We just sent a code to this number on WhatsApp. Enter it below.");
                            return
                        }
                        let t = eD(a, "send");
                        if (L && !e && t !== v) return;
                        e ? eu(ec) : (eu(null), G("phone")), !e && t && R && R(t)
                    }
                }
                async function eO() {
                    let e = J;
                    for (let t = 0; t < 2; t += 1) try {
                        let t = await fetch("/api/auth/complete", {
                            method: "POST",
                            headers: {
                                "content-type": "application/json"
                            },
                            credentials: "same-origin",
                            keepalive: !0,
                            body: JSON.stringify({
                                next: J,
                                authMethod: "whatsapp"
                            })
                        });
                        if (t.ok) {
                            let n = await t.json();
                            e = (0, c.u)(n.data ? .location ? ? J);
                            break
                        }
                        if (t.status < 500 && 429 !== t.status) break
                    } catch {}
                    return e
                }
                async function eR(e) {
                    if (6 !== e.length || es) return;
                    er(!0), el(null), j ? .();
                    let t = null;
                    try {
                        let {
                            data: n,
                            error: a
                        } = await (await eW()).auth.verifyOtp({
                            phone: et,
                            token: e,
                            type: "sms"
                        });
                        if (a) throw a;
                        t = n.user, eA("auth_otp_verified", {
                            flow: "code"
                        })
                    } catch (e) {
                        eD(e, "verify"), ei(""), er(!1), $ ? .(), ev.current ? .focus();
                        return
                    }
                    if (N(null), (0, u.Sm)(!0), E) {
                        eO(), er(!1), E();
                        return
                    }
                    let n = (0, l.Ub)(J, t);
                    if (n) {
                        eO(), window.location.assign((0, l.ku)(n));
                        return
                    }
                    window.location.assign((0, l.ku)(await eO()))
                }(0, i.useEffect)(() => {
                    if ("inbound" !== q || !eE || Y) return;
                    let e = !1;
                    return n.e(56276).then(n.t.bind(n, 56276, 19)).then(e => e.default.toDataURL(eE, {
                        errorCorrectionLevel: "M",
                        margin: 1,
                        width: 360
                    })).then(t => {
                        e || Q(t)
                    }).catch(() => {}), () => {
                        e = !0
                    }
                }, [q, eE, Y]);
                let eM = ec ? Math.max(0, 60 - Math.floor((ed - ec) / 1e3)) : 0;

                function ez() {
                    N(null), G("idle"), B(null), ei(""), eu(null), el(null)
                }

                function eF() {
                    em(!0), N(null), B(null), el(null), G("phone")
                }(0, i.useEffect)(() => {
                    if ("code" !== q || eM <= 0) return;
                    let e = window.setInterval(() => ep(Date.now()), 1e3);
                    return () => window.clearInterval(e)
                }, [q, eM]), (0, i.useEffect)(() => {
                    "code" === q && ev.current ? .focus()
                }, [q]);
                let eI = "font-medium text-cp-primary underline-offset-2 hover:underline disabled:cursor-default disabled:text-cp-muted disabled:no-underline",
                    eJ = "h-12 w-full rounded-full border border-cp-line bg-cp-bg text-[15px] text-cp-ink transition-[border-color,box-shadow] duration-150 placeholder:text-cp-muted hover:border-cp-line-strong focus:border-cp-primary focus:shadow-[0_0_0_4px_color-mix(in_srgb,var(--cp-primary)_16%,transparent)] focus:outline-none disabled:opacity-60",
                    eU = "absolute top-1.5 right-1.5 inline-flex h-9 items-center gap-1.5 rounded-full bg-cp-primary px-4 text-[13px] font-medium text-white transition-colors duration-150 hover:bg-cp-primary-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select disabled:cursor-not-allowed disabled:opacity-60",
                    eY = F ? ? "flex h-12 w-full items-center justify-center gap-2.5 rounded-full border border-cp-line bg-cp-bg px-5 text-[14px] font-semibold text-cp-ink transition-colors duration-150 hover:border-cp-line-strong hover:bg-cp-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select disabled:cursor-wait disabled:opacity-70",
                    eq = O ? () => {
                        ez(), O()
                    } : ez,
                    eG = (0, a.jsx)("button", {
                        type: "button",
                        onClick: eq,
                        className: eI,
                        children: "Cancel"
                    });
                return (0, a.jsxs)("div", {
                    className: "w-full",
                    onFocusCapture: z,
                    onPointerDownCapture: z,
                    children: ["idle" === q || "starting" === q ? (0, a.jsxs)("button", {
                        type: "button",
                        onClick: () => I ? eF() : void eC(),
                        disabled: "starting" === q,
                        className: eY,
                        children: ["starting" === q ? (0, a.jsx)(s.A, {
                            className: "size-4 animate-spin",
                            strokeWidth: 2,
                            "aria-hidden": !0
                        }) : (0, a.jsx)(T, {}), "starting" === q ? "Opening WhatsApp\u2026" : "Continue with WhatsApp"]
                    }) : null, ("inbound" === q || "finishing" === q) && V ? (0, a.jsxs)("div", {
                        className: "rounded-2xl border border-cp-line bg-cp-bg p-4 text-center",
                        children: ["finishing" === q ? (0, a.jsxs)("p", {
                            className: "flex items-center justify-center gap-2 py-6 text-[14px] font-medium text-cp-ink",
                            children: [(0, a.jsx)(s.A, {
                                className: "size-4 animate-spin text-cp-primary",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            }), "Verified. Signing you in\u2026"]
                        }) : Y ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)("p", {
                                className: "text-[13px] leading-5 text-cp-muted",
                                children: "Tap send in WhatsApp, then come back here."
                            }), (0, a.jsx)("a", {
                                href: V.waLink,
                                className: (0, p.cn)(eI, "mt-1 inline-block text-[13px]"),
                                children: "Open WhatsApp again"
                            })]
                        }) : (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)("p", {
                                className: "text-[13px] leading-5 text-cp-muted",
                                children: "Scan with your phone's camera and send the message on WhatsApp."
                            }), (0, a.jsx)("div", {
                                className: "mx-auto mt-3 flex size-[168px] items-center justify-center rounded-xl border border-cp-line bg-white p-2",
                                children: Z ? (0, a.jsx)("img", {
                                    src: Z,
                                    alt: "QR code that opens WhatsApp with your sign-in code",
                                    className: "size-full"
                                }) : (0, a.jsx)(s.A, {
                                    className: "size-5 animate-spin text-cp-muted",
                                    strokeWidth: 2,
                                    "aria-hidden": !0
                                })
                            }), (0, a.jsx)("p", {
                                className: "mt-3 text-[12px] text-cp-muted",
                                children: "Or send this code to us on WhatsApp"
                            }), (0, a.jsx)("p", {
                                className: "font-mono text-[26px] font-semibold tracking-[0.08em] text-cp-ink",
                                children: V.code
                            }), (0, a.jsx)("a", {
                                href: V.waLink,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: (0, p.cn)(eI, "text-[12px]"),
                                children: "Open WhatsApp on this computer"
                            })]
                        }), "inbound" === q ? (0, a.jsxs)("p", {
                            className: "mt-3 flex items-center justify-center gap-1.5 text-[12px] text-cp-muted",
                            "aria-live": "polite",
                            children: [(0, a.jsx)(s.A, {
                                className: "size-3 animate-spin",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            }), "Waiting for your message\u2026"]
                        }) : null]
                    }) : null, "expired" === q ? (0, a.jsxs)("div", {
                        className: "rounded-2xl border border-cp-line bg-cp-bg p-4 text-center",
                        children: [(0, a.jsx)("p", {
                            className: "text-[13px] leading-5 text-cp-muted",
                            children: "That code has expired."
                        }), (0, a.jsxs)("button", {
                            type: "button",
                            onClick: () => void eC(),
                            className: (0, p.cn)(eY, "mt-3"),
                            children: [(0, a.jsx)(T, {}), "Get a new code"]
                        })]
                    }) : null, "phone" === q ? (0, a.jsxs)("form", {
                        onSubmit: e => {
                            e.preventDefault(), eL(!1)
                        },
                        noValidate: !0,
                        className: "relative",
                        children: [(0, a.jsx)("label", {
                            htmlFor: `wa-phone-${t}`,
                            className: "sr-only",
                            children: "WhatsApp number"
                        }), (0, a.jsx)("input", {
                            "aria-label": "Country code",
                            type: "tel",
                            inputMode: "tel",
                            autoComplete: "tel-country-code",
                            value: H,
                            onChange: e => {
                                K(`+${e.target.value.replace(/\D/g,"").slice(0,4)}`), eo && el(null)
                            },
                            disabled: es,
                            className: "absolute top-1/2 left-3 w-14 -translate-y-1/2 rounded-full bg-transparent px-2 py-1 text-center text-[15px] text-cp-muted focus:text-cp-ink focus-visible:outline-2 focus-visible:outline-cp-select disabled:opacity-60"
                        }), (0, a.jsx)("input", {
                            id: `wa-phone-${t}`,
                            type: "tel",
                            inputMode: "tel",
                            autoComplete: "tel-national",
                            placeholder: "WhatsApp number",
                            value: X,
                            onChange: e => {
                                ee(e.target.value), eo && el(null)
                            },
                            disabled: es,
                            autoFocus: !L,
                            className: (0, p.cn)(eJ, "pr-32 pl-18")
                        }), (0, a.jsxs)("button", {
                            type: "submit",
                            disabled: es,
                            className: eU,
                            children: [es ? (0, a.jsx)(s.A, {
                                className: "size-3.5 animate-spin",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            }) : null, es ? "Sending" : "Send code", es ? null : (0, a.jsx)(r.A, {
                                className: "size-3.5",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            })]
                        })]
                    }) : null, "code" === q ? (0, a.jsxs)("form", {
                        onSubmit: e => {
                            e.preventDefault(), eR(ea)
                        },
                        noValidate: !0,
                        children: [(0, a.jsxs)("p", {
                            className: "mb-2 text-[13px] leading-5 text-cp-muted",
                            children: ["Code sent on WhatsApp to ", (0, a.jsx)("span", {
                                className: "font-medium text-cp-ink",
                                children: et
                            }), " \xb7 ", (0, a.jsx)("button", {
                                type: "button",
                                onClick: O ? eq : eF,
                                className: eI,
                                children: "Change"
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "relative",
                            children: [(0, a.jsx)("label", {
                                htmlFor: `wa-code-${t}`,
                                className: "sr-only",
                                children: "6-digit code"
                            }), (0, a.jsx)("input", {
                                ref: ev,
                                id: `wa-code-${t}`,
                                type: "text",
                                inputMode: "numeric",
                                autoComplete: "one-time-code",
                                pattern: "[0-9]*",
                                placeholder: "000000",
                                value: ea,
                                onChange: e => {
                                    let t = e.target.value.replace(/\D/g, "").slice(0, 6);
                                    ei(t), eo && el(null), 6 === t.length && eR(t)
                                },
                                disabled: es,
                                className: (0, p.cn)(eJ, "pr-32 pl-5 font-mono text-[20px] font-semibold tracking-[0.4em] placeholder:tracking-[0.4em] placeholder:text-cp-line-strong")
                            }), (0, a.jsxs)("button", {
                                type: "submit",
                                disabled: es || 6 !== ea.length,
                                className: eU,
                                children: [es ? (0, a.jsx)(s.A, {
                                    className: "size-3.5 animate-spin",
                                    strokeWidth: 2,
                                    "aria-hidden": !0
                                }) : null, es ? "Checking" : "Continue"]
                            })]
                        }), (0, a.jsxs)("p", {
                            className: "mt-2 text-[12px] leading-5 text-cp-muted",
                            children: ["The code can take up to a minute to arrive on WhatsApp.", " ", eM > 0 ? (0, a.jsxs)("span", {
                                children: ["Resend in ", (0, a.jsxs)("span", {
                                    className: "font-medium text-cp-ink tabular-nums",
                                    children: ["0:", String(eM).padStart(2, "0")]
                                })]
                            }) : (0, a.jsx)("button", {
                                type: "button",
                                onClick: () => void eL(!0),
                                disabled: es,
                                className: eI,
                                children: "Resend the code"
                            })]
                        })]
                    }) : null, "idle" !== q && "starting" !== q ? (0, a.jsxs)("p", {
                        className: "mt-2 text-center text-[12px] leading-5 text-cp-muted",
                        children: ["inbound" === q ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)("button", {
                                type: "button",
                                onClick: eF,
                                className: eI,
                                children: "Send me a code instead"
                            }), " \xb7 "]
                        }) : null, I && ("phone" === q || "code" === q) ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)("button", {
                                type: "button",
                                onClick: () => void eC(),
                                className: eI,
                                children: "Message us on WhatsApp instead"
                            }), " \xb7 "]
                        }) : null, eG]
                    }) : null, M && eh && ("code" !== q || ef) ? (0, a.jsx)(h.$, {
                        ref: eb,
                        onToken: function(e) {
                            e && ex(!1);
                            let t = e_.current;
                            if (e && t) {
                                e_.current = null, t(e);
                                return
                            }
                            ey.current = e
                        },
                        onError: e => {
                            ex(!0);
                            let t = e_.current;
                            e_.current = null, t ? .(null), eA("auth_otp_failed", {
                                stage: "captcha_widget",
                                code: e ? ? "unknown"
                            })
                        },
                        className: "mt-2 flex justify-center empty:mt-0"
                    }) : null, eg ? (0, a.jsxs)("p", {
                        className: "mt-1.5 text-center text-[13px] leading-5 text-cp-muted",
                        children: ["The security check didn't go through.", " ", (0, a.jsx)("button", {
                            type: "button",
                            onClick: () => {
                                el(null), eb.current ? .reset()
                            },
                            className: eI,
                            children: "Try again"
                        }), "finishing" === q ? null : (0, a.jsxs)(a.Fragment, {
                            children: [", or ", eG]
                        })]
                    }) : null, (0, a.jsxs)("p", {
                        role: "status",
                        "aria-live": "polite",
                        className: "mt-1.5 min-h-5 text-center text-[13px] leading-5 text-cp-danger-ink empty:mt-0 empty:min-h-0",
                        children: [eo, eo && "finishing" === q ? (0, a.jsxs)(a.Fragment, {
                            children: [" ", (0, a.jsx)("button", {
                                type: "button",
                                onClick: () => void eT(),
                                className: eI,
                                children: "Try again"
                            })]
                        }) : null]
                    })]
                })
            }

            function T({
                className: e
            }) {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 24 24",
                    "aria-hidden": !0,
                    className: (0, p.cn)("size-5 shrink-0 fill-current text-cp-success", e),
                    children: (0, a.jsx)("path", {
                        d: "M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.7.63.71.22 1.36.19 1.87.12.57-.09 1.76-.72 2-1.41.25-.7.25-1.29.18-1.41-.07-.13-.27-.2-.57-.35M12.05 21.79h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88 2.64 0 5.12 1.03 6.99 2.9a9.82 9.82 0 0 1 2.89 6.99c0 5.45-4.43 9.88-9.88 9.88m8.41-18.3A11.81 11.81 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.68 1.45h.01c6.55 0 11.89-5.34 11.89-11.9 0-3.18-1.24-6.16-3.48-8.41"
                    })
                })
            }
        }
    }
]);