"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [72746], {
        95813: (e, n, t) => {
            t.d(n, {
                JeP: () => nF,
                fCn: () => l
            });
            var i = t(84910);

            function r() {
                let e = null,
                    n = !1,
                    t = null,
                    i = null;

                function r(n, a) {
                    i = e.requestAnimationFrame(r), t(n, a)
                }
                return {
                    start: function() {
                        !0 === n || null === t || null !== e && (i = e.requestAnimationFrame(r), n = !0)
                    },
                    stop: function() {
                        null !== e && e.cancelAnimationFrame(i), n = !1
                    },
                    setAnimationLoop: function(e) {
                        t = e
                    },
                    setContext: function(n) {
                        e = n
                    }
                }
            }

            function a(e) {
                let n = new WeakMap;
                return {
                    get: function(e) {
                        return e.isInterleavedBufferAttribute && (e = e.data), n.get(e)
                    },
                    remove: function(t) {
                        t.isInterleavedBufferAttribute && (t = t.data);
                        let i = n.get(t);
                        i && (e.deleteBuffer(i.buffer), n.delete(t))
                    },
                    update: function(t, i) {
                        if (t.isInterleavedBufferAttribute && (t = t.data), t.isGLBufferAttribute) {
                            let e = n.get(t);
                            (!e || e.version < t.version) && n.set(t, {
                                buffer: t.buffer,
                                type: t.type,
                                bytesPerElement: t.elementSize,
                                version: t.version
                            });
                            return
                        }
                        let r = n.get(t);
                        if (void 0 === r) n.set(t, function(n, t) {
                            let i, r = n.array,
                                a = n.usage,
                                o = r.byteLength,
                                l = e.createBuffer();
                            if (e.bindBuffer(t, l), e.bufferData(t, r, a), n.onUploadCallback(), r instanceof Float32Array) i = e.FLOAT;
                            else if ("u" > typeof Float16Array && r instanceof Float16Array) i = e.HALF_FLOAT;
                            else if (r instanceof Uint16Array) i = n.isFloat16BufferAttribute ? e.HALF_FLOAT : e.UNSIGNED_SHORT;
                            else if (r instanceof Int16Array) i = e.SHORT;
                            else if (r instanceof Uint32Array) i = e.UNSIGNED_INT;
                            else if (r instanceof Int32Array) i = e.INT;
                            else if (r instanceof Int8Array) i = e.BYTE;
                            else if (r instanceof Uint8Array) i = e.UNSIGNED_BYTE;
                            else if (r instanceof Uint8ClampedArray) i = e.UNSIGNED_BYTE;
                            else throw Error("THREE.WebGLAttributes: Unsupported buffer data format: " + r);
                            return {
                                buffer: l,
                                type: i,
                                bytesPerElement: r.BYTES_PER_ELEMENT,
                                version: n.version,
                                size: o
                            }
                        }(t, i));
                        else if (r.version < t.version) {
                            if (r.size !== t.array.byteLength) throw Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");
                            ! function(n, t, i) {
                                let r = t.array,
                                    a = t.updateRanges;
                                if (e.bindBuffer(i, n), 0 === a.length) e.bufferSubData(i, 0, r);
                                else {
                                    a.sort((e, n) => e.start - n.start);
                                    let n = 0;
                                    for (let e = 1; e < a.length; e++) {
                                        let t = a[n],
                                            i = a[e];
                                        i.start <= t.start + t.count + 1 ? t.count = Math.max(t.count, i.start + i.count - t.start) : a[++n] = i
                                    }
                                    a.length = n + 1;
                                    for (let n = 0, t = a.length; n < t; n++) {
                                        let t = a[n];
                                        e.bufferSubData(i, t.start * r.BYTES_PER_ELEMENT, r, t.start, t.count)
                                    }
                                    t.clearUpdateRanges()
                                }
                                t.onUploadCallback()
                            }(r.buffer, t, i), r.version = t.version
                        }
                    }
                }
            }
            let o = {
                    alphahash_fragment: "#ifdef USE_ALPHAHASH\n	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;\n#endif",
                    alphahash_pars_fragment: "#ifdef USE_ALPHAHASH\n	const float ALPHA_HASH_SCALE = 0.05;\n	float hash2D( vec2 value ) {\n		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );\n	}\n	float hash3D( vec3 value ) {\n		return hash2D( vec2( hash2D( value.xy ), value.z ) );\n	}\n	float getAlphaHashThreshold( vec3 position ) {\n		float maxDeriv = max(\n			length( dFdx( position.xyz ) ),\n			length( dFdy( position.xyz ) )\n		);\n		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );\n		vec2 pixScales = vec2(\n			exp2( floor( log2( pixScale ) ) ),\n			exp2( ceil( log2( pixScale ) ) )\n		);\n		vec2 alpha = vec2(\n			hash3D( floor( pixScales.x * position.xyz ) ),\n			hash3D( floor( pixScales.y * position.xyz ) )\n		);\n		float lerpFactor = fract( log2( pixScale ) );\n		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;\n		float a = min( lerpFactor, 1.0 - lerpFactor );\n		vec3 cases = vec3(\n			x * x / ( 2.0 * a * ( 1.0 - a ) ),\n			( x - 0.5 * a ) / ( 1.0 - a ),\n			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )\n		);\n		float threshold = ( x < ( 1.0 - a ) )\n			? ( ( x < a ) ? cases.x : cases.y )\n			: cases.z;\n		return clamp( threshold , 1.0e-6, 1.0 );\n	}\n#endif",
                    alphamap_fragment: "#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;\n#endif",
                    alphamap_pars_fragment: "#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif",
                    alphatest_fragment: "#ifdef USE_ALPHATEST\n	#ifdef ALPHA_TO_COVERAGE\n	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );\n	if ( diffuseColor.a == 0.0 ) discard;\n	#else\n	if ( diffuseColor.a < alphaTest ) discard;\n	#endif\n#endif",
                    alphatest_pars_fragment: "#ifdef USE_ALPHATEST\n	uniform float alphaTest;\n#endif",
                    aomap_fragment: "#ifdef USE_AOMAP\n	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;\n	reflectedLight.indirectDiffuse *= ambientOcclusion;\n	#if defined( USE_CLEARCOAT ) \n		clearcoatSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_SHEEN ) \n		sheenSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( STANDARD )\n		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );\n		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );\n	#endif\n#endif",
                    aomap_pars_fragment: "#ifdef USE_AOMAP\n	uniform sampler2D aoMap;\n	uniform float aoMapIntensity;\n#endif",
                    batching_pars_vertex: "#ifdef USE_BATCHING\n	#if ! defined( GL_ANGLE_multi_draw )\n	#define gl_DrawID _gl_DrawID\n	uniform int _gl_DrawID;\n	#endif\n	uniform highp sampler2D batchingTexture;\n	uniform highp usampler2D batchingIdTexture;\n	mat4 getBatchingMatrix( const in float i ) {\n		int size = textureSize( batchingTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n	float getIndirectIndex( const in int i ) {\n		int size = textureSize( batchingIdTexture, 0 ).x;\n		int x = i % size;\n		int y = i / size;\n		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );\n	}\n#endif\n#ifdef USE_BATCHING_COLOR\n	uniform sampler2D batchingColorTexture;\n	vec4 getBatchingColor( const in float i ) {\n		int size = textureSize( batchingColorTexture, 0 ).x;\n		int j = int( i );\n		int x = j % size;\n		int y = j / size;\n		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );\n	}\n#endif",
                    batching_vertex: "#ifdef USE_BATCHING\n	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );\n#endif",
                    begin_vertex: "vec3 transformed = vec3( position );\n#ifdef USE_ALPHAHASH\n	vPosition = vec3( position );\n#endif",
                    beginnormal_vertex: "vec3 objectNormal = vec3( normal );\n#ifdef USE_TANGENT\n	vec3 objectTangent = vec3( tangent.xyz );\n#endif",
                    bsdfs: "float G_BlinnPhong_Implicit( ) {\n	return 0.25;\n}\nfloat D_BlinnPhong( const in float shininess, const in float dotNH ) {\n	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );\n}\nvec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( specularColor, 1.0, dotVH );\n	float G = G_BlinnPhong_Implicit( );\n	float D = D_BlinnPhong( shininess, dotNH );\n	return F * ( G * D );\n} // validated",
                    iridescence_fragment: "#ifdef USE_IRIDESCENCE\n	const mat3 XYZ_TO_REC709 = mat3(\n		 3.2404542, -0.9692660,  0.0556434,\n		-1.5371385,  1.8760108, -0.2040259,\n		-0.4985314,  0.0415560,  1.0572252\n	);\n	vec3 Fresnel0ToIor( vec3 fresnel0 ) {\n		vec3 sqrtF0 = sqrt( fresnel0 );\n		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );\n	}\n	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );\n	}\n	float IorToFresnel0( float transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));\n	}\n	vec3 evalSensitivity( float OPD, vec3 shift ) {\n		float phase = 2.0 * PI * OPD * 1.0e-9;\n		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );\n		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );\n		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );\n		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );\n		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );\n		xyz /= 1.0685e-7;\n		vec3 rgb = XYZ_TO_REC709 * xyz;\n		return rgb;\n	}\n	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {\n		vec3 I;\n		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );\n		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );\n		float cosTheta2Sq = 1.0 - sinTheta2Sq;\n		if ( cosTheta2Sq < 0.0 ) {\n			return vec3( 1.0 );\n		}\n		float cosTheta2 = sqrt( cosTheta2Sq );\n		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );\n		float R12 = F_Schlick( R0, 1.0, cosTheta1 );\n		float T121 = 1.0 - R12;\n		float phi12 = 0.0;\n		if ( iridescenceIOR < outsideIOR ) phi12 = PI;\n		float phi21 = PI - phi12;\n		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );\n		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );\n		vec3 phi23 = vec3( 0.0 );\n		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;\n		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;\n		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;\n		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;\n		vec3 phi = vec3( phi21 ) + phi23;\n		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );\n		vec3 r123 = sqrt( R123 );\n		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );\n		vec3 C0 = R12 + Rs;\n		I = C0;\n		vec3 Cm = Rs - T121;\n		for ( int m = 1; m <= 2; ++ m ) {\n			Cm *= r123;\n			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );\n			I += Cm * Sm;\n		}\n		return max( I, vec3( 0.0 ) );\n	}\n#endif",
                    bumpmap_pars_fragment: "#ifdef USE_BUMPMAP\n	uniform sampler2D bumpMap;\n	uniform float bumpScale;\n	vec2 dHdxy_fwd() {\n		vec2 dSTdx = dFdx( vBumpMapUv );\n		vec2 dSTdy = dFdy( vBumpMapUv );\n		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;\n		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;\n		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;\n		return vec2( dBx, dBy );\n	}\n	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {\n		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );\n		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );\n		vec3 vN = surf_norm;\n		vec3 R1 = cross( vSigmaY, vN );\n		vec3 R2 = cross( vN, vSigmaX );\n		float fDet = dot( vSigmaX, R1 ) * faceDirection;\n		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );\n		return normalize( abs( fDet ) * surf_norm - vGrad );\n	}\n#endif",
                    clipping_planes_fragment: "#if NUM_CLIPPING_PLANES > 0\n	vec4 plane;\n	#ifdef ALPHA_TO_COVERAGE\n		float distanceToPlane, distanceGradient;\n		float clipOpacity = 1.0;\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n			distanceGradient = fwidth( distanceToPlane ) / 2.0;\n			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			if ( clipOpacity == 0.0 ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			float unionClipOpacity = 1.0;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n				distanceGradient = fwidth( distanceToPlane ) / 2.0;\n				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			}\n			#pragma unroll_loop_end\n			clipOpacity *= 1.0 - unionClipOpacity;\n		#endif\n		diffuseColor.a *= clipOpacity;\n		if ( diffuseColor.a == 0.0 ) discard;\n	#else\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			bool clipped = true;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;\n			}\n			#pragma unroll_loop_end\n			if ( clipped ) discard;\n		#endif\n	#endif\n#endif",
                    clipping_planes_pars_fragment: "#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];\n#endif",
                    clipping_planes_pars_vertex: "#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n#endif",
                    clipping_planes_vertex: "#if NUM_CLIPPING_PLANES > 0\n	vClipPosition = - mvPosition.xyz;\n#endif",
                    color_fragment: "#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )\n	diffuseColor *= vColor;\n#endif",
                    color_pars_fragment: "#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )\n	varying vec4 vColor;\n#endif",
                    color_pars_vertex: "#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	varying vec4 vColor;\n#endif",
                    color_vertex: "#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	vColor = vec4( 1.0 );\n#endif\n#ifdef USE_COLOR_ALPHA\n	vColor *= color;\n#elif defined( USE_COLOR )\n	vColor.rgb *= color;\n#endif\n#ifdef USE_INSTANCING_COLOR\n	vColor.rgb *= instanceColor.rgb;\n#endif\n#ifdef USE_BATCHING_COLOR\n	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );\n#endif",
                    common: "#define PI 3.141592653589793\n#define PI2 6.283185307179586\n#define PI_HALF 1.5707963267948966\n#define RECIPROCAL_PI 0.3183098861837907\n#define RECIPROCAL_PI2 0.15915494309189535\n#define EPSILON 1e-6\n#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\n#define whiteComplement( a ) ( 1.0 - saturate( a ) )\nfloat pow2( const in float x ) { return x*x; }\nvec3 pow2( const in vec3 x ) { return x*x; }\nfloat pow3( const in float x ) { return x*x*x; }\nfloat pow4( const in float x ) { float x2 = x*x; return x2*x2; }\nfloat max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }\nfloat average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }\nhighp float rand( const in vec2 uv ) {\n	const highp float a = 12.9898, b = 78.233, c = 43758.5453;\n	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );\n	return fract( sin( sn ) * c );\n}\n#ifdef HIGH_PRECISION\n	float precisionSafeLength( vec3 v ) { return length( v ); }\n#else\n	float precisionSafeLength( vec3 v ) {\n		float maxComponent = max3( abs( v ) );\n		return length( v / maxComponent ) * maxComponent;\n	}\n#endif\nstruct IncidentLight {\n	vec3 color;\n	vec3 direction;\n	bool visible;\n};\nstruct ReflectedLight {\n	vec3 directDiffuse;\n	vec3 directSpecular;\n	vec3 indirectDiffuse;\n	vec3 indirectSpecular;\n};\n#ifdef USE_ALPHAHASH\n	varying vec3 vPosition;\n#endif\nvec3 transformDirection( in vec3 dir, in mat4 matrix ) {\n	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );\n}\n#define inverseTransformDirection transformDirectionByInverseViewMatrix\nvec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {\n	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );\n}\nvec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {\n	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );\n}\nbool isPerspectiveMatrix( mat4 m ) {\n	return m[ 2 ][ 3 ] == - 1.0;\n}\nvec2 equirectUv( in vec3 dir ) {\n	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;\n	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;\n	return vec2( u, v );\n}\nvec3 BRDF_Lambert( const in vec3 diffuseColor ) {\n	return RECIPROCAL_PI * diffuseColor;\n}\nvec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n}\nfloat F_Schlick( const in float f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n} // validated",
                    cube_uv_reflection_fragment: "#ifdef ENVMAP_TYPE_CUBE_UV\n	#define cubeUV_minMipLevel 4.0\n	#define cubeUV_minTileSize 16.0\n	float getFace( vec3 direction ) {\n		vec3 absDirection = abs( direction );\n		float face = - 1.0;\n		if ( absDirection.x > absDirection.z ) {\n			if ( absDirection.x > absDirection.y )\n				face = direction.x > 0.0 ? 0.0 : 3.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		} else {\n			if ( absDirection.z > absDirection.y )\n				face = direction.z > 0.0 ? 2.0 : 5.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		}\n		return face;\n	}\n	vec2 getUV( vec3 direction, float face ) {\n		vec2 uv;\n		if ( face == 0.0 ) {\n			uv = vec2( direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 1.0 ) {\n			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );\n		} else if ( face == 2.0 ) {\n			uv = vec2( - direction.x, direction.y ) / abs( direction.z );\n		} else if ( face == 3.0 ) {\n			uv = vec2( - direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 4.0 ) {\n			uv = vec2( - direction.x, direction.z ) / abs( direction.y );\n		} else {\n			uv = vec2( direction.x, direction.y ) / abs( direction.z );\n		}\n		return 0.5 * ( uv + 1.0 );\n	}\n	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {\n		float face = getFace( direction );\n		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );\n		mipInt = max( mipInt, cubeUV_minMipLevel );\n		float faceSize = exp2( mipInt );\n		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;\n		if ( face > 2.0 ) {\n			uv.y += faceSize;\n			face -= 3.0;\n		}\n		uv.x += face * faceSize;\n		uv.x += filterInt * 3.0 * cubeUV_minTileSize;\n		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );\n		uv.x *= CUBEUV_TEXEL_WIDTH;\n		uv.y *= CUBEUV_TEXEL_HEIGHT;\n		#ifdef texture2DGradEXT\n			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;\n		#else\n			return texture2D( envMap, uv ).rgb;\n		#endif\n	}\n	#define cubeUV_r0 1.0\n	#define cubeUV_m0 - 2.0\n	#define cubeUV_r1 0.8\n	#define cubeUV_m1 - 1.0\n	#define cubeUV_r4 0.4\n	#define cubeUV_m4 2.0\n	#define cubeUV_r5 0.305\n	#define cubeUV_m5 3.0\n	#define cubeUV_r6 0.21\n	#define cubeUV_m6 4.0\n	float roughnessToMip( float roughness ) {\n		float mip = 0.0;\n		if ( roughness >= cubeUV_r1 ) {\n			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;\n		} else if ( roughness >= cubeUV_r4 ) {\n			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;\n		} else if ( roughness >= cubeUV_r5 ) {\n			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;\n		} else if ( roughness >= cubeUV_r6 ) {\n			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;\n		} else {\n			mip = - 2.0 * log2( 1.16 * roughness );		}\n		return mip;\n	}\n	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {\n		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );\n		float mipF = fract( mip );\n		float mipInt = floor( mip );\n		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );\n		if ( mipF == 0.0 ) {\n			return vec4( color0, 1.0 );\n		} else {\n			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );\n			return vec4( mix( color0, color1, mipF ), 1.0 );\n		}\n	}\n#endif",
                    defaultnormal_vertex: "vec3 transformedNormal = objectNormal;\n#ifdef USE_TANGENT\n	vec3 transformedTangent = objectTangent;\n#endif\n#ifdef USE_BATCHING\n	mat3 bm = mat3( batchingMatrix );\n	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );\n	transformedNormal = bm * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = bm * transformedTangent;\n	#endif\n#endif\n#ifdef USE_INSTANCING\n	mat3 im = mat3( instanceMatrix );\n	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );\n	transformedNormal = im * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = im * transformedTangent;\n	#endif\n#endif\ntransformedNormal = normalMatrix * transformedNormal;\n#ifdef FLIP_SIDED\n	transformedNormal = - transformedNormal;\n#endif\n#ifdef USE_TANGENT\n	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;\n#endif",
                    displacementmap_pars_vertex: "#ifdef USE_DISPLACEMENTMAP\n	uniform sampler2D displacementMap;\n	uniform float displacementScale;\n	uniform float displacementBias;\n#endif",
                    displacementmap_vertex: "#ifdef USE_DISPLACEMENTMAP\n	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );\n#endif",
                    emissivemap_fragment: "#ifdef USE_EMISSIVEMAP\n	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE\n		emissiveColor = sRGBTransferEOTF( emissiveColor );\n	#endif\n	totalEmissiveRadiance *= emissiveColor.rgb;\n#endif",
                    emissivemap_pars_fragment: "#ifdef USE_EMISSIVEMAP\n	uniform sampler2D emissiveMap;\n#endif",
                    colorspace_fragment: "gl_FragColor = linearToOutputTexel( gl_FragColor );",
                    colorspace_pars_fragment: "vec4 LinearTransferOETF( in vec4 value ) {\n	return value;\n}\nvec4 sRGBTransferEOTF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );\n}\nvec4 sRGBTransferOETF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );\n}",
                    envmap_fragment: "#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vec3 cameraToFrag;\n		if ( isOrthographic ) {\n			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToFrag = normalize( vWorldPosition - cameraPosition );\n		}\n		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vec3 reflectVec = reflect( cameraToFrag, worldNormal );\n		#else\n			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );\n		#endif\n	#else\n		vec3 reflectVec = vReflect;\n	#endif\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );\n		#ifdef ENVMAP_BLENDING_MULTIPLY\n			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );\n		#elif defined( ENVMAP_BLENDING_MIX )\n			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );\n		#elif defined( ENVMAP_BLENDING_ADD )\n			outgoingLight += envColor.xyz * specularStrength * reflectivity;\n		#endif\n	#endif\n#endif",
                    envmap_common_pars_fragment: "#ifdef USE_ENVMAP\n	uniform float envMapIntensity;\n	uniform mat3 envMapRotation;\n	#ifdef ENVMAP_TYPE_CUBE\n		uniform samplerCube envMap;\n	#else\n		uniform sampler2D envMap;\n	#endif\n#endif",
                    envmap_pars_fragment: "#ifdef USE_ENVMAP\n	uniform float reflectivity;\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		varying vec3 vWorldPosition;\n		uniform float refractionRatio;\n	#else\n		varying vec3 vReflect;\n	#endif\n#endif",
                    envmap_pars_vertex: "#ifdef USE_ENVMAP\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		\n		varying vec3 vWorldPosition;\n	#else\n		varying vec3 vReflect;\n		uniform float refractionRatio;\n	#endif\n#endif",
                    envmap_physical_pars_fragment: "#ifdef USE_ENVMAP\n	vec3 getIBLIrradiance( const in vec3 normal ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );\n			return PI * envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 reflectVec = reflect( - viewDir, normal );\n			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );\n			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );\n			return envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	#ifdef USE_RETROREFLECTION\n		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {\n			#ifdef ENVMAP_TYPE_CUBE_UV\n				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );\n				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );\n				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );\n				return envMapColor.rgb * envMapIntensity;\n			#else\n				return vec3( 0.0 );\n			#endif\n		}\n	#endif\n	#ifdef USE_ANISOTROPY\n		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {\n			#ifdef ENVMAP_TYPE_CUBE_UV\n				vec3 bentNormal = cross( bitangent, viewDir );\n				bentNormal = normalize( cross( bentNormal, bitangent ) );\n				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );\n				return getIBLRadiance( viewDir, bentNormal, roughness );\n			#else\n				return vec3( 0.0 );\n			#endif\n		}\n		#ifdef USE_RETROREFLECTION\n			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {\n				#ifdef ENVMAP_TYPE_CUBE_UV\n					vec3 bentNormal = cross( bitangent, viewDir );\n					bentNormal = normalize( cross( bentNormal, bitangent ) );\n					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );\n					return getIBLRetroRadiance( viewDir, bentNormal, roughness );\n				#else\n					return vec3( 0.0 );\n				#endif\n			}\n		#endif\n	#endif\n#endif",
                    envmap_vertex: "#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vWorldPosition = worldPosition.xyz;\n	#else\n		vec3 cameraToVertex;\n		if ( isOrthographic ) {\n			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );\n		}\n		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vReflect = reflect( cameraToVertex, worldNormal );\n		#else\n			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );\n		#endif\n	#endif\n#endif",
                    fog_vertex: "#ifdef USE_FOG\n	vFogDepth = - mvPosition.z;\n#endif",
                    fog_pars_vertex: "#ifdef USE_FOG\n	varying float vFogDepth;\n#endif",
                    fog_fragment: "#ifdef USE_FOG\n	#ifdef FOG_EXP2\n		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );\n	#else\n		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );\n	#endif\n	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );\n#endif",
                    fog_pars_fragment: "#ifdef USE_FOG\n	uniform vec3 fogColor;\n	varying float vFogDepth;\n	#ifdef FOG_EXP2\n		uniform float fogDensity;\n	#else\n		uniform float fogNear;\n		uniform float fogFar;\n	#endif\n#endif",
                    gradientmap_pars_fragment: "#ifdef USE_GRADIENTMAP\n	uniform sampler2D gradientMap;\n#endif\nvec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {\n	float dotNL = dot( normal, lightDirection );\n	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );\n	#ifdef USE_GRADIENTMAP\n		return vec3( texture2D( gradientMap, coord ).r );\n	#else\n		vec2 fw = fwidth( coord ) * 0.5;\n		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );\n	#endif\n}",
                    lightmap_pars_fragment: "#ifdef USE_LIGHTMAP\n	uniform sampler2D lightMap;\n	uniform float lightMapIntensity;\n#endif",
                    lights_lambert_fragment: "LambertMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularStrength = specularStrength;",
                    lights_lambert_pars_fragment: "varying vec3 vViewPosition;\nstruct LambertMaterial {\n	vec3 diffuseColor;\n	float specularStrength;\n};\nvoid RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Lambert\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert",
                    lights_pars_begin: "uniform bool receiveShadow;\nuniform vec3 ambientLightColor;\n#if defined( USE_LIGHT_PROBES )\n	uniform vec3 lightProbe[ 9 ];\n#endif\nvec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {\n	float x = normal.x, y = normal.y, z = normal.z;\n	vec3 result = shCoefficients[ 0 ] * 0.886227;\n	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;\n	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;\n	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;\n	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;\n	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;\n	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );\n	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;\n	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );\n	return result;\n}\nvec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {\n	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );\n	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );\n	return irradiance;\n}\nvec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {\n	vec3 irradiance = ambientLightColor;\n	return irradiance;\n}\nfloat getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {\n	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );\n	if ( cutoffDistance > 0.0 ) {\n		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );\n	}\n	return distanceFalloff;\n}\nfloat getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {\n	return smoothstep( coneCosine, penumbraCosine, angleCosine );\n}\n#if NUM_SUN_LIGHTS > 0\n	struct SunLight {\n		vec3 direction;\n		vec3 color;\n	};\n	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];\n	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {\n		light.color = sunLight.color;\n		light.direction = sunLight.direction;\n		light.visible = true;\n	}\n#endif\n#if NUM_DIR_LIGHTS > 0\n	struct DirectionalLight {\n		vec3 direction;\n		vec3 color;\n	};\n	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];\n	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {\n		light.color = directionalLight.color;\n		light.direction = directionalLight.direction;\n		light.visible = true;\n	}\n#endif\n#if NUM_POINT_LIGHTS > 0\n	struct PointLight {\n		vec3 position;\n		vec3 color;\n		float distance;\n		float decay;\n	};\n	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];\n	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = pointLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float lightDistance = length( lVector );\n		light.color = pointLight.color;\n		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );\n		light.visible = ( light.color != vec3( 0.0 ) );\n	}\n#endif\n#if NUM_SPOT_LIGHTS > 0\n	struct SpotLight {\n		vec3 position;\n		vec3 direction;\n		vec3 color;\n		float distance;\n		float decay;\n		float coneCos;\n		float penumbraCos;\n	};\n	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];\n	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = spotLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float angleCos = dot( light.direction, spotLight.direction );\n		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );\n		if ( spotAttenuation > 0.0 ) {\n			float lightDistance = length( lVector );\n			light.color = spotLight.color * spotAttenuation;\n			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );\n			light.visible = ( light.color != vec3( 0.0 ) );\n		} else {\n			light.color = vec3( 0.0 );\n			light.visible = false;\n		}\n	}\n#endif\n#if NUM_RECT_AREA_LIGHTS > 0\n	struct RectAreaLight {\n		vec3 color;\n		vec3 position;\n		vec3 halfWidth;\n		vec3 halfHeight;\n	};\n	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;\n	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];\n#endif\n#if NUM_HEMI_LIGHTS > 0\n	struct HemisphereLight {\n		vec3 direction;\n		vec3 skyColor;\n		vec3 groundColor;\n	};\n	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];\n	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {\n		float dotNL = dot( normal, hemiLight.direction );\n		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;\n		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );\n		return irradiance;\n	}\n#endif\n#include <lightprobes_pars_fragment>",
                    lights_toon_fragment: "ToonMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;",
                    lights_toon_pars_fragment: "varying vec3 vViewPosition;\nstruct ToonMaterial {\n	vec3 diffuseColor;\n};\nvoid RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Toon\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon",
                    lights_phong_fragment: "BlinnPhongMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularColor = specular;\nmaterial.specularShininess = shininess;\nmaterial.specularStrength = specularStrength;",
                    lights_phong_pars_fragment: "varying vec3 vViewPosition;\nstruct BlinnPhongMaterial {\n	vec3 diffuseColor;\n	vec3 specularColor;\n	float specularShininess;\n	float specularStrength;\n};\nvoid RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;\n}\nvoid RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_BlinnPhong\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong",
                    lights_physical_fragment: "PhysicalMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );\nmaterial.metalness = metalnessFactor;\nvec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );\nfloat geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );\nmaterial.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;\nmaterial.roughness = min( material.roughness, 1.0 );\n#ifdef IOR\n	material.ior = ior;\n	#ifdef USE_SPECULAR\n		float specularIntensityFactor = specularIntensity;\n		vec3 specularColorFactor = specularColor;\n		#ifdef USE_SPECULAR_COLORMAP\n			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;\n		#endif\n		#ifdef USE_SPECULAR_INTENSITYMAP\n			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;\n		#endif\n		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );\n	#else\n		float specularIntensityFactor = 1.0;\n		vec3 specularColorFactor = vec3( 1.0 );\n		material.specularF90 = 1.0;\n	#endif\n	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;\n	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );\n#else\n	material.specularColor = vec3( 0.04 );\n	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );\n	material.specularF90 = 1.0;\n#endif\n#ifdef USE_CLEARCOAT\n	material.clearcoat = clearcoat;\n	material.clearcoatRoughness = clearcoatRoughness;\n	material.clearcoatF0 = vec3( 0.04 );\n	material.clearcoatF90 = 1.0;\n	#ifdef USE_CLEARCOATMAP\n		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;\n	#endif\n	#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;\n	#endif\n	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );\n	material.clearcoatRoughness += geometryRoughness;\n	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );\n#endif\n#ifdef USE_DISPERSION\n	material.dispersion = dispersion;\n#endif\n#ifdef USE_RETROREFLECTION\n	material.retroreflectivity = retroreflectivity;\n#endif\n#ifdef USE_IRIDESCENCE\n	material.iridescence = iridescence;\n	material.iridescenceIOR = iridescenceIOR;\n	#ifdef USE_IRIDESCENCEMAP\n		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;\n	#endif\n	#ifdef USE_IRIDESCENCE_THICKNESSMAP\n		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;\n	#else\n		material.iridescenceThickness = iridescenceThicknessMaximum;\n	#endif\n#endif\n#ifdef USE_SHEEN\n	material.sheenColor = sheenColor;\n	#ifdef USE_SHEEN_COLORMAP\n		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;\n	#endif\n	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	#ifdef USE_ANISOTROPYMAP\n		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );\n		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;\n		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;\n	#else\n		vec2 anisotropyV = anisotropyVector;\n	#endif\n	material.anisotropy = length( anisotropyV );\n	if( material.anisotropy == 0.0 ) {\n		anisotropyV = vec2( 1.0, 0.0 );\n	} else {\n		anisotropyV /= material.anisotropy;\n		material.anisotropy = saturate( material.anisotropy );\n	}\n	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );\n	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;\n	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;\n#endif",
                    lights_physical_pars_fragment: "uniform sampler2D dfgLUT;\nstruct PhysicalMaterial {\n	vec3 diffuseColor;\n	vec3 diffuseContribution;\n	vec3 specularColor;\n	vec3 specularColorBlended;\n	float roughness;\n	float metalness;\n	float specularF90;\n	float dispersion;\n	vec2 dfg;\n	vec3 multiScatteringCompensation;\n	#ifdef USE_RETROREFLECTION\n		float retroreflectivity;\n	#endif\n	#ifdef USE_CLEARCOAT\n		float clearcoat;\n		float clearcoatRoughness;\n		vec3 clearcoatF0;\n		float clearcoatF90;\n	#endif\n	#ifdef USE_IRIDESCENCE\n		float iridescence;\n		float iridescenceIOR;\n		float iridescenceThickness;\n		vec3 iridescenceFresnel;\n		vec3 iridescenceF0Dielectric;\n		vec3 iridescenceF0Metallic;\n	#endif\n	#ifdef USE_SHEEN\n		vec3 sheenColor;\n		float sheenRoughness;\n	#endif\n	#ifdef IOR\n		float ior;\n	#endif\n	#ifdef USE_TRANSMISSION\n		float transmission;\n		float transmissionAlpha;\n		float thickness;\n		float attenuationDistance;\n		vec3 attenuationColor;\n	#endif\n	#ifdef USE_ANISOTROPY\n		float anisotropy;\n		float alphaT;\n		vec3 anisotropyT;\n		vec3 anisotropyB;\n	#endif\n};\nvec3 clearcoatSpecularDirect = vec3( 0.0 );\nvec3 clearcoatSpecularIndirect = vec3( 0.0 );\nvec3 sheenSpecularDirect = vec3( 0.0 );\nvec3 sheenSpecularIndirect = vec3(0.0 );\nvec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {\n    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );\n    float x2 = x * x;\n    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );\n    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );\n}\nfloat V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {\n	float a2 = pow2( alpha );\n	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );\n	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );\n	return 0.5 / max( gv + gl, EPSILON );\n}\nfloat D_GGX( const in float alpha, const in float dotNH ) {\n	float a2 = pow2( alpha );\n	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;\n	return RECIPROCAL_PI * a2 / pow2( denom );\n}\n#ifdef USE_ANISOTROPY\n	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {\n		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );\n		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );\n		return 0.5 / max( gv + gl, EPSILON );\n	}\n	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {\n		float a2 = alphaT * alphaB;\n		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );\n		highp float v2 = dot( v, v );\n		float w2 = a2 / v2;\n		return RECIPROCAL_PI * a2 * pow2 ( w2 );\n	}\n#endif\n#ifdef USE_CLEARCOAT\n	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {\n		vec3 f0 = material.clearcoatF0;\n		float f90 = material.clearcoatF90;\n		float roughness = material.clearcoatRoughness;\n		float alpha = pow2( roughness );\n		vec3 halfDir = normalize( lightDir + viewDir );\n		float dotNL = saturate( dot( normal, lightDir ) );\n		float dotNV = saturate( dot( normal, viewDir ) );\n		float dotNH = saturate( dot( normal, halfDir ) );\n		float dotVH = saturate( dot( viewDir, halfDir ) );\n		vec3 F = F_Schlick( f0, f90, dotVH );\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n		return F * ( V * D );\n	}\n#endif\nvec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {\n	vec3 f0 = material.specularColorBlended;\n	float f90 = material.specularF90;\n	float roughness = material.roughness;\n	float alpha = pow2( roughness );\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( f0, f90, dotVH );\n	#ifdef USE_IRIDESCENCE\n		F = mix( F, material.iridescenceFresnel, material.iridescence );\n	#endif\n	#ifdef USE_ANISOTROPY\n		float dotTL = dot( material.anisotropyT, lightDir );\n		float dotTV = dot( material.anisotropyT, viewDir );\n		float dotTH = dot( material.anisotropyT, halfDir );\n		float dotBL = dot( material.anisotropyB, lightDir );\n		float dotBV = dot( material.anisotropyB, viewDir );\n		float dotBH = dot( material.anisotropyB, halfDir );\n		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );\n		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );\n	#else\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n	#endif\n	return F * ( V * D );\n}\nvec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {\n	const float LUT_SIZE = 64.0;\n	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;\n	const float LUT_BIAS = 0.5 / LUT_SIZE;\n	float dotNV = saturate( dot( N, V ) );\n	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );\n	uv = uv * LUT_SCALE + LUT_BIAS;\n	return uv;\n}\nfloat LTC_ClippedSphereFormFactor( const in vec3 f ) {\n	float l = length( f );\n	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );\n}\nvec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {\n	float x = dot( v1, v2 );\n	float y = abs( x );\n	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;\n	float b = 3.4175940 + ( 4.1616724 + y ) * y;\n	float v = a / b;\n	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;\n	return cross( v1, v2 ) * theta_sintheta;\n}\nvec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {\n	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];\n	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];\n	vec3 lightNormal = cross( v1, v2 );\n	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );\n	vec3 T1, T2;\n	T1 = normalize( V - N * dot( V, N ) );\n	T2 = - cross( N, T1 );\n	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );\n	vec3 coords[ 4 ];\n	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );\n	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );\n	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );\n	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );\n	coords[ 0 ] = normalize( coords[ 0 ] );\n	coords[ 1 ] = normalize( coords[ 1 ] );\n	coords[ 2 ] = normalize( coords[ 2 ] );\n	coords[ 3 ] = normalize( coords[ 3 ] );\n	vec3 vectorFormFactor = vec3( 0.0 );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );\n	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );\n	return vec3( result );\n}\n#if defined( USE_SHEEN )\nfloat D_Charlie( float roughness, float dotNH ) {\n	float alpha = pow2( roughness );\n	float invAlpha = 1.0 / alpha;\n	float cos2h = dotNH * dotNH;\n	float sin2h = max( 1.0 - cos2h, 0.0078125 );\n	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );\n}\nfloat V_Neubelt( float dotNV, float dotNL ) {\n	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );\n}\nvec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float D = D_Charlie( sheenRoughness, dotNH );\n	float V = V_Neubelt( dotNV, dotNL );\n	return sheenColor * ( D * V );\n}\n#endif\nfloat IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float r2 = roughness * roughness;\n	float rInv = 1.0 / ( roughness + 0.1 );\n	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;\n	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;\n	float DG = exp( a * dotNV + b );\n	return saturate( DG );\n}\nvec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;\n	return specularColor * fab.x + specularF90 * fab.y;\n}\n#ifdef USE_IRIDESCENCE\nvoid computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#else\nvoid computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#endif\n	#ifdef USE_IRIDESCENCE\n		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );\n	#else\n		vec3 Fr = specularColor;\n	#endif\n	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;\n	float Ess = fab.x + fab.y;\n	float Ems = 1.0 - Ess;\n	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );\n	singleScatter += FssEss;\n	multiScatter += Fms * Ems;\n}\n#if NUM_RECT_AREA_LIGHTS > 0\n	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n		vec3 normal = geometryNormal;\n		vec3 viewDir = geometryViewDir;\n		vec3 position = geometryPosition;\n		vec3 lightPos = rectAreaLight.position;\n		vec3 halfWidth = rectAreaLight.halfWidth;\n		vec3 halfHeight = rectAreaLight.halfHeight;\n		vec3 lightColor = rectAreaLight.color;\n		float roughness = material.roughness;\n		vec3 rectCoords[ 4 ];\n		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;\n		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;\n		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;\n		vec2 uv = LTC_Uv( normal, viewDir, roughness );\n		vec4 t1 = texture2D( ltc_1, uv );\n		vec4 t2 = texture2D( ltc_2, uv );\n		mat3 mInv = mat3(\n			vec3( t1.x, 0, t1.y ),\n			vec3(    0, 1,    0 ),\n			vec3( t1.z, 0, t1.w )\n		);\n		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );\n		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );\n		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );\n		#ifdef USE_CLEARCOAT\n			vec3 Ncc = geometryClearcoatNormal;\n			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );\n			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );\n			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );\n			mat3 mInvClearcoat = mat3(\n				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),\n				vec3(             0, 1,             0 ),\n				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )\n			);\n			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;\n			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );\n		#endif\n	}\n#endif\nvoid RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	#ifdef USE_CLEARCOAT\n		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );\n		vec3 ccIrradiance = dotNLcc * directLight.color;\n		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );\n	#endif\n	#ifdef USE_SHEEN\n \n 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );\n \n 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );\n \n 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );\n \n 		irradiance *= sheenEnergyComp;\n \n 	#endif\n	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );\n	#ifdef USE_RETROREFLECTION\n		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );\n		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );\n		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );\n	#endif\n	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;\n	vec3 halfDir = normalize( directLight.direction + geometryViewDir );\n	float dotVH = saturate( dot( geometryViewDir, halfDir ) );\n	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );\n	#ifdef USE_RETROREFLECTION\n		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );\n		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );\n		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );\n		F = mix( F, retroF, saturate( material.retroreflectivity ) );\n	#endif\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );\n}\nvoid RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	vec3 singleScattering = vec3( 0.0 );\n	vec3 multiScattering = vec3( 0.0 );\n	#ifdef USE_IRIDESCENCE\n		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );\n	#else\n		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );\n	#endif\n	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );\n	#ifdef USE_SHEEN\n		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;\n		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;\n		diffuse *= sheenEnergyComp;\n	#endif\n	reflectedLight.indirectDiffuse += diffuse;\n}\nvoid RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {\n	#ifdef USE_CLEARCOAT\n		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );\n	#endif\n	#ifdef USE_SHEEN\n		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;\n 	#endif\n	vec3 singleScatteringDielectric = vec3( 0.0 );\n	vec3 multiScatteringDielectric = vec3( 0.0 );\n	vec3 singleScatteringMetallic = vec3( 0.0 );\n	vec3 multiScatteringMetallic = vec3( 0.0 );\n	#ifdef USE_IRIDESCENCE\n		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );\n		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );\n	#else\n		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );\n		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );\n	#endif\n	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );\n	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );\n	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;\n	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );\n	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;\n	vec3 indirectSpecular = radiance * singleScattering;\n	indirectSpecular += multiScattering * cosineWeightedIrradiance;\n	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;\n	#ifdef USE_SHEEN\n		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;\n		indirectSpecular *= sheenEnergyComp;\n		indirectDiffuse *= sheenEnergyComp;\n	#endif\n	reflectedLight.indirectSpecular += indirectSpecular;\n	reflectedLight.indirectDiffuse += indirectDiffuse;\n}\n#define RE_Direct				RE_Direct_Physical\n#define RE_Direct_RectArea		RE_Direct_RectArea_Physical\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical\n#define RE_IndirectSpecular		RE_IndirectSpecular_Physical\nfloat computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {\n	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );\n}",
                    lights_fragment_begin: "\nvec3 geometryPosition = - vViewPosition;\nvec3 geometryNormal = normal;\nvec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );\nvec3 geometryClearcoatNormal = vec3( 0.0 );\n#ifdef USE_CLEARCOAT\n	geometryClearcoatNormal = clearcoatNormal;\n#endif\n#ifdef USE_IRIDESCENCE\n	float dotNVi = saturate( dot( normal, geometryViewDir ) );\n	if ( material.iridescenceThickness == 0.0 ) {\n		material.iridescence = 0.0;\n	} else {\n		material.iridescence = saturate( material.iridescence );\n	}\n	if ( material.iridescence > 0.0 ) {\n		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );\n		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );\n		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );\n		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );\n		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );\n	}\n#endif\n#ifdef STANDARD\n	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );\n	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;\n	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )\n		float EssMs = material.dfg.x + material.dfg.y;\n		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );\n	#endif\n#endif\nIncidentLight directLight;\n#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )\n	PointLight pointLight;\n	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0\n	PointLightShadow pointLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {\n		pointLight = pointLights[ i ];\n		getPointLightInfo( pointLight, geometryPosition, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )\n		pointLightShadow = pointLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )\n	SpotLight spotLight;\n	vec4 spotColor;\n	vec3 spotLightCoord;\n	bool inSpotLightMap;\n	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {\n		spotLight = spotLights[ i ];\n		getSpotLightInfo( spotLight, geometryPosition, directLight );\n		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX\n		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS\n		#else\n		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#endif\n		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )\n			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;\n			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );\n			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );\n			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;\n		#endif\n		#undef SPOT_LIGHT_MAP_INDEX\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		spotLightShadow = spotLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )\n	SunLight sunLight;\n	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0\n	SunLightShadow sunLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {\n		sunLight = sunLights[ i ];\n		getSunLightInfo( sunLight, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )\n		sunLightShadow = sunLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )\n	DirectionalLight directionalLight;\n	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {\n		directionalLight = directionalLights[ i ];\n		getDirectionalLightInfo( directionalLight, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )\n		directionalLightShadow = directionalLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )\n	RectAreaLight rectAreaLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {\n		rectAreaLight = rectAreaLights[ i ];\n		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if defined( RE_IndirectDiffuse )\n	vec3 iblIrradiance = vec3( 0.0 );\n	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );\n	#if defined( USE_LIGHT_PROBES )\n		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );\n	#endif\n	#if ( NUM_HEMI_LIGHTS > 0 )\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {\n			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );\n		}\n		#pragma unroll_loop_end\n	#endif\n	#ifdef USE_LIGHT_PROBES_GRID\n		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;\n		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );\n		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );\n	#endif\n#endif\n#if defined( RE_IndirectSpecular )\n	vec3 radiance = vec3( 0.0 );\n	vec3 clearcoatRadiance = vec3( 0.0 );\n#endif",
                    lights_fragment_maps: "#if defined( RE_IndirectDiffuse )\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;\n		irradiance += lightMapIrradiance;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )\n		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )\n			iblIrradiance += getIBLIrradiance( geometryNormal );\n		#endif\n	#endif\n#endif\n#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )\n	#ifdef USE_ANISOTROPY\n		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );\n	#else\n		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );\n	#endif\n	#ifdef USE_RETROREFLECTION\n		#ifdef USE_ANISOTROPY\n			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );\n		#else\n			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );\n		#endif\n		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );\n	#endif\n	radiance += iblRadiance;\n	#ifdef USE_CLEARCOAT\n		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );\n	#endif\n#endif",
                    lights_fragment_end: "#if defined( RE_IndirectDiffuse )\n	#if defined( LAMBERT ) || defined( PHONG )\n		irradiance += iblIrradiance;\n	#endif\n	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif\n#if defined( RE_IndirectSpecular )\n	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif",
                    lightprobes_pars_fragment: "#ifdef USE_LIGHT_PROBES_GRID\nuniform highp sampler3D probesSH;\nuniform vec3 probesMin;\nuniform vec3 probesMax;\nuniform vec3 probesResolution;\nvec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {\n	vec3 res = probesResolution;\n	vec3 gridRange = probesMax - probesMin;\n	vec3 resMinusOne = res - 1.0;\n	vec3 probeSpacing = gridRange / resMinusOne;\n	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;\n	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );\n	uvw = uvw * resMinusOne / res + 0.5 / res;\n	float nz          = res.z;\n	float paddedSlices = nz + 2.0;\n	float atlasDepth  = 7.0 * paddedSlices;\n	float uvZBase     = uvw.z * nz + 1.0;\n	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );\n	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );\n	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );\n	vec3 c0 = s0.xyz;\n	vec3 c1 = vec3( s0.w, s1.xy );\n	vec3 c2 = vec3( s1.zw, s2.x );\n	vec3 c3 = s2.yzw;\n	vec3 c4 = s3.xyz;\n	vec3 c5 = vec3( s3.w, s4.xy );\n	vec3 c6 = vec3( s4.zw, s5.x );\n	vec3 c7 = s5.yzw;\n	vec3 c8 = s6.xyz;\n	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;\n	vec3 result = c0 * 0.886227;\n	result += c1 * 2.0 * 0.511664 * y;\n	result += c2 * 2.0 * 0.511664 * z;\n	result += c3 * 2.0 * 0.511664 * x;\n	result += c4 * 2.0 * 0.429043 * x * y;\n	result += c5 * 2.0 * 0.429043 * y * z;\n	result += c6 * ( 0.743125 * z * z - 0.247708 );\n	result += c7 * 2.0 * 0.429043 * x * z;\n	result += c8 * 0.429043 * ( x * x - y * y );\n	return max( result, vec3( 0.0 ) );\n}\n#endif",
                    logdepthbuf_fragment: "#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )\n	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;\n#endif",
                    logdepthbuf_pars_fragment: "#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )\n	uniform float logDepthBufFC;\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif",
                    logdepthbuf_pars_vertex: "#ifdef USE_LOGARITHMIC_DEPTH_BUFFER\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif",
                    logdepthbuf_vertex: "#ifdef USE_LOGARITHMIC_DEPTH_BUFFER\n	vFragDepth = 1.0 + gl_Position.w;\n	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );\n#endif",
                    map_fragment: "#ifdef USE_MAP\n	vec4 sampledDiffuseColor = texture2D( map, vMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );\n	#endif\n	diffuseColor *= sampledDiffuseColor;\n#endif",
                    map_pars_fragment: "#ifdef USE_MAP\n	uniform sampler2D map;\n#endif",
                    map_particle_fragment: "#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n	#if defined( USE_POINTS_UV )\n		vec2 uv = vUv;\n	#else\n		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;\n	#endif\n#endif\n#ifdef USE_MAP\n	diffuseColor *= texture2D( map, uv );\n#endif\n#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, uv ).g;\n#endif",
                    map_particle_pars_fragment: "#if defined( USE_POINTS_UV )\n	varying vec2 vUv;\n#else\n	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n		uniform mat3 uvTransform;\n	#endif\n#endif\n#ifdef USE_MAP\n	uniform sampler2D map;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif",
                    metalnessmap_fragment: "float metalnessFactor = metalness;\n#ifdef USE_METALNESSMAP\n	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );\n	metalnessFactor *= texelMetalness.b;\n#endif",
                    metalnessmap_pars_fragment: "#ifdef USE_METALNESSMAP\n	uniform sampler2D metalnessMap;\n#endif",
                    morphinstance_vertex: "#ifdef USE_INSTANCING_MORPH\n	float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;\n	}\n#endif",
                    morphcolor_vertex: "#if defined( USE_MORPHCOLORS )\n	vColor *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		#if defined( USE_COLOR_ALPHA )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];\n		#elif defined( USE_COLOR )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];\n		#endif\n	}\n#endif",
                    morphnormal_vertex: "#ifdef USE_MORPHNORMALS\n	objectNormal *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif",
                    morphtarget_pars_vertex: "#ifdef USE_MORPHTARGETS\n	#ifndef USE_INSTANCING_MORPH\n		uniform float morphTargetBaseInfluence;\n		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	#endif\n	uniform sampler2DArray morphTargetsTexture;\n	uniform ivec2 morphTargetsTextureSize;\n	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {\n		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;\n		int y = texelIndex / morphTargetsTextureSize.x;\n		int x = texelIndex - y * morphTargetsTextureSize.x;\n		ivec3 morphUV = ivec3( x, y, morphTargetIndex );\n		return texelFetch( morphTargetsTexture, morphUV, 0 );\n	}\n#endif",
                    morphtarget_vertex: "#ifdef USE_MORPHTARGETS\n	transformed *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif",
                    normal_fragment_begin: "float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;\n#ifdef FLAT_SHADED\n	vec3 fdx = dFdx( vViewPosition );\n	vec3 fdy = dFdy( vViewPosition );\n	vec3 normal = normalize( cross( fdx, fdy ) );\n#else\n	vec3 normal = normalize( vNormal );\n	#ifdef DOUBLE_SIDED\n		normal *= faceDirection;\n	#endif\n#endif\n#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )\n	#ifdef USE_TANGENT\n		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn = getTangentFrame( - vViewPosition, normal,\n		#if defined( USE_NORMALMAP )\n			vNormalMapUv\n		#elif defined( USE_CLEARCOAT_NORMALMAP )\n			vClearcoatNormalMapUv\n		#else\n			vUv\n		#endif\n		);\n	#endif\n	#ifdef DOUBLE_SIDED\n		tbn[0] *= faceDirection;\n		tbn[1] *= faceDirection;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	#ifdef USE_TANGENT\n		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );\n	#endif\n	#ifdef DOUBLE_SIDED\n		tbn2[0] *= faceDirection;\n		tbn2[1] *= faceDirection;\n	#endif\n#endif\nvec3 nonPerturbedNormal = normal;",
                    normal_fragment_maps: "#ifdef USE_NORMALMAP_OBJECTSPACE\n	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	#ifdef FLIP_SIDED\n		normal = - normal;\n	#endif\n	#ifdef DOUBLE_SIDED\n		normal = normal * faceDirection;\n	#endif\n	normal = normalize( normalMatrix * normal );\n#elif defined( USE_NORMALMAP_TANGENTSPACE )\n	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	#if defined( USE_PACKED_NORMALMAP )\n		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );\n	#endif\n	mapN.xy *= normalScale;\n	normal = normalize( tbn * mapN );\n#elif defined( USE_BUMPMAP )\n	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );\n#endif",
                    normal_pars_fragment: "#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif",
                    normal_pars_vertex: "#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif",
                    normal_vertex: "#ifndef FLAT_SHADED\n	vNormal = normalize( transformedNormal );\n	#ifdef USE_TANGENT\n		vTangent = normalize( transformedTangent );\n		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );\n		#ifdef FLIP_SIDED\n			vBitangent = - vBitangent;\n		#endif\n	#endif\n#endif",
                    normalmap_pars_fragment: "#ifdef USE_NORMALMAP\n	uniform sampler2D normalMap;\n	uniform vec2 normalScale;\n#endif\n#ifdef USE_NORMALMAP_OBJECTSPACE\n	uniform mat3 normalMatrix;\n#endif\n#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )\n	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {\n		vec3 q0 = dFdx( eye_pos.xyz );\n		vec3 q1 = dFdy( eye_pos.xyz );\n		vec2 st0 = dFdx( uv.st );\n		vec2 st1 = dFdy( uv.st );\n		vec3 N = surf_norm;\n		vec3 q1perp = cross( q1, N );\n		vec3 q0perp = cross( N, q0 );\n		vec3 T = q1perp * st0.x + q0perp * st1.x;\n		vec3 B = q1perp * st0.y + q0perp * st1.y;\n		float det = max( dot( T, T ), dot( B, B ) );\n		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );\n		return mat3( T * scale, B * scale, N );\n	}\n#endif",
                    clearcoat_normal_fragment_begin: "#ifdef USE_CLEARCOAT\n	vec3 clearcoatNormal = nonPerturbedNormal;\n#endif",
                    clearcoat_normal_fragment_maps: "#ifdef USE_CLEARCOAT_NORMALMAP\n	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;\n	clearcoatMapN.xy *= clearcoatNormalScale;\n	clearcoatNormal = normalize( tbn2 * clearcoatMapN );\n#endif",
                    clearcoat_pars_fragment: "#ifdef USE_CLEARCOATMAP\n	uniform sampler2D clearcoatMap;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform sampler2D clearcoatNormalMap;\n	uniform vec2 clearcoatNormalScale;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform sampler2D clearcoatRoughnessMap;\n#endif",
                    iridescence_pars_fragment: "#ifdef USE_IRIDESCENCEMAP\n	uniform sampler2D iridescenceMap;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform sampler2D iridescenceThicknessMap;\n#endif",
                    opaque_fragment: "#ifdef OPAQUE\ndiffuseColor.a = 1.0;\n#endif\n#ifdef USE_TRANSMISSION\ndiffuseColor.a *= material.transmissionAlpha;\n#endif\ngl_FragColor = vec4( outgoingLight, diffuseColor.a );",
                    packing: "vec3 packNormalToRGB( const in vec3 normal ) {\n	return normalize( normal ) * 0.5 + 0.5;\n}\nvec3 unpackRGBToNormal( const in vec3 rgb ) {\n	return 2.0 * rgb.xyz - 1.0;\n}\nconst float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;\nconst float Inv255 = 1. / 255.;\nconst vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );\nconst vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );\nconst vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );\nconst vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );\nvec4 packDepthToRGBA( const in float v ) {\n	if( v <= 0.0 )\n		return vec4( 0., 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec4( 1., 1., 1., 1. );\n	float vuf;\n	float af = modf( v * PackFactors.a, vuf );\n	float bf = modf( vuf * ShiftRight8, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );\n}\nvec3 packDepthToRGB( const in float v ) {\n	if( v <= 0.0 )\n		return vec3( 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec3( 1., 1., 1. );\n	float vuf;\n	float bf = modf( v * PackFactors.b, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec3( vuf * Inv255, gf * PackUpscale, bf );\n}\nvec2 packDepthToRG( const in float v ) {\n	if( v <= 0.0 )\n		return vec2( 0., 0. );\n	if( v >= 1.0 )\n		return vec2( 1., 1. );\n	float vuf;\n	float gf = modf( v * 256., vuf );\n	return vec2( vuf * Inv255, gf );\n}\nfloat unpackRGBAToDepth( const in vec4 v ) {\n	return dot( v, UnpackFactors4 );\n}\nfloat unpackRGBToDepth( const in vec3 v ) {\n	return dot( v, UnpackFactors3 );\n}\nfloat unpackRGToDepth( const in vec2 v ) {\n	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;\n}\nvec4 pack2HalfToRGBA( const in vec2 v ) {\n	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );\n	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );\n}\nvec2 unpackRGBATo2Half( const in vec4 v ) {\n	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );\n}\nfloat viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( viewZ + near ) / ( near - far );\n}\nfloat orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n	\n		return depth * ( far - near ) - far;\n	#else\n		return depth * ( near - far ) - near;\n	#endif\n}\nfloat viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );\n}\nfloat perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n		return ( near * far ) / ( ( near - far ) * depth - near );\n	#else\n		return ( near * far ) / ( ( far - near ) * depth - far );\n	#endif\n}",
                    premultiplied_alpha_fragment: "#ifdef PREMULTIPLIED_ALPHA\n	gl_FragColor.rgb *= gl_FragColor.a;\n#endif",
                    project_vertex: "vec4 mvPosition = vec4( transformed, 1.0 );\n#ifdef USE_BATCHING\n	mvPosition = batchingMatrix * mvPosition;\n#endif\n#ifdef USE_INSTANCING\n	mvPosition = instanceMatrix * mvPosition;\n#endif\nmvPosition = modelViewMatrix * mvPosition;\ngl_Position = projectionMatrix * mvPosition;",
                    dithering_fragment: "#ifdef DITHERING\n	gl_FragColor.rgb = dithering( gl_FragColor.rgb );\n#endif",
                    dithering_pars_fragment: "#ifdef DITHERING\n	vec3 dithering( vec3 color ) {\n		float grid_position = rand( gl_FragCoord.xy );\n		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );\n		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );\n		return color + dither_shift_RGB;\n	}\n#endif",
                    roughnessmap_fragment: "float roughnessFactor = roughness;\n#ifdef USE_ROUGHNESSMAP\n	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );\n	roughnessFactor *= texelRoughness.g;\n#endif",
                    roughnessmap_pars_fragment: "#ifdef USE_ROUGHNESSMAP\n	uniform sampler2D roughnessMap;\n#endif",
                    shadowmap_pars_fragment: "#if NUM_SPOT_LIGHT_COORDS > 0\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#if NUM_SPOT_LIGHT_MAPS > 0\n	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n		#define SUN_LIGHT_CASCADES 2\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];\n		#else\n			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];\n		#endif\n		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];\n		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];\n		varying vec4 vSunShadowWorldPosition;\n		varying vec3 vSunShadowWorldNormal;\n		struct SunLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];\n		#else\n			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];\n		#endif\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];\n		#else\n			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];\n		#endif\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];\n		#elif defined( SHADOWMAP_TYPE_BASIC )\n			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];\n		#endif\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n	#if defined( SHADOWMAP_TYPE_PCF )\n		float interleavedGradientNoise( vec2 position ) {\n			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );\n		}\n		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {\n			const float goldenAngle = 2.399963229728653;\n			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );\n			float theta = float( sampleIndex ) * goldenAngle + phi;\n			return vec2( cos( theta ), sin( theta ) ) * r;\n		}\n	#endif\n	#if defined( SHADOWMAP_TYPE_PCF )\n		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			shadowCoord.z += shadowBias;\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;\n				float radius = shadowRadius * texelSize.x;\n				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;\n				shadow = (\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )\n				) * 0.2;\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#elif defined( SHADOWMAP_TYPE_VSM )\n		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				shadowCoord.z -= shadowBias;\n			#else\n				shadowCoord.z += shadowBias;\n			#endif\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;\n				float mean = distribution.x;\n				float variance = distribution.y * distribution.y;\n				#ifdef USE_REVERSED_DEPTH_BUFFER\n					float hard_shadow = step( mean, shadowCoord.z );\n				#else\n					float hard_shadow = step( shadowCoord.z, mean );\n				#endif\n				\n				if ( hard_shadow == 1.0 ) {\n					shadow = 1.0;\n				} else {\n					variance = max( variance, 0.0000001 );\n					float d = shadowCoord.z - mean;\n					float p_max = variance / ( variance + d * d );\n					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );\n					shadow = max( hard_shadow, p_max );\n				}\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#else\n		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				shadowCoord.z -= shadowBias;\n			#else\n				shadowCoord.z += shadowBias;\n			#endif\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				float depth = texture2D( shadowMap, shadowCoord.xy ).r;\n				#ifdef USE_REVERSED_DEPTH_BUFFER\n					shadow = step( depth, shadowCoord.z );\n				#else\n					shadow = step( shadowCoord.z, depth );\n				#endif\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#endif\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n		float getSunShadow(\n			#if defined( SHADOWMAP_TYPE_PCF )\n				sampler2DShadow shadowMap,\n			#else\n				sampler2D shadowMap,\n			#endif\n			SunLightShadow sunLightShadow,\n			int shadowIndex\n		) {\n			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );\n			float viewDepth = vSunShadowWorldPosition.w;\n			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;\n			float shadow = 1.0;\n			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {\n				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];\n				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {\n					float cascadeShadow = getShadow(\n						shadowMap,\n						sunLightShadow.shadowMapSize,\n						sunLightShadow.shadowIntensity,\n						sunLightShadow.shadowBias,\n						sunLightShadow.shadowRadius,\n						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition\n					);\n					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );\n				}\n			}\n			return shadow;\n		}\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n	#if defined( SHADOWMAP_TYPE_PCF )\n	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {\n		float shadow = 1.0;\n		vec3 lightToPosition = shadowCoord.xyz;\n		vec3 bd3D = normalize( lightToPosition );\n		vec3 absVec = abs( lightToPosition );\n		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );\n		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n				dp -= shadowBias;\n			#else\n				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n				dp += shadowBias;\n			#endif\n			float texelSize = shadowRadius / shadowMapSize.x;\n			vec3 absDir = abs( bd3D );\n			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );\n			tangent = normalize( cross( bd3D, tangent ) );\n			vec3 bitangent = cross( bd3D, tangent );\n			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;\n			vec2 sample0 = vogelDiskSample( 0, 5, phi );\n			vec2 sample1 = vogelDiskSample( 1, 5, phi );\n			vec2 sample2 = vogelDiskSample( 2, 5, phi );\n			vec2 sample3 = vogelDiskSample( 3, 5, phi );\n			vec2 sample4 = vogelDiskSample( 4, 5, phi );\n			shadow = (\n				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )\n			) * 0.2;\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n	#elif defined( SHADOWMAP_TYPE_BASIC )\n	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {\n		float shadow = 1.0;\n		vec3 lightToPosition = shadowCoord.xyz;\n		vec3 absVec = abs( lightToPosition );\n		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );\n		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {\n			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n			dp += shadowBias;\n			vec3 bd3D = normalize( lightToPosition );\n			float depth = textureCube( shadowMap, bd3D ).r;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				depth = 1.0 - depth;\n			#endif\n			shadow = step( dp, depth );\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n	#endif\n	#endif\n#endif",
                    shadowmap_pars_vertex: "#if NUM_SPOT_LIGHT_COORDS > 0\n	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n		varying vec4 vSunShadowWorldPosition;\n		varying vec3 vSunShadowWorldNormal;\n	#endif\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n#endif",
                    shadowmap_vertex: "#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )\n	#ifdef HAS_NORMAL\n		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );\n	#else\n		vec3 shadowWorldNormal = vec3( 0.0 );\n	#endif\n	vec4 shadowWorldPosition;\n#endif\n#if defined( USE_SHADOWMAP )\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );\n		vSunShadowWorldNormal = shadowWorldNormal;\n	#endif\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );\n			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );\n			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n#endif\n#if NUM_SPOT_LIGHT_COORDS > 0\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {\n		shadowWorldPosition = worldPosition;\n		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;\n		#endif\n		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;\n	}\n	#pragma unroll_loop_end\n#endif",
                    shadowmask_pars_fragment: "float getShadowMask() {\n	float shadow = 1.0;\n	#ifdef USE_SHADOWMAP\n	#if NUM_SUN_LIGHT_SHADOWS > 0\n	SunLightShadow sunLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {\n		sunLight = sunLightShadows[ i ];\n		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n		directionalLight = directionalLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {\n		spotLight = spotLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )\n	PointLightShadow pointLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n		pointLight = pointLightShadows[ i ];\n		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#endif\n	return shadow;\n}",
                    skinbase_vertex: "#ifdef USE_SKINNING\n	mat4 boneMatX = getBoneMatrix( skinIndex.x );\n	mat4 boneMatY = getBoneMatrix( skinIndex.y );\n	mat4 boneMatZ = getBoneMatrix( skinIndex.z );\n	mat4 boneMatW = getBoneMatrix( skinIndex.w );\n#endif",
                    skinning_pars_vertex: "#ifdef USE_SKINNING\n	uniform mat4 bindMatrix;\n	uniform mat4 bindMatrixInverse;\n	uniform highp sampler2D boneTexture;\n	mat4 getBoneMatrix( const in float i ) {\n		int size = textureSize( boneTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n#endif",
                    skinning_vertex: "#ifdef USE_SKINNING\n	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );\n	vec4 skinned = vec4( 0.0 );\n	skinned += boneMatX * skinVertex * skinWeight.x;\n	skinned += boneMatY * skinVertex * skinWeight.y;\n	skinned += boneMatZ * skinVertex * skinWeight.z;\n	skinned += boneMatW * skinVertex * skinWeight.w;\n	transformed = ( bindMatrixInverse * skinned ).xyz;\n#endif",
                    skinnormal_vertex: "#ifdef USE_SKINNING\n	mat4 skinMatrix = mat4( 0.0 );\n	skinMatrix += skinWeight.x * boneMatX;\n	skinMatrix += skinWeight.y * boneMatY;\n	skinMatrix += skinWeight.z * boneMatZ;\n	skinMatrix += skinWeight.w * boneMatW;\n	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;\n	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;\n	#ifdef USE_TANGENT\n		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;\n	#endif\n#endif",
                    specularmap_fragment: "float specularStrength;\n#ifdef USE_SPECULARMAP\n	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );\n	specularStrength = texelSpecular.r;\n#else\n	specularStrength = 1.0;\n#endif",
                    specularmap_pars_fragment: "#ifdef USE_SPECULARMAP\n	uniform sampler2D specularMap;\n#endif",
                    tonemapping_fragment: "#if defined( TONE_MAPPING )\n	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );\n#endif",
                    tonemapping_pars_fragment: "#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\nuniform float toneMappingExposure;\nvec3 LinearToneMapping( vec3 color ) {\n	return saturate( toneMappingExposure * color );\n}\nvec3 ReinhardToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	return saturate( color / ( vec3( 1.0 ) + color ) );\n}\nvec3 CineonToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	color = max( vec3( 0.0 ), color - 0.004 );\n	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );\n}\nvec3 RRTAndODTFit( vec3 v ) {\n	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;\n	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;\n	return a / b;\n}\nvec3 ACESFilmicToneMapping( vec3 color ) {\n	const mat3 ACESInputMat = mat3(\n		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),\n		vec3( 0.04823, 0.01566, 0.83777 )\n	);\n	const mat3 ACESOutputMat = mat3(\n		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),\n		vec3( -0.07367, -0.00605,  1.07602 )\n	);\n	color *= toneMappingExposure / 0.6;\n	color = ACESInputMat * color;\n	color = RRTAndODTFit( color );\n	color = ACESOutputMat * color;\n	return saturate( color );\n}\nconst mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(\n	vec3( 1.6605, - 0.1246, - 0.0182 ),\n	vec3( - 0.5876, 1.1329, - 0.1006 ),\n	vec3( - 0.0728, - 0.0083, 1.1187 )\n);\nconst mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(\n	vec3( 0.6274, 0.0691, 0.0164 ),\n	vec3( 0.3293, 0.9195, 0.0880 ),\n	vec3( 0.0433, 0.0113, 0.8956 )\n);\nvec3 agxDefaultContrastApprox( vec3 x ) {\n	vec3 x2 = x * x;\n	vec3 x4 = x2 * x2;\n	return + 15.5 * x4 * x2\n		- 40.14 * x4 * x\n		+ 31.96 * x4\n		- 6.868 * x2 * x\n		+ 0.4298 * x2\n		+ 0.1191 * x\n		- 0.00232;\n}\nvec3 AgXToneMapping( vec3 color ) {\n	const mat3 AgXInsetMatrix = mat3(\n		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),\n		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),\n		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )\n	);\n	const mat3 AgXOutsetMatrix = mat3(\n		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),\n		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),\n		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )\n	);\n	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;\n	color *= toneMappingExposure;\n	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;\n	color = AgXInsetMatrix * color;\n	color = max( color, 1e-10 );	color = log2( color );\n	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );\n	color = clamp( color, 0.0, 1.0 );\n	color = agxDefaultContrastApprox( color );\n	color = AgXOutsetMatrix * color;\n	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );\n	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;\n	color = clamp( color, 0.0, 1.0 );\n	return color;\n}\nvec3 NeutralToneMapping( vec3 color ) {\n	const float StartCompression = 0.8 - 0.04;\n	const float Desaturation = 0.15;\n	color *= toneMappingExposure;\n	float x = min( color.r, min( color.g, color.b ) );\n	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;\n	color -= offset;\n	float peak = max( color.r, max( color.g, color.b ) );\n	if ( peak < StartCompression ) return color;\n	float d = 1. - StartCompression;\n	float newPeak = 1. - d * d / ( peak + d - StartCompression );\n	color *= newPeak / peak;\n	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );\n	return mix( color, vec3( newPeak ), g );\n}\nvec3 CustomToneMapping( vec3 color ) { return color; }",
                    transmission_fragment: "#ifdef USE_TRANSMISSION\n	material.transmission = transmission;\n	material.transmissionAlpha = 1.0;\n	material.thickness = thickness;\n	material.attenuationDistance = attenuationDistance;\n	material.attenuationColor = attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;\n	#endif\n	vec3 pos = vWorldPosition;\n	vec3 v = normalize( cameraPosition - pos );\n	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );\n	vec4 transmitted = getIBLVolumeRefraction(\n		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,\n		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,\n		material.attenuationColor, material.attenuationDistance );\n	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );\n	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );\n#endif",
                    transmission_pars_fragment: "#ifdef USE_TRANSMISSION\n	uniform float transmission;\n	uniform float thickness;\n	uniform float attenuationDistance;\n	uniform vec3 attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		uniform sampler2D transmissionMap;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		uniform sampler2D thicknessMap;\n	#endif\n	uniform vec2 transmissionSamplerSize;\n	uniform sampler2D transmissionSamplerMap;\n	uniform mat4 modelMatrix;\n	uniform mat4 projectionMatrix;\n	varying vec3 vWorldPosition;\n	float w0( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );\n	}\n	float w1( float a ) {\n		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );\n	}\n	float w2( float a ){\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );\n	}\n	float w3( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * a * a );\n	}\n	float g0( float a ) {\n		return w0( a ) + w1( a );\n	}\n	float g1( float a ) {\n		return w2( a ) + w3( a );\n	}\n	float h0( float a ) {\n		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );\n	}\n	float h1( float a ) {\n		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );\n	}\n	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {\n		uv = uv * texelSize.zw + 0.5;\n		vec2 iuv = floor( uv );\n		vec2 fuv = fract( uv );\n		float g0x = g0( fuv.x );\n		float g1x = g1( fuv.x );\n		float h0x = h0( fuv.x );\n		float h1x = h1( fuv.x );\n		float h0y = h0( fuv.y );\n		float h1y = h1( fuv.y );\n		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +\n			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );\n	}\n	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {\n		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );\n		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );\n		vec2 fLodSizeInv = 1.0 / fLodSize;\n		vec2 cLodSizeInv = 1.0 / cLodSize;\n		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );\n		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );\n		return mix( fSample, cSample, fract( lod ) );\n	}\n	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {\n		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );\n		vec3 modelScale;\n		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );\n		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );\n		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );\n		return normalize( refractionVector ) * thickness * modelScale;\n	}\n	float applyIorToRoughness( const in float roughness, const in float ior ) {\n		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );\n	}\n	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {\n		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );\n		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );\n	}\n	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {\n		if ( isinf( attenuationDistance ) ) {\n			return vec3( 1.0 );\n		} else {\n			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;\n			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;\n		}\n	}\n	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,\n		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,\n		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,\n		const in vec3 attenuationColor, const in float attenuationDistance ) {\n		vec4 transmittedLight;\n		vec3 transmittance;\n		#ifdef USE_DISPERSION\n			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;\n			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );\n			for ( int i = 0; i < 3; i ++ ) {\n				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );\n				vec3 refractedRayExit = position + transmissionRay;\n				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n				vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n				refractionCoords += 1.0;\n				refractionCoords /= 2.0;\n				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );\n				transmittedLight[ i ] = transmissionSample[ i ];\n				transmittedLight.a += transmissionSample.a;\n				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];\n			}\n			transmittedLight.a /= 3.0;\n		#else\n			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );\n			vec3 refractedRayExit = position + transmissionRay;\n			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n			vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n			refractionCoords += 1.0;\n			refractionCoords /= 2.0;\n			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );\n			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );\n		#endif\n		vec3 attenuatedColor = transmittance * transmittedLight.rgb;\n		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );\n		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;\n		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );\n	}\n#endif",
                    uv_pars_fragment: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif",
                    uv_pars_vertex: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	uniform mat3 mapTransform;\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform mat3 alphaMapTransform;\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	uniform mat3 lightMapTransform;\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	uniform mat3 aoMapTransform;\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	uniform mat3 bumpMapTransform;\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	uniform mat3 normalMapTransform;\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	uniform mat3 displacementMapTransform;\n	varying vec2 vDisplacementMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	uniform mat3 emissiveMapTransform;\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	uniform mat3 metalnessMapTransform;\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	uniform mat3 roughnessMapTransform;\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	uniform mat3 anisotropyMapTransform;\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	uniform mat3 clearcoatMapTransform;\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform mat3 clearcoatNormalMapTransform;\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform mat3 clearcoatRoughnessMapTransform;\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	uniform mat3 sheenColorMapTransform;\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	uniform mat3 sheenRoughnessMapTransform;\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	uniform mat3 iridescenceMapTransform;\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform mat3 iridescenceThicknessMapTransform;\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	uniform mat3 specularMapTransform;\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	uniform mat3 specularColorMapTransform;\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	uniform mat3 specularIntensityMapTransform;\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif",
                    uv_vertex: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	vUv = vec3( uv, 1 ).xy;\n#endif\n#ifdef USE_MAP\n	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ALPHAMAP\n	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_LIGHTMAP\n	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_AOMAP\n	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_BUMPMAP\n	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_NORMALMAP\n	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_EMISSIVEMAP\n	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_METALNESSMAP\n	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOATMAP\n	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULARMAP\n	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_THICKNESSMAP\n	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;\n#endif",
                    worldpos_vertex: "#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0\n	vec4 worldPosition = vec4( transformed, 1.0 );\n	#ifdef USE_BATCHING\n		worldPosition = batchingMatrix * worldPosition;\n	#endif\n	#ifdef USE_INSTANCING\n		worldPosition = instanceMatrix * worldPosition;\n	#endif\n	worldPosition = modelMatrix * worldPosition;\n#endif",
                    background_vert: "varying vec2 vUv;\nuniform mat3 uvTransform;\nvoid main() {\n	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	gl_Position = vec4( position.xy, 1.0, 1.0 );\n}",
                    background_frag: "uniform sampler2D t2D;\nuniform float backgroundIntensity;\nvarying vec2 vUv;\nvoid main() {\n	vec4 texColor = texture2D( t2D, vUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
                    backgroundCube_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}",
                    backgroundCube_frag: "#ifdef ENVMAP_TYPE_CUBE\n	uniform samplerCube envMap;\n#elif defined( ENVMAP_TYPE_CUBE_UV )\n	uniform sampler2D envMap;\n#endif\nuniform float backgroundBlurriness;\nuniform float backgroundIntensity;\nuniform mat3 backgroundRotation;\nvarying vec3 vWorldDirection;\n#include <cube_uv_reflection_fragment>\nvoid main() {\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );\n	#elif defined( ENVMAP_TYPE_CUBE_UV )\n		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );\n	#else\n		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
                    cube_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}",
                    cube_frag: "uniform samplerCube tCube;\nuniform float tFlip;\nuniform float opacity;\nvarying vec3 vWorldDirection;\nvoid main() {\n	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );\n	gl_FragColor = texColor;\n	gl_FragColor.a *= opacity;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
                    depth_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vHighPrecisionZW = gl_Position.zw;\n}",
                    depth_frag: "#if DEPTH_PACKING == 3200\n	uniform float opacity;\n#endif\n#include <common>\n#include <packing>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#if DEPTH_PACKING == 3200\n		diffuseColor.a = opacity;\n	#endif\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <logdepthbuf_fragment>\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];\n	#else\n		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;\n	#endif\n	#if DEPTH_PACKING == 3200\n		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );\n	#elif DEPTH_PACKING == 3201\n		gl_FragColor = packDepthToRGBA( fragCoordZ );\n	#elif DEPTH_PACKING == 3202\n		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );\n	#elif DEPTH_PACKING == 3203\n		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );\n	#endif\n}",
                    distance_vert: "#define DISTANCE\nvarying vec3 vWorldPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <worldpos_vertex>\n	#include <clipping_planes_vertex>\n	vWorldPosition = worldPosition.xyz;\n}",
                    distance_frag: "#define DISTANCE\nuniform vec3 referencePosition;\nuniform float nearDistance;\nuniform float farDistance;\nvarying vec3 vWorldPosition;\n#include <common>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	float dist = length( vWorldPosition - referencePosition );\n	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );\n	dist = saturate( dist );\n	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );\n}",
                    equirect_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n}",
                    equirect_frag: "uniform sampler2D tEquirect;\nvarying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vec3 direction = normalize( vWorldDirection );\n	vec2 sampleUV = equirectUv( direction );\n	gl_FragColor = texture2D( tEquirect, sampleUV );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
                    linedashed_vert: "uniform float scale;\nattribute float lineDistance;\nvarying float vLineDistance;\n#include <common>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	vLineDistance = scale * lineDistance;\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}",
                    linedashed_frag: "uniform vec3 diffuse;\nuniform float opacity;\nuniform float dashSize;\nuniform float totalSize;\nvarying float vLineDistance;\n#include <common>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	if ( mod( vLineDistance, totalSize ) > dashSize ) {\n		discard;\n	}\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",
                    meshbasic_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinbase_vertex>\n		#include <skinnormal_vertex>\n		#include <defaultnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <fog_vertex>\n}",
                    meshbasic_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n#endif\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;\n	#else\n		reflectedLight.indirectDiffuse += vec3( 1.0 );\n	#endif\n	#include <aomap_fragment>\n	reflectedLight.indirectDiffuse *= diffuseColor.rgb;\n	vec3 outgoingLight = reflectedLight.indirectDiffuse;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
                    meshlambert_vert: "#define LAMBERT\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
                    meshlambert_frag: "#define LAMBERT\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_lambert_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_lambert_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
                    meshmatcap_vert: "#define MATCAP\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n	vViewPosition = - mvPosition.xyz;\n}",
                    meshmatcap_frag: "#define MATCAP\nuniform vec3 diffuse;\nuniform float opacity;\nuniform sampler2D matcap;\nvarying vec3 vViewPosition;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	vec3 viewDir = normalize( vViewPosition );\n	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );\n	vec3 y = cross( viewDir, x );\n	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;\n	#ifdef USE_MATCAP\n		vec4 matcapColor = texture2D( matcap, uv );\n	#else\n		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );\n	#endif\n	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
                    meshnormal_vert: "#define NORMAL\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	vViewPosition = - mvPosition.xyz;\n#endif\n}",
                    meshnormal_frag: "#define NORMAL\nuniform float opacity;\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <uv_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );\n	#ifdef OPAQUE\n		gl_FragColor.a = 1.0;\n	#endif\n}",
                    meshphong_vert: "#define PHONG\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
                    meshphong_frag: "#define PHONG\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform vec3 specular;\nuniform float shininess;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_phong_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_phong_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
                    meshphysical_vert: "#define STANDARD\nvarying vec3 vViewPosition;\n#ifdef USE_TRANSMISSION\n	varying vec3 vWorldPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n#ifdef USE_TRANSMISSION\n	vWorldPosition = worldPosition.xyz;\n#endif\n}",
                    meshphysical_frag: "#define STANDARD\n#ifdef PHYSICAL\n	#define IOR\n	#define USE_SPECULAR\n#endif\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float roughness;\nuniform float metalness;\nuniform float opacity;\n#ifdef IOR\n	uniform float ior;\n#endif\n#ifdef USE_SPECULAR\n	uniform float specularIntensity;\n	uniform vec3 specularColor;\n	#ifdef USE_SPECULAR_COLORMAP\n		uniform sampler2D specularColorMap;\n	#endif\n	#ifdef USE_SPECULAR_INTENSITYMAP\n		uniform sampler2D specularIntensityMap;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT\n	uniform float clearcoat;\n	uniform float clearcoatRoughness;\n#endif\n#ifdef USE_DISPERSION\n	uniform float dispersion;\n#endif\n#ifdef USE_RETROREFLECTION\n	uniform float retroreflectivity;\n#endif\n#ifdef USE_IRIDESCENCE\n	uniform float iridescence;\n	uniform float iridescenceIOR;\n	uniform float iridescenceThicknessMinimum;\n	uniform float iridescenceThicknessMaximum;\n#endif\n#ifdef USE_SHEEN\n	uniform vec3 sheenColor;\n	uniform float sheenRoughness;\n	#ifdef USE_SHEEN_COLORMAP\n		uniform sampler2D sheenColorMap;\n	#endif\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		uniform sampler2D sheenRoughnessMap;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	uniform vec2 anisotropyVector;\n	#ifdef USE_ANISOTROPYMAP\n		uniform sampler2D anisotropyMap;\n	#endif\n#endif\nvarying vec3 vViewPosition;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <iridescence_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_physical_pars_fragment>\n#include <transmission_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <clearcoat_pars_fragment>\n#include <iridescence_pars_fragment>\n#include <roughnessmap_pars_fragment>\n#include <metalnessmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <roughnessmap_fragment>\n	#include <metalnessmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <clearcoat_normal_fragment_begin>\n	#include <clearcoat_normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_physical_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;\n	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;\n	#include <transmission_fragment>\n	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;\n	#ifdef USE_SHEEN\n \n		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;\n \n 	#endif\n	#ifdef USE_CLEARCOAT\n		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );\n		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );\n		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;\n	#endif\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
                    meshtoon_vert: "#define TOON\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
                    meshtoon_frag: "#define TOON\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <gradientmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_toon_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_toon_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
                    points_vert: "uniform float size;\nuniform float scale;\n#include <common>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\n#ifdef USE_POINTS_UV\n	varying vec2 vUv;\n	uniform mat3 uvTransform;\n#endif\nvoid main() {\n	#ifdef USE_POINTS_UV\n		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	#endif\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	gl_PointSize = size;\n	#ifdef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );\n	#endif\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <fog_vertex>\n}",
                    points_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <color_pars_fragment>\n#include <map_particle_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_particle_fragment>\n	#include <color_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",
                    shadow_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <shadowmap_pars_vertex>\nvoid main() {\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
                    shadow_frag: "uniform vec3 color;\nuniform float opacity;\n#include <common>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <logdepthbuf_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <shadowmask_pars_fragment>\nvoid main() {\n	#include <logdepthbuf_fragment>\n	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",
                    sprite_vert: "uniform float rotation;\nuniform vec2 center;\n#include <common>\n#include <uv_pars_vertex>\n#include <fog_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	vec4 mvPosition = modelViewMatrix[ 3 ];\n	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );\n	#ifndef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) scale *= - mvPosition.z;\n	#endif\n	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;\n	vec2 rotatedPosition;\n	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;\n	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;\n	mvPosition.xy += rotatedPosition;\n	gl_Position = projectionMatrix * mvPosition;\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}",
                    sprite_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n}"
                },
                l = {
                    common: {
                        diffuse: {
                            value: new i.Q1f(0xffffff)
                        },
                        opacity: {
                            value: 1
                        },
                        map: {
                            value: null
                        },
                        mapTransform: {
                            value: new i.dwI
                        },
                        alphaMap: {
                            value: null
                        },
                        alphaMapTransform: {
                            value: new i.dwI
                        },
                        alphaTest: {
                            value: 0
                        }
                    },
                    specularmap: {
                        specularMap: {
                            value: null
                        },
                        specularMapTransform: {
                            value: new i.dwI
                        }
                    },
                    envmap: {
                        envMap: {
                            value: null
                        },
                        envMapRotation: {
                            value: new i.dwI
                        },
                        reflectivity: {
                            value: 1
                        },
                        ior: {
                            value: 1.5
                        },
                        refractionRatio: {
                            value: .98
                        },
                        dfgLUT: {
                            value: null
                        }
                    },
                    aomap: {
                        aoMap: {
                            value: null
                        },
                        aoMapIntensity: {
                            value: 1
                        },
                        aoMapTransform: {
                            value: new i.dwI
                        }
                    },
                    lightmap: {
                        lightMap: {
                            value: null
                        },
                        lightMapIntensity: {
                            value: 1
                        },
                        lightMapTransform: {
                            value: new i.dwI
                        }
                    },
                    bumpmap: {
                        bumpMap: {
                            value: null
                        },
                        bumpMapTransform: {
                            value: new i.dwI
                        },
                        bumpScale: {
                            value: 1
                        }
                    },
                    normalmap: {
                        normalMap: {
                            value: null
                        },
                        normalMapTransform: {
                            value: new i.dwI
                        },
                        normalScale: {
                            value: new i.I9Y(1, 1)
                        }
                    },
                    displacementmap: {
                        displacementMap: {
                            value: null
                        },
                        displacementMapTransform: {
                            value: new i.dwI
                        },
                        displacementScale: {
                            value: 1
                        },
                        displacementBias: {
                            value: 0
                        }
                    },
                    emissivemap: {
                        emissiveMap: {
                            value: null
                        },
                        emissiveMapTransform: {
                            value: new i.dwI
                        }
                    },
                    metalnessmap: {
                        metalnessMap: {
                            value: null
                        },
                        metalnessMapTransform: {
                            value: new i.dwI
                        }
                    },
                    roughnessmap: {
                        roughnessMap: {
                            value: null
                        },
                        roughnessMapTransform: {
                            value: new i.dwI
                        }
                    },
                    gradientmap: {
                        gradientMap: {
                            value: null
                        }
                    },
                    fog: {
                        fogDensity: {
                            value: 25e-5
                        },
                        fogNear: {
                            value: 1
                        },
                        fogFar: {
                            value: 2e3
                        },
                        fogColor: {
                            value: new i.Q1f(0xffffff)
                        }
                    },
                    lights: {
                        ambientLightColor: {
                            value: []
                        },
                        lightProbe: {
                            value: []
                        },
                        sunLights: {
                            value: [],
                            properties: {
                                direction: {},
                                color: {}
                            }
                        },
                        sunLightShadows: {
                            value: [],
                            properties: {
                                shadowIntensity: 1,
                                shadowBias: {},
                                shadowNormalBias: {},
                                shadowRadius: {},
                                shadowMapSize: {}
                            }
                        },
                        sunShadowMatrix: {
                            value: []
                        },
                        sunShadowCascade: {
                            value: []
                        },
                        directionalLights: {
                            value: [],
                            properties: {
                                direction: {},
                                color: {}
                            }
                        },
                        directionalLightShadows: {
                            value: [],
                            properties: {
                                shadowIntensity: 1,
                                shadowBias: {},
                                shadowNormalBias: {},
                                shadowRadius: {},
                                shadowMapSize: {}
                            }
                        },
                        directionalShadowMatrix: {
                            value: []
                        },
                        spotLights: {
                            value: [],
                            properties: {
                                color: {},
                                position: {},
                                direction: {},
                                distance: {},
                                coneCos: {},
                                penumbraCos: {},
                                decay: {}
                            }
                        },
                        spotLightShadows: {
                            value: [],
                            properties: {
                                shadowIntensity: 1,
                                shadowBias: {},
                                shadowNormalBias: {},
                                shadowRadius: {},
                                shadowMapSize: {}
                            }
                        },
                        spotLightMap: {
                            value: []
                        },
                        spotLightMatrix: {
                            value: []
                        },
                        pointLights: {
                            value: [],
                            properties: {
                                color: {},
                                position: {},
                                decay: {},
                                distance: {}
                            }
                        },
                        pointLightShadows: {
                            value: [],
                            properties: {
                                shadowIntensity: 1,
                                shadowBias: {},
                                shadowNormalBias: {},
                                shadowRadius: {},
                                shadowMapSize: {},
                                shadowCameraNear: {},
                                shadowCameraFar: {}
                            }
                        },
                        pointShadowMatrix: {
                            value: []
                        },
                        hemisphereLights: {
                            value: [],
                            properties: {
                                direction: {},
                                skyColor: {},
                                groundColor: {}
                            }
                        },
                        rectAreaLights: {
                            value: [],
                            properties: {
                                color: {},
                                position: {},
                                width: {},
                                height: {}
                            }
                        },
                        ltc_1: {
                            value: null
                        },
                        ltc_2: {
                            value: null
                        },
                        probesSH: {
                            value: null
                        },
                        probesMin: {
                            value: new i.Pq0
                        },
                        probesMax: {
                            value: new i.Pq0
                        },
                        probesResolution: {
                            value: new i.Pq0
                        }
                    },
                    points: {
                        diffuse: {
                            value: new i.Q1f(0xffffff)
                        },
                        opacity: {
                            value: 1
                        },
                        size: {
                            value: 1
                        },
                        scale: {
                            value: 1
                        },
                        map: {
                            value: null
                        },
                        alphaMap: {
                            value: null
                        },
                        alphaMapTransform: {
                            value: new i.dwI
                        },
                        alphaTest: {
                            value: 0
                        },
                        uvTransform: {
                            value: new i.dwI
                        }
                    },
                    sprite: {
                        diffuse: {
                            value: new i.Q1f(0xffffff)
                        },
                        opacity: {
                            value: 1
                        },
                        center: {
                            value: new i.I9Y(.5, .5)
                        },
                        rotation: {
                            value: 0
                        },
                        map: {
                            value: null
                        },
                        mapTransform: {
                            value: new i.dwI
                        },
                        alphaMap: {
                            value: null
                        },
                        alphaMapTransform: {
                            value: new i.dwI
                        },
                        alphaTest: {
                            value: 0
                        }
                    }
                },
                s = {
                    basic: {
                        uniforms: (0, i.Iit)([l.common, l.specularmap, l.envmap, l.aomap, l.lightmap, l.fog]),
                        vertexShader: o.meshbasic_vert,
                        fragmentShader: o.meshbasic_frag
                    },
                    lambert: {
                        uniforms: (0, i.Iit)([l.common, l.specularmap, l.envmap, l.aomap, l.lightmap, l.emissivemap, l.bumpmap, l.normalmap, l.displacementmap, l.fog, l.lights, {
                            emissive: {
                                value: new i.Q1f(0)
                            },
                            envMapIntensity: {
                                value: 1
                            }
                        }]),
                        vertexShader: o.meshlambert_vert,
                        fragmentShader: o.meshlambert_frag
                    },
                    phong: {
                        uniforms: (0, i.Iit)([l.common, l.specularmap, l.envmap, l.aomap, l.lightmap, l.emissivemap, l.bumpmap, l.normalmap, l.displacementmap, l.fog, l.lights, {
                            emissive: {
                                value: new i.Q1f(0)
                            },
                            specular: {
                                value: new i.Q1f(1118481)
                            },
                            shininess: {
                                value: 30
                            },
                            envMapIntensity: {
                                value: 1
                            }
                        }]),
                        vertexShader: o.meshphong_vert,
                        fragmentShader: o.meshphong_frag
                    },
                    standard: {
                        uniforms: (0, i.Iit)([l.common, l.envmap, l.aomap, l.lightmap, l.emissivemap, l.bumpmap, l.normalmap, l.displacementmap, l.roughnessmap, l.metalnessmap, l.fog, l.lights, {
                            emissive: {
                                value: new i.Q1f(0)
                            },
                            roughness: {
                                value: 1
                            },
                            metalness: {
                                value: 0
                            },
                            envMapIntensity: {
                                value: 1
                            }
                        }]),
                        vertexShader: o.meshphysical_vert,
                        fragmentShader: o.meshphysical_frag
                    },
                    toon: {
                        uniforms: (0, i.Iit)([l.common, l.aomap, l.lightmap, l.emissivemap, l.bumpmap, l.normalmap, l.displacementmap, l.gradientmap, l.fog, l.lights, {
                            emissive: {
                                value: new i.Q1f(0)
                            }
                        }]),
                        vertexShader: o.meshtoon_vert,
                        fragmentShader: o.meshtoon_frag
                    },
                    matcap: {
                        uniforms: (0, i.Iit)([l.common, l.bumpmap, l.normalmap, l.displacementmap, l.fog, {
                            matcap: {
                                value: null
                            }
                        }]),
                        vertexShader: o.meshmatcap_vert,
                        fragmentShader: o.meshmatcap_frag
                    },
                    points: {
                        uniforms: (0, i.Iit)([l.points, l.fog]),
                        vertexShader: o.points_vert,
                        fragmentShader: o.points_frag
                    },
                    dashed: {
                        uniforms: (0, i.Iit)([l.common, l.fog, {
                            scale: {
                                value: 1
                            },
                            dashSize: {
                                value: 1
                            },
                            totalSize: {
                                value: 2
                            }
                        }]),
                        vertexShader: o.linedashed_vert,
                        fragmentShader: o.linedashed_frag
                    },
                    depth: {
                        uniforms: (0, i.Iit)([l.common, l.displacementmap]),
                        vertexShader: o.depth_vert,
                        fragmentShader: o.depth_frag
                    },
                    normal: {
                        uniforms: (0, i.Iit)([l.common, l.bumpmap, l.normalmap, l.displacementmap, {
                            opacity: {
                                value: 1
                            }
                        }]),
                        vertexShader: o.meshnormal_vert,
                        fragmentShader: o.meshnormal_frag
                    },
                    sprite: {
                        uniforms: (0, i.Iit)([l.sprite, l.fog]),
                        vertexShader: o.sprite_vert,
                        fragmentShader: o.sprite_frag
                    },
                    background: {
                        uniforms: {
                            uvTransform: {
                                value: new i.dwI
                            },
                            t2D: {
                                value: null
                            },
                            backgroundIntensity: {
                                value: 1
                            }
                        },
                        vertexShader: o.background_vert,
                        fragmentShader: o.background_frag
                    },
                    backgroundCube: {
                        uniforms: {
                            envMap: {
                                value: null
                            },
                            backgroundBlurriness: {
                                value: 0
                            },
                            backgroundIntensity: {
                                value: 1
                            },
                            backgroundRotation: {
                                value: new i.dwI
                            }
                        },
                        vertexShader: o.backgroundCube_vert,
                        fragmentShader: o.backgroundCube_frag
                    },
                    cube: {
                        uniforms: {
                            tCube: {
                                value: null
                            },
                            tFlip: {
                                value: -1
                            },
                            opacity: {
                                value: 1
                            }
                        },
                        vertexShader: o.cube_vert,
                        fragmentShader: o.cube_frag
                    },
                    equirect: {
                        uniforms: {
                            tEquirect: {
                                value: null
                            }
                        },
                        vertexShader: o.equirect_vert,
                        fragmentShader: o.equirect_frag
                    },
                    distance: {
                        uniforms: (0, i.Iit)([l.common, l.displacementmap, {
                            referencePosition: {
                                value: new i.Pq0
                            },
                            nearDistance: {
                                value: 1
                            },
                            farDistance: {
                                value: 1e3
                            }
                        }]),
                        vertexShader: o.distance_vert,
                        fragmentShader: o.distance_frag
                    },
                    shadow: {
                        uniforms: (0, i.Iit)([l.lights, l.fog, {
                            color: {
                                value: new i.Q1f(0)
                            },
                            opacity: {
                                value: 1
                            }
                        }]),
                        vertexShader: o.shadow_vert,
                        fragmentShader: o.shadow_frag
                    }
                };
            s.physical = {
                uniforms: (0, i.Iit)([s.standard.uniforms, {
                    clearcoat: {
                        value: 0
                    },
                    clearcoatMap: {
                        value: null
                    },
                    clearcoatMapTransform: {
                        value: new i.dwI
                    },
                    clearcoatNormalMap: {
                        value: null
                    },
                    clearcoatNormalMapTransform: {
                        value: new i.dwI
                    },
                    clearcoatNormalScale: {
                        value: new i.I9Y(1, 1)
                    },
                    clearcoatRoughness: {
                        value: 0
                    },
                    clearcoatRoughnessMap: {
                        value: null
                    },
                    clearcoatRoughnessMapTransform: {
                        value: new i.dwI
                    },
                    dispersion: {
                        value: 0
                    },
                    retroreflectivity: {
                        value: 0
                    },
                    iridescence: {
                        value: 0
                    },
                    iridescenceMap: {
                        value: null
                    },
                    iridescenceMapTransform: {
                        value: new i.dwI
                    },
                    iridescenceIOR: {
                        value: 1.3
                    },
                    iridescenceThicknessMinimum: {
                        value: 100
                    },
                    iridescenceThicknessMaximum: {
                        value: 400
                    },
                    iridescenceThicknessMap: {
                        value: null
                    },
                    iridescenceThicknessMapTransform: {
                        value: new i.dwI
                    },
                    sheen: {
                        value: 0
                    },
                    sheenColor: {
                        value: new i.Q1f(0)
                    },
                    sheenColorMap: {
                        value: null
                    },
                    sheenColorMapTransform: {
                        value: new i.dwI
                    },
                    sheenRoughness: {
                        value: 1
                    },
                    sheenRoughnessMap: {
                        value: null
                    },
                    sheenRoughnessMapTransform: {
                        value: new i.dwI
                    },
                    transmission: {
                        value: 0
                    },
                    transmissionMap: {
                        value: null
                    },
                    transmissionMapTransform: {
                        value: new i.dwI
                    },
                    transmissionSamplerSize: {
                        value: new i.I9Y
                    },
                    transmissionSamplerMap: {
                        value: null
                    },
                    thickness: {
                        value: 0
                    },
                    thicknessMap: {
                        value: null
                    },
                    thicknessMapTransform: {
                        value: new i.dwI
                    },
                    attenuationDistance: {
                        value: 0
                    },
                    attenuationColor: {
                        value: new i.Q1f(0)
                    },
                    specularColor: {
                        value: new i.Q1f(1, 1, 1)
                    },
                    specularColorMap: {
                        value: null
                    },
                    specularColorMapTransform: {
                        value: new i.dwI
                    },
                    specularIntensity: {
                        value: 1
                    },
                    specularIntensityMap: {
                        value: null
                    },
                    specularIntensityMapTransform: {
                        value: new i.dwI
                    },
                    anisotropyVector: {
                        value: new i.I9Y
                    },
                    anisotropyMap: {
                        value: null
                    },
                    anisotropyMapTransform: {
                        value: new i.dwI
                    }
                }]),
                vertexShader: o.meshphysical_vert,
                fragmentShader: o.meshphysical_frag
            };
            let c = {
                    r: 0,
                    b: 0,
                    g: 0
                },
                d = new i.kn4,
                u = new i.dwI;

            function f(e, n, t, r, a, o) {
                let l, f, p = new i.Q1f(0),
                    m = +(!0 !== a),
                    h = null,
                    _ = 0,
                    g = null;

                function v(e) {
                    let t = !0 === e.isScene ? e.background : null;
                    if (t && t.isTexture) {
                        let i = e.backgroundBlurriness > 0;
                        t = n.get(t, i)
                    }
                    return t
                }

                function S(n, r) {
                    n.getRGB(c, (0, i._Ut)(e)), t.buffers.color.setClear(c.r, c.g, c.b, r, o)
                }
                return {
                    getClearColor: function() {
                        return p
                    },
                    setClearColor: function(e, n = 1) {
                        p.set(e), S(p, m = n)
                    },
                    getClearAlpha: function() {
                        return m
                    },
                    setClearAlpha: function(e) {
                        S(p, m = e)
                    },
                    render: function(n) {
                        let i = !1,
                            r = v(n);
                        null === r ? S(p, m) : r && r.isColor && (S(r, 1), i = !0);
                        let a = e.xr.getEnvironmentBlendMode();
                        "additive" === a ? t.buffers.color.setClear(0, 0, 0, 1, o) : "alpha-blend" === a && t.buffers.color.setClear(0, 0, 0, 0, o), (e.autoClear || i) && (t.buffers.depth.setTest(!0), t.buffers.depth.setMask(!0), t.buffers.color.setMask(!0), e.clear(e.autoClearColor, e.autoClearDepth, e.autoClearStencil))
                    },
                    addToRenderList: function(n, t) {
                        let a = v(t);
                        a && (a.isCubeTexture || a.mapping === i.Om) ? (void 0 === f && ((f = new i.eaF(new i.iNn(1, 1, 1), new i.BKk({
                            name: "BackgroundCubeMaterial",
                            uniforms: (0, i.lxW)(s.backgroundCube.uniforms),
                            vertexShader: s.backgroundCube.vertexShader,
                            fragmentShader: s.backgroundCube.fragmentShader,
                            side: i.hsX,
                            depthTest: !1,
                            depthWrite: !1,
                            fog: !1,
                            allowOverride: !1
                        }))).geometry.deleteAttribute("normal"), f.geometry.deleteAttribute("uv"), f.onBeforeRender = function(e, n, t) {
                            this.matrixWorld.copyPosition(t.matrixWorld)
                        }, Object.defineProperty(f.material, "envMap", {
                            get: function() {
                                return this.uniforms.envMap.value
                            }
                        }), r.update(f)), f.material.uniforms.envMap.value = a, f.material.uniforms.backgroundBlurriness.value = t.backgroundBlurriness, f.material.uniforms.backgroundIntensity.value = t.backgroundIntensity, f.material.uniforms.backgroundRotation.value.setFromMatrix4(d.makeRotationFromEuler(t.backgroundRotation)).transpose(), a.isCubeTexture && !1 === a.isRenderTargetTexture && f.material.uniforms.backgroundRotation.value.premultiply(u), f.material.toneMapped = i.ppV.getTransfer(a.colorSpace) !== i.KLL, (h !== a || _ !== a.version || g !== e.toneMapping) && (f.material.needsUpdate = !0, h = a, _ = a.version, g = e.toneMapping), f.layers.enableAll(), n.unshift(f, f.geometry, f.material, 0, 0, null)) : a && a.isTexture && (void 0 === l && ((l = new i.eaF(new i.bdM(2, 2), new i.BKk({
                            name: "BackgroundMaterial",
                            uniforms: (0, i.lxW)(s.background.uniforms),
                            vertexShader: s.background.vertexShader,
                            fragmentShader: s.background.fragmentShader,
                            side: i.hB5,
                            depthTest: !1,
                            depthWrite: !1,
                            fog: !1,
                            allowOverride: !1
                        }))).geometry.deleteAttribute("normal"), Object.defineProperty(l.material, "map", {
                            get: function() {
                                return this.uniforms.t2D.value
                            }
                        }), r.update(l)), l.material.uniforms.t2D.value = a, l.material.uniforms.backgroundIntensity.value = t.backgroundIntensity, l.material.toneMapped = i.ppV.getTransfer(a.colorSpace) !== i.KLL, !0 === a.matrixAutoUpdate && a.updateMatrix(), l.material.uniforms.uvTransform.value.copy(a.matrix), (h !== a || _ !== a.version || g !== e.toneMapping) && (l.material.needsUpdate = !0, h = a, _ = a.version, g = e.toneMapping), l.layers.enableAll(), n.unshift(l, l.geometry, l.material, 0, 0, null))
                    },
                    dispose: function() {
                        void 0 !== f && (f.geometry.dispose(), f.material.dispose(), f = void 0), void 0 !== l && (l.geometry.dispose(), l.material.dispose(), l = void 0)
                    }
                }
            }

            function p(e, n) {
                let t = e.getParameter(e.MAX_VERTEX_ATTRIBS),
                    r = {},
                    a = d(null),
                    o = a,
                    l = !1;

                function s(n) {
                    return e.bindVertexArray(n)
                }

                function c(n) {
                    return e.deleteVertexArray(n)
                }

                function d(e) {
                    let n = [],
                        i = [],
                        r = [];
                    for (let e = 0; e < t; e++) n[e] = 0, i[e] = 0, r[e] = 0;
                    return {
                        geometry: null,
                        program: null,
                        wireframe: !1,
                        newAttributes: n,
                        enabledAttributes: i,
                        attributeDivisors: r,
                        object: e,
                        attributes: {},
                        index: null
                    }
                }

                function u() {
                    let e = o.newAttributes;
                    for (let n = 0, t = e.length; n < t; n++) e[n] = 0
                }

                function f(e) {
                    p(e, 0)
                }

                function p(n, t) {
                    let i = o.newAttributes,
                        r = o.enabledAttributes,
                        a = o.attributeDivisors;
                    i[n] = 1, 0 === r[n] && (e.enableVertexAttribArray(n), r[n] = 1), a[n] !== t && (e.vertexAttribDivisor(n, t), a[n] = t)
                }

                function m() {
                    let n = o.newAttributes,
                        t = o.enabledAttributes;
                    for (let i = 0, r = t.length; i < r; i++) t[i] !== n[i] && (e.disableVertexAttribArray(i), t[i] = 0)
                }

                function h(n, t, i, r, a, o, l) {
                    !0 === l ? e.vertexAttribIPointer(n, t, i, a, o) : e.vertexAttribPointer(n, t, i, r, a, o)
                }

                function _() {
                    g(), l = !0, o !== a && s((o = a).object)
                }

                function g() {
                    a.geometry = null, a.program = null, a.wireframe = !1
                }
                return {
                    setup: function(t, a, c, _, g) {
                        var v, S, E;
                        let M, T, x, R, A, b, C = !1,
                            P = (v = t, S = _, E = c, M = !0 === a.wireframe, void 0 === (T = r[S.id]) && (T = {}, r[S.id] = T), void 0 === (R = T[x = !0 === v.isInstancedMesh ? v.id : 0]) && (R = {}, T[x] = R), void 0 === (A = R[E.id]) && (A = {}, R[E.id] = A), void 0 === (b = A[M]) && (b = d(e.createVertexArray()), A[M] = b), b);
                        o !== P && s((o = P).object), (C = function(e, n, t, i) {
                            let r = o.attributes,
                                a = n.attributes,
                                l = 0,
                                s = t.getAttributes();
                            for (let n in s)
                                if (s[n].location >= 0) {
                                    let t = r[n],
                                        i = a[n];
                                    if (void 0 === i && ("instanceMatrix" === n && e.instanceMatrix && (i = e.instanceMatrix), "instanceColor" === n && e.instanceColor && (i = e.instanceColor)), void 0 === t || t.attribute !== i || i && t.data !== i.data) return !0;
                                    l++
                                }
                            return o.attributesNum !== l || o.index !== i
                        }(t, _, c, g)) && function(e, n, t, i) {
                            let r = {},
                                a = n.attributes,
                                l = 0,
                                s = t.getAttributes();
                            for (let n in s)
                                if (s[n].location >= 0) {
                                    let t = a[n];
                                    void 0 === t && ("instanceMatrix" === n && e.instanceMatrix && (t = e.instanceMatrix), "instanceColor" === n && e.instanceColor && (t = e.instanceColor));
                                    let i = {};
                                    i.attribute = t, t && t.data && (i.data = t.data), r[n] = i, l++
                                }
                            o.attributes = r, o.attributesNum = l, o.index = i
                        }(t, _, c, g), null !== g && n.update(g, e.ELEMENT_ARRAY_BUFFER), (C || l) && (l = !1, function(t, r, a, o) {
                            u();
                            let l = o.attributes,
                                s = a.getAttributes(),
                                c = r.defaultAttributeValues;
                            for (let r in s) {
                                let a = s[r];
                                if (a.location >= 0) {
                                    let s = l[r];
                                    if (void 0 === s && ("instanceMatrix" === r && t.instanceMatrix && (s = t.instanceMatrix), "instanceColor" === r && t.instanceColor && (s = t.instanceColor)), void 0 !== s) {
                                        let r = s.normalized,
                                            l = s.itemSize,
                                            c = n.get(s);
                                        if (void 0 === c) continue;
                                        let d = c.buffer,
                                            u = c.type,
                                            m = c.bytesPerElement,
                                            _ = u === e.INT || u === e.UNSIGNED_INT || s.gpuType === i.Yuy;
                                        if (s.isInterleavedBufferAttribute) {
                                            let n = s.data,
                                                i = n.stride,
                                                c = s.offset;
                                            if (n.isInstancedInterleavedBuffer) {
                                                for (let e = 0; e < a.locationSize; e++) p(a.location + e, n.meshPerAttribute);
                                                !0 !== t.isInstancedMesh && void 0 === o._maxInstanceCount && (o._maxInstanceCount = n.meshPerAttribute * n.count)
                                            } else
                                                for (let e = 0; e < a.locationSize; e++) f(a.location + e);
                                            e.bindBuffer(e.ARRAY_BUFFER, d);
                                            for (let e = 0; e < a.locationSize; e++) h(a.location + e, l / a.locationSize, u, r, i * m, (c + l / a.locationSize * e) * m, _)
                                        } else {
                                            if (s.isInstancedBufferAttribute) {
                                                for (let e = 0; e < a.locationSize; e++) p(a.location + e, s.meshPerAttribute);
                                                !0 !== t.isInstancedMesh && void 0 === o._maxInstanceCount && (o._maxInstanceCount = s.meshPerAttribute * s.count)
                                            } else
                                                for (let e = 0; e < a.locationSize; e++) f(a.location + e);
                                            e.bindBuffer(e.ARRAY_BUFFER, d);
                                            for (let e = 0; e < a.locationSize; e++) h(a.location + e, l / a.locationSize, u, r, l * m, l / a.locationSize * e * m, _)
                                        }
                                    } else if (void 0 !== c) {
                                        let n = c[r];
                                        if (void 0 !== n) switch (n.length) {
                                            case 2:
                                                e.vertexAttrib2fv(a.location, n);
                                                break;
                                            case 3:
                                                e.vertexAttrib3fv(a.location, n);
                                                break;
                                            case 4:
                                                e.vertexAttrib4fv(a.location, n);
                                                break;
                                            default:
                                                e.vertexAttrib1fv(a.location, n)
                                        }
                                    }
                                }
                            }
                            m()
                        }(t, a, c, _), null !== g && e.bindBuffer(e.ELEMENT_ARRAY_BUFFER, n.get(g).buffer))
                    },
                    reset: _,
                    resetDefaultState: g,
                    dispose: function() {
                        for (let e in _(), r) {
                            let n = r[e];
                            for (let e in n) {
                                let t = n[e];
                                for (let e in t) {
                                    let n = t[e];
                                    for (let e in n) c(n[e].object), delete n[e];
                                    delete t[e]
                                }
                            }
                            delete r[e]
                        }
                    },
                    releaseStatesOfGeometry: function(e) {
                        if (void 0 === r[e.id]) return;
                        let n = r[e.id];
                        for (let e in n) {
                            let t = n[e];
                            for (let e in t) {
                                let n = t[e];
                                for (let e in n) c(n[e].object), delete n[e];
                                delete t[e]
                            }
                        }
                        delete r[e.id]
                    },
                    releaseStatesOfObject: function(e) {
                        for (let n in r) {
                            let t = r[n],
                                i = !0 === e.isInstancedMesh ? e.id : 0,
                                a = t[i];
                            if (void 0 !== a) {
                                for (let e in a) {
                                    let n = a[e];
                                    for (let e in n) c(n[e].object), delete n[e];
                                    delete a[e]
                                }
                                delete t[i], 0 === Object.keys(t).length && delete r[n]
                            }
                        }
                    },
                    releaseStatesOfProgram: function(e) {
                        for (let n in r) {
                            let t = r[n];
                            for (let n in t) {
                                let i = t[n];
                                if (void 0 === i[e.id]) continue;
                                let r = i[e.id];
                                for (let e in r) c(r[e].object), delete r[e];
                                delete i[e.id]
                            }
                        }
                    },
                    initAttributes: u,
                    enableAttribute: f,
                    disableUnusedAttributes: m
                }
            }

            function m(e, n, t) {
                let i;
                this.setMode = function(e) {
                    i = e
                }, this.render = function(n, r) {
                    e.drawArrays(i, n, r), t.update(r, i, 1)
                }, this.renderInstances = function(n, r, a) {
                    0 !== a && (e.drawArraysInstanced(i, n, r, a), t.update(r, i, a))
                }, this.renderMultiDraw = function(e, r, a) {
                    if (0 === a) return;
                    n.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i, e, 0, r, 0, a);
                    let o = 0;
                    for (let e = 0; e < a; e++) o += r[e];
                    t.update(o, i, 1)
                }
            }

            function h(e, n, t, r) {
                let a;

                function o(n) {
                    if ("highp" === n) {
                        if (e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.HIGH_FLOAT).precision > 0 && e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT).precision > 0) return "highp";
                        n = "mediump"
                    }
                    return "mediump" === n && e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.MEDIUM_FLOAT).precision > 0 && e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.MEDIUM_FLOAT).precision > 0 ? "mediump" : "lowp"
                }
                let l = void 0 !== t.precision ? t.precision : "highp",
                    s = o(l);
                s !== l && ((0, i.R8M)("WebGLRenderer:", l, "not supported, using", s, "instead."), l = s);
                let c = !0 === t.logarithmicDepthBuffer,
                    d = !0 === t.reversedDepthBuffer && n.has("EXT_clip_control");
                return !0 === t.reversedDepthBuffer && !1 === d && (0, i.R8M)("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."), {
                    isWebGL2: !0,
                    getMaxAnisotropy: function() {
                        if (void 0 !== a) return a;
                        if (!0 === n.has("EXT_texture_filter_anisotropic")) {
                            let t = n.get("EXT_texture_filter_anisotropic");
                            a = e.getParameter(t.MAX_TEXTURE_MAX_ANISOTROPY_EXT)
                        } else a = 0;
                        return a
                    },
                    getMaxPrecision: o,
                    textureFormatReadable: function(n) {
                        return n === i.GWd || r.convert(n) === e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT)
                    },
                    textureTypeReadable: function(t) {
                        let a = t === i.ix0 && (n.has("EXT_color_buffer_half_float") || n.has("EXT_color_buffer_float"));
                        return t === i.OUM || t === i.RQf || !!a || r.convert(t) === e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE)
                    },
                    precision: l,
                    logarithmicDepthBuffer: c,
                    reversedDepthBuffer: d,
                    maxTextures: e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),
                    maxVertexTextures: e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),
                    maxTextureSize: e.getParameter(e.MAX_TEXTURE_SIZE),
                    maxCubemapSize: e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),
                    maxAttributes: e.getParameter(e.MAX_VERTEX_ATTRIBS),
                    maxVertexUniforms: e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),
                    maxVaryings: e.getParameter(e.MAX_VARYING_VECTORS),
                    maxFragmentUniforms: e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),
                    maxSamples: e.getParameter(e.MAX_SAMPLES),
                    samples: e.getParameter(e.SAMPLES)
                }
            }

            function _(e) {
                let n = this,
                    t = null,
                    r = 0,
                    a = !1,
                    o = !1,
                    l = new i.Zcv,
                    s = new i.dwI,
                    c = {
                        value: null,
                        needsUpdate: !1
                    };

                function d(e, t, i, r) {
                    let a = null !== e ? e.length : 0,
                        o = null;
                    if (0 !== a) {
                        if (o = c.value, !0 !== r || null === o) {
                            let n = i + 4 * a,
                                r = t.matrixWorldInverse;
                            s.getNormalMatrix(r), (null === o || o.length < n) && (o = new Float32Array(n));
                            for (let n = 0, t = i; n !== a; ++n, t += 4) l.copy(e[n]).applyMatrix4(r, s), l.normal.toArray(o, t), o[t + 3] = l.constant
                        }
                        c.value = o, c.needsUpdate = !0
                    }
                    return n.numPlanes = a, n.numIntersection = 0, o
                }
                this.uniform = c, this.numPlanes = 0, this.numIntersection = 0, this.init = function(e, n) {
                    let t = 0 !== e.length || n || 0 !== r || a;
                    return a = n, r = e.length, t
                }, this.beginShadows = function() {
                    o = !0, d(null)
                }, this.endShadows = function() {
                    o = !1
                }, this.setGlobalState = function(e, n) {
                    t = d(e, n, 0)
                }, this.setState = function(i, l, s) {
                    let u = i.clippingPlanes,
                        f = i.clipIntersection,
                        p = i.clipShadows,
                        m = e.get(i);
                    if (a && null !== u && 0 !== u.length && (!o || p)) {
                        let e = o ? 0 : r,
                            n = 4 * e,
                            i = m.clippingState || null;
                        c.value = i, i = d(u, l, n, s);
                        for (let e = 0; e !== n; ++e) i[e] = t[e];
                        m.clippingState = i, this.numIntersection = f ? this.numPlanes : 0, this.numPlanes += e
                    } else o ? d(null) : (c.value !== t && (c.value = t, c.needsUpdate = r > 0), n.numPlanes = r, n.numIntersection = 0)
                }
            }
            u.set(-1, 0, 0, 0, 1, 0, 0, 0, 1);
            let g = new i.qUd,
                v = new i.Q1f,
                S = null,
                E = 0,
                M = 0,
                T = !1,
                x = new i.Pq0,
                R = new i.Pq0;
            class A {
                constructor(e) {
                    this._renderer = e, this._pingPongRenderTarget = null, this._lodMax = 0, this._cubeSize = 0, this._sizeLods = [], this._lodMeshes = [], this._backgroundBox = null, this._cubemapMaterial = null, this._equirectMaterial = null, this._blurMaterial = null, this._ggxMaterial = null
                }
                fromScene(e, n = 0, t = .1, i = 100, r = {}) {
                    let {
                        size: a = 256,
                        position: o = x
                    } = r;
                    S = this._renderer.getRenderTarget(), E = this._renderer.getActiveCubeFace(), M = this._renderer.getActiveMipmapLevel(), T = this._renderer.xr.enabled, this._renderer.xr.enabled = !1, this._setSize(a);
                    let l = this._allocateTargets();
                    return l.depthBuffer = !0, this._sceneToCubeUV(e, t, i, l, o), n > 0 && this._blur(l, 0, 0, n), this._applyPMREM(l), this._cleanup(l), l
                }
                fromEquirectangular(e, n = null) {
                    return this._fromTexture(e, n)
                }
                fromCubemap(e, n = null) {
                    return this._fromTexture(e, n)
                }
                compileCubemapShader() {
                    null === this._cubemapMaterial && (this._cubemapMaterial = L(), this._compileMaterial(this._cubemapMaterial))
                }
                compileEquirectangularShader() {
                    null === this._equirectMaterial && (this._equirectMaterial = P(), this._compileMaterial(this._equirectMaterial))
                }
                dispose() {
                    this._dispose(), null !== this._cubemapMaterial && this._cubemapMaterial.dispose(), null !== this._equirectMaterial && this._equirectMaterial.dispose(), null !== this._backgroundBox && (this._backgroundBox.geometry.dispose(), this._backgroundBox.material.dispose())
                }
                _setSize(e) {
                    this._lodMax = Math.floor(Math.log2(e)), this._cubeSize = Math.pow(2, this._lodMax)
                }
                _dispose() {
                    null !== this._blurMaterial && this._blurMaterial.dispose(), null !== this._ggxMaterial && this._ggxMaterial.dispose(), null !== this._pingPongRenderTarget && this._pingPongRenderTarget.dispose();
                    for (let e = 0; e < this._lodMeshes.length; e++) this._lodMeshes[e].geometry.dispose()
                }
                _cleanup(e) {
                    this._renderer.setRenderTarget(S, E, M), this._renderer.xr.enabled = T, e.scissorTest = !1, C(e, 0, 0, e.width, e.height)
                }
                _fromTexture(e, n) {
                    e.mapping === i.hy7 || e.mapping === i.xFO ? this._setSize(0 === e.image.length ? 16 : e.image[0].width || e.image[0].image.width) : this._setSize(e.image.width / 4), S = this._renderer.getRenderTarget(), E = this._renderer.getActiveCubeFace(), M = this._renderer.getActiveMipmapLevel(), T = this._renderer.xr.enabled, this._renderer.xr.enabled = !1;
                    let t = n || this._allocateTargets();
                    return this._textureToCubeUV(e, t), this._applyPMREM(t), this._cleanup(t), t
                }
                _allocateTargets() {
                    let e = 3 * Math.max(this._cubeSize, 112),
                        n = 4 * this._cubeSize,
                        t = {
                            magFilter: i.k6q,
                            minFilter: i.k6q,
                            generateMipmaps: !1,
                            type: i.ix0,
                            format: i.GWd,
                            colorSpace: i.Zr2,
                            depthBuffer: !1
                        },
                        r = b(e, n, t);
                    if (null === this._pingPongRenderTarget || this._pingPongRenderTarget.width !== e || this._pingPongRenderTarget.height !== n) {
                        var a, o, l, s, c, d;
                        null !== this._pingPongRenderTarget && this._dispose(), this._pingPongRenderTarget = b(e, n, t);
                        let {
                            _lodMax: r
                        } = this;
                        ({
                            lodMeshes: this._lodMeshes,
                            sizeLods: this._sizeLods
                        } = function(e) {
                            let n = [],
                                t = [],
                                r = e,
                                a = e - 4 + 1 + 6;
                            for (let e = 0; e < a; e++) {
                                let e = Math.pow(2, r);
                                n.push(e);
                                let a = 1 / (e - 2),
                                    o = -a,
                                    l = 1 + a,
                                    s = [o, o, l, o, l, l, o, o, l, l, o, l],
                                    c = new Float32Array(108),
                                    d = new Float32Array(108);
                                for (let e = 0; e < 6; e++) {
                                    let n = e % 3 * 2 / 3 - 1,
                                        t = e > 2 ? 0 : -1,
                                        i = [n, t, 0, n + 2 / 3, t, 0, n + 2 / 3, t + 1, 0, n, t, 0, n + 2 / 3, t + 1, 0, n, t + 1, 0];
                                    c.set(i, 18 * e);
                                    for (let n = 0; n < 6; n++) {
                                        let t = 2 * s[2 * n] - 1,
                                            i = 2 * s[2 * n + 1] - 1;
                                        0 === e ? R.set(1, i, t) : 1 === e ? R.set(-t, 1, -i) : 2 === e ? R.set(-t, i, 1) : 3 === e ? R.set(-1, i, -t) : 4 === e ? R.set(-t, -1, i) : R.set(t, i, -1), R.toArray(d, (6 * e + n) * 3)
                                    }
                                }
                                let u = new i.LoY;
                                u.setAttribute("position", new i.THS(c, 3)), u.setAttribute("outputDirection", new i.THS(d, 3)), t.push(new i.eaF(u, null)), r > 4 && r--
                            }
                            return {
                                lodMeshes: t,
                                sizeLods: n
                            }
                        }(r)), this._blurMaterial = (a = r, o = e, l = n, new i.BKk({
                            name: "SphericalGaussianBlur",
                            defines: {
                                SAMPLES: 20,
                                CUBEUV_TEXEL_WIDTH: 1 / o,
                                CUBEUV_TEXEL_HEIGHT: 1 / l,
                                CUBEUV_MAX_MIP: `${a}.0`
                            },
                            uniforms: {
                                envMap: {
                                    value: null
                                },
                                sigma: {
                                    value: 0
                                },
                                mipInt: {
                                    value: 0
                                }
                            },
                            vertexShader: w(),
                            fragmentShader: `

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,
                            blending: i.XIg,
                            depthTest: !1,
                            depthWrite: !1
                        })), this._ggxMaterial = (s = r, c = e, d = n, new i.BKk({
                            name: "PMREMGGXConvolution",
                            defines: {
                                GGX_SAMPLES: 256,
                                CUBEUV_TEXEL_WIDTH: 1 / c,
                                CUBEUV_TEXEL_HEIGHT: 1 / d,
                                CUBEUV_MAX_MIP: `${s}.0`
                            },
                            uniforms: {
                                envMap: {
                                    value: null
                                },
                                roughness: {
                                    value: 0
                                },
                                mipInt: {
                                    value: 0
                                }
                            },
                            vertexShader: w(),
                            fragmentShader: `

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,
                            blending: i.XIg,
                            depthTest: !1,
                            depthWrite: !1
                        }))
                    }
                    return r
                }
                _compileMaterial(e) {
                    let n = new i.eaF(new i.LoY, e);
                    this._renderer.compile(n, g)
                }
                _sceneToCubeUV(e, n, t, r, a) {
                    let o = new i.ubm(90, 1, n, t),
                        l = [1, -1, 1, 1, 1, 1],
                        s = [1, 1, 1, -1, -1, -1],
                        c = this._renderer,
                        d = c.autoClear,
                        u = c.toneMapping;
                    c.getClearColor(v), c.toneMapping = i.y_p, c.autoClear = !1, c.state.buffers.depth.getReversed() && (c.setRenderTarget(r), c.clearDepth(), c.setRenderTarget(null)), null === this._backgroundBox && (this._backgroundBox = new i.eaF(new i.iNn, new i.V9B({
                        name: "PMREM.Background",
                        side: i.hsX,
                        depthWrite: !1,
                        depthTest: !1
                    })));
                    let f = this._backgroundBox,
                        p = f.material,
                        m = !1,
                        h = e.background;
                    h ? h.isColor && (p.color.copy(h), e.background = null, m = !0) : (p.color.copy(v), m = !0);
                    for (let n = 0; n < 6; n++) {
                        let t = n % 3;
                        0 === t ? (o.up.set(0, l[n], 0), o.position.set(a.x, a.y, a.z), o.lookAt(a.x + s[n], a.y, a.z)) : 1 === t ? (o.up.set(0, 0, l[n]), o.position.set(a.x, a.y, a.z), o.lookAt(a.x, a.y + s[n], a.z)) : (o.up.set(0, l[n], 0), o.position.set(a.x, a.y, a.z), o.lookAt(a.x, a.y, a.z + s[n]));
                        let i = this._cubeSize;
                        C(r, t * i, n > 2 ? i : 0, i, i), c.setRenderTarget(r), m && c.render(f, o), c.render(e, o)
                    }
                    c.toneMapping = u, c.autoClear = d, e.background = h
                }
                _textureToCubeUV(e, n) {
                    let t = this._renderer,
                        r = e.mapping === i.hy7 || e.mapping === i.xFO;
                    r ? (null === this._cubemapMaterial && (this._cubemapMaterial = L()), this._cubemapMaterial.uniforms.flipEnvMap.value = !1 === e.isRenderTargetTexture ? -1 : 1) : null === this._equirectMaterial && (this._equirectMaterial = P());
                    let a = r ? this._cubemapMaterial : this._equirectMaterial,
                        o = this._lodMeshes[0];
                    o.material = a, a.uniforms.envMap.value = e;
                    let l = this._cubeSize;
                    C(n, 0, 0, 3 * l, 2 * l), t.setRenderTarget(n), t.render(o, g)
                }
                _applyPMREM(e) {
                    let n = this._renderer,
                        t = n.autoClear;
                    n.autoClear = !1;
                    let i = this._lodMeshes.length;
                    for (let n = 1; n < i; n++) this._applyGGXFilter(e, n - 1, n);
                    n.autoClear = t
                }
                _applyGGXFilter(e, n, t) {
                    let i = this._renderer,
                        r = this._pingPongRenderTarget,
                        a = this._ggxMaterial,
                        o = this._lodMeshes[t];
                    o.material = a;
                    let l = a.uniforms,
                        s = t / (this._lodMeshes.length - 1),
                        c = n / (this._lodMeshes.length - 1),
                        d = Math.sqrt(s * s - c * c),
                        {
                            _lodMax: u
                        } = this,
                        f = this._sizeLods[t],
                        p = 3 * f * (t > u - 4 ? t - u + 4 : 0),
                        m = 4 * (this._cubeSize - f);
                    l.envMap.value = e.texture, l.roughness.value = 1.25 * s * d, l.mipInt.value = u - n, C(r, p, m, 3 * f, 2 * f), i.setRenderTarget(r), i.render(o, g), l.envMap.value = r.texture, l.roughness.value = 0, l.mipInt.value = u - t, C(e, p, m, 3 * f, 2 * f), i.setRenderTarget(e), i.render(o, g)
                }
                _blur(e, n, t, i) {
                    let r = this._pingPongRenderTarget,
                        a = Math.min(i, Math.PI) / Math.SQRT2;
                    this._blurPass(e, r, n, t, a), this._blurPass(r, e, t, t, a)
                }
                _blurPass(e, n, t, i, r) {
                    let a = this._renderer,
                        o = this._blurMaterial,
                        l = this._lodMeshes[i];
                    l.material = o;
                    let s = o.uniforms;
                    s.envMap.value = e.texture, s.sigma.value = r, s.mipInt.value = this._lodMax - t;
                    let c = this._sizeLods[i];
                    C(n, 3 * c * (i > this._lodMax - 4 ? i - this._lodMax + 4 : 0), 4 * (this._cubeSize - c), 3 * c, 2 * c), a.setRenderTarget(n), a.render(l, g)
                }
            }

            function b(e, n, t) {
                let r = new i.nWS(e, n, t);
                return r.texture.mapping = i.Om, r.texture.name = "PMREM.cubeUv", r.scissorTest = !0, r
            }

            function C(e, n, t, i, r) {
                e.viewport.set(n, t, i, r), e.scissor.set(n, t, i, r)
            }

            function P() {
                return new i.BKk({
                    name: "EquirectangularToCubeUV",
                    uniforms: {
                        envMap: {
                            value: null
                        }
                    },
                    vertexShader: w(),
                    fragmentShader: `

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,
                    blending: i.XIg,
                    depthTest: !1,
                    depthWrite: !1
                })
            }

            function L() {
                return new i.BKk({
                    name: "CubemapToCubeUV",
                    uniforms: {
                        envMap: {
                            value: null
                        },
                        flipEnvMap: {
                            value: -1
                        }
                    },
                    vertexShader: w(),
                    fragmentShader: `

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,
                    blending: i.XIg,
                    depthTest: !1,
                    depthWrite: !1
                })
            }

            function w() {
                return `

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`
            }
            class U extends i.nWS {
                constructor(e = 1, n = {}) {
                    super(e, e, n), this.isWebGLCubeRenderTarget = !0;
                    const t = {
                        width: e,
                        height: e,
                        depth: 1
                    };
                    this.texture = new i.b4q([t, t, t, t, t, t]), this._setTextureOptions(n), this.texture.isRenderTargetTexture = !0
                }
                fromEquirectangularTexture(e, n) {
                    this.texture.type = n.type, this.texture.colorSpace = n.colorSpace, this.texture.generateMipmaps = n.generateMipmaps, this.texture.minFilter = n.minFilter, this.texture.magFilter = n.magFilter;
                    let t = {
                            uniforms: {
                                tEquirect: {
                                    value: null
                                }
                            },
                            vertexShader: `

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,
                            fragmentShader: `

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`
                        },
                        r = new i.iNn(5, 5, 5),
                        a = new i.BKk({
                            name: "CubemapFromEquirect",
                            uniforms: (0, i.lxW)(t.uniforms),
                            vertexShader: t.vertexShader,
                            fragmentShader: t.fragmentShader,
                            side: i.hsX,
                            blending: i.XIg
                        });
                    a.uniforms.tEquirect.value = n;
                    let o = new i.eaF(r, a),
                        l = n.minFilter;
                    return n.minFilter === i.$_I && (n.minFilter = i.k6q), new i.F1T(1, 10, this).update(e, o), n.minFilter = l, o.geometry.dispose(), o.material.dispose(), this
                }
                clear(e, n = !0, t = !0, i = !0) {
                    let r = e.getRenderTarget();
                    for (let r = 0; r < 6; r++) e.setRenderTarget(this, r), e.clear(n, t, i);
                    e.setRenderTarget(r)
                }
            }

            function I(e) {
                let n = new WeakMap,
                    t = new WeakMap,
                    r = null;

                function a(e, n) {
                    return n === i.wfO ? e.mapping = i.hy7 : n === i.uV5 && (e.mapping = i.xFO), e
                }

                function o(e) {
                    let t = e.target;
                    t.removeEventListener("dispose", o);
                    let i = n.get(t);
                    void 0 !== i && (n.delete(t), i.dispose())
                }

                function l(e) {
                    let n = e.target;
                    n.removeEventListener("dispose", l);
                    let i = t.get(n);
                    void 0 !== i && (t.delete(n), i.dispose())
                }
                return {
                    get: function(s, c = !1) {
                        return null == s ? null : c ? function(n) {
                            if (n && n.isTexture) {
                                let a = n.mapping,
                                    o = a === i.wfO || a === i.uV5,
                                    s = a === i.hy7 || a === i.xFO;
                                if (o || s) {
                                    let i = t.get(n),
                                        a = void 0 !== i ? i.texture.pmremVersion : 0;
                                    if (n.isRenderTargetTexture && n.pmremVersion !== a) return null === r && (r = new A(e)), (i = o ? r.fromEquirectangular(n, i) : r.fromCubemap(n, i)).texture.pmremVersion = n.pmremVersion, t.set(n, i), i.texture; {
                                        if (void 0 !== i) return i.texture;
                                        let a = n.image;
                                        return o && a && a.height > 0 || s && a && function(e) {
                                            let n = 0;
                                            for (let t = 0; t < 6; t++) void 0 !== e[t] && n++;
                                            return 6 === n
                                        }(a) ? (null === r && (r = new A(e)), (i = o ? r.fromEquirectangular(n) : r.fromCubemap(n)).texture.pmremVersion = n.pmremVersion, t.set(n, i), n.addEventListener("dispose", l), i.texture) : null
                                    }
                                }
                            }
                            return n
                        }(s) : function(t) {
                            if (t && t.isTexture) {
                                let r = t.mapping;
                                if (r === i.wfO || r === i.uV5)
                                    if (n.has(t)) return a(n.get(t).texture, t.mapping);
                                    else {
                                        let i = t.image;
                                        if (!i || !(i.height > 0)) return null; {
                                            let r = new U(i.height);
                                            return r.fromEquirectangularTexture(e, t), n.set(t, r), t.addEventListener("dispose", o), a(r.texture, t.mapping)
                                        }
                                    }
                            }
                            return t
                        }(s)
                    },
                    dispose: function() {
                        n = new WeakMap, t = new WeakMap, null !== r && (r.dispose(), r = null)
                    }
                }
            }

            function D(e) {
                let n = {};

                function t(t) {
                    if (void 0 !== n[t]) return n[t];
                    let i = e.getExtension(t);
                    return n[t] = i, i
                }
                return {
                    has: function(e) {
                        return null !== t(e)
                    },
                    init: function() {
                        t("EXT_color_buffer_float"), t("WEBGL_clip_cull_distance"), t("OES_texture_float_linear"), t("EXT_color_buffer_half_float"), t("WEBGL_multisampled_render_to_texture"), t("WEBGL_render_shared_exponent")
                    },
                    get: function(e) {
                        let n = t(e);
                        return null === n && (0, i.mcG)("WebGLRenderer: " + e + " extension not supported."), n
                    }
                }
            }

            function N(e, n, t, r) {
                let a = {},
                    o = new WeakMap;

                function l(e) {
                    let i = e.target;
                    for (let e in null !== i.index && n.remove(i.index), i.attributes) n.remove(i.attributes[e]);
                    i.removeEventListener("dispose", l), delete a[i.id];
                    let s = o.get(i);
                    s && (n.remove(s), o.delete(i)), r.releaseStatesOfGeometry(i), !0 === i.isInstancedBufferGeometry && delete i._maxInstanceCount, t.memory.geometries--
                }

                function s(e) {
                    let t = [],
                        r = e.index,
                        a = e.attributes.position,
                        l = 0;
                    if (void 0 === a) return;
                    if (null !== r) {
                        let e = r.array;
                        l = r.version;
                        for (let n = 0, i = e.length; n < i; n += 3) {
                            let i = e[n + 0],
                                r = e[n + 1],
                                a = e[n + 2];
                            t.push(i, r, r, a, a, i)
                        }
                    } else {
                        let e = a.array;
                        l = a.version;
                        for (let n = 0, i = e.length / 3 - 1; n < i; n += 3) {
                            let e = n + 0,
                                i = n + 1,
                                r = n + 2;
                            t.push(e, i, i, r, r, e)
                        }
                    }
                    let s = new(a.count >= 65535 ? i.MW4 : i.A$4)(t, 1);
                    s.version = l;
                    let c = o.get(e);
                    c && n.remove(c), o.set(e, s)
                }
                return {
                    get: function(e, n) {
                        return !0 === a[n.id] || (n.addEventListener("dispose", l), a[n.id] = !0, t.memory.geometries++), n
                    },
                    update: function(t) {
                        let i = t.attributes;
                        for (let t in i) n.update(i[t], e.ARRAY_BUFFER)
                    },
                    getWireframeAttribute: function(e) {
                        let n = o.get(e);
                        if (n) {
                            let t = e.index;
                            null !== t && n.version < t.version && s(e)
                        } else s(e);
                        return o.get(e)
                    }
                }
            }

            function y(e, n, t) {
                let i, r, a;
                this.setMode = function(e) {
                    i = e
                }, this.setIndex = function(e) {
                    r = e.type, a = e.bytesPerElement
                }, this.render = function(n, o) {
                    e.drawElements(i, o, r, n * a), t.update(o, i, 1)
                }, this.renderInstances = function(n, o, l) {
                    0 !== l && (e.drawElementsInstanced(i, o, r, n * a, l), t.update(o, i, l))
                }, this.renderMultiDraw = function(e, a, o) {
                    if (0 === o) return;
                    n.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i, a, 0, r, e, 0, o);
                    let l = 0;
                    for (let e = 0; e < o; e++) l += a[e];
                    t.update(l, i, 1)
                }
            }

            function O(e) {
                let n = {
                    frame: 0,
                    calls: 0,
                    triangles: 0,
                    points: 0,
                    lines: 0
                };
                return {
                    memory: {
                        geometries: 0,
                        textures: 0
                    },
                    render: n,
                    programs: null,
                    autoReset: !0,
                    reset: function() {
                        n.calls = 0, n.triangles = 0, n.points = 0, n.lines = 0
                    },
                    update: function(t, r, a) {
                        switch (n.calls++, r) {
                            case e.TRIANGLES:
                                n.triangles += t / 3 * a;
                                break;
                            case e.LINES:
                                n.lines += t / 2 * a;
                                break;
                            case e.LINE_STRIP:
                                n.lines += a * (t - 1);
                                break;
                            case e.LINE_LOOP:
                                n.lines += a * t;
                                break;
                            case e.POINTS:
                                n.points += a * t;
                                break;
                            default:
                                (0, i.z3S)("WebGLInfo: Unknown draw mode:", r)
                        }
                    }
                }
            }

            function F(e, n, t) {
                let r = new WeakMap,
                    a = new i.IUQ;
                return {
                    update: function(o, l, s) {
                        let c = o.morphTargetInfluences,
                            d = l.morphAttributes.position || l.morphAttributes.normal || l.morphAttributes.color,
                            u = void 0 !== d ? d.length : 0,
                            f = r.get(l);
                        if (void 0 === f || f.count !== u) {
                            void 0 !== f && f.texture.dispose();
                            let e = void 0 !== l.morphAttributes.position,
                                t = void 0 !== l.morphAttributes.normal,
                                o = void 0 !== l.morphAttributes.color,
                                s = l.morphAttributes.position || [],
                                c = l.morphAttributes.normal || [],
                                d = l.morphAttributes.color || [],
                                p = 0;
                            !0 === e && (p = 1), !0 === t && (p = 2), !0 === o && (p = 3);
                            let m = l.attributes.position.count * p,
                                h = 1;
                            m > n.maxTextureSize && (h = Math.ceil(m / n.maxTextureSize), m = n.maxTextureSize);
                            let _ = new Float32Array(m * h * 4 * u),
                                g = new i.rFo(_, m, h, u);
                            g.type = i.RQf, g.needsUpdate = !0;
                            let v = 4 * p;
                            for (let n = 0; n < u; n++) {
                                let i = s[n],
                                    r = c[n],
                                    l = d[n],
                                    u = m * h * 4 * n;
                                for (let n = 0; n < i.count; n++) {
                                    let s = n * v;
                                    !0 === e && (a.fromBufferAttribute(i, n), _[u + s + 0] = a.x, _[u + s + 1] = a.y, _[u + s + 2] = a.z, _[u + s + 3] = 0), !0 === t && (a.fromBufferAttribute(r, n), _[u + s + 4] = a.x, _[u + s + 5] = a.y, _[u + s + 6] = a.z, _[u + s + 7] = 0), !0 === o && (a.fromBufferAttribute(l, n), _[u + s + 8] = a.x, _[u + s + 9] = a.y, _[u + s + 10] = a.z, _[u + s + 11] = 4 === l.itemSize ? a.w : 1)
                                }
                            }
                            f = {
                                count: u,
                                texture: g,
                                size: new i.I9Y(m, h)
                            }, r.set(l, f), l.addEventListener("dispose", function e() {
                                g.dispose(), r.delete(l), l.removeEventListener("dispose", e)
                            })
                        }
                        if (!0 === o.isInstancedMesh && null !== o.morphTexture) s.getUniforms().setValue(e, "morphTexture", o.morphTexture, t);
                        else {
                            let n = 0;
                            for (let e = 0; e < c.length; e++) n += c[e];
                            let t = l.morphTargetsRelative ? 1 : 1 - n;
                            s.getUniforms().setValue(e, "morphTargetBaseInfluence", t), s.getUniforms().setValue(e, "morphTargetInfluences", c)
                        }
                        s.getUniforms().setValue(e, "morphTargetsTexture", f.texture, t), s.getUniforms().setValue(e, "morphTargetsTextureSize", f.size)
                    }
                }
            }

            function B(e, n, t, i, r) {
                let a = new WeakMap;

                function o(e) {
                    let n = e.target;
                    n.removeEventListener("dispose", o), i.releaseStatesOfObject(n), t.remove(n.instanceMatrix), null !== n.instanceColor && t.remove(n.instanceColor)
                }
                return {
                    update: function(i) {
                        let l = r.render.frame,
                            s = i.geometry,
                            c = n.get(i, s);
                        if (a.get(c) !== l && (n.update(c), a.set(c, l)), i.isInstancedMesh && (!1 === i.hasEventListener("dispose", o) && i.addEventListener("dispose", o), a.get(i) !== l && (t.update(i.instanceMatrix, e.ARRAY_BUFFER), null !== i.instanceColor && t.update(i.instanceColor, e.ARRAY_BUFFER), a.set(i, l))), i.isSkinnedMesh) {
                            let e = i.skeleton;
                            a.get(e) !== l && (e.update(), a.set(e, l))
                        }
                        return c
                    },
                    dispose: function() {
                        a = new WeakMap
                    }
                }
            }
            let G = {
                [i.kyO]: "LINEAR_TONE_MAPPING",
                [i.Mjd]: "REINHARD_TONE_MAPPING",
                [i.nNL]: "CINEON_TONE_MAPPING",
                [i.FV]: "ACES_FILMIC_TONE_MAPPING",
                [i.LAk]: "AGX_TONE_MAPPING",
                [i.aJ8]: "NEUTRAL_TONE_MAPPING",
                [i.g7M]: "CUSTOM_TONE_MAPPING"
            };

            function H(e, n, t, r, a, o) {
                let l, s = new i.nWS(n, t, {
                        type: e,
                        depthBuffer: a,
                        stencilBuffer: o,
                        samples: 4 * !!r,
                        storeMultisampledDepthBuffer: !1,
                        storeMultisampledStencilBuffer: !1,
                        resolveDepthBuffer: !1,
                        resolveStencilBuffer: !1
                    }),
                    c = null,
                    d = null,
                    u = new i.LoY;
                u.setAttribute("position", new i.qtW([-1, 3, 0, -1, -1, 0, 3, -1, 0], 3)), u.setAttribute("uv", new i.qtW([0, 2, 0, 0, 2, 0], 2));
                let f = new i.D$Q({
                        uniforms: {
                            tDiffuse: {
                                value: null
                            }
                        },
                        vertexShader: `
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,
                        fragmentShader: `
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,
                        depthTest: !1,
                        depthWrite: !1
                    }),
                    p = new i.eaF(u, f),
                    m = new i.qUd(-1, 1, 1, -1, 0, 1),
                    h = null,
                    _ = null,
                    g = !1,
                    v = null,
                    S = [],
                    E = !1;
                this.setSize = function(e, n) {
                    s.setSize(e, n), null !== c && c.setSize(e, n), null !== d && d.setSize(e, n);
                    for (let t = 0; t < S.length; t++) {
                        let i = S[t];
                        i.setSize && i.setSize(e, n)
                    }
                }, this.setEffects = function(e) {
                    E = (S = e).length > 0 && !0 === S[0].isRenderPass;
                    let n = s.width,
                        t = s.height;
                    S.length > 0 && null === c && (c = new i.nWS(n, t, {
                        type: i.ix0,
                        depthBuffer: !1,
                        stencilBuffer: !1
                    }), d = new i.nWS(n, t, {
                        type: i.ix0,
                        depthBuffer: !1,
                        stencilBuffer: !1
                    }));
                    for (let e = 0; e < S.length; e++) {
                        let i = S[e];
                        i.setSize && i.setSize(n, t)
                    }
                }, this.begin = function(e, n) {
                    if (g || e.toneMapping === i.y_p && 0 === S.length) return !1;
                    if (v = n, null !== n) {
                        let e = n.width,
                            t = n.height;
                        (s.width !== e || s.height !== t) && this.setSize(e, t)
                    }
                    return !1 === E && e.setRenderTarget(s), l = e.toneMapping, e.toneMapping = i.y_p, !0
                }, this.hasRenderPass = function() {
                    return E
                }, this.end = function(e, n) {
                    e.toneMapping = l, g = !0;
                    let t = s,
                        r = c;
                    for (let i = 0; i < S.length; i++) {
                        let a = S[i];
                        !1 !== a.enabled && (a.render(e, r, t, n), !1 !== a.needsSwap && (t = r, r = r === c ? d : c))
                    }
                    if (h !== e.outputColorSpace || _ !== e.toneMapping) {
                        h = e.outputColorSpace, _ = e.toneMapping, f.defines = {}, i.ppV.getTransfer(h) === i.KLL && (f.defines.SRGB_TRANSFER = "");
                        let n = G[_];
                        n && (f.defines[n] = ""), f.needsUpdate = !0
                    }
                    f.uniforms.tDiffuse.value = t.texture, e.setRenderTarget(v), e.render(p, m), v = null, g = !1
                }, this.isCompositing = function() {
                    return g
                }, this.dispose = function() {
                    s.dispose(), null !== c && c.dispose(), null !== d && d.dispose(), u.dispose(), f.dispose()
                }
            }
            let V = new i.gPd,
                W = new i.VCu(1, 1),
                z = new i.rFo,
                k = new i.dYF,
                X = new i.b4q,
                K = [],
                q = [],
                Y = new Float32Array(16),
                j = new Float32Array(9),
                Z = new Float32Array(4);

            function Q(e, n, t) {
                let i = e[0];
                if (i <= 0 || i > 0) return e;
                let r = n * t,
                    a = K[r];
                if (void 0 === a && (a = new Float32Array(r), K[r] = a), 0 !== n) {
                    i.toArray(a, 0);
                    for (let i = 1, r = 0; i !== n; ++i) r += t, e[i].toArray(a, r)
                }
                return a
            }

            function $(e, n) {
                if (e.length !== n.length) return !1;
                for (let t = 0, i = e.length; t < i; t++)
                    if (e[t] !== n[t]) return !1;
                return !0
            }

            function J(e, n) {
                for (let t = 0, i = n.length; t < i; t++) e[t] = n[t]
            }

            function ee(e, n) {
                let t = q[n];
                void 0 === t && (t = new Int32Array(n), q[n] = t);
                for (let i = 0; i !== n; ++i) t[i] = e.allocateTextureUnit();
                return t
            }

            function en(e, n) {
                let t = this.cache;
                t[0] !== n && (e.uniform1f(this.addr, n), t[0] = n)
            }

            function et(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y) && (e.uniform2f(this.addr, n.x, n.y), t[0] = n.x, t[1] = n.y);
                else {
                    if ($(t, n)) return;
                    e.uniform2fv(this.addr, n), J(t, n)
                }
            }

            function ei(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y || t[2] !== n.z) && (e.uniform3f(this.addr, n.x, n.y, n.z), t[0] = n.x, t[1] = n.y, t[2] = n.z);
                else if (void 0 !== n.r)(t[0] !== n.r || t[1] !== n.g || t[2] !== n.b) && (e.uniform3f(this.addr, n.r, n.g, n.b), t[0] = n.r, t[1] = n.g, t[2] = n.b);
                else {
                    if ($(t, n)) return;
                    e.uniform3fv(this.addr, n), J(t, n)
                }
            }

            function er(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y || t[2] !== n.z || t[3] !== n.w) && (e.uniform4f(this.addr, n.x, n.y, n.z, n.w), t[0] = n.x, t[1] = n.y, t[2] = n.z, t[3] = n.w);
                else {
                    if ($(t, n)) return;
                    e.uniform4fv(this.addr, n), J(t, n)
                }
            }

            function ea(e, n) {
                let t = this.cache,
                    i = n.elements;
                if (void 0 === i) {
                    if ($(t, n)) return;
                    e.uniformMatrix2fv(this.addr, !1, n), J(t, n)
                } else {
                    if ($(t, i)) return;
                    Z.set(i), e.uniformMatrix2fv(this.addr, !1, Z), J(t, i)
                }
            }

            function eo(e, n) {
                let t = this.cache,
                    i = n.elements;
                if (void 0 === i) {
                    if ($(t, n)) return;
                    e.uniformMatrix3fv(this.addr, !1, n), J(t, n)
                } else {
                    if ($(t, i)) return;
                    j.set(i), e.uniformMatrix3fv(this.addr, !1, j), J(t, i)
                }
            }

            function el(e, n) {
                let t = this.cache,
                    i = n.elements;
                if (void 0 === i) {
                    if ($(t, n)) return;
                    e.uniformMatrix4fv(this.addr, !1, n), J(t, n)
                } else {
                    if ($(t, i)) return;
                    Y.set(i), e.uniformMatrix4fv(this.addr, !1, Y), J(t, i)
                }
            }

            function es(e, n) {
                let t = this.cache;
                t[0] !== n && (e.uniform1i(this.addr, n), t[0] = n)
            }

            function ec(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y) && (e.uniform2i(this.addr, n.x, n.y), t[0] = n.x, t[1] = n.y);
                else {
                    if ($(t, n)) return;
                    e.uniform2iv(this.addr, n), J(t, n)
                }
            }

            function ed(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y || t[2] !== n.z) && (e.uniform3i(this.addr, n.x, n.y, n.z), t[0] = n.x, t[1] = n.y, t[2] = n.z);
                else {
                    if ($(t, n)) return;
                    e.uniform3iv(this.addr, n), J(t, n)
                }
            }

            function eu(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y || t[2] !== n.z || t[3] !== n.w) && (e.uniform4i(this.addr, n.x, n.y, n.z, n.w), t[0] = n.x, t[1] = n.y, t[2] = n.z, t[3] = n.w);
                else {
                    if ($(t, n)) return;
                    e.uniform4iv(this.addr, n), J(t, n)
                }
            }

            function ef(e, n) {
                let t = this.cache;
                t[0] !== n && (e.uniform1ui(this.addr, n), t[0] = n)
            }

            function ep(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y) && (e.uniform2ui(this.addr, n.x, n.y), t[0] = n.x, t[1] = n.y);
                else {
                    if ($(t, n)) return;
                    e.uniform2uiv(this.addr, n), J(t, n)
                }
            }

            function em(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y || t[2] !== n.z) && (e.uniform3ui(this.addr, n.x, n.y, n.z), t[0] = n.x, t[1] = n.y, t[2] = n.z);
                else {
                    if ($(t, n)) return;
                    e.uniform3uiv(this.addr, n), J(t, n)
                }
            }

            function eh(e, n) {
                let t = this.cache;
                if (void 0 !== n.x)(t[0] !== n.x || t[1] !== n.y || t[2] !== n.z || t[3] !== n.w) && (e.uniform4ui(this.addr, n.x, n.y, n.z, n.w), t[0] = n.x, t[1] = n.y, t[2] = n.z, t[3] = n.w);
                else {
                    if ($(t, n)) return;
                    e.uniform4uiv(this.addr, n), J(t, n)
                }
            }

            function e_(e, n, t) {
                let r, a = this.cache,
                    o = t.allocateTextureUnit();
                a[0] !== o && (e.uniform1i(this.addr, o), a[0] = o), this.type === e.SAMPLER_2D_SHADOW ? (W.compareFunction = t.isReversedDepthBuffer() ? i.gWB : i.TiK, r = W) : r = V, t.setTexture2D(n || r, o)
            }

            function eg(e, n, t) {
                let i = this.cache,
                    r = t.allocateTextureUnit();
                i[0] !== r && (e.uniform1i(this.addr, r), i[0] = r), t.setTexture3D(n || k, r)
            }

            function ev(e, n, t) {
                let i = this.cache,
                    r = t.allocateTextureUnit();
                i[0] !== r && (e.uniform1i(this.addr, r), i[0] = r), t.setTextureCube(n || X, r)
            }

            function eS(e, n, t) {
                let i = this.cache,
                    r = t.allocateTextureUnit();
                i[0] !== r && (e.uniform1i(this.addr, r), i[0] = r), t.setTexture2DArray(n || z, r)
            }

            function eE(e, n) {
                e.uniform1fv(this.addr, n)
            }

            function eM(e, n) {
                let t = Q(n, this.size, 2);
                e.uniform2fv(this.addr, t)
            }

            function eT(e, n) {
                let t = Q(n, this.size, 3);
                e.uniform3fv(this.addr, t)
            }

            function ex(e, n) {
                let t = Q(n, this.size, 4);
                e.uniform4fv(this.addr, t)
            }

            function eR(e, n) {
                let t = Q(n, this.size, 4);
                e.uniformMatrix2fv(this.addr, !1, t)
            }

            function eA(e, n) {
                let t = Q(n, this.size, 9);
                e.uniformMatrix3fv(this.addr, !1, t)
            }

            function eb(e, n) {
                let t = Q(n, this.size, 16);
                e.uniformMatrix4fv(this.addr, !1, t)
            }

            function eC(e, n) {
                e.uniform1iv(this.addr, n)
            }

            function eP(e, n) {
                e.uniform2iv(this.addr, n)
            }

            function eL(e, n) {
                e.uniform3iv(this.addr, n)
            }

            function ew(e, n) {
                e.uniform4iv(this.addr, n)
            }

            function eU(e, n) {
                e.uniform1uiv(this.addr, n)
            }

            function eI(e, n) {
                e.uniform2uiv(this.addr, n)
            }

            function eD(e, n) {
                e.uniform3uiv(this.addr, n)
            }

            function eN(e, n) {
                e.uniform4uiv(this.addr, n)
            }

            function ey(e, n, t) {
                let i, r = this.cache,
                    a = n.length,
                    o = ee(t, a);
                $(r, o) || (e.uniform1iv(this.addr, o), J(r, o)), i = this.type === e.SAMPLER_2D_SHADOW ? W : V;
                for (let e = 0; e !== a; ++e) t.setTexture2D(n[e] || i, o[e])
            }

            function eO(e, n, t) {
                let i = this.cache,
                    r = n.length,
                    a = ee(t, r);
                $(i, a) || (e.uniform1iv(this.addr, a), J(i, a));
                for (let e = 0; e !== r; ++e) t.setTexture3D(n[e] || k, a[e])
            }

            function eF(e, n, t) {
                let i = this.cache,
                    r = n.length,
                    a = ee(t, r);
                $(i, a) || (e.uniform1iv(this.addr, a), J(i, a));
                for (let e = 0; e !== r; ++e) t.setTextureCube(n[e] || X, a[e])
            }

            function eB(e, n, t) {
                let i = this.cache,
                    r = n.length,
                    a = ee(t, r);
                $(i, a) || (e.uniform1iv(this.addr, a), J(i, a));
                for (let e = 0; e !== r; ++e) t.setTexture2DArray(n[e] || z, a[e])
            }
            class eG {
                constructor(e, n, t) {
                    this.id = e, this.addr = t, this.cache = [], this.type = n.type, this.setValue = function(e) {
                        switch (e) {
                            case 5126:
                                return en;
                            case 35664:
                                return et;
                            case 35665:
                                return ei;
                            case 35666:
                                return er;
                            case 35674:
                                return ea;
                            case 35675:
                                return eo;
                            case 35676:
                                return el;
                            case 5124:
                            case 35670:
                                return es;
                            case 35667:
                            case 35671:
                                return ec;
                            case 35668:
                            case 35672:
                                return ed;
                            case 35669:
                            case 35673:
                                return eu;
                            case 5125:
                                return ef;
                            case 36294:
                                return ep;
                            case 36295:
                                return em;
                            case 36296:
                                return eh;
                            case 35678:
                            case 36198:
                            case 36298:
                            case 36306:
                            case 35682:
                                return e_;
                            case 35679:
                            case 36299:
                            case 36307:
                                return eg;
                            case 35680:
                            case 36300:
                            case 36308:
                            case 36293:
                                return ev;
                            case 36289:
                            case 36303:
                            case 36311:
                            case 36292:
                                return eS
                        }
                    }(n.type)
                }
            }
            class eH {
                constructor(e, n, t) {
                    this.id = e, this.addr = t, this.cache = [], this.type = n.type, this.size = n.size, this.setValue = function(e) {
                        switch (e) {
                            case 5126:
                                return eE;
                            case 35664:
                                return eM;
                            case 35665:
                                return eT;
                            case 35666:
                                return ex;
                            case 35674:
                                return eR;
                            case 35675:
                                return eA;
                            case 35676:
                                return eb;
                            case 5124:
                            case 35670:
                                return eC;
                            case 35667:
                            case 35671:
                                return eP;
                            case 35668:
                            case 35672:
                                return eL;
                            case 35669:
                            case 35673:
                                return ew;
                            case 5125:
                                return eU;
                            case 36294:
                                return eI;
                            case 36295:
                                return eD;
                            case 36296:
                                return eN;
                            case 35678:
                            case 36198:
                            case 36298:
                            case 36306:
                            case 35682:
                                return ey;
                            case 35679:
                            case 36299:
                            case 36307:
                                return eO;
                            case 35680:
                            case 36300:
                            case 36308:
                            case 36293:
                                return eF;
                            case 36289:
                            case 36303:
                            case 36311:
                            case 36292:
                                return eB
                        }
                    }(n.type)
                }
            }
            class eV {
                constructor(e) {
                    this.id = e, this.seq = [], this.map = {}
                }
                setValue(e, n, t) {
                    let i = this.seq;
                    for (let r = 0, a = i.length; r !== a; ++r) {
                        let a = i[r];
                        a.setValue(e, n[a.id], t)
                    }
                }
            }
            let eW = /(\w+)(\])?(\[|\.)?/g;

            function ez(e, n) {
                e.seq.push(n), e.map[n.id] = n
            }
            class ek {
                constructor(e, n) {
                    this.seq = [], this.map = {};
                    const t = e.getProgramParameter(n, e.ACTIVE_UNIFORMS);
                    for (let i = 0; i < t; ++i) {
                        const t = e.getActiveUniform(n, i),
                            r = e.getUniformLocation(n, t.name);
                        ! function(e, n, t) {
                            let i = e.name,
                                r = i.length;
                            for (eW.lastIndex = 0;;) {
                                let a = eW.exec(i),
                                    o = eW.lastIndex,
                                    l = a[1],
                                    s = "]" === a[2],
                                    c = a[3];
                                if (s && (l |= 0), void 0 === c || "[" === c && o + 2 === r) {
                                    ez(t, void 0 === c ? new eG(l, e, n) : new eH(l, e, n));
                                    break
                                } {
                                    let e = t.map[l];
                                    void 0 === e && ez(t, e = new eV(l)), t = e
                                }
                            }
                        }(t, r, this)
                    }
                    const i = [],
                        r = [];
                    for (const n of this.seq) n.type === e.SAMPLER_2D_SHADOW || n.type === e.SAMPLER_CUBE_SHADOW || n.type === e.SAMPLER_2D_ARRAY_SHADOW ? i.push(n) : r.push(n);
                    i.length > 0 && (this.seq = i.concat(r))
                }
                setValue(e, n, t, i) {
                    let r = this.map[n];
                    void 0 !== r && r.setValue(e, t, i)
                }
                setOptional(e, n, t) {
                    let i = n[t];
                    void 0 !== i && this.setValue(e, t, i)
                }
                static upload(e, n, t, i) {
                    for (let r = 0, a = n.length; r !== a; ++r) {
                        let a = n[r],
                            o = t[a.id];
                        !1 !== o.needsUpdate && a.setValue(e, o.value, i)
                    }
                }
                static seqWithValue(e, n) {
                    let t = [];
                    for (let i = 0, r = e.length; i !== r; ++i) {
                        let r = e[i];
                        r.id in n && t.push(r)
                    }
                    return t
                }
            }

            function eX(e, n, t) {
                let i = e.createShader(n);
                return e.shaderSource(i, t), e.compileShader(i), i
            }
            let eK = 0,
                eq = new i.dwI;

            function eY(e, n, t) {
                let i = e.getShaderParameter(n, e.COMPILE_STATUS),
                    r = (e.getShaderInfoLog(n) || "").trim();
                if (i && "" === r) return "";
                let a = /ERROR: 0:(\d+)/.exec(r);
                if (!a) return r; {
                    let i = parseInt(a[1]);
                    return t.toUpperCase() + "\n\n" + r + "\n\n" + function(e, n) {
                        let t = e.split("\n"),
                            i = [],
                            r = Math.max(n - 6, 0),
                            a = Math.min(n + 6, t.length);
                        for (let e = r; e < a; e++) {
                            let r = e + 1;
                            i.push(`${r===n?">":" "} ${r}: ${t[e]}`)
                        }
                        return i.join("\n")
                    }(e.getShaderSource(n), i)
                }
            }
            let ej = {
                    [i.kyO]: "Linear",
                    [i.Mjd]: "Reinhard",
                    [i.nNL]: "Cineon",
                    [i.FV]: "ACESFilmic",
                    [i.LAk]: "AgX",
                    [i.aJ8]: "Neutral",
                    [i.g7M]: "Custom"
                },
                eZ = new i.Pq0;

            function eQ(e) {
                return "" !== e
            }

            function e$(e, n) {
                let t = n.numSpotLightShadows + n.numSpotLightMaps - n.numSpotLightShadowsWithMaps;
                return e.replace(/NUM_SUN_LIGHTS/g, n.numSunLights).replace(/NUM_DIR_LIGHTS/g, n.numDirLights).replace(/NUM_SPOT_LIGHTS/g, n.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g, n.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g, t).replace(/NUM_RECT_AREA_LIGHTS/g, n.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g, n.numPointLights).replace(/NUM_HEMI_LIGHTS/g, n.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g, n.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g, n.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g, n.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g, n.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g, n.numPointLightShadows)
            }

            function eJ(e, n) {
                return e.replace(/NUM_CLIPPING_PLANES/g, n.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g, n.numClippingPlanes - n.numClipIntersection)
            }
            let e0 = /^[ \t]*#include +<([\w\d./]+)>/gm;

            function e1(e) {
                return e.replace(e0, e2)
            }
            let e3 = new Map;

            function e2(e, n) {
                let t = o[n];
                if (void 0 === t) {
                    let e = e3.get(n);
                    if (void 0 !== e) t = o[e], (0, i.R8M)('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.', n, e);
                    else throw Error("THREE.WebGLProgram: Can not resolve #include <" + n + ">")
                }
                return e1(t)
            }
            let e4 = /#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;

            function e5(e) {
                return e.replace(e4, e6)
            }

            function e6(e, n, t, i) {
                let r = "";
                for (let e = parseInt(n); e < parseInt(t); e++) r += i.replace(/\[\s*i\s*\]/g, "[ " + e + " ]").replace(/UNROLLED_LOOP_INDEX/g, e);
                return r
            }

            function e8(e) {
                let n = `precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;
                return "highp" === e.precision ? n += "\n#define HIGH_PRECISION" : "mediump" === e.precision ? n += "\n#define MEDIUM_PRECISION" : "lowp" === e.precision && (n += "\n#define LOW_PRECISION"), n
            }
            let e9 = {
                    [i.QP0]: "SHADOWMAP_TYPE_PCF",
                    [i.RyA]: "SHADOWMAP_TYPE_VSM"
                },
                e7 = {
                    [i.hy7]: "ENVMAP_TYPE_CUBE",
                    [i.xFO]: "ENVMAP_TYPE_CUBE",
                    [i.Om]: "ENVMAP_TYPE_CUBE_UV"
                },
                ne = {
                    [i.xFO]: "ENVMAP_MODE_REFRACTION"
                },
                nn = {
                    [i.caT]: "ENVMAP_BLENDING_MULTIPLY",
                    [i.KRh]: "ENVMAP_BLENDING_MIX",
                    [i.XrR]: "ENVMAP_BLENDING_ADD"
                };

            function nt(e, n, t, r) {
                var a, l;
                let s, c, d, u, f = e.getContext(),
                    p = t.defines,
                    m = t.vertexShader,
                    h = t.fragmentShader,
                    _ = e9[t.shadowMapType] || "SHADOWMAP_TYPE_BASIC",
                    g = !1 === t.envMap ? "ENVMAP_TYPE_CUBE" : e7[t.envMapMode] || "ENVMAP_TYPE_CUBE",
                    v = !1 === t.envMap ? "ENVMAP_MODE_REFLECTION" : ne[t.envMapMode] || "ENVMAP_MODE_REFLECTION",
                    S = !1 === t.envMap ? "ENVMAP_BLENDING_NONE" : nn[t.combine] || "ENVMAP_BLENDING_NONE",
                    E = function(e) {
                        let n = e.envMapCubeUVHeight;
                        if (null === n) return null;
                        let t = Math.log2(n) - 2;
                        return {
                            texelWidth: 1 / (3 * Math.max(Math.pow(2, t), 112)),
                            texelHeight: 1 / n,
                            maxMip: t
                        }
                    }(t),
                    M = [t.extensionClipCullDistance ? "#extension GL_ANGLE_clip_cull_distance : require" : "", t.extensionMultiDraw ? "#extension GL_ANGLE_multi_draw : require" : ""].filter(eQ).join("\n"),
                    T = function(e) {
                        let n = [];
                        for (let t in e) {
                            let i = e[t];
                            !1 !== i && n.push("#define " + t + " " + i)
                        }
                        return n.join("\n")
                    }(p),
                    x = f.createProgram(),
                    R = t.glslVersion ? "#version " + t.glslVersion + "\n" : "";
                if (t.isRawShaderMaterial)(s = ["#define SHADER_TYPE " + t.shaderType, "#define SHADER_NAME " + t.shaderName, T].filter(eQ).join("\n")).length > 0 && (s += "\n"), (c = ["#define SHADER_TYPE " + t.shaderType, "#define SHADER_NAME " + t.shaderName, T].filter(eQ).join("\n")).length > 0 && (c += "\n");
                else {
                    let e, n, r, d, u;
                    s = [e8(t), "#define SHADER_TYPE " + t.shaderType, "#define SHADER_NAME " + t.shaderName, T, t.extensionClipCullDistance ? "#define USE_CLIP_DISTANCE" : "", t.batching ? "#define USE_BATCHING" : "", t.batchingColor ? "#define USE_BATCHING_COLOR" : "", t.instancing ? "#define USE_INSTANCING" : "", t.instancingColor ? "#define USE_INSTANCING_COLOR" : "", t.instancingMorph ? "#define USE_INSTANCING_MORPH" : "", t.useFog && t.fog ? "#define USE_FOG" : "", t.useFog && t.fogExp2 ? "#define FOG_EXP2" : "", t.map ? "#define USE_MAP" : "", t.envMap ? "#define USE_ENVMAP" : "", t.envMap ? "#define " + v : "", t.lightMap ? "#define USE_LIGHTMAP" : "", t.aoMap ? "#define USE_AOMAP" : "", t.bumpMap ? "#define USE_BUMPMAP" : "", t.normalMap ? "#define USE_NORMALMAP" : "", t.normalMapObjectSpace ? "#define USE_NORMALMAP_OBJECTSPACE" : "", t.normalMapTangentSpace ? "#define USE_NORMALMAP_TANGENTSPACE" : "", t.displacementMap ? "#define USE_DISPLACEMENTMAP" : "", t.emissiveMap ? "#define USE_EMISSIVEMAP" : "", t.anisotropy ? "#define USE_ANISOTROPY" : "", t.anisotropyMap ? "#define USE_ANISOTROPYMAP" : "", t.clearcoatMap ? "#define USE_CLEARCOATMAP" : "", t.clearcoatRoughnessMap ? "#define USE_CLEARCOAT_ROUGHNESSMAP" : "", t.clearcoatNormalMap ? "#define USE_CLEARCOAT_NORMALMAP" : "", t.iridescenceMap ? "#define USE_IRIDESCENCEMAP" : "", t.iridescenceThicknessMap ? "#define USE_IRIDESCENCE_THICKNESSMAP" : "", t.specularMap ? "#define USE_SPECULARMAP" : "", t.specularColorMap ? "#define USE_SPECULAR_COLORMAP" : "", t.specularIntensityMap ? "#define USE_SPECULAR_INTENSITYMAP" : "", t.roughnessMap ? "#define USE_ROUGHNESSMAP" : "", t.metalnessMap ? "#define USE_METALNESSMAP" : "", t.alphaMap ? "#define USE_ALPHAMAP" : "", t.alphaHash ? "#define USE_ALPHAHASH" : "", t.transmission ? "#define USE_TRANSMISSION" : "", t.transmissionMap ? "#define USE_TRANSMISSIONMAP" : "", t.thicknessMap ? "#define USE_THICKNESSMAP" : "", t.sheenColorMap ? "#define USE_SHEEN_COLORMAP" : "", t.sheenRoughnessMap ? "#define USE_SHEEN_ROUGHNESSMAP" : "", t.mapUv ? "#define MAP_UV " + t.mapUv : "", t.alphaMapUv ? "#define ALPHAMAP_UV " + t.alphaMapUv : "", t.lightMapUv ? "#define LIGHTMAP_UV " + t.lightMapUv : "", t.aoMapUv ? "#define AOMAP_UV " + t.aoMapUv : "", t.emissiveMapUv ? "#define EMISSIVEMAP_UV " + t.emissiveMapUv : "", t.bumpMapUv ? "#define BUMPMAP_UV " + t.bumpMapUv : "", t.normalMapUv ? "#define NORMALMAP_UV " + t.normalMapUv : "", t.displacementMapUv ? "#define DISPLACEMENTMAP_UV " + t.displacementMapUv : "", t.metalnessMapUv ? "#define METALNESSMAP_UV " + t.metalnessMapUv : "", t.roughnessMapUv ? "#define ROUGHNESSMAP_UV " + t.roughnessMapUv : "", t.anisotropyMapUv ? "#define ANISOTROPYMAP_UV " + t.anisotropyMapUv : "", t.clearcoatMapUv ? "#define CLEARCOATMAP_UV " + t.clearcoatMapUv : "", t.clearcoatNormalMapUv ? "#define CLEARCOAT_NORMALMAP_UV " + t.clearcoatNormalMapUv : "", t.clearcoatRoughnessMapUv ? "#define CLEARCOAT_ROUGHNESSMAP_UV " + t.clearcoatRoughnessMapUv : "", t.iridescenceMapUv ? "#define IRIDESCENCEMAP_UV " + t.iridescenceMapUv : "", t.iridescenceThicknessMapUv ? "#define IRIDESCENCE_THICKNESSMAP_UV " + t.iridescenceThicknessMapUv : "", t.sheenColorMapUv ? "#define SHEEN_COLORMAP_UV " + t.sheenColorMapUv : "", t.sheenRoughnessMapUv ? "#define SHEEN_ROUGHNESSMAP_UV " + t.sheenRoughnessMapUv : "", t.specularMapUv ? "#define SPECULARMAP_UV " + t.specularMapUv : "", t.specularColorMapUv ? "#define SPECULAR_COLORMAP_UV " + t.specularColorMapUv : "", t.specularIntensityMapUv ? "#define SPECULAR_INTENSITYMAP_UV " + t.specularIntensityMapUv : "", t.transmissionMapUv ? "#define TRANSMISSIONMAP_UV " + t.transmissionMapUv : "", t.thicknessMapUv ? "#define THICKNESSMAP_UV " + t.thicknessMapUv : "", t.vertexTangents && !1 === t.flatShading ? "#define USE_TANGENT" : "", t.vertexNormals ? "#define HAS_NORMAL" : "", t.vertexColors ? "#define USE_COLOR" : "", t.vertexAlphas ? "#define USE_COLOR_ALPHA" : "", t.vertexUv1s ? "#define USE_UV1" : "", t.vertexUv2s ? "#define USE_UV2" : "", t.vertexUv3s ? "#define USE_UV3" : "", t.pointsUvs ? "#define USE_POINTS_UV" : "", t.flatShading ? "#define FLAT_SHADED" : "", t.skinning ? "#define USE_SKINNING" : "", t.morphTargets ? "#define USE_MORPHTARGETS" : "", t.morphNormals && !1 === t.flatShading ? "#define USE_MORPHNORMALS" : "", t.morphColors ? "#define USE_MORPHCOLORS" : "", t.morphTargetsCount > 0 ? "#define MORPHTARGETS_TEXTURE_STRIDE " + t.morphTextureStride : "", t.morphTargetsCount > 0 ? "#define MORPHTARGETS_COUNT " + t.morphTargetsCount : "", t.doubleSided ? "#define DOUBLE_SIDED" : "", t.flipSided ? "#define FLIP_SIDED" : "", t.shadowMapEnabled ? "#define USE_SHADOWMAP" : "", t.shadowMapEnabled ? "#define " + _ : "", t.sizeAttenuation ? "#define USE_SIZEATTENUATION" : "", t.numLightProbes > 0 ? "#define USE_LIGHT_PROBES" : "", t.logarithmicDepthBuffer ? "#define USE_LOGARITHMIC_DEPTH_BUFFER" : "", t.reversedDepthBuffer ? "#define USE_REVERSED_DEPTH_BUFFER" : "", "uniform mat4 modelMatrix;", "uniform mat4 modelViewMatrix;", "uniform mat4 projectionMatrix;", "uniform mat4 viewMatrix;", "uniform mat3 normalMatrix;", "uniform vec3 cameraPosition;", "uniform bool isOrthographic;", "#ifdef USE_INSTANCING", "	attribute mat4 instanceMatrix;", "#endif", "#ifdef USE_INSTANCING_COLOR", "	attribute vec3 instanceColor;", "#endif", "#ifdef USE_INSTANCING_MORPH", "	uniform sampler2D morphTexture;", "#endif", "attribute vec3 position;", "attribute vec3 normal;", "attribute vec2 uv;", "#ifdef USE_UV1", "	attribute vec2 uv1;", "#endif", "#ifdef USE_UV2", "	attribute vec2 uv2;", "#endif", "#ifdef USE_UV3", "	attribute vec2 uv3;", "#endif", "#ifdef USE_TANGENT", "	attribute vec4 tangent;", "#endif", "#if defined( USE_COLOR_ALPHA )", "	attribute vec4 color;", "#elif defined( USE_COLOR )", "	attribute vec3 color;", "#endif", "#ifdef USE_SKINNING", "	attribute vec4 skinIndex;", "	attribute vec4 skinWeight;", "#endif", "\n"].filter(eQ).join("\n"), c = [e8(t), "#define SHADER_TYPE " + t.shaderType, "#define SHADER_NAME " + t.shaderName, T, t.useFog && t.fog ? "#define USE_FOG" : "", t.useFog && t.fogExp2 ? "#define FOG_EXP2" : "", t.alphaToCoverage ? "#define ALPHA_TO_COVERAGE" : "", t.map ? "#define USE_MAP" : "", t.matcap ? "#define USE_MATCAP" : "", t.envMap ? "#define USE_ENVMAP" : "", t.envMap ? "#define " + g : "", t.envMap ? "#define " + v : "", t.envMap ? "#define " + S : "", E ? "#define CUBEUV_TEXEL_WIDTH " + E.texelWidth : "", E ? "#define CUBEUV_TEXEL_HEIGHT " + E.texelHeight : "", E ? "#define CUBEUV_MAX_MIP " + E.maxMip + ".0" : "", t.lightMap ? "#define USE_LIGHTMAP" : "", t.aoMap ? "#define USE_AOMAP" : "", t.bumpMap ? "#define USE_BUMPMAP" : "", t.normalMap ? "#define USE_NORMALMAP" : "", t.normalMapObjectSpace ? "#define USE_NORMALMAP_OBJECTSPACE" : "", t.normalMapTangentSpace ? "#define USE_NORMALMAP_TANGENTSPACE" : "", t.packedNormalMap ? "#define USE_PACKED_NORMALMAP" : "", t.emissiveMap ? "#define USE_EMISSIVEMAP" : "", t.anisotropy ? "#define USE_ANISOTROPY" : "", t.anisotropyMap ? "#define USE_ANISOTROPYMAP" : "", t.clearcoat ? "#define USE_CLEARCOAT" : "", t.clearcoatMap ? "#define USE_CLEARCOATMAP" : "", t.clearcoatRoughnessMap ? "#define USE_CLEARCOAT_ROUGHNESSMAP" : "", t.clearcoatNormalMap ? "#define USE_CLEARCOAT_NORMALMAP" : "", t.dispersion ? "#define USE_DISPERSION" : "", t.retroreflection ? "#define USE_RETROREFLECTION" : "", t.iridescence ? "#define USE_IRIDESCENCE" : "", t.iridescenceMap ? "#define USE_IRIDESCENCEMAP" : "", t.iridescenceThicknessMap ? "#define USE_IRIDESCENCE_THICKNESSMAP" : "", t.specularMap ? "#define USE_SPECULARMAP" : "", t.specularColorMap ? "#define USE_SPECULAR_COLORMAP" : "", t.specularIntensityMap ? "#define USE_SPECULAR_INTENSITYMAP" : "", t.roughnessMap ? "#define USE_ROUGHNESSMAP" : "", t.metalnessMap ? "#define USE_METALNESSMAP" : "", t.alphaMap ? "#define USE_ALPHAMAP" : "", t.alphaTest ? "#define USE_ALPHATEST" : "", t.alphaHash ? "#define USE_ALPHAHASH" : "", t.sheen ? "#define USE_SHEEN" : "", t.sheenColorMap ? "#define USE_SHEEN_COLORMAP" : "", t.sheenRoughnessMap ? "#define USE_SHEEN_ROUGHNESSMAP" : "", t.transmission ? "#define USE_TRANSMISSION" : "", t.transmissionMap ? "#define USE_TRANSMISSIONMAP" : "", t.thicknessMap ? "#define USE_THICKNESSMAP" : "", t.vertexTangents && !1 === t.flatShading ? "#define USE_TANGENT" : "", t.vertexColors || t.instancingColor ? "#define USE_COLOR" : "", t.vertexAlphas || t.batchingColor ? "#define USE_COLOR_ALPHA" : "", t.vertexUv1s ? "#define USE_UV1" : "", t.vertexUv2s ? "#define USE_UV2" : "", t.vertexUv3s ? "#define USE_UV3" : "", t.pointsUvs ? "#define USE_POINTS_UV" : "", t.gradientMap ? "#define USE_GRADIENTMAP" : "", t.flatShading ? "#define FLAT_SHADED" : "", t.doubleSided ? "#define DOUBLE_SIDED" : "", t.flipSided ? "#define FLIP_SIDED" : "", t.shadowMapEnabled ? "#define USE_SHADOWMAP" : "", t.shadowMapEnabled ? "#define " + _ : "", t.premultipliedAlpha ? "#define PREMULTIPLIED_ALPHA" : "", t.numLightProbes > 0 ? "#define USE_LIGHT_PROBES" : "", t.numLightProbeGrids > 0 ? "#define USE_LIGHT_PROBES_GRID" : "", t.decodeVideoTexture ? "#define DECODE_VIDEO_TEXTURE" : "", t.decodeVideoTextureEmissive ? "#define DECODE_VIDEO_TEXTURE_EMISSIVE" : "", t.logarithmicDepthBuffer ? "#define USE_LOGARITHMIC_DEPTH_BUFFER" : "", t.reversedDepthBuffer ? "#define USE_REVERSED_DEPTH_BUFFER" : "", "uniform mat4 viewMatrix;", "uniform vec3 cameraPosition;", "uniform bool isOrthographic;", t.toneMapping !== i.y_p ? "#define TONE_MAPPING" : "", t.toneMapping !== i.y_p ? o.tonemapping_pars_fragment : "", t.toneMapping !== i.y_p ? (a = "toneMapping", void 0 === (e = ej[l = t.toneMapping]) ? ((0, i.R8M)("WebGLProgram: Unsupported toneMapping:", l), "vec3 " + a + "( vec3 color ) { return LinearToneMapping( color ); }") : "vec3 " + a + "( vec3 color ) { return " + e + "ToneMapping( color ); }") : "", t.dithering ? "#define DITHERING" : "", t.opaque ? "#define OPAQUE" : "", o.colorspace_pars_fragment, (n = function(e) {
                        i.ppV._getMatrix(eq, i.ppV.workingColorSpace, e);
                        let n = `mat3( ${eq.elements.map(e=>e.toFixed(4))} )`;
                        switch (i.ppV.getTransfer(e)) {
                            case i.VxR:
                                return [n, "LinearTransferOETF"];
                            case i.KLL:
                                return [n, "sRGBTransferOETF"];
                            default:
                                return (0, i.R8M)("WebGLProgram: Unsupported color space: ", e), [n, "LinearTransferOETF"]
                        }
                    }(t.outputColorSpace), `vec4 linearToOutputTexel( vec4 value ) {
	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );
}`), (i.ppV.getLuminanceCoefficients(eZ), r = eZ.x.toFixed(4), d = eZ.y.toFixed(4), u = eZ.z.toFixed(4), `float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( ${r}, ${d}, ${u} );
	return dot( weights, rgb );
}`), t.useDepthPacking ? "#define DEPTH_PACKING " + t.depthPacking : "", "\n"].filter(eQ).join("\n")
                }
                m = eJ(m = e$(m = e1(m), t), t), h = eJ(h = e$(h = e1(h), t), t), m = e5(m), h = e5(h), !0 !== t.isRawShaderMaterial && (R = "#version 300 es\n", s = [M, "#define attribute in\n#define varying out\n#define texture2D texture"].join("\n") + "\n" + s, c = ["#define varying in", t.glslVersion === i.Wdf ? "" : "layout(location = 0) out highp vec4 pc_fragColor;", t.glslVersion === i.Wdf ? "" : "#define gl_FragColor pc_fragColor", "#define gl_FragDepthEXT gl_FragDepth\n#define texture2D texture\n#define textureCube texture\n#define texture2DProj textureProj\n#define texture2DLodEXT textureLod\n#define texture2DProjLodEXT textureProjLod\n#define textureCubeLodEXT textureLod\n#define texture2DGradEXT textureGrad\n#define texture2DProjGradEXT textureProjGrad\n#define textureCubeGradEXT textureGrad"].join("\n") + "\n" + c);
                let A = R + s + m,
                    b = R + c + h,
                    C = eX(f, f.VERTEX_SHADER, A),
                    P = eX(f, f.FRAGMENT_SHADER, b);

                function L(n) {
                    if (e.debug.checkShaderErrors) {
                        let t = f.getProgramInfoLog(x) || "",
                            r = f.getShaderInfoLog(C) || "",
                            a = f.getShaderInfoLog(P) || "",
                            o = t.trim(),
                            l = r.trim(),
                            d = a.trim(),
                            u = !0,
                            p = !0;
                        if (!1 === f.getProgramParameter(x, f.LINK_STATUS))
                            if (u = !1, "function" == typeof e.debug.onShaderError) e.debug.onShaderError(f, x, C, P);
                            else {
                                let e = eY(f, C, "vertex"),
                                    t = eY(f, P, "fragment");
                                (0, i.z3S)("WebGLProgram: Shader Error " + f.getError() + " - VALIDATE_STATUS " + f.getProgramParameter(x, f.VALIDATE_STATUS) + "\n\nMaterial Name: " + n.name + "\nMaterial Type: " + n.type + "\n\nProgram Info Log: " + o + "\n" + e + "\n" + t)
                            }
                        else "" !== o ? (0, i.R8M)("WebGLProgram: Program Info Log:", o) : ("" === l || "" === d) && (p = !1);
                        p && (n.diagnostics = {
                            runnable: u,
                            programLog: o,
                            vertexShader: {
                                log: l,
                                prefix: s
                            },
                            fragmentShader: {
                                log: d,
                                prefix: c
                            }
                        })
                    }
                    f.deleteShader(C), f.deleteShader(P), d = new ek(f, x), u = function(e, n) {
                        let t = {},
                            i = e.getProgramParameter(n, e.ACTIVE_ATTRIBUTES);
                        for (let r = 0; r < i; r++) {
                            let i = e.getActiveAttrib(n, r),
                                a = i.name,
                                o = 1;
                            i.type === e.FLOAT_MAT2 && (o = 2), i.type === e.FLOAT_MAT3 && (o = 3), i.type === e.FLOAT_MAT4 && (o = 4), t[a] = {
                                type: i.type,
                                location: e.getAttribLocation(n, a),
                                locationSize: o
                            }
                        }
                        return t
                    }(f, x)
                }
                f.attachShader(x, C), f.attachShader(x, P), void 0 !== t.index0AttributeName ? f.bindAttribLocation(x, 0, t.index0AttributeName) : !0 === t.hasPositionAttribute && f.bindAttribLocation(x, 0, "position"), f.linkProgram(x), this.getUniforms = function() {
                    return void 0 === d && L(this), d
                }, this.getAttributes = function() {
                    return void 0 === u && L(this), u
                };
                let w = !1 === t.rendererExtensionParallelShaderCompile;
                return this.isReady = function() {
                    return !1 === w && (w = f.getProgramParameter(x, 37297)), w
                }, this.destroy = function() {
                    r.releaseStatesOfProgram(this), f.deleteProgram(x), this.program = void 0
                }, this.type = t.shaderType, this.name = t.shaderName, this.id = eK++, this.cacheKey = n, this.usedTimes = 1, this.program = x, this.vertexShader = C, this.fragmentShader = P, this
            }
            let ni = 0;
            class nr {
                constructor() {
                    this.shaderCache = new Map, this.materialCache = new Map
                }
                update(e, n, t) {
                    let i = this._getShaderCacheForMaterial(e);
                    return !1 === i.has(n) && (i.add(n), n.usedTimes++), !1 === i.has(t) && (i.add(t), t.usedTimes++), this
                }
                remove(e) {
                    for (let n of this.materialCache.get(e)) n.usedTimes--, 0 === n.usedTimes && this.shaderCache.delete(n.code);
                    return this.materialCache.delete(e), this
                }
                getVertexShaderStage(e) {
                    return this._getShaderStage(e.vertexShader)
                }
                getFragmentShaderStage(e) {
                    return this._getShaderStage(e.fragmentShader)
                }
                dispose() {
                    this.shaderCache.clear(), this.materialCache.clear()
                }
                _getShaderCacheForMaterial(e) {
                    let n = this.materialCache,
                        t = n.get(e);
                    return void 0 === t && (t = new Set, n.set(e, t)), t
                }
                _getShaderStage(e) {
                    let n = this.shaderCache,
                        t = n.get(e);
                    return void 0 === t && (t = new na(e), n.set(e, t)), t
                }
            }
            class na {
                constructor(e) {
                    this.id = ni++, this.code = e, this.usedTimes = 0
                }
            }

            function no(e, n, t, r, a, o) {
                let l = new i.zgK,
                    c = new nr,
                    d = new Set,
                    u = [],
                    f = new Map,
                    p = r.logarithmicDepthBuffer,
                    m = r.precision,
                    h = {
                        MeshDepthMaterial: "depth",
                        MeshDistanceMaterial: "distance",
                        MeshNormalMaterial: "normal",
                        MeshBasicMaterial: "basic",
                        MeshLambertMaterial: "lambert",
                        MeshPhongMaterial: "phong",
                        MeshToonMaterial: "toon",
                        MeshStandardMaterial: "physical",
                        MeshPhysicalMaterial: "physical",
                        MeshMatcapMaterial: "matcap",
                        LineBasicMaterial: "basic",
                        LineDashedMaterial: "dashed",
                        PointsMaterial: "points",
                        ShadowMaterial: "shadow",
                        SpriteMaterial: "sprite"
                    };

                function _(e) {
                    return (d.add(e), 0 === e) ? "uv" : `uv${e}`
                }
                return {
                    getParameters: function(a, l, u, f, g, v) {
                        var S;
                        let E, M, T, x, R = f.fog,
                            A = g.geometry,
                            b = a.isMeshStandardMaterial || a.isMeshLambertMaterial || a.isMeshPhongMaterial ? f.environment : null,
                            C = a.isMeshStandardMaterial || a.isMeshLambertMaterial && !a.envMap || a.isMeshPhongMaterial && !a.envMap,
                            P = n.get(a.envMap || b, C),
                            L = P && P.mapping === i.Om ? P.image.height : null,
                            w = h[a.type];
                        null !== a.precision && (m = r.getMaxPrecision(a.precision)) !== a.precision && (0, i.R8M)("WebGLProgram.getParameters:", a.precision, "not supported, using", m, "instead.");
                        let U = A.morphAttributes.position || A.morphAttributes.normal || A.morphAttributes.color,
                            I = void 0 !== U ? U.length : 0,
                            D = 0;
                        if (void 0 !== A.morphAttributes.position && (D = 1), void 0 !== A.morphAttributes.normal && (D = 2), void 0 !== A.morphAttributes.color && (D = 3), w) {
                            let e = s[w];
                            E = e.vertexShader, M = e.fragmentShader
                        } else {
                            E = a.vertexShader, M = a.fragmentShader;
                            let e = c.getVertexShaderStage(a),
                                n = c.getFragmentShaderStage(a);
                            c.update(a, e, n), T = e.id, x = n.id
                        }
                        let N = e.getRenderTarget(),
                            y = e.state.buffers.depth.getReversed(),
                            O = !0 === g.isInstancedMesh,
                            F = !0 === g.isBatchedMesh,
                            B = !!a.map,
                            G = !!a.matcap,
                            H = !!P,
                            V = !!a.aoMap,
                            W = !!a.lightMap,
                            z = !!a.bumpMap && !1 === a.wireframe,
                            k = !!a.normalMap,
                            X = !!a.displacementMap,
                            K = !!a.emissiveMap,
                            q = !!a.metalnessMap,
                            Y = !!a.roughnessMap,
                            j = a.anisotropy > 0,
                            Z = a.clearcoat > 0,
                            Q = a.dispersion > 0,
                            $ = a.retroreflectivity > 0,
                            J = a.iridescence > 0,
                            ee = a.sheen > 0,
                            en = a.transmission > 0,
                            et = j && !!a.anisotropyMap,
                            ei = Z && !!a.clearcoatMap,
                            er = Z && !!a.clearcoatNormalMap,
                            ea = Z && !!a.clearcoatRoughnessMap,
                            eo = J && !!a.iridescenceMap,
                            el = J && !!a.iridescenceThicknessMap,
                            es = ee && !!a.sheenColorMap,
                            ec = ee && !!a.sheenRoughnessMap,
                            ed = !!a.specularMap,
                            eu = !!a.specularColorMap,
                            ef = !!a.specularIntensityMap,
                            ep = en && !!a.transmissionMap,
                            em = en && !!a.thicknessMap,
                            eh = !!a.gradientMap,
                            e_ = !!a.alphaMap,
                            eg = a.alphaTest > 0,
                            ev = !!a.alphaHash,
                            eS = !!a.extensions,
                            eE = i.y_p;
                        a.toneMapped && (null === N || !0 === N.isXRRenderTarget) && (eE = e.toneMapping);
                        let eM = {
                            shaderID: w,
                            shaderType: a.type,
                            shaderName: a.name,
                            vertexShader: E,
                            fragmentShader: M,
                            defines: a.defines,
                            customVertexShaderID: T,
                            customFragmentShaderID: x,
                            isRawShaderMaterial: !0 === a.isRawShaderMaterial,
                            glslVersion: a.glslVersion,
                            precision: m,
                            batching: F,
                            batchingColor: F && null !== g._colorsTexture,
                            instancing: O,
                            instancingColor: O && null !== g.instanceColor,
                            instancingMorph: O && null !== g.morphTexture,
                            outputColorSpace: null === N ? e.outputColorSpace : !0 === N.isXRRenderTarget ? N.texture.colorSpace : i.ppV.workingColorSpace,
                            alphaToCoverage: !!a.alphaToCoverage,
                            map: B,
                            matcap: G,
                            envMap: H,
                            envMapMode: H && P.mapping,
                            envMapCubeUVHeight: L,
                            aoMap: V,
                            lightMap: W,
                            bumpMap: z,
                            normalMap: k,
                            displacementMap: X,
                            emissiveMap: K,
                            normalMapObjectSpace: k && a.normalMapType === i.vyJ,
                            normalMapTangentSpace: k && a.normalMapType === i.bI3,
                            packedNormalMap: k && a.normalMapType === i.bI3 && ((S = a.normalMap.format) === i.paN || S === i.OtU || S === i.HO_),
                            metalnessMap: q,
                            roughnessMap: Y,
                            anisotropy: j,
                            anisotropyMap: et,
                            clearcoat: Z,
                            clearcoatMap: ei,
                            clearcoatNormalMap: er,
                            clearcoatRoughnessMap: ea,
                            dispersion: Q,
                            retroreflection: $,
                            iridescence: J,
                            iridescenceMap: eo,
                            iridescenceThicknessMap: el,
                            sheen: ee,
                            sheenColorMap: es,
                            sheenRoughnessMap: ec,
                            specularMap: ed,
                            specularColorMap: eu,
                            specularIntensityMap: ef,
                            transmission: en,
                            transmissionMap: ep,
                            thicknessMap: em,
                            gradientMap: eh,
                            opaque: !1 === a.transparent && a.blending === i.NTi && !1 === a.alphaToCoverage,
                            alphaMap: e_,
                            alphaTest: eg,
                            alphaHash: ev,
                            combine: a.combine,
                            mapUv: B && _(a.map.channel),
                            aoMapUv: V && _(a.aoMap.channel),
                            lightMapUv: W && _(a.lightMap.channel),
                            bumpMapUv: z && _(a.bumpMap.channel),
                            normalMapUv: k && _(a.normalMap.channel),
                            displacementMapUv: X && _(a.displacementMap.channel),
                            emissiveMapUv: K && _(a.emissiveMap.channel),
                            metalnessMapUv: q && _(a.metalnessMap.channel),
                            roughnessMapUv: Y && _(a.roughnessMap.channel),
                            anisotropyMapUv: et && _(a.anisotropyMap.channel),
                            clearcoatMapUv: ei && _(a.clearcoatMap.channel),
                            clearcoatNormalMapUv: er && _(a.clearcoatNormalMap.channel),
                            clearcoatRoughnessMapUv: ea && _(a.clearcoatRoughnessMap.channel),
                            iridescenceMapUv: eo && _(a.iridescenceMap.channel),
                            iridescenceThicknessMapUv: el && _(a.iridescenceThicknessMap.channel),
                            sheenColorMapUv: es && _(a.sheenColorMap.channel),
                            sheenRoughnessMapUv: ec && _(a.sheenRoughnessMap.channel),
                            specularMapUv: ed && _(a.specularMap.channel),
                            specularColorMapUv: eu && _(a.specularColorMap.channel),
                            specularIntensityMapUv: ef && _(a.specularIntensityMap.channel),
                            transmissionMapUv: ep && _(a.transmissionMap.channel),
                            thicknessMapUv: em && _(a.thicknessMap.channel),
                            alphaMapUv: e_ && _(a.alphaMap.channel),
                            vertexTangents: !!A.attributes.tangent && (k || j),
                            vertexNormals: !!A.attributes.normal,
                            vertexColors: a.vertexColors,
                            vertexAlphas: !0 === a.vertexColors && !!A.attributes.color && 4 === A.attributes.color.itemSize,
                            pointsUvs: !0 === g.isPoints && !!A.attributes.uv && (B || e_),
                            fog: !!R,
                            useFog: !0 === a.fog,
                            fogExp2: !!R && R.isFogExp2,
                            flatShading: !1 === a.wireframe && (!0 === a.flatShading || void 0 === A.attributes.normal && !1 === k && (a.isMeshLambertMaterial || a.isMeshPhongMaterial || a.isMeshStandardMaterial || a.isMeshPhysicalMaterial)),
                            sizeAttenuation: !0 === a.sizeAttenuation,
                            logarithmicDepthBuffer: p,
                            reversedDepthBuffer: y,
                            skinning: !0 === g.isSkinnedMesh,
                            hasPositionAttribute: void 0 !== A.attributes.position,
                            morphTargets: void 0 !== A.morphAttributes.position,
                            morphNormals: void 0 !== A.morphAttributes.normal,
                            morphColors: void 0 !== A.morphAttributes.color,
                            morphTargetsCount: I,
                            morphTextureStride: D,
                            numSunLights: l.sun.length,
                            numDirLights: l.directional.length,
                            numPointLights: l.point.length,
                            numSpotLights: l.spot.length,
                            numSpotLightMaps: l.spotLightMap.length,
                            numRectAreaLights: l.rectArea.length,
                            numHemiLights: l.hemi.length,
                            numSunLightShadows: l.sunShadowMap.length,
                            numDirLightShadows: l.directionalShadowMap.length,
                            numPointLightShadows: l.pointShadowMap.length,
                            numSpotLightShadows: l.spotShadowMap.length,
                            numSpotLightShadowsWithMaps: l.numSpotLightShadowsWithMaps,
                            numLightProbes: l.numLightProbes,
                            numLightProbeGrids: v.length,
                            numClippingPlanes: o.numPlanes,
                            numClipIntersection: o.numIntersection,
                            dithering: a.dithering,
                            shadowMapEnabled: e.shadowMap.enabled && u.length > 0,
                            shadowMapType: e.shadowMap.type,
                            toneMapping: eE,
                            decodeVideoTexture: B && !0 === a.map.isVideoTexture && i.ppV.getTransfer(a.map.colorSpace) === i.KLL,
                            decodeVideoTextureEmissive: K && !0 === a.emissiveMap.isVideoTexture && i.ppV.getTransfer(a.emissiveMap.colorSpace) === i.KLL,
                            premultipliedAlpha: a.premultipliedAlpha,
                            doubleSided: a.side === i.$EB,
                            flipSided: a.side === i.hsX,
                            useDepthPacking: a.depthPacking >= 0,
                            depthPacking: a.depthPacking || 0,
                            index0AttributeName: a.index0AttributeName,
                            extensionClipCullDistance: eS && !0 === a.extensions.clipCullDistance && t.has("WEBGL_clip_cull_distance"),
                            extensionMultiDraw: (eS && !0 === a.extensions.multiDraw || F) && t.has("WEBGL_multi_draw"),
                            rendererExtensionParallelShaderCompile: t.has("KHR_parallel_shader_compile"),
                            customProgramCacheKey: a.customProgramCacheKey()
                        };
                        return eM.vertexUv1s = d.has(1), eM.vertexUv2s = d.has(2), eM.vertexUv3s = d.has(3), d.clear(), eM
                    },
                    getProgramCacheKey: function(n) {
                        var t, i, r, a;
                        let o = [];
                        if (n.shaderID ? o.push(n.shaderID) : (o.push(n.customVertexShaderID), o.push(n.customFragmentShaderID)), void 0 !== n.defines)
                            for (let e in n.defines) o.push(e), o.push(n.defines[e]);
                        return !1 === n.isRawShaderMaterial && (t = o, i = n, t.push(i.precision), t.push(i.outputColorSpace), t.push(i.envMapMode), t.push(i.envMapCubeUVHeight), t.push(i.mapUv), t.push(i.alphaMapUv), t.push(i.lightMapUv), t.push(i.aoMapUv), t.push(i.bumpMapUv), t.push(i.normalMapUv), t.push(i.displacementMapUv), t.push(i.emissiveMapUv), t.push(i.metalnessMapUv), t.push(i.roughnessMapUv), t.push(i.anisotropyMapUv), t.push(i.clearcoatMapUv), t.push(i.clearcoatNormalMapUv), t.push(i.clearcoatRoughnessMapUv), t.push(i.iridescenceMapUv), t.push(i.iridescenceThicknessMapUv), t.push(i.sheenColorMapUv), t.push(i.sheenRoughnessMapUv), t.push(i.specularMapUv), t.push(i.specularColorMapUv), t.push(i.specularIntensityMapUv), t.push(i.transmissionMapUv), t.push(i.thicknessMapUv), t.push(i.combine), t.push(i.fogExp2), t.push(i.sizeAttenuation), t.push(i.morphTargetsCount), t.push(i.morphAttributeCount), t.push(i.numSunLights), t.push(i.numDirLights), t.push(i.numPointLights), t.push(i.numSpotLights), t.push(i.numSpotLightMaps), t.push(i.numHemiLights), t.push(i.numRectAreaLights), t.push(i.numSunLightShadows), t.push(i.numDirLightShadows), t.push(i.numPointLightShadows), t.push(i.numSpotLightShadows), t.push(i.numSpotLightShadowsWithMaps), t.push(i.numLightProbes), t.push(i.shadowMapType), t.push(i.toneMapping), t.push(i.numClippingPlanes), t.push(i.numClipIntersection), t.push(i.depthPacking), r = o, a = n, l.disableAll(), a.instancing && l.enable(0), a.instancingColor && l.enable(1), a.instancingMorph && l.enable(2), a.matcap && l.enable(3), a.envMap && l.enable(4), a.normalMapObjectSpace && l.enable(5), a.normalMapTangentSpace && l.enable(6), a.clearcoat && l.enable(7), a.iridescence && l.enable(8), a.alphaTest && l.enable(9), a.vertexColors && l.enable(10), a.vertexAlphas && l.enable(11), a.vertexUv1s && l.enable(12), a.vertexUv2s && l.enable(13), a.vertexUv3s && l.enable(14), a.vertexTangents && l.enable(15), a.anisotropy && l.enable(16), a.alphaHash && l.enable(17), a.batching && l.enable(18), a.dispersion && l.enable(19), a.retroreflection && l.enable(24), a.batchingColor && l.enable(20), a.gradientMap && l.enable(21), a.packedNormalMap && l.enable(22), a.vertexNormals && l.enable(23), r.push(l.mask), l.disableAll(), a.fog && l.enable(0), a.useFog && l.enable(1), a.flatShading && l.enable(2), a.logarithmicDepthBuffer && l.enable(3), a.reversedDepthBuffer && l.enable(4), a.skinning && l.enable(5), a.morphTargets && l.enable(6), a.morphNormals && l.enable(7), a.morphColors && l.enable(8), a.premultipliedAlpha && l.enable(9), a.shadowMapEnabled && l.enable(10), a.doubleSided && l.enable(11), a.flipSided && l.enable(12), a.useDepthPacking && l.enable(13), a.dithering && l.enable(14), a.transmission && l.enable(15), a.sheen && l.enable(16), a.opaque && l.enable(17), a.pointsUvs && l.enable(18), a.decodeVideoTexture && l.enable(19), a.decodeVideoTextureEmissive && l.enable(20), a.alphaToCoverage && l.enable(21), a.numLightProbeGrids > 0 && l.enable(22), a.hasPositionAttribute && l.enable(23), r.push(l.mask), o.push(e.outputColorSpace)), o.push(n.customProgramCacheKey), o.join()
                    },
                    getUniforms: function(e) {
                        let n, t = h[e.type];
                        if (t) {
                            let e = s[t];
                            n = i.LlO.clone(e.uniforms)
                        } else n = e.uniforms;
                        return n
                    },
                    acquireProgram: function(n, t) {
                        let i = f.get(t);
                        return void 0 !== i ? ++i.usedTimes : (i = new nt(e, t, n, a), u.push(i), f.set(t, i)), i
                    },
                    releaseProgram: function(e) {
                        if (0 == --e.usedTimes) {
                            let n = u.indexOf(e);
                            u[n] = u[u.length - 1], u.pop(), f.delete(e.cacheKey), e.destroy()
                        }
                    },
                    releaseShaderCache: function(e) {
                        c.remove(e)
                    },
                    programs: u,
                    dispose: function() {
                        c.dispose()
                    }
                }
            }

            function nl() {
                let e = new WeakMap;
                return {
                    has: function(n) {
                        return e.has(n)
                    },
                    get: function(n) {
                        let t = e.get(n);
                        return void 0 === t && (t = {}, e.set(n, t)), t
                    },
                    remove: function(n) {
                        e.delete(n)
                    },
                    update: function(n, t, i) {
                        e.get(n)[t] = i
                    },
                    dispose: function() {
                        e = new WeakMap
                    }
                }
            }

            function ns(e, n) {
                if (e.groupOrder !== n.groupOrder) return e.groupOrder - n.groupOrder;
                if (e.renderOrder !== n.renderOrder) return e.renderOrder - n.renderOrder;
                if (e.material.id !== n.material.id) return e.material.id - n.material.id;
                if (e.materialVariant !== n.materialVariant) return e.materialVariant - n.materialVariant;
                if (e.z !== n.z) return e.z - n.z;
                else return e.id - n.id
            }

            function nc(e, n) {
                return e.groupOrder !== n.groupOrder ? e.groupOrder - n.groupOrder : e.renderOrder !== n.renderOrder ? e.renderOrder - n.renderOrder : e.z !== n.z ? n.z - e.z : e.id - n.id
            }

            function nd() {
                let e = [],
                    n = 0,
                    t = [],
                    i = [],
                    r = [];

                function a(e) {
                    let n = 0;
                    return e.isInstancedMesh && (n += 2), e.isSkinnedMesh && (n += 1), n
                }

                function o(t, i, r, o, l, s) {
                    let c = e[n];
                    return void 0 === c ? (c = {
                        id: t.id,
                        object: t,
                        geometry: i,
                        material: r,
                        materialVariant: a(t),
                        groupOrder: o,
                        renderOrder: t.renderOrder,
                        z: l,
                        group: s
                    }, e[n] = c) : (c.id = t.id, c.object = t, c.geometry = i, c.material = r, c.materialVariant = a(t), c.groupOrder = o, c.renderOrder = t.renderOrder, c.z = l, c.group = s), n++, c
                }
                return {
                    opaque: t,
                    transmissive: i,
                    transparent: r,
                    init: function() {
                        n = 0, t.length = 0, i.length = 0, r.length = 0
                    },
                    push: function(e, n, a, l, s, c, d) {
                        !0 === d.reversedDepth && (s = -s);
                        let u = o(e, n, a, l, s, c);
                        a.transmission > 0 ? i.push(u) : !0 === a.transparent ? r.push(u) : t.push(u)
                    },
                    unshift: function(e, n, a, l, s, c) {
                        let d = o(e, n, a, l, s, c);
                        a.transmission > 0 ? i.unshift(d) : !0 === a.transparent ? r.unshift(d) : t.unshift(d)
                    },
                    finish: function() {
                        for (let t = n, i = e.length; t < i; t++) {
                            let n = e[t];
                            if (null === n.id) break;
                            n.id = null, n.object = null, n.geometry = null, n.material = null, n.group = null
                        }
                    },
                    sort: function(e, n) {
                        t.length > 1 && t.sort(e || ns), i.length > 1 && i.sort(n || nc), r.length > 1 && r.sort(n || nc)
                    }
                }
            }

            function nu() {
                let e = new WeakMap;
                return {
                    get: function(n, t) {
                        let i, r = e.get(n);
                        return void 0 === r ? (i = new nd, e.set(n, [i])) : t >= r.length ? (i = new nd, r.push(i)) : i = r[t], i
                    },
                    dispose: function() {
                        e = new WeakMap
                    }
                }
            }

            function nf() {
                let e = {};
                return {
                    get: function(n) {
                        let t;
                        if (void 0 !== e[n.id]) return e[n.id];
                        switch (n.type) {
                            case "SunLight":
                            case "DirectionalLight":
                                t = {
                                    direction: new i.Pq0,
                                    color: new i.Q1f
                                };
                                break;
                            case "SpotLight":
                                t = {
                                    position: new i.Pq0,
                                    direction: new i.Pq0,
                                    color: new i.Q1f,
                                    distance: 0,
                                    coneCos: 0,
                                    penumbraCos: 0,
                                    decay: 0
                                };
                                break;
                            case "PointLight":
                                t = {
                                    position: new i.Pq0,
                                    color: new i.Q1f,
                                    distance: 0,
                                    decay: 0
                                };
                                break;
                            case "HemisphereLight":
                                t = {
                                    direction: new i.Pq0,
                                    skyColor: new i.Q1f,
                                    groundColor: new i.Q1f
                                };
                                break;
                            case "RectAreaLight":
                                t = {
                                    color: new i.Q1f,
                                    position: new i.Pq0,
                                    halfWidth: new i.Pq0,
                                    halfHeight: new i.Pq0
                                }
                        }
                        return e[n.id] = t, t
                    }
                }
            }
            let np = 0;

            function nm(e, n) {
                return 2 * !!n.castShadow - 2 * !!e.castShadow + +!!n.map - !!e.map
            }

            function nh(e) {
                let n, t = new nf,
                    r = (n = {}, {
                        get: function(e) {
                            let t;
                            if (void 0 !== n[e.id]) return n[e.id];
                            switch (e.type) {
                                case "SunLight":
                                case "DirectionalLight":
                                case "SpotLight":
                                    t = {
                                        shadowIntensity: 1,
                                        shadowBias: 0,
                                        shadowNormalBias: 0,
                                        shadowRadius: 1,
                                        shadowMapSize: new i.I9Y
                                    };
                                    break;
                                case "PointLight":
                                    t = {
                                        shadowIntensity: 1,
                                        shadowBias: 0,
                                        shadowNormalBias: 0,
                                        shadowRadius: 1,
                                        shadowMapSize: new i.I9Y,
                                        shadowCameraNear: 1,
                                        shadowCameraFar: 1e3
                                    }
                            }
                            return n[e.id] = t, t
                        }
                    }),
                    a = {
                        version: 0,
                        hash: {
                            sunLength: -1,
                            directionalLength: -1,
                            pointLength: -1,
                            spotLength: -1,
                            rectAreaLength: -1,
                            hemiLength: -1,
                            numSunShadows: -1,
                            numDirectionalShadows: -1,
                            numPointShadows: -1,
                            numSpotShadows: -1,
                            numSpotMaps: -1,
                            numLightProbes: -1
                        },
                        ambient: [0, 0, 0],
                        probe: [],
                        sun: [],
                        sunShadow: [],
                        sunShadowMap: [],
                        sunShadowMatrix: [],
                        sunShadowCascade: [],
                        directional: [],
                        directionalShadow: [],
                        directionalShadowMap: [],
                        directionalShadowMatrix: [],
                        spot: [],
                        spotLightMap: [],
                        spotShadow: [],
                        spotShadowMap: [],
                        spotLightMatrix: [],
                        rectArea: [],
                        rectAreaLTC1: null,
                        rectAreaLTC2: null,
                        point: [],
                        pointShadow: [],
                        pointShadowMap: [],
                        pointShadowMatrix: [],
                        hemi: [],
                        numSpotLightShadowsWithMaps: 0,
                        numLightProbes: 0
                    };
                for (let e = 0; e < 9; e++) a.probe.push(new i.Pq0);
                let o = new i.Pq0,
                    s = new i.kn4,
                    c = new i.kn4;
                return {
                    setup: function(n) {
                        let o = 0,
                            s = 0,
                            c = 0;
                        for (let e = 0; e < 9; e++) a.probe[e].set(0, 0, 0);
                        let d = 0,
                            u = 0,
                            f = 0,
                            p = 0,
                            m = 0,
                            h = 0,
                            _ = 0,
                            g = 0,
                            v = 0,
                            S = 0,
                            E = 0,
                            M = 0,
                            T = 0,
                            x = 0;
                        n.sort(nm);
                        for (let e = 0, l = n.length; e < l; e++) {
                            let l = n[e],
                                R = l.color,
                                A = l.intensity,
                                b = l.distance,
                                C = null;
                            if (l.shadow && l.shadow.map && (C = l.shadow.map.texture.format === i.paN ? l.shadow.map.texture : l.shadow.map.depthTexture || l.shadow.map.texture), l.isAmbientLight) o += R.r * A, s += R.g * A, c += R.b * A;
                            else if (l.isLightProbe) {
                                for (let e = 0; e < 9; e++) a.probe[e].addScaledVector(l.sh.coefficients[e], A);
                                x++
                            } else if (l.isSunLight) {
                                let e = t.get(l);
                                if (e.color.copy(l.color).multiplyScalar(l.intensity), l.castShadow) {
                                    let e = l.shadow,
                                        n = r.get(l);
                                    n.shadowIntensity = e.intensity, n.shadowBias = e.bias, n.shadowNormalBias = e.normalBias, n.shadowRadius = e.radius, n.shadowMapSize.copy(e.mapSize).multiply(e.getFrameExtents()), a.sunShadow[u] = n, a.sunShadowMap[u] = C;
                                    let t = e.getViewportCount();
                                    for (let n = 0; n < t; n++) a.sunShadowMatrix[f + n] = e.getMatrix(n), a.sunShadowCascade[f + n] = e._cascadeData[n];
                                    f += t, u++
                                }
                                a.sun[d] = e, d++
                            } else if (l.isDirectionalLight) {
                                let e = t.get(l);
                                if (e.color.copy(l.color).multiplyScalar(l.intensity), l.castShadow) {
                                    let e = l.shadow,
                                        n = r.get(l);
                                    n.shadowIntensity = e.intensity, n.shadowBias = e.bias, n.shadowNormalBias = e.normalBias, n.shadowRadius = e.radius, n.shadowMapSize = e.mapSize, a.directionalShadow[p] = n, a.directionalShadowMap[p] = C, a.directionalShadowMatrix[p] = l.shadow.matrix, v++
                                }
                                a.directional[p] = e, p++
                            } else if (l.isSpotLight) {
                                let e = t.get(l);
                                e.position.setFromMatrixPosition(l.matrixWorld), e.color.copy(R).multiplyScalar(A), e.distance = b, e.coneCos = Math.cos(l.angle), e.penumbraCos = Math.cos(l.angle * (1 - l.penumbra)), e.decay = l.decay, a.spot[h] = e;
                                let n = l.shadow;
                                if (l.map && (a.spotLightMap[M] = l.map, M++, n.updateMatrices(l), l.castShadow && T++), a.spotLightMatrix[h] = n.matrix, l.castShadow) {
                                    let e = r.get(l);
                                    e.shadowIntensity = n.intensity, e.shadowBias = n.bias, e.shadowNormalBias = n.normalBias, e.shadowRadius = n.radius, e.shadowMapSize = n.mapSize, a.spotShadow[h] = e, a.spotShadowMap[h] = C, E++
                                }
                                h++
                            } else if (l.isRectAreaLight) {
                                let e = t.get(l);
                                e.color.copy(R).multiplyScalar(A), e.halfWidth.set(.5 * l.width, 0, 0), e.halfHeight.set(0, .5 * l.height, 0), a.rectArea[_] = e, _++
                            } else if (l.isPointLight) {
                                let e = t.get(l);
                                if (e.color.copy(l.color).multiplyScalar(l.intensity), e.distance = l.distance, e.decay = l.decay, l.castShadow) {
                                    let e = l.shadow,
                                        n = r.get(l);
                                    n.shadowIntensity = e.intensity, n.shadowBias = e.bias, n.shadowNormalBias = e.normalBias, n.shadowRadius = e.radius, n.shadowMapSize = e.mapSize, n.shadowCameraNear = e.camera.near, n.shadowCameraFar = e.camera.far, a.pointShadow[m] = n, a.pointShadowMap[m] = C, a.pointShadowMatrix[m] = l.shadow.matrix, S++
                                }
                                a.point[m] = e, m++
                            } else if (l.isHemisphereLight) {
                                let e = t.get(l);
                                e.skyColor.copy(l.color).multiplyScalar(A), e.groundColor.copy(l.groundColor).multiplyScalar(A), a.hemi[g] = e, g++
                            }
                        }
                        _ > 0 && (!0 === e.has("OES_texture_float_linear") ? (a.rectAreaLTC1 = l.LTC_FLOAT_1, a.rectAreaLTC2 = l.LTC_FLOAT_2) : (a.rectAreaLTC1 = l.LTC_HALF_1, a.rectAreaLTC2 = l.LTC_HALF_2)), a.ambient[0] = o, a.ambient[1] = s, a.ambient[2] = c;
                        let R = a.hash;
                        (R.sunLength !== d || R.directionalLength !== p || R.pointLength !== m || R.spotLength !== h || R.rectAreaLength !== _ || R.hemiLength !== g || R.numSunShadows !== u || R.numDirectionalShadows !== v || R.numPointShadows !== S || R.numSpotShadows !== E || R.numSpotMaps !== M || R.numLightProbes !== x) && (a.sun.length = d, a.directional.length = p, a.spot.length = h, a.rectArea.length = _, a.point.length = m, a.hemi.length = g, a.sunShadow.length = u, a.sunShadowMap.length = u, a.sunShadowMatrix.length = f, a.sunShadowCascade.length = f, a.directionalShadow.length = v, a.directionalShadowMap.length = v, a.directionalShadowMatrix.length = v, a.pointShadow.length = S, a.pointShadowMap.length = S, a.pointShadowMatrix.length = S, a.spotShadow.length = E, a.spotShadowMap.length = E, a.spotLightMatrix.length = E + M - T, a.spotLightMap.length = M, a.numSpotLightShadowsWithMaps = T, a.numLightProbes = x, R.sunLength = d, R.directionalLength = p, R.pointLength = m, R.spotLength = h, R.rectAreaLength = _, R.hemiLength = g, R.numSunShadows = u, R.numDirectionalShadows = v, R.numPointShadows = S, R.numSpotShadows = E, R.numSpotMaps = M, R.numLightProbes = x, a.version = np++)
                    },
                    setupView: function(e, n) {
                        let t = 0,
                            i = 0,
                            r = 0,
                            l = 0,
                            d = 0,
                            u = 0,
                            f = n.matrixWorldInverse;
                        for (let n = 0, p = e.length; n < p; n++) {
                            let p = e[n];
                            if (p.isSunLight) {
                                let e = a.sun[t];
                                e.direction.setFromMatrixPosition(p.matrixWorld), e.direction.transformDirection(f), t++
                            } else if (p.isDirectionalLight) {
                                let e = a.directional[i];
                                e.direction.setFromMatrixPosition(p.matrixWorld), o.setFromMatrixPosition(p.target.matrixWorld), e.direction.sub(o), e.direction.transformDirection(f), i++
                            } else if (p.isSpotLight) {
                                let e = a.spot[l];
                                e.position.setFromMatrixPosition(p.matrixWorld), e.position.applyMatrix4(f), e.direction.setFromMatrixPosition(p.matrixWorld), o.setFromMatrixPosition(p.target.matrixWorld), e.direction.sub(o), e.direction.transformDirection(f), l++
                            } else if (p.isRectAreaLight) {
                                let e = a.rectArea[d];
                                e.position.setFromMatrixPosition(p.matrixWorld), e.position.applyMatrix4(f), c.identity(), s.copy(p.matrixWorld), s.premultiply(f), c.extractRotation(s), e.halfWidth.set(.5 * p.width, 0, 0), e.halfHeight.set(0, .5 * p.height, 0), e.halfWidth.applyMatrix4(c), e.halfHeight.applyMatrix4(c), d++
                            } else if (p.isPointLight) {
                                let e = a.point[r];
                                e.position.setFromMatrixPosition(p.matrixWorld), e.position.applyMatrix4(f), r++
                            } else if (p.isHemisphereLight) {
                                let e = a.hemi[u];
                                e.direction.setFromMatrixPosition(p.matrixWorld), e.direction.transformDirection(f), u++
                            }
                        }
                    },
                    state: a
                }
            }

            function n_(e) {
                let n = new nh(e),
                    t = [],
                    i = [],
                    r = [],
                    a = {
                        lightsArray: t,
                        shadowsArray: i,
                        lightProbeGridArray: r,
                        camera: null,
                        lights: n,
                        transmissionRenderTarget: {},
                        textureUnits: 0
                    };
                return {
                    init: function(e) {
                        a.camera = e, t.length = 0, i.length = 0, r.length = 0
                    },
                    state: a,
                    setupLights: function() {
                        n.setup(t)
                    },
                    setupLightsView: function(e) {
                        n.setupView(t, e)
                    },
                    pushLight: function(e) {
                        t.push(e)
                    },
                    pushShadow: function(e) {
                        i.push(e)
                    },
                    pushLightProbeGrid: function(e) {
                        r.push(e)
                    }
                }
            }

            function ng(e) {
                let n = new WeakMap;
                return {
                    get: function(t, i = 0) {
                        let r, a = n.get(t);
                        return void 0 === a ? (r = new n_(e), n.set(t, [r])) : i >= a.length ? (r = new n_(e), a.push(r)) : r = a[i], r
                    },
                    dispose: function() {
                        n = new WeakMap
                    }
                }
            }
            let nv = [new i.Pq0(1, 0, 0), new i.Pq0(-1, 0, 0), new i.Pq0(0, 1, 0), new i.Pq0(0, -1, 0), new i.Pq0(0, 0, 1), new i.Pq0(0, 0, -1)],
                nS = [new i.Pq0(0, -1, 0), new i.Pq0(0, -1, 0), new i.Pq0(0, 0, 1), new i.Pq0(0, 0, -1), new i.Pq0(0, -1, 0), new i.Pq0(0, -1, 0)],
                nE = new i.kn4,
                nM = new i.Pq0,
                nT = new i.Pq0;

            function nx(e, n, t) {
                let r = new i.PPD,
                    a = new i.I9Y,
                    o = new i.I9Y,
                    l = new i.IUQ,
                    s = new i.CSG,
                    c = new i.aVO,
                    d = {},
                    u = t.maxTextureSize,
                    f = {
                        [i.hB5]: i.hsX,
                        [i.hsX]: i.hB5,
                        [i.$EB]: i.$EB
                    },
                    p = new i.BKk({
                        defines: {
                            VSM_SAMPLES: 8
                        },
                        uniforms: {
                            shadow_pass: {
                                value: null
                            },
                            resolution: {
                                value: new i.I9Y
                            },
                            radius: {
                                value: 4
                            }
                        },
                        vertexShader: "void main() {\n	gl_Position = vec4( position, 1.0 );\n}",
                        fragmentShader: "uniform sampler2D shadow_pass;\nuniform vec2 resolution;\nuniform float radius;\nvoid main() {\n	const float samples = float( VSM_SAMPLES );\n	float mean = 0.0;\n	float squared_mean = 0.0;\n	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );\n	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;\n	for ( float i = 0.0; i < samples; i ++ ) {\n		float uvOffset = uvStart + i * uvStride;\n		#ifdef HORIZONTAL_PASS\n			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;\n			mean += distribution.x;\n			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;\n		#else\n			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;\n			mean += depth;\n			squared_mean += depth * depth;\n		#endif\n	}\n	mean = mean / samples;\n	squared_mean = squared_mean / samples;\n	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );\n	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );\n}"
                    }),
                    m = p.clone();
                m.defines.HORIZONTAL_PASS = 1;
                let h = new i.LoY;
                h.setAttribute("position", new i.THS(new Float32Array([-1, -1, .5, 3, -1, .5, -1, 3, .5]), 3));
                let _ = new i.eaF(h, p),
                    g = this;
                this.enabled = !1, this.autoUpdate = !0, this.needsUpdate = !1, this.type = i.QP0;
                let v = this.type;

                function S(n, t, r, a) {
                    let o = null,
                        l = !0 === r.isPointLight ? n.customDistanceMaterial : n.customDepthMaterial;
                    if (void 0 !== l) o = l;
                    else if (o = !0 === r.isPointLight ? c : s, e.localClippingEnabled && !0 === t.clipShadows && Array.isArray(t.clippingPlanes) && 0 !== t.clippingPlanes.length || t.displacementMap && 0 !== t.displacementScale || t.alphaMap && t.alphaTest > 0 || t.map && t.alphaTest > 0 || !0 === t.alphaToCoverage) {
                        let e = o.uuid,
                            n = t.uuid,
                            i = d[e];
                        void 0 === i && (i = {}, d[e] = i);
                        let r = i[n];
                        void 0 === r && (r = o.clone(), i[n] = r, t.addEventListener("dispose", E)), o = r
                    }
                    return o.visible = t.visible, o.wireframe = t.wireframe, a === i.RyA ? o.side = null !== t.shadowSide ? t.shadowSide : t.side : o.side = null !== t.shadowSide ? t.shadowSide : f[t.side], o.alphaMap = t.alphaMap, o.alphaTest = !0 === t.alphaToCoverage ? .5 : t.alphaTest, o.map = t.map, o.clipShadows = t.clipShadows, o.clippingPlanes = t.clippingPlanes, o.clipIntersection = t.clipIntersection, o.displacementMap = t.displacementMap, o.displacementScale = t.displacementScale, o.displacementBias = t.displacementBias, o.wireframeLinewidth = t.wireframeLinewidth, o.linewidth = t.linewidth, !0 === r.isPointLight && !0 === o.isMeshDistanceMaterial && (e.properties.get(o).light = r), o
                }

                function E(e) {
                    for (let n in e.target.removeEventListener("dispose", E), d) {
                        let t = d[n],
                            i = e.target.uuid;
                        i in t && (t[i].dispose(), delete t[i])
                    }
                }
                this.render = function(t, s, c) {
                    if (!1 === g.enabled || !1 === g.autoUpdate && !1 === g.needsUpdate || 0 === t.length) return;
                    this.type === i.Wk7 && ((0, i.R8M)("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."), this.type = i.QP0);
                    let d = e.getRenderTarget(),
                        f = e.getActiveCubeFace(),
                        h = e.getActiveMipmapLevel(),
                        E = e.state;
                    E.setBlending(i.XIg), !0 === E.buffers.depth.getReversed() ? E.buffers.color.setClear(0, 0, 0, 0) : E.buffers.color.setClear(1, 1, 1, 1), E.buffers.depth.setTest(!0), E.setScissorTest(!1);
                    let M = v !== this.type;
                    M && s.traverse(function(e) {
                        e.material && (Array.isArray(e.material) ? e.material.forEach(e => e.needsUpdate = !0) : e.material.needsUpdate = !0)
                    });
                    for (let d = 0, f = t.length; d < f; d++) {
                        let f = t[d],
                            h = f.shadow;
                        if (void 0 === h) {
                            (0, i.R8M)("WebGLShadowMap:", f, "has no shadow.");
                            continue
                        }
                        if (!1 === h.autoUpdate && !1 === h.needsUpdate) continue;
                        a.copy(h.mapSize);
                        let g = h.getFrameExtents();
                        a.multiply(g), o.copy(h.mapSize), (a.x > u || a.y > u) && (a.x > u && (o.x = Math.floor(u / g.x), a.x = o.x * g.x, h.mapSize.x = o.x), a.y > u && (o.y = Math.floor(u / g.y), a.y = o.y * g.y, h.mapSize.y = o.y));
                        let v = e.state.buffers.depth.getReversed();
                        if (h.camera._reversedDepth = v, null === h.map || !0 === M) {
                            if (null !== h.map && (null !== h.map.depthTexture && (h.map.depthTexture.dispose(), h.map.depthTexture = null), h.map.dispose()), this.type === i.RyA) {
                                if (f.isPointLight) {
                                    (0, i.R8M)("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");
                                    continue
                                }
                                h.map = new i.nWS(a.x, a.y, {
                                    format: i.paN,
                                    type: i.ix0,
                                    minFilter: i.k6q,
                                    magFilter: i.k6q,
                                    generateMipmaps: !1
                                }), h.map.texture.name = f.name + ".shadowMap", h.map.depthTexture = new i.VCu(a.x, a.y, i.RQf), h.map.depthTexture.name = f.name + ".shadowMapDepth", h.map.depthTexture.format = i.zdS, h.map.depthTexture.compareFunction = null, h.map.depthTexture.minFilter = i.hxR, h.map.depthTexture.magFilter = i.hxR
                            } else f.isPointLight ? (h.map = new U(a.x), h.map.depthTexture = new i.Gc6(a.x, i.bkx)) : (h.map = new i.nWS(a.x, a.y), h.map.depthTexture = new i.VCu(a.x, a.y, i.bkx)), h.map.depthTexture.name = f.name + ".shadowMap", h.map.depthTexture.format = i.zdS, this.type === i.QP0 ? (h.map.depthTexture.compareFunction = v ? i.gWB : i.TiK, h.map.depthTexture.minFilter = i.k6q, h.map.depthTexture.magFilter = i.k6q) : (h.map.depthTexture.compareFunction = null, h.map.depthTexture.minFilter = i.hxR, h.map.depthTexture.magFilter = i.hxR);
                            h.camera.updateProjectionMatrix()
                        }!0 !== h.map.isWebGLCubeRenderTarget && (h.map.width !== a.x || h.map.height !== a.y) && h.map.setSize(a.x, a.y);
                        let T = h.map.isWebGLCubeRenderTarget ? 6 : h.getViewportCount();
                        !0 !== f.isPointLight && h.updateMatrices(f, c);
                        for (let t = 0; t < T; t++) {
                            let a = h.getCamera(t);
                            if (f.isPointLight) {
                                let e = h.camera,
                                    n = h.matrix,
                                    i = f.distance || e.far;
                                i !== e.far && (e.far = i, e.updateProjectionMatrix()), nM.setFromMatrixPosition(f.matrixWorld), e.position.copy(nM), nT.copy(e.position), nT.add(nv[t]), e.up.copy(nS[t]), e.lookAt(nT), e.updateMatrixWorld(), n.makeTranslation(-nM.x, -nM.y, -nM.z), nE.multiplyMatrices(e.projectionMatrix, e.matrixWorldInverse), h._frustum.setFromProjectionMatrix(nE, e.coordinateSystem, e.reversedDepth)
                            }
                            if (h.map.isWebGLCubeRenderTarget) e.setRenderTarget(h.map, t), e.clear();
                            else {
                                0 === t && (e.setRenderTarget(h.map), e.clear());
                                let n = h.getViewport(t);
                                l.set(o.x * n.x, o.y * n.y, o.x * n.z, o.y * n.w), E.viewport(l)
                            }
                            r = h.getFrustum(t),
                                function t(a, o, l, s, c) {
                                    if (!1 === a.visible) return;
                                    if (a.layers.test(o.layers) && (a.isMesh || a.isLine || a.isPoints) && (a.castShadow || a.receiveShadow && c === i.RyA) && (!a.frustumCulled || a.intersectsFrustum(r))) {
                                        a.modelViewMatrix.multiplyMatrices(l.matrixWorldInverse, a.matrixWorld);
                                        let t = n.update(a),
                                            i = a.material;
                                        if (Array.isArray(i)) {
                                            let n = t.groups;
                                            for (let r = 0, d = n.length; r < d; r++) {
                                                let d = n[r],
                                                    u = i[d.materialIndex];
                                                if (u && u.visible) {
                                                    let n = S(a, u, s, c);
                                                    a.onBeforeShadow(e, a, o, l, t, n, d), e.renderBufferDirect(l, null, t, n, a, d), a.onAfterShadow(e, a, o, l, t, n, d)
                                                }
                                            }
                                        } else if (i.visible) {
                                            let n = S(a, i, s, c);
                                            a.onBeforeShadow(e, a, o, l, t, n, null), e.renderBufferDirect(l, null, t, n, a, null), a.onAfterShadow(e, a, o, l, t, n, null)
                                        }
                                    }
                                    let d = a.children;
                                    for (let e = 0, n = d.length; e < n; e++) t(d[e], o, l, s, c)
                                }(s, c, a, f, this.type)
                        }!0 !== h.isPointLightShadow && this.type === i.RyA && function(t, r) {
                            let o = n.update(_);
                            p.defines.VSM_SAMPLES !== t.blurSamples && (p.defines.VSM_SAMPLES = t.blurSamples, m.defines.VSM_SAMPLES = t.blurSamples, p.needsUpdate = !0, m.needsUpdate = !0), null === t.mapPass ? t.mapPass = new i.nWS(a.x, a.y, {
                                format: i.paN,
                                type: i.ix0
                            }) : (t.mapPass.width !== t.map.width || t.mapPass.height !== t.map.height) && t.mapPass.setSize(t.map.width, t.map.height), p.uniforms.shadow_pass.value = t.map.depthTexture, p.uniforms.resolution.value.set(t.map.width, t.map.height), p.uniforms.radius.value = t.radius, e.setRenderTarget(t.mapPass), e.clear(), e.renderBufferDirect(r, null, o, p, _, null), m.uniforms.shadow_pass.value = t.mapPass.texture, m.uniforms.resolution.value.set(t.map.width, t.map.height), m.uniforms.radius.value = t.radius, e.setRenderTarget(t.map), e.clear(), e.renderBufferDirect(r, null, o, m, _, null)
                        }(h, c), h.needsUpdate = !1
                    }
                    v = this.type, g.needsUpdate = !1, e.setRenderTarget(d, f, h)
                }
            }

            function nR(e, n) {
                let t = new function() {
                        let n = !1,
                            t = new i.IUQ,
                            r = null,
                            a = new i.IUQ(0, 0, 0, 0);
                        return {
                            setMask: function(t) {
                                r === t || n || (e.colorMask(t, t, t, t), r = t)
                            },
                            setLocked: function(e) {
                                n = e
                            },
                            setClear: function(n, i, r, o, l) {
                                !0 === l && (n *= o, i *= o, r *= o), t.set(n, i, r, o), !1 === a.equals(t) && (e.clearColor(n, i, r, o), a.copy(t))
                            },
                            reset: function() {
                                n = !1, r = null, a.set(-1, 0, 0, 0)
                            }
                        }
                    },
                    r = new function() {
                        let t = !1,
                            r = !1,
                            a = null,
                            o = null,
                            l = null;
                        return {
                            setReversed: function(e) {
                                if (r !== e) {
                                    let t = n.get("EXT_clip_control");
                                    e ? t.clipControlEXT(t.LOWER_LEFT_EXT, t.ZERO_TO_ONE_EXT) : t.clipControlEXT(t.LOWER_LEFT_EXT, t.NEGATIVE_ONE_TO_ONE_EXT), r = e;
                                    let i = l;
                                    l = null, this.setClear(i)
                                }
                            },
                            getReversed: function() {
                                return r
                            },
                            setTest: function(n) {
                                n ? V(e.DEPTH_TEST) : W(e.DEPTH_TEST)
                            },
                            setMask: function(n) {
                                a === n || t || (e.depthMask(n), a = n)
                            },
                            setFunc: function(n) {
                                if (r && (n = i.ri6[n]), o !== n) {
                                    switch (n) {
                                        case i.eHc:
                                            e.depthFunc(e.NEVER);
                                            break;
                                        case i.lGu:
                                            e.depthFunc(e.ALWAYS);
                                            break;
                                        case i.brA:
                                            e.depthFunc(e.LESS);
                                            break;
                                        case i.xSv:
                                            e.depthFunc(e.LEQUAL);
                                            break;
                                        case i.U3G:
                                            e.depthFunc(e.EQUAL);
                                            break;
                                        case i.Gwm:
                                            e.depthFunc(e.GEQUAL);
                                            break;
                                        case i.K52:
                                            e.depthFunc(e.GREATER);
                                            break;
                                        case i.bw0:
                                            e.depthFunc(e.NOTEQUAL);
                                            break;
                                        default:
                                            e.depthFunc(e.LEQUAL)
                                    }
                                    o = n
                                }
                            },
                            setLocked: function(e) {
                                t = e
                            },
                            setClear: function(n) {
                                l !== n && (l = n, r && (n = 1 - n), e.clearDepth(n))
                            },
                            reset: function() {
                                t = !1, a = null, o = null, l = null, r = !1
                            }
                        }
                    },
                    a = new function() {
                        let n = !1,
                            t = null,
                            i = null,
                            r = null,
                            a = null,
                            o = null,
                            l = null,
                            s = null,
                            c = null;
                        return {
                            setTest: function(t) {
                                n || (t ? V(e.STENCIL_TEST) : W(e.STENCIL_TEST))
                            },
                            setMask: function(i) {
                                t === i || n || (e.stencilMask(i), t = i)
                            },
                            setFunc: function(n, t, o) {
                                (i !== n || r !== t || a !== o) && (e.stencilFunc(n, t, o), i = n, r = t, a = o)
                            },
                            setOp: function(n, t, i) {
                                (o !== n || l !== t || s !== i) && (e.stencilOp(n, t, i), o = n, l = t, s = i)
                            },
                            setLocked: function(e) {
                                n = e
                            },
                            setClear: function(n) {
                                c !== n && (e.clearStencil(n), c = n)
                            },
                            reset: function() {
                                n = !1, t = null, i = null, r = null, a = null, o = null, l = null, s = null, c = null
                            }
                        }
                    },
                    o = new WeakMap,
                    l = new WeakMap,
                    s = {},
                    c = {},
                    d = {},
                    u = new WeakMap,
                    f = [],
                    p = null,
                    m = !1,
                    h = null,
                    _ = null,
                    g = null,
                    v = null,
                    S = null,
                    E = null,
                    M = null,
                    T = new i.Q1f(0, 0, 0),
                    x = 0,
                    R = !1,
                    A = null,
                    b = null,
                    C = null,
                    P = null,
                    L = null,
                    w = e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),
                    U = !1,
                    I = e.getParameter(e.VERSION); - 1 !== I.indexOf("WebGL") ? U = parseFloat(/^WebGL (\d)/.exec(I)[1]) >= 1 : -1 !== I.indexOf("OpenGL ES") && (U = parseFloat(/^OpenGL ES (\d)/.exec(I)[1]) >= 2);
                let D = null,
                    N = {},
                    y = e.getParameter(e.SCISSOR_BOX),
                    O = e.getParameter(e.VIEWPORT),
                    F = new i.IUQ().fromArray(y),
                    B = new i.IUQ().fromArray(O);

                function G(n, t, i, r) {
                    let a = new Uint8Array(4),
                        o = e.createTexture();
                    e.bindTexture(n, o), e.texParameteri(n, e.TEXTURE_MIN_FILTER, e.NEAREST), e.texParameteri(n, e.TEXTURE_MAG_FILTER, e.NEAREST);
                    for (let o = 0; o < i; o++) n === e.TEXTURE_3D || n === e.TEXTURE_2D_ARRAY ? e.texImage3D(t, 0, e.RGBA, 1, 1, r, 0, e.RGBA, e.UNSIGNED_BYTE, a) : e.texImage2D(t + o, 0, e.RGBA, 1, 1, 0, e.RGBA, e.UNSIGNED_BYTE, a);
                    return o
                }
                let H = {};

                function V(n) {
                    !0 !== s[n] && (e.enable(n), s[n] = !0)
                }

                function W(n) {
                    !1 !== s[n] && (e.disable(n), s[n] = !1)
                }
                H[e.TEXTURE_2D] = G(e.TEXTURE_2D, e.TEXTURE_2D, 1), H[e.TEXTURE_CUBE_MAP] = G(e.TEXTURE_CUBE_MAP, e.TEXTURE_CUBE_MAP_POSITIVE_X, 6), H[e.TEXTURE_2D_ARRAY] = G(e.TEXTURE_2D_ARRAY, e.TEXTURE_2D_ARRAY, 1, 1), H[e.TEXTURE_3D] = G(e.TEXTURE_3D, e.TEXTURE_3D, 1, 1), t.setClear(0, 0, 0, 1), r.setClear(1), a.setClear(0), V(e.DEPTH_TEST), r.setFunc(i.xSv), K(!1), q(i.Vb5), V(e.CULL_FACE), X(i.XIg);
                let z = {
                    [i.gO9]: e.FUNC_ADD,
                    [i.FXf]: e.FUNC_SUBTRACT,
                    [i.nST]: e.FUNC_REVERSE_SUBTRACT
                };
                z[i.znC] = e.MIN, z[i.$ei] = e.MAX;
                let k = {
                    [i.ojh]: e.ZERO,
                    [i.qad]: e.ONE,
                    [i.f4X]: e.SRC_COLOR,
                    [i.ie2]: e.SRC_ALPHA,
                    [i.hgQ]: e.SRC_ALPHA_SATURATE,
                    [i.wn6]: e.DST_COLOR,
                    [i.hdd]: e.DST_ALPHA,
                    [i.LiQ]: e.ONE_MINUS_SRC_COLOR,
                    [i.OuU]: e.ONE_MINUS_SRC_ALPHA,
                    [i.aEY]: e.ONE_MINUS_DST_COLOR,
                    [i.Nt7]: e.ONE_MINUS_DST_ALPHA,
                    [i.RrE]: e.CONSTANT_COLOR,
                    [i.$Yl]: e.ONE_MINUS_CONSTANT_COLOR,
                    [i.e0p]: e.CONSTANT_ALPHA,
                    [i.ov9]: e.ONE_MINUS_CONSTANT_ALPHA
                };

                function X(n, t, r, a, o, l, s, c, d, u) {
                    if (n === i.XIg) {
                        !0 === m && (W(e.BLEND), m = !1);
                        return
                    }
                    if (!1 === m && (V(e.BLEND), m = !0), n !== i.bCz) {
                        if (n !== h || u !== R) {
                            if ((_ !== i.gO9 || S !== i.gO9) && (e.blendEquation(e.FUNC_ADD), _ = i.gO9, S = i.gO9), u) switch (n) {
                                case i.NTi:
                                    e.blendFuncSeparate(e.ONE, e.ONE_MINUS_SRC_ALPHA, e.ONE, e.ONE_MINUS_SRC_ALPHA);
                                    break;
                                case i.EZo:
                                    e.blendFunc(e.ONE, e.ONE);
                                    break;
                                case i.Kwu:
                                    e.blendFuncSeparate(e.ZERO, e.ONE_MINUS_SRC_COLOR, e.ZERO, e.ONE);
                                    break;
                                case i.EdD:
                                    e.blendFuncSeparate(e.DST_COLOR, e.ONE_MINUS_SRC_ALPHA, e.ZERO, e.ONE);
                                    break;
                                default:
                                    (0, i.z3S)("WebGLState: Invalid blending: ", n)
                            } else switch (n) {
                                case i.NTi:
                                    e.blendFuncSeparate(e.SRC_ALPHA, e.ONE_MINUS_SRC_ALPHA, e.ONE, e.ONE_MINUS_SRC_ALPHA);
                                    break;
                                case i.EZo:
                                    e.blendFuncSeparate(e.SRC_ALPHA, e.ONE, e.ONE, e.ONE);
                                    break;
                                case i.Kwu:
                                    (0, i.z3S)("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");
                                    break;
                                case i.EdD:
                                    (0, i.z3S)("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");
                                    break;
                                default:
                                    (0, i.z3S)("WebGLState: Invalid blending: ", n)
                            }
                            g = null, v = null, E = null, M = null, T.set(0, 0, 0), x = 0, h = n, R = u
                        }
                        return
                    }
                    o = o || t, l = l || r, s = s || a, (t !== _ || o !== S) && (e.blendEquationSeparate(z[t], z[o]), _ = t, S = o), (r !== g || a !== v || l !== E || s !== M) && (e.blendFuncSeparate(k[r], k[a], k[l], k[s]), g = r, v = a, E = l, M = s), (!1 === c.equals(T) || d !== x) && (e.blendColor(c.r, c.g, c.b, d), T.copy(c), x = d), h = n, R = !1
                }

                function K(n) {
                    A !== n && (n ? e.frontFace(e.CW) : e.frontFace(e.CCW), A = n)
                }

                function q(n) {
                    n !== i.WNZ ? (V(e.CULL_FACE), n !== b && (n === i.Vb5 ? e.cullFace(e.BACK) : n === i.Jnc ? e.cullFace(e.FRONT) : e.cullFace(e.FRONT_AND_BACK))) : W(e.CULL_FACE), b = n
                }

                function Y(n, t, i) {
                    n ? (V(e.POLYGON_OFFSET_FILL), (P !== t || L !== i) && (P = t, L = i, r.getReversed() && (t = -t), e.polygonOffset(t, i))) : W(e.POLYGON_OFFSET_FILL)
                }
                return {
                    buffers: {
                        color: t,
                        depth: r,
                        stencil: a
                    },
                    enable: V,
                    disable: W,
                    bindFramebuffer: function(n, t) {
                        return d[n] !== t && (e.bindFramebuffer(n, t), d[n] = t, n === e.DRAW_FRAMEBUFFER && (d[e.FRAMEBUFFER] = t), n === e.FRAMEBUFFER && (d[e.DRAW_FRAMEBUFFER] = t), !0)
                    },
                    drawBuffers: function(n, t) {
                        let i = f,
                            r = !1;
                        if (n) {
                            void 0 === (i = u.get(t)) && (i = [], u.set(t, i));
                            let a = n.textures;
                            if (i.length !== a.length || i[0] !== e.COLOR_ATTACHMENT0) {
                                for (let n = 0, t = a.length; n < t; n++) i[n] = e.COLOR_ATTACHMENT0 + n;
                                i.length = a.length, r = !0
                            }
                        } else i[0] !== e.BACK && (i[0] = e.BACK, r = !0);
                        r && e.drawBuffers(i)
                    },
                    useProgram: function(n) {
                        return p !== n && (e.useProgram(n), p = n, !0)
                    },
                    setBlending: X,
                    setMaterial: function(n, o) {
                        n.side === i.$EB ? W(e.CULL_FACE) : V(e.CULL_FACE);
                        let l = n.side === i.hsX;
                        o && (l = !l), K(l), n.blending === i.NTi && !1 === n.transparent ? X(i.XIg) : X(n.blending, n.blendEquation, n.blendSrc, n.blendDst, n.blendEquationAlpha, n.blendSrcAlpha, n.blendDstAlpha, n.blendColor, n.blendAlpha, n.premultipliedAlpha), r.setFunc(n.depthFunc), r.setTest(n.depthTest), r.setMask(n.depthWrite), t.setMask(n.colorWrite);
                        let s = n.stencilWrite;
                        a.setTest(s), s && (a.setMask(n.stencilWriteMask), a.setFunc(n.stencilFunc, n.stencilRef, n.stencilFuncMask), a.setOp(n.stencilFail, n.stencilZFail, n.stencilZPass)), Y(n.polygonOffset, n.polygonOffsetFactor, n.polygonOffsetUnits), !0 === n.alphaToCoverage ? V(e.SAMPLE_ALPHA_TO_COVERAGE) : W(e.SAMPLE_ALPHA_TO_COVERAGE)
                    },
                    setFlipSided: K,
                    setCullFace: q,
                    setLineWidth: function(n) {
                        n !== C && (U && e.lineWidth(n), C = n)
                    },
                    setPolygonOffset: Y,
                    setScissorTest: function(n) {
                        n ? V(e.SCISSOR_TEST) : W(e.SCISSOR_TEST)
                    },
                    activeTexture: function(n) {
                        void 0 === n && (n = e.TEXTURE0 + w - 1), D !== n && (e.activeTexture(n), D = n)
                    },
                    bindTexture: function(n, t, i) {
                        void 0 === i && (i = null === D ? e.TEXTURE0 + w - 1 : D);
                        let r = N[i];
                        void 0 === r && (r = {
                            type: void 0,
                            texture: void 0
                        }, N[i] = r), (r.type !== n || r.texture !== t) && (D !== i && (e.activeTexture(i), D = i), e.bindTexture(n, t || H[n]), r.type = n, r.texture = t)
                    },
                    unbindTexture: function() {
                        let n = N[D];
                        void 0 !== n && void 0 !== n.type && (e.bindTexture(n.type, null), n.type = void 0, n.texture = void 0)
                    },
                    compressedTexImage2D: function() {
                        try {
                            e.compressedTexImage2D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    compressedTexImage3D: function() {
                        try {
                            e.compressedTexImage3D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    texImage2D: function() {
                        try {
                            e.texImage2D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    texImage3D: function() {
                        try {
                            e.texImage3D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    pixelStorei: function(n, t) {
                        c[n] !== t && (e.pixelStorei(n, t), c[n] = t)
                    },
                    getParameter: function(n) {
                        return void 0 !== c[n] ? c[n] : e.getParameter(n)
                    },
                    updateUBOMapping: function(n, t) {
                        let i = l.get(t);
                        void 0 === i && (i = new WeakMap, l.set(t, i));
                        let r = i.get(n);
                        void 0 === r && (r = e.getUniformBlockIndex(t, n.name), i.set(n, r))
                    },
                    uniformBlockBinding: function(n, t) {
                        let i = l.get(t).get(n);
                        o.get(t) !== i && (e.uniformBlockBinding(t, i, n.__bindingPointIndex), o.set(t, i))
                    },
                    texStorage2D: function() {
                        try {
                            e.texStorage2D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    texStorage3D: function() {
                        try {
                            e.texStorage3D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    texSubImage2D: function() {
                        try {
                            e.texSubImage2D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    texSubImage3D: function() {
                        try {
                            e.texSubImage3D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    compressedTexSubImage2D: function() {
                        try {
                            e.compressedTexSubImage2D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    compressedTexSubImage3D: function() {
                        try {
                            e.compressedTexSubImage3D(...arguments)
                        } catch (e) {
                            (0, i.z3S)("WebGLState:", e)
                        }
                    },
                    scissor: function(n) {
                        !1 === F.equals(n) && (e.scissor(n.x, n.y, n.z, n.w), F.copy(n))
                    },
                    viewport: function(n) {
                        !1 === B.equals(n) && (e.viewport(n.x, n.y, n.z, n.w), B.copy(n))
                    },
                    reset: function() {
                        e.disable(e.BLEND), e.disable(e.CULL_FACE), e.disable(e.DEPTH_TEST), e.disable(e.POLYGON_OFFSET_FILL), e.disable(e.SCISSOR_TEST), e.disable(e.STENCIL_TEST), e.disable(e.SAMPLE_ALPHA_TO_COVERAGE), e.blendEquation(e.FUNC_ADD), e.blendFunc(e.ONE, e.ZERO), e.blendFuncSeparate(e.ONE, e.ZERO, e.ONE, e.ZERO), e.blendColor(0, 0, 0, 0), e.colorMask(!0, !0, !0, !0), e.clearColor(0, 0, 0, 0), e.depthMask(!0), e.depthFunc(e.LESS), r.setReversed(!1), e.clearDepth(1), e.stencilMask(0xffffffff), e.stencilFunc(e.ALWAYS, 0, 0xffffffff), e.stencilOp(e.KEEP, e.KEEP, e.KEEP), e.clearStencil(0), e.cullFace(e.BACK), e.frontFace(e.CCW), e.polygonOffset(0, 0), e.activeTexture(e.TEXTURE0), e.bindFramebuffer(e.FRAMEBUFFER, null), e.bindFramebuffer(e.DRAW_FRAMEBUFFER, null), e.bindFramebuffer(e.READ_FRAMEBUFFER, null), e.useProgram(null), e.lineWidth(1), e.scissor(0, 0, e.canvas.width, e.canvas.height), e.viewport(0, 0, e.canvas.width, e.canvas.height), e.pixelStorei(e.PACK_ALIGNMENT, 4), e.pixelStorei(e.UNPACK_ALIGNMENT, 4), e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, !1), e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL, e.BROWSER_DEFAULT_WEBGL), e.pixelStorei(e.PACK_ROW_LENGTH, 0), e.pixelStorei(e.PACK_SKIP_PIXELS, 0), e.pixelStorei(e.PACK_SKIP_ROWS, 0), e.pixelStorei(e.UNPACK_ROW_LENGTH, 0), e.pixelStorei(e.UNPACK_IMAGE_HEIGHT, 0), e.pixelStorei(e.UNPACK_SKIP_PIXELS, 0), e.pixelStorei(e.UNPACK_SKIP_ROWS, 0), e.pixelStorei(e.UNPACK_SKIP_IMAGES, 0), s = {}, c = {}, D = null, N = {}, d = {}, u = new WeakMap, f = [], p = null, m = !1, h = null, _ = null, g = null, v = null, S = null, E = null, M = null, T = new i.Q1f(0, 0, 0), x = 0, R = !1, A = null, b = null, C = null, P = null, L = null, F.set(0, 0, e.canvas.width, e.canvas.height), B.set(0, 0, e.canvas.width, e.canvas.height), t.reset(), r.reset(), a.reset()
                    }
                }
            }

            function nA(e, n, t, r, a, o, l) {
                let s, c = n.has("WEBGL_multisampled_render_to_texture") ? n.get("WEBGL_multisampled_render_to_texture") : null,
                    d = "u" > typeof navigator && /OculusBrowser/g.test(navigator.userAgent),
                    u = new i.I9Y,
                    f = new WeakMap,
                    p = new Set,
                    m = new WeakMap,
                    h = !1;
                try {
                    h = "u" > typeof OffscreenCanvas && null !== new OffscreenCanvas(1, 1).getContext("2d")
                } catch (e) {}

                function _(e, n) {
                    return h ? new OffscreenCanvas(e, n) : (0, i.qq$)("canvas")
                }

                function g(e, n, t) {
                    let r = 1,
                        a = k(e);
                    if ((a.width > t || a.height > t) && (r = t / Math.max(a.width, a.height)), r < 1)
                        if ("u" > typeof HTMLImageElement && e instanceof HTMLImageElement || "u" > typeof HTMLCanvasElement && e instanceof HTMLCanvasElement || "u" > typeof ImageBitmap && e instanceof ImageBitmap || "u" > typeof VideoFrame && e instanceof VideoFrame) {
                            let t = Math.floor(r * a.width),
                                o = Math.floor(r * a.height);
                            void 0 === s && (s = _(t, o));
                            let l = n ? _(t, o) : s;
                            return l.width = t, l.height = o, l.getContext("2d").drawImage(e, 0, 0, t, o), (0, i.R8M)("WebGLRenderer: Texture has been resized from (" + a.width + "x" + a.height + ") to (" + t + "x" + o + ")."), l
                        } else "data" in e && (0, i.R8M)("WebGLRenderer: Image in DataTexture is too big (" + a.width + "x" + a.height + ").");
                    return e
                }

                function v(e) {
                    return e.generateMipmaps
                }

                function S(n) {
                    e.generateMipmap(n)
                }

                function E(t, r, a, o, l, s = !1) {
                    let c;
                    if (null !== t) {
                        if (void 0 !== e[t]) return e[t];
                        (0, i.R8M)("WebGLRenderer: Attempt to use non-existing WebGL internal format '" + t + "'")
                    }
                    o && ((c = n.get("EXT_texture_norm16")) || (0, i.R8M)("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));
                    let d = r;
                    if (r === e.RED && (a === e.FLOAT && (d = e.R32F), a === e.HALF_FLOAT && (d = e.R16F), a === e.UNSIGNED_BYTE && (d = e.R8), a === e.UNSIGNED_SHORT && c && (d = c.R16_EXT), a === e.SHORT && c && (d = c.R16_SNORM_EXT)), r === e.RED_INTEGER && (a === e.UNSIGNED_BYTE && (d = e.R8UI), a === e.UNSIGNED_SHORT && (d = e.R16UI), a === e.UNSIGNED_INT && (d = e.R32UI), a === e.BYTE && (d = e.R8I), a === e.SHORT && (d = e.R16I), a === e.INT && (d = e.R32I)), r === e.RG && (a === e.FLOAT && (d = e.RG32F), a === e.HALF_FLOAT && (d = e.RG16F), a === e.UNSIGNED_BYTE && (d = e.RG8), a === e.UNSIGNED_SHORT && c && (d = c.RG16_EXT), a === e.SHORT && c && (d = c.RG16_SNORM_EXT)), r === e.RG_INTEGER && (a === e.UNSIGNED_BYTE && (d = e.RG8UI), a === e.UNSIGNED_SHORT && (d = e.RG16UI), a === e.UNSIGNED_INT && (d = e.RG32UI), a === e.BYTE && (d = e.RG8I), a === e.SHORT && (d = e.RG16I), a === e.INT && (d = e.RG32I)), r === e.RGB_INTEGER && (a === e.UNSIGNED_BYTE && (d = e.RGB8UI), a === e.UNSIGNED_SHORT && (d = e.RGB16UI), a === e.UNSIGNED_INT && (d = e.RGB32UI), a === e.BYTE && (d = e.RGB8I), a === e.SHORT && (d = e.RGB16I), a === e.INT && (d = e.RGB32I)), r === e.RGBA_INTEGER && (a === e.UNSIGNED_BYTE && (d = e.RGBA8UI), a === e.UNSIGNED_SHORT && (d = e.RGBA16UI), a === e.UNSIGNED_INT && (d = e.RGBA32UI), a === e.BYTE && (d = e.RGBA8I), a === e.SHORT && (d = e.RGBA16I), a === e.INT && (d = e.RGBA32I)), r === e.RGB && (a === e.UNSIGNED_SHORT && c && (d = c.RGB16_EXT), a === e.SHORT && c && (d = c.RGB16_SNORM_EXT), a === e.UNSIGNED_INT_5_9_9_9_REV && (d = e.RGB9_E5), a === e.UNSIGNED_INT_10F_11F_11F_REV && (d = e.R11F_G11F_B10F)), r === e.RGBA) {
                        let n = s ? i.VxR : i.ppV.getTransfer(l);
                        a === e.FLOAT && (d = e.RGBA32F), a === e.HALF_FLOAT && (d = e.RGBA16F), a === e.UNSIGNED_BYTE && (d = n === i.KLL ? e.SRGB8_ALPHA8 : e.RGBA8), a === e.UNSIGNED_SHORT && c && (d = c.RGBA16_EXT), a === e.SHORT && c && (d = c.RGBA16_SNORM_EXT), a === e.UNSIGNED_SHORT_4_4_4_4 && (d = e.RGBA4), a === e.UNSIGNED_SHORT_5_5_5_1 && (d = e.RGB5_A1)
                    }
                    return (d === e.R16F || d === e.R32F || d === e.RG16F || d === e.RG32F || d === e.RGBA16F || d === e.RGBA32F) && n.get("EXT_color_buffer_float"), d
                }

                function M(n, t) {
                    let r;
                    return n ? null === t || t === i.bkx || t === i.V3x ? r = e.DEPTH24_STENCIL8 : t === i.RQf ? r = e.DEPTH32F_STENCIL8 : t === i.cHt && (r = e.DEPTH24_STENCIL8, (0, i.R8M)("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")) : null === t || t === i.bkx || t === i.V3x ? r = e.DEPTH_COMPONENT24 : t === i.RQf ? r = e.DEPTH_COMPONENT32F : t === i.cHt && (r = e.DEPTH_COMPONENT16), r
                }

                function T(e, n) {
                    return !0 === v(e) || e.isFramebufferTexture && e.minFilter !== i.hxR && e.minFilter !== i.k6q ? Math.log2(Math.max(n.width, n.height)) + 1 : void 0 !== e.mipmaps && e.mipmaps.length > 0 ? e.mipmaps.length : e.isCompressedTexture && Array.isArray(e.image) ? n.mipmaps.length : 1
                }

                function x(e) {
                    let n = e.target;
                    n.removeEventListener("dispose", x),
                        function(e) {
                            let n = r.get(e);
                            if (void 0 === n.__webglInit) return;
                            let t = e.source,
                                i = m.get(t);
                            if (i) {
                                let r = i[n.__cacheKey];
                                r.usedTimes--, 0 === r.usedTimes && A(e), 0 === Object.keys(i).length && m.delete(t)
                            }
                            r.remove(e)
                        }(n), n.isVideoTexture && f.delete(n), n.isHTMLTexture && p.delete(n)
                }

                function R(n) {
                    let t = n.target;
                    t.removeEventListener("dispose", R),
                        function(n) {
                            let t = r.get(n);
                            if (n.depthTexture && (n.depthTexture.dispose(), r.remove(n.depthTexture)), n.isWebGLCubeRenderTarget)
                                for (let n = 0; n < 6; n++) {
                                    if (Array.isArray(t.__webglFramebuffer[n]))
                                        for (let i = 0; i < t.__webglFramebuffer[n].length; i++) e.deleteFramebuffer(t.__webglFramebuffer[n][i]);
                                    else e.deleteFramebuffer(t.__webglFramebuffer[n]);
                                    t.__webglDepthbuffer && e.deleteRenderbuffer(t.__webglDepthbuffer[n])
                                } else {
                                    if (Array.isArray(t.__webglFramebuffer))
                                        for (let n = 0; n < t.__webglFramebuffer.length; n++) e.deleteFramebuffer(t.__webglFramebuffer[n]);
                                    else e.deleteFramebuffer(t.__webglFramebuffer);
                                    if (t.__webglDepthbuffer && e.deleteRenderbuffer(t.__webglDepthbuffer), t.__webglMultisampledFramebuffer && e.deleteFramebuffer(t.__webglMultisampledFramebuffer), t.__webglColorRenderbuffer)
                                        for (let n = 0; n < t.__webglColorRenderbuffer.length; n++) t.__webglColorRenderbuffer[n] && e.deleteRenderbuffer(t.__webglColorRenderbuffer[n]);
                                    t.__webglDepthRenderbuffer && e.deleteRenderbuffer(t.__webglDepthRenderbuffer)
                                }
                            let i = n.textures;
                            for (let n = 0, t = i.length; n < t; n++) {
                                let t = r.get(i[n]);
                                t.__webglTexture && (e.deleteTexture(t.__webglTexture), l.memory.textures--), r.remove(i[n])
                            }
                            r.remove(n)
                        }(t)
                }

                function A(n) {
                    let t = r.get(n);
                    e.deleteTexture(t.__webglTexture);
                    let i = n.source,
                        a = m.get(i);
                    delete a[t.__cacheKey], l.memory.textures--
                }
                let b = 0;

                function C(n, a) {
                    var o;
                    let s, c = r.get(n);
                    if (n.isVideoTexture && (o = n, s = l.render.frame, f.get(o) !== s && (f.set(o, s), o.update())), !1 === n.isRenderTargetTexture && !0 !== n.isExternalTexture && n.version > 0 && c.__version !== n.version) {
                        let e = n.image;
                        if (null === e)(0, i.R8M)("WebGLRenderer: Texture marked for update but no image data found.");
                        else {
                            if (!1 !== e.complete) return void N(c, n, a);
                            (0, i.R8M)("WebGLRenderer: Texture marked for update but image is incomplete")
                        }
                    } else n.isExternalTexture && (c.__webglTexture = n.sourceTexture ? n.sourceTexture : null);
                    t.bindTexture(e.TEXTURE_2D, c.__webglTexture, e.TEXTURE0 + a)
                }
                let P = {
                        [i.GJx]: e.REPEAT,
                        [i.ghU]: e.CLAMP_TO_EDGE,
                        [i.kTW]: e.MIRRORED_REPEAT
                    },
                    L = {
                        [i.hxR]: e.NEAREST,
                        [i.pHI]: e.NEAREST_MIPMAP_NEAREST,
                        [i.Cfg]: e.NEAREST_MIPMAP_LINEAR,
                        [i.k6q]: e.LINEAR,
                        [i.kRr]: e.LINEAR_MIPMAP_NEAREST,
                        [i.$_I]: e.LINEAR_MIPMAP_LINEAR
                    },
                    w = {
                        [i.amv]: e.NEVER,
                        [i.FFZ]: e.ALWAYS,
                        [i.vim]: e.LESS,
                        [i.TiK]: e.LEQUAL,
                        [i.kO0]: e.EQUAL,
                        [i.gWB]: e.GEQUAL,
                        [i.eoi]: e.GREATER,
                        [i.jzd]: e.NOTEQUAL
                    };

                function U(t, o) {
                    if ((o.type === i.RQf && !1 === n.has("OES_texture_float_linear") && (o.magFilter === i.k6q || o.magFilter === i.kRr || o.magFilter === i.Cfg || o.magFilter === i.$_I || o.minFilter === i.k6q || o.minFilter === i.kRr || o.minFilter === i.Cfg || o.minFilter === i.$_I) && (0, i.R8M)("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."), e.texParameteri(t, e.TEXTURE_WRAP_S, P[o.wrapS]), e.texParameteri(t, e.TEXTURE_WRAP_T, P[o.wrapT]), (t === e.TEXTURE_3D || t === e.TEXTURE_2D_ARRAY) && e.texParameteri(t, e.TEXTURE_WRAP_R, P[o.wrapR]), e.texParameteri(t, e.TEXTURE_MAG_FILTER, L[o.magFilter]), e.texParameteri(t, e.TEXTURE_MIN_FILTER, L[o.minFilter]), o.compareFunction && (e.texParameteri(t, e.TEXTURE_COMPARE_MODE, e.COMPARE_REF_TO_TEXTURE), e.texParameteri(t, e.TEXTURE_COMPARE_FUNC, w[o.compareFunction])), !0 === n.has("EXT_texture_filter_anisotropic")) && o.magFilter !== i.hxR && (o.minFilter === i.Cfg || o.minFilter === i.$_I) && (o.type !== i.RQf || !1 !== n.has("OES_texture_float_linear")) && (o.anisotropy > 1 || r.get(o).__currentAnisotropy)) {
                        let i = n.get("EXT_texture_filter_anisotropic");
                        e.texParameterf(t, i.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(o.anisotropy, a.getMaxAnisotropy())), r.get(o).__currentAnisotropy = o.anisotropy
                    }
                }

                function I(n, t) {
                    let i, r = !1;
                    void 0 === n.__webglInit && (n.__webglInit = !0, t.addEventListener("dispose", x));
                    let a = t.source,
                        o = m.get(a);
                    void 0 === o && (o = {}, m.set(a, o));
                    let s = ((i = []).push(t.wrapS), i.push(t.wrapT), i.push(t.wrapR || 0), i.push(t.magFilter), i.push(t.minFilter), i.push(t.anisotropy), i.push(t.internalFormat), i.push(t.format), i.push(t.type), i.push(t.generateMipmaps), i.push(t.premultiplyAlpha), i.push(t.flipY), i.push(t.unpackAlignment), i.push(t.colorSpace), i.join());
                    if (s !== n.__cacheKey) {
                        void 0 === o[s] && (o[s] = {
                            texture: e.createTexture(),
                            usedTimes: 0
                        }, l.memory.textures++, r = !0), o[s].usedTimes++;
                        let i = o[n.__cacheKey];
                        void 0 !== i && (o[n.__cacheKey].usedTimes--, 0 === i.usedTimes && A(t)), n.__cacheKey = s, n.__webglTexture = o[s].texture
                    }
                    return r
                }

                function D(e, n, t) {
                    return Math.floor(Math.floor(e / t) / n)
                }

                function N(n, l, s) {
                    let c = e.TEXTURE_2D;
                    (l.isDataArrayTexture || l.isCompressedArrayTexture) && (c = e.TEXTURE_2D_ARRAY), l.isData3DTexture && (c = e.TEXTURE_3D);
                    let d = I(n, l),
                        u = l.source;
                    t.bindTexture(c, n.__webglTexture, e.TEXTURE0 + s);
                    let f = r.get(u);
                    if (u.version !== f.__version || !0 === d) {
                        let n;
                        if (t.activeTexture(e.TEXTURE0 + s), !1 == ("u" > typeof ImageBitmap && l.image instanceof ImageBitmap)) {
                            let n = i.ppV.getPrimaries(i.ppV.workingColorSpace),
                                r = l.colorSpace === i.jf0 ? null : i.ppV.getPrimaries(l.colorSpace),
                                a = l.colorSpace === i.jf0 || n === r ? e.NONE : e.BROWSER_DEFAULT_WEBGL;
                            t.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, l.flipY), t.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, l.premultiplyAlpha), t.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL, a)
                        }
                        t.pixelStorei(e.UNPACK_ALIGNMENT, l.unpackAlignment);
                        let r = g(l.image, !1, a.maxTextureSize);
                        r = z(l, r);
                        let m = o.convert(l.format, l.colorSpace),
                            h = o.convert(l.type),
                            _ = E(l.internalFormat, m, h, l.normalized, l.colorSpace, l.isVideoTexture);
                        U(c, l);
                        let x = l.mipmaps,
                            R = !0 !== l.isVideoTexture,
                            A = void 0 === f.__version || !0 === d,
                            b = u.dataReady,
                            C = T(l, r);
                        if (l.isDepthTexture) _ = M(l.format === i.dcC, l.type), A && (R ? t.texStorage2D(e.TEXTURE_2D, 1, _, r.width, r.height) : t.texImage2D(e.TEXTURE_2D, 0, _, r.width, r.height, 0, m, h, null));
                        else if (l.isDataTexture)
                            if (x.length > 0) {
                                R && A && t.texStorage2D(e.TEXTURE_2D, C, _, x[0].width, x[0].height);
                                for (let i = 0, r = x.length; i < r; i++) n = x[i], R ? b && t.texSubImage2D(e.TEXTURE_2D, i, 0, 0, n.width, n.height, m, h, n.data) : t.texImage2D(e.TEXTURE_2D, i, _, n.width, n.height, 0, m, h, n.data);
                                l.generateMipmaps = !1
                            } else R ? (A && t.texStorage2D(e.TEXTURE_2D, C, _, r.width, r.height), b && function(n, i, r, a) {
                                let o = n.updateRanges;
                                if (0 === o.length) t.texSubImage2D(e.TEXTURE_2D, 0, 0, 0, i.width, i.height, r, a, i.data);
                                else {
                                    o.sort((e, n) => e.start - n.start);
                                    let l = 0;
                                    for (let e = 1; e < o.length; e++) {
                                        let n = o[l],
                                            t = o[e],
                                            r = n.start + n.count,
                                            a = D(t.start, i.width, 4),
                                            s = D(n.start, i.width, 4);
                                        t.start <= r + 1 && a === s && D(t.start + t.count - 1, i.width, 4) === a ? n.count = Math.max(n.count, t.start + t.count - n.start) : o[++l] = t
                                    }
                                    o.length = l + 1;
                                    let s = t.getParameter(e.UNPACK_ROW_LENGTH),
                                        c = t.getParameter(e.UNPACK_SKIP_PIXELS),
                                        d = t.getParameter(e.UNPACK_SKIP_ROWS);
                                    t.pixelStorei(e.UNPACK_ROW_LENGTH, i.width);
                                    for (let n = 0, l = o.length; n < l; n++) {
                                        let l = o[n],
                                            s = Math.floor(l.start / 4),
                                            c = Math.ceil(l.count / 4),
                                            d = s % i.width,
                                            u = Math.floor(s / i.width);
                                        t.pixelStorei(e.UNPACK_SKIP_PIXELS, d), t.pixelStorei(e.UNPACK_SKIP_ROWS, u), t.texSubImage2D(e.TEXTURE_2D, 0, d, u, c, 1, r, a, i.data)
                                    }
                                    n.clearUpdateRanges(), t.pixelStorei(e.UNPACK_ROW_LENGTH, s), t.pixelStorei(e.UNPACK_SKIP_PIXELS, c), t.pixelStorei(e.UNPACK_SKIP_ROWS, d)
                                }
                            }(l, r, m, h)) : t.texImage2D(e.TEXTURE_2D, 0, _, r.width, r.height, 0, m, h, r.data);
                        else if (l.isCompressedTexture)
                            if (l.isCompressedArrayTexture) {
                                R && A && t.texStorage3D(e.TEXTURE_2D_ARRAY, C, _, x[0].width, x[0].height, r.depth);
                                for (let a = 0, o = x.length; a < o; a++)
                                    if (n = x[a], l.format !== i.GWd)
                                        if (null !== m)
                                            if (R) {
                                                if (b)
                                                    if (l.layerUpdates.size > 0) {
                                                        let r = (0, i.Nex)(n.width, n.height, l.format, l.type);
                                                        for (let i of l.layerUpdates) {
                                                            let o = n.data.subarray(i * r / n.data.BYTES_PER_ELEMENT, (i + 1) * r / n.data.BYTES_PER_ELEMENT);
                                                            t.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY, a, 0, 0, i, n.width, n.height, 1, m, o)
                                                        }
                                                    } else t.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY, a, 0, 0, 0, n.width, n.height, r.depth, m, n.data)
                                            } else t.compressedTexImage3D(e.TEXTURE_2D_ARRAY, a, _, n.width, n.height, r.depth, 0, n.data, 0, 0);
                                else(0, i.R8M)("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");
                                else R ? b && t.texSubImage3D(e.TEXTURE_2D_ARRAY, a, 0, 0, 0, n.width, n.height, r.depth, m, h, n.data) : t.texImage3D(e.TEXTURE_2D_ARRAY, a, _, n.width, n.height, r.depth, 0, m, h, n.data);
                                l.layerUpdates.size > 0 && l.clearLayerUpdates()
                            } else {
                                R && A && t.texStorage2D(e.TEXTURE_2D, C, _, x[0].width, x[0].height);
                                for (let r = 0, a = x.length; r < a; r++) n = x[r], l.format !== i.GWd ? null !== m ? R ? b && t.compressedTexSubImage2D(e.TEXTURE_2D, r, 0, 0, n.width, n.height, m, n.data) : t.compressedTexImage2D(e.TEXTURE_2D, r, _, n.width, n.height, 0, n.data) : (0, i.R8M)("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()") : R ? b && t.texSubImage2D(e.TEXTURE_2D, r, 0, 0, n.width, n.height, m, h, n.data) : t.texImage2D(e.TEXTURE_2D, r, _, n.width, n.height, 0, m, h, n.data)
                            }
                        else if (l.isDataArrayTexture)
                            if (R) {
                                if (A && t.texStorage3D(e.TEXTURE_2D_ARRAY, C, _, r.width, r.height, r.depth), b)
                                    if (l.layerUpdates.size > 0) {
                                        let n = (0, i.Nex)(r.width, r.height, l.format, l.type);
                                        for (let i of l.layerUpdates) {
                                            let a = r.data.subarray(i * n / r.data.BYTES_PER_ELEMENT, (i + 1) * n / r.data.BYTES_PER_ELEMENT);
                                            t.texSubImage3D(e.TEXTURE_2D_ARRAY, 0, 0, 0, i, r.width, r.height, 1, m, h, a)
                                        }
                                        l.clearLayerUpdates()
                                    } else t.texSubImage3D(e.TEXTURE_2D_ARRAY, 0, 0, 0, 0, r.width, r.height, r.depth, m, h, r.data)
                            } else t.texImage3D(e.TEXTURE_2D_ARRAY, 0, _, r.width, r.height, r.depth, 0, m, h, r.data);
                        else if (l.isData3DTexture) R ? (A && t.texStorage3D(e.TEXTURE_3D, C, _, r.width, r.height, r.depth), b && t.texSubImage3D(e.TEXTURE_3D, 0, 0, 0, 0, r.width, r.height, r.depth, m, h, r.data)) : t.texImage3D(e.TEXTURE_3D, 0, _, r.width, r.height, r.depth, 0, m, h, r.data);
                        else if (l.isFramebufferTexture) {
                            if (A)
                                if (R) t.texStorage2D(e.TEXTURE_2D, C, _, r.width, r.height);
                                else {
                                    let n = r.width,
                                        i = r.height;
                                    for (let r = 0; r < C; r++) t.texImage2D(e.TEXTURE_2D, r, _, n, i, 0, m, h, null), n >>= 1, i >>= 1
                                }
                        } else if (l.isHTMLTexture) {
                            if ("texElementImage2D" in e) {
                                let n = e.canvas;
                                if (n.hasAttribute("layoutsubtree") || n.setAttribute("layoutsubtree", "true"), r.parentNode !== n) {
                                    n.appendChild(r), p.add(l), n.onpaint = e => {
                                        let n = e.changedElements;
                                        for (let e of p) n.includes(e.image) && (e.needsUpdate = !0)
                                    }, n.requestPaint();
                                    return
                                }
                                if (3 === e.texElementImage2D.length) e.texElementImage2D(e.TEXTURE_2D, e.RGBA8, r);
                                else {
                                    let n = e.RGBA,
                                        t = e.RGBA,
                                        i = e.UNSIGNED_BYTE;
                                    e.texElementImage2D(e.TEXTURE_2D, 0, n, t, i, r)
                                }
                                e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, e.LINEAR), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, e.CLAMP_TO_EDGE), e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, e.CLAMP_TO_EDGE)
                            }
                        } else if (x.length > 0) {
                            if (R && A) {
                                let n = k(x[0]);
                                t.texStorage2D(e.TEXTURE_2D, C, _, n.width, n.height)
                            }
                            for (let i = 0, r = x.length; i < r; i++) n = x[i], R ? b && t.texSubImage2D(e.TEXTURE_2D, i, 0, 0, m, h, n) : t.texImage2D(e.TEXTURE_2D, i, _, m, h, n);
                            l.generateMipmaps = !1
                        } else if (R) {
                            if (A) {
                                let n = k(r);
                                t.texStorage2D(e.TEXTURE_2D, C, _, n.width, n.height)
                            }
                            b && t.texSubImage2D(e.TEXTURE_2D, 0, 0, 0, m, h, r)
                        } else t.texImage2D(e.TEXTURE_2D, 0, _, m, h, r);
                        v(l) && S(c), f.__version = u.version, l.onUpdate && l.onUpdate(l)
                    }
                    n.__version = l.version
                }

                function y(n, i, a, l, s, d) {
                    let u = o.convert(a.format, a.colorSpace),
                        f = o.convert(a.type),
                        p = E(a.internalFormat, u, f, a.normalized, a.colorSpace),
                        m = r.get(i),
                        h = r.get(a);
                    if (h.__renderTarget = i, !m.__hasExternalTextures) {
                        let n = Math.max(1, i.width >> d),
                            r = Math.max(1, i.height >> d);
                        s === e.TEXTURE_3D || s === e.TEXTURE_2D_ARRAY ? t.texImage3D(s, d, p, n, r, i.depth, 0, u, f, null) : t.texImage2D(s, d, p, n, r, 0, u, f, null)
                    }
                    t.bindFramebuffer(e.FRAMEBUFFER, n), W(i) ? c.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER, l, s, h.__webglTexture, 0, V(i)) : (s === e.TEXTURE_2D || s >= e.TEXTURE_CUBE_MAP_POSITIVE_X && s <= e.TEXTURE_CUBE_MAP_NEGATIVE_Z) && e.framebufferTexture2D(e.FRAMEBUFFER, l, s, h.__webglTexture, d), t.bindFramebuffer(e.FRAMEBUFFER, null)
                }

                function O(n, t, i) {
                    if (e.bindRenderbuffer(e.RENDERBUFFER, n), t.depthBuffer) {
                        let r = t.depthTexture,
                            a = r && r.isDepthTexture ? r.type : null,
                            o = M(t.stencilBuffer, a),
                            l = t.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT;
                        W(t) ? c.renderbufferStorageMultisampleEXT(e.RENDERBUFFER, V(t), o, t.width, t.height) : i ? e.renderbufferStorageMultisample(e.RENDERBUFFER, V(t), o, t.width, t.height) : e.renderbufferStorage(e.RENDERBUFFER, o, t.width, t.height), e.framebufferRenderbuffer(e.FRAMEBUFFER, l, e.RENDERBUFFER, n)
                    } else {
                        let n = t.textures;
                        for (let r = 0; r < n.length; r++) {
                            let a = n[r],
                                l = o.convert(a.format, a.colorSpace),
                                s = o.convert(a.type),
                                d = E(a.internalFormat, l, s, a.normalized, a.colorSpace);
                            W(t) ? c.renderbufferStorageMultisampleEXT(e.RENDERBUFFER, V(t), d, t.width, t.height) : i ? e.renderbufferStorageMultisample(e.RENDERBUFFER, V(t), d, t.width, t.height) : e.renderbufferStorage(e.RENDERBUFFER, d, t.width, t.height)
                        }
                    }
                    e.bindRenderbuffer(e.RENDERBUFFER, null)
                }

                function F(n, a, l) {
                    let s = !0 === a.isWebGLCubeRenderTarget;
                    if (t.bindFramebuffer(e.FRAMEBUFFER, n), !(a.depthTexture && a.depthTexture.isDepthTexture)) throw Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");
                    let d = r.get(a.depthTexture);
                    if (d.__renderTarget = a, d.__webglTexture && a.depthTexture.image.width === a.width && a.depthTexture.image.height === a.height || (a.depthTexture.image.width = a.width, a.depthTexture.image.height = a.height, a.depthTexture.needsUpdate = !0), s) {
                        if (void 0 === d.__webglInit && (d.__webglInit = !0, a.depthTexture.addEventListener("dispose", x)), void 0 === d.__webglTexture) {
                            let n;
                            d.__webglTexture = e.createTexture(), t.bindTexture(e.TEXTURE_CUBE_MAP, d.__webglTexture), U(e.TEXTURE_CUBE_MAP, a.depthTexture);
                            let r = o.convert(a.depthTexture.format),
                                l = o.convert(a.depthTexture.type);
                            a.depthTexture.format === i.zdS ? n = e.DEPTH_COMPONENT24 : a.depthTexture.format === i.dcC && (n = e.DEPTH24_STENCIL8);
                            for (let t = 0; t < 6; t++) e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + t, 0, n, a.width, a.height, 0, r, l, null)
                        }
                    } else C(a.depthTexture, 0);
                    let u = d.__webglTexture,
                        f = V(a),
                        p = s ? e.TEXTURE_CUBE_MAP_POSITIVE_X + l : e.TEXTURE_2D,
                        m = a.depthTexture.format === i.dcC ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT;
                    if (a.depthTexture.format === i.zdS) W(a) ? c.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER, m, p, u, 0, f) : e.framebufferTexture2D(e.FRAMEBUFFER, m, p, u, 0);
                    else if (a.depthTexture.format === i.dcC) W(a) ? c.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER, m, p, u, 0, f) : e.framebufferTexture2D(e.FRAMEBUFFER, m, p, u, 0);
                    else throw Error("THREE.WebGLTextures: Unknown depthTexture format.")
                }

                function B(n) {
                    let i = r.get(n),
                        a = !0 === n.isWebGLCubeRenderTarget;
                    if (i.__boundDepthTexture !== n.depthTexture) {
                        let e = n.depthTexture;
                        if (i.__depthDisposeCallback && i.__depthDisposeCallback(), e) {
                            let n = () => {
                                delete i.__boundDepthTexture, delete i.__depthDisposeCallback, e.removeEventListener("dispose", n)
                            };
                            e.addEventListener("dispose", n), i.__depthDisposeCallback = n
                        }
                        i.__boundDepthTexture = e
                    }
                    if (n.depthTexture && !i.__autoAllocateDepthBuffer)
                        if (a)
                            for (let e = 0; e < 6; e++) F(i.__webglFramebuffer[e], n, e);
                        else {
                            let e = n.texture.mipmaps;
                            e && e.length > 0 ? F(i.__webglFramebuffer[0], n, 0) : F(i.__webglFramebuffer, n, 0)
                        }
                    else if (a) {
                        i.__webglDepthbuffer = [];
                        for (let r = 0; r < 6; r++)
                            if (t.bindFramebuffer(e.FRAMEBUFFER, i.__webglFramebuffer[r]), void 0 === i.__webglDepthbuffer[r]) i.__webglDepthbuffer[r] = e.createRenderbuffer(), O(i.__webglDepthbuffer[r], n, !1);
                            else {
                                let t = n.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT,
                                    a = i.__webglDepthbuffer[r];
                                e.bindRenderbuffer(e.RENDERBUFFER, a), e.framebufferRenderbuffer(e.FRAMEBUFFER, t, e.RENDERBUFFER, a)
                            }
                    } else {
                        let r = n.texture.mipmaps;
                        if (r && r.length > 0 ? t.bindFramebuffer(e.FRAMEBUFFER, i.__webglFramebuffer[0]) : t.bindFramebuffer(e.FRAMEBUFFER, i.__webglFramebuffer), void 0 === i.__webglDepthbuffer) i.__webglDepthbuffer = e.createRenderbuffer(), O(i.__webglDepthbuffer, n, !1);
                        else {
                            let t = n.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT,
                                r = i.__webglDepthbuffer;
                            e.bindRenderbuffer(e.RENDERBUFFER, r), e.framebufferRenderbuffer(e.FRAMEBUFFER, t, e.RENDERBUFFER, r)
                        }
                    }
                    t.bindFramebuffer(e.FRAMEBUFFER, null)
                }
                let G = [],
                    H = [];

                function V(e) {
                    return Math.min(a.maxSamples, e.samples)
                }

                function W(e) {
                    let t = r.get(e);
                    return e.samples > 0 && !0 === n.has("WEBGL_multisampled_render_to_texture") && !1 !== t.__useRenderToTexture
                }

                function z(e, n) {
                    let t = e.colorSpace,
                        r = e.format,
                        a = e.type;
                    return !0 === e.isCompressedTexture || !0 === e.isVideoTexture || t !== i.Zr2 && t !== i.jf0 && (i.ppV.getTransfer(t) === i.KLL ? (r !== i.GWd || a !== i.OUM) && (0, i.R8M)("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.") : (0, i.z3S)("WebGLTextures: Unsupported texture color space:", t)), n
                }

                function k(e) {
                    return "u" > typeof HTMLImageElement && e instanceof HTMLImageElement ? (u.width = e.naturalWidth || e.width, u.height = e.naturalHeight || e.height) : "u" > typeof VideoFrame && e instanceof VideoFrame ? (u.width = e.displayWidth, u.height = e.displayHeight) : (u.width = e.width, u.height = e.height), u
                }
                this.allocateTextureUnit = function() {
                    let e = b;
                    return e >= a.maxTextures && (0, i.R8M)("WebGLTextures: Trying to use " + (e + 1) + " texture units while this GPU supports only " + a.maxTextures), b += 1, e
                }, this.resetTextureUnits = function() {
                    b = 0
                }, this.getTextureUnits = function() {
                    return b
                }, this.setTextureUnits = function(e) {
                    b = e
                }, this.setTexture2D = C, this.setTexture2DArray = function(n, i) {
                    let a = r.get(n);
                    !1 === n.isRenderTargetTexture && n.version > 0 && a.__version !== n.version ? N(a, n, i) : (n.isExternalTexture && (a.__webglTexture = n.sourceTexture ? n.sourceTexture : null), t.bindTexture(e.TEXTURE_2D_ARRAY, a.__webglTexture, e.TEXTURE0 + i))
                }, this.setTexture3D = function(n, i) {
                    let a = r.get(n);
                    !1 === n.isRenderTargetTexture && n.version > 0 && a.__version !== n.version ? N(a, n, i) : t.bindTexture(e.TEXTURE_3D, a.__webglTexture, e.TEXTURE0 + i)
                }, this.setTextureCube = function(n, l) {
                    let s = r.get(n);
                    !0 !== n.isCubeDepthTexture && n.version > 0 && s.__version !== n.version ? function(n, l, s) {
                        if (6 !== l.image.length) return;
                        let c = I(n, l),
                            d = l.source;
                        t.bindTexture(e.TEXTURE_CUBE_MAP, n.__webglTexture, e.TEXTURE0 + s);
                        let u = r.get(d);
                        if (d.version !== u.__version || !0 === c) {
                            let n;
                            t.activeTexture(e.TEXTURE0 + s);
                            let r = i.ppV.getPrimaries(i.ppV.workingColorSpace),
                                f = l.colorSpace === i.jf0 ? null : i.ppV.getPrimaries(l.colorSpace),
                                p = l.colorSpace === i.jf0 || r === f ? e.NONE : e.BROWSER_DEFAULT_WEBGL;
                            t.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, l.flipY), t.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, l.premultiplyAlpha), t.pixelStorei(e.UNPACK_ALIGNMENT, l.unpackAlignment), t.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL, p);
                            let m = l.isCompressedTexture || l.image[0].isCompressedTexture,
                                h = l.image[0] && l.image[0].isDataTexture,
                                _ = [];
                            for (let e = 0; e < 6; e++) m || h ? _[e] = h ? l.image[e].image : l.image[e] : _[e] = g(l.image[e], !0, a.maxCubemapSize), _[e] = z(l, _[e]);
                            let M = _[0],
                                x = o.convert(l.format, l.colorSpace),
                                R = o.convert(l.type),
                                A = E(l.internalFormat, x, R, l.normalized, l.colorSpace),
                                b = !0 !== l.isVideoTexture,
                                C = void 0 === u.__version || !0 === c,
                                P = d.dataReady,
                                L = T(l, M);
                            if (U(e.TEXTURE_CUBE_MAP, l), m) {
                                b && C && t.texStorage2D(e.TEXTURE_CUBE_MAP, L, A, M.width, M.height);
                                for (let r = 0; r < 6; r++) {
                                    n = _[r].mipmaps;
                                    for (let a = 0; a < n.length; a++) {
                                        let o = n[a];
                                        l.format !== i.GWd ? null !== x ? b ? P && t.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + r, a, 0, 0, o.width, o.height, x, o.data) : t.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + r, a, A, o.width, o.height, 0, o.data) : (0, i.R8M)("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()") : b ? P && t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + r, a, 0, 0, o.width, o.height, x, R, o.data) : t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + r, a, A, o.width, o.height, 0, x, R, o.data)
                                    }
                                }
                            } else {
                                if (n = l.mipmaps, b && C) {
                                    n.length > 0 && L++;
                                    let i = k(_[0]);
                                    t.texStorage2D(e.TEXTURE_CUBE_MAP, L, A, i.width, i.height)
                                }
                                for (let i = 0; i < 6; i++)
                                    if (h) {
                                        b ? P && t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, 0, 0, _[i].width, _[i].height, x, R, _[i].data) : t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, A, _[i].width, _[i].height, 0, x, R, _[i].data);
                                        for (let r = 0; r < n.length; r++) {
                                            let a = n[r].image[i].image;
                                            b ? P && t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + i, r + 1, 0, 0, a.width, a.height, x, R, a.data) : t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + i, r + 1, A, a.width, a.height, 0, x, R, a.data)
                                        }
                                    } else {
                                        b ? P && t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, 0, 0, x, R, _[i]) : t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, A, x, R, _[i]);
                                        for (let r = 0; r < n.length; r++) {
                                            let a = n[r];
                                            b ? P && t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + i, r + 1, 0, 0, x, R, a.image[i]) : t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X + i, r + 1, A, x, R, a.image[i])
                                        }
                                    }
                            }
                            v(l) && S(e.TEXTURE_CUBE_MAP), u.__version = d.version, l.onUpdate && l.onUpdate(l)
                        }
                        n.__version = l.version
                    }(s, n, l) : t.bindTexture(e.TEXTURE_CUBE_MAP, s.__webglTexture, e.TEXTURE0 + l)
                }, this.rebindTextures = function(n, t, i) {
                    let a = r.get(n);
                    void 0 !== t && y(a.__webglFramebuffer, n, n.texture, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, 0), void 0 !== i && B(n)
                }, this.setupRenderTarget = function(n) {
                    let i = n.texture,
                        a = r.get(n),
                        s = r.get(i);
                    n.addEventListener("dispose", R);
                    let c = n.textures,
                        d = !0 === n.isWebGLCubeRenderTarget,
                        u = c.length > 1;
                    if (!u && (void 0 === s.__webglTexture && (s.__webglTexture = e.createTexture()), s.__version = i.version, l.memory.textures++), d) {
                        a.__webglFramebuffer = [];
                        for (let n = 0; n < 6; n++)
                            if (i.mipmaps && i.mipmaps.length > 0) {
                                a.__webglFramebuffer[n] = [];
                                for (let t = 0; t < i.mipmaps.length; t++) a.__webglFramebuffer[n][t] = e.createFramebuffer()
                            } else a.__webglFramebuffer[n] = e.createFramebuffer()
                    } else {
                        if (i.mipmaps && i.mipmaps.length > 0) {
                            a.__webglFramebuffer = [];
                            for (let n = 0; n < i.mipmaps.length; n++) a.__webglFramebuffer[n] = e.createFramebuffer()
                        } else a.__webglFramebuffer = e.createFramebuffer();
                        if (u)
                            for (let n = 0, t = c.length; n < t; n++) {
                                let t = r.get(c[n]);
                                void 0 === t.__webglTexture && (t.__webglTexture = e.createTexture(), l.memory.textures++)
                            }
                        if (n.samples > 0 && !1 === W(n)) {
                            a.__webglMultisampledFramebuffer = e.createFramebuffer(), a.__webglColorRenderbuffer = [], t.bindFramebuffer(e.FRAMEBUFFER, a.__webglMultisampledFramebuffer);
                            for (let t = 0; t < c.length; t++) {
                                let i = c[t];
                                a.__webglColorRenderbuffer[t] = e.createRenderbuffer(), e.bindRenderbuffer(e.RENDERBUFFER, a.__webglColorRenderbuffer[t]);
                                let r = o.convert(i.format, i.colorSpace),
                                    l = o.convert(i.type),
                                    s = E(i.internalFormat, r, l, i.normalized, i.colorSpace, !0 === n.isXRRenderTarget),
                                    d = V(n);
                                e.renderbufferStorageMultisample(e.RENDERBUFFER, d, s, n.width, n.height), e.framebufferRenderbuffer(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0 + t, e.RENDERBUFFER, a.__webglColorRenderbuffer[t])
                            }
                            e.bindRenderbuffer(e.RENDERBUFFER, null), n.depthBuffer && (a.__webglDepthRenderbuffer = e.createRenderbuffer(), O(a.__webglDepthRenderbuffer, n, !0)), t.bindFramebuffer(e.FRAMEBUFFER, null)
                        }
                    }
                    if (d) {
                        t.bindTexture(e.TEXTURE_CUBE_MAP, s.__webglTexture), U(e.TEXTURE_CUBE_MAP, i);
                        for (let t = 0; t < 6; t++)
                            if (i.mipmaps && i.mipmaps.length > 0)
                                for (let r = 0; r < i.mipmaps.length; r++) y(a.__webglFramebuffer[t][r], n, i, e.COLOR_ATTACHMENT0, e.TEXTURE_CUBE_MAP_POSITIVE_X + t, r);
                            else y(a.__webglFramebuffer[t], n, i, e.COLOR_ATTACHMENT0, e.TEXTURE_CUBE_MAP_POSITIVE_X + t, 0);
                        v(i) && S(e.TEXTURE_CUBE_MAP), t.unbindTexture()
                    } else if (u) {
                        for (let i = 0, o = c.length; i < o; i++) {
                            let o = c[i],
                                l = r.get(o),
                                s = e.TEXTURE_2D;
                            (n.isWebGL3DRenderTarget || n.isWebGLArrayRenderTarget) && (s = n.isWebGL3DRenderTarget ? e.TEXTURE_3D : e.TEXTURE_2D_ARRAY), t.bindTexture(s, l.__webglTexture), U(s, o), y(a.__webglFramebuffer, n, o, e.COLOR_ATTACHMENT0 + i, s, 0), v(o) && S(s)
                        }
                        t.unbindTexture()
                    } else {
                        let r = e.TEXTURE_2D;
                        if ((n.isWebGL3DRenderTarget || n.isWebGLArrayRenderTarget) && (r = n.isWebGL3DRenderTarget ? e.TEXTURE_3D : e.TEXTURE_2D_ARRAY), t.bindTexture(r, s.__webglTexture), U(r, i), i.mipmaps && i.mipmaps.length > 0)
                            for (let t = 0; t < i.mipmaps.length; t++) y(a.__webglFramebuffer[t], n, i, e.COLOR_ATTACHMENT0, r, t);
                        else y(a.__webglFramebuffer, n, i, e.COLOR_ATTACHMENT0, r, 0);
                        v(i) && S(r), t.unbindTexture()
                    }
                    n.depthBuffer && B(n)
                }, this.updateRenderTargetMipmap = function(n) {
                    let i = n.textures;
                    for (let a = 0, o = i.length; a < o; a++) {
                        let o = i[a];
                        if (v(o)) {
                            let i = n.isWebGLCubeRenderTarget ? e.TEXTURE_CUBE_MAP : n.isWebGL3DRenderTarget ? e.TEXTURE_3D : n.isWebGLArrayRenderTarget || n.isCompressedArrayTexture ? e.TEXTURE_2D_ARRAY : e.TEXTURE_2D,
                                a = r.get(o).__webglTexture;
                            t.bindTexture(i, a), S(i), t.unbindTexture()
                        }
                    }
                }, this.updateMultisampleRenderTarget = function(n) {
                    if (n.samples > 0) {
                        if (!1 === W(n)) {
                            let i = n.textures,
                                a = n.width,
                                o = n.height,
                                l = e.COLOR_BUFFER_BIT,
                                s = n.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT,
                                c = r.get(n),
                                u = i.length > 1;
                            if (u)
                                for (let n = 0; n < i.length; n++) t.bindFramebuffer(e.FRAMEBUFFER, c.__webglMultisampledFramebuffer), e.framebufferRenderbuffer(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0 + n, e.RENDERBUFFER, null), t.bindFramebuffer(e.FRAMEBUFFER, c.__webglFramebuffer), e.framebufferTexture2D(e.DRAW_FRAMEBUFFER, e.COLOR_ATTACHMENT0 + n, e.TEXTURE_2D, null, 0);
                            t.bindFramebuffer(e.READ_FRAMEBUFFER, c.__webglMultisampledFramebuffer);
                            let f = n.texture.mipmaps;
                            f && f.length > 0 ? t.bindFramebuffer(e.DRAW_FRAMEBUFFER, c.__webglFramebuffer[0]) : t.bindFramebuffer(e.DRAW_FRAMEBUFFER, c.__webglFramebuffer);
                            for (let t = 0; t < i.length; t++) {
                                if (n.resolveDepthBuffer && (n.depthBuffer && (l |= e.DEPTH_BUFFER_BIT), n.stencilBuffer && n.resolveStencilBuffer && (l |= e.STENCIL_BUFFER_BIT)), u) {
                                    e.framebufferRenderbuffer(e.READ_FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.RENDERBUFFER, c.__webglColorRenderbuffer[t]);
                                    let n = r.get(i[t]).__webglTexture;
                                    e.framebufferTexture2D(e.DRAW_FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, n, 0)
                                }
                                e.blitFramebuffer(0, 0, a, o, 0, 0, a, o, l, e.NEAREST), !0 === d && (G.length = 0, H.length = 0, G.push(e.COLOR_ATTACHMENT0 + t), n.depthBuffer && !1 === n.storeMultisampledDepthBuffer && (G.push(s), H.push(s), e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER, H)), e.invalidateFramebuffer(e.READ_FRAMEBUFFER, G))
                            }
                            if (t.bindFramebuffer(e.READ_FRAMEBUFFER, null), t.bindFramebuffer(e.DRAW_FRAMEBUFFER, null), u)
                                for (let n = 0; n < i.length; n++) {
                                    t.bindFramebuffer(e.FRAMEBUFFER, c.__webglMultisampledFramebuffer), e.framebufferRenderbuffer(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0 + n, e.RENDERBUFFER, c.__webglColorRenderbuffer[n]);
                                    let a = r.get(i[n]).__webglTexture;
                                    t.bindFramebuffer(e.FRAMEBUFFER, c.__webglFramebuffer), e.framebufferTexture2D(e.DRAW_FRAMEBUFFER, e.COLOR_ATTACHMENT0 + n, e.TEXTURE_2D, a, 0)
                                }
                            t.bindFramebuffer(e.DRAW_FRAMEBUFFER, c.__webglMultisampledFramebuffer)
                        } else if (n.depthBuffer && !1 === n.storeMultisampledDepthBuffer && d) {
                            let t = n.stencilBuffer ? e.DEPTH_STENCIL_ATTACHMENT : e.DEPTH_ATTACHMENT;
                            e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER, [t])
                        }
                    }
                }, this.setupDepthRenderbuffer = B, this.setupFrameBufferTexture = y, this.useMultisampledRTT = W, this.isReversedDepthBuffer = function() {
                    return t.buffers.depth.getReversed()
                }
            }

            function nb(e, n) {
                return {
                    convert: function(t, r = i.jf0) {
                        let a, o = i.ppV.getTransfer(r);
                        if (t === i.OUM) return e.UNSIGNED_BYTE;
                        if (t === i.Wew) return e.UNSIGNED_SHORT_4_4_4_4;
                        if (t === i.gJ2) return e.UNSIGNED_SHORT_5_5_5_1;
                        if (t === i.Dmk) return e.UNSIGNED_INT_5_9_9_9_REV;
                        if (t === i.yT7) return e.UNSIGNED_INT_10F_11F_11F_REV;
                        if (t === i.tJf) return e.BYTE;
                        if (t === i.fBL) return e.SHORT;
                        if (t === i.cHt) return e.UNSIGNED_SHORT;
                        if (t === i.Yuy) return e.INT;
                        if (t === i.bkx) return e.UNSIGNED_INT;
                        if (t === i.RQf) return e.FLOAT;
                        if (t === i.ix0) return e.HALF_FLOAT;
                        if (t === i.wrO) return e.ALPHA;
                        if (t === i.HIg) return e.RGB;
                        if (t === i.GWd) return e.RGBA;
                        if (t === i.zdS) return e.DEPTH_COMPONENT;
                        if (t === i.dcC) return e.DEPTH_STENCIL;
                        if (t === i.VT0) return e.RED;
                        if (t === i.ZQM) return e.RED_INTEGER;
                        if (t === i.paN) return e.RG;
                        if (t === i.TkQ) return e.RG_INTEGER;
                        if (t === i.c90) return e.RGBA_INTEGER;
                        if (t === i.IE4 || t === i.Nz6 || t === i.jR7 || t === i.BXX)
                            if (o === i.KLL) {
                                if (null === (a = n.get("WEBGL_compressed_texture_s3tc_srgb"))) return null;
                                if (t === i.IE4) return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;
                                if (t === i.Nz6) return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;
                                if (t === i.jR7) return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;
                                if (t === i.BXX) return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT
                            } else {
                                if (null === (a = n.get("WEBGL_compressed_texture_s3tc"))) return null;
                                if (t === i.IE4) return a.COMPRESSED_RGB_S3TC_DXT1_EXT;
                                if (t === i.Nz6) return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;
                                if (t === i.jR7) return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;
                                if (t === i.BXX) return a.COMPRESSED_RGBA_S3TC_DXT5_EXT
                            }
                        if (t === i.k6Q || t === i.kTp || t === i.HXV || t === i.pBf) {
                            if (null === (a = n.get("WEBGL_compressed_texture_pvrtc"))) return null;
                            if (t === i.k6Q) return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;
                            if (t === i.kTp) return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;
                            if (t === i.HXV) return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;
                            if (t === i.pBf) return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG
                        }
                        if (t === i.CVz || t === i.Riy || t === i.KDk || t === i.BVL || t === i.gZr || t === i.OtU || t === i.jSS) {
                            if (null === (a = n.get("WEBGL_compressed_texture_etc"))) return null;
                            if (t === i.CVz || t === i.Riy) return o === i.KLL ? a.COMPRESSED_SRGB8_ETC2 : a.COMPRESSED_RGB8_ETC2;
                            if (t === i.KDk) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC : a.COMPRESSED_RGBA8_ETC2_EAC;
                            if (t === i.BVL) return a.COMPRESSED_R11_EAC;
                            if (t === i.gZr) return a.COMPRESSED_SIGNED_R11_EAC;
                            if (t === i.OtU) return a.COMPRESSED_RG11_EAC;
                            if (t === i.jSS) return a.COMPRESSED_SIGNED_RG11_EAC
                        }
                        if (t === i.qa3 || t === i.B_h || t === i.czI || t === i.rSH || t === i.Qrf || t === i.psI || t === i.a5J || t === i._QJ || t === i.uB5 || t === i.lyL || t === i.bC7 || t === i.y3Z || t === i.ojs || t === i.S$4) {
                            if (null === (a = n.get("WEBGL_compressed_texture_astc"))) return null;
                            if (t === i.qa3) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR : a.COMPRESSED_RGBA_ASTC_4x4_KHR;
                            if (t === i.B_h) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR : a.COMPRESSED_RGBA_ASTC_5x4_KHR;
                            if (t === i.czI) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR : a.COMPRESSED_RGBA_ASTC_5x5_KHR;
                            if (t === i.rSH) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR : a.COMPRESSED_RGBA_ASTC_6x5_KHR;
                            if (t === i.Qrf) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR : a.COMPRESSED_RGBA_ASTC_6x6_KHR;
                            if (t === i.psI) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR : a.COMPRESSED_RGBA_ASTC_8x5_KHR;
                            if (t === i.a5J) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR : a.COMPRESSED_RGBA_ASTC_8x6_KHR;
                            if (t === i._QJ) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR : a.COMPRESSED_RGBA_ASTC_8x8_KHR;
                            if (t === i.uB5) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR : a.COMPRESSED_RGBA_ASTC_10x5_KHR;
                            if (t === i.lyL) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR : a.COMPRESSED_RGBA_ASTC_10x6_KHR;
                            if (t === i.bC7) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR : a.COMPRESSED_RGBA_ASTC_10x8_KHR;
                            if (t === i.y3Z) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR : a.COMPRESSED_RGBA_ASTC_10x10_KHR;
                            if (t === i.ojs) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR : a.COMPRESSED_RGBA_ASTC_12x10_KHR;
                            if (t === i.S$4) return o === i.KLL ? a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR : a.COMPRESSED_RGBA_ASTC_12x12_KHR
                        }
                        if (t === i.Fn || t === i.H23 || t === i.W9U) {
                            if (null === (a = n.get("EXT_texture_compression_bptc"))) return null;
                            if (t === i.Fn) return o === i.KLL ? a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT : a.COMPRESSED_RGBA_BPTC_UNORM_EXT;
                            if (t === i.H23) return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;
                            if (t === i.W9U) return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT
                        }
                        if (t === i.Kef || t === i.XG_ || t === i.HO_ || t === i.CWW) {
                            if (null === (a = n.get("EXT_texture_compression_rgtc"))) return null;
                            if (t === i.Kef) return a.COMPRESSED_RED_RGTC1_EXT;
                            if (t === i.XG_) return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;
                            if (t === i.HO_) return a.COMPRESSED_RED_GREEN_RGTC2_EXT;
                            if (t === i.CWW) return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT
                        }
                        return t === i.V3x ? e.UNSIGNED_INT_24_8 : void 0 !== e[t] ? e[t] : null
                    }
                }
            }
            let nC = `
void main() {

	gl_Position = vec4( position, 1.0 );

}`,
                nP = `
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;
            class nL {
                constructor() {
                    this.texture = null, this.mesh = null, this.depthNear = 0, this.depthFar = 0
                }
                init(e, n) {
                    if (null === this.texture) {
                        let t = new i.rjZ(e.texture);
                        (e.depthNear !== n.depthNear || e.depthFar !== n.depthFar) && (this.depthNear = e.depthNear, this.depthFar = e.depthFar), this.texture = t
                    }
                }
                getMesh(e) {
                    if (null !== this.texture && null === this.mesh) {
                        let n = e.cameras[0].viewport,
                            t = new i.BKk({
                                vertexShader: nC,
                                fragmentShader: nP,
                                uniforms: {
                                    depthColor: {
                                        value: this.texture
                                    },
                                    depthWidth: {
                                        value: n.z
                                    },
                                    depthHeight: {
                                        value: n.w
                                    }
                                }
                            });
                        this.mesh = new i.eaF(new i.bdM(20, 20), t)
                    }
                    return this.mesh
                }
                reset() {
                    this.texture = null, this.mesh = null
                }
                getDepthTexture() {
                    return this.texture
                }
            }
            class nw extends i.Qev {
                constructor(e, n) {
                    super();
                    const t = this;
                    let a = null,
                        o = 1,
                        l = null,
                        s = "local-floor",
                        c = 1,
                        d = null,
                        u = null,
                        f = null,
                        p = null,
                        m = null,
                        h = null;
                    const _ = "u" > typeof XRWebGLBinding,
                        g = new nL,
                        v = {},
                        S = n.getContextAttributes();
                    let E = null,
                        M = null;
                    const T = [],
                        x = [],
                        R = new i.I9Y;
                    let A = null,
                        b = null;
                    const C = new i.ubm;
                    C.viewport = new i.IUQ;
                    const P = new i.ubm;
                    P.viewport = new i.IUQ;
                    const L = [C, P],
                        w = new i.nZQ;
                    let U = null,
                        I = null;

                    function D(e) {
                        let n = x.indexOf(e.inputSource);
                        if (-1 === n) return;
                        let t = T[n];
                        void 0 !== t && (t.update(e.inputSource, e.frame, d || l), t.dispatchEvent({
                            type: e.type,
                            data: e.inputSource
                        }))
                    }

                    function N() {
                        a.removeEventListener("select", D), a.removeEventListener("selectstart", D), a.removeEventListener("selectend", D), a.removeEventListener("squeeze", D), a.removeEventListener("squeezestart", D), a.removeEventListener("squeezeend", D), a.removeEventListener("end", N), a.removeEventListener("inputsourceschange", y);
                        for (let e = 0; e < T.length; e++) {
                            let n = x[e];
                            null !== n && (x[e] = null, T[e].disconnect(n))
                        }
                        for (let e in U = null, I = null, g.reset(), v) delete v[e];
                        if (e.setRenderTarget(E), m = null, p = null, f = null, a = null, M = null, H.stop(), t.isPresenting = !1, e.setPixelRatio(A), e.setSize(R.width, R.height, !1), null !== b) {
                            let e = b.camera;
                            e.fov = b.fov, e.zoom = b.zoom, e.updateProjectionMatrix(), b = null
                        }
                        t.dispatchEvent({
                            type: "sessionend"
                        })
                    }

                    function y(e) {
                        for (let n = 0; n < e.removed.length; n++) {
                            let t = e.removed[n],
                                i = x.indexOf(t);
                            i >= 0 && (x[i] = null, T[i].disconnect(t))
                        }
                        for (let n = 0; n < e.added.length; n++) {
                            let t = e.added[n],
                                i = x.indexOf(t);
                            if (-1 === i) {
                                for (let e = 0; e < T.length; e++)
                                    if (e >= x.length) {
                                        x.push(t), i = e;
                                        break
                                    } else if (null === x[e]) {
                                    x[e] = t, i = e;
                                    break
                                }
                                if (-1 === i) break
                            }
                            let r = T[i];
                            r && r.connect(t)
                        }
                    }
                    this.cameraAutoUpdate = !0, this.enabled = !1, this.isPresenting = !1, this.getController = function(e) {
                        let n = T[e];
                        return void 0 === n && (n = new i.R3r, T[e] = n), n.getTargetRaySpace()
                    }, this.getControllerGrip = function(e) {
                        let n = T[e];
                        return void 0 === n && (n = new i.R3r, T[e] = n), n.getGripSpace()
                    }, this.getHand = function(e) {
                        let n = T[e];
                        return void 0 === n && (n = new i.R3r, T[e] = n), n.getHandSpace()
                    }, this.setFramebufferScaleFactor = function(e) {
                        o = e, !0 === t.isPresenting && (0, i.R8M)("WebXRManager: Cannot change framebuffer scale while presenting.")
                    }, this.setReferenceSpaceType = function(e) {
                        s = e, !0 === t.isPresenting && (0, i.R8M)("WebXRManager: Cannot change reference space type while presenting.")
                    }, this.getReferenceSpace = function() {
                        return d || l
                    }, this.setReferenceSpace = function(e) {
                        d = e
                    }, this.getBaseLayer = function() {
                        return null !== p ? p : m
                    }, this.getBinding = function() {
                        return null === f && _ && (f = new XRWebGLBinding(a, n)), f
                    }, this.getFrame = function() {
                        return h
                    }, this.getSession = function() {
                        return a
                    }, this.setSession = async function(r) {
                        if (null !== (a = r)) {
                            if (E = e.getRenderTarget(), a.addEventListener("select", D), a.addEventListener("selectstart", D), a.addEventListener("selectend", D), a.addEventListener("squeeze", D), a.addEventListener("squeezestart", D), a.addEventListener("squeezeend", D), a.addEventListener("end", N), a.addEventListener("inputsourceschange", y), !0 !== S.xrCompatible && await n.makeXRCompatible(), A = e.getPixelRatio(), e.getSize(R), _ && "createProjectionLayer" in XRWebGLBinding.prototype) {
                                let t = null,
                                    r = null,
                                    l = null;
                                S.depth && (l = S.stencil ? n.DEPTH24_STENCIL8 : n.DEPTH_COMPONENT24, t = S.stencil ? i.dcC : i.zdS, r = S.stencil ? i.V3x : i.bkx);
                                let s = {
                                    colorFormat: n.RGBA8,
                                    depthFormat: l,
                                    scaleFactor: o
                                };
                                p = (f = this.getBinding()).createProjectionLayer(s), a.updateRenderState({
                                    layers: [p]
                                }), e.setPixelRatio(1), e.setSize(p.textureWidth, p.textureHeight, !1), M = new i.nWS(p.textureWidth, p.textureHeight, {
                                    format: i.GWd,
                                    type: i.OUM,
                                    depthTexture: new i.VCu(p.textureWidth, p.textureHeight, r, void 0, void 0, void 0, void 0, void 0, void 0, t),
                                    stencilBuffer: S.stencil,
                                    colorSpace: e.outputColorSpace,
                                    samples: 4 * !!S.antialias,
                                    resolveDepthBuffer: !1 === p.ignoreDepthValues,
                                    resolveStencilBuffer: !1 === p.ignoreDepthValues,
                                    storeMultisampledDepthBuffer: !1 === p.ignoreDepthValues,
                                    storeMultisampledStencilBuffer: !1 === p.ignoreDepthValues
                                })
                            } else {
                                let t = {
                                    antialias: S.antialias,
                                    alpha: !0,
                                    depth: S.depth,
                                    stencil: S.stencil,
                                    framebufferScaleFactor: o
                                };
                                m = new XRWebGLLayer(a, n, t), a.updateRenderState({
                                    baseLayer: m
                                }), e.setPixelRatio(1), e.setSize(m.framebufferWidth, m.framebufferHeight, !1), M = new i.nWS(m.framebufferWidth, m.framebufferHeight, {
                                    format: i.GWd,
                                    type: i.OUM,
                                    colorSpace: e.outputColorSpace,
                                    stencilBuffer: S.stencil,
                                    resolveDepthBuffer: !1 === m.ignoreDepthValues,
                                    resolveStencilBuffer: !1 === m.ignoreDepthValues,
                                    storeMultisampledDepthBuffer: !1 === m.ignoreDepthValues,
                                    storeMultisampledStencilBuffer: !1 === m.ignoreDepthValues
                                })
                            }
                            M.isXRRenderTarget = !0, this.setFoveation(c), d = null, l = await a.requestReferenceSpace(s), H.setContext(a), H.start(), t.isPresenting = !0, t.dispatchEvent({
                                type: "sessionstart"
                            })
                        }
                    }, this.getEnvironmentBlendMode = function() {
                        if (null !== a) return a.environmentBlendMode
                    }, this.getDepthTexture = function() {
                        return g.getDepthTexture()
                    };
                    const O = new i.Pq0,
                        F = new i.Pq0;

                    function B(e, n) {
                        null === n ? e.matrixWorld.copy(e.matrix) : e.matrixWorld.multiplyMatrices(n.matrixWorld, e.matrix), e.matrixWorldInverse.copy(e.matrixWorld).invert()
                    }
                    this.updateCamera = function(e) {
                        var n, t, r;
                        if (null === a) return;
                        let o = e.near,
                            l = e.far;
                        null !== g.texture && (g.depthNear > 0 && (o = g.depthNear), g.depthFar > 0 && (l = g.depthFar)), w.near = P.near = C.near = o, w.far = P.far = C.far = l, (U !== w.near || I !== w.far) && (a.updateRenderState({
                            depthNear: w.near,
                            depthFar: w.far
                        }), U = w.near, I = w.far), w.layers.mask = 6 | e.layers.mask, C.layers.mask = -5 & w.layers.mask, P.layers.mask = -3 & w.layers.mask;
                        let s = e.parent,
                            c = w.cameras;
                        B(w, s);
                        for (let e = 0; e < c.length; e++) B(c[e], s);
                        2 === c.length ? function(e, n, t) {
                            O.setFromMatrixPosition(n.matrixWorld), F.setFromMatrixPosition(t.matrixWorld);
                            let i = O.distanceTo(F),
                                r = n.projectionMatrix.elements,
                                a = t.projectionMatrix.elements,
                                o = r[14] / (r[10] - 1),
                                l = r[14] / (r[10] + 1),
                                s = (r[9] + 1) / r[5],
                                c = (r[9] - 1) / r[5],
                                d = (r[8] - 1) / r[0],
                                u = (a[8] + 1) / a[0],
                                f = i / (-d + u),
                                p = -(f * d);
                            if (n.matrixWorld.decompose(e.position, e.quaternion, e.scale), e.translateX(p), e.translateZ(f), e.matrixWorld.compose(e.position, e.quaternion, e.scale), e.matrixWorldInverse.copy(e.matrixWorld).invert(), -1 === r[10]) e.projectionMatrix.copy(n.projectionMatrix), e.projectionMatrixInverse.copy(n.projectionMatrixInverse);
                            else {
                                let n = o + f,
                                    t = l + f;
                                e.projectionMatrix.makePerspective(o * d - p, o * u + (i - p), s * l / t * n, c * l / t * n, n, t), e.projectionMatrixInverse.copy(e.projectionMatrix).invert()
                            }
                        }(w, C, P) : w.projectionMatrix.copy(C.projectionMatrix), null === b && e.isPerspectiveCamera && (b = {
                            camera: e,
                            fov: e.fov,
                            zoom: e.zoom
                        }), n = e, t = w, null === (r = s) ? n.matrix.copy(t.matrixWorld) : (n.matrix.copy(r.matrixWorld), n.matrix.invert(), n.matrix.multiply(t.matrixWorld)), n.matrix.decompose(n.position, n.quaternion, n.scale), n.updateMatrixWorld(!0), n.projectionMatrix.copy(t.projectionMatrix), n.projectionMatrixInverse.copy(t.projectionMatrixInverse), n.isPerspectiveCamera && (n.fov = 2 * i.a55 * Math.atan(1 / n.projectionMatrix.elements[5]), n.zoom = 1)
                    }, this.getCamera = function() {
                        return w
                    }, this.getFoveation = function() {
                        if (null !== p || null !== m) return c
                    }, this.setFoveation = function(e) {
                        c = e, null !== p && (p.fixedFoveation = e), null !== m && void 0 !== m.fixedFoveation && (m.fixedFoveation = e)
                    }, this.hasDepthSensing = function() {
                        return null !== g.texture
                    }, this.getDepthSensingMesh = function() {
                        return g.getMesh(w)
                    }, this.getCameraTexture = function(e) {
                        return v[e]
                    };
                    let G = null;
                    const H = new r;
                    H.setAnimationLoop(function(n, r) {
                        if (u = r.getViewerPose(d || l), h = r, null !== u) {
                            let n = u.views;
                            null !== m && (e.setRenderTargetFramebuffer(M, m.framebuffer), e.setRenderTarget(M));
                            let r = !1;
                            n.length !== w.cameras.length && (w.cameras.length = 0, r = !0);
                            for (let t = 0; t < n.length; t++) {
                                let a = n[t],
                                    o = null;
                                if (null !== m) o = m.getViewport(a);
                                else {
                                    let n = f.getViewSubImage(p, a);
                                    o = n.viewport, 0 === t && (e.setRenderTargetTextures(M, n.colorTexture, n.depthStencilTexture), e.setRenderTarget(M))
                                }
                                let l = L[t];
                                void 0 === l && ((l = new i.ubm).layers.enable(t), l.viewport = new i.IUQ, L[t] = l), l.matrix.fromArray(a.transform.matrix), l.matrix.decompose(l.position, l.quaternion, l.scale), l.projectionMatrix.fromArray(a.projectionMatrix), l.projectionMatrixInverse.copy(l.projectionMatrix).invert(), l.viewport.set(o.x, o.y, o.width, o.height), 0 === t && (w.matrix.copy(l.matrix), w.matrix.decompose(w.position, w.quaternion, w.scale)), !0 === r && w.cameras.push(l)
                            }
                            let o = a.enabledFeatures;
                            if (o && o.includes("depth-sensing") && "gpu-optimized" == a.depthUsage && _) {
                                let e = (f = t.getBinding()).getDepthInformation(n[0]);
                                e && e.isValid && e.texture && g.init(e, a.renderState)
                            }
                            if (o && o.includes("camera-access") && _) {
                                e.state.unbindTexture(), f = t.getBinding();
                                for (let e = 0; e < n.length; e++) {
                                    let t = n[e].camera;
                                    if (t) {
                                        let e = v[t];
                                        e || (e = new i.rjZ, v[t] = e);
                                        let n = f.getCameraImage(t);
                                        e.sourceTexture = n
                                    }
                                }
                            }
                        }
                        for (let e = 0; e < T.length; e++) {
                            let n = x[e],
                                t = T[e];
                            null !== n && void 0 !== t && t.update(n, r, d || l)
                        }
                        G && G(n, r), r.detectedPlanes && t.dispatchEvent({
                            type: "planesdetected",
                            data: r
                        }), h = null
                    }), this.setAnimationLoop = function(e) {
                        G = e
                    }, this.dispose = function() {}
                }
            }
            let nU = new i.kn4,
                nI = new i.dwI;

            function nD(e, n) {
                function t(e, n) {
                    !0 === e.matrixAutoUpdate && e.updateMatrix(), n.value.copy(e.matrix)
                }

                function r(e, r) {
                    e.opacity.value = r.opacity, r.color && e.diffuse.value.copy(r.color), r.emissive && e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity), r.map && (e.map.value = r.map, t(r.map, e.mapTransform)), r.alphaMap && (e.alphaMap.value = r.alphaMap, t(r.alphaMap, e.alphaMapTransform)), r.bumpMap && (e.bumpMap.value = r.bumpMap, t(r.bumpMap, e.bumpMapTransform), e.bumpScale.value = r.bumpScale, r.side === i.hsX && (e.bumpScale.value *= -1)), r.normalMap && (e.normalMap.value = r.normalMap, t(r.normalMap, e.normalMapTransform), e.normalScale.value.copy(r.normalScale), r.side === i.hsX && e.normalScale.value.negate()), r.displacementMap && (e.displacementMap.value = r.displacementMap, t(r.displacementMap, e.displacementMapTransform), e.displacementScale.value = r.displacementScale, e.displacementBias.value = r.displacementBias), r.emissiveMap && (e.emissiveMap.value = r.emissiveMap, t(r.emissiveMap, e.emissiveMapTransform)), r.specularMap && (e.specularMap.value = r.specularMap, t(r.specularMap, e.specularMapTransform)), r.alphaTest > 0 && (e.alphaTest.value = r.alphaTest);
                    let a = n.get(r),
                        o = a.envMap,
                        l = a.envMapRotation;
                    o && (e.envMap.value = o, e.envMapRotation.value.setFromMatrix4(nU.makeRotationFromEuler(l)).transpose(), o.isCubeTexture && !1 === o.isRenderTargetTexture && e.envMapRotation.value.premultiply(nI), e.reflectivity.value = r.reflectivity, e.ior.value = r.ior, e.refractionRatio.value = r.refractionRatio), r.lightMap && (e.lightMap.value = r.lightMap, e.lightMapIntensity.value = r.lightMapIntensity, t(r.lightMap, e.lightMapTransform)), r.aoMap && (e.aoMap.value = r.aoMap, e.aoMapIntensity.value = r.aoMapIntensity, t(r.aoMap, e.aoMapTransform))
                }
                return {
                    refreshFogUniforms: function(n, t) {
                        t.color.getRGB(n.fogColor.value, (0, i._Ut)(e)), t.isFog ? (n.fogNear.value = t.near, n.fogFar.value = t.far) : t.isFogExp2 && (n.fogDensity.value = t.density)
                    },
                    refreshMaterialUniforms: function(e, a, o, l, s) {
                        var c, d, u, f, p, m, h, _, g, v, S, E, M, T, x, R, A, b, C, P, L, w, U;
                        let I;
                        a.isNodeMaterial ? a.uniformsNeedUpdate = !1 : a.isMeshBasicMaterial ? r(e, a) : a.isMeshLambertMaterial ? (r(e, a), a.envMap && (e.envMapIntensity.value = a.envMapIntensity)) : a.isMeshToonMaterial ? (r(e, a), c = e, (d = a).gradientMap && (c.gradientMap.value = d.gradientMap)) : a.isMeshPhongMaterial ? (r(e, a), u = e, f = a, u.specular.value.copy(f.specular), u.shininess.value = Math.max(f.shininess, 1e-4), a.envMap && (e.envMapIntensity.value = a.envMapIntensity)) : a.isMeshStandardMaterial ? (r(e, a), p = e, m = a, p.metalness.value = m.metalness, m.metalnessMap && (p.metalnessMap.value = m.metalnessMap, t(m.metalnessMap, p.metalnessMapTransform)), p.roughness.value = m.roughness, m.roughnessMap && (p.roughnessMap.value = m.roughnessMap, t(m.roughnessMap, p.roughnessMapTransform)), m.envMap && (p.envMapIntensity.value = m.envMapIntensity), a.isMeshPhysicalMaterial && (h = e, _ = a, g = s, h.ior.value = _.ior, _.sheen > 0 && (h.sheenColor.value.copy(_.sheenColor).multiplyScalar(_.sheen), h.sheenRoughness.value = _.sheenRoughness, _.sheenColorMap && (h.sheenColorMap.value = _.sheenColorMap, t(_.sheenColorMap, h.sheenColorMapTransform)), _.sheenRoughnessMap && (h.sheenRoughnessMap.value = _.sheenRoughnessMap, t(_.sheenRoughnessMap, h.sheenRoughnessMapTransform))), _.clearcoat > 0 && (h.clearcoat.value = _.clearcoat, h.clearcoatRoughness.value = _.clearcoatRoughness, _.clearcoatMap && (h.clearcoatMap.value = _.clearcoatMap, t(_.clearcoatMap, h.clearcoatMapTransform)), _.clearcoatRoughnessMap && (h.clearcoatRoughnessMap.value = _.clearcoatRoughnessMap, t(_.clearcoatRoughnessMap, h.clearcoatRoughnessMapTransform)), _.clearcoatNormalMap && (h.clearcoatNormalMap.value = _.clearcoatNormalMap, t(_.clearcoatNormalMap, h.clearcoatNormalMapTransform), h.clearcoatNormalScale.value.copy(_.clearcoatNormalScale), _.side === i.hsX && h.clearcoatNormalScale.value.negate())), _.dispersion > 0 && (h.dispersion.value = _.dispersion), _.retroreflectivity > 0 && (h.retroreflectivity.value = _.retroreflectivity), _.iridescence > 0 && (h.iridescence.value = _.iridescence, h.iridescenceIOR.value = _.iridescenceIOR, h.iridescenceThicknessMinimum.value = _.iridescenceThicknessRange[0], h.iridescenceThicknessMaximum.value = _.iridescenceThicknessRange[1], _.iridescenceMap && (h.iridescenceMap.value = _.iridescenceMap, t(_.iridescenceMap, h.iridescenceMapTransform)), _.iridescenceThicknessMap && (h.iridescenceThicknessMap.value = _.iridescenceThicknessMap, t(_.iridescenceThicknessMap, h.iridescenceThicknessMapTransform))), _.transmission > 0 && (h.transmission.value = _.transmission, h.transmissionSamplerMap.value = g.texture, h.transmissionSamplerSize.value.set(g.width, g.height), _.transmissionMap && (h.transmissionMap.value = _.transmissionMap, t(_.transmissionMap, h.transmissionMapTransform)), h.thickness.value = _.thickness, _.thicknessMap && (h.thicknessMap.value = _.thicknessMap, t(_.thicknessMap, h.thicknessMapTransform)), h.attenuationDistance.value = _.attenuationDistance, h.attenuationColor.value.copy(_.attenuationColor)), _.anisotropy > 0 && (h.anisotropyVector.value.set(_.anisotropy * Math.cos(_.anisotropyRotation), _.anisotropy * Math.sin(_.anisotropyRotation)), _.anisotropyMap && (h.anisotropyMap.value = _.anisotropyMap, t(_.anisotropyMap, h.anisotropyMapTransform))), h.specularIntensity.value = _.specularIntensity, h.specularColor.value.copy(_.specularColor), _.specularColorMap && (h.specularColorMap.value = _.specularColorMap, t(_.specularColorMap, h.specularColorMapTransform)), _.specularIntensityMap && (h.specularIntensityMap.value = _.specularIntensityMap, t(_.specularIntensityMap, h.specularIntensityMapTransform)))) : a.isMeshMatcapMaterial ? (r(e, a), v = e, (S = a).matcap && (v.matcap.value = S.matcap)) : a.isMeshDepthMaterial ? r(e, a) : a.isMeshDistanceMaterial ? (r(e, a), E = e, M = a, I = n.get(M).light, E.referencePosition.value.setFromMatrixPosition(I.matrixWorld), E.nearDistance.value = I.shadow.camera.near, E.farDistance.value = I.shadow.camera.far) : a.isMeshNormalMaterial ? r(e, a) : a.isLineBasicMaterial ? (T = e, x = a, T.diffuse.value.copy(x.color), T.opacity.value = x.opacity, x.map && (T.map.value = x.map, t(x.map, T.mapTransform)), a.isLineDashedMaterial && (R = e, A = a, R.dashSize.value = A.dashSize, R.totalSize.value = A.dashSize + A.gapSize, R.scale.value = A.scale)) : a.isPointsMaterial ? (b = e, C = a, P = o, L = l, b.diffuse.value.copy(C.color), b.opacity.value = C.opacity, b.size.value = C.size * P, b.scale.value = .5 * L, C.map && (b.map.value = C.map, t(C.map, b.uvTransform)), C.alphaMap && (b.alphaMap.value = C.alphaMap, t(C.alphaMap, b.alphaMapTransform)), C.alphaTest > 0 && (b.alphaTest.value = C.alphaTest)) : a.isSpriteMaterial ? (w = e, U = a, w.diffuse.value.copy(U.color), w.opacity.value = U.opacity, w.rotation.value = U.rotation, U.map && (w.map.value = U.map, t(U.map, w.mapTransform)), U.alphaMap && (w.alphaMap.value = U.alphaMap, t(U.alphaMap, w.alphaMapTransform)), U.alphaTest > 0 && (w.alphaTest.value = U.alphaTest)) : a.isShadowMaterial ? (e.color.value.copy(a.color), e.opacity.value = a.opacity) : a.isShaderMaterial && (a.uniformsNeedUpdate = !1)
                    }
                }
            }

            function nN(e, n, t, r) {
                let a = {},
                    o = {},
                    l = [],
                    s = e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);

                function c(n, t, i, r) {
                    if (!0 === function(e, n, t, i) {
                            let r = e.value,
                                a = n + "_" + t;
                            if (void 0 === i[a]) return "number" == typeof r || "boolean" == typeof r ? i[a] = r : ArrayBuffer.isView(r) ? i[a] = r.slice() : i[a] = r.clone(), !0; {
                                let e = i[a];
                                if ("number" == typeof r || "boolean" == typeof r) {
                                    if (e !== r) return i[a] = r, !0
                                } else if (ArrayBuffer.isView(r)) return !0;
                                else if (!1 === e.equals(r)) return e.copy(r), !0
                            }
                            return !1
                        }(n, t, i, r)) {
                        let t = n.__offset,
                            i = n.value;
                        if (Array.isArray(i)) {
                            let e = 0;
                            for (let t = 0; t < i.length; t++) {
                                let r = i[t],
                                    a = u(r);
                                d(r, n.__data, e), "number" == typeof r || "boolean" == typeof r || r.isMatrix3 || ArrayBuffer.isView(r) || (e += a.storage / Float32Array.BYTES_PER_ELEMENT)
                            }
                        } else d(i, n.__data, 0);
                        e.bufferSubData(e.UNIFORM_BUFFER, t, n.__data)
                    }
                }

                function d(e, n, t) {
                    "number" == typeof e || "boolean" == typeof e ? n[0] = e : e.isMatrix3 ? (n[0] = e.elements[0], n[1] = e.elements[1], n[2] = e.elements[2], n[3] = 0, n[4] = e.elements[3], n[5] = e.elements[4], n[6] = e.elements[5], n[7] = 0, n[8] = e.elements[6], n[9] = e.elements[7], n[10] = e.elements[8], n[11] = 0) : ArrayBuffer.isView(e) ? n.set(new e.constructor(e.buffer, e.byteOffset, n.length)) : e.toArray(n, t)
                }

                function u(e) {
                    let n = {
                        boundary: 0,
                        storage: 0
                    };
                    return "number" == typeof e || "boolean" == typeof e ? (n.boundary = 4, n.storage = 4) : e.isVector2 ? (n.boundary = 8, n.storage = 8) : e.isVector3 || e.isColor ? (n.boundary = 16, n.storage = 12) : e.isVector4 ? (n.boundary = 16, n.storage = 16) : e.isMatrix3 ? (n.boundary = 48, n.storage = 48) : e.isMatrix4 ? (n.boundary = 64, n.storage = 64) : e.isTexture ? (0, i.R8M)("WebGLRenderer: Texture samplers can not be part of an uniforms group.") : ArrayBuffer.isView(e) ? (n.boundary = 16, n.storage = e.byteLength) : (0, i.R8M)("WebGLRenderer: Unsupported uniform value type.", e), n
                }

                function f(n) {
                    let t = n.target;
                    t.removeEventListener("dispose", f);
                    let i = l.indexOf(t.__bindingPointIndex);
                    l.splice(i, 1), e.deleteBuffer(a[t.id]), delete a[t.id], delete o[t.id]
                }
                return {
                    bind: function(e, n) {
                        let t = n.program;
                        r.uniformBlockBinding(e, t)
                    },
                    update: function(t, d) {
                        var p;
                        let m, h, _, g, v = a[t.id];
                        void 0 === v && (function(e) {
                            let n = e.uniforms,
                                t = 0;
                            for (let e = 0, i = n.length; e < i; e++) {
                                let i = Array.isArray(n[e]) ? n[e] : [n[e]];
                                for (let e = 0, n = i.length; e < n; e++) {
                                    let n = i[e],
                                        r = Array.isArray(n.value) ? n.value : [n.value];
                                    for (let e = 0, i = r.length; e < i; e++) {
                                        let i = u(r[e]),
                                            a = t % 16,
                                            o = a % i.boundary,
                                            l = a + o;
                                        t += o, 0 !== l && 16 - l < i.storage && (t += 16 - l), n.__data = new Float32Array(i.storage / Float32Array.BYTES_PER_ELEMENT), n.__offset = t, t += i.storage
                                    }
                                }
                            }
                            let i = t % 16;
                            i > 0 && (t += 16 - i), e.__size = t, e.__cache = {}
                        }(t), (p = t).__bindingPointIndex = m = function() {
                            for (let e = 0; e < s; e++)
                                if (-1 === l.indexOf(e)) return l.push(e), e;
                            return (0, i.z3S)("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."), 0
                        }(), h = e.createBuffer(), _ = p.__size, g = p.usage, e.bindBuffer(e.UNIFORM_BUFFER, h), e.bufferData(e.UNIFORM_BUFFER, _, g), e.bindBuffer(e.UNIFORM_BUFFER, null), e.bindBufferBase(e.UNIFORM_BUFFER, m, h), v = h, a[t.id] = v, t.addEventListener("dispose", f));
                        let S = d.program;
                        r.updateUBOMapping(t, S);
                        let E = n.render.frame;
                        o[t.id] !== E && (function(n) {
                            let t = a[n.id],
                                i = n.uniforms,
                                r = n.__cache;
                            e.bindBuffer(e.UNIFORM_BUFFER, t);
                            for (let e = 0, n = i.length; e < n; e++) {
                                let n = i[e];
                                if (Array.isArray(n))
                                    for (let t = 0, i = n.length; t < i; t++) c(n[t], e, t, r);
                                else c(n, e, 0, r)
                            }
                            e.bindBuffer(e.UNIFORM_BUFFER, null)
                        }(t), o[t.id] = E)
                    },
                    dispose: function() {
                        for (let n in a) e.deleteBuffer(a[n]);
                        l = [], a = {}, o = {}
                    }
                }
            }
            nI.set(-1, 0, 0, 0, 1, 0, 0, 0, 1);
            let ny = new Uint16Array([12469, 15057, 12620, 14925, 13266, 14620, 13807, 14376, 14323, 13990, 14545, 13625, 14713, 13328, 14840, 12882, 14931, 12528, 14996, 12233, 15039, 11829, 15066, 11525, 15080, 11295, 15085, 10976, 15082, 10705, 15073, 10495, 13880, 14564, 13898, 14542, 13977, 14430, 14158, 14124, 14393, 13732, 14556, 13410, 14702, 12996, 14814, 12596, 14891, 12291, 14937, 11834, 14957, 11489, 14958, 11194, 14943, 10803, 14921, 10506, 14893, 10278, 14858, 9960, 14484, 14039, 14487, 14025, 14499, 13941, 14524, 13740, 14574, 13468, 14654, 13106, 14743, 12678, 14818, 12344, 14867, 11893, 14889, 11509, 14893, 11180, 14881, 10751, 14852, 10428, 14812, 10128, 14765, 9754, 14712, 9466, 14764, 13480, 14764, 13475, 14766, 13440, 14766, 13347, 14769, 13070, 14786, 12713, 14816, 12387, 14844, 11957, 14860, 11549, 14868, 11215, 14855, 10751, 14825, 10403, 14782, 10044, 14729, 9651, 14666, 9352, 14599, 9029, 14967, 12835, 14966, 12831, 14963, 12804, 14954, 12723, 14936, 12564, 14917, 12347, 14900, 11958, 14886, 11569, 14878, 11247, 14859, 10765, 14828, 10401, 14784, 10011, 14727, 9600, 14660, 9289, 14586, 8893, 14508, 8533, 15111, 12234, 15110, 12234, 15104, 12216, 15092, 12156, 15067, 12010, 15028, 11776, 14981, 11500, 14942, 11205, 14902, 10752, 14861, 10393, 14812, 9991, 14752, 9570, 14682, 9252, 14603, 8808, 14519, 8445, 14431, 8145, 15209, 11449, 15208, 11451, 15202, 11451, 15190, 11438, 15163, 11384, 15117, 11274, 15055, 10979, 14994, 10648, 14932, 10343, 14871, 9936, 14803, 9532, 14729, 9218, 14645, 8742, 14556, 8381, 14461, 8020, 14365, 7603, 15273, 10603, 15272, 10607, 15267, 10619, 15256, 10631, 15231, 10614, 15182, 10535, 15118, 10389, 15042, 10167, 14963, 9787, 14883, 9447, 14800, 9115, 14710, 8665, 14615, 8318, 14514, 7911, 14411, 7507, 14279, 7198, 15314, 9675, 15313, 9683, 15309, 9712, 15298, 9759, 15277, 9797, 15229, 9773, 15166, 9668, 15084, 9487, 14995, 9274, 14898, 8910, 14800, 8539, 14697, 8234, 14590, 7790, 14479, 7409, 14367, 7067, 14178, 6621, 15337, 8619, 15337, 8631, 15333, 8677, 15325, 8769, 15305, 8871, 15264, 8940, 15202, 8909, 15119, 8775, 15022, 8565, 14916, 8328, 14804, 8009, 14688, 7614, 14569, 7287, 14448, 6888, 14321, 6483, 14088, 6171, 15350, 7402, 15350, 7419, 15347, 7480, 15340, 7613, 15322, 7804, 15287, 7973, 15229, 8057, 15148, 8012, 15046, 7846, 14933, 7611, 14810, 7357, 14682, 7069, 14552, 6656, 14421, 6316, 14251, 5948, 14007, 5528, 15356, 5942, 15356, 5977, 15353, 6119, 15348, 6294, 15332, 6551, 15302, 6824, 15249, 7044, 15171, 7122, 15070, 7050, 14949, 6861, 14818, 6611, 14679, 6349, 14538, 6067, 14398, 5651, 14189, 5311, 13935, 4958, 15359, 4123, 15359, 4153, 15356, 4296, 15353, 4646, 15338, 5160, 15311, 5508, 15263, 5829, 15188, 6042, 15088, 6094, 14966, 6001, 14826, 5796, 14678, 5543, 14527, 5287, 14377, 4985, 14133, 4586, 13869, 4257, 15360, 1563, 15360, 1642, 15358, 2076, 15354, 2636, 15341, 3350, 15317, 4019, 15273, 4429, 15203, 4732, 15105, 4911, 14981, 4932, 14836, 4818, 14679, 4621, 14517, 4386, 14359, 4156, 14083, 3795, 13808, 3437, 15360, 122, 15360, 137, 15358, 285, 15355, 636, 15344, 1274, 15322, 2177, 15281, 2765, 15215, 3223, 15120, 3451, 14995, 3569, 14846, 3567, 14681, 3466, 14511, 3305, 14344, 3121, 14037, 2800, 13753, 2467, 15360, 0, 15360, 1, 15359, 21, 15355, 89, 15346, 253, 15325, 479, 15287, 796, 15225, 1148, 15133, 1492, 15008, 1749, 14856, 1882, 14685, 1886, 14506, 1783, 14324, 1608, 13996, 1398, 13702, 1183]),
                nO = null;
            class nF {
                constructor(e = {}) {
                    let n, t, o, l, s, c, d, u, g, v, S, E, M, T, x, R, A, b, C, P, L, w, U, G;
                    const {
                        canvas: V = (0, i.lPF)(),
                        context: W = null,
                        depth: z = !0,
                        stencil: k = !1,
                        alpha: X = !1,
                        antialias: K = !1,
                        premultipliedAlpha: q = !0,
                        preserveDrawingBuffer: Y = !1,
                        powerPreference: j = "default",
                        failIfMajorPerformanceCaveat: Z = !1,
                        reversedDepthBuffer: Q = !1,
                        outputBufferType: $ = i.OUM
                    } = e;
                    if (this.isWebGLRenderer = !0, null !== W) {
                        if ("u" > typeof WebGLRenderingContext && W instanceof WebGLRenderingContext) throw Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");
                        n = W.getContextAttributes().alpha
                    } else n = X;
                    const J = new Set([i.c90, i.TkQ, i.ZQM]),
                        ee = new Set([i.OUM, i.bkx, i.cHt, i.V3x, i.Wew, i.gJ2]),
                        en = new Uint32Array(4),
                        et = new Int32Array(4),
                        ei = new i.Pq0;
                    let er = null,
                        ea = null;
                    const eo = [],
                        el = [];
                    let es = null;
                    this.domElement = V, this.debug = {
                        checkShaderErrors: !0,
                        diagnostics: {
                            keywords: !1
                        },
                        onShaderError: null
                    }, this.autoClear = !0, this.autoClearColor = !0, this.autoClearDepth = !0, this.autoClearStencil = !0, this.sortObjects = !0, this.clippingPlanes = [], this.localClippingEnabled = !1, this.toneMapping = i.y_p, this.toneMappingExposure = 1, this.transmissionResolutionScale = 1;
                    const ec = this;
                    let ed = !1,
                        eu = null,
                        ef = null,
                        ep = null,
                        em = null;
                    this._outputColorSpace = i.er$;
                    let eh = 0,
                        e_ = 0,
                        eg = null,
                        ev = -1,
                        eS = null;
                    const eE = new i.IUQ,
                        eM = new i.IUQ;
                    let eT = null;
                    const ex = new i.Q1f(0);
                    let eR = 0,
                        eA = V.width,
                        eb = V.height,
                        eC = 1,
                        eP = null,
                        eL = null;
                    const ew = new i.IUQ(0, 0, eA, eb),
                        eU = new i.IUQ(0, 0, eA, eb);
                    let eI = !1;
                    const eD = new i.PPD;
                    let eN = !1,
                        ey = !1;
                    const eO = new i.kn4,
                        eF = new i.Pq0,
                        eB = new i.IUQ,
                        eG = {
                            background: null,
                            fog: null,
                            environment: null,
                            overrideMaterial: null,
                            isScene: !0
                        };
                    let eH = !1;

                    function eV() {
                        return null === eg ? eC : 1
                    }
                    let eW = W;

                    function ez(e, n) {
                        return V.getContext(e, n)
                    }
                    try {
                        if ("setAttribute" in V && V.setAttribute("data-engine", `three.js r${i.sPf}`), V.addEventListener("webglcontextlost", eq, !1), V.addEventListener("webglcontextrestored", eY, !1), V.addEventListener("webglcontextcreationerror", ej, !1), null === eW) {
                            const e = "webgl2";
                            if (eW = ez(e, {
                                    alpha: !0,
                                    depth: z,
                                    stencil: k,
                                    antialias: K,
                                    premultipliedAlpha: q,
                                    preserveDrawingBuffer: Y,
                                    powerPreference: j,
                                    failIfMajorPerformanceCaveat: Z
                                }), null === eW)
                                if (ez(e)) throw Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.");
                                else throw Error("THREE.WebGLRenderer: Error creating WebGL context.")
                        }
                        eX()
                    } catch (e) {
                        throw V.removeEventListener("webglcontextlost", eq, !1), V.removeEventListener("webglcontextrestored", eY, !1), V.removeEventListener("webglcontextcreationerror", ej, !1), (0, i.z3S)("WebGLRenderer: " + e.message), e
                    }

                    function eX() {
                        (t = new D(eW)).init(), w = new nb(eW, t), o = new h(eW, t, e, w), l = new nR(eW, t), o.reversedDepthBuffer && Q && l.buffers.depth.setReversed(!0), ef = eW.createFramebuffer(), ep = eW.createFramebuffer(), em = eW.createFramebuffer(), s = new O(eW), c = new nl, d = new nA(eW, t, l, c, o, w, s), u = new I(ec), g = new a(eW), U = new p(eW, g), v = new N(eW, g, s, U), S = new B(eW, v, g, U, s), C = new F(eW, o, d), R = new _(c), E = new no(ec, u, t, o, U, R), M = new nD(ec, c), T = new nu, x = new ng(t), b = new f(ec, u, l, S, n, q), A = new nx(ec, S, o), G = new nN(eW, s, o, l), P = new m(eW, t, s), L = new y(eW, t, s), s.programs = E.programs, ec.capabilities = o, ec.extensions = t, ec.properties = c, ec.renderLists = T, ec.shadowMap = A, ec.state = l, ec.info = s
                    }
                    $ !== i.OUM && (es = new H($, V.width, V.height, K, z, k));
                    const eK = new nw(ec, eW);

                    function eq(e) {
                        e.preventDefault(), (0, i.Rm2)("WebGLRenderer: Context Lost."), ed = !0
                    }

                    function eY() {
                        (0, i.Rm2)("WebGLRenderer: Context Restored."), ed = !1;
                        let e = s.autoReset,
                            n = A.enabled,
                            t = A.autoUpdate,
                            r = A.needsUpdate,
                            a = A.type;
                        eX(), s.autoReset = e, A.enabled = n, A.autoUpdate = t, A.needsUpdate = r, A.type = a
                    }

                    function ej(e) {
                        (0, i.z3S)("WebGLRenderer: A WebGL context could not be created. Reason: ", e.statusMessage)
                    }

                    function eZ(e) {
                        var n, t;
                        let i, r = e.target;
                        r.removeEventListener("dispose", eZ), t = n = r, void 0 !== (i = c.get(t).programs) && (i.forEach(function(e) {
                            E.releaseProgram(e)
                        }), t.isShaderMaterial && E.releaseShaderCache(t)), c.remove(n)
                    }

                    function eQ(e, n, t, r) {
                        null !== eu && e.isNodeMaterial && eu.setObject(r, e), !0 === eN && R.setState(e, t, !1), !0 === e.transparent && e.side === i.$EB && !1 === e.forceSinglePass ? (e.side = i.hsX, e.needsUpdate = !0, e8(e, n, r), e.side = i.hB5, e.needsUpdate = !0, e8(e, n, r), e.side = i.$EB) : e8(e, n, r)
                    }
                    this.xr = eK, this.getContext = function() {
                        return eW
                    }, this.getContextAttributes = function() {
                        return eW.getContextAttributes()
                    }, this.forceContextLoss = function() {
                        let e = t.get("WEBGL_lose_context");
                        e && e.loseContext()
                    }, this.forceContextRestore = function() {
                        let e = t.get("WEBGL_lose_context");
                        e && e.restoreContext()
                    }, this.getPixelRatio = function() {
                        return eC
                    }, this.setPixelRatio = function(e) {
                        void 0 !== e && (eC = e, this.setSize(eA, eb, !1))
                    }, this.getSize = function(e) {
                        return e.set(eA, eb)
                    }, this.setSize = function(e, n, t = !0) {
                        eK.isPresenting ? (0, i.R8M)("WebGLRenderer: Can't change size while VR device is presenting.") : (eA = e, eb = n, V.width = Math.floor(e * eC), V.height = Math.floor(n * eC), !0 === t && (V.style.width = e + "px", V.style.height = n + "px"), null !== es && es.setSize(V.width, V.height), this.setViewport(0, 0, e, n))
                    }, this.getDrawingBufferSize = function(e) {
                        return e.set(eA * eC, eb * eC).floor()
                    }, this.setDrawingBufferSize = function(e, n, t) {
                        eA = e, eb = n, eC = t, V.width = Math.floor(e * t), V.height = Math.floor(n * t), this.setViewport(0, 0, e, n)
                    }, this.setEffects = function(e) {
                        if ($ === i.OUM) return void(0, i.z3S)("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");
                        if (e) {
                            for (let n = 0; n < e.length; n++)
                                if (!0 === e[n].isOutputPass) {
                                    (0, i.R8M)("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");
                                    break
                                }
                        }
                        es.setEffects(e || [])
                    }, this.getCurrentViewport = function(e) {
                        return e.copy(eE)
                    }, this.getViewport = function(e) {
                        return e.copy(ew)
                    }, this.setViewport = function(e, n, t, i) {
                        e.isVector4 ? ew.set(e.x, e.y, e.z, e.w) : ew.set(e, n, t, i), l.viewport(eE.copy(ew).multiplyScalar(eC).round())
                    }, this.getScissor = function(e) {
                        return e.copy(eU)
                    }, this.setScissor = function(e, n, t, i) {
                        e.isVector4 ? eU.set(e.x, e.y, e.z, e.w) : eU.set(e, n, t, i), l.scissor(eM.copy(eU).multiplyScalar(eC).round())
                    }, this.getScissorTest = function() {
                        return eI
                    }, this.setScissorTest = function(e) {
                        l.setScissorTest(eI = e)
                    }, this.setOpaqueSort = function(e) {
                        eP = e
                    }, this.setTransparentSort = function(e) {
                        eL = e
                    }, this.getClearColor = function(e) {
                        return e.copy(b.getClearColor())
                    }, this.setClearColor = function() {
                        b.setClearColor(...arguments)
                    }, this.getClearAlpha = function() {
                        return b.getClearAlpha()
                    }, this.setClearAlpha = function() {
                        b.setClearAlpha(...arguments)
                    }, this.clear = function(e = !0, n = !0, t = !0) {
                        let i = 0;
                        if (e) {
                            let e = !1;
                            if (null !== eg) {
                                let n = eg.texture.format;
                                e = J.has(n)
                            }
                            if (e) {
                                let e = eg.texture.type,
                                    n = ee.has(e),
                                    t = b.getClearColor(),
                                    i = b.getClearAlpha(),
                                    r = t.r,
                                    a = t.g,
                                    o = t.b;
                                n ? (en[0] = r, en[1] = a, en[2] = o, en[3] = i, eW.clearBufferuiv(eW.COLOR, 0, en)) : (et[0] = r, et[1] = a, et[2] = o, et[3] = i, eW.clearBufferiv(eW.COLOR, 0, et))
                            } else i |= eW.COLOR_BUFFER_BIT
                        }
                        n && (i |= eW.DEPTH_BUFFER_BIT, this.state.buffers.depth.setMask(!0)), t && (i |= eW.STENCIL_BUFFER_BIT, this.state.buffers.stencil.setMask(0xffffffff)), 0 !== i && eW.clear(i)
                    }, this.clearColor = function() {
                        this.clear(!0, !1, !1)
                    }, this.clearDepth = function() {
                        this.clear(!1, !0, !1)
                    }, this.clearStencil = function() {
                        this.clear(!1, !1, !0)
                    }, this.setNodesHandler = function(e) {
                        e.setRenderer(this), eu = e
                    }, this.dispose = function() {
                        V.removeEventListener("webglcontextlost", eq, !1), V.removeEventListener("webglcontextrestored", eY, !1), V.removeEventListener("webglcontextcreationerror", ej, !1), b.dispose(), T.dispose(), x.dispose(), c.dispose(), u.dispose(), S.dispose(), U.dispose(), G.dispose(), E.dispose(), eK.dispose(), eK.removeEventListener("sessionstart", eJ), eK.removeEventListener("sessionend", e0), e1.stop()
                    }, this.renderBufferDirect = function(e, n, r, a, s, f) {
                        let p;
                        null === n && (n = eG);
                        let m = s.isMesh && 0 > s.matrixWorld.determinantAffine(),
                            h = function(e, n, t, r, a) {
                                !0 !== n.isScene && (n = eG), d.resetTextureUnits();
                                let s = n.fog,
                                    f = r.isMeshStandardMaterial || r.isMeshLambertMaterial || r.isMeshPhongMaterial ? n.environment : null,
                                    p = null === eg ? ec.outputColorSpace : !0 === eg.isXRRenderTarget ? eg.texture.colorSpace : i.ppV.workingColorSpace,
                                    m = r.isMeshStandardMaterial || r.isMeshLambertMaterial && !r.envMap || r.isMeshPhongMaterial && !r.envMap,
                                    h = u.get(r.envMap || f, m),
                                    _ = !0 === r.vertexColors && !!t.attributes.color && 4 === t.attributes.color.itemSize,
                                    g = !!t.attributes.tangent && (!!r.normalMap || r.anisotropy > 0),
                                    v = !!t.morphAttributes.position,
                                    S = !!t.morphAttributes.normal,
                                    E = !!t.morphAttributes.color,
                                    T = i.y_p;
                                r.toneMapped && (null === eg || !0 === eg.isXRRenderTarget) && (T = ec.toneMapping);
                                let x = t.morphAttributes.position || t.morphAttributes.normal || t.morphAttributes.color,
                                    A = void 0 !== x ? x.length : 0,
                                    b = c.get(r),
                                    P = ea.state.lights;
                                if (!0 === eN && (!0 === ey || e !== eS)) {
                                    let n = e === eS && r.id === ev;
                                    R.setState(r, e, n)
                                }
                                let L = !1;
                                r.version === b.__version ? b.needsLights && b.lightsStateVersion !== P.state.version || b.outputColorSpace !== p || a.isBatchedMesh && !1 === b.batching ? L = !0 : a.isBatchedMesh || !0 !== b.batching ? a.isBatchedMesh && !0 === b.batchingColor && null === a._colorsTexture || a.isBatchedMesh && !1 === b.batchingColor && null !== a._colorsTexture || a.isInstancedMesh && !1 === b.instancing ? L = !0 : a.isInstancedMesh || !0 !== b.instancing ? a.isSkinnedMesh && !1 === b.skinning ? L = !0 : a.isSkinnedMesh || !0 !== b.skinning ? a.isInstancedMesh && !0 === b.instancingColor && null === a.instanceColor || a.isInstancedMesh && !1 === b.instancingColor && null !== a.instanceColor || a.isInstancedMesh && !0 === b.instancingMorph && null === a.morphTexture || a.isInstancedMesh && !1 === b.instancingMorph && null !== a.morphTexture || b.envMap !== h || !0 === r.fog && b.fog !== s || void 0 !== b.numClippingPlanes && (b.numClippingPlanes !== R.numPlanes || b.numIntersection !== R.numIntersection) || b.vertexAlphas !== _ || b.vertexTangents !== g || b.morphTargets !== v || b.morphNormals !== S || b.morphColors !== E || b.toneMapping !== T || b.morphTargetsCount !== A ? L = !0 : !!b.lightProbeGrid != ea.state.lightProbeGridArray.length > 0 && (L = !0) : L = !0 : L = !0 : L = !0 : (L = !0, b.__version = r.version);
                                let w = b.currentProgram;
                                !0 === L && (w = e8(r, n, a), eu && r.isNodeMaterial && eu.onUpdateProgram(r, w, b));
                                let U = !1,
                                    I = !1,
                                    D = !1,
                                    N = w.getUniforms(),
                                    y = b.uniforms;
                                if (l.useProgram(w.program) && (U = !0, I = !0, D = !0), r.id !== ev && (ev = r.id, I = !0), b.needsLights) {
                                    let e = function(e, n) {
                                        if (0 === e.length) return null;
                                        if (1 === e.length) return null !== e[0].texture ? e[0] : null;
                                        ei.setFromMatrixPosition(n.matrixWorld);
                                        for (let n = 0, t = e.length; n < t; n++) {
                                            let t = e[n];
                                            if (null !== t.texture && t.boundingBox.containsPoint(ei)) return t
                                        }
                                        return null
                                    }(ea.state.lightProbeGridArray, a);
                                    b.lightProbeGrid !== e && (b.lightProbeGrid = e, I = !0)
                                }
                                if (U || eS !== e) {
                                    l.buffers.depth.getReversed() && !0 !== e.reversedDepth && (e._reversedDepth = !0, e.updateProjectionMatrix()), N.setValue(eW, "projectionMatrix", e.projectionMatrix), N.setValue(eW, "viewMatrix", e.matrixWorldInverse);
                                    let n = N.map.cameraPosition;
                                    void 0 !== n && n.setValue(eW, eF.setFromMatrixPosition(e.matrixWorld)), o.logarithmicDepthBuffer && N.setValue(eW, "logDepthBufFC", 2 / (Math.log(e.far + 1) / Math.LN2)), (r.isMeshPhongMaterial || r.isMeshToonMaterial || r.isMeshLambertMaterial || r.isMeshBasicMaterial || r.isMeshStandardMaterial || r.isShaderMaterial) && N.setValue(eW, "isOrthographic", !0 === e.isOrthographicCamera), eS !== e && (eS = e, I = !0, D = !0)
                                }
                                if (b.needsLights && (P.state.sunShadowMap.length > 0 && N.setValue(eW, "sunShadowMap", P.state.sunShadowMap, d), P.state.directionalShadowMap.length > 0 && N.setValue(eW, "directionalShadowMap", P.state.directionalShadowMap, d), P.state.spotShadowMap.length > 0 && N.setValue(eW, "spotShadowMap", P.state.spotShadowMap, d), P.state.pointShadowMap.length > 0 && N.setValue(eW, "pointShadowMap", P.state.pointShadowMap, d)), a.isSkinnedMesh) {
                                    N.setOptional(eW, a, "bindMatrix"), N.setOptional(eW, a, "bindMatrixInverse");
                                    let e = a.skeleton;
                                    e && (null === e.boneTexture && e.computeBoneTexture(), N.setValue(eW, "boneTexture", e.boneTexture, d))
                                }
                                a.isBatchedMesh && (N.setOptional(eW, a, "batchingTexture"), N.setValue(eW, "batchingTexture", a._matricesTexture, d), N.setOptional(eW, a, "batchingIdTexture"), N.setValue(eW, "batchingIdTexture", a._indirectTexture, d), N.setOptional(eW, a, "batchingColorTexture"), null !== a._colorsTexture && N.setValue(eW, "batchingColorTexture", a._colorsTexture, d));
                                let O = t.morphAttributes;
                                if ((void 0 !== O.position || void 0 !== O.normal || void 0 !== O.color) && C.update(a, t, w), (I || b.receiveShadow !== a.receiveShadow) && (b.receiveShadow = a.receiveShadow, N.setValue(eW, "receiveShadow", a.receiveShadow)), (r.isMeshStandardMaterial || r.isMeshLambertMaterial || r.isMeshPhongMaterial) && null === r.envMap && null !== n.environment && (y.envMapIntensity.value = n.environmentIntensity), void 0 !== y.dfgLUT && (y.dfgLUT.value = (null === nO && ((nO = new i.GYF(ny, 16, 16, i.paN, i.ix0)).name = "DFG_LUT", nO.minFilter = i.k6q, nO.magFilter = i.k6q, nO.wrapS = i.ghU, nO.wrapT = i.ghU, nO.generateMipmaps = !1, nO.needsUpdate = !0), nO)), I) {
                                    var F, B;
                                    if (N.setValue(eW, "toneMappingExposure", ec.toneMappingExposure), b.needsLights && (F = y, B = D, F.ambientLightColor.needsUpdate = B, F.lightProbe.needsUpdate = B, F.sunLights.needsUpdate = B, F.sunLightShadows.needsUpdate = B, F.directionalLights.needsUpdate = B, F.directionalLightShadows.needsUpdate = B, F.pointLights.needsUpdate = B, F.pointLightShadows.needsUpdate = B, F.spotLights.needsUpdate = B, F.spotLightShadows.needsUpdate = B, F.rectAreaLights.needsUpdate = B, F.hemisphereLights.needsUpdate = B), s && !0 === r.fog && M.refreshFogUniforms(y, s), M.refreshMaterialUniforms(y, r, eC, eb, ea.state.transmissionRenderTarget[e.id]), b.needsLights && b.lightProbeGrid) {
                                        let e = b.lightProbeGrid;
                                        y.probesSH.value = e.texture, y.probesMin.value.copy(e.boundingBox.min), y.probesMax.value.copy(e.boundingBox.max), y.probesResolution.value.copy(e.resolution)
                                    }
                                    ek.upload(eW, e9(b), y, d)
                                }
                                if (r.isShaderMaterial && !0 === r.uniformsNeedUpdate && (ek.upload(eW, e9(b), y, d), r.uniformsNeedUpdate = !1), r.isSpriteMaterial && N.setValue(eW, "center", a.center), N.setValue(eW, "modelViewMatrix", a.modelViewMatrix), N.setValue(eW, "normalMatrix", a.normalMatrix), N.setValue(eW, "modelMatrix", a.matrixWorld), void 0 !== r.uniformsGroups) {
                                    let e = r.uniformsGroups;
                                    for (let n = 0, t = e.length; n < t; n++) {
                                        let t = e[n];
                                        G.update(t, w), G.bind(t, w)
                                    }
                                }
                                return w
                            }(e, n, r, a, s);
                        l.setMaterial(a, m);
                        let _ = r.index,
                            S = 1;
                        if (!0 === a.wireframe) {
                            if (void 0 === (_ = v.getWireframeAttribute(r))) return;
                            S = 2
                        }
                        let E = r.drawRange,
                            T = r.attributes.position,
                            x = E.start * S,
                            A = (E.start + E.count) * S;
                        null !== f && (x = Math.max(x, f.start * S), A = Math.min(A, (f.start + f.count) * S)), null !== _ ? (x = Math.max(x, 0), A = Math.min(A, _.count)) : null != T && (x = Math.max(x, 0), A = Math.min(A, T.count));
                        let b = A - x;
                        if (b < 0 || b === 1 / 0) return;
                        U.setup(s, a, h, r, _);
                        let w = P;
                        if (null !== _ && (p = g.get(_), (w = L).setIndex(p)), s.isMesh) !0 === a.wireframe ? (l.setLineWidth(a.wireframeLinewidth * eV()), w.setMode(eW.LINES)) : w.setMode(eW.TRIANGLES);
                        else if (s.isLine) {
                            let e = a.linewidth;
                            void 0 === e && (e = 1), l.setLineWidth(e * eV()), s.isLineSegments ? w.setMode(eW.LINES) : s.isLineLoop ? w.setMode(eW.LINE_LOOP) : w.setMode(eW.LINE_STRIP)
                        } else s.isPoints ? w.setMode(eW.POINTS) : s.isSprite && w.setMode(eW.TRIANGLES);
                        if (s.isBatchedMesh)
                            if (t.get("WEBGL_multi_draw")) w.renderMultiDraw(s._multiDrawStarts, s._multiDrawCounts, s._multiDrawCount);
                            else {
                                let e = s._multiDrawStarts,
                                    n = s._multiDrawCounts,
                                    t = s._multiDrawCount,
                                    i = _ ? g.get(_).bytesPerElement : 1,
                                    r = c.get(a).currentProgram.getUniforms();
                                for (let a = 0; a < t; a++) r.setValue(eW, "_gl_DrawID", a), w.render(e[a] / i, n[a])
                            }
                        else if (s.isInstancedMesh) w.renderInstances(x, b, s.count);
                        else if (r.isInstancedBufferGeometry) {
                            let e = void 0 !== r._maxInstanceCount ? r._maxInstanceCount : 1 / 0,
                                n = Math.min(r.instanceCount, e);
                            w.renderInstances(x, b, n)
                        } else w.render(x, b)
                    }, this.compile = function(e, n, t = null) {
                        null === t && (t = e), null !== eu && eu.renderStart(e, n, t), (ea = x.get(t)).init(n), el.push(ea), t.traverseVisible(function(e) {
                            e.isLight && e.layers.test(n.layers) && (ea.pushLight(e), e.castShadow && ea.pushShadow(e))
                        }), e !== t && e.traverseVisible(function(e) {
                            e.isLight && e.layers.test(n.layers) && (ea.pushLight(e), e.castShadow && ea.pushShadow(e))
                        }), ea.setupLights(), null !== eu && eu.updateLights(ea.state.lightsArray), ey = this.localClippingEnabled, !0 === (eN = R.init(this.clippingPlanes, ey)) && R.setGlobalState(this.clippingPlanes, n), null !== eu && A.render(ea.state.shadowsArray, t, n);
                        let i = new Set;
                        return e.traverse(function(e) {
                            if (!(e.isMesh || e.isPoints || e.isLine || e.isSprite)) return;
                            let r = e.material;
                            if (r)
                                if (Array.isArray(r))
                                    for (let a = 0; a < r.length; a++) {
                                        let o = r[a];
                                        eQ(o, t, n, e), i.add(o)
                                    } else eQ(r, t, n, e), i.add(r)
                        }), ea = el.pop(), null !== eu && eu.renderEnd(), i
                    }, this.compileAsync = function(e, n, i = null) {
                        let r = this.compile(e, n, i);
                        return new Promise(n => {
                            function i() {
                                (r.forEach(function(e) {
                                    let n = c.get(e).currentProgram;
                                    (void 0 === n || n.isReady()) && r.delete(e)
                                }), 0 === r.size) ? n(e): setTimeout(i, 10)
                            }
                            null !== t.get("KHR_parallel_shader_compile") ? i() : setTimeout(i, 10)
                        })
                    };
                    let e$ = null;

                    function eJ() {
                        e1.stop()
                    }

                    function e0() {
                        e1.start()
                    }
                    const e1 = new r;

                    function e3(e, n, t, i) {
                        if (!1 === e.visible) return;
                        if (e.layers.test(n.layers)) {
                            if (e.isGroup) t = e.renderOrder;
                            else if (e.isLOD) !0 === e.autoUpdate && e.update(n);
                            else if (e.isLightProbeGrid) ea.pushLightProbeGrid(e);
                            else if (e.isLight) ea.pushLight(e), e.castShadow && ea.pushShadow(e);
                            else if (e.isSprite) {
                                if (!e.frustumCulled || e.intersectsFrustum(eD)) {
                                    i && eB.setFromMatrixPosition(e.matrixWorld).applyMatrix4(eO);
                                    let r = S.update(e),
                                        a = e.material;
                                    a.visible && er.push(e, r, a, t, eB.z, null, n)
                                }
                            } else if ((e.isMesh || e.isLine || e.isPoints) && (!e.frustumCulled || e.intersectsFrustum(eD))) {
                                let r = S.update(e),
                                    a = e.material;
                                if (i && (void 0 !== e.boundingSphere ? (null === e.boundingSphere && e.computeBoundingSphere(), eB.copy(e.boundingSphere.center)) : (null === r.boundingSphere && r.computeBoundingSphere(), eB.copy(r.boundingSphere.center)), eB.applyMatrix4(e.matrixWorld).applyMatrix4(eO)), Array.isArray(a)) {
                                    let i = r.groups;
                                    for (let o = 0, l = i.length; o < l; o++) {
                                        let l = i[o],
                                            s = a[l.materialIndex];
                                        s && s.visible && er.push(e, r, s, t, eB.z, l, n)
                                    }
                                } else a.visible && er.push(e, r, a, t, eB.z, null, n)
                            }
                        }
                        let r = e.children;
                        for (let e = 0, a = r.length; e < a; e++) e3(r[e], n, t, i)
                    }

                    function e2(e, n, t, i) {
                        let {
                            opaque: r,
                            transmissive: a,
                            transparent: o
                        } = e;
                        ea.setupLightsView(t), !0 === eN && R.setGlobalState(ec.clippingPlanes, t), i && l.viewport(eE.copy(i)), r.length > 0 && e5(r, n, t), a.length > 0 && e5(a, n, t), o.length > 0 && e5(o, n, t), l.buffers.depth.setTest(!0), l.buffers.depth.setMask(!0), l.buffers.color.setMask(!0), l.setPolygonOffset(!1)
                    }

                    function e4(e, n, r, a) {
                        if (null !== (!0 === r.isScene ? r.overrideMaterial : null)) return;
                        if (void 0 === ea.state.transmissionRenderTarget[a.id]) {
                            let e = t.has("EXT_color_buffer_half_float") || t.has("EXT_color_buffer_float");
                            ea.state.transmissionRenderTarget[a.id] = new i.nWS(1, 1, {
                                generateMipmaps: !0,
                                type: e ? i.ix0 : i.OUM,
                                minFilter: i.$_I,
                                samples: Math.max(4, o.samples),
                                stencilBuffer: k,
                                resolveDepthBuffer: !1,
                                resolveStencilBuffer: !1,
                                storeMultisampledDepthBuffer: !1,
                                storeMultisampledStencilBuffer: !1,
                                colorSpace: i.ppV.workingColorSpace
                            })
                        }
                        let l = ea.state.transmissionRenderTarget[a.id],
                            s = a.viewport || eE;
                        l.setSize(s.z * ec.transmissionResolutionScale, s.w * ec.transmissionResolutionScale);
                        let c = ec.getRenderTarget(),
                            u = ec.getActiveCubeFace(),
                            f = ec.getActiveMipmapLevel();
                        ec.setRenderTarget(l), ec.getClearColor(ex), (eR = ec.getClearAlpha()) < 1 && ec.setClearColor(0xffffff, .5), ec.clear(), eH && b.render(r);
                        let p = ec.toneMapping;
                        ec.toneMapping = i.y_p;
                        let m = a.viewport;
                        if (void 0 !== a.viewport && (a.viewport = void 0), ea.setupLightsView(a), !0 === eN && R.setGlobalState(ec.clippingPlanes, a), e5(e, r, a), d.updateMultisampleRenderTarget(l), d.updateRenderTargetMipmap(l), !1 === t.has("WEBGL_multisampled_render_to_texture")) {
                            let e = !1;
                            for (let t = 0, o = n.length; t < o; t++) {
                                let {
                                    object: o,
                                    geometry: l,
                                    material: s,
                                    group: c
                                } = n[t];
                                if (s.side === i.$EB && o.layers.test(a.layers)) {
                                    let n = s.side;
                                    s.side = i.hsX, s.needsUpdate = !0, e6(o, r, a, l, s, c), s.side = n, s.needsUpdate = !0, e = !0
                                }
                            }!0 === e && (d.updateMultisampleRenderTarget(l), d.updateRenderTargetMipmap(l))
                        }
                        ec.setRenderTarget(c, u, f), ec.setClearColor(ex, eR), void 0 !== m && (a.viewport = m), ec.toneMapping = p
                    }

                    function e5(e, n, t) {
                        let i = !0 === n.isScene ? n.overrideMaterial : null;
                        for (let r = 0, a = e.length; r < a; r++) {
                            let a = e[r],
                                {
                                    object: o,
                                    geometry: l,
                                    group: s
                                } = a,
                                c = a.material;
                            !0 === c.allowOverride && null !== i && (c = i), o.layers.test(t.layers) && e6(o, n, t, l, c, s)
                        }
                    }

                    function e6(e, n, t, r, a, o) {
                        null !== eu && a.isNodeMaterial && eu.setObject(e, a), e.onBeforeRender(ec, n, t, r, a, o), e.modelViewMatrix.multiplyMatrices(t.matrixWorldInverse, e.matrixWorld), e.normalMatrix.getNormalMatrix(e.modelViewMatrix), a.onBeforeRender(ec, n, t, r, e, o), !0 === a.transparent && a.side === i.$EB && !1 === a.forceSinglePass ? (a.side = i.hsX, a.needsUpdate = !0, ec.renderBufferDirect(t, n, r, a, e, o), a.side = i.hB5, a.needsUpdate = !0, ec.renderBufferDirect(t, n, r, a, e, o), a.side = i.$EB) : ec.renderBufferDirect(t, n, r, a, e, o), e.onAfterRender(ec, n, t, r, a, o)
                    }

                    function e8(e, n, t) {
                        var i;
                        !0 !== n.isScene && (n = eG);
                        let r = c.get(e),
                            a = ea.state.lights,
                            o = ea.state.shadowsArray,
                            l = a.state.version,
                            s = E.getParameters(e, a.state, o, n, t, ea.state.lightProbeGridArray),
                            d = E.getProgramCacheKey(s),
                            f = r.programs;
                        r.environment = e.isMeshStandardMaterial || e.isMeshLambertMaterial || e.isMeshPhongMaterial ? n.environment : null, r.fog = n.fog;
                        let p = e.isMeshStandardMaterial || e.isMeshLambertMaterial && !e.envMap || e.isMeshPhongMaterial && !e.envMap;
                        r.envMap = u.get(e.envMap || r.environment, p), r.envMapRotation = null !== r.environment && null === e.envMap ? n.environmentRotation : e.envMapRotation, void 0 === f && (e.addEventListener("dispose", eZ), r.programs = f = new Map);
                        let m = f.get(d);
                        if (void 0 !== m) {
                            if (r.currentProgram === m && r.lightsStateVersion === l) return e7(e, s), m
                        } else s.uniforms = E.getUniforms(e), null !== eu && e.isNodeMaterial && eu.build(e, t, s), e.onBeforeCompile(s, ec), m = E.acquireProgram(s, d), f.set(d, m), r.uniforms = s.uniforms;
                        let h = r.uniforms;
                        return (e.isShaderMaterial || e.isRawShaderMaterial) && !0 !== e.clipping || (h.clippingPlanes = R.uniform), e7(e, s), r.needsLights = (i = e).isMeshLambertMaterial || i.isMeshToonMaterial || i.isMeshPhongMaterial || i.isMeshStandardMaterial || i.isShadowMaterial || i.isShaderMaterial && !0 === i.lights, r.lightsStateVersion = l, r.needsLights && (h.ambientLightColor.value = a.state.ambient, h.lightProbe.value = a.state.probe, h.sunLights.value = a.state.sun, h.sunLightShadows.value = a.state.sunShadow, h.directionalLights.value = a.state.directional, h.directionalLightShadows.value = a.state.directionalShadow, h.spotLights.value = a.state.spot, h.spotLightShadows.value = a.state.spotShadow, h.rectAreaLights.value = a.state.rectArea, h.ltc_1.value = a.state.rectAreaLTC1, h.ltc_2.value = a.state.rectAreaLTC2, h.pointLights.value = a.state.point, h.pointLightShadows.value = a.state.pointShadow, h.hemisphereLights.value = a.state.hemi, h.sunShadowMatrix.value = a.state.sunShadowMatrix, h.sunShadowCascade.value = a.state.sunShadowCascade, h.directionalShadowMatrix.value = a.state.directionalShadowMatrix, h.spotLightMatrix.value = a.state.spotLightMatrix, h.spotLightMap.value = a.state.spotLightMap, h.pointShadowMatrix.value = a.state.pointShadowMatrix), r.lightProbeGrid = ea.state.lightProbeGridArray.length > 0, r.currentProgram = m, r.uniformsList = null, m
                    }

                    function e9(e) {
                        if (null === e.uniformsList) {
                            let n = e.currentProgram.getUniforms();
                            e.uniformsList = ek.seqWithValue(n.seq, e.uniforms)
                        }
                        return e.uniformsList
                    }

                    function e7(e, n) {
                        let t = c.get(e);
                        t.outputColorSpace = n.outputColorSpace, t.batching = n.batching, t.batchingColor = n.batchingColor, t.instancing = n.instancing, t.instancingColor = n.instancingColor, t.instancingMorph = n.instancingMorph, t.skinning = n.skinning, t.morphTargets = n.morphTargets, t.morphNormals = n.morphNormals, t.morphColors = n.morphColors, t.morphTargetsCount = n.morphTargetsCount, t.numClippingPlanes = n.numClippingPlanes, t.numIntersection = n.numClipIntersection, t.vertexAlphas = n.vertexAlphas, t.vertexTangents = n.vertexTangents, t.toneMapping = n.toneMapping
                    }

                    function ne(e) {
                        let n = c.get(e);
                        return (n.__readFormat !== e.format || n.__readType !== e.type) && (n.__readFormat = e.format, n.__readType = e.type, n.__formatReadable = o.textureFormatReadable(e.format), n.__typeReadable = o.textureTypeReadable(e.type)), n
                    }
                    e1.setAnimationLoop(function(e) {
                        e$ && e$(e)
                    }), "u" > typeof self && e1.setContext(self), this.setAnimationLoop = function(e) {
                        e$ = e, eK.setAnimationLoop(e), null === e ? e1.stop() : e1.start()
                    }, eK.addEventListener("sessionstart", eJ), eK.addEventListener("sessionend", e0), this.render = function(e, n) {
                        if (void 0 !== n && !0 !== n.isCamera) return void(0, i.z3S)("WebGLRenderer.render: camera is not an instance of THREE.Camera.");
                        if (!0 === ed) return;
                        null !== eu && eu.renderStart(e, n);
                        let t = !0 === eK.enabled && !0 === eK.isPresenting,
                            r = null !== es && (null === eg || t) && es.begin(ec, eg);
                        if (!0 === e.matrixWorldAutoUpdate && e.updateMatrixWorld(), null === n.parent && !0 === n.matrixWorldAutoUpdate && n.updateMatrixWorld(), !0 === eK.enabled && !0 === eK.isPresenting && (null === es || !1 === es.isCompositing()) && (!0 === eK.cameraAutoUpdate && eK.updateCamera(n), n = eK.getCamera()), !0 === e.isScene && e.onBeforeRender(ec, e, n, eg), (ea = x.get(e, el.length)).init(n), ea.state.textureUnits = d.getTextureUnits(), el.push(ea), eO.multiplyMatrices(n.projectionMatrix, n.matrixWorldInverse), eD.setFromProjectionMatrix(eO, i.TdN, n.reversedDepth), ey = this.localClippingEnabled, eN = R.init(this.clippingPlanes, ey), (er = T.get(e, eo.length)).init(), eo.push(er), !0 === eK.enabled && !0 === eK.isPresenting) {
                            let e = ec.xr.getDepthSensingMesh();
                            null !== e && e3(e, n, -1 / 0, ec.sortObjects)
                        }
                        e3(e, n, 0, ec.sortObjects), er.finish(), null !== eu && eu.updateLights(ea.state.lightsArray), !0 === ec.sortObjects && er.sort(eP, eL), (eH = !1 === eK.enabled || !1 === eK.isPresenting || !1 === eK.hasDepthSensing()) && b.addToRenderList(er, e), this.info.render.frame++, !0 === this.info.autoReset && this.info.reset(), !0 === eN && R.beginShadows();
                        let a = ea.state.shadowsArray;
                        if (A.render(a, e, n), !0 === eN && R.endShadows(), !1 === (r && es.hasRenderPass())) {
                            let t = er.opaque,
                                i = er.transmissive;
                            if (ea.setupLights(), n.isArrayCamera) {
                                let r = n.cameras;
                                if (i.length > 0)
                                    for (let n = 0, a = r.length; n < a; n++) e4(t, i, e, r[n]);
                                eH && b.render(e);
                                for (let n = 0, t = r.length; n < t; n++) {
                                    let t = r[n];
                                    e2(er, e, t, t.viewport)
                                }
                            } else i.length > 0 && e4(t, i, e, n), eH && b.render(e), e2(er, e, n)
                        }
                        null !== eg && 0 === e_ && (d.updateMultisampleRenderTarget(eg), d.updateRenderTargetMipmap(eg)), r && es.end(ec), !0 === e.isScene && e.onAfterRender(ec, e, n), U.resetDefaultState(), ev = -1, eS = null, el.pop(), el.length > 0 ? (ea = el[el.length - 1], d.setTextureUnits(ea.state.textureUnits), !0 === eN && R.setGlobalState(ec.clippingPlanes, ea.state.camera)) : ea = null, eo.pop(), er = eo.length > 0 ? eo[eo.length - 1] : null, null !== eu && eu.renderEnd()
                    }, this.getActiveCubeFace = function() {
                        return eh
                    }, this.getActiveMipmapLevel = function() {
                        return e_
                    }, this.getRenderTarget = function() {
                        return eg
                    }, this.setRenderTargetTextures = function(e, n, t) {
                        let i = c.get(e);
                        i.__autoAllocateDepthBuffer = !1 === e.resolveDepthBuffer, !1 === i.__autoAllocateDepthBuffer && (i.__useRenderToTexture = !1), c.get(e.texture).__webglTexture = n, c.get(e.depthTexture).__webglTexture = i.__autoAllocateDepthBuffer ? void 0 : t, i.__hasExternalTextures = !0
                    }, this.setRenderTargetFramebuffer = function(e, n) {
                        let t = c.get(e);
                        t.__webglFramebuffer = n, t.__useDefaultFramebuffer = void 0 === n
                    }, this.setRenderTarget = function(e, n = 0, t = 0) {
                        eg = e, eh = n, e_ = t;
                        let i = null,
                            r = !1,
                            a = !1;
                        if (e) {
                            let o = c.get(e);
                            if (void 0 !== o.__useDefaultFramebuffer) {
                                l.bindFramebuffer(eW.FRAMEBUFFER, o.__webglFramebuffer), eE.copy(e.viewport), eM.copy(e.scissor), eT = e.scissorTest, l.viewport(eE), l.scissor(eM), l.setScissorTest(eT), ev = -1;
                                return
                            }
                            if (void 0 === o.__webglFramebuffer) d.setupRenderTarget(e);
                            else if (o.__hasExternalTextures) d.rebindTextures(e, c.get(e.texture).__webglTexture, c.get(e.depthTexture).__webglTexture);
                            else if (e.depthBuffer) {
                                let n = e.depthTexture;
                                if (o.__boundDepthTexture !== n) {
                                    if (null !== n && c.has(n) && (e.width !== n.image.width || e.height !== n.image.height)) throw Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");
                                    d.setupDepthRenderbuffer(e)
                                }
                            }
                            let s = e.texture;
                            (s.isData3DTexture || s.isDataArrayTexture || s.isCompressedArrayTexture) && (a = !0);
                            let u = c.get(e).__webglFramebuffer;
                            e.isWebGLCubeRenderTarget ? (i = Array.isArray(u[n]) ? u[n][t] : u[n], r = !0) : i = e.samples > 0 && !1 === d.useMultisampledRTT(e) ? c.get(e).__webglMultisampledFramebuffer : Array.isArray(u) ? u[t] : u, eE.copy(e.viewport), eM.copy(e.scissor), eT = e.scissorTest
                        } else eE.copy(ew).multiplyScalar(eC).floor(), eM.copy(eU).multiplyScalar(eC).floor(), eT = eI;
                        if (0 !== t && (i = ef), l.bindFramebuffer(eW.FRAMEBUFFER, i) && l.drawBuffers(e, i), l.viewport(eE), l.scissor(eM), l.setScissorTest(eT), r) {
                            let i = c.get(e.texture);
                            eW.framebufferTexture2D(eW.FRAMEBUFFER, eW.COLOR_ATTACHMENT0, eW.TEXTURE_CUBE_MAP_POSITIVE_X + n, i.__webglTexture, t)
                        } else if (a)
                            for (let i = 0; i < e.textures.length; i++) {
                                let r = c.get(e.textures[i]);
                                eW.framebufferTextureLayer(eW.FRAMEBUFFER, eW.COLOR_ATTACHMENT0 + i, r.__webglTexture, t, n)
                            } else if (null !== e && 0 !== t) {
                                let n = c.get(e.texture);
                                eW.framebufferTexture2D(eW.FRAMEBUFFER, eW.COLOR_ATTACHMENT0, eW.TEXTURE_2D, n.__webglTexture, t)
                            }
                        ev = -1
                    }, this.readRenderTargetPixels = function(e, n, t, r, a, o, s, d = 0) {
                        if (!(e && e.isWebGLRenderTarget)) return void(0, i.z3S)("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");
                        let u = c.get(e).__webglFramebuffer;
                        if (e.isWebGLCubeRenderTarget && void 0 !== s && (u = u[s]), u) {
                            l.bindFramebuffer(eW.FRAMEBUFFER, u);
                            try {
                                let l = e.textures[d],
                                    s = l.format,
                                    c = l.type;
                                e.textures.length > 1 && eW.readBuffer(eW.COLOR_ATTACHMENT0 + d);
                                let u = ne(l);
                                if (!1 === u.__formatReadable) return void(0, i.z3S)("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");
                                if (!1 === u.__typeReadable) return void(0, i.z3S)("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");
                                n >= 0 && n <= e.width - r && t >= 0 && t <= e.height - a && eW.readPixels(n, t, r, a, w.convert(s), w.convert(c), o)
                            } finally {
                                let e = null !== eg ? c.get(eg).__webglFramebuffer : null;
                                l.bindFramebuffer(eW.FRAMEBUFFER, e)
                            }
                        }
                    }, this.readRenderTargetPixelsAsync = async function(e, n, t, r, a, o, s, d = 0) {
                        if (!(e && e.isWebGLRenderTarget)) throw Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");
                        let u = c.get(e).__webglFramebuffer;
                        if (e.isWebGLCubeRenderTarget && void 0 !== s && (u = u[s]), u)
                            if (n >= 0 && n <= e.width - r && t >= 0 && t <= e.height - a) {
                                l.bindFramebuffer(eW.FRAMEBUFFER, u);
                                let s = e.textures[d],
                                    f = s.format,
                                    p = s.type;
                                e.textures.length > 1 && eW.readBuffer(eW.COLOR_ATTACHMENT0 + d);
                                let m = ne(s);
                                if (!1 === m.__formatReadable) throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");
                                if (!1 === m.__typeReadable) throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");
                                let h = eW.createBuffer();
                                eW.bindBuffer(eW.PIXEL_PACK_BUFFER, h), eW.bufferData(eW.PIXEL_PACK_BUFFER, o.byteLength, eW.STREAM_READ), eW.readPixels(n, t, r, a, w.convert(f), w.convert(p), 0), eW.bindBuffer(eW.PIXEL_PACK_BUFFER, null);
                                let _ = null !== eg ? c.get(eg).__webglFramebuffer : null;
                                l.bindFramebuffer(eW.FRAMEBUFFER, _);
                                let g = eW.fenceSync(eW.SYNC_GPU_COMMANDS_COMPLETE, 0);
                                return eW.flush(), await (0, i.jej)(eW, g, 4), eW.bindBuffer(eW.PIXEL_PACK_BUFFER, h), eW.getBufferSubData(eW.PIXEL_PACK_BUFFER, 0, o), eW.bindBuffer(eW.PIXEL_PACK_BUFFER, null), eW.deleteBuffer(h), eW.deleteSync(g), o
                            } else throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")
                    }, this.copyFramebufferToTexture = function(e, n = null, t = 0) {
                        let i = Math.pow(2, -t),
                            r = Math.floor(e.image.width * i),
                            a = Math.floor(e.image.height * i),
                            o = null !== n ? n.x : 0,
                            s = null !== n ? n.y : 0;
                        d.setTexture2D(e, 0), eW.copyTexSubImage2D(eW.TEXTURE_2D, t, 0, 0, o, s, r, a), l.unbindTexture()
                    }, this.copyTextureToTexture = function(e, n, t = null, i = null, r = 0, a = 0) {
                        let o, s, u, f, p, m, h, _, g, v, S = e.isCompressedTexture ? e.mipmaps[a] : e.image;
                        if (null !== t) o = t.max.x - t.min.x, s = t.max.y - t.min.y, u = t.isBox3 ? t.max.z - t.min.z : 1, f = t.min.x, p = t.min.y, m = t.isBox3 ? t.min.z : 0;
                        else {
                            let n = Math.pow(2, -r);
                            o = Math.floor(S.width * n), s = Math.floor(S.height * n), u = e.isDataArrayTexture ? S.depth : e.isData3DTexture ? Math.floor(S.depth * n) : 1, f = 0, p = 0, m = 0
                        }
                        null !== i ? (h = i.x, _ = i.y, g = i.z) : (h = 0, _ = 0, g = 0);
                        let E = w.convert(n.format),
                            M = w.convert(n.type);
                        n.isData3DTexture ? (d.setTexture3D(n, 0), v = eW.TEXTURE_3D) : n.isDataArrayTexture || n.isCompressedArrayTexture ? (d.setTexture2DArray(n, 0), v = eW.TEXTURE_2D_ARRAY) : (d.setTexture2D(n, 0), v = eW.TEXTURE_2D), l.activeTexture(eW.TEXTURE0), l.pixelStorei(eW.UNPACK_FLIP_Y_WEBGL, n.flipY), l.pixelStorei(eW.UNPACK_PREMULTIPLY_ALPHA_WEBGL, n.premultiplyAlpha), l.pixelStorei(eW.UNPACK_ALIGNMENT, n.unpackAlignment);
                        let T = l.getParameter(eW.UNPACK_ROW_LENGTH),
                            x = l.getParameter(eW.UNPACK_IMAGE_HEIGHT),
                            R = l.getParameter(eW.UNPACK_SKIP_PIXELS),
                            A = l.getParameter(eW.UNPACK_SKIP_ROWS),
                            b = l.getParameter(eW.UNPACK_SKIP_IMAGES);
                        l.pixelStorei(eW.UNPACK_ROW_LENGTH, S.width), l.pixelStorei(eW.UNPACK_IMAGE_HEIGHT, S.height), l.pixelStorei(eW.UNPACK_SKIP_PIXELS, f), l.pixelStorei(eW.UNPACK_SKIP_ROWS, p), l.pixelStorei(eW.UNPACK_SKIP_IMAGES, m);
                        let C = e.isDataArrayTexture || e.isData3DTexture,
                            P = n.isDataArrayTexture || n.isData3DTexture;
                        if (e.isDepthTexture) {
                            let t = c.get(e),
                                i = c.get(n),
                                d = c.get(t.__renderTarget),
                                v = c.get(i.__renderTarget);
                            l.bindFramebuffer(eW.READ_FRAMEBUFFER, d.__webglFramebuffer), l.bindFramebuffer(eW.DRAW_FRAMEBUFFER, v.__webglFramebuffer);
                            for (let t = 0; t < u; t++) C && (eW.framebufferTextureLayer(eW.READ_FRAMEBUFFER, eW.COLOR_ATTACHMENT0, c.get(e).__webglTexture, r, m + t), eW.framebufferTextureLayer(eW.DRAW_FRAMEBUFFER, eW.COLOR_ATTACHMENT0, c.get(n).__webglTexture, a, g + t)), eW.blitFramebuffer(f, p, o, s, h, _, o, s, eW.DEPTH_BUFFER_BIT, eW.NEAREST);
                            l.bindFramebuffer(eW.READ_FRAMEBUFFER, null), l.bindFramebuffer(eW.DRAW_FRAMEBUFFER, null)
                        } else if (0 !== r || e.isRenderTargetTexture || c.has(e)) {
                            let t = c.get(e),
                                i = c.get(n);
                            l.bindFramebuffer(eW.READ_FRAMEBUFFER, ep), l.bindFramebuffer(eW.DRAW_FRAMEBUFFER, em);
                            for (let e = 0; e < u; e++) C ? eW.framebufferTextureLayer(eW.READ_FRAMEBUFFER, eW.COLOR_ATTACHMENT0, t.__webglTexture, r, m + e) : eW.framebufferTexture2D(eW.READ_FRAMEBUFFER, eW.COLOR_ATTACHMENT0, eW.TEXTURE_2D, t.__webglTexture, r), P ? eW.framebufferTextureLayer(eW.DRAW_FRAMEBUFFER, eW.COLOR_ATTACHMENT0, i.__webglTexture, a, g + e) : eW.framebufferTexture2D(eW.DRAW_FRAMEBUFFER, eW.COLOR_ATTACHMENT0, eW.TEXTURE_2D, i.__webglTexture, a), 0 !== r ? eW.blitFramebuffer(f, p, o, s, h, _, o, s, eW.COLOR_BUFFER_BIT, eW.NEAREST) : P ? eW.copyTexSubImage3D(v, a, h, _, g + e, f, p, o, s) : eW.copyTexSubImage2D(v, a, h, _, f, p, o, s);
                            l.bindFramebuffer(eW.READ_FRAMEBUFFER, null), l.bindFramebuffer(eW.DRAW_FRAMEBUFFER, null)
                        } else P ? e.isDataTexture || e.isData3DTexture ? eW.texSubImage3D(v, a, h, _, g, o, s, u, E, M, S.data) : n.isCompressedArrayTexture ? eW.compressedTexSubImage3D(v, a, h, _, g, o, s, u, E, S.data) : eW.texSubImage3D(v, a, h, _, g, o, s, u, E, M, S) : e.isDataTexture ? eW.texSubImage2D(eW.TEXTURE_2D, a, h, _, o, s, E, M, S.data) : e.isCompressedTexture ? eW.compressedTexSubImage2D(eW.TEXTURE_2D, a, h, _, S.width, S.height, E, S.data) : eW.texSubImage2D(eW.TEXTURE_2D, a, h, _, o, s, E, M, S);
                        l.pixelStorei(eW.UNPACK_ROW_LENGTH, T), l.pixelStorei(eW.UNPACK_IMAGE_HEIGHT, x), l.pixelStorei(eW.UNPACK_SKIP_PIXELS, R), l.pixelStorei(eW.UNPACK_SKIP_ROWS, A), l.pixelStorei(eW.UNPACK_SKIP_IMAGES, b), 0 === a && n.generateMipmaps && eW.generateMipmap(v), l.unbindTexture()
                    }, this.initRenderTarget = function(e) {
                        void 0 === c.get(e).__webglFramebuffer && d.setupRenderTarget(e)
                    }, this.initTexture = function(e) {
                        e.isCubeTexture ? d.setTextureCube(e, 0) : e.isData3DTexture ? d.setTexture3D(e, 0) : e.isDataArrayTexture || e.isCompressedArrayTexture ? d.setTexture2DArray(e, 0) : d.setTexture2D(e, 0), l.unbindTexture()
                    }, this.resetState = function() {
                        eh = 0, e_ = 0, eg = null, l.reset(), U.reset()
                    }, "u" > typeof __THREE_DEVTOOLS__ && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", {
                        detail: this
                    }))
                }
                get coordinateSystem() {
                    return i.TdN
                }
                get outputColorSpace() {
                    return this._outputColorSpace
                }
                set outputColorSpace(e) {
                    this._outputColorSpace = e;
                    let n = this.getContext();
                    n.drawingBufferColorSpace = i.ppV._getDrawingBufferColorSpace(e), n.unpackColorSpace = i.ppV._getUnpackColorSpace()
                }
            }
        }
    }
]);