"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [94505], {
        7614: (e, a, t) => {
            t.d(a, {
                U: () => i,
                s: () => r
            });
            var s = t(67344);
            let n = e => `https://cdn.cutiepage.in/template-seeds/${e}/cover-v2.webp`,
                r = [{
                    slug: "cp-bhai-dooj-mini",
                    name: "Tilak in a Tap",
                    line: "Quick and sweet, made in two minutes",
                    tag: "Most loved",
                    cover: n("cp-bhai-dooj-mini")
                }, {
                    slug: "cp-bhai-dooj-genz",
                    name: "Bhai.exe",
                    line: "Bright colours, funny cards and your photos",
                    tag: "Gen Z",
                    cover: n("cp-bhai-dooj-genz")
                }, {
                    slug: "cp-bhai-dooj",
                    name: "Bhai Dooj Thali",
                    line: "A calm story: the tilak, your memories, a box of sweets",
                    tag: "Signature",
                    cover: n("cp-bhai-dooj")
                }],
                i = s.Vt.path
        },
        26613: (e, a, t) => {
            t.d(a, {
                AutoSwipeRow: () => r
            });
            var s = t(73365),
                n = t(1521);

            function r({
                children: e,
                className: a,
                intervalMs: t = 3e3
            }) {
                let i = (0, n.useRef)(null);
                return (0, n.useEffect)(() => {
                    let e = i.current;
                    if (!e || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
                    let a = !1,
                        s = 0,
                        n = e => {
                            "mouse" === e.pointerType && (a = !0)
                        },
                        r = () => {
                            a = !1
                        },
                        l = () => {
                            s = Date.now()
                        };
                    e.addEventListener("pointerenter", n), e.addEventListener("pointerleave", r), e.addEventListener("touchstart", l, {
                        passive: !0
                    });
                    let o = window.setInterval(() => {
                        let [t, n] = e.children;
                        if (a || Date.now() - s < 5e3 || !n || document.hidden) return;
                        let r = e.scrollLeft + e.clientWidth >= e.scrollWidth - 4;
                        e.scrollTo({
                            left: r ? 0 : e.scrollLeft + n.offsetLeft - t.offsetLeft,
                            behavior: "smooth"
                        })
                    }, t);
                    return () => {
                        window.clearInterval(o), e.removeEventListener("pointerenter", n), e.removeEventListener("pointerleave", r), e.removeEventListener("touchstart", l)
                    }
                }, [t]), (0, s.jsx)("div", {
                    ref: i,
                    className: a,
                    children: e
                })
            }
        },
        36037: (e, a, t) => {
            t.d(a, {
                k: () => d,
                u: () => h
            });
            var s = t(73365),
                n = t(99568),
                r = t.n(n),
                i = t(56957),
                l = t(67344),
                o = t(14856);
            let p = ["bg-cp-highlight shadow-[0_0_6px_2px_color-mix(in_srgb,var(--cp-highlight)_70%,transparent)]", "bg-cp-warning shadow-[0_0_6px_2px_color-mix(in_srgb,var(--cp-warning)_70%,transparent)]", "bg-cp-rose shadow-[0_0_6px_2px_color-mix(in_srgb,var(--cp-rose)_70%,transparent)]", "bg-cp-lavender shadow-[0_0_6px_2px_color-mix(in_srgb,var(--cp-lavender)_70%,transparent)]"],
                c = [
                    [30, 70],
                    [46, 28],
                    [62, 80],
                    [74, 34],
                    [90, 72]
                ];

            function d({
                count: e,
                className: a
            }) {
                let t = e ? `${e} desi minis` : "Desi minis";
                return (0, s.jsxs)(r(), {
                    href: l.Ei.path,
                    "aria-label": `${l.Ei.name}: ${t}, live ${o.Bi} days`,
                    className: `group relative col-span-2 flex items-center gap-3 overflow-hidden rounded-2xl bg-cp-night p-3 pt-6 pr-3.5 text-white transition duration-200 motion-safe:hover:-translate-y-0.5 hover:shadow-cp-modal focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none sm:col-span-4 sm:gap-5 sm:p-4 sm:pt-7 sm:pr-5 ${a??""}`,
                    children: [(0, s.jsx)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_70%,color-mix(in_srgb,var(--cp-primary)_60%,transparent)_0%,transparent_45%),radial-gradient(circle_at_100%_100%,color-mix(in_srgb,var(--cp-rose)_28%,transparent)_0%,transparent_45%)]"
                    }), c.map(([e, a], t) => (0, s.jsx)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute size-0.5 rounded-full bg-white/70 motion-safe:animate-pulse-soft",
                        style: {
                            left: `${e}%`,
                            top: `${a}%`,
                            animationDelay: `${.8*t}s`
                        }
                    }, t)), (0, s.jsx)(x, {
                        swags: 6,
                        className: "sm:hidden"
                    }), (0, s.jsx)(x, {
                        swags: 12,
                        className: "hidden sm:block"
                    }), (0, s.jsx)(m, {}), (0, s.jsxs)("span", {
                        className: "relative min-w-0 flex-1 text-left",
                        children: [(0, s.jsx)("span", {
                            className: "text-[9.5px] font-semibold uppercase tracking-[0.3em] text-cp-pastel-butter/80 sm:text-[10.5px]",
                            children: t
                        }), (0, s.jsxs)("span", {
                            className: "mt-0.5 flex flex-wrap items-center gap-x-2.5 gap-y-1",
                            children: [(0, s.jsx)("span", {
                                className: "font-display text-[20px] leading-tight tracking-tight text-cp-pastel-butter [text-shadow:0_1px_14px_color-mix(in_srgb,var(--cp-warning)_45%,transparent)] sm:text-[28px]",
                                children: "Mini CutiePages"
                            }), (0, s.jsxs)("span", {
                                className: "inline-flex -rotate-3 items-baseline gap-1 rounded-md border border-dashed border-cp-warning-ink/50 bg-cp-pastel-butter px-1.5 py-0.5 text-cp-warning-ink transition-transform duration-300 motion-safe:group-hover:rotate-0 motion-reduce:transition-none",
                                children: [(0, s.jsx)("span", {
                                    className: "text-[9px] font-semibold uppercase tracking-[0.1em]",
                                    children: "just"
                                }), (0, s.jsx)("span", {
                                    className: "font-display text-[13px] font-bold sm:text-[15px]",
                                    children: "\u20b929"
                                })]
                            })]
                        }), (0, s.jsxs)("span", {
                            className: "mt-1 line-clamp-2 block text-[11.5px] leading-snug text-white/70 sm:text-[13.5px]",
                            children: ["Tiny pages you play, not just read. Live ", o.Bi, " days."]
                        })]
                    }), (0, s.jsxs)("span", {
                        "aria-hidden": !0,
                        className: "relative inline-flex shrink-0 items-center gap-2 transition duration-200 group-hover:translate-x-0.5 motion-reduce:transition-none",
                        children: [(0, s.jsx)("span", {
                            className: "hidden text-[13px] font-semibold text-white sm:inline",
                            children: "Explore"
                        }), (0, s.jsx)("img", {
                            src: "/ui/arrow-go-v1.webp",
                            alt: "",
                            decoding: "async",
                            className: "size-9 drop-shadow-[0_6px_10px_rgba(0,0,0,0.25)] sm:size-10"
                        })]
                    })]
                })
            }

            function x({
                swags: e,
                className: a
            }) {
                return (0, s.jsxs)("span", {
                    "aria-hidden": !0,
                    className: `pointer-events-none absolute inset-x-0 top-0 h-5 ${a}`,
                    children: [(0, s.jsx)("svg", {
                        viewBox: `0 0 ${100*e} 20`,
                        preserveAspectRatio: "none",
                        className: "absolute inset-0 size-full",
                        children: (0, s.jsx)("path", {
                            d: Array.from({
                                length: e
                            }, (e, a) => `M${100*a} 1 Q${100*a+50} 19 ${100*a+100} 1`).join(" "),
                            fill: "none",
                            className: "stroke-white/35",
                            strokeWidth: "1",
                            vectorEffect: "non-scaling-stroke"
                        })
                    }), Array.from({
                        length: e
                    }, (a, t) => [.25, .5, .75].map(a => [(t + a) / e * 100, 1 + 4 * a * (1 - a) * 9])).flat().map(([e, a], t) => (0, s.jsxs)("span", {
                        className: "absolute -translate-x-1/2",
                        style: {
                            left: `${e}%`,
                            top: a
                        },
                        children: [(0, s.jsx)("span", {
                            className: "mx-auto block h-[3px] w-[4px] rounded-t-sm bg-cp-warning-ink"
                        }), (0, s.jsx)("span", {
                            className: `block h-[8px] w-[6px] rounded-full motion-safe:animate-pulse-soft ${p[t%p.length]}`,
                            style: {
                                animationDelay: `${t%5*.6}s`
                            }
                        })]
                    }, t))]
                })
            }

            function m() {
                return (0, s.jsxs)("span", {
                    "aria-hidden": !0,
                    className: "relative size-[92px] shrink-0 sm:size-[118px]",
                    children: [(0, s.jsx)(i.T, {
                        name: "carrom-board",
                        className: "left-0 top-0 w-[50px] -rotate-6 motion-safe:group-hover:-translate-x-0.5 motion-safe:group-hover:-translate-y-0.5 sm:w-[64px]"
                    }), (0, s.jsx)(i.T, {
                        name: "kite-pink",
                        className: "right-0 top-0 w-[40px] rotate-6 motion-safe:group-hover:translate-x-0.5 motion-safe:group-hover:-translate-y-0.5 sm:w-[52px]"
                    }), (0, s.jsx)(i.T, {
                        name: "gola-rose",
                        className: "bottom-0 left-2 w-[30px] rotate-3 motion-safe:group-hover:-translate-x-0.5 motion-safe:group-hover:translate-y-0.5 sm:w-[38px]"
                    }), (0, s.jsx)(i.T, {
                        name: "kulhad-chai",
                        className: "bottom-0 right-0 z-10 w-[42px] -rotate-3 motion-safe:group-hover:translate-x-0.5 motion-safe:group-hover:translate-y-0.5 sm:w-[54px]"
                    })]
                })
            }
            let g = [{
                sticker: "carrom-board",
                name: "Carrom Queen",
                slug: "cp-carrom"
            }, {
                sticker: "kite-pink",
                name: "Patang Baazi",
                slug: "cp-patang"
            }, {
                sticker: "gola-rose",
                name: "Barf Ka Gola",
                slug: "cp-barf-gola"
            }, {
                sticker: "kulhad-chai",
                name: "Chai Tapri",
                slug: "cp-chai-tapri"
            }, {
                sticker: "lottery-ticket",
                name: "Dil Ki Lottery",
                slug: "cp-lottery"
            }, {
                sticker: "steam-engine",
                name: "Rail Gaadi",
                slug: "cp-rail-gaadi"
            }, {
                sticker: "ludo-board",
                name: "Ludo Pe Pyaar",
                slug: "cp-ludo"
            }, {
                sticker: "jalebi",
                name: "Jalebi Si Baatein",
                slug: "cp-jalebi"
            }, {
                sticker: "giant-wheel",
                name: "Mela Ka Jhoola",
                slug: "cp-jhoola"
            }, {
                sticker: "auto-black",
                name: "Auto Wala Pyaar",
                slug: "cp-auto"
            }, {
                sticker: "diya-clay",
                name: "Ek Diya",
                slug: "cp-diya"
            }, {
                sticker: "cassette",
                name: "Mixtape",
                slug: "cp-cassette"
            }, {
                sticker: "kulfi-matka",
                name: "Matka Kulfi",
                slug: "cp-matka-kulfi"
            }, {
                sticker: "bioscope",
                name: "Bioscope",
                slug: "cp-bioscope"
            }, {
                sticker: "cricket-bat",
                name: "Gali Cricket",
                slug: "cp-gali-cricket"
            }, {
                sticker: "rakhi-zari",
                name: "Rakhi Ka Vaada",
                slug: "cp-rakhi"
            }, {
                sticker: "cycle-pink",
                name: "Cycle Sawaari",
                slug: "cp-cycle"
            }, {
                sticker: "postbox",
                name: "Inland Letter",
                slug: "cp-inland-letter"
            }, {
                sticker: "balloons",
                name: "Balloon Shoot",
                slug: "cp-balloon-shoot"
            }, {
                sticker: "slam-book",
                name: "Slam Book",
                slug: "cp-slam-book"
            }];

            function h({
                className: e
            }) {
                return (0, s.jsxs)("div", {
                    className: `group relative block overflow-hidden rounded-2xl bg-cp-night px-3 pb-3 pt-6 text-white transition duration-200 motion-safe:hover:-translate-y-0.5 hover:shadow-cp-modal motion-reduce:transition-none sm:px-4 sm:pb-4 ${e??""}`,
                    children: [(0, s.jsx)(r(), {
                        href: l.Ei.path,
                        "aria-label": `${l.Ei.name}: explore from 60+ templates, live ${o.Bi} days`,
                        className: "absolute inset-0 rounded-2xl focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-cp-select"
                    }), (0, s.jsx)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_10%_20%,color-mix(in_srgb,var(--cp-primary)_55%,transparent)_0%,transparent_45%),radial-gradient(circle_at_100%_100%,color-mix(in_srgb,var(--cp-rose)_28%,transparent)_0%,transparent_45%)]"
                    }), (0, s.jsx)(x, {
                        swags: 6,
                        className: "sm:hidden"
                    }), (0, s.jsx)(x, {
                        swags: 10,
                        className: "hidden sm:block"
                    }), (0, s.jsxs)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none relative flex items-center gap-3",
                        children: [(0, s.jsxs)("span", {
                            className: "inline-flex size-12 shrink-0 -rotate-6 flex-col items-center justify-center rounded-full border-2 border-dashed border-cp-warning-ink/50 bg-cp-pastel-butter text-cp-warning-ink shadow-cp-float",
                            children: [(0, s.jsx)("span", {
                                className: "font-display text-[15px] font-bold leading-none",
                                children: "\u20b929"
                            }), (0, s.jsx)("span", {
                                className: "text-[7.5px] font-semibold uppercase tracking-[0.12em]",
                                children: "each"
                            })]
                        }), (0, s.jsxs)("span", {
                            className: "min-w-0 flex-1",
                            children: [(0, s.jsx)("span", {
                                className: "block font-display text-[19px] leading-tight tracking-tight text-cp-pastel-butter sm:text-[22px]",
                                children: "Mini CutiePages"
                            }), (0, s.jsx)("span", {
                                className: "block truncate text-[11.5px] text-white/70 sm:text-[12.5px]",
                                children: "Explore from 60+ templates"
                            })]
                        }), (0, s.jsx)("img", {
                            "aria-hidden": !0,
                            src: "/ui/arrow-go-v1.webp",
                            alt: "",
                            decoding: "async",
                            className: "size-8 shrink-0 transition group-hover:translate-x-0.5"
                        })]
                    }), (0, s.jsx)("span", {
                        className: "no-scrollbar pointer-events-none relative -mx-3 mt-1 flex snap-x gap-2 overflow-x-auto px-3 pb-1 pt-2.5 sm:-mx-4 sm:px-4",
                        children: g.map(e => (0, s.jsxs)(r(), {
                            href: `/try/${e.slug}`,
                            prefetch: !1,
                            className: "group/tile pointer-events-auto flex w-[56px] shrink-0 snap-start flex-col items-center gap-1 rounded-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select sm:w-[64px]",
                            children: [(0, s.jsx)("span", {
                                className: "relative flex aspect-square w-full items-center justify-center rounded-full bg-white/95 shadow-[0_6px_14px_-6px_rgb(0_0_0/0.5)] ring-2 ring-white/40 transition-transform duration-200 ease-out group-hover/tile:scale-110 motion-reduce:transition-none motion-reduce:group-hover/tile:scale-100",
                                children: (0, s.jsx)(i.T, {
                                    name: e.sticker,
                                    className: "inset-0 m-auto max-h-[80%] w-auto max-w-[74%] group-hover:-translate-y-0.5"
                                })
                            }), (0, s.jsx)("span", {
                                className: "line-clamp-2 text-center text-[9.5px] font-semibold leading-tight text-white/85 sm:text-[10.5px]",
                                children: e.name
                            })]
                        }, e.sticker))
                    })]
                })
            }
        },
        56957: (e, a, t) => {
            t.d(a, {
                T: () => i
            });
            var s = t(73365),
                n = t(58872),
                r = t(78874);

            function i({
                name: e,
                className: a = ""
            }) {
                let [t, l] = r.B[e];
                return (0, s.jsx)(n.default, {
                    src: (0, r.Y)(e),
                    alt: "",
                    width: t,
                    height: l,
                    unoptimized: !0,
                    draggable: !1,
                    className: `pointer-events-none absolute h-auto select-none drop-shadow-[0_6px_10px_rgb(0_0_0/0.35)] transition-transform duration-300 ease-out motion-reduce:transition-none ${a}`
                })
            }
        },
        78874: (e, a, t) => {
            t.d(a, {
                B: () => s,
                Y: () => n
            });
            let s = {
                anaar: [314, 474],
                "auto-black": [386, 367],
                "auto-pink": [382, 372],
                balloons: [349, 464],
                "bandhani-gift": [388, 392],
                bandmaster: [363, 498],
                bangles: [370, 331],
                bioscope: [386, 460],
                boombox: [406, 344],
                "carrom-board": [422, 362],
                "carrom-coins": [351, 337],
                "carrom-queen": [309, 299],
                cassette: [397, 347],
                chakri: [420, 332],
                charkhi: [319, 434],
                clapper: [349, 409],
                "cotton-candy": [299, 463],
                "cricket-bat": [308, 453],
                "cutting-chai": [281, 376],
                "cycle-black": [414, 343],
                "cycle-pink": [384, 380],
                "dahi-bhalla": [419, 394],
                "desi-cake": [385, 415],
                dhol: [392, 423],
                dice: [351, 335],
                "diya-brass": [363, 360],
                "diya-clay": [358, 361],
                firki: [304, 447],
                gajra: [353, 381],
                "galaxy-marble": [338, 340],
                ghodi: [400, 501],
                "giant-wheel": [360, 442],
                "gola-kala-khatta": [271, 433],
                "gola-mango": [272, 433],
                "gola-rose": [267, 433],
                "gulab-jamun": [424, 372],
                "gulal-cloud": [384, 401],
                "gulal-thali": [419, 297],
                "holi-kurta": [334, 465],
                imarti: [369, 339],
                "inland-letter": [390, 365],
                jalebi: [381, 346],
                jhumka: [407, 364],
                "kaan-pakad-kid": [295, 470],
                kabootar: [412, 368],
                kandil: [324, 491],
                kettle: [432, 490],
                "kite-pink": [360, 460],
                "kite-teal": [333, 468],
                "kulfi-malai": [300, 459],
                "kulfi-matka": [371, 391],
                "kulfi-rose": [307, 460],
                "kulhad-chai": [299, 437],
                ladder: [337, 433],
                "lottery-ticket": [424, 279],
                "ludo-board": [409, 375],
                "ludo-tokens": [388, 347],
                marbles: [388, 358],
                "marigold-heart": [411, 365],
                mic: [240, 436],
                milestone: [359, 368],
                "mithai-thali": [409, 350],
                paan: [374, 368],
                "papdi-chaat": [421, 336],
                phuljhadi: [336, 428],
                pichkari: [388, 306],
                popcorn: [340, 430],
                postbox: [226, 435],
                "rail-coach": [382, 333],
                "rakhi-cartoon": [357, 331],
                "rakhi-pearl": [375, 313],
                "rakhi-zari": [385, 309],
                rangoli: [381, 357],
                rusk: [346, 372],
                "saanp-seedhi-board": [414, 398],
                "slam-book": [362, 424],
                snake: [328, 414],
                stamp: [317, 351],
                "steam-engine": [364, 425],
                "steel-chai": [287, 381],
                stumps: [299, 425],
                "tape-ball": [346, 346],
                "taxi-meter": [330, 390],
                teddy: [343, 415],
                toran: [436, 358],
                trophy: [373, 399],
                "water-balloons": [363, 375],
                "wheel-cabin": [304, 433],
                "sorry-parcel": [400, 376],
                "sorry-scooter": [400, 396],
                "sorry-pin": [335, 400],
                "sorry-doorbell": [356, 364],
                "sorry-glass-heart": [400, 357],
                "sorry-clipboard": [358, 400],
                "sorry-stamp": [333, 400],
                "sorry-envelope": [400, 332],
                "sorry-bug": [375, 386],
                "sorry-undo": [365, 357],
                "sorry-wrench-heart": [383, 356],
                "sorry-download": [400, 317],
                "sorry-battery": [400, 250],
                "sorry-shield": [337, 369],
                "sorry-rocket": [359, 370],
                "sorry-phone": [338, 400]
            };

            function n(e) {
                return `https://cdn.cutiepage.in/static/mini-stickers/${e}-v1.webp`
            }
        },
        94505: (e, a, t) => {
            t.d(a, {
                M: () => T
            });
            var s = t(73365),
                n = t(26613),
                r = t(58872),
                i = t(99568),
                l = t.n(i),
                o = t(67344),
                p = t(7614);
            let c = "rounded-full bg-[radial-gradient(circle,#b9471a_0%_26%,#f08a12_30%_64%,#ffc53d_68%)] shadow-[0_1px_2px_rgba(60,10,0,0.45)]",
                d = ["bottom-1 left-0 -rotate-[9deg] group-hover:-translate-x-1 group-hover:-rotate-[12deg]", "left-1/2 top-0 z-10 -translate-x-1/2 group-hover:-translate-y-1", "bottom-1 right-0 rotate-[9deg] group-hover:translate-x-1 group-hover:rotate-[12deg]"];

            function x({
                className: e
            }) {
                return (0, s.jsxs)(l(), {
                    href: o.Vt.path,
                    "aria-label": `${o.Vt.name} special`,
                    className: `group @container relative col-span-2 flex items-center gap-3 overflow-hidden rounded-2xl p-3 pt-6 pr-3.5 text-white transition duration-200 hover:-translate-y-0.5 hover:shadow-cp-modal focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none sm:col-span-4 lg:gap-5 lg:p-4 lg:pt-7 lg:pr-5 ${e??""}`,
                    style: {
                        background: "radial-gradient(circle at 12% 70%, rgba(255,170,60,0.42) 0%, transparent 42%), radial-gradient(circle at 100% 0%, rgba(255,120,80,0.25) 0%, transparent 45%), linear-gradient(115deg, #4a1016 0%, #7a1d1d 55%, #9c3418 100%)"
                    },
                    children: [(0, s.jsx)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-y-0 right-0 w-1/2 bg-[radial-gradient(rgba(255,214,140,0.16)_1px,transparent_1.5px)] bg-[length:12px_12px] [mask-image:linear-gradient(to_left,black,transparent)]"
                    }), (0, s.jsx)(m, {
                        flowers: 14,
                        className: "@lg:hidden"
                    }), (0, s.jsx)(m, {
                        flowers: 32,
                        className: "hidden @lg:block"
                    }), (0, s.jsx)("span", {
                        "data-art": !0,
                        "aria-hidden": !0,
                        className: "relative h-[86px] w-[106px] shrink-0 @lg:h-[104px] @lg:w-[140px]",
                        children: p.s.map((e, a) => (0, s.jsx)(r.default, {
                            src: e.cover,
                            alt: "",
                            width: 120,
                            height: 80,
                            unoptimized: !0,
                            draggable: !1,
                            className: `pointer-events-none absolute aspect-[3/2] w-[62px] select-none rounded-md object-cover ring-2 ring-[#ffe3a3] shadow-[0_6px_12px_rgb(0_0_0/0.4)] transition-transform duration-300 ease-out motion-reduce:transition-none @lg:w-[82px] ${d[a]}`
                        }, e.slug))
                    }), (0, s.jsxs)("span", {
                        className: "relative min-w-0 flex-1 text-left",
                        children: [(0, s.jsx)("span", {
                            className: "text-[9.5px] font-semibold uppercase tracking-[0.36em] text-[#ffd98a]/85 @lg:text-[10.5px]",
                            children: "Celebrate"
                        }), (0, s.jsxs)("span", {
                            className: "mt-0.5 flex flex-wrap items-baseline gap-x-2",
                            children: [(0, s.jsx)("span", {
                                className: "font-display text-[22px] leading-tight tracking-tight text-[#ffe3a3] [text-shadow:0_1px_14px_rgba(255,170,60,0.5)] @lg:text-[30px]",
                                children: o.Vt.name
                            }), (0, s.jsx)("span", {
                                className: "font-display text-[13px] italic text-white/80 @lg:text-[16px]",
                                children: "specials"
                            })]
                        }), (0, s.jsxs)("span", {
                            className: "mt-0.5 line-clamp-2 block text-[11.5px] leading-snug text-white/75 @lg:text-[13.5px]",
                            children: ["A page for your bhai or behen, made in minutes. ", p.s.length, " designs."]
                        }), (0, s.jsx)("span", {
                            "data-chips": !0,
                            className: "mt-2 hidden flex-wrap gap-1.5 lg:flex",
                            children: p.s.map(e => (0, s.jsx)("span", {
                                className: "rounded-full border border-[#ffd98a]/30 bg-white/10 px-2.5 py-0.5 text-[11.5px] font-medium text-[#ffe3a3]",
                                children: e.name
                            }, e.slug))
                        })]
                    }), (0, s.jsxs)("span", {
                        "aria-hidden": !0,
                        className: "relative inline-flex shrink-0 items-center gap-2 transition duration-200 group-hover:translate-x-0.5 motion-reduce:transition-none",
                        children: [(0, s.jsx)("span", {
                            className: "hidden text-[13px] font-semibold text-white @lg:inline",
                            children: "Explore"
                        }), (0, s.jsx)("img", {
                            src: "/ui/arrow-go-v1.webp",
                            alt: "",
                            decoding: "async",
                            className: "size-9 drop-shadow-[0_6px_10px_rgba(0,0,0,0.25)] @lg:size-10"
                        })]
                    })]
                })
            }

            function m({
                flowers: e,
                className: a
            }) {
                return (0, s.jsxs)("span", {
                    "aria-hidden": !0,
                    className: `pointer-events-none absolute inset-x-0 top-0 h-6 ${a}`,
                    children: [(0, s.jsx)("span", {
                        className: "absolute inset-x-0 top-[3px] h-px bg-[#ffd98a]/50"
                    }), Array.from({
                        length: e
                    }, (a, t) => {
                        let n = (t + .5) / e * 100;
                        return (0, s.jsxs)("span", {
                            className: "absolute top-0 flex -translate-x-1/2 flex-col items-center",
                            style: {
                                left: `${n}%`
                            },
                            children: [(0, s.jsx)("span", {
                                className: `size-[9px] ${c}`
                            }), t % 3 == 1 ? (0, s.jsxs)(s.Fragment, {
                                children: [(0, s.jsx)("span", {
                                    className: `-mt-px size-[7px] ${c}`
                                }), (0, s.jsx)("span", {
                                    className: `-mt-px size-[6px] ${c}`
                                })]
                            }) : null]
                        }, t)
                    }), Array.from({
                        length: e
                    }, (a, t) => (0, s.jsx)("span", {
                        className: "absolute top-[3px] h-[9px] w-[4px] -translate-x-1/2 rotate-12 rounded-b-full bg-[#3f7d32]",
                        style: {
                            left: `${t/e*100}%`
                        }
                    }, t))]
                })
            }
            let g = [{
                    slug: "cp-diya",
                    name: "Ek Diya Tere Naam"
                }, {
                    slug: "cp-diwali-dabba",
                    name: "Diwali Ka Dabba"
                }, {
                    slug: "cp-world-diwali",
                    name: "Diwali Night in 3D"
                }].map(e => ({ ...e,
                    cover: `https://cdn.cutiepage.in/template-seeds/${e.slug}/cover-v1.webp`
                })),
                h = ["bottom-2 left-0 -rotate-[9deg] group-hover:-translate-x-1 group-hover:-rotate-[12deg]", "left-1/2 top-0 z-10 -translate-x-1/2 group-hover:-translate-y-1", "bottom-2 right-0 rotate-[9deg] group-hover:translate-x-1 group-hover:rotate-[12deg]"],
                u = ["#ffd36b", "#ff8fb1", "#8fe3ff", "#ffb35c"],
                f = [
                    [58, 8, 30, 0],
                    [71, 46, 20, .8]
                ];

            function b({
                className: e
            }) {
                return (0, s.jsxs)(l(), {
                    href: o.Mw.path,
                    "aria-label": `${o.Mw.name} special`,
                    className: `group @container relative col-span-2 flex items-center gap-3 overflow-hidden rounded-2xl p-3 pt-6 pr-3.5 text-white transition duration-200 hover:-translate-y-0.5 hover:shadow-cp-modal focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none sm:col-span-4 lg:gap-5 lg:p-4 lg:pt-7 lg:pr-5 ${e??""}`,
                    style: {
                        background: "radial-gradient(circle at 14% 92%, rgba(255,170,60,0.5) 0%, transparent 40%), radial-gradient(circle at 80% 30%, rgba(255,120,190,0.22) 0%, transparent 45%), linear-gradient(115deg, #1a1342 0%, #2b1a5a 55%, #57266c 100%)"
                    },
                    children: [(0, s.jsx)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-y-0 right-0 w-3/5 bg-[radial-gradient(rgba(255,240,200,0.35)_0.8px,transparent_1.3px)] bg-[length:17px_13px] [mask-image:linear-gradient(to_left,black,transparent)]"
                    }), f.map(([e, a, t, n]) => (0, s.jsx)(v, {
                        left: e,
                        top: a,
                        size: t,
                        delay: n
                    }, `${e}-${a}`)), (0, s.jsx)(_, {
                        count: 12,
                        className: "@lg:hidden"
                    }), (0, s.jsx)(_, {
                        count: 26,
                        className: "hidden @lg:block"
                    }), (0, s.jsxs)("span", {
                        "data-art": !0,
                        "aria-hidden": !0,
                        className: "relative h-[86px] w-[106px] shrink-0 @lg:h-[104px] @lg:w-[140px]",
                        children: [g.map((e, a) => (0, s.jsx)(r.default, {
                            src: e.cover,
                            alt: "",
                            width: 120,
                            height: 80,
                            unoptimized: !0,
                            draggable: !1,
                            className: `pointer-events-none absolute aspect-[3/2] w-[62px] select-none rounded-md object-cover ring-2 ring-[#ffe3a3] shadow-[0_6px_12px_rgb(0_0_0/0.45)] transition-transform duration-300 ease-out motion-reduce:transition-none @lg:w-[82px] ${h[a]}`
                        }, e.slug)), (0, s.jsx)(w, {})]
                    }), (0, s.jsxs)("span", {
                        className: "relative min-w-0 flex-1 text-left",
                        children: [(0, s.jsx)("span", {
                            className: "text-[9.5px] font-semibold uppercase tracking-[0.36em] text-[#ffd98a]/85 @lg:text-[10.5px]",
                            children: "Light up"
                        }), (0, s.jsxs)("span", {
                            className: "mt-0.5 flex flex-wrap items-baseline gap-x-2",
                            children: [(0, s.jsx)("span", {
                                className: "font-display text-[22px] leading-tight tracking-tight text-[#ffe3a3] [text-shadow:0_1px_14px_rgba(255,170,60,0.55)] @lg:text-[30px]",
                                children: o.Mw.name
                            }), (0, s.jsx)("span", {
                                className: "font-display text-[13px] italic text-white/80 @lg:text-[16px]",
                                children: "specials"
                            })]
                        }), (0, s.jsx)("span", {
                            className: "mt-0.5 line-clamp-2 block text-[11.5px] leading-snug text-white/75 @lg:text-[13.5px]",
                            children: "Diyas, rangoli and fireworks with your photos, sent as one link."
                        }), (0, s.jsx)("span", {
                            "data-chips": !0,
                            className: "mt-2 hidden flex-wrap gap-1.5 lg:flex",
                            children: g.map(e => (0, s.jsx)("span", {
                                className: "rounded-full border border-[#ffd98a]/30 bg-white/10 px-2.5 py-0.5 text-[11.5px] font-medium text-[#ffe3a3]",
                                children: e.name
                            }, e.slug))
                        })]
                    }), (0, s.jsxs)("span", {
                        "aria-hidden": !0,
                        className: "relative inline-flex shrink-0 items-center gap-2 transition duration-200 group-hover:translate-x-0.5 motion-reduce:transition-none",
                        children: [(0, s.jsx)("span", {
                            className: "hidden text-[13px] font-semibold text-white @lg:inline",
                            children: "Explore"
                        }), (0, s.jsx)("img", {
                            src: "/ui/arrow-go-v1.webp",
                            alt: "",
                            decoding: "async",
                            className: "size-9 drop-shadow-[0_6px_10px_rgba(0,0,0,0.25)] @lg:size-10"
                        })]
                    })]
                })
            }

            function w() {
                return (0, s.jsxs)("span", {
                    className: "absolute -bottom-0.5 left-1/2 z-20 flex -translate-x-1/2 flex-col items-center",
                    children: [(0, s.jsx)("span", {
                        className: "h-[11px] w-[7px] animate-pulse-soft rounded-[50%_50%_50%_50%/65%_65%_35%_35%] bg-[radial-gradient(circle_at_50%_75%,#fff6c8_0%,#ffc23d_45%,#ff7a1a_100%)] shadow-[0_0_10px_4px_rgba(255,190,70,0.6)] motion-reduce:animate-none"
                    }), (0, s.jsx)("span", {
                        className: "-mt-px h-[9px] w-[26px] rounded-b-full bg-[linear-gradient(#e0742c,#93380f)] shadow-[0_3px_6px_rgb(0_0_0/0.45)] ring-1 ring-[#ffd98a]/60"
                    })]
                })
            }

            function v({
                left: e,
                top: a,
                size: t,
                delay: n
            }) {
                return (0, s.jsx)("span", {
                    "aria-hidden": !0,
                    className: "pointer-events-none absolute animate-sparkle rounded-full bg-[repeating-conic-gradient(#ffd98a_0deg_6deg,transparent_6deg_30deg)] opacity-70 [mask-image:radial-gradient(circle,transparent_20%,black_26%,black_55%,transparent_70%)] motion-reduce:animate-none",
                    style: {
                        left: `${e}%`,
                        top: `${a}%`,
                        width: t,
                        height: t,
                        animationDuration: "2.6s",
                        animationDelay: `${n}s`
                    }
                })
            }

            function _({
                count: e,
                className: a
            }) {
                return (0, s.jsxs)("span", {
                    "aria-hidden": !0,
                    className: `pointer-events-none absolute inset-x-0 top-0 h-5 ${a}`,
                    children: [(0, s.jsx)("span", {
                        className: "absolute inset-x-0 top-[3px] h-px bg-[#ffd98a]/40"
                    }), Array.from({
                        length: e
                    }, (a, t) => (0, s.jsx)("span", {
                        className: "absolute top-[3px] h-[7px] w-[5px] -translate-x-1/2 rounded-b-full",
                        style: {
                            left: `${(t+.5)/e*100}%`,
                            background: u[t % u.length],
                            boxShadow: `0 1px 6px 1px ${u[t%u.length]}`,
                            marginTop: t % 2 ? 2 : 0
                        }
                    }, t))]
                })
            }
            var k = t(56957);
            let j = ["Wedding", "Party", "Corporate", "Navratri", "Durga Puja"];

            function N({
                className: e
            }) {
                return (0, s.jsxs)(l(), {
                    href: "/collections/invites",
                    "aria-label": "Invites: wedding, party, corporate and festival invites with RSVP",
                    className: `group @container relative col-span-2 flex items-center gap-3 overflow-hidden rounded-2xl p-3 pt-6 pr-3.5 text-white transition duration-200 hover:-translate-y-0.5 hover:shadow-cp-modal focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none sm:col-span-4 lg:gap-5 lg:p-4 lg:pt-7 lg:pr-5 ${e??""}`,
                    style: {
                        background: "radial-gradient(circle at 12% 70%, rgba(255,214,140,0.30) 0%, transparent 42%), radial-gradient(circle at 100% 0%, rgba(120,220,190,0.18) 0%, transparent 45%), linear-gradient(115deg, #0d3b33 0%, #12524a 55%, #1d6b5a 100%)"
                    },
                    children: [(0, s.jsx)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-x-0 top-0 h-[6px] bg-[repeating-linear-gradient(135deg,#e2493b_0_10px,#fdf3e1_10px_20px,#2f6fd6_20px_30px,#fdf3e1_30px_40px)] opacity-90"
                    }), (0, s.jsx)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-y-0 right-0 w-1/2 bg-[radial-gradient(rgba(255,226,160,0.14)_1px,transparent_1.5px)] bg-[length:12px_12px] [mask-image:linear-gradient(to_left,black,transparent)]"
                    }), (0, s.jsxs)("span", {
                        "data-art": !0,
                        "aria-hidden": !0,
                        className: "relative h-[86px] w-[106px] shrink-0 @lg:h-[104px] @lg:w-[140px]",
                        children: [(0, s.jsx)(k.T, {
                            name: "ghodi",
                            className: "bottom-0 left-0 w-[46px] -rotate-[8deg] group-hover:-translate-x-1 group-hover:-rotate-[11deg] @lg:w-[60px]"
                        }), (0, s.jsx)(k.T, {
                            name: "desi-cake",
                            className: "bottom-1 right-0 w-[42px] rotate-[8deg] group-hover:translate-x-1 group-hover:rotate-[11deg] @lg:w-[56px]"
                        }), (0, s.jsx)(k.T, {
                            name: "inland-letter",
                            className: "left-1/2 top-0 z-10 w-[58px] -translate-x-1/2 -rotate-3 group-hover:-translate-y-1 @lg:w-[74px]"
                        })]
                    }), (0, s.jsxs)("span", {
                        className: "relative min-w-0 flex-1 text-left",
                        children: [(0, s.jsx)("span", {
                            className: "text-[9.5px] font-semibold uppercase tracking-[0.22em] text-[#ffe2a0]/85 @lg:text-[10.5px]",
                            children: "You're invited"
                        }), (0, s.jsx)("span", {
                            className: "mt-0.5 block font-display text-[22px] leading-tight tracking-tight text-[#fff1cf] [text-shadow:0_1px_14px_rgba(255,200,90,0.35)] @lg:text-[30px]",
                            children: "Invites"
                        }), (0, s.jsx)("span", {
                            className: "mt-0.5 line-clamp-2 block text-[11.5px] leading-snug text-white/75 @lg:text-[13.5px]",
                            children: "Wedding, party and office invites, with RSVPs."
                        }), (0, s.jsx)("span", {
                            "data-chips": !0,
                            className: "mt-2 hidden flex-wrap gap-1.5 lg:flex",
                            children: j.map(e => (0, s.jsx)("span", {
                                className: "rounded-full border border-[#ffe2a0]/30 bg-white/10 px-2.5 py-0.5 text-[11.5px] font-medium text-[#fff1cf]",
                                children: e
                            }, e))
                        })]
                    }), (0, s.jsxs)("span", {
                        "aria-hidden": !0,
                        className: "relative inline-flex shrink-0 items-center gap-2 transition duration-200 group-hover:translate-x-0.5 motion-reduce:transition-none",
                        children: [(0, s.jsx)("span", {
                            className: "hidden text-[13px] font-semibold text-white @lg:inline",
                            children: "Explore"
                        }), (0, s.jsx)("img", {
                            src: "/ui/arrow-go-v1.webp",
                            alt: "",
                            decoding: "async",
                            className: "size-9 drop-shadow-[0_6px_10px_rgba(0,0,0,0.25)] @lg:size-10"
                        })]
                    })]
                })
            }

            function y({
                className: e
            }) {
                return (0, s.jsxs)(l(), {
                    href: "/collections/make-your-own",
                    "aria-label": "Make your own: start from a blank page",
                    className: `group @container relative col-span-2 flex items-center gap-3 overflow-hidden rounded-2xl p-3 pt-6 pr-3.5 text-white transition duration-200 hover:-translate-y-0.5 hover:shadow-cp-modal focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select motion-reduce:transition-none sm:col-span-4 lg:gap-5 lg:p-4 lg:pt-7 lg:pr-5 ${e??""}`,
                    style: {
                        background: "radial-gradient(circle at 12% 70%, rgba(255,214,240,0.35) 0%, transparent 42%), radial-gradient(circle at 100% 0%, rgba(160,200,255,0.25) 0%, transparent 45%), linear-gradient(115deg, #5b3fd0 0%, #8a4fd8 50%, #d65fa8 100%)"
                    },
                    children: [(0, s.jsx)("span", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.18)_1px,transparent_1.5px)] bg-[length:14px_14px] [mask-image:linear-gradient(to_left,black,transparent_75%)]"
                    }), (0, s.jsxs)("span", {
                        "data-art": !0,
                        "aria-hidden": !0,
                        className: "relative h-[86px] w-[106px] shrink-0 @lg:h-[104px] @lg:w-[140px]",
                        children: [(0, s.jsx)(k.T, {
                            name: "stamp",
                            className: "bottom-1 left-0 w-[40px] -rotate-[12deg] group-hover:-translate-x-1 group-hover:-rotate-[15deg] @lg:w-[52px]"
                        }), (0, s.jsx)(k.T, {
                            name: "firki",
                            className: "bottom-0 right-0 w-[36px] rotate-[10deg] group-hover:translate-x-1 group-hover:rotate-[14deg] @lg:w-[46px]"
                        }), (0, s.jsx)(k.T, {
                            name: "slam-book",
                            className: "left-1/2 top-0 z-10 w-[56px] -translate-x-1/2 rotate-3 group-hover:-translate-y-1 @lg:w-[70px]"
                        })]
                    }), (0, s.jsxs)("span", {
                        className: "relative min-w-0 flex-1 text-left",
                        children: [(0, s.jsx)("span", {
                            className: "text-[9.5px] font-semibold uppercase tracking-[0.22em] text-white/80 @lg:text-[10.5px]",
                            children: "From scratch"
                        }), (0, s.jsx)("span", {
                            className: "mt-0.5 block font-display text-[22px] leading-tight tracking-tight text-white [text-shadow:0_1px_14px_rgba(255,255,255,0.3)] @lg:text-[30px]",
                            children: "Make your own"
                        }), (0, s.jsx)("span", {
                            className: "mt-0.5 line-clamp-2 block text-[11.5px] leading-snug text-white/80 @lg:text-[13.5px]",
                            children: "A blank page for your photos, words, stickers and games."
                        })]
                    }), (0, s.jsxs)("span", {
                        "aria-hidden": !0,
                        className: "relative inline-flex shrink-0 items-center gap-2 transition duration-200 group-hover:translate-x-0.5 motion-reduce:transition-none",
                        children: [(0, s.jsx)("span", {
                            className: "hidden text-[13px] font-semibold text-white @lg:inline",
                            children: "Explore"
                        }), (0, s.jsx)("img", {
                            src: "/ui/arrow-go-v1.webp",
                            alt: "",
                            decoding: "async",
                            className: "size-9 drop-shadow-[0_6px_10px_rgba(0,0,0,0.25)] @lg:size-10"
                        })]
                    })]
                })
            }
            var $ = t(36037);
            let z = "pt-5! pb-2.5! [&_[data-art]]:[zoom:0.8] [&_[data-chips]]:hidden",
                E = "w-[84%] shrink-0 snap-start sm:w-[calc(50%-6px)]";

            function T({
                miniCount: e,
                className: a = "",
                wide: t = !0
            }) {
                let r = `no-scrollbar flex snap-x snap-mandatory gap-2.5 overflow-x-auto pb-1 sm:gap-3 ${t?"-mx-4 scroll-px-4 px-4 sm:mx-0 sm:scroll-px-0 sm:px-0":""}`;
                return (0, s.jsxs)("div", {
                    className: `min-w-0 space-y-2.5 sm:space-y-3 ${a}`,
                    children: [(0, s.jsxs)(n.AutoSwipeRow, {
                        className: r,
                        children: [(0, s.jsx)(b, {
                            className: `${E} ${z}`
                        }), (0, s.jsx)(x, {
                            className: `${E} ${z}`
                        }), (0, s.jsx)(y, {
                            className: `${E} ${z}`
                        }), (0, s.jsx)(N, {
                            className: `${E} ${z}`
                        })]
                    }), (0, s.jsx)($.u, {
                        count: e
                    })]
                })
            }
        }
    }
]);