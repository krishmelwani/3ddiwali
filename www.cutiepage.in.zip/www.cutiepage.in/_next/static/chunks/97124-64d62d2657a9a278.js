(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [97124], {
        46648: (e, s, r) => {
            "use strict";
            r.d(s, {
                $Y: () => j,
                CF: () => o,
                GO: () => T,
                LX: () => L,
                S7: () => N,
                UV: () => v,
                VV: () => P,
                WL: () => C,
                WR: () => M,
                bV: () => k,
                dI: () => g,
                e$: () => S,
                g_: () => u,
                i7: () => x,
                j1: () => w,
                jJ: () => V,
                kT: () => E,
                mJ: () => c,
                o3: () => Z,
                oV: () => p,
                pe: () => b,
                pq: () => f,
                sU: () => n,
                sy: () => m,
                xu: () => y,
                yX: () => $
            });
            var a = r(73365);
            let l = e => `var(--prsd-${e})`;

            function t({
                fill: e
            }) {
                return (0, a.jsx)("path", {
                    d: "M12 0 C13 8 16 11 24 12 C16 13 13 16 12 24 C11 16 8 13 0 12 C8 11 11 8 12 0 Z",
                    fill: e
                })
            }
            let i = [
                    [8, 14, 16, "spark"],
                    [88, 10, 12, "spark"],
                    [16, 46, 7, "dot"],
                    [92, 38, 8, "dot"],
                    [6, 74, 12, "spark"],
                    [84, 70, 14, "spark"],
                    [50, 6, 6, "dot"],
                    [70, 88, 7, "dot"]
                ],
                d = ["sun", "accent", "coral"];

            function n() {
                return (0, a.jsx)("span", {
                    className: "prsd-sparkles",
                    "aria-hidden": !0,
                    children: i.map(([e, s, r, i], n) => (0, a.jsx)("span", {
                        className: "prsd-spark",
                        style: {
                            left: `${e}%`,
                            top: `${s}%`,
                            width: r,
                            height: r,
                            "--i": n
                        },
                        children: "spark" === i ? (0, a.jsx)("svg", {
                            viewBox: "0 0 24 24",
                            className: "block size-full",
                            children: (0, a.jsx)(t, {
                                fill: l(d[n % 3])
                            })
                        }) : (0, a.jsx)("i", {
                            className: "prsd-dot",
                            style: {
                                background: l(d[(n + 1) % 3])
                            }
                        })
                    }, n))
                })
            }

            function c({
                className: e = ""
            }) {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 120 16",
                    "aria-hidden": !0,
                    className: `prsd-squiggle ${e}`,
                    children: (0, a.jsx)("path", {
                        className: "prsd-draw",
                        pathLength: 1,
                        d: "M2 10 C12 2 20 2 30 8 C40 14 48 14 58 8 C68 2 76 2 86 8 C96 14 104 14 118 6",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "2.5",
                        strokeLinecap: "round"
                    })
                })
            }

            function p({
                className: e = "",
                fill: s = "var(--prsd-coral)"
            }) {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 24 22",
                    "aria-hidden": !0,
                    className: e,
                    children: (0, a.jsx)("path", {
                        d: "M12 21 C5 16 1 12 1 7.2 C1 3.8 3.6 1.2 6.8 1.2 C9 1.2 10.9 2.4 12 4.3 C13.1 2.4 15 1.2 17.2 1.2 C20.4 1.2 23 3.8 23 7.2 C23 12 19 16 12 21 Z",
                        fill: s
                    })
                })
            }

            function o() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 40 40",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "40",
                        height: "40",
                        rx: "11",
                        fill: "var(--f-accent)"
                    }), (0, a.jsx)("path", {
                        d: "M10 15 L20 10 L30 15 L30 27 L20 32 L10 27 Z",
                        fill: l("sun")
                    }), (0, a.jsx)("path", {
                        d: "M10 15 L20 20 L30 15 M20 20 L20 32",
                        fill: "none",
                        stroke: l("parcel-dark"),
                        strokeWidth: "1.6",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("path", {
                        d: "M20 18.4 C17.6 16.6 16.4 15.4 16.4 14 C16.4 12.9 17.3 12.1 18.3 12.1 C19 12.1 19.6 12.5 20 13.1 C20.4 12.5 21 12.1 21.7 12.1 C22.7 12.1 23.6 12.9 23.6 14 C23.6 15.4 22.4 16.6 20 18.4 Z",
                        fill: l("coral")
                    })]
                })
            }

            function h({
                side: e
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "100",
                        height: "100",
                        fill: l("parcel")
                    }), "top" === e ? (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("rect", {
                            x: "40",
                            width: "20",
                            height: "100",
                            fill: l("sun"),
                            opacity: "0.92"
                        }), (0, a.jsx)("rect", {
                            y: "40",
                            width: "100",
                            height: "20",
                            fill: l("sun"),
                            opacity: "0.92"
                        })]
                    }) : (0, a.jsx)("rect", {
                        x: "40",
                        width: "20",
                        height: "100",
                        fill: l("sun"),
                        opacity: "0.92"
                    }), "front" === e ? (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("rect", {
                            x: "14",
                            y: "58",
                            width: "34",
                            height: "26",
                            rx: "4",
                            fill: "#ffffff"
                        }), (0, a.jsx)("rect", {
                            x: "19",
                            y: "64",
                            width: "18",
                            height: "3",
                            rx: "1.5",
                            fill: l("parcel-dark"),
                            opacity: "0.5"
                        }), (0, a.jsx)("rect", {
                            x: "19",
                            y: "71",
                            width: "24",
                            height: "3",
                            rx: "1.5",
                            fill: l("parcel-dark"),
                            opacity: "0.35"
                        }), (0, a.jsx)("path", {
                            d: "M50 46 C44 41.5 41 38.5 41 35 C41 32.4 43 30.4 45.5 30.4 C47.4 30.4 49 31.4 50 33 C51 31.4 52.6 30.4 54.5 30.4 C57 30.4 59 32.4 59 35 C59 38.5 56 41.5 50 46 Z",
                            fill: l("coral")
                        })]
                    }) : null]
                })
            }

            function f() {
                return (0, a.jsxs)("span", {
                    className: "prsd-cube prsd-parcel-cube",
                    "aria-hidden": !0,
                    children: [(0, a.jsx)("span", {
                        className: "prsd-face prsd-f-front",
                        children: (0, a.jsx)(h, {
                            side: "front"
                        })
                    }), (0, a.jsx)("span", {
                        className: "prsd-face prsd-f-back prsd-shade-2",
                        children: (0, a.jsx)(h, {
                            side: "side"
                        })
                    }), (0, a.jsx)("span", {
                        className: "prsd-face prsd-f-right prsd-shade-1",
                        children: (0, a.jsx)(h, {
                            side: "side"
                        })
                    }), (0, a.jsx)("span", {
                        className: "prsd-face prsd-f-left prsd-shade-1",
                        children: (0, a.jsx)(h, {
                            side: "side"
                        })
                    }), (0, a.jsx)("span", {
                        className: "prsd-face prsd-f-top prsd-shade-0",
                        children: (0, a.jsx)(h, {
                            side: "top"
                        })
                    }), (0, a.jsx)("span", {
                        className: "prsd-face prsd-f-bottom prsd-shade-2",
                        children: (0, a.jsx)(h, {
                            side: "side"
                        })
                    })]
                })
            }

            function x() {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 320 12",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block h-[12px] w-full",
                    children: (0, a.jsx)("path", {
                        d: "M0 0 H320 V2 L310 12 L300 2 L290 12 L280 2 L270 12 L260 2 L250 12 L240 2 L230 12 L220 2 L210 12 L200 2 L190 12 L180 2 L170 12 L160 2 L150 12 L140 2 L130 12 L120 2 L110 12 L100 2 L90 12 L80 2 L70 12 L60 2 L50 12 L40 2 L30 12 L20 2 L10 12 L0 2 Z",
                        fill: "var(--f-surface)"
                    })
                })
            }
            let u = ["heart", "star", "ticket"];

            function j({
                kind: e
            }) {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 64 64",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: "heart" === e ? (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("path", {
                            d: "M32 56 C14 44 5 34 5 22 C5 13 12 6 20.5 6 C25.6 6 29.6 8.6 32 12.8 C34.4 8.6 38.4 6 43.5 6 C52 6 59 13 59 22 C59 34 50 44 32 56 Z",
                            fill: l("coral")
                        }), (0, a.jsx)("path", {
                            d: "M15 20 C16 15 19 12.5 23 12",
                            fill: "none",
                            stroke: "#ffffff",
                            strokeWidth: "4",
                            strokeLinecap: "round",
                            opacity: "0.7"
                        })]
                    }) : "star" === e ? (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("path", {
                            d: "M32 4 L39.6 21.6 L58.6 23.2 L44.2 35.8 L48.6 54.4 L32 44.6 L15.4 54.4 L19.8 35.8 L5.4 23.2 L24.4 21.6 Z",
                            fill: l("sun"),
                            strokeLinejoin: "round"
                        }), (0, a.jsx)("path", {
                            d: "M24 26 L28 25.6",
                            stroke: "#ffffff",
                            strokeWidth: "4",
                            strokeLinecap: "round",
                            opacity: "0.75"
                        })]
                    }) : (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("path", {
                            d: "M6 16 H58 V26 A6 6 0 0 0 58 38 V48 H6 V38 A6 6 0 0 0 6 26 Z",
                            fill: "var(--f-accent)",
                            transform: "rotate(-8 32 32)"
                        }), (0, a.jsx)("path", {
                            d: "M40 18 V46",
                            stroke: "#ffffff",
                            strokeWidth: "2.5",
                            strokeDasharray: "3 4",
                            transform: "rotate(-8 32 32)",
                            opacity: "0.8"
                        }), (0, a.jsx)("path", {
                            d: "M23 36.5 C18.6 33.2 16.4 31 16.4 28.4 C16.4 26.4 18 24.8 20 24.8 C21.4 24.8 22.4 25.6 23 26.6 C23.6 25.6 24.6 24.8 26 24.8 C28 24.8 29.6 26.4 29.6 28.4 C29.6 31 27.4 33.2 23 36.5 Z",
                            fill: "#ffffff",
                            transform: "rotate(-8 32 32)"
                        })]
                    })
                })
            }

            function m() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 220 170",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("ellipse", {
                        cx: "110",
                        cy: "162",
                        rx: "92",
                        ry: "8",
                        fill: "var(--f-fg)",
                        opacity: "0.08"
                    }), (0, a.jsx)("g", {
                        className: "prsd-ob-flap prsd-ob-flap-l",
                        children: (0, a.jsx)("path", {
                            d: "M24 58 L104 58 L82 14 L6 22 Z",
                            fill: l("parcel-dark")
                        })
                    }), (0, a.jsx)("g", {
                        className: "prsd-ob-flap prsd-ob-flap-r",
                        children: (0, a.jsx)("path", {
                            d: "M116 58 L196 58 L214 22 L138 14 Z",
                            fill: l("parcel-dark")
                        })
                    }), (0, a.jsx)("path", {
                        d: "M24 58 H196 L190 70 H30 Z",
                        fill: l("parcel-deep")
                    }), (0, a.jsx)("path", {
                        d: "M24 64 H196 V150 Q196 158 188 158 H32 Q24 158 24 150 Z",
                        fill: l("parcel")
                    }), (0, a.jsx)("rect", {
                        x: "24",
                        y: "64",
                        width: "172",
                        height: "10",
                        fill: l("parcel-dark"),
                        opacity: "0.35"
                    }), (0, a.jsx)("g", {
                        className: "prsd-ob-tape",
                        children: (0, a.jsx)("rect", {
                            x: "94",
                            y: "60",
                            width: "32",
                            height: "56",
                            rx: "2",
                            fill: l("sun"),
                            opacity: "0.95"
                        })
                    }), (0, a.jsx)("rect", {
                        x: "40",
                        y: "118",
                        width: "46",
                        height: "26",
                        rx: "5",
                        fill: "#ffffff",
                        opacity: "0.9"
                    }), (0, a.jsx)("rect", {
                        x: "46",
                        y: "125",
                        width: "26",
                        height: "3.5",
                        rx: "1.75",
                        fill: l("parcel-dark"),
                        opacity: "0.55"
                    }), (0, a.jsx)("rect", {
                        x: "46",
                        y: "133",
                        width: "34",
                        height: "3.5",
                        rx: "1.75",
                        fill: l("parcel-dark"),
                        opacity: "0.35"
                    }), (0, a.jsx)("path", {
                        d: "M160 140 C152 134 148 130 148 125.5 C148 122.4 150.4 120 153.4 120 C155.6 120 157.2 121.2 158.2 123 C159.2 121.2 160.8 120 163 120 C166 120 168.4 122.4 168.4 125.5 C168.4 130 164.4 134 160 140 Z",
                        fill: l("coral")
                    })]
                })
            }

            function g() {
                return (0, a.jsxs)("g", {
                    "aria-hidden": !0,
                    children: [(0, a.jsx)("rect", {
                        width: "320",
                        height: "300",
                        rx: "22",
                        fill: l("map")
                    }), (0, a.jsx)("path", {
                        d: "M-10 120 C60 100 90 150 160 130 C220 112 260 150 330 128 L330 150 C260 172 220 134 160 152 C90 172 60 122 -10 142 Z",
                        fill: "var(--f-accent)",
                        opacity: "0.16"
                    }), (0, a.jsx)("rect", {
                        x: "18",
                        y: "20",
                        width: "70",
                        height: "56",
                        rx: "10",
                        fill: l("block")
                    }), (0, a.jsx)("rect", {
                        x: "104",
                        y: "20",
                        width: "96",
                        height: "40",
                        rx: "10",
                        fill: l("block")
                    }), (0, a.jsx)("rect", {
                        x: "216",
                        y: "160",
                        width: "86",
                        height: "56",
                        rx: "10",
                        fill: l("block")
                    }), (0, a.jsx)("rect", {
                        x: "20",
                        y: "176",
                        width: "64",
                        height: "40",
                        rx: "10",
                        fill: l("block")
                    }), (0, a.jsx)("rect", {
                        x: "104",
                        y: "232",
                        width: "80",
                        height: "50",
                        rx: "10",
                        fill: l("block")
                    }), (0, a.jsx)("ellipse", {
                        cx: "248",
                        cy: "58",
                        rx: "46",
                        ry: "30",
                        fill: l("leaf"),
                        opacity: "0.28"
                    }), (0, a.jsx)("circle", {
                        cx: "232",
                        cy: "52",
                        r: "7",
                        fill: l("leaf"),
                        opacity: "0.55"
                    }), (0, a.jsx)("circle", {
                        cx: "262",
                        cy: "62",
                        r: "9",
                        fill: l("leaf"),
                        opacity: "0.55"
                    }), (0, a.jsx)("path", {
                        d: "M0 96 H320 M96 0 V300 M0 224 H320 M206 0 V300",
                        stroke: "var(--f-surface)",
                        strokeWidth: "9",
                        opacity: "0.9"
                    })]
                })
            }
            let v = {
                    start: [40, 262],
                    stops: [
                        [112, 196],
                        [204, 222],
                        [196, 120]
                    ],
                    door: [262, 78]
                },
                N = ["M40 262 C60 230 84 214 112 196", "M112 196 C140 178 176 236 204 222", "M204 222 C232 208 172 150 196 120", "M196 120 C214 100 240 96 262 78"];

            function k() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 64 48",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("rect", {
                        x: "4",
                        y: "10",
                        width: "20",
                        height: "18",
                        rx: "3",
                        fill: l("parcel")
                    }), (0, a.jsx)("rect", {
                        x: "12",
                        y: "10",
                        width: "4",
                        height: "18",
                        fill: l("sun")
                    }), (0, a.jsx)("path", {
                        d: "M8 34 C8 26 14 26 22 26 H40 L46 12 H52 L46 30 C50 30 54 32 56 36 Z",
                        fill: "var(--f-accent)"
                    }), (0, a.jsx)("path", {
                        d: "M44 12 H54",
                        stroke: "var(--f-fg)",
                        strokeWidth: "3.5",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("circle", {
                        cx: "16",
                        cy: "38",
                        r: "7.5",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("circle", {
                        cx: "16",
                        cy: "38",
                        r: "3",
                        fill: "var(--f-surface)"
                    }), (0, a.jsx)("circle", {
                        cx: "50",
                        cy: "38",
                        r: "7.5",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("circle", {
                        cx: "50",
                        cy: "38",
                        r: "3",
                        fill: "var(--f-surface)"
                    }), (0, a.jsx)("path", {
                        d: "M30 22 C27.4 20 26 18.6 26 16.9 C26 15.6 27 14.6 28.3 14.6 C29 14.6 29.6 15 30 15.6 C30.4 15 31 14.6 31.7 14.6 C33 14.6 34 15.6 34 16.9 C34 18.6 32.6 20 30 22 Z",
                        fill: l("coral")
                    })]
                })
            }

            function y() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 40 50",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("ellipse", {
                        cx: "20",
                        cy: "47",
                        rx: "8",
                        ry: "3",
                        fill: "var(--f-fg)",
                        opacity: "0.18"
                    }), (0, a.jsx)("path", {
                        d: "M20 46 C10 34 4 26 4 18 C4 9 11 2 20 2 C29 2 36 9 36 18 C36 26 30 34 20 46 Z",
                        fill: l("coral")
                    }), (0, a.jsx)("path", {
                        d: "M20 24.5 C15.6 21.2 13.4 19 13.4 16.4 C13.4 14.4 15 12.8 17 12.8 C18.4 12.8 19.4 13.6 20 14.6 C20.6 13.6 21.6 12.8 23 12.8 C25 12.8 26.6 14.4 26.6 16.4 C26.6 19 24.4 21.2 20 24.5 Z",
                        fill: "#ffffff"
                    })]
                })
            }

            function C() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 220 260",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("rect", {
                        x: "20",
                        y: "8",
                        width: "180",
                        height: "244",
                        rx: "14",
                        fill: "var(--f-surface)"
                    }), (0, a.jsx)("rect", {
                        x: "34",
                        y: "22",
                        width: "152",
                        height: "230",
                        rx: "6",
                        fill: l("sun"),
                        opacity: "0.35"
                    }), (0, a.jsx)("path", {
                        d: "M34 252 V200 H186 V252 Z",
                        fill: l("sun"),
                        opacity: "0.25"
                    }), (0, a.jsx)("rect", {
                        x: "62",
                        y: "186",
                        width: "96",
                        height: "62",
                        rx: "6",
                        fill: l("parcel")
                    }), (0, a.jsx)("rect", {
                        x: "102",
                        y: "186",
                        width: "16",
                        height: "62",
                        fill: l("sun")
                    }), (0, a.jsx)("path", {
                        d: "M86 214 C80 209.5 77 206.5 77 203 C77 200.4 79 198.4 81.5 198.4 C83.4 198.4 85 199.4 86 201 C87 199.4 88.6 198.4 90.5 198.4 C93 198.4 95 200.4 95 203 C95 206.5 92 209.5 86 214 Z",
                        fill: l("coral")
                    }), (0, a.jsx)("rect", {
                        x: "0",
                        y: "250",
                        width: "220",
                        height: "10",
                        rx: "5",
                        fill: "var(--f-fg)",
                        opacity: "0.12"
                    })]
                })
            }

            function L() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 152 230",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "152",
                        height: "230",
                        rx: "6",
                        fill: "var(--f-accent)"
                    }), (0, a.jsx)("rect", {
                        x: "18",
                        y: "18",
                        width: "116",
                        height: "80",
                        rx: "8",
                        fill: "#ffffff",
                        opacity: "0.18"
                    }), (0, a.jsx)("rect", {
                        x: "18",
                        y: "114",
                        width: "116",
                        height: "96",
                        rx: "8",
                        fill: "#000000",
                        opacity: "0.1"
                    }), (0, a.jsx)("path", {
                        d: "M76 70 C66 62.4 61 57.4 61 51.6 C61 47.2 64.4 43.8 68.6 43.8 C71.8 43.8 74.4 45.6 76 48.4 C77.6 45.6 80.2 43.8 83.4 43.8 C87.6 43.8 91 47.2 91 51.6 C91 57.4 86 62.4 76 70 Z",
                        fill: l("coral")
                    }), (0, a.jsx)("circle", {
                        cx: "128",
                        cy: "124",
                        r: "7",
                        fill: l("sun")
                    })]
                })
            }

            function b() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 48 48",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("path", {
                        d: "M24 6 C15 6 11 13 11 21 V29 L7 35 H41 L37 29 V21 C37 13 33 6 24 6 Z",
                        fill: l("sun")
                    }), (0, a.jsx)("path", {
                        d: "M17 18 C18 13 20.5 11 24 10.6",
                        fill: "none",
                        stroke: "#ffffff",
                        strokeWidth: "3",
                        strokeLinecap: "round",
                        opacity: "0.7"
                    }), (0, a.jsx)("circle", {
                        cx: "24",
                        cy: "40",
                        r: "4.5",
                        fill: l("coral")
                    })]
                })
            }

            function M() {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 200 200",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: (0, a.jsxs)("g", {
                        fill: l("sun"),
                        children: [(0, a.jsx)("path", {
                            d: "M100 100 L88 0 H112 Z"
                        }), (0, a.jsx)("path", {
                            d: "M100 100 L170 18 L184 34 Z"
                        }), (0, a.jsx)("path", {
                            d: "M100 100 L200 88 V112 Z"
                        }), (0, a.jsx)("path", {
                            d: "M100 100 L30 18 L16 34 Z"
                        }), (0, a.jsx)("path", {
                            d: "M100 100 L0 88 V112 Z"
                        }), (0, a.jsx)("path", {
                            d: "M100 100 L148 6 L166 14 Z"
                        }), (0, a.jsx)("path", {
                            d: "M100 100 L52 6 L34 14 Z"
                        })]
                    })
                })
            }

            function w() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 84",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("rect", {
                        x: "4",
                        y: "6",
                        width: "112",
                        height: "76",
                        rx: "10",
                        fill: "var(--f-surface)"
                    }), (0, a.jsx)("path", {
                        d: "M6 12 L60 50 L114 12",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "3",
                        strokeLinejoin: "round",
                        opacity: "0.5"
                    }), (0, a.jsx)("path", {
                        d: "M60 52 C53 46.8 49.6 43.4 49.6 39.4 C49.6 36.4 52 34 55 34 C57.2 34 58.9 35.2 60 37.1 C61.1 35.2 62.8 34 65 34 C68 34 70.4 36.4 70.4 39.4 C70.4 43.4 67 46.8 60 52 Z",
                        fill: l("coral")
                    })]
                })
            }

            function $({
                kind: e
            }) {
                return "Gift Red" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    preserveAspectRatio: "xMidYMid slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "100",
                        height: "100",
                        fill: l("coral")
                    }), [
                        [14, 14],
                        [50, 14],
                        [86, 14],
                        [32, 38],
                        [68, 38],
                        [14, 62],
                        [50, 62],
                        [86, 62],
                        [32, 86],
                        [68, 86]
                    ].map(([e, s]) => (0, a.jsx)("circle", {
                        cx: e,
                        cy: s,
                        r: "5",
                        fill: "#ffffff",
                        opacity: "0.85"
                    }, `${e}-${s}`))]
                }) : "Holo" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    preserveAspectRatio: "xMidYMid slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "100",
                        height: "100",
                        fill: "var(--f-accent)"
                    }), (0, a.jsx)("path", {
                        d: "M0 0 H60 L0 60 Z",
                        fill: l("coral"),
                        opacity: "0.85"
                    }), (0, a.jsx)("path", {
                        d: "M100 100 H36 L100 36 Z",
                        fill: l("sun"),
                        opacity: "0.85"
                    }), (0, a.jsx)("path", {
                        d: "M-10 70 L70 -10 L84 4 L4 84 Z",
                        fill: "#ffffff",
                        opacity: "0.28"
                    }), (0, a.jsx)("path", {
                        d: "M30 110 L110 30 L116 36 L36 116 Z",
                        fill: "#ffffff",
                        opacity: "0.22"
                    })]
                }) : (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    preserveAspectRatio: "xMidYMid slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "100",
                        height: "100",
                        fill: l("parcel")
                    }), (0, a.jsx)("path", {
                        d: "M14 30 L20 22 L26 30 M20 22 V40",
                        fill: "none",
                        stroke: l("parcel-deep"),
                        strokeWidth: "2.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        opacity: "0.5"
                    }), (0, a.jsx)("path", {
                        d: "M74 70 L80 62 L86 70 M80 62 V80",
                        fill: "none",
                        stroke: l("parcel-deep"),
                        strokeWidth: "2.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        opacity: "0.5"
                    }), (0, a.jsx)("rect", {
                        x: "12",
                        y: "62",
                        width: "34",
                        height: "22",
                        rx: "3",
                        fill: "#ffffff",
                        opacity: "0.8"
                    })]
                })
            }

            function S({
                kind: e
            }) {
                let s = [12, 36, 60, 84, 108, 132, 156, 180];
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 36 200",
                    preserveAspectRatio: "xMidYMin slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "36",
                        height: "200",
                        fill: l("sun"),
                        opacity: "0.95"
                    }), (0, a.jsx)("rect", {
                        x: "4",
                        width: "3",
                        height: "200",
                        fill: "#ffffff",
                        opacity: "0.35"
                    }), "Hearts" === e ? s.map(e => (0, a.jsx)("path", {
                        d: `M18 ${e+8} C13 ${e+4.4} 10.6 ${e+2} 10.6 ${e-.8} C10.6 ${e-3} 12.4 ${e-4.8} 14.6 ${e-4.8} C16.1 ${e-4.8} 17.3 ${e-4} 18 ${e-2.8} C18.7 ${e-4} 19.9 ${e-4.8} 21.4 ${e-4.8} C23.6 ${e-4.8} 25.4 ${e-3} 25.4 ${e-.8} C25.4 ${e+2} 23 ${e+4.4} 18 ${e+8} Z`,
                        fill: l("coral")
                    }, e)) : "Stars" === e ? s.map(e => (0, a.jsx)("path", {
                        d: `M18 ${e-7} L20.1 ${e-2.1} L25.4 ${e-1.6} L21.4 ${e+1.9} L22.6 ${e+7} L18 ${e+4.3} L13.4 ${e+7} L14.6 ${e+1.9} L10.6 ${e-1.6} L15.9 ${e-2.1} Z`,
                        fill: "#ffffff"
                    }, e)) : null]
                })
            }
            let R = {
                    back: ["M150 196 C122 178 92 164 66 128", "M150 172 C184 152 214 140 240 106", "M150 140 C136 112 112 92 96 70"],
                    mid: ["M150 266 C147 228 156 196 150 150", "M150 204 C130 188 110 176 92 150", "M150 180 C170 164 192 152 212 128", "M150 152 C140 124 132 102 120 78", "M150 152 C162 126 172 106 186 82", "M150 150 C150 122 150 98 152 62"],
                    front: ["M150 218 C176 204 204 192 228 166", "M150 188 C126 172 102 152 84 114"]
                },
                Z = {
                    back: [
                        [66, 126],
                        [240, 104],
                        [96, 68],
                        [196, 140],
                        [80, 98]
                    ],
                    mid: [
                        [92, 148],
                        [212, 126],
                        [120, 76],
                        [186, 80],
                        [152, 58],
                        [132, 112],
                        [172, 112]
                    ],
                    front: [
                        [228, 164],
                        [84, 112],
                        [204, 190],
                        [108, 150]
                    ]
                },
                B = {
                    back: [
                        [110, 160, -30],
                        [214, 128, 30]
                    ],
                    mid: [
                        [104, 166, -40],
                        [198, 146, 40],
                        [138, 96, -20],
                        [174, 98, 24]
                    ],
                    front: [
                        [212, 184, 30],
                        [96, 134, -36]
                    ]
                };

            function V({
                plane: e
            }) {
                let s = "mid" === e ? 9 : "back" === e ? 5 : 6;
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 300 300",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [R[e].map((r, t) => (0, a.jsx)("path", {
                        className: "prsd-branch",
                        style: {
                            "--i": t
                        },
                        pathLength: 1,
                        d: r,
                        fill: "none",
                        stroke: l("bark"),
                        strokeWidth: "mid" === e && 0 === t ? 14 : s,
                        strokeLinecap: "round"
                    }, r)), B[e].map(([e, s, r]) => (0, a.jsx)("ellipse", {
                        className: "prsd-leaf",
                        cx: e,
                        cy: s,
                        rx: "9",
                        ry: "4.5",
                        fill: l("leaf"),
                        transform: `rotate(${r} ${e} ${s})`
                    }, `${e}-${s}`))]
                })
            }
            let E = {
                "Sakura Pink": ["#ffb3cb", "#ff86ad"],
                Coral: ["var(--prsd-coral)", "var(--prsd-coral-deep)"],
                Lilac: ["#cdb4ff", "#a985ff"]
            };

            function P({
                kind: e
            }) {
                let [s, r] = E[e] ? ? E["Sakura Pink"];
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 40 38",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("path", {
                        d: "M20 36 C8 28 2 21 2 13 C2 7 6.6 2.4 12.4 2.4 C15.8 2.4 18.4 4.2 20 7 C21.6 4.2 24.2 2.4 27.6 2.4 C33.4 2.4 38 7 38 13 C38 21 32 28 20 36 Z",
                        fill: r
                    }), (0, a.jsx)("path", {
                        d: "M20 31 C11.6 25 7.4 19.6 7.4 14 C7.4 10 10.4 7.2 14 7.2 C16.6 7.2 18.6 8.6 20 10.8 C21.4 8.6 23.4 7.2 26 7.2 C29.6 7.2 32.6 10 32.6 14 C32.6 19.6 28.4 25 20 31 Z",
                        fill: s
                    }), (0, a.jsx)("circle", {
                        cx: "20",
                        cy: "17",
                        r: "3.2",
                        fill: l("sun")
                    }), (0, a.jsx)("path", {
                        d: "M11 12 C12 9.6 13.6 8.6 15.6 8.4",
                        fill: "none",
                        stroke: "#ffffff",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        opacity: "0.8"
                    })]
                })
            }
            let T = [
                [8, 12, 24, 6.2],
                [18, 9, -18, 7.4],
                [27, 14, 30, 5.6],
                [36, 10, -26, 6.8],
                [45, 12, 20, 7.8],
                [53, 9, -14, 6],
                [61, 13, 28, 7],
                [70, 10, -22, 5.8],
                [78, 12, 18, 6.6],
                [86, 9, -30, 7.6],
                [93, 11, 16, 6.4],
                [14, 10, 26, 8],
                [58, 11, -20, 8.2],
                [82, 13, 22, 5.4]
            ]
        },
        59860: () => {},
        97124: (e, s, r) => {
            "use strict";
            r.r(s), r.d(s, {
                DeliveredStamp: () => M,
                Doorbell: () => v,
                ETA_MIN: () => m,
                LiveTrack: () => g,
                LoveTree: () => b,
                OPEN_BEATS: () => h,
                OpeningSequence: () => f,
                OrderSlip: () => x,
                PackBox: () => j,
                RETURN_HOPS: () => y,
                ReturnDodge: () => C,
                SLICE_PX: () => N,
                Unboxing: () => k
            });
            var a = r(73365),
                l = r(1521),
                t = r(87191),
                i = r(34768),
                d = r(82161),
                n = r(46648);

            function c() {
                let e = (0, i.useStory)(),
                    s = (0, i.useSectionIndex)();
                return !e.active || e.index === s
            }

            function p() {
                let e = (0, l.useRef)([]);
                return (0, l.useEffect)(() => {
                    let s = e.current;
                    return () => s.forEach(clearTimeout)
                }, []), (s, r) => {
                    e.current.push(setTimeout(s, r))
                }
            }
            r(59860);
            let o = e => e ? "" : void 0,
                h = [250, 1300, 3100, 4700];

            function f({
                notice: e,
                media: s,
                stickers: r,
                skip: p,
                children: x
            }) {
                let u = "edit" === (0, i.useMode)(),
                    j = (0, t.usePrefersReducedMotion)(),
                    m = c(),
                    g = (0, d.useSoundEffect)(),
                    v = (0, l.useRef)(null),
                    [N, k] = (0, l.useState)(0),
                    [y, C] = (0, l.useState)(0),
                    L = u || j ? 4 : N;
                return (0, t.useReplaySignal)(v, () => {
                    k(0), C(e => e + 1)
                }), (0, l.useEffect)(() => {
                    if (u || j || !m) return;
                    let e = h.map((e, s) => setTimeout(() => {
                        k(e => Math.max(e, s + 1)), 0 === s && g("tick")
                    }, e));
                    return () => e.forEach(clearTimeout)
                }, [u, j, m, y, g]), (0, a.jsxs)("div", {
                    ref: v,
                    className: "prsd-open",
                    "data-b1": o(L >= 1),
                    "data-b2": o(L >= 2),
                    "data-b3": o(L >= 3),
                    "data-b4": o(L >= 4),
                    children: [(0, a.jsxs)("div", {
                        className: "prsd-open-stage",
                        children: [r, (0, a.jsxs)("div", {
                            className: "prsd-notify",
                            children: [(0, a.jsx)("span", {
                                className: "prsd-notify-icon",
                                children: (0, a.jsx)(n.CF, {})
                            }), (0, a.jsx)("span", {
                                className: "prsd-notify-text",
                                children: e
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "prsd-parcel-3d",
                            "aria-hidden": !0,
                            children: [(0, a.jsx)("span", {
                                className: "prsd-parcel-shadow"
                            }), (0, a.jsx)("span", {
                                className: "prsd-parcel-drop",
                                children: (0, a.jsx)("span", {
                                    className: "prsd-parcel-tilt",
                                    children: (0, a.jsx)("span", {
                                        className: "prsd-parcel-spin",
                                        children: (0, a.jsx)(n.pq, {})
                                    })
                                })
                            })]
                        }), (0, a.jsx)("div", {
                            className: "prsd-open-media",
                            children: s
                        }), u ? (0, a.jsx)("span", {
                            className: "prsd-skip",
                            children: (0, a.jsx)("span", {
                                className: "prsd-chip",
                                children: p
                            })
                        }) : L < 4 ? (0, a.jsx)("button", {
                            type: "button",
                            className: "prsd-skip",
                            onClick: () => k(4),
                            children: (0, a.jsx)("span", {
                                className: "prsd-chip",
                                children: p
                            })
                        }) : null]
                    }), (0, a.jsx)("div", {
                        className: "prsd-open-card",
                        children: x
                    })]
                })
            }

            function x({
                header: e,
                lines: s,
                paid: r,
                done: p
            }) {
                let o = "edit" === (0, i.useMode)(),
                    h = (0, t.usePrefersReducedMotion)(),
                    f = c(),
                    u = (0, d.useSoundEffect)(),
                    j = (0, l.useRef)(null),
                    [m, g] = (0, l.useState)(0),
                    v = o || h ? s.length : m,
                    N = v >= s.length;
                return (0, t.useReplaySignal)(j, () => g(0)), (0, l.useEffect)(() => {
                    if (o || h || !f || m >= s.length) return;
                    let e = setTimeout(() => {
                        g(e => e + 1), u(m + 1 >= s.length ? "win" : "tick")
                    }, 0 === m ? 700 : 620);
                    return () => clearTimeout(e)
                }, [o, h, f, m, s.length, u]), (0, a.jsxs)("div", {
                    ref: j,
                    className: "prsd-slip",
                    ...N ? {
                        "data-all": ""
                    } : {},
                    children: [(0, a.jsxs)("div", {
                        className: "prsd-receipt",
                        children: [(0, a.jsxs)("div", {
                            className: "prsd-receipt-body",
                            children: [e, (0, a.jsx)("ul", {
                                className: "prsd-items",
                                children: s.map((e, s) => (0, a.jsxs)("li", {
                                    className: "prsd-item",
                                    ...s < v ? {
                                        "data-on": ""
                                    } : {},
                                    children: [(0, a.jsx)("span", {
                                        className: "prsd-tick",
                                        "aria-hidden": !0,
                                        children: (0, a.jsx)("svg", {
                                            viewBox: "0 0 24 24",
                                            className: "block size-full",
                                            children: (0, a.jsx)("path", {
                                                className: "prsd-tick-mark",
                                                pathLength: 1,
                                                d: "M6 12.5 L10.2 16.5 L18 8",
                                                fill: "none",
                                                stroke: "currentColor",
                                                strokeWidth: "3",
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round"
                                            })
                                        })
                                    }), (0, a.jsx)("span", {
                                        className: "prsd-item-text",
                                        children: e
                                    })]
                                }, s))
                            }), (0, a.jsx)("div", {
                                className: "prsd-paid",
                                children: r
                            })]
                        }), (0, a.jsx)(n.i7, {})]
                    }), (0, a.jsx)("div", {
                        className: "prsd-after",
                        children: N ? (0, a.jsx)("div", {
                            className: o ? "" : "prsd-rise",
                            children: p
                        }) : null
                    })]
                })
            }

            function u({
                index: e,
                label: s,
                name: r,
                packed: t,
                target: d,
                onPack: c
            }) {
                var p;
                let o, h, f, x = "edit" === (0, i.useMode)(),
                    j = (p = x || t, o = (0, l.useRef)(null), h = (0, l.useRef)(!1), f = e => {
                        e.style.translate = "", delete e.dataset.dragging
                    }, {
                        onPointerDown(e) {
                            p || (o.current = {
                                id: e.pointerId,
                                x: e.clientX,
                                y: e.clientY,
                                moved: !1
                            }, e.currentTarget.setPointerCapture(e.pointerId))
                        },
                        onPointerMove(e) {
                            let s = o.current;
                            if (!s || s.id !== e.pointerId) return;
                            let r = e.clientX - s.x,
                                a = e.clientY - s.y;
                            !s.moved && 8 > Math.hypot(r, a) || (s.moved = !0, e.currentTarget.dataset.dragging = "", e.currentTarget.style.translate = `${Math.round(r)}px ${Math.round(a)}px`)
                        },
                        onPointerUp(e) {
                            let s = o.current;
                            o.current = null;
                            let r = e.currentTarget;
                            if (!s ? .moved) return;
                            h.current = !0;
                            let a = d.current ? .getBoundingClientRect();
                            a && e.clientX > a.left - 28 && e.clientX < a.right + 28 && e.clientY > a.top - 28 && e.clientY < a.bottom + 28 ? (delete r.dataset.dragging, c(r)) : f(r)
                        },
                        onPointerCancel(e) {
                            o.current = null, f(e.currentTarget)
                        },
                        onClick(e) {
                            if (h.current) {
                                h.current = !1;
                                return
                            }
                            p || c(e.currentTarget)
                        }
                    });
                return (0, a.jsxs)("li", {
                    className: "prsd-pack-slot",
                    children: [(0, a.jsx)("button", {
                        type: "button",
                        className: "prsd-pack-item",
                        "aria-label": r,
                        tabIndex: x ? -1 : void 0,
                        disabled: t,
                        ...t ? {
                            "data-packed": ""
                        } : {},
                        ...j,
                        children: (0, a.jsx)("span", {
                            className: "prsd-pack-art",
                            children: (0, a.jsx)(n.$Y, {
                                kind: n.g_[e]
                            })
                        })
                    }), (0, a.jsx)("span", {
                        className: "prsd-pack-label",
                        children: s
                    })]
                })
            }

            function j({
                labels: e,
                names: s,
                cards: r,
                hint: c,
                done: o
            }) {
                let h = "edit" === (0, i.useMode)(),
                    f = (0, d.useFolioSound)(),
                    x = p(),
                    m = (0, l.useRef)(null),
                    g = (0, l.useRef)(null),
                    [v, N] = (0, l.useState)(() => n.g_.map(() => !1)),
                    [k, y] = (0, l.useState)(null),
                    [C, L] = (0, l.useState)(!1),
                    b = v.filter(Boolean).length,
                    M = h || b === n.g_.length;
                return (0, t.useReplaySignal)(m, () => {
                    m.current ? .querySelectorAll(".prsd-pack-item").forEach(e => {
                        e.style.translate = ""
                    }), N(n.g_.map(() => !1)), y(null), L(!1)
                }), (0, a.jsxs)("div", {
                    ref: m,
                    className: "prsd-pack",
                    ...M ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsx)("ul", {
                        className: "prsd-pack-row",
                        children: n.g_.map((r, l) => (0, a.jsx)(u, {
                            index: l,
                            label: e[l],
                            name: s[l] ? ? "",
                            packed: !h && v[l],
                            target: g,
                            onPack: e => {
                                h || v[l] || (f.unlock(e), function(e, s) {
                                    if (!s) return;
                                    let r = e.getBoundingClientRect(),
                                        a = s.getBoundingClientRect();
                                    e.style.setProperty("--prsd-fx", `${Math.round(a.left+a.width/2-(r.left+r.width/2))}px`), e.style.setProperty("--prsd-fy", `${Math.round(a.top+.3*a.height-(r.top+r.height/2))}px`)
                                }(e, g.current), f.playEffect("pop"), N(e => e.map((e, s) => s === l || e)), y(l), b + 1 === n.g_.length && x(() => {
                                    L(!0), f.playEffect("rustle")
                                }, 1400))
                            }
                        }, r))
                    }), (0, a.jsx)("div", {
                        ref: g,
                        className: "prsd-pack-box",
                        ...C || h ? {
                            "data-closed": ""
                        } : {},
                        "data-bump": b % 2,
                        children: (0, a.jsx)(n.sy, {})
                    }), h ? (0, a.jsx)("div", {
                        className: "prsd-cards",
                        children: r
                    }) : null !== k ? (0, a.jsx)("div", {
                        className: "prsd-cards prsd-pop",
                        children: r[k]
                    }, k) : (0, a.jsx)("div", {
                        className: "prsd-pack-hint",
                        children: c
                    }), (0, a.jsx)("div", {
                        className: "prsd-after",
                        children: M && (C || h) ? (0, a.jsx)("div", {
                            className: h ? "" : "prsd-rise",
                            children: o
                        }) : null
                    })]
                })
            }
            let m = [8, 6, 4, 2];

            function g({
                stops: e,
                eta: s,
                unit: r,
                arrived: p,
                done: o
            }) {
                let h = "edit" === (0, i.useMode)(),
                    f = (0, t.usePrefersReducedMotion)(),
                    x = c(),
                    u = (0, d.useSoundEffect)(),
                    j = (0, l.useRef)(null),
                    [v, N] = (0, l.useState)(0),
                    k = n.S7.length,
                    y = h || f ? k : v,
                    C = 0 === y ? n.UV.start : y >= k ? n.UV.door : n.UV.stops[y - 1];
                (0, t.useReplaySignal)(j, () => N(0)), (0, l.useEffect)(() => {
                    if (h || f || !x || v >= k) return;
                    let e = setTimeout(() => {
                        N(e => e + 1), u(v + 1 >= k ? "horn" : "tick")
                    }, 0 === v ? 500 : 1300);
                    return () => clearTimeout(e)
                }, [h, f, x, v, k, u]);
                let L = y >= k;
                return (0, a.jsxs)("div", {
                    ref: j,
                    className: "prsd-track",
                    ...L ? {
                        "data-there": ""
                    } : {},
                    children: [(0, a.jsxs)("div", {
                        className: "prsd-map",
                        children: [(0, a.jsxs)("svg", {
                            viewBox: "0 0 320 300",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, a.jsx)(n.dI, {}), (0, a.jsx)("path", {
                                d: n.S7.join(" "),
                                fill: "none",
                                stroke: "var(--f-fg)",
                                strokeWidth: "3",
                                strokeDasharray: "1 9",
                                strokeLinecap: "round",
                                opacity: "0.28"
                            }), n.S7.map((e, s) => (0, a.jsx)("path", {
                                className: "prsd-leg",
                                ...s < y ? {
                                    "data-on": ""
                                } : {},
                                d: e,
                                pathLength: 1,
                                fill: "none",
                                stroke: "var(--f-accent)",
                                strokeWidth: "6",
                                strokeLinecap: "round"
                            }, e)), (0, a.jsx)("circle", {
                                cx: n.UV.start[0],
                                cy: n.UV.start[1],
                                r: "7",
                                fill: "var(--f-accent)"
                            }), (0, a.jsx)("circle", {
                                cx: n.UV.start[0],
                                cy: n.UV.start[1],
                                r: "3",
                                fill: "var(--f-surface)"
                            }), n.UV.stops.map(([e, s], r) => (0, a.jsx)("circle", {
                                className: "prsd-stop-dot",
                                ...r < y ? {
                                    "data-on": ""
                                } : {},
                                cx: e,
                                cy: s,
                                r: "6"
                            }, `${e}-${s}`)), (0, a.jsx)("g", {
                                className: "prsd-rider",
                                style: {
                                    transform: `translate(${C[0]}px, ${C[1]}px)`
                                },
                                children: (0, a.jsx)("g", {
                                    className: "prsd-rider-bob",
                                    children: (0, a.jsx)("svg", {
                                        x: "-23",
                                        y: "-36",
                                        width: "46",
                                        height: "34",
                                        viewBox: "0 0 64 48",
                                        overflow: "visible",
                                        children: (0, a.jsx)(n.bV, {})
                                    })
                                })
                            })]
                        }), (0, a.jsx)("span", {
                            className: "prsd-home-pin",
                            "aria-hidden": !0,
                            children: (0, a.jsx)(n.xu, {})
                        }), n.UV.stops.map(([s, r], l) => (0, a.jsx)("span", {
                            className: "prsd-stop-label",
                            "data-n": l,
                            style: {
                                left: `${(s/320*100).toFixed(2)}%`,
                                top: `${(r/300*100).toFixed(2)}%`
                            },
                            ...l < y ? {
                                "data-on": ""
                            } : {},
                            children: e[l]
                        }, `${s}-${r}`)), (0, a.jsx)("div", {
                            className: "prsd-eta",
                            "aria-live": "polite",
                            children: L ? (0, a.jsx)("span", {
                                className: "prsd-eta-arrived",
                                children: p
                            }) : (0, a.jsxs)(a.Fragment, {
                                children: [(0, a.jsx)("span", {
                                    className: "prsd-eta-label",
                                    children: s
                                }), (0, a.jsxs)("span", {
                                    className: "prsd-eta-time",
                                    children: [(0, a.jsx)("span", {
                                        className: "prsd-eta-num",
                                        children: m[y]
                                    }, y), " ", r]
                                })]
                            })
                        })]
                    }), (0, a.jsx)("div", {
                        className: "prsd-after",
                        children: L ? (0, a.jsx)("div", {
                            className: h ? "" : "prsd-rise",
                            children: o
                        }) : null
                    })]
                })
            }

            function v({
                ring: e,
                ding: s,
                after: r
            }) {
                let c = "edit" === (0, i.useMode)(),
                    o = (0, t.usePrefersReducedMotion)(),
                    h = (0, d.useSoundEffect)(),
                    f = p(),
                    x = (0, l.useRef)(null),
                    [u, j] = (0, l.useState)("idle"),
                    m = c ? "open" : u;
                return (0, t.useReplaySignal)(x, () => j("idle")), (0, a.jsxs)("div", {
                    ref: x,
                    className: "prsd-door",
                    "data-phase": m,
                    children: [(0, a.jsxs)("div", {
                        className: "prsd-door-stage",
                        children: [(0, a.jsx)("span", {
                            className: "prsd-door-frame",
                            children: (0, a.jsx)(n.WL, {})
                        }), (0, a.jsx)("span", {
                            className: "prsd-door-leaf",
                            children: (0, a.jsx)(n.LX, {})
                        }), "idle" !== m ? (0, a.jsx)("span", {
                            className: c ? "prsd-ding" : "prsd-ding prsd-pop",
                            children: s
                        }) : null, c ? (0, a.jsxs)("span", {
                            className: "prsd-bell",
                            children: [(0, a.jsx)("span", {
                                className: "prsd-bell-face",
                                children: (0, a.jsx)(n.pe, {})
                            }), (0, a.jsx)("span", {
                                className: "prsd-bell-label",
                                children: e
                            })]
                        }) : (0, a.jsxs)("button", {
                            type: "button",
                            className: "prsd-bell",
                            onClick: () => {
                                c || "idle" !== u || (j("ringing"), h("jingle"), f(() => {
                                    j("open"), h("open")
                                }, 1100 * !o))
                            },
                            disabled: "idle" !== u,
                            ..."idle" === u ? {
                                "data-ready": ""
                            } : {},
                            children: [(0, a.jsx)("span", {
                                className: "prsd-bell-face",
                                children: (0, a.jsx)(n.pe, {})
                            }), (0, a.jsx)("span", {
                                className: "prsd-bell-label",
                                children: e
                            })]
                        })]
                    }), (0, a.jsx)("div", {
                        className: "prsd-after",
                        children: "open" === m ? (0, a.jsx)("div", {
                            className: c ? "" : "prsd-rise prsd-rise-late",
                            children: r
                        }) : null
                    })]
                })
            }
            let N = 140;

            function k({
                wrap: e,
                tape: s,
                cut: r,
                hint: c,
                done: o
            }) {
                let h = "edit" === (0, i.useMode)(),
                    f = (0, t.usePrefersReducedMotion)(),
                    x = (0, d.useSoundEffect)(),
                    u = p(),
                    j = (0, l.useRef)(null),
                    m = (0, l.useRef)(null),
                    g = (0, l.useRef)(null),
                    [v, y] = (0, l.useState)("closed"),
                    C = h ? "risen" : v,
                    L = e => m.current ? .style.setProperty("--prsd-cut", e.toFixed(3));
                (0, t.useReplaySignal)(j, () => {
                    y("closed"), L(0)
                });
                let b = () => {
                        h || "closed" !== v || (L(1), y("cut"), x("cut"), u(() => {
                            y("open"), x("reveal")
                        }, 380 * !f), u(() => {
                            y("risen"), x("win")
                        }, 1500 * !f))
                    },
                    M = (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsxs)("span", {
                            className: "prsd-face prsd-f-front prsd-wrap",
                            children: [e, (0, a.jsx)("span", {
                                className: "prsd-front-tape",
                                children: s
                            })]
                        }), (0, a.jsx)("span", {
                            className: "prsd-face prsd-f-back prsd-wrap prsd-shade-2",
                            children: e
                        }), (0, a.jsx)("span", {
                            className: "prsd-face prsd-f-right prsd-wrap prsd-shade-1",
                            children: e
                        }), (0, a.jsx)("span", {
                            className: "prsd-face prsd-f-left prsd-wrap prsd-shade-1",
                            children: e
                        }), (0, a.jsx)("span", {
                            className: "prsd-face prsd-f-bottom prsd-shade-3"
                        })]
                    });
                return (0, a.jsxs)("div", {
                    ref: j,
                    className: "prsd-unbox",
                    "data-phase": C,
                    children: [(0, a.jsxs)("div", {
                        ref: m,
                        className: "prsd-unbox-stage",
                        onPointerDown: e => {
                            h || "closed" !== v || (g.current = {
                                id: e.pointerId,
                                x: e.clientX,
                                y: e.clientY,
                                total: 0
                            }, e.currentTarget.setPointerCapture(e.pointerId))
                        },
                        onPointerMove: e => {
                            let s = g.current;
                            s && s.id === e.pointerId && (s.total += Math.hypot(e.clientX - s.x, e.clientY - s.y), s.x = e.clientX, s.y = e.clientY, L(Math.min(1, s.total / N)), s.total >= N && (g.current = null, b()))
                        },
                        onPointerUp: () => {
                            let e = g.current;
                            g.current = null, e && (e.total < 8 ? b() : L(0))
                        },
                        onPointerCancel: () => {
                            g.current = null, L(0)
                        },
                        children: [(0, a.jsx)("span", {
                            className: "prsd-rays",
                            "aria-hidden": !0,
                            children: (0, a.jsx)(n.WR, {})
                        }), (0, a.jsx)("span", {
                            className: "prsd-unbox-persp",
                            "aria-hidden": !0,
                            children: (0, a.jsx)("span", {
                                className: "prsd-unbox-float",
                                children: (0, a.jsx)("span", {
                                    className: "prsd-unbox-tilt",
                                    children: (0, a.jsxs)("span", {
                                        className: "prsd-cube prsd-gift-cube",
                                        children: [M, (0, a.jsx)("span", {
                                            className: "prsd-box-glow"
                                        }), ["front", "back", "right", "left"].map(s => (0, a.jsx)("span", {
                                            className: `prsd-hinge prsd-hinge-${s}`,
                                            children: (0, a.jsx)("span", {
                                                className: "prsd-flap prsd-wrap",
                                                children: e
                                            })
                                        }, s)), (0, a.jsxs)("span", {
                                            className: "prsd-top-tape",
                                            children: [(0, a.jsx)("span", {
                                                className: "prsd-tape-half prsd-tape-l",
                                                children: (0, a.jsx)("span", {
                                                    className: "prsd-tape-art",
                                                    children: s
                                                })
                                            }), (0, a.jsx)("span", {
                                                className: "prsd-tape-half prsd-tape-r",
                                                children: (0, a.jsx)("span", {
                                                    className: "prsd-tape-art",
                                                    children: s
                                                })
                                            })]
                                        }), (0, a.jsx)("span", {
                                            className: "prsd-cutline"
                                        })]
                                    })
                                })
                            })
                        }), (0, a.jsx)("span", {
                            className: "prsd-note-rise",
                            "aria-hidden": !0,
                            children: (0, a.jsx)(n.j1, {})
                        })]
                    }), (0, a.jsx)("div", {
                        className: "prsd-after",
                        children: h ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)("span", {
                                className: "prsd-hint",
                                children: c
                            }), (0, a.jsx)("span", {
                                className: "prsd-btn",
                                children: r
                            }), o]
                        }) : "closed" === C ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)("span", {
                                className: "prsd-hint",
                                children: c
                            }), (0, a.jsx)("button", {
                                type: "button",
                                className: "prsd-btn prsd-btn-ghost",
                                onClick: b,
                                children: r
                            })]
                        }) : "risen" === C ? (0, a.jsx)("div", {
                            className: "prsd-rise",
                            children: o
                        }) : null
                    })]
                })
            }
            let y = [
                [72, 52],
                [-76, 104],
                [44, 152]
            ];

            function C({
                accept: e,
                back: s,
                replies: r,
                noReturn: n,
                answered: c
            }) {
                let p = "edit" === (0, i.useMode)(),
                    o = (0, d.useSoundEffect)(),
                    h = (0, l.useRef)(null),
                    [f, x] = (0, l.useState)(!1),
                    [u, j] = (0, l.useState)(0);
                (0, t.useReplaySignal)(h, () => {
                    x(!1), j(0)
                });
                let m = u >= y.length,
                    g = () => {
                        p || f || m || (j(e => e + 1), o("nope"))
                    },
                    v = u > 0 ? y[Math.min(u, y.length) - 1] : null,
                    N = 0 === u ? null : m ? n : r[Math.min(u, r.length) - 1];
                return p ? (0, a.jsxs)("div", {
                    ref: h,
                    className: "prsd-accept",
                    children: [(0, a.jsxs)("div", {
                        className: "prsd-accept-buttons",
                        children: [(0, a.jsx)("span", {
                            className: "prsd-btn prsd-btn-wide",
                            children: e
                        }), (0, a.jsx)("span", {
                            className: "prsd-btn prsd-btn-ghost",
                            children: s
                        })]
                    }), (0, a.jsxs)("div", {
                        className: "prsd-replies",
                        children: [r.map((e, s) => (0, a.jsx)("span", {
                            className: "prsd-reply",
                            children: e
                        }, s)), (0, a.jsx)("span", {
                            className: "prsd-reply",
                            children: n
                        })]
                    }), (0, a.jsx)("div", {
                        children: c
                    })]
                }) : (0, a.jsx)("div", {
                    ref: h,
                    className: "prsd-accept",
                    ...f ? {
                        "data-said": ""
                    } : {},
                    children: f ? (0, a.jsxs)("div", {
                        className: "prsd-rise relative",
                        children: [(0, a.jsx)(t.ConfettiBurst, {
                            seed: 31,
                            count: 30,
                            top: "20%"
                        }), c]
                    }) : (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsxs)("div", {
                            className: "prsd-accept-buttons",
                            children: [(0, a.jsx)("button", {
                                type: "button",
                                className: "prsd-btn prsd-btn-wide",
                                onClick: () => {
                                    p || f || (x(!0), o("popper"))
                                },
                                children: e
                            }), (0, a.jsx)("button", {
                                type: "button",
                                className: "prsd-btn prsd-btn-ghost prsd-return",
                                style: v ? {
                                    transform: `translate(${v[0]}px, ${v[1]}px)`
                                } : void 0,
                                disabled: m,
                                ...m ? {
                                    "data-locked": ""
                                } : {},
                                onClick: g,
                                onPointerEnter: e => {
                                    "mouse" === e.pointerType && g()
                                },
                                children: s
                            })]
                        }), (0, a.jsx)("p", {
                            className: "prsd-replies",
                            "aria-live": "polite",
                            children: N ? (0, a.jsx)("span", {
                                className: "prsd-reply prsd-pop",
                                children: N
                            }, u) : null
                        })]
                    })
                })
            }
            let L = ["back", "mid", "front"];

            function b({
                blossom: e,
                petal: s,
                children: r
            }) {
                let p = "edit" === (0, i.useMode)(),
                    o = (0, t.usePrefersReducedMotion)(),
                    h = c(),
                    f = (0, d.useSoundEffect)(),
                    x = (0, l.useRef)(null),
                    [u, j] = (0, l.useState)(!1),
                    m = p || u;
                (0, t.useReplaySignal)(x, () => j(!1)), (0, l.useEffect)(() => {
                    if (p || !h) return;
                    let e = setTimeout(() => {
                        j(!0), f("reveal")
                    }, 120);
                    return () => clearTimeout(e)
                }, [p, h, f]);
                let g = 0;
                return (0, a.jsxs)("div", {
                    ref: x,
                    className: "prsd-tree",
                    ...m ? {
                        "data-grow": ""
                    } : {},
                    style: {
                        "--prsd-petal": s[0],
                        "--prsd-petal-deep": s[1]
                    },
                    children: [(0, a.jsxs)("div", {
                        className: "prsd-tree-stage",
                        "aria-hidden": !0,
                        children: [(0, a.jsx)("span", {
                            className: "prsd-tree-glow"
                        }), (0, a.jsx)("div", {
                            className: "prsd-tree-persp",
                            children: (0, a.jsx)("div", {
                                className: "prsd-tree-sway",
                                children: L.map(s => (0, a.jsxs)("div", {
                                    className: "prsd-plane",
                                    "data-plane": s,
                                    children: [(0, a.jsx)(n.jJ, {
                                        plane: s
                                    }), n.o3[s].map(([s, r]) => {
                                        let l = g++;
                                        return (0, a.jsx)("span", {
                                            className: "prsd-blossom",
                                            style: {
                                                left: `${(s/3).toFixed(2)}%`,
                                                top: `${(r/3).toFixed(2)}%`,
                                                "--i": l
                                            },
                                            children: e
                                        }, `${s}-${r}`)
                                    })]
                                }, s))
                            })
                        }), (0, a.jsx)("span", {
                            className: "prsd-tree-box",
                            children: (0, a.jsx)(n.sy, {})
                        }), !m || p || o ? null : (0, a.jsx)("span", {
                            className: "prsd-petals",
                            children: n.GO.map(([e, s, r, l], t) => (0, a.jsx)("i", {
                                style: {
                                    left: `${e}%`,
                                    width: s,
                                    height: s,
                                    "--dx": `${r}px`,
                                    "--i": t,
                                    animationDuration: `${l}s`
                                }
                            }, t))
                        })]
                    }), (0, a.jsx)("div", {
                        className: "prsd-tree-after",
                        children: r
                    })]
                })
            }

            function M({
                children: e
            }) {
                let s = "edit" === (0, i.useMode)(),
                    r = c(),
                    n = (0, d.useSoundEffect)(),
                    p = (0, l.useRef)(null),
                    [o, h] = (0, l.useState)(!1);
                return (0, t.useReplaySignal)(p, () => h(!1)), (0, l.useEffect)(() => {
                    if (s || !r) return;
                    let e = setTimeout(() => {
                        h(!0), n("stamp")
                    }, 380);
                    return () => clearTimeout(e)
                }, [s, r, n]), (0, a.jsx)("div", {
                    ref: p,
                    className: "prsd-stamp-wrap",
                    ...s || o ? {
                        "data-down": ""
                    } : {},
                    children: (0, a.jsxs)("span", {
                        className: "prsd-stamp",
                        children: [(0, a.jsx)("svg", {
                            viewBox: "0 0 24 24",
                            "aria-hidden": !0,
                            className: "prsd-stamp-check",
                            children: (0, a.jsx)("path", {
                                d: "M5 12.5 L10 17 L19 7.5",
                                fill: "none",
                                stroke: "currentColor",
                                strokeWidth: "3.4",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        }), e]
                    })
                })
            }
        }
    }
]);