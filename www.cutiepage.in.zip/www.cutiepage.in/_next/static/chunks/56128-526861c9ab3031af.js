(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [56128], {
        7828: (e, r, s) => {
            "use strict";
            s.d(r, {
                AR: () => v,
                AZ: () => n,
                Bs: () => N,
                Es: () => $,
                Ex: () => y,
                NG: () => k,
                Sd: () => W,
                Xu: () => w,
                ed: () => m,
                hK: () => g,
                je: () => L,
                me: () => p,
                pP: () => C,
                s7: () => x,
                wV: () => c,
                wt: () => f
            });
            var a = s(73365);
            s(43352);
            let l = {
                stroke: "var(--f-fg)",
                strokeWidth: 3.5,
                strokeLinejoin: "round",
                strokeLinecap: "round"
            };

            function t({
                x: e,
                y: r,
                s = 1
            }) {
                return (0, a.jsx)("path", {
                    transform: `translate(${e} ${r}) scale(${s})`,
                    d: "M0 6 C-5 2 -8 -1 -8 -4 C-8 -7 -5.5 -9 -3.5 -9 C-1.8 -9 -0.6 -8 0 -6.6 C0.6 -8 1.8 -9 3.5 -9 C5.5 -9 8 -7 8 -4 C8 -1 5 2 0 6 Z",
                    fill: "var(--prpg-rose)",
                    stroke: "var(--f-fg)",
                    strokeWidth: "2",
                    strokeLinejoin: "round"
                })
            }

            function i({
                mood: e
            }) {
                return "sleepy" === e ? (0, a.jsxs)("g", {
                    className: "prpg-face",
                    "data-face": "sleepy",
                    children: [(0, a.jsx)("path", {
                        d: "M-27 52 q7 6 14 0 M13 52 q7 6 14 0",
                        fill: "none",
                        ...l,
                        strokeWidth: 3
                    }), (0, a.jsx)("ellipse", {
                        cx: "0",
                        cy: "70",
                        rx: "4",
                        ry: "3",
                        fill: "var(--f-fg)"
                    }), (0, a.jsxs)("g", {
                        className: "prpg-zzz",
                        children: [(0, a.jsx)("path", {
                            d: "M34 18 h9 l-9 10 h9",
                            fill: "none",
                            ...l,
                            strokeWidth: 2.5
                        }), (0, a.jsx)("path", {
                            d: "M48 4 h6 l-6 7 h6",
                            fill: "none",
                            ...l,
                            strokeWidth: 2
                        })]
                    })]
                }) : "wow" === e ? (0, a.jsxs)("g", {
                    className: "prpg-face",
                    "data-face": "wow",
                    children: [(0, a.jsxs)("g", {
                        className: "prpg-eyes",
                        children: [(0, a.jsx)("circle", {
                            cx: "-20",
                            cy: "50",
                            r: "8.5",
                            fill: "var(--f-fg)"
                        }), (0, a.jsx)("circle", {
                            cx: "20",
                            cy: "50",
                            r: "8.5",
                            fill: "var(--f-fg)"
                        }), (0, a.jsx)("circle", {
                            cx: "-17",
                            cy: "47",
                            r: "3",
                            fill: "var(--prpg-paper)"
                        }), (0, a.jsx)("circle", {
                            cx: "23",
                            cy: "47",
                            r: "3",
                            fill: "var(--prpg-paper)"
                        })]
                    }), (0, a.jsx)("ellipse", {
                        cx: "0",
                        cy: "72",
                        rx: "6",
                        ry: "8",
                        fill: "var(--f-fg)"
                    })]
                }) : "shy" === e ? (0, a.jsxs)("g", {
                    className: "prpg-face",
                    "data-face": "shy",
                    children: [(0, a.jsxs)("g", {
                        className: "prpg-eyes",
                        children: [(0, a.jsx)("circle", {
                            cx: "-17",
                            cy: "56",
                            r: "4.5",
                            fill: "var(--f-fg)"
                        }), (0, a.jsx)("circle", {
                            cx: "23",
                            cy: "56",
                            r: "4.5",
                            fill: "var(--f-fg)"
                        })]
                    }), (0, a.jsx)("path", {
                        d: "M-6 72 q3 -3 6 0 q3 3 6 0",
                        fill: "none",
                        ...l,
                        strokeWidth: 2.5
                    }), (0, a.jsx)("path", {
                        d: "M-40 62 l5 -4 M-34 64 l5 -4 M30 62 l5 -4 M36 64 l5 -4",
                        ...l,
                        strokeWidth: 2
                    })]
                }) : "love" === e ? (0, a.jsxs)("g", {
                    className: "prpg-face",
                    "data-face": "love",
                    children: [(0, a.jsx)(t, {
                        x: -20,
                        y: 52,
                        s: 1.15
                    }), (0, a.jsx)(t, {
                        x: 20,
                        y: 52,
                        s: 1.15
                    }), (0, a.jsx)("path", {
                        d: "M-12 64 Q0 84 12 64 Z",
                        fill: "var(--f-fg)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("path", {
                        d: "M-5 72 Q0 77 5 72",
                        fill: "var(--prpg-rose)"
                    })]
                }) : (0, a.jsxs)("g", {
                    className: "prpg-face",
                    "data-face": "happy",
                    children: [(0, a.jsxs)("g", {
                        className: "prpg-eyes",
                        children: [(0, a.jsx)("circle", {
                            cx: "-20",
                            cy: "52",
                            r: "6",
                            fill: "var(--f-fg)"
                        }), (0, a.jsx)("circle", {
                            cx: "20",
                            cy: "52",
                            r: "6",
                            fill: "var(--f-fg)"
                        }), (0, a.jsx)("circle", {
                            cx: "-18",
                            cy: "50",
                            r: "2",
                            fill: "var(--prpg-paper)"
                        }), (0, a.jsx)("circle", {
                            cx: "22",
                            cy: "50",
                            r: "2",
                            fill: "var(--prpg-paper)"
                        })]
                    }), (0, a.jsx)("path", {
                        d: "M-10 66 Q0 78 10 66",
                        fill: "none",
                        ...l,
                        strokeWidth: 3
                    })]
                })
            }

            function p({
                mood: e,
                top: r
            }) {
                let s = "wake" === e ? "happy" : e;
                return (0, a.jsxs)("g", {
                    className: "prpg-buddy",
                    "data-mood": e,
                    "data-pose": s,
                    children: [(0, a.jsx)("ellipse", {
                        cx: "0",
                        cy: "110",
                        rx: "58",
                        ry: "7",
                        fill: "var(--f-fg)",
                        opacity: "0.14"
                    }), r, (0, a.jsxs)("g", {
                        className: "prpg-breathe",
                        children: [(0, a.jsxs)("g", {
                            className: "prpg-arm prpg-arm-l",
                            children: [(0, a.jsx)("path", {
                                d: "M-60 40 q-20 6 -24 26",
                                fill: "none",
                                ...l,
                                strokeWidth: 9
                            }), (0, a.jsx)("path", {
                                d: "M-60 40 q-20 6 -24 26",
                                fill: "none",
                                stroke: "var(--prpg-pot)",
                                strokeWidth: 4,
                                strokeLinecap: "round"
                            })]
                        }), (0, a.jsxs)("g", {
                            className: "prpg-arm prpg-arm-r",
                            children: [(0, a.jsx)("path", {
                                d: "M60 40 q20 6 24 26",
                                fill: "none",
                                ...l,
                                strokeWidth: 9
                            }), (0, a.jsx)("path", {
                                d: "M60 40 q20 6 24 26",
                                fill: "none",
                                stroke: "var(--prpg-pot)",
                                strokeWidth: 4,
                                strokeLinecap: "round"
                            })]
                        }), (0, a.jsx)("path", {
                            d: "M-66 20 L-50 104 Q0 112 50 104 L66 20 Z",
                            fill: "var(--prpg-pot)",
                            ...l
                        }), (0, a.jsx)("path", {
                            d: "M-60 34 L60 34",
                            stroke: "var(--prpg-potDark)",
                            strokeWidth: "5"
                        }), [-48, -32, -16, 0, 16, 32, 48].map(e => (0, a.jsx)("circle", {
                            cx: e,
                            cy: "34",
                            r: "2.6",
                            fill: "var(--prpg-paper)"
                        }, e)), (0, a.jsx)("path", {
                            d: "M-48 92 Q0 99 48 92",
                            fill: "none",
                            stroke: "var(--prpg-potDark)",
                            strokeWidth: "3",
                            opacity: "0.6"
                        }), (0, a.jsx)("ellipse", {
                            cx: "-34",
                            cy: "66",
                            rx: "8",
                            ry: "5",
                            fill: "var(--prpg-rose)",
                            opacity: "0.55"
                        }), (0, a.jsx)("ellipse", {
                            cx: "34",
                            cy: "66",
                            rx: "8",
                            ry: "5",
                            fill: "var(--prpg-rose)",
                            opacity: "0.55"
                        }), "wake" === e ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)("g", {
                                className: "prpg-wake-sleepy",
                                children: (0, a.jsx)(i, {
                                    mood: "sleepy"
                                })
                            }), (0, a.jsx)("g", {
                                className: "prpg-wake-happy",
                                children: (0, a.jsx)(i, {
                                    mood: "happy"
                                })
                            })]
                        }) : (0, a.jsx)(i, {
                            mood: e
                        }), (0, a.jsx)("rect", {
                            x: "-78",
                            y: "-6",
                            width: "156",
                            height: "28",
                            rx: "9",
                            fill: "var(--prpg-pot)",
                            ...l
                        }), (0, a.jsx)("ellipse", {
                            cx: "0",
                            cy: "-3",
                            rx: "66",
                            ry: "6",
                            fill: "var(--prpg-soil)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2.5"
                        }), (0, a.jsx)("path", {
                            d: "M-70 4 h22",
                            stroke: "var(--prpg-paper)",
                            strokeWidth: "3",
                            strokeLinecap: "round",
                            opacity: "0.5"
                        })]
                    })]
                })
            }

            function n({
                className: e = ""
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "-40 -32 80 64",
                    "aria-hidden": !0,
                    className: `block size-full overflow-visible ${e}`,
                    children: [(0, a.jsxs)("g", {
                        className: "prpg-wing prpg-wing-l",
                        children: [(0, a.jsx)("path", {
                            d: "M-2 -2 C-14 -26 -38 -26 -36 -8 C-35 2 -20 4 -2 2 Z",
                            fill: "var(--prpg-wing)",
                            ...l,
                            strokeWidth: 2.5
                        }), (0, a.jsx)("path", {
                            d: "M-2 2 C-18 6 -30 20 -20 26 C-12 30 -4 18 -2 4 Z",
                            fill: "var(--prpg-rose)",
                            ...l,
                            strokeWidth: 2.5
                        }), (0, a.jsx)("circle", {
                            cx: "-22",
                            cy: "-12",
                            r: "4",
                            fill: "var(--prpg-paper)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "1.5"
                        })]
                    }), (0, a.jsxs)("g", {
                        className: "prpg-wing prpg-wing-r",
                        children: [(0, a.jsx)("path", {
                            d: "M2 -2 C14 -26 38 -26 36 -8 C35 2 20 4 2 2 Z",
                            fill: "var(--prpg-wing)",
                            ...l,
                            strokeWidth: 2.5
                        }), (0, a.jsx)("path", {
                            d: "M2 2 C18 6 30 20 20 26 C12 30 4 18 2 4 Z",
                            fill: "var(--prpg-rose)",
                            ...l,
                            strokeWidth: 2.5
                        }), (0, a.jsx)("circle", {
                            cx: "22",
                            cy: "-12",
                            r: "4",
                            fill: "var(--prpg-paper)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "1.5"
                        })]
                    }), (0, a.jsx)("ellipse", {
                        cx: "0",
                        cy: "2",
                        rx: "3.5",
                        ry: "13",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("path", {
                        d: "M-1 -10 C-4 -18 -8 -22 -11 -24 M1 -10 C4 -18 8 -22 11 -24",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("circle", {
                        cx: "-11",
                        cy: "-24",
                        r: "2",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("circle", {
                        cx: "11",
                        cy: "-24",
                        r: "2",
                        fill: "var(--f-fg)"
                    })]
                })
            }
            let o = ["rose", "marigold", "periwinkle"],
                d = {
                    rose: {
                        d: "M0 0 C-15 -4 -19 -23 -9 -29 C-3 -32 3 -32 9 -29 C19 -23 15 -4 0 0Z",
                        fill: "var(--prpg-rose)",
                        count: 5
                    },
                    marigold: {
                        d: "M0 0 C-7 -7 -8 -19 -4 -24 L0 -20 L4 -24 C8 -19 7 -7 0 0Z",
                        fill: "var(--prpg-genda)",
                        count: 12,
                        ring: {
                            d: "M0 0 C-5 -5 -6 -13 -3 -16 L0 -13 L3 -16 C6 -13 5 -5 0 0Z",
                            fill: "var(--prpg-gendaDeep)",
                            count: 9
                        }
                    },
                    periwinkle: {
                        d: "M0 0 C-13 -8 -16 -24 -7 -28 C-2 -30 0 -26 0 -23 C0 -26 2 -30 7 -28 C16 -24 13 -8 0 0Z",
                        fill: "var(--prpg-sada)",
                        count: 5
                    }
                };

            function c({
                kind: e,
                bloom: r = !1,
                delay: s = 0
            }) {
                let t = d[e],
                    i = (e, r, s, t, i) => Array.from({
                        length: s
                    }, (p, n) => (0, a.jsx)("g", {
                        transform: `rotate(${(360/s*n+t).toFixed(2)})`,
                        children: (0, a.jsx)("path", {
                            className: "prpg-petal",
                            style: {
                                "--i": i + n
                            },
                            d: e,
                            fill: r,
                            ...l,
                            strokeWidth: 2.2
                        })
                    }, `${i}-${n}`));
                return (0, a.jsxs)("g", {
                    className: "prpg-flower",
                    "data-bloom": r ? "" : void 0,
                    style: {
                        "--bloom-delay": `${s}ms`
                    },
                    children: [i(t.d, t.fill, t.count, 0, 0), t.ring ? i(t.ring.d, t.ring.fill, t.ring.count, 20, t.count) : null, "rose" === e ? (0, a.jsxs)("g", {
                        className: "prpg-petal-core",
                        children: [(0, a.jsx)("circle", {
                            r: "11",
                            fill: "var(--prpg-roseDeep)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2.2"
                        }), (0, a.jsx)("path", {
                            d: "M-6 -1 C-6 -8 7 -8 7 -1 C7 5 -3 5 -3 0 C-3 -4 3 -4 3 -1",
                            fill: "none",
                            stroke: "var(--f-fg)",
                            strokeWidth: "1.8",
                            strokeLinecap: "round"
                        })]
                    }) : "marigold" === e ? (0, a.jsx)("circle", {
                        className: "prpg-petal-core",
                        r: "6",
                        fill: "var(--prpg-gendaDeep)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.2"
                    }) : (0, a.jsxs)("g", {
                        className: "prpg-petal-core",
                        children: [(0, a.jsx)("circle", {
                            r: "6",
                            fill: "var(--prpg-paper)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2"
                        }), (0, a.jsx)("circle", {
                            r: "2.4",
                            fill: "var(--prpg-rose)"
                        })]
                    })]
                })
            }

            function x({
                kind: e
            }) {
                return (0, a.jsxs)("g", {
                    className: "prpg-bud",
                    children: [(0, a.jsx)("path", {
                        d: "M0 -18 C10 -10 11 4 0 10 C-11 4 -10 -10 0 -18Z",
                        fill: "rose" === e ? "var(--prpg-rose)" : "marigold" === e ? "var(--prpg-genda)" : "var(--prpg-sada)",
                        ...l,
                        strokeWidth: 2.5
                    }), (0, a.jsx)("path", {
                        d: "M0 10 C-8 8 -12 2 -12 -4 C-6 0 -3 4 0 10 C3 4 6 0 12 -4 C12 2 8 8 0 10Z",
                        fill: "var(--prpg-leaf)",
                        ...l,
                        strokeWidth: 2.2
                    })]
                })
            }

            function g({
                x: e,
                y: r,
                turn: s,
                flip: t = !1
            }) {
                return (0, a.jsx)("g", {
                    transform: `translate(${e} ${r}) rotate(${s}) scale(${t?-1:1} 1)`,
                    children: (0, a.jsx)("path", {
                        className: "prpg-leaf",
                        d: "M0 0 C6 -12 20 -14 28 -8 C20 2 8 4 0 0Z",
                        fill: "var(--prpg-leaf)",
                        ...l,
                        strokeWidth: 2.2
                    })
                })
            }

            function f({
                x1: e,
                y1: r,
                x2: s,
                y2: l,
                bend: t = 0,
                draw: i = !1
            }) {
                let p = ((e + s) / 2 + t).toFixed(2),
                    n = ((r + l) / 2).toFixed(2);
                return (0, a.jsx)("path", {
                    className: i ? "prpg-draw" : void 0,
                    pathLength: 1,
                    d: `M${e} ${r} Q${p} ${n} ${s} ${l}`,
                    fill: "none",
                    stroke: "var(--prpg-leafDeep)",
                    strokeWidth: "5",
                    strokeLinecap: "round"
                })
            }
            let h = Array.from({
                    length: 16
                }, (e, r) => ({
                    x: 37 * r % 340,
                    d: 173 * r % 900,
                    l: 10 + 7 * r % 8
                })),
                j = [{
                    x: 40,
                    y: 120,
                    d: 0
                }, {
                    x: 92,
                    y: 70,
                    d: 700
                }, {
                    x: 150,
                    y: 140,
                    d: 1400
                }, {
                    x: 230,
                    y: 60,
                    d: 300
                }, {
                    x: 290,
                    y: 130,
                    d: 1100
                }, {
                    x: 200,
                    y: 180,
                    d: 1800
                }];

            function v({
                time: e,
                height: r = 320,
                beat: s = !1,
                bare: l = !1,
                children: t
            }) {
                let i = e => s ? ` prpg-beat prpg-beat-${e}` : "";
                return (0, a.jsxs)("div", {
                    className: "prpg-scene",
                    "data-time": e,
                    style: {
                        height: r
                    },
                    children: [(0, a.jsxs)("svg", {
                        viewBox: "0 0 360 320",
                        preserveAspectRatio: "xMidYMax slice",
                        "aria-hidden": !0,
                        className: "prpg-layer prpg-pan-sky",
                        children: [(0, a.jsx)("rect", {
                            width: "360",
                            height: "320",
                            className: "prpg-sky"
                        }), l ? null : "night" === e ? (0, a.jsx)("g", {
                            transform: "translate(214 46)",
                            children: (0, a.jsxs)("g", {
                                className: `prpg-moon${i("sun")}`,
                                children: [(0, a.jsx)("circle", {
                                    r: "20",
                                    fill: "var(--prpg-paper)",
                                    stroke: "var(--f-fg)",
                                    strokeWidth: "3"
                                }), (0, a.jsx)("circle", {
                                    cx: "9",
                                    cy: "-6",
                                    r: "18",
                                    className: "prpg-sky"
                                })]
                            })
                        }) : (0, a.jsx)("g", {
                            transform: "translate(214 46) scale(0.7)",
                            children: (0, a.jsxs)("g", {
                                className: `prpg-sun${i("sun")}`,
                                children: [(0, a.jsx)("circle", {
                                    r: "30",
                                    fill: "var(--prpg-genda)",
                                    stroke: "var(--f-fg)",
                                    strokeWidth: "3.5"
                                }), (0, a.jsx)("path", {
                                    d: "M0 -44 v-10 M0 54 v-10 M-44 0 h-10 M54 0 h-10 M-31 -31 l-7 -7 M38 38 l-7 -7 M31 -31 l7 -7 M-38 38 l7 -7",
                                    stroke: "var(--f-fg)",
                                    strokeWidth: "3.5",
                                    strokeLinecap: "round"
                                })]
                            })
                        }), (0, a.jsx)("g", {
                            className: "prpg-cloud",
                            children: (0, a.jsx)("path", {
                                d: "M120 84 a16 16 0 0 1 28 -12 a20 20 0 0 1 36 8 a12 12 0 0 1 2 24 h-62 a12 12 0 0 1 -4 -20z",
                                fill: "var(--prpg-paper)",
                                stroke: "var(--f-fg)",
                                strokeWidth: "2.5"
                            })
                        }), s ? (0, a.jsx)("rect", {
                            width: "360",
                            height: "320",
                            className: "prpg-beat prpg-beat-veil",
                            fill: "var(--prpg-night)"
                        }) : null]
                    }), (0, a.jsxs)("svg", {
                        viewBox: "0 0 360 320",
                        preserveAspectRatio: "xMidYMax slice",
                        "aria-hidden": !0,
                        className: `prpg-layer prpg-pan-far${i("far")}`,
                        children: [(0, a.jsxs)("g", {
                            fill: "var(--prpg-roof)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2.5",
                            strokeLinejoin: "round",
                            children: [(0, a.jsx)("path", {
                                d: "M-10 320 V196 H58 V170 H112 V214 H150 V182 H214 V206 H262 V160 H330 V200 H380 V320 Z"
                            }), (0, a.jsx)("rect", {
                                x: "70",
                                y: "150",
                                width: "28",
                                height: "20",
                                rx: "4"
                            }), (0, a.jsx)("path", {
                                d: "M70 150 q14 -6 28 0",
                                fill: "none"
                            }), (0, a.jsx)("rect", {
                                x: "278",
                                y: "140",
                                width: "34",
                                height: "20",
                                rx: "4"
                            }), (0, a.jsx)("path", {
                                d: "M162 182 V160 M162 160 l-8 -6 M162 160 l8 -6",
                                fill: "none"
                            })]
                        }), [
                            [24, 214],
                            [80, 196],
                            [126, 232],
                            [176, 200],
                            [232, 224],
                            [286, 180],
                            [344, 220]
                        ].map(([e, r]) => (0, a.jsx)("rect", {
                            x: e,
                            y: r,
                            width: "10",
                            height: "12",
                            rx: "2",
                            className: "prpg-window"
                        }, `${e}`))]
                    }), (0, a.jsxs)("svg", {
                        viewBox: "0 0 360 320",
                        preserveAspectRatio: "xMidYMax slice",
                        "aria-hidden": !0,
                        className: `prpg-layer prpg-pan-mid${i("rail")}`,
                        children: [(0, a.jsx)("rect", {
                            x: "-10",
                            y: "262",
                            width: "380",
                            height: "70",
                            fill: "var(--prpg-ledge)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "3"
                        }), (0, a.jsx)("path", {
                            className: s ? "prpg-draw prpg-beat prpg-beat-railline" : void 0,
                            pathLength: 1,
                            d: "M-10 252 H370",
                            fill: "none",
                            stroke: "var(--f-fg)",
                            strokeWidth: "4",
                            strokeLinecap: "round"
                        }), (0, a.jsx)("path", {
                            className: s ? "prpg-draw prpg-beat prpg-beat-railline" : void 0,
                            pathLength: 1,
                            d: "M10 252 v10 M40 252 v10 M70 252 v10 M100 252 v10 M260 252 v10 M290 252 v10 M320 252 v10 M350 252 v10",
                            fill: "none",
                            stroke: "var(--f-fg)",
                            strokeWidth: "3"
                        }), [30, 90, 150, 210, 270, 330].map(e => (0, a.jsx)("path", {
                            d: `M${e-8} 290 q8 -8 16 0 q-8 8 -16 0`,
                            fill: "var(--prpg-paper)",
                            opacity: "0.5"
                        }, e))]
                    }), "rain" === e ? (0, a.jsx)("svg", {
                        viewBox: "0 0 340 320",
                        "aria-hidden": !0,
                        className: "prpg-layer",
                        children: h.map((e, r) => (0, a.jsx)("path", {
                            className: "prpg-drizzle",
                            style: {
                                "--d": `${e.d}ms`
                            },
                            d: `M${e.x} -20 l-3 ${e.l}`,
                            stroke: "var(--prpg-water)",
                            strokeWidth: "3",
                            strokeLinecap: "round"
                        }, r))
                    }) : null, "night" === e ? (0, a.jsx)("svg", {
                        viewBox: "0 0 340 320",
                        "aria-hidden": !0,
                        className: "prpg-layer",
                        children: j.map(e => (0, a.jsx)("circle", {
                            className: "prpg-firefly",
                            style: {
                                "--d": `${e.d}ms`
                            },
                            cx: e.x,
                            cy: e.y,
                            r: "3.5",
                            fill: "var(--prpg-genda)"
                        }, `${e.x}`))
                    }) : null, (0, a.jsx)("div", {
                        className: "prpg-stage",
                        children: t
                    }), (0, a.jsx)("svg", {
                        viewBox: "0 0 360 320",
                        preserveAspectRatio: "xMidYMax slice",
                        "aria-hidden": !0,
                        className: `prpg-layer prpg-near prpg-pan-near${i("near")}`,
                        children: (0, a.jsxs)("g", {
                            fill: "var(--prpg-leaf)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "3",
                            strokeLinejoin: "round",
                            children: [(0, a.jsx)("path", {
                                d: "M-20 330 C-10 280 20 262 46 270 C34 290 18 312 -20 330Z"
                            }), (0, a.jsx)("path", {
                                d: "M-14 332 C4 300 40 296 58 312 C40 324 20 332 -14 332Z"
                            }), (0, a.jsx)("path", {
                                d: "M380 330 C368 284 340 268 316 276 C326 298 344 314 380 330Z"
                            })]
                        })
                    })]
                })
            }
            let k = ["Chime", "Diya", "Chidiya", "Lantern"];

            function u({
                kind: e
            }) {
                let r = (0, a.jsx)("path", {
                    d: "M50 0 V40",
                    stroke: "var(--f-fg)",
                    strokeWidth: "2.5"
                });
                return "Diya" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 160",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("path", {
                        d: "M50 0 V70 M50 70 L26 96 M50 70 L74 96",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5"
                    }), (0, a.jsx)("path", {
                        d: "M20 100 Q50 140 80 100 Z",
                        fill: "var(--prpg-pot)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M28 104 Q50 124 72 104",
                        fill: "none",
                        stroke: "var(--prpg-paper)",
                        strokeWidth: "2.5",
                        strokeDasharray: "1 6"
                    }), (0, a.jsx)("path", {
                        className: "prpg-flame",
                        d: "M50 74 C58 84 58 94 50 98 C42 94 42 84 50 74Z",
                        fill: "var(--prpg-genda)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5"
                    })]
                }) : "Chidiya" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 160",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [r, (0, a.jsx)("circle", {
                        cx: "50",
                        cy: "84",
                        r: "44",
                        fill: "none",
                        stroke: "var(--prpg-pot)",
                        strokeWidth: "5"
                    }), (0, a.jsx)("circle", {
                        cx: "50",
                        cy: "84",
                        r: "44",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "1.5"
                    }), (0, a.jsx)("path", {
                        d: "M18 112 H82",
                        stroke: "var(--f-fg)",
                        strokeWidth: "4",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("path", {
                        d: "M34 110 C30 92 44 80 58 84 C66 76 76 80 74 88 L82 90 L74 94 C72 104 60 110 46 110 Z",
                        fill: "var(--prpg-wing)",
                        ...l,
                        strokeWidth: 3
                    }), (0, a.jsx)("path", {
                        d: "M34 108 L20 100 L30 112 Z",
                        fill: "var(--prpg-wing)",
                        ...l,
                        strokeWidth: 2.5
                    }), (0, a.jsx)("circle", {
                        cx: "66",
                        cy: "88",
                        r: "2.4",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("path", {
                        d: "M44 96 q8 6 16 0",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2"
                    })]
                }) : "Lantern" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 160",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [r, (0, a.jsx)("path", {
                        d: "M50 40 L66 66 L94 74 L70 92 L74 122 L50 106 L26 122 L30 92 L6 74 L34 66 Z",
                        fill: "var(--prpg-rose)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M50 58 L58 74 L50 92 L42 74 Z",
                        fill: "var(--prpg-genda)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2"
                    }), [40, 50, 60].map(e => (0, a.jsx)("path", {
                        d: `M${e} 112 V150`,
                        stroke: "var(--prpg-genda)",
                        strokeWidth: "3",
                        strokeLinecap: "round"
                    }, e))]
                }) : (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 160",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [r, (0, a.jsx)("ellipse", {
                        cx: "50",
                        cy: "44",
                        rx: "34",
                        ry: "8",
                        fill: "var(--prpg-pot)",
                        ...l
                    }), [24, 40, 60, 76].map((e, r) => (0, a.jsxs)("g", {
                        className: "prpg-chime",
                        style: {
                            "--d": `${160*r}ms`
                        },
                        children: [(0, a.jsx)("path", {
                            d: `M${e} 50 V${70+6*r}`,
                            stroke: "var(--f-fg)",
                            strokeWidth: "1.8"
                        }), (0, a.jsx)("rect", {
                            x: e - 4,
                            y: 70 + 6 * r,
                            width: "8",
                            height: 44 - 4 * r,
                            rx: "4",
                            fill: "var(--prpg-genda)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2.2"
                        })]
                    }, e)), (0, a.jsx)("path", {
                        d: "M50 52 V130",
                        stroke: "var(--f-fg)",
                        strokeWidth: "1.8"
                    }), (0, a.jsx)("path", {
                        d: "M42 130 h16 l-8 18 z",
                        fill: "var(--prpg-rose)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.2",
                        strokeLinejoin: "round"
                    })]
                })
            }
            let m = Object.fromEntries(k.map(e => [e, (0, a.jsx)(u, {
                    kind: e
                }, e)])),
                y = ["Ladybug", "Snail", "Bee", "Gilahri"];

            function M({
                kind: e
            }) {
                return "Snail" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 80",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("path", {
                        d: "M10 70 C10 60 20 56 30 58 L80 58 C90 58 94 66 92 70 Z",
                        fill: "var(--prpg-wing)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M80 58 C82 44 84 34 80 26 M86 58 C90 46 94 38 92 30",
                        fill: "none",
                        ...l,
                        strokeWidth: 2.5
                    }), (0, a.jsx)("circle", {
                        cx: "80",
                        cy: "25",
                        r: "3",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("circle", {
                        cx: "92",
                        cy: "29",
                        r: "3",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("circle", {
                        cx: "46",
                        cy: "42",
                        r: "26",
                        fill: "var(--prpg-pot)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M46 42 m0 -4 a4 4 0 1 1 -4 4 a8 8 0 1 1 8 8 a12 12 0 1 1 -12 -12 a16 16 0 1 1 16 16",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5",
                        strokeLinecap: "round"
                    })]
                }) : "Bee" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 80",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("ellipse", {
                        className: "prpg-wing prpg-wing-l",
                        cx: "40",
                        cy: "22",
                        rx: "14",
                        ry: "18",
                        fill: "var(--prpg-paper)",
                        ...l,
                        strokeWidth: 2.5
                    }), (0, a.jsx)("ellipse", {
                        className: "prpg-wing prpg-wing-r",
                        cx: "60",
                        cy: "22",
                        rx: "14",
                        ry: "18",
                        fill: "var(--prpg-paper)",
                        ...l,
                        strokeWidth: 2.5
                    }), (0, a.jsx)("ellipse", {
                        cx: "50",
                        cy: "50",
                        rx: "30",
                        ry: "22",
                        fill: "var(--prpg-genda)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M40 30 V70 M56 29 V71",
                        stroke: "var(--f-fg)",
                        strokeWidth: "7"
                    }), (0, a.jsx)("circle", {
                        cx: "74",
                        cy: "46",
                        r: "3",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("path", {
                        d: "M18 50 L8 50",
                        ...l
                    })]
                }) : "Gilahri" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 80",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("path", {
                        d: "M30 72 C6 70 0 40 14 22 C24 10 40 16 34 30 C28 42 40 52 44 60 Z",
                        fill: "var(--prpg-roof)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M40 74 C38 56 46 42 62 40 C78 40 84 54 80 66 C78 72 72 74 66 74 Z",
                        fill: "var(--prpg-pot)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M54 50 C56 60 58 66 60 72 M62 46 C66 56 68 64 70 72 M70 46 C74 54 76 62 76 70",
                        stroke: "var(--prpg-paper)",
                        strokeWidth: "2.5",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("circle", {
                        cx: "74",
                        cy: "34",
                        r: "14",
                        fill: "var(--prpg-pot)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M68 22 l-2 -8 l8 6",
                        fill: "var(--prpg-pot)",
                        ...l,
                        strokeWidth: 2.5
                    }), (0, a.jsx)("circle", {
                        cx: "78",
                        cy: "32",
                        r: "2.5",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("circle", {
                        cx: "88",
                        cy: "38",
                        r: "2",
                        fill: "var(--f-fg)"
                    })]
                }) : (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 80",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("path", {
                        d: "M20 66 L10 74 M50 70 V78 M80 66 L90 74",
                        ...l,
                        strokeWidth: 3
                    }), (0, a.jsx)("path", {
                        d: "M14 60 C14 30 30 16 50 16 C70 16 86 30 86 60 Z",
                        fill: "var(--prpg-rose)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M50 16 V60",
                        stroke: "var(--f-fg)",
                        strokeWidth: "3"
                    }), [
                        [32, 34],
                        [30, 50],
                        [68, 34],
                        [70, 50],
                        [42, 26],
                        [58, 26]
                    ].map(([e, r]) => (0, a.jsx)("circle", {
                        cx: e,
                        cy: r,
                        r: "4.5",
                        fill: "var(--f-fg)"
                    }, `${e}-${r}`)), (0, a.jsx)("path", {
                        d: "M30 16 C30 4 70 4 70 16 Z",
                        fill: "var(--f-fg)"
                    }), (0, a.jsx)("circle", {
                        cx: "42",
                        cy: "10",
                        r: "2",
                        fill: "var(--prpg-paper)"
                    }), (0, a.jsx)("circle", {
                        cx: "58",
                        cy: "10",
                        r: "2",
                        fill: "var(--prpg-paper)"
                    })]
                })
            }
            let w = Object.fromEntries(y.map(e => [e, (0, a.jsx)(M, {
                    kind: e
                }, e)])),
                b = Array.from({
                    length: 16
                }, (e, r) => ({
                    left: 61 * r % 100,
                    delay: 530 * r % 5200,
                    dur: 5200 + 370 * r % 2600,
                    kind: o[r % 3],
                    size: 14 + 5 * r % 10
                }));

            function N() {
                return (0, a.jsx)("span", {
                    "aria-hidden": !0,
                    className: "prpg-fall",
                    children: b.map((e, r) => (0, a.jsx)("span", {
                        className: "prpg-fall-piece",
                        style: {
                            left: `${e.left}%`,
                            "--d": `${e.delay}ms`,
                            "--t": `${e.dur}ms`,
                            width: e.size,
                            height: e.size
                        },
                        children: (0, a.jsx)("svg", {
                            viewBox: "-12 -30 24 32",
                            className: "block size-full",
                            children: (0, a.jsx)("path", {
                                d: d[e.kind].d,
                                fill: d[e.kind].fill,
                                stroke: "var(--f-fg)",
                                strokeWidth: "2"
                            })
                        })
                    }, r))
                })
            }

            function C({
                tie: e = !1
            }) {
                return (0, a.jsxs)("g", {
                    children: [(0, a.jsx)(f, {
                        x1: 160,
                        y1: 200,
                        x2: 112,
                        y2: 96,
                        bend: -10
                    }), (0, a.jsx)(f, {
                        x1: 160,
                        y1: 200,
                        x2: 160,
                        y2: 70
                    }), (0, a.jsx)(f, {
                        x1: 160,
                        y1: 200,
                        x2: 208,
                        y2: 96,
                        bend: 10
                    }), (0, a.jsx)(g, {
                        x: 130,
                        y: 150,
                        turn: -150
                    }), (0, a.jsx)(g, {
                        x: 190,
                        y: 150,
                        turn: -30
                    }), (0, a.jsx)("g", {
                        transform: "translate(112 96)",
                        children: (0, a.jsx)(c, {
                            kind: "marigold"
                        })
                    }), (0, a.jsx)("g", {
                        transform: "translate(208 96)",
                        children: (0, a.jsx)(c, {
                            kind: "periwinkle"
                        })
                    }), (0, a.jsx)("g", {
                        transform: "translate(160 70)",
                        children: (0, a.jsx)(c, {
                            kind: "rose"
                        })
                    }), (0, a.jsx)(W, {}), (0, a.jsx)(L, {
                        tie: e
                    })]
                })
            }

            function W() {
                return (0, a.jsxs)("g", {
                    children: [(0, a.jsx)("path", {
                        d: "M96 140 L160 290 L224 140 Q160 158 96 140 Z",
                        fill: "var(--prpg-kraft)",
                        ...l
                    }), (0, a.jsx)("path", {
                        d: "M96 140 Q160 120 224 140",
                        fill: "none",
                        ...l
                    }), [
                        [124, 170],
                        [150, 166],
                        [176, 166],
                        [200, 170],
                        [136, 196],
                        [162, 194],
                        [186, 196],
                        [148, 224],
                        [172, 224],
                        [160, 252]
                    ].map(([e, r]) => (0, a.jsxs)("g", {
                        children: [(0, a.jsx)("circle", {
                            cx: e,
                            cy: r,
                            r: "4.5",
                            fill: "var(--prpg-rose)"
                        }), (0, a.jsx)("circle", {
                            cx: e,
                            cy: r,
                            r: "1.6",
                            fill: "var(--prpg-paper)"
                        })]
                    }, `${e}-${r}`))]
                })
            }

            function L({
                tie: e
            }) {
                let r = e ? "prpg-draw prpg-tie" : void 0;
                return (0, a.jsxs)("g", {
                    children: [(0, a.jsx)("path", {
                        className: r,
                        pathLength: 1,
                        d: "M128 212 Q160 222 192 212",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "8",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("path", {
                        className: r,
                        pathLength: 1,
                        d: "M160 216 C140 196 120 206 132 220 C140 228 152 222 160 216 C168 222 180 228 188 220 C200 206 180 196 160 216 Z",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "6",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("path", {
                        className: r,
                        pathLength: 1,
                        d: "M160 216 L146 248 M160 216 L176 246",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "6",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("circle", {
                        cx: "160",
                        cy: "216",
                        r: "6",
                        fill: "var(--f-accent)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2"
                    })]
                })
            }

            function $() {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 300 400",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "prpg-vine",
                    children: (0, a.jsx)("path", {
                        className: "prpg-draw prpg-vine-line",
                        pathLength: 1,
                        d: "M7 388 C4 300 10 220 6 140 C3 90 8 40 28 9 C90 3 150 11 210 5 C250 3 280 7 293 30",
                        fill: "none",
                        stroke: "var(--prpg-leafDeep)",
                        strokeWidth: "3",
                        strokeLinecap: "round"
                    })
                })
            }
        },
        43352: () => {},
        56128: (e, r, s) => {
            "use strict";
            s.r(r), s.d(r, {
                BloomBuds: () => h,
                BouquetMaker: () => m,
                CoverOpening: () => o,
                GardenPlant: () => g,
                PhotoFlip: () => j
            });
            var a = s(73365),
                l = s(1521),
                t = s(87191),
                i = s(34768),
                p = s(82161),
                n = s(7828);

            function o({
                skipLabel: e,
                children: r
            }) {
                let s = "edit" === (0, i.useMode)(),
                    p = (0, t.usePrefersReducedMotion)(),
                    n = (0, l.useRef)(null),
                    [d, c] = (0, l.useState)(!1),
                    [x, g] = (0, l.useState)(0),
                    f = s || p || d;
                return (0, t.useReplaySignal)(n, () => {
                    c(!1), g(e => e + 1)
                }), (0, l.useEffect)(() => {
                    if (f) return;
                    let e = window.setTimeout(() => c(!0), 7e3);
                    return () => window.clearTimeout(e)
                }, [f, x]), (0, a.jsxs)("div", {
                    ref: n,
                    className: "prpg-opening",
                    ...f ? {
                        "data-skip": ""
                    } : {},
                    onClickCapture: e => {
                        f || (e.preventDefault(), e.stopPropagation(), c(!0))
                    },
                    children: [f && !s ? null : (0, a.jsx)("button", {
                        type: "button",
                        className: "prpg-skip",
                        tabIndex: s ? -1 : void 0,
                        onClick: () => c(!0),
                        children: e
                    }), r]
                }, x)
            }
            s(43352);
            let d = [-38, 0, 38];

            function c({
                index: e
            }) {
                let r = ["var(--prpg-rose)", "var(--prpg-genda)", "var(--prpg-sada)"][e];
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 60 70",
                    "aria-hidden": !0,
                    className: "block h-[54px] w-[46px]",
                    children: [(0, a.jsx)("path", {
                        d: "M8 10 L52 10 L50 66 L10 66 Z",
                        fill: "var(--prpg-kraft)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "3",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("path", {
                        d: "M8 10 l4 -6 l4 6 l4 -6 l4 6 l4 -6 l4 6 l4 -6 l4 6 l4 -6 l4 6",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("circle", {
                        cx: "30",
                        cy: "34",
                        r: "12",
                        fill: r,
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5"
                    }), (0, a.jsx)("circle", {
                        cx: "30",
                        cy: "34",
                        r: "4",
                        fill: "var(--prpg-paper)"
                    }), (0, a.jsx)("path", {
                        d: "M18 56 h24",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5",
                        strokeLinecap: "round"
                    })]
                })
            }

            function x() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 90",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, a.jsx)("path", {
                        d: "M48 52 L10 26",
                        stroke: "var(--f-fg)",
                        strokeWidth: "11",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("path", {
                        d: "M48 52 L10 26",
                        stroke: "var(--prpg-water)",
                        strokeWidth: "5",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("path", {
                        d: "M2 18 L16 34 L20 20 Z",
                        fill: "var(--prpg-water)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "3",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("path", {
                        d: "M94 34 C116 34 118 72 96 72",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "6",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("path", {
                        d: "M42 30 L100 30 L96 82 L46 82 Z",
                        fill: "var(--prpg-water)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "3.5",
                        strokeLinejoin: "round"
                    }), (0, a.jsx)("path", {
                        d: "M48 48 q10 -8 20 0 q10 8 20 0 M50 64 q10 -8 20 0 q10 8 20 0",
                        fill: "none",
                        stroke: "var(--prpg-paper)",
                        strokeWidth: "3",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("ellipse", {
                        cx: "71",
                        cy: "30",
                        rx: "29",
                        ry: "5",
                        fill: "var(--prpg-paper)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "3"
                    })]
                })
            }

            function g({
                seeds: e,
                seedLabels: r,
                canLabel: s,
                plantHint: o,
                waterHint: f,
                pourButton: h,
                done: j
            }) {
                let v = "edit" === (0, i.useMode)(),
                    k = (0, p.useFolioSound)(),
                    u = (0, l.useRef)(null),
                    [m, y] = (0, l.useState)([!1, !1, !1]),
                    [M, w] = (0, l.useState)(0),
                    [b, N] = (0, l.useState)(!1),
                    C = (0, l.useRef)(!1);
                (0, t.useReplaySignal)(u, () => {
                    y([!1, !1, !1]), w(0), N(!1), C.current = !1
                });
                let W = v ? [!0, !0, !0] : m,
                    L = W.every(Boolean),
                    $ = v ? 100 : M,
                    Z = $ >= 100,
                    B = L ? Z ? "done" : "water" : "plant";
                (0, l.useEffect)(() => {
                    if (!b || Z) return;
                    let e = window.setInterval(() => w(e => Math.min(100, e + 4)), 80);
                    return () => window.clearInterval(e)
                }, [b, Z]);
                let {
                    playEffect: z
                } = k;
                (0, l.useEffect)(() => {
                    !Z || v || C.current || (C.current = !0, z("reveal"))
                }, [Z, v, z]);
                let V = e => {
                        v || Z || (k.unlock(e), k.playEffect("tap"), w(e => Math.min(100, e + 34)))
                    },
                    R = b && "water" === B,
                    S = "plant" === B ? W.some(Boolean) ? "happy" : "sleepy" : "water" === B ? R ? "wow" : "happy" : "love";
                return (0, a.jsxs)("div", {
                    ref: u,
                    className: "prpg-garden",
                    "data-phase": B,
                    ...R ? {
                        "data-pouring": ""
                    } : {},
                    children: [(0, a.jsxs)(n.AR, {
                        time: "day",
                        children: [(0, a.jsx)("svg", {
                            viewBox: "0 0 320 320",
                            "aria-hidden": !0,
                            className: "block size-full overflow-visible",
                            children: (0, a.jsxs)("g", {
                                transform: "translate(160 150)",
                                children: [(0, a.jsx)(n.me, {
                                    mood: S
                                }), (0, a.jsx)("ellipse", {
                                    cx: "0",
                                    cy: "-3",
                                    rx: "66",
                                    ry: "6",
                                    fill: "var(--prpg-soilWet)",
                                    style: {
                                        opacity: $ / 100 * .85
                                    },
                                    className: "prpg-wet"
                                }), d.map((e, r) => W[r] ? (0, a.jsxs)("g", {
                                    children: [(0, a.jsx)("ellipse", {
                                        className: "prpg-seed",
                                        cx: e,
                                        cy: "-6",
                                        rx: "5",
                                        ry: "3.5",
                                        fill: "var(--prpg-potDark)",
                                        stroke: "var(--f-fg)",
                                        strokeWidth: "2"
                                    }), (0, a.jsx)("path", {
                                        d: `M${e-10} -2 q10 -9 20 0`,
                                        fill: "var(--prpg-soil)",
                                        stroke: "var(--f-fg)",
                                        strokeWidth: "2"
                                    })]
                                }, e) : null), Z ? d.map((e, r) => (0, a.jsxs)("g", {
                                    className: "prpg-sprout",
                                    style: {
                                        "--i": r
                                    },
                                    children: [(0, a.jsx)("path", {
                                        className: "prpg-draw",
                                        pathLength: 1,
                                        d: `M${e} -4 Q${e+(r-1)*6} -24 ${e} -42`,
                                        fill: "none",
                                        stroke: "var(--prpg-leafDeep)",
                                        strokeWidth: "4.5",
                                        strokeLinecap: "round"
                                    }), (0, a.jsx)(n.hK, {
                                        x: e,
                                        y: -36,
                                        turn: -30
                                    }), (0, a.jsx)(n.hK, {
                                        x: e,
                                        y: -30,
                                        turn: -150
                                    })]
                                }, e)) : null, R ? Array.from({
                                    length: 7
                                }, (e, r) => (0, a.jsx)("path", {
                                    className: "prpg-drop",
                                    style: {
                                        "--i": r
                                    },
                                    d: `M${44+r%3*5} -78 c-3 5 -3 9 0 9 c3 0 3 -4 0 -9z`,
                                    fill: "var(--prpg-water)",
                                    stroke: "var(--f-fg)",
                                    strokeWidth: "1.2"
                                }, r)) : null]
                            })
                        }), (0, a.jsx)("div", {
                            className: "prpg-packets",
                            "aria-hidden": "plant" !== B || void 0,
                            children: e.map((e, s) => (0, a.jsxs)("button", {
                                type: "button",
                                className: "prpg-packet",
                                "aria-label": r[s],
                                disabled: v ? void 0 : m[s] || "plant" !== B,
                                tabIndex: v || "plant" !== B ? -1 : void 0,
                                ...W[s] ? {
                                    "data-used": ""
                                } : {},
                                onClick: e => {
                                    var r;
                                    return r = e.currentTarget, void(!v && !m[s] && (k.unlock(r), k.playEffect("pop"), y(e => e.map((e, r) => e || r === s))))
                                },
                                children: [(0, a.jsx)(c, {
                                    index: s
                                }), (0, a.jsx)("span", {
                                    className: "prpg-packet-name",
                                    children: e
                                })]
                            }, s))
                        }), (0, a.jsx)("button", {
                            type: "button",
                            className: "prpg-can",
                            "aria-label": s,
                            tabIndex: v || "water" !== B ? -1 : void 0,
                            onPointerDown: e => {
                                v || "water" !== B || (k.unlock(e.currentTarget), e.currentTarget.setPointerCapture ? .(e.pointerId), N(!0))
                            },
                            onPointerUp: () => N(!1),
                            onPointerCancel: () => N(!1),
                            onClick: e => {
                                0 === e.detail && V(e.currentTarget)
                            },
                            onContextMenu: e => e.preventDefault(),
                            children: (0, a.jsx)(x, {})
                        })]
                    }), (0, a.jsx)("div", {
                        className: "prpg-meter",
                        "aria-hidden": !0,
                        children: (0, a.jsx)("i", {
                            style: {
                                transform: `scaleX(${($/100).toFixed(2)})`
                            }
                        })
                    }), (0, a.jsx)("div", {
                        className: "prpg-garden-hint",
                        children: v ? (0, a.jsxs)(a.Fragment, {
                            children: [o, f]
                        }) : "plant" === B ? o : f
                    }), "water" === B || v ? (0, a.jsx)("button", {
                        type: "button",
                        className: "prpg-small-btn",
                        tabIndex: v ? -1 : void 0,
                        onClick: e => V(e.currentTarget),
                        children: h
                    }) : null, (0, a.jsx)("div", {
                        className: "prpg-done",
                        children: j
                    })]
                })
            }
            let f = [{
                kind: "rose",
                x: 78,
                y: 82,
                from: -30,
                bend: -26
            }, {
                kind: "marigold",
                x: 160,
                y: 52,
                from: 0,
                bend: 8
            }, {
                kind: "periwinkle",
                x: 242,
                y: 82,
                from: 30,
                bend: 26
            }];

            function h({
                notes: e,
                budLabels: r,
                hint: s,
                friend: o,
                done: d
            }) {
                let c = "edit" === (0, i.useMode)(),
                    x = (0, p.useFolioSound)(),
                    g = (0, l.useRef)(null),
                    [j, v] = (0, l.useState)([!1, !1, !1]),
                    [k, u] = (0, l.useState)(-1);
                (0, t.useReplaySignal)(g, () => {
                    v([!1, !1, !1]), u(-1)
                });
                let m = c ? [!0, !0, !0] : j,
                    y = m.filter(Boolean).length;
                return (0, a.jsxs)("div", {
                    ref: g,
                    className: "prpg-bloom",
                    "data-count": y,
                    ...3 === y ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsxs)(n.AR, {
                        time: "dawn",
                        height: 360,
                        bare: !0,
                        children: [(0, a.jsxs)("svg", {
                            viewBox: "0 0 320 360",
                            "aria-hidden": !0,
                            className: "block size-full overflow-visible",
                            children: [f.map(e => (0, a.jsx)(n.wt, {
                                x1: 160 + e.from,
                                y1: 176,
                                x2: e.x,
                                y2: e.y + 14,
                                bend: e.bend,
                                draw: !0
                            }, e.kind)), (0, a.jsx)(n.hK, {
                                x: 112,
                                y: 130,
                                turn: -160
                            }), (0, a.jsx)(n.hK, {
                                x: 204,
                                y: 124,
                                turn: -24
                            }), (0, a.jsx)(n.hK, {
                                x: 160,
                                y: 120,
                                turn: -70,
                                flip: !0
                            }), (0, a.jsx)("g", {
                                transform: "translate(160 180)",
                                children: (0, a.jsx)(n.me, {
                                    mood: 0 === y ? "shy" : y < 3 ? "happy" : "love"
                                })
                            }), f.map((e, r) => (0, a.jsx)("g", {
                                transform: `translate(${e.x} ${e.y})`,
                                children: m[r] ? (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)(n.wV, {
                                        kind: e.kind,
                                        bloom: !c
                                    }), c ? null : (0, a.jsx)("g", {
                                        className: "prpg-spark",
                                        children: [0, 45, 90, 135, 180, 225, 270, 315].map(e => (0, a.jsx)("path", {
                                            transform: `rotate(${e})`,
                                            d: "M0 -38 V-48",
                                            stroke: "var(--prpg-genda)",
                                            strokeWidth: "3.5",
                                            strokeLinecap: "round"
                                        }, e))
                                    })]
                                }) : (0, a.jsx)("g", {
                                    className: "prpg-bud-wait",
                                    children: (0, a.jsx)(n.s7, {
                                        kind: e.kind
                                    })
                                })
                            }, e.kind))]
                        }), f.map((e, s) => (0, a.jsx)("button", {
                            type: "button",
                            className: "prpg-bud-btn",
                            style: {
                                left: `${(e.x/320*100).toFixed(2)}%`,
                                top: `${(e.y/360*100).toFixed(2)}%`
                            },
                            "aria-label": r[s],
                            tabIndex: c ? -1 : void 0,
                            ...m[s] ? {
                                "data-open": ""
                            } : {},
                            onClick: e => {
                                var r;
                                return r = e.currentTarget, void(!c && (x.unlock(r), x.playEffect(2 !== j.filter(Boolean).length || j[s] ? "reveal" : "win"), v(e => e.map((e, r) => e || r === s)), u(s)))
                            }
                        }, e.kind)), (0, a.jsx)("div", {
                            className: "prpg-friend",
                            children: o
                        })]
                    }), c ? (0, a.jsxs)("div", {
                        className: "prpg-notes-edit",
                        children: [(0, a.jsx)("div", {
                            className: "prpg-bubble-hint",
                            children: s
                        }), e.map((e, r) => (0, a.jsx)("div", {
                            className: "prpg-bubble",
                            children: e
                        }, r))]
                    }) : (0, a.jsx)("div", {
                        className: "prpg-bubble-slot",
                        "aria-live": "polite",
                        children: k >= 0 ? (0, a.jsx)("div", {
                            className: "prpg-bubble prpg-bubble-pop",
                            "data-kind": f[k].kind,
                            children: e[k]
                        }, k) : (0, a.jsx)("div", {
                            className: "prpg-bubble-hint",
                            children: s
                        })
                    }), (0, a.jsx)("div", {
                        className: "prpg-done",
                        children: d
                    })]
                })
            }

            function j({
                label: e,
                front: r,
                back: s
            }) {
                let n = "edit" === (0, i.useMode)(),
                    o = (0, p.useFolioSound)(),
                    d = (0, l.useRef)(null),
                    [c, x] = (0, l.useState)(!1);
                return ((0, t.useReplaySignal)(d, () => x(!1)), n) ? (0, a.jsx)("div", {
                    className: "prpg-polaroid prpg-face-front",
                    children: r
                }) : (0, a.jsx)("button", {
                    ref: d,
                    type: "button",
                    className: "prpg-polaroid",
                    "aria-label": e,
                    "aria-pressed": c,
                    ...c ? {
                        "data-flipped": ""
                    } : {},
                    onClick: e => {
                        o.unlock(e.currentTarget), o.playEffect("tap"), x(e => !e)
                    },
                    children: (0, a.jsxs)("span", {
                        className: "prpg-flip",
                        children: [(0, a.jsx)("span", {
                            className: "prpg-face-front",
                            children: r
                        }), (0, a.jsx)("span", {
                            className: "prpg-face-back",
                            children: s
                        })]
                    })
                })
            }
            let v = ["rose", "marigold", "periwinkle", "rose", "marigold"],
                k = [{
                    x: 112,
                    y: 96,
                    bend: -10
                }, {
                    x: 160,
                    y: 70,
                    bend: 0
                }, {
                    x: 208,
                    y: 96,
                    bend: 10
                }],
                u = k.length;

            function m({
                flowerLabel: e,
                tag: r,
                hint: s,
                done: o
            }) {
                let d = "edit" === (0, i.useMode)(),
                    c = (0, p.useFolioSound)(),
                    x = (0, l.useRef)(null),
                    g = (0, l.useRef)(null),
                    [f, h] = (0, l.useState)([]),
                    [j, y] = (0, l.useState)(null);
                (0, t.useReplaySignal)(x, () => {
                    h([]), y(null)
                });
                let M = d ? [0, 1, 2] : f,
                    w = M.length >= u,
                    b = (e, r) => {
                        d || w || f.includes(e) || (c.unlock(r), c.playEffect(f.length + 1 === u ? "win" : "pop"), h(r => r.length < u && !r.includes(e) ? [...r, e] : r))
                    },
                    N = e => {
                        j && y({ ...j,
                            dx: e.clientX - j.x0,
                            dy: e.clientY - j.y0
                        })
                    },
                    C = e => {
                        if (!j) return;
                        let r = Math.hypot(j.dx, j.dy),
                            s = g.current ? .getBoundingClientRect(),
                            a = !!s && e.clientX >= s.left && e.clientX <= s.right && e.clientY >= s.top && e.clientY <= s.bottom;
                        (r < 8 || a) && b(j.index, e.currentTarget), y(null)
                    };
                return (0, a.jsxs)("div", {
                    ref: x,
                    className: "prpg-bouquet",
                    ...w ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsx)("div", {
                        className: "prpg-choices",
                        children: v.map((r, s) => {
                            let l = M.includes(s),
                                t = j ? .index === s;
                            return (0, a.jsx)("button", {
                                type: "button",
                                className: "prpg-choice",
                                "aria-label": e,
                                tabIndex: d || l || w ? -1 : void 0,
                                ...l ? {
                                    "data-used": ""
                                } : {},
                                ...t ? {
                                    "data-drag": ""
                                } : {},
                                style: t ? {
                                    transform: `translate(${j.dx}px, ${j.dy}px) scale(1.12)`
                                } : void 0,
                                onPointerDown: e => {
                                    !d && !w && (e.currentTarget.setPointerCapture ? .(e.pointerId), y({
                                        index: s,
                                        x0: e.clientX,
                                        y0: e.clientY,
                                        dx: 0,
                                        dy: 0
                                    }))
                                },
                                onPointerMove: N,
                                onPointerUp: C,
                                onPointerCancel: () => y(null),
                                onClick: e => {
                                    0 === e.detail && b(s, e.currentTarget)
                                },
                                children: (0, a.jsxs)("svg", {
                                    viewBox: "-34 -34 68 96",
                                    "aria-hidden": !0,
                                    className: "block size-full overflow-visible",
                                    children: [(0, a.jsx)("path", {
                                        d: "M0 10 V58",
                                        stroke: "var(--prpg-leafDeep)",
                                        strokeWidth: "4.5",
                                        strokeLinecap: "round"
                                    }), (0, a.jsx)(n.hK, {
                                        x: 0,
                                        y: 44,
                                        turn: -30
                                    }), (0, a.jsx)(n.wV, {
                                        kind: r
                                    })]
                                })
                            }, s)
                        })
                    }), (0, a.jsxs)(n.AR, {
                        time: "day",
                        bare: !0,
                        children: [(0, a.jsxs)("svg", {
                            viewBox: "0 0 320 320",
                            "aria-hidden": !0,
                            className: "block size-full overflow-visible",
                            children: [M.map((e, r) => {
                                let s = k[r];
                                return (0, a.jsxs)("g", {
                                    className: "prpg-in-cone",
                                    children: [(0, a.jsx)(n.wt, {
                                        x1: 160,
                                        y1: 200,
                                        x2: s.x,
                                        y2: s.y,
                                        bend: s.bend
                                    }), (0, a.jsx)("g", {
                                        transform: `translate(${s.x} ${s.y})`,
                                        children: (0, a.jsx)(n.wV, {
                                            kind: v[e]
                                        })
                                    })]
                                }, e)
                            }), (0, a.jsx)(n.Sd, {}), w ? (0, a.jsx)(n.je, {
                                tie: !d
                            }) : null]
                        }), (0, a.jsx)("div", {
                            ref: g,
                            className: "prpg-cone-zone",
                            "aria-hidden": !0
                        }), (0, a.jsx)("div", {
                            className: "prpg-tag",
                            children: r
                        })]
                    }), (0, a.jsx)("div", {
                        className: "prpg-garden-hint",
                        children: s
                    }), (0, a.jsx)("div", {
                        className: "prpg-done",
                        children: o
                    })]
                })
            }
        }
    }
]);