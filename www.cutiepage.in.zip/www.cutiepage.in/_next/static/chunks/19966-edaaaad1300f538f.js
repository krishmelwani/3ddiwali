(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [19966], {
        2514: (e, t, a) => {
            "use strict";
            a.d(t, {
                OZ: () => v,
                NY: () => r,
                KR: () => l,
                Ez: () => i,
                TE: () => o,
                _G: () => c,
                Ty: () => s,
                L3: () => d,
                AQ: () => j,
                WS: () => N,
                o3: () => h,
                xX: () => b,
                ky: () => w,
                YK: () => g,
                aO: () => m,
                yJ: () => p,
                z: () => C,
                Xl: () => S,
                JZ: () => f,
                Vq: () => k
            });
            var n = a(47433);
            let r = 50,
                i = [{
                    value: "birthday",
                    label: "Birthday",
                    noun: "birthday"
                }, {
                    value: "anniversary",
                    label: "Anniversary",
                    noun: "anniversary"
                }, {
                    value: "valentines",
                    label: "Valentine's Day",
                    noun: "Valentine's Day"
                }, {
                    value: "friendship",
                    label: "Friendship Day",
                    noun: "Friendship Day"
                }, {
                    value: "wedding",
                    label: "Wedding day",
                    noun: "wedding day"
                }, {
                    value: "other",
                    label: "Something else",
                    noun: "special day"
                }],
                s = ["Partner", "Wife", "Husband", "Girlfriend", "Boyfriend", "Best friend", "Friend", "Mom", "Dad", "Sister", "Brother", "Colleague"],
                l = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                o = 60,
                c = 40;

            function d(e) {
                return [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][e - 1] ? ? 31
            }

            function u(e) {
                return i.some(t => t.value === e)
            }

            function m(e) {
                return i.find(t => t.value === e) ? .label ? ? "Special day"
            }

            function p(e) {
                return i.find(t => t.value === e) ? .noun ? ? "special day"
            }

            function f(e) {
                return n.$I.find(t => t.slug === e) ? .name ? ? null
            }

            function h(e) {
                switch (e) {
                    case "birthday":
                        return "birthday";
                    case "anniversary":
                        return "anniversary";
                    case "valentines":
                        return "love";
                    case "friendship":
                        return "friendship";
                    case "wedding":
                        return "wedding";
                    default:
                        return null
                }
            }

            function y(e, t, a) {
                let n = "string" == typeof e && "" !== e.trim() ? Number(e) : e;
                return "number" == typeof n && Number.isInteger(n) && n >= t && n <= a ? n : null
            }

            function x(e) {
                return "string" == typeof e && e.trim() ? e.trim() : null
            }

            function g(e) {
                if (!e || "object" != typeof e) return null;
                let t = x(e.id),
                    a = x(e.personName);
                if (!t || !a) return null;
                let n = y(e.month, 1, 12),
                    r = y(e.day, 1, 31);
                if ((null === n || null === r) && "string" == typeof e.eventDate) {
                    let t = /^\d{4}-(\d{2})-(\d{2})/.exec(e.eventDate);
                    t && (n = y(Number(t[1]), 1, 12), r = y(Number(t[2]), 1, 31))
                }
                return null === n || null === r || r > d(n) ? null : {
                    id: t,
                    personName: a,
                    relation: x(e.relation),
                    occasionType: x(e.occasionType) ? ? "other",
                    month: n,
                    day: r,
                    templateCategory: x(e.templateCategory),
                    active: !1 !== e.active,
                    unsubscribed: !!e.unsubscribedAt
                }
            }
            let v = {
                personName: "",
                relation: "",
                occasionType: "birthday",
                month: "",
                day: "",
                templateCategory: ""
            };

            function b(e) {
                return {
                    personName: e.personName,
                    relation: e.relation ? ? "",
                    occasionType: u(e.occasionType) ? e.occasionType : "other",
                    month: String(e.month),
                    day: String(e.day),
                    templateCategory: e.templateCategory ? ? ""
                }
            }

            function k(e) {
                var t;
                let a = {},
                    r = e.personName.replace(/\s+/g, " ").trim(),
                    i = e.relation.replace(/\s+/g, " ").trim(),
                    s = y(e.month, 1, 12),
                    m = y(e.day, 1, 31);
                if (r ? r.length > o && (a.personName = `Keep it under ${o} letters.`) : a.personName = "Add their name.", i.length > c && (a.relation = `Keep it under ${c} letters.`), u(e.occasionType) || (a.occasionType = "Pick an occasion."), null === s && (a.month = "Pick a month."), null === m ? a.day = "Pick a day." : null !== s && m > d(s) && (a.day = `${l[s-1]} has ${d(s)} days.`), e.templateCategory && (t = e.templateCategory, !n.$I.some(e => e.slug === t)) && (a.templateCategory = "Pick a kind of page."), Object.keys(a).length > 0 || null === s || null === m || !u(e.occasionType)) return {
                    ok: !1,
                    errors: a
                };
                let p = e.templateCategory || h(e.occasionType);
                return {
                    ok: !0,
                    body: {
                        personName: r,
                        ...i ? {
                            relation: i
                        } : {},
                        occasionType: e.occasionType,
                        month: s,
                        day: m,
                        ...p ? {
                            templateCategory: p
                        } : {}
                    }
                }
            }

            function j(e, t, a = new Date) {
                let n = new Date(a.getFullYear(), a.getMonth(), a.getDate());
                return Math.round(((function(e, t, a = new Date) {
                    let n = new Date(a.getFullYear(), a.getMonth(), a.getDate()),
                        r = a => new Date(a, e - 1, 2 === e && 29 === t && (a % 4 != 0 || a % 100 == 0) && a % 400 != 0 ? 28 : t),
                        i = r(n.getFullYear());
                    return i >= n ? i : r(n.getFullYear() + 1)
                })(e, t, a).getTime() - n.getTime()) / 864e5)
            }

            function N(e) {
                if (0 === e) return "Today";
                if (1 === e) return "Tomorrow";
                if (e < 60) return `In ${e} days`;
                let t = Math.round(e / 30);
                return `In about ${t} months`
            }

            function w(e, t) {
                return `${t} ${l[e-1]??""}`.trim()
            }

            function S(e, t = new Date) {
                return [...e].sort((e, a) => j(e.month, e.day, t) - j(a.month, a.day, t))
            }

            function C(e) {
                var t;
                let a = p(e.occasionType);
                return e.personName ? `Remind me before ${t=e.personName,`${t}\u2019s`} next ${a}` : `Remind me before their next ${a}`
            }
            l.map(e => e.slice(0, 3).toLowerCase())
        },
        15381: (e, t, a) => {
            "use strict";
            a.d(t, {
                v: () => i
            });
            var n = a(73365),
                r = a(2911);

            function i({
                stage: e,
                progress: t
            }) {
                let a = "creating" === e ? "Setting up your page\u2026" : "uploading" === e ? t && t.total > 1 ? `Saving your customisations (${t.done} of ${t.total})\u2026` : "Saving your customisations\u2026" : "Getting your page ready\u2026";
                return (0, n.jsxs)("div", {
                    role: "status",
                    "aria-live": "polite",
                    className: "fixed inset-0 z-[130] flex flex-col items-center justify-center gap-4 bg-cp-canvas/95 backdrop-blur-sm",
                    children: [(0, n.jsx)(r.A, {
                        className: "size-7 animate-spin text-cp-primary motion-reduce:animate-none",
                        strokeWidth: 2
                    }), (0, n.jsx)("p", {
                        className: "text-[15px] font-semibold text-cp-ink",
                        children: a
                    }), (0, n.jsx)("p", {
                        className: "max-w-xs text-center text-[13px] text-cp-muted",
                        children: "Keep this tab open. If it doesn't update in 6 seconds, please refresh the page. Your edits are safe."
                    })]
                })
            }
        },
        58034: (e, t, a) => {
            "use strict";
            a.d(t, {
                ReminderPrompt: () => g,
                e: () => x
            });
            var n = a(73365),
                r = a(1521),
                i = a(99568),
                s = a.n(i),
                l = a(83078),
                o = a(32967),
                c = a(9388),
                d = a(17001),
                u = a(87583),
                m = a(54872),
                p = a(76823),
                f = a(2514),
                h = a(83989);
            let y = "cp_reminder_prompt_v1:";

            function x(e) {
                if (!e) return !1;
                try {
                    return null !== window.localStorage.getItem(y + e)
                } catch {
                    return !1
                }
            }

            function g({
                prefill: e,
                surface: t,
                projectId: a,
                templateSlug: i,
                variant: v = "card",
                onEngage: b,
                className: k
            }) {
                let j = (0, r.useId)(),
                    [N, w] = (0, r.useState)(!1),
                    [S, C] = (0, r.useState)("idle"),
                    [T, $] = (0, r.useState)(e.personName ? ? ""),
                    [P, z] = (0, r.useState)(e.day ? String(e.day) : ""),
                    [D, A] = (0, r.useState)(e.month ? String(e.month) : ""),
                    [I, E] = (0, r.useState)({}),
                    [_, M] = (0, r.useState)(null),
                    R = (0, r.useRef)(null);

                function F(e) {
                    if (a) try {
                        window.localStorage.setItem(y + a, e)
                    } catch {}
                    C(e), "saved" === e ? setTimeout(() => R.current ? .(), 1200) : R.current ? .()
                }
                async function O() {
                    let a = (0, f.Vq)({
                        personName: T,
                        relation: "",
                        occasionType: e.occasionType,
                        month: D,
                        day: P,
                        templateCategory: e.templateCategory ? ? ""
                    });
                    if (!a.ok) {
                        E(a.errors), C("form");
                        return
                    }
                    C("saving"), M(null);
                    let n = await (0, h.XU)(a.body, {
                        keepalive: "paid_setup" === t
                    });
                    if (!n.ok) {
                        M(n.message), C("form");
                        return
                    }(0, p.X)(t, {
                        occasionType: e.occasionType,
                        prefilled: !!e.personName,
                        templateSlug: i
                    }), F("saved")
                }
                if ((0, r.useEffect)(() => {
                        x(a) || (w(!0), (0, p.Z)(t, i))
                    }, [a, t, i]), (0, r.useEffect)(() => () => R.current ? .(), []), !N || "dismissed" === S) return null;
                let Y = T.trim(),
                    W = Number(D) ? (0, f.L3)(Number(D)) : 31,
                    K = "saved" === S ? (0, n.jsxs)("div", {
                        role: "status",
                        className: "flex items-start gap-3",
                        children: [(0, n.jsx)(l.A, {
                            className: "mt-0.5 size-5 shrink-0 text-cp-success-ink",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }), (0, n.jsxs)("div", {
                            className: "min-w-0",
                            children: [(0, n.jsxs)("p", {
                                className: "m-0 text-[14px] font-semibold text-cp-ink",
                                children: ["Done. We\u2019ll remind you a week before ", Y ? `${Y}\u2019s` : "their", " ", (0, f.yJ)(e.occasionType), "."]
                            }), "success" === t ? (0, n.jsx)(s(), {
                                href: "/dashboard/dates",
                                prefetch: !1,
                                className: "mt-1 inline-block text-[13px] font-medium text-cp-primary underline underline-offset-4",
                                children: "See your dates"
                            }) : null]
                        })]
                    }) : "idle" === S ? (0, n.jsxs)("div", {
                        className: "flex flex-col gap-3",
                        children: [(0, n.jsxs)("div", {
                            className: "flex items-start gap-3",
                            children: [(0, n.jsx)("span", {
                                className: "flex size-9 shrink-0 items-center justify-center rounded-xl bg-cp-primary-soft text-cp-primary",
                                children: (0, n.jsx)(o.A, {
                                    className: "size-4",
                                    strokeWidth: 1.75,
                                    "aria-hidden": !0
                                })
                            }), (0, n.jsxs)("div", {
                                className: "min-w-0",
                                children: [(0, n.jsx)("p", {
                                    className: "m-0 text-[14px] font-semibold text-cp-ink",
                                    children: "Never miss the next one"
                                }), (0, n.jsx)("p", {
                                    className: "m-0 mt-0.5 text-[13px] leading-5 text-cp-muted",
                                    children: "We\u2019ll email you a week before, every year."
                                })]
                            })]
                        }), (0, n.jsxs)("div", {
                            className: "flex flex-wrap items-center gap-2",
                            children: [(0, n.jsx)(c.$, {
                                size: "sm",
                                variant: "secondary",
                                className: "h-auto min-h-9 max-w-full whitespace-normal py-2 text-left",
                                onClick: function() {
                                    ! function() {
                                        if (!b || R.current) return;
                                        let e = () => {},
                                            t = new Promise(t => {
                                                let a = setTimeout(t, 12e4);
                                                e = () => {
                                                    clearTimeout(a), t()
                                                }
                                            });
                                        R.current = () => {
                                            R.current = null, e()
                                        }, b(t)
                                    }(), e.personName && e.month && e.day ? O() : C("form")
                                },
                                children: (0, f.z)({
                                    personName: e.personName,
                                    occasionType: e.occasionType
                                })
                            }), (0, n.jsx)(c.$, {
                                size: "sm",
                                variant: "ghost",
                                onClick: () => F("dismissed"),
                                children: "Not now"
                            })]
                        })]
                    }) : (0, n.jsxs)("form", {
                        noValidate: !0,
                        className: "flex flex-col gap-3",
                        onSubmit: e => {
                            e.preventDefault(), O()
                        },
                        children: [(0, n.jsxs)("p", {
                            className: "m-0 text-[14px] font-semibold text-cp-ink",
                            children: ["When is ", T.trim() ? `${T.trim()}\u2019s` : "their", " ", (0, f.yJ)(e.occasionType), "?"]
                        }), e.personName ? null : (0, n.jsx)(d.D0, {
                            label: "Their name",
                            htmlFor: `${j}-name`,
                            error: I.personName,
                            children: (0, n.jsx)(d.pd, {
                                id: `${j}-name`,
                                inputSize: "sm",
                                value: T,
                                onChange: e => {
                                    $(e.target.value), E(e => ({ ...e,
                                        personName: void 0
                                    }))
                                },
                                placeholder: "Riya",
                                autoComplete: "off",
                                maxLength: f.TE + 10,
                                invalid: !!I.personName
                            })
                        }), (0, n.jsxs)("div", {
                            className: "grid grid-cols-[minmax(0,2fr)_minmax(0,3fr)] gap-2",
                            children: [(0, n.jsx)(d.D0, {
                                label: "Day",
                                htmlFor: `${j}-day`,
                                error: I.day,
                                children: (0, n.jsxs)(u.l, {
                                    id: `${j}-day`,
                                    inputSize: "sm",
                                    value: P,
                                    onChange: e => {
                                        z(e.target.value), E(e => ({ ...e,
                                            day: void 0
                                        }))
                                    },
                                    invalid: !!I.day,
                                    children: [(0, n.jsx)("option", {
                                        value: "",
                                        children: "Day"
                                    }), Array.from({
                                        length: W
                                    }, (e, t) => (0, n.jsx)("option", {
                                        value: String(t + 1),
                                        children: t + 1
                                    }, t + 1))]
                                })
                            }), (0, n.jsx)(d.D0, {
                                label: "Month",
                                htmlFor: `${j}-month`,
                                error: I.month,
                                children: (0, n.jsxs)(u.l, {
                                    id: `${j}-month`,
                                    inputSize: "sm",
                                    value: D,
                                    onChange: e => {
                                        A(e.target.value), E(e => ({ ...e,
                                            month: void 0
                                        }))
                                    },
                                    invalid: !!I.month,
                                    children: [(0, n.jsx)("option", {
                                        value: "",
                                        children: "Month"
                                    }), f.KR.map((e, t) => (0, n.jsx)("option", {
                                        value: String(t + 1),
                                        children: e
                                    }, e))]
                                })
                            })]
                        }), _ ? (0, n.jsx)("p", {
                            role: "alert",
                            className: "m-0 text-[12.5px] text-cp-danger-ink",
                            children: _
                        }) : null, (0, n.jsxs)("div", {
                            className: "flex flex-wrap items-center gap-2",
                            children: [(0, n.jsx)(c.$, {
                                type: "submit",
                                size: "sm",
                                loading: "saving" === S,
                                children: "Remind me"
                            }), (0, n.jsx)(c.$, {
                                type: "button",
                                size: "sm",
                                variant: "ghost",
                                disabled: "saving" === S,
                                onClick: () => F("dismissed"),
                                children: "Not now"
                            })]
                        })]
                    });
                return "sheet" === v ? (0, n.jsx)("div", {
                    className: (0, m.cn)("fixed inset-x-0 bottom-0 z-[151] px-4 pb-4", k),
                    children: (0, n.jsx)("div", {
                        className: "mx-auto w-full max-w-sm rounded-2xl border border-cp-line bg-cp-bg p-4 shadow-cp-modal",
                        children: K
                    })
                }) : (0, n.jsx)("section", {
                    className: (0, m.cn)("rounded-xl border border-cp-line bg-cp-bg p-4 sm:p-5", k),
                    children: K
                })
            }
        },
        76823: (e, t, a) => {
            "use strict";
            a.d(t, {
                X: () => i,
                Z: () => r
            });
            var n = a(37809);

            function r(e, t) {
                (0, n.G4)({
                    name: "reminder_prompt_view",
                    template_slug: t ? ? void 0,
                    props: {
                        surface: e
                    }
                })
            }

            function i(e, t) {
                (0, n.G4)({
                    name: "reminder_saved",
                    template_slug: t.templateSlug ? ? void 0,
                    props: {
                        surface: e,
                        occasion: t.occasionType,
                        ...void 0 !== t.prefilled ? {
                            prefilled: t.prefilled
                        } : {}
                    }
                }), "paid_setup" === e && (0, n.Sm)(!0)
            }
        },
        77082: (e, t, a) => {
            "use strict";
            a.d(t, {
                S: () => O,
                v: () => M
            });
            var n = a(73365),
                r = a(1521),
                i = a(86714),
                s = a(98196),
                l = a(80289),
                o = a(23408),
                c = a(79678),
                d = a(97587),
                u = a(68279),
                m = a(14578),
                p = a(88786),
                f = a(85815),
                h = a.n(f),
                y = a(14825),
                x = a.n(y),
                g = a(54872);
            a(78680);
            var v = a(35104),
                b = a(91511);
            let k = (0, b.createServerReference)("40347ebbe1b261b6e58e3ea70840974f8cacbe0329", b.callServer, void 0, b.findSourceMapURL, "loadReminderPrefill");
            var j = a(58034);

            function N({
                templateSlug: e,
                projectId: t,
                getContent: a,
                onEngage: i
            }) {
                let [s, l] = (0, r.useState)(null), o = (0, r.useRef)(void 0);
                return (void 0 === o.current && (o.current = a() ? ? null), (0, r.useEffect)(() => {
                    if ((0, j.e)(t)) return;
                    let a = !1;
                    return k({
                        templateSlug: e,
                        content: o.current
                    }).then(e => {
                        a || l(e)
                    }, () => {}), () => {
                        a = !0
                    }
                }, [e, t]), s) ? (0, n.jsx)(j.ReminderPrompt, {
                    prefill: s,
                    surface: "paid_setup",
                    projectId: t,
                    templateSlug: e,
                    variant: "sheet",
                    onEngage: i
                }) : null
            }
            var w = a(82055),
                S = a(36084),
                C = a(83078),
                T = a(2911),
                $ = a(64369);
            let P = ["Preparing your page\u2026", "Adding your photos and words\u2026", "Making a little magic\u2026", "Almost ready\u2026"],
                z = [{
                    className: "top-[12%] left-[10%] size-10 rounded-full bg-cp-primary-soft",
                    delay: "0ms"
                }, {
                    className: "top-[20%] right-[12%] size-6 rounded-md rotate-12 bg-cp-primary/25",
                    delay: "300ms"
                }, {
                    className: "bottom-[22%] left-[16%] size-7 rounded-md -rotate-12 bg-cp-primary/20",
                    delay: "600ms"
                }, {
                    className: "bottom-[14%] right-[18%] size-12 rounded-full bg-cp-primary-soft",
                    delay: "900ms"
                }, {
                    className: "top-[42%] left-[6%] size-4 rounded-full bg-cp-primary/30",
                    delay: "450ms"
                }, {
                    className: "top-[38%] right-[6%] size-5 rounded-full bg-cp-primary/25",
                    delay: "750ms"
                }];

            function D({
                paid: e,
                preparing: t,
                href: a,
                reminder: r,
                video: i = !1
            }) {
                return (0, n.jsxs)(n.Fragment, {
                    children: [t ? (0, n.jsx)(E, {
                        href: a
                    }) : (0, n.jsx)(I, {
                        paid: e,
                        href: a,
                        video: i
                    }), r]
                })
            }

            function A({
                href: e
            }) {
                let [t, a] = (0, r.useState)(!1);
                return ((0, r.useEffect)(() => {
                    if (!e) return;
                    let t = setTimeout(() => a(!0), 4e3);
                    return () => clearTimeout(t)
                }, [e]), e && t) ? (0, n.jsx)("a", {
                    href: e,
                    className: "relative mt-1 inline-flex min-h-11 items-center justify-center rounded-full bg-cp-primary px-6 text-[15px] font-semibold text-white no-underline",
                    children: "Continue"
                }) : null
            }

            function I({
                paid: e,
                href: t,
                video: a
            }) {
                return (0, n.jsx)("div", {
                    className: "fixed inset-0 z-[150] flex items-center justify-center bg-cp-ink/40 px-6",
                    children: (0, n.jsxs)("div", {
                        role: "status",
                        "aria-live": "polite",
                        className: "flex w-full max-w-sm flex-col items-center gap-3 rounded-2xl bg-cp-bg p-6 text-center shadow-cp-modal",
                        children: [(0, n.jsx)(C.A, {
                            className: "size-12 text-cp-success-ink",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }), (0, n.jsx)("p", {
                            className: "m-0 text-[18px] font-semibold text-cp-ink",
                            children: e ? "Payment successful" : a ? "This video is already yours" : "This page is already yours"
                        }), (0, n.jsxs)("p", {
                            className: "m-0 flex items-center gap-2 text-[14px] text-cp-muted",
                            children: [(0, n.jsx)(T.A, {
                                className: "size-4 animate-spin motion-reduce:animate-none",
                                "aria-hidden": !0
                            }), a ? "Taking you to your video\u2026" : "Taking you to make it live\u2026"]
                        }), (0, n.jsx)("p", {
                            className: "m-0 mt-1 rounded-xl bg-cp-primary-soft px-4 py-3 text-[13px] leading-5 text-cp-ink",
                            children: a ? `Note: you can edit photos and words for ${w.kq} hours, and download your video anytime.` : "Note: you can make unlimited edits, even after it\u2019s live."
                        }), (0, n.jsx)(A, {
                            href: t
                        })]
                    })
                })
            }

            function E({
                href: e
            }) {
                let [t, a] = (0, r.useState)(0);
                return (0, r.useEffect)(() => {
                    let e = setInterval(() => a(e => Math.min(e + 1, P.length - 1)), 1600);
                    return () => clearInterval(e)
                }, []), (0, n.jsxs)("div", {
                    role: "status",
                    "aria-live": "polite",
                    className: "fixed inset-0 z-[150] flex flex-col items-center justify-center gap-7 overflow-hidden bg-cp-canvas px-8 text-center",
                    children: [z.map(e => (0, n.jsx)("span", {
                        "aria-hidden": !0,
                        className: `absolute animate-bounce motion-reduce:animate-none ${e.className}`,
                        style: {
                            animationDelay: e.delay,
                            animationDuration: "2.4s"
                        }
                    }, e.className)), (0, n.jsxs)("div", {
                        className: "relative flex size-24 items-center justify-center",
                        children: [(0, n.jsx)("span", {
                            "aria-hidden": !0,
                            className: "absolute inset-0 animate-ping rounded-full bg-cp-primary-soft motion-reduce:animate-none"
                        }), (0, n.jsx)("span", {
                            "aria-hidden": !0,
                            className: "absolute inset-3 rounded-full bg-cp-primary-soft"
                        }), (0, n.jsx)($.A, {
                            className: "relative size-10 animate-pulse fill-cp-primary text-cp-primary motion-reduce:animate-none",
                            strokeWidth: 1.5,
                            "aria-hidden": !0
                        })]
                    }), (0, n.jsxs)("div", {
                        className: "relative flex flex-col items-center gap-2",
                        children: [(0, n.jsx)("p", {
                            className: "m-0 animate-pulse text-[18px] font-semibold text-cp-ink motion-reduce:animate-none",
                            children: P[t]
                        }, t), (0, n.jsx)("p", {
                            className: "m-0 text-[14px] text-cp-muted",
                            children: "Your payment is done. Please keep this page open."
                        }), (0, n.jsx)(A, {
                            href: e
                        })]
                    }), (0, n.jsx)("div", {
                        className: "relative h-1.5 w-48 overflow-hidden rounded-full bg-cp-line",
                        children: (0, n.jsx)("div", {
                            className: "h-full rounded-full bg-cp-primary transition-[width] duration-[1600ms] ease-out",
                            style: {
                                width: `${Math.round((t+1)/P.length*92)}%`
                            }
                        })
                    })]
                })
            }
            let _ = (0, i.default)(() => Promise.all([a.e(59082), a.e(76139), a.e(54990), a.e(48106)]).then(a.bind(a, 54990)).then(e => e.CheckoutExperience), {
                loadableGenerated: {
                    webpack: () => [54990]
                },
                ssr: !1
            });

            function M() {
                return (0, d.k)() || (0, o.Ij)()
            }
            let R = new Map,
                F = () => () => {};

            function O({
                open: e,
                onClose: t,
                templateSlug: i,
                templateName: l,
                priceInr: o,
                invitePlans: d = null,
                togetherPlans: f = null,
                nextPath: h,
                signedIn: y,
                getDraft: x,
                onClaimStart: g,
                afterSave: b
            }) {
                let [k, j] = (0, r.useState)(void 0), [C, T] = (0, r.useState)({
                    emailOtp: !0,
                    whatsapp: !0,
                    whatsappSendsCode: !1
                }), [$, P] = (0, r.useState)(!1), [z, A] = (0, r.useState)(!1), [I, E] = (0, r.useState)(!1), [M, W] = (0, r.useState)(null), [K, L] = (0, r.useState)(""), [J, U] = (0, r.useState)(null), B = (0, r.useRef)(null), G = (0, r.useRef)(null), X = (0, r.useRef)(!1), V = (0, r.useSyncExternalStore)(F, () => (0, m.f)(navigator.userAgent), () => !1), q = (0, w.K2)(i);
                (0, r.useEffect)(() => {
                    let e, t = !1;
                    return (!(e = R.get(i)) && (e = fetch(`/api/checkout/preview?template=${encodeURIComponent(i)}`).then(async e => e.ok ? (await e.json()).data : null).catch(() => null), R.set(i, e)), e).then(e => {
                        t || j(e)
                    }), Promise.all([a.e(59082), a.e(76139), a.e(54990), a.e(48106)]).then(a.bind(a, 54990)).catch(() => {}), () => {
                        t = !0
                    }
                }, [i]), (0, r.useEffect)(() => {
                    e && fetch("/api/warm", {
                        cache: "no-store"
                    }).catch(() => {})
                }, [e]), (0, r.useEffect)(() => {
                    if (!e) return;
                    let t = !1,
                        a = e => {
                            t || T({
                                emailOtp: e.emailOtp,
                                whatsapp: !0 === e.whatsapp,
                                whatsappSendsCode: !0 === e.whatsappSendsCode
                            })
                        },
                        n = (0, c.O5)();
                    return n && a(n), (0, c.tz)(6e4).then(a), () => {
                        t = !0
                    }
                }, [e]);
                let Z = (0, r.useCallback)(e => {
                        let t = x();
                        return t ? (0, v.wt)(t, {
                            intoProjectId: e,
                            keepDraft: !0
                        }).then(async t => t.ok ? (await b ? .(e).catch(() => {}), !0) : ((0, u.LX)() ? .track("editor_claim_failed", {
                            stage: t.stage,
                            status: t.status,
                            surface: "guest_checkout"
                        }), !1), () => !1) : Promise.resolve(!0)
                    }, [x, b]),
                    H = (0, r.useCallback)(async (e, t, a) => {
                        U({
                            paid: a,
                            preparing: !1
                        });
                        let n = !1,
                            r = (async () => await (B.current ? ? Z(e)) || Z(e))();
                        r.finally(() => {
                            n = !0
                        }), await new Promise(e => setTimeout(e, 2e3)), n || U({
                            paid: a,
                            preparing: !0
                        });
                        let i = await Promise.race([r, new Promise(e => setTimeout(() => e(!1), 3e4))]),
                            s = x();
                        i && s && (0, v.e3)(s), await G.current;
                        let l = (0, p.ku)(i ? t : `/editor/${e}`);
                        U(e => e && { ...e,
                            href: l
                        }), window.location.assign(l)
                    }, [Z, x]),
                    Q = (0, r.useCallback)(async () => {
                        let e = x();
                        if (!e) return void window.location.assign((0, p.ku)(`/dashboard/templates/${i}/start`));
                        g(), W(null), E(!0);
                        let t = await (0, v.YH)(e);
                        if (!t.ok) {
                            E(!1), A(!1), W(t.message);
                            return
                        }
                        let a = t.projectId;
                        B.current = Z(a), E(!1), L(a), fetch(`/api/projects/${a}/checkout`).then(async e => (await e.json()).data).then(e => {
                            e ? .kind === "redirect" && e.to && H(a, e.to, !1)
                        }).catch(() => {})
                    }, [x, g, i, Z, H]);
                (0, r.useEffect)(() => {
                    e && y && !X.current && (X.current = !0, Q())
                }, [e, y, Q]);
                let ee = (0, r.useCallback)(() => {
                        P(!0), X.current || (X.current = !0, Q())
                    }, [Q]),
                    et = (0, r.useCallback)(() => {
                        A(!0), I || Q()
                    }, [Q, I]),
                    ea = (y || $) && void 0 !== k;
                return (0, n.jsxs)(n.Fragment, {
                    children: [(0, n.jsx)(Y, {
                        video: q,
                        open: e && !ea,
                        handingOff: ea,
                        onClose: t,
                        children: (0, n.jsx)(c.lB, {
                            nextPath: h,
                            inAppBrowser: V,
                            emailOtp: C.emailOtp,
                            whatsapp: C.whatsapp,
                            whatsappSendsCode: C.whatsappSendsCode,
                            onSignedIn: ee
                        })
                    }), ea ? (0, n.jsx)(_, {
                        projectId: K,
                        templateName: l,
                        templateImageUrl: k ? .templateImageUrl ? ? null,
                        templateSlug: i,
                        priceInr: o,
                        livePass: k ? .livePass ? ? !1,
                        invitePlans: d,
                        togetherPlans: f,
                        availableProviders: k ? .availableProviders,
                        cashfreeMode: k ? .cashfreeMode ? ? null,
                        bloomQr: k ? .bloomQr,
                        reveal: k ? .reveal,
                        linkDelivery: k ? .linkDelivery,
                        referralCookiePresent: !1,
                        enableCoupon: !0,
                        presentation: "modal",
                        entrance: $ ? "side" : "up",
                        open: e && !J,
                        onClose: t,
                        guest: {
                            gate: M ? (0, n.jsxs)("p", {
                                role: "alert",
                                className: "m-0 text-[13px] leading-5 text-cp-danger-ink",
                                children: [M, " Tap Pay to try again."]
                            }) : null,
                            onPay: et,
                            busy: z,
                            payLabel: z ? "Opening payment\u2026" : null
                        },
                        onPaid: e => void H(e, q ? (0, S.OK)(e) : `/dashboard/projects/${e}#publish`, !0)
                    }) : null, J && "u" > typeof document ? (0, s.createPortal)((0, n.jsx)(D, {
                        paid: J.paid,
                        preparing: J.preparing,
                        href: J.href,
                        video: q,
                        reminder: J.paid ? (0, n.jsx)(N, {
                            templateSlug: i,
                            projectId: K || void 0,
                            getContent: () => x() ? .draftContent,
                            onEngage: e => {
                                G.current = e
                            }
                        }) : null
                    }), document.body) : null]
                })
            }

            function Y({
                open: e,
                handingOff: t,
                onClose: a,
                children: i,
                video: o = !1
            }) {
                let [c, d] = (0, r.useState)(e), [u, m] = (0, r.useState)(!1);
                return ((0, r.useEffect)(() => {
                    if (e) {
                        d(!0);
                        let e = 0,
                            t = requestAnimationFrame(() => {
                                e = requestAnimationFrame(() => m(!0))
                            });
                        return () => {
                            cancelAnimationFrame(t), e && cancelAnimationFrame(e)
                        }
                    }
                    m(!1);
                    let t = setTimeout(() => d(!1), 320);
                    return () => clearTimeout(t)
                }, [e]), (0, r.useEffect)(() => {
                    if (!c) return;
                    let e = document.body.style.overflow;
                    return document.body.style.overflow = "hidden", () => {
                        document.body.style.overflow = e
                    }
                }, [c]), !c || "u" < typeof document) ? null : (0, s.createPortal)((0, n.jsx)("div", {
                    className: (0, g.cn)("fixed inset-0 z-[140] flex items-end justify-center bg-cp-ink/40 px-0 pt-6 transition-opacity duration-[320ms] ease-out md:items-center md:px-6 md:py-8", u ? "opacity-100" : "pointer-events-none opacity-0"),
                    onClick: a,
                    children: (0, n.jsx)("div", {
                        role: "dialog",
                        "aria-modal": "true",
                        "aria-labelledby": "guest-sign-in-title",
                        className: (0, g.cn)("relative flex max-h-[calc(100dvh-1.5rem)] w-full max-w-md flex-col transition-[translate,scale,opacity] duration-[320ms] ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-opacity md:max-h-[calc(100dvh-4rem)]", u ? "translate-y-0 opacity-100 md:scale-100" : t ? "-translate-x-1/3 opacity-0" : "translate-y-full opacity-0 md:translate-y-6 md:scale-[0.97]"),
                        onClick: e => e.stopPropagation(),
                        children: (0, n.jsxs)("div", {
                            className: (0, g.cn)(h().className, x().variable, "ck-root ck-sheet flex max-h-[calc(100dvh-1.5rem)] flex-col overflow-hidden bg-white shadow-[0_-10px_40px_rgba(0,0,0,0.18)] md:max-h-[calc(100dvh-5rem)] md:shadow-cp-modal"),
                            children: [(0, n.jsx)("span", {
                                "aria-hidden": "true",
                                className: "mx-auto mt-2.5 mb-1.5 block h-[5px] w-10 shrink-0 rounded-full bg-(--ck-grip) md:hidden"
                            }), (0, n.jsxs)("div", {
                                className: "no-scrollbar flex min-h-0 flex-1 flex-col gap-5 overflow-y-auto px-5 pt-1.5 pb-[calc(1.5rem+env(safe-area-inset-bottom))] md:pt-5",
                                children: [(0, n.jsxs)("div", {
                                    className: "flex items-start gap-3.5",
                                    children: [(0, n.jsxs)("div", {
                                        className: "flex min-w-0 flex-1 flex-col gap-1.5 pt-1",
                                        children: [(0, n.jsx)("h2", {
                                            id: "guest-sign-in-title",
                                            className: "ck-display m-0 text-[26px] font-bold leading-[1.1] tracking-[-0.025em]",
                                            children: o ? "Get my video" : "Make it live"
                                        }), (0, n.jsx)("p", {
                                            className: "m-0 text-[14px] leading-5 text-(--ck-muted)",
                                            children: o ? "Sign in to keep your video and pay. Your edits are safe." : "Sign in to keep your page and pay. Your edits are safe."
                                        })]
                                    }), (0, n.jsx)("button", {
                                        type: "button",
                                        "aria-label": "Close",
                                        onClick: a,
                                        className: "ck-press flex size-11 shrink-0 cursor-pointer items-center justify-center rounded-full bg-(--ck-close) text-(--ck-ink) focus-visible:outline-2 focus-visible:outline-cp-select",
                                        children: (0, n.jsxs)("svg", {
                                            width: 18,
                                            height: 18,
                                            viewBox: "0 0 24 24",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: 2.2,
                                            strokeLinecap: "round",
                                            "aria-hidden": "true",
                                            children: [(0, n.jsx)("path", {
                                                d: "M6 6l12 12"
                                            }), (0, n.jsx)("path", {
                                                d: "M18 6L6 18"
                                            })]
                                        })
                                    })]
                                }), (0, n.jsx)("div", {
                                    children: i
                                }), (0, n.jsxs)("p", {
                                    className: "m-0 flex items-center justify-center gap-1.5 text-center text-[12px] text-(--ck-muted)",
                                    children: [(0, n.jsx)(l.A, {
                                        className: "size-3.5 text-(--ck-success)",
                                        strokeWidth: 1.75,
                                        "aria-hidden": !0
                                    }), "Secure sign-in \xb7 You stay right here"]
                                })]
                            })]
                        })
                    })
                }), document.body)
            }
        },
        78680: () => {},
        83989: (e, t, a) => {
            "use strict";
            a.d(t, {
                XU: () => u,
                e6: () => d,
                sV: () => p,
                yf: () => m
            });
            var n = a(2514);
            async function r(e, t = {}) {
                try {
                    let a = await fetch(e, { ...t,
                            headers: {
                                "Content-Type": "application/json",
                                ...t.headers ? ? {}
                            },
                            cache: "no-store"
                        }),
                        r = await a.json().catch(() => null);
                    if (!a.ok) {
                        let e = r ? .error ? .message,
                            t = 400 === a.status && "string" == typeof e && /\b50\b|limit|maximum/i.test(e) ? 409 : a.status;
                        return {
                            ok: !1,
                            status: t,
                            message: 409 === t ? `You can keep up to ${n.NY} dates. Delete one to add another.` : 400 === t || 422 === t ? "Please check the name and date, then try again." : 401 === t ? "Please sign in again to save your dates." : 404 === t ? "Date reminders aren\u2019t available right now." : 429 === t ? "That was a lot at once. Please wait a moment and try again." : "We couldn\u2019t save that. Please try again.",
                            unavailable: 404 === a.status
                        }
                    }
                    return {
                        ok: !0,
                        payload: r
                    }
                } catch {
                    return {
                        ok: !1,
                        status: 0,
                        message: "We couldn\u2019t reach Cutiepage. Please check your connection.",
                        unavailable: !1
                    }
                }
            }
            let i = e => String(e).padStart(2, "0");

            function s(e) {
                let {
                    month: t,
                    day: a,
                    ...n
                } = e;
                return void 0 !== t && void 0 !== a ? { ...n,
                    eventDate: `${i(t)}-${i(a)}`
                } : n
            }

            function l(e) {
                let t = e ? .data;
                return t && "object" == typeof t ? t : {}
            }

            function o(e) {
                let t = l(e).reminders;
                return Array.isArray(t) ? t.map(n.YK).filter(e => null !== e) : []
            }

            function c(e) {
                let t = l(e);
                return (0, n.YK)(t.reminder ? ? t)
            }
            async function d() {
                let e = await r("/api/reminders");
                return e.ok ? {
                    ok: !0,
                    data: o(e.payload)
                } : e
            }
            async function u(e, t = {}) {
                let a = await r("/api/reminders", {
                    method: "POST",
                    body: JSON.stringify(s(e)),
                    keepalive: t.keepalive
                });
                if (!a.ok) return a;
                let n = Array.isArray(l(a.payload).reminders) ? o(a.payload) : null;
                return {
                    ok: !0,
                    data: {
                        saved: c(a.payload),
                        list: n
                    }
                }
            }
            async function m(e, t) {
                let a = await r(`/api/reminders/${encodeURIComponent(e)}`, {
                    method: "PATCH",
                    body: JSON.stringify(s(t))
                });
                if (!a.ok) return a;
                let n = Array.isArray(l(a.payload).reminders) ? o(a.payload) : null;
                return {
                    ok: !0,
                    data: {
                        saved: c(a.payload),
                        list: n
                    }
                }
            }
            async function p(e) {
                let t = await r(`/api/reminders/${encodeURIComponent(e)}`, {
                    method: "DELETE"
                });
                return t.ok ? {
                    ok: !0,
                    data: null
                } : t
            }
        }
    }
]);