"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [89539], {
        80579: (e, t, a) => {
            a.d(t, {
                Ok: () => n,
                nv: () => l
            }), a(1521), a(82161);
            let o = "https://cdn.cutiepage.in/template-seeds/diwali-audio",
                l = {
                    match: `${o}/sfx/match-v1.mp3`,
                    flame: `${o}/sfx/flame-v1.mp3`,
                    chime: `${o}/sfx/chime-v1.mp3`,
                    bell: `${o}/sfx/bell-v1.mp3`,
                    fizz: `${o}/sfx/fizz-v1.mp3`,
                    fountain: `${o}/sfx/fountain-v1.mp3`,
                    whirr: `${o}/sfx/whirr-v1.mp3`,
                    whistle: `${o}/sfx/whistle-v1.mp3`,
                    boom: `${o}/sfx/boom-v1.mp3`,
                    crackle: `${o}/sfx/crackle-v1.mp3`,
                    lid: `${o}/sfx/lid-v1.mp3`,
                    paper: `${o}/sfx/paper-v1.mp3`,
                    unfold: `${o}/sfx/unfold-v1.mp3`,
                    seal: `${o}/sfx/seal-v1.mp3`
                };

            function n(e) {
                let t = e ? e.AudioContext ? ? e.webkitAudioContext : void 0,
                    a = null,
                    o = null,
                    n = !1,
                    i = new Map,
                    r = new Set,
                    f = () => {
                        if (!t) return null;
                        if (!a) {
                            (o = (a = new t).createGain()).gain.value = +!n;
                            let e = a.createDynamicsCompressor();
                            o.connect(e).connect(a.destination)
                        }
                        return "suspended" === a.state && a.resume().catch(() => {}), a
                    },
                    s = (e, t, s) => {
                        let d, c = f();
                        if (!c || !o || n) return null;
                        let p = c.createGain();
                        p.gain.value = t.volume ? ? .7;
                        let u = (void 0 !== t.pan && c.createStereoPanner ? ((d = c.createStereoPanner()).pan.value = Math.max(-1, Math.min(1, t.pan)), p.connect(d).connect(o)) : p.connect(o), p),
                            h = {
                                src: null,
                                stopped: !1,
                                gain: p
                            };
                        return (e => {
                            let t = i.get(e);
                            if (!t) {
                                let o = a;
                                t = fetch(l[e]).then(e => e.ok ? e.arrayBuffer() : Promise.reject()).then(e => o.decodeAudioData(e)).catch(() => null), i.set(e, t)
                            }
                            return t
                        })(e).then(e => {
                            if (!e || h.stopped || !a) return;
                            let o = a.createBufferSource();
                            o.buffer = e, o.loop = s, o.playbackRate.value = t.rate ? ? 1, o.connect(u), o.onended = () => r.delete(o), r.add(o), o.start(a.currentTime + (t.delay ? ? 0)), h.src = o
                        }), h
                    };
                return {
                    play(e, t = {}) {
                        s(e, t, !1)
                    },
                    loop(e, t = {}) {
                        let o = s(e, t, !0);
                        return {
                            stop(e = .25) {
                                if (!o || (o.stopped = !0, !a || !o.src)) return;
                                let t = a.currentTime;
                                o.gain.gain.setTargetAtTime(0, t, Math.max(.01, e / 3)), o.src.stop(t + e + .05)
                            }
                        }
                    },
                    unlock() {
                        f()
                    },
                    setMuted(e) {
                        if (n = e, o && a && o.gain.setTargetAtTime(+!e, a.currentTime, .05), e)
                            for (let e of r) e.loop = !1
                    },
                    dispose() {
                        for (let e of r) try {
                            e.stop()
                        } catch {}
                        r.clear(), a ? .close().catch(() => {}), a = null
                    }
                }
            }
        },
        89539: (e, t, a) => {
            a.r(t), a.d(t, {
                default: () => $
            });
            var o = a(84910),
                l = a(63962),
                n = a(80579);
            let i = "https://cdn.cutiepage.in/template-seeds/cp-world-diwali/tex",
                r = new o.kn4,
                f = new o.PTz,
                s = new o.O9p,
                d = new o.Pq0,
                c = new o.Pq0;
            class p {
                constructor(e = []) {
                    this.names = e, this.parts = []
                }
                get size() {
                    return this.parts.length
                }
                add(e, t, a = [0, 0, 0], l = [1, 1, 1], n = {}) {
                    r.compose(c.set(t[0], t[1], t[2]), f.setFromEuler(s.set(a[0], a[1], a[2], "YXZ")), d.set(l[0], l[1], l[2]));
                    let i = e.index ? e.toNonIndexed() : e.clone();
                    for (let e of Object.keys(i.attributes)) "position" !== e && "normal" !== e && "uv" !== e && i.deleteAttribute(e);
                    i.attributes.normal || i.computeVertexNormals(), i.applyMatrix4(r);
                    let p = i.attributes.position.count;
                    for (let e of this.names) i.setAttribute(e, new o.qtW(new Float32Array(p).fill(n[e] ? ? 0), 1));
                    this.parts.push(i)
                }
                plane(e, t, a, l, n, i) {
                    let r = new o.bdM(e, t);
                    if (i) {
                        let e = r.attributes.uv;
                        for (let t = 0; t < e.count; t++) e.setXY(t, i[0] + e.getX(t) * (i[2] - i[0]), i[1] + e.getY(t) * (i[3] - i[1]))
                    }
                    this.add(r, a, l, [1, 1, 1], n), r.dispose()
                }
                build(e) {
                    let t = this.parts.length ? (0, l.pP)(this.parts, !1) : null;
                    for (let e of this.parts) e.dispose();
                    return (this.parts.length = 0, t) ? (t.computeBoundingSphere(), new o.eaF(t, e)) : null
                }
            }

            function u(e, t, a) {
                let l = {
                    uTime: t,
                    uMap: {
                        value: e
                    },
                    uStart: {
                        value: 1e6
                    },
                    uBase: {
                        value: a.base ? ? 0
                    },
                    uDim: {
                        value: a.dim
                    },
                    uGain: {
                        value: a.gain
                    },
                    uHue: {
                        value: 0
                    },
                    uTint: {
                        value: new o.Q1f("#ffffff")
                    }
                };
                return new o.BKk({
                    uniforms: l,
                    side: a.doubleSide ? o.$EB : void 0,
                    vertexShader: `uniform float uTime, uStart, uBase; attribute float aDelay, aRand; varying vec2 vUv; varying float vLit;
      void main(){
        vUv = uv;
        float t = uTime - uStart - aDelay;
        float early = step(aRand, uBase)*(0.55 + 0.1*sin(uTime*0.9 + aRand*40.0));
        float pop = smoothstep(0.0, 0.45, t);
        vLit = max(early, pop*(1.0 + 0.6*exp(-max(t, 0.0)*3.0)));
        gl_Position = projectionMatrix*modelViewMatrix*vec4(position, 1.0);
      }`,
                    fragmentShader: `uniform sampler2D uMap; uniform float uDim, uGain, uHue; uniform vec3 uTint; varying vec2 vUv; varying float vLit;
      vec3 hueShift(vec3 c, float a){ const vec3 k = vec3(0.57735); float ca = cos(a); return c*ca + cross(k, c)*sin(a) + k*dot(k, c)*(1.0 - ca); }
      void main(){
        vec4 t = texture2D(uMap, vUv);
        if (t.a < 0.4) discard;
        vec3 c = max(hueShift(t.rgb, uHue), 0.0)*uTint;
        gl_FragColor = vec4(c*(uDim + uGain*vLit), 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                })
            }
            var h = a(29703),
                m = a(95468),
                b = a(23445);
            let v = Math.PI,
                w = [{
                    sky: {
                        top: "#070826",
                        horizon: "#3a2257",
                        bottom: "#120a1e",
                        sunDir: [.3, .05, -1],
                        sunColor: "#4a2440"
                    },
                    fog: ["#24163c", 40, 210],
                    hemi: ["#7d74c9", "#4a2a2a", .5],
                    star: ["#a9b4ff", .35],
                    stars: 1,
                    skyline: ["#140f2c", "#ffc070", "#3a2257"]
                }, {
                    sky: {
                        top: "#1f2266",
                        horizon: "#d06a86",
                        bottom: "#3a1d3e",
                        sunDir: [-.9, .04, .3],
                        sunColor: "#ff8a6a"
                    },
                    fog: ["#4a2d55", 40, 200],
                    hemi: ["#a8a0f0", "#6a3a3a", .72],
                    star: ["#d8c8ff", .42],
                    stars: .35,
                    skyline: ["#2a1d45", "#ffc888", "#a0506a"]
                }, {
                    sky: {
                        top: "#12061c",
                        horizon: "#6e2a26",
                        bottom: "#1a0910",
                        sunDir: [.4, .04, -1],
                        sunColor: "#6a2410"
                    },
                    fog: ["#2c1418", 38, 200],
                    hemi: ["#b48ad0", "#5a2a14", .55],
                    star: ["#ffd2b0", .32],
                    stars: .7,
                    skyline: ["#1e0c14", "#ffb85a", "#5e2a24"]
                }],
                x = {
                    Warm: ["#ffcf7d", "#ffd99a", "#ffc46a"],
                    Rainbow: ["#ff5d6c", "#ffb347", "#ffe066", "#6ee7a0", "#5ec8ff", "#b18cff"],
                    Pink: ["#ff8fb8", "#ffb3cf", "#ff7aa8"],
                    Marigold: ["#ffa31a", "#ffc94a", "#ff7a1a"]
                },
                g = {
                    Saffron: [0, "#ffffff"],
                    Pink: [-1, "#ffe6ef"],
                    Teal: [2.55, "#e6fffb"],
                    Gold: [.25, "#fff2c4"]
                },
                y = [
                    ["#ff4f7b", "#ffd23f"],
                    ["#5ec8ff", "#b18cff"],
                    ["#7dffb0", "#fff3a0"],
                    ["#ff8a3d", "#ffd27a"],
                    ["#ff6bd5", "#ffffff"],
                    ["#ffd27a", "#ffb238"],
                    ["#ff3b4f", "#7ad7ff"]
                ],
                M = (e, t, a) => new o.Pq0(e, t, a),
                k = v / 2,
                S = -v / 2,
                z = [{
                    fx: 2.6,
                    fz: 10.45,
                    rot: S,
                    w: 3.9,
                    d: 4,
                    floors: 3,
                    color: "#f29bb5",
                    door: -.95
                }, {
                    fx: 2.6,
                    fz: 6.6,
                    rot: S,
                    w: 3.8,
                    d: 4,
                    floors: 2,
                    color: "#5cc3bd",
                    door: .6,
                    balcony: !0
                }, {
                    fx: 2.6,
                    fz: 2.6,
                    rot: S,
                    w: 4,
                    d: 4,
                    floors: 3,
                    color: "#f3c14f",
                    door: -.5,
                    jharokha: .9
                }, {
                    fx: -2.6,
                    fz: 10.6,
                    rot: k,
                    w: 3.6,
                    d: 4,
                    floors: 2,
                    color: "#b59ae6",
                    door: .4,
                    balcony: !0
                }, {
                    fx: -2.6,
                    fz: 6.85,
                    rot: k,
                    w: 3.9,
                    d: 4,
                    floors: 3,
                    color: "#ff9d7a",
                    door: -.7,
                    jharokha: .8
                }, {
                    fx: -2.6,
                    fz: 2.75,
                    rot: k,
                    w: 4.3,
                    d: 4,
                    floors: 2,
                    color: "#93d4a7",
                    door: .6,
                    balcony: !0
                }, {
                    fx: -8.5,
                    fz: .6,
                    rot: v,
                    w: 4.2,
                    d: 4,
                    floors: 2,
                    color: "#86c3ef",
                    door: .5,
                    balcony: !0
                }, {
                    fx: -4.5,
                    fz: .6,
                    rot: v,
                    w: 3.8,
                    d: 4,
                    floors: 3,
                    color: "#ffb86b",
                    door: -.4
                }, {
                    fx: 4.6,
                    fz: .6,
                    rot: v,
                    w: 4,
                    d: 4,
                    floors: 2,
                    color: "#e7769b",
                    door: .5,
                    balcony: !0
                }, {
                    fx: 8.6,
                    fz: .6,
                    rot: v,
                    w: 4,
                    d: 4,
                    floors: 2,
                    color: "#f3c14f",
                    door: 0
                }, {
                    fx: -10.6,
                    fz: -1.7,
                    rot: k,
                    w: 4.4,
                    d: 4,
                    floors: 3,
                    color: "#5cc3bd",
                    door: .2,
                    jharokha: -1.1
                }, {
                    fx: -10.6,
                    fz: -6,
                    rot: k,
                    w: 4.2,
                    d: 4,
                    floors: 2,
                    color: "#f29bb5",
                    door: -.3,
                    balcony: !0
                }, {
                    fx: -10.6,
                    fz: -10.3,
                    rot: k,
                    w: 4.6,
                    d: 4,
                    floors: 3,
                    color: "#b59ae6",
                    door: null
                }, {
                    fx: -7.8,
                    fz: -12.6,
                    rot: 0,
                    w: 3.8,
                    d: 4,
                    floors: 2,
                    color: "#93d4a7",
                    door: null
                }, {
                    fx: -3.6,
                    fz: -12.6,
                    rot: 0,
                    w: 4.2,
                    d: 4,
                    floors: 2,
                    color: "#ffb86b",
                    shop: !0
                }, {
                    fx: .8,
                    fz: -12.6,
                    rot: 0,
                    w: 4.6,
                    d: 4,
                    floors: 3,
                    color: "#ff9d7a",
                    door: .9,
                    balcony: !0,
                    jharokha: -1.2
                }, {
                    fx: 5.3,
                    fz: -12.6,
                    rot: 0,
                    w: 4.4,
                    d: 4,
                    floors: 2,
                    color: "#86c3ef",
                    door: -.6,
                    balcony: !0
                }, {
                    fx: 9.2,
                    fz: -12.6,
                    rot: 0,
                    w: 2.8,
                    d: 4,
                    floors: 2,
                    color: "#e7769b",
                    door: null
                }],
                T = {
                    x: -8,
                    z: -9.7,
                    front: -8.3
                },
                A = {
                    x: -7.4,
                    z: -3.3
                },
                P = M(0, 3.75, 5.45),
                F = M(58, 22, -8),
                R = {
                    spawn: {
                        x: 0,
                        z: 11,
                        facing: v
                    },
                    diya: {
                        x: .95,
                        z: 9.55,
                        facing: v / 2
                    },
                    kandils: {
                        x: 0,
                        z: 7.4,
                        facing: v
                    },
                    rangoli: {
                        x: 0,
                        z: -.95,
                        facing: v
                    },
                    bell: {
                        x: -8,
                        z: -6.9,
                        facing: v
                    },
                    mithai: {
                        x: -3.6,
                        z: -10.5,
                        facing: v
                    },
                    phuljhadi: {
                        x: 3.6,
                        z: -6.6,
                        facing: v / 2
                    },
                    anar: {
                        x: 6.6,
                        z: -7.2,
                        facing: Math.atan2(1.6, -1.4)
                    },
                    chakri: {
                        x: 5.9,
                        z: -3.9,
                        facing: Math.atan2(1.5, 1.5)
                    },
                    rocket: {
                        x: 9,
                        z: -3.4,
                        facing: v / 2
                    },
                    lantern: {
                        x: 4.8,
                        z: -9.6,
                        facing: v
                    },
                    finale: {
                        x: 8.4,
                        z: -6.6,
                        facing: v / 2
                    }
                },
                B = {
                    pos: [-1.5, 1.55, 7],
                    look: [2.3, .75, 9.8],
                    fov: 50
                },
                C = {
                    pos: [.9, 1.3, 9.4],
                    look: [0, 3, 4.8],
                    fov: 52
                },
                _ = {
                    pos: [1.9, 3.3, .5],
                    look: [0, .1, -3.6],
                    fov: 50
                },
                D = {
                    pos: [-6.2, 1.55, -4.6],
                    look: [-8, 1.7, -9.3],
                    fov: 50
                },
                H = {
                    pos: [-2.1, 1.75, -8.6],
                    look: [-3.6, 1.05, -12.1],
                    fov: 50
                },
                j = {
                    pos: [6.5, 1.45, -5.3],
                    look: [3.4, 1.15, -6.8],
                    fov: 50
                },
                Y = {
                    pos: [4.6, 1.6, -5.3],
                    look: [8.3, 1.2, -9.2],
                    fov: 50
                },
                Q = {
                    pos: [4.4, 2, -5.8],
                    look: [7.5, .25, -2.2],
                    fov: 50
                },
                V = {
                    pos: [6.4, 1.4, -1.4],
                    look: [10.8, 1.6, -4.2],
                    fov: 50
                },
                q = {
                    pos: [6.8, 1.4, -6.9],
                    look: [4.7, 1.9, -10.9],
                    fov: 50
                };

            function G(e, t, a) {
                return .3 + (a > .3 ? Math.abs(a - 9.5) + .45 * Math.abs(e - 2.3) : 9.2 + .85 * Math.hypot(e, a - .3)) / 5.2 + .07 * t
            }
            let $ = {
                key: "diwali",
                memoryCount: 10,
                build: function(e) {
                    var t, a;
                    let l, r, f, s, d, c, k, S, $, I, O, E, U, {
                            fx: W,
                            photos: L,
                            text: N,
                            rand: J
                        } = e,
                        X = "high" === e.quality,
                        Z = e.reducedMotion,
                        K = e.doc,
                        ee = (e, t) => e + (t - e) * J(),
                        et = new o.YJl;
                    et.name = "diwali";
                    let ea = [],
                        eo = e => (ea.push(e), e),
                        el = eo((t = K.defaultView, l = (0, n.Ok)(t), r = !1, f = 0, s = !0, d = !1, c = new Set, {
                            get live() {
                                return r && f > 0 && s
                            },
                            unlock() {
                                t && (r = !0, l.unlock(), !d && t.fetch && (d = !0, t.fetch(n.nv.boom).then(e => {
                                    s = e.ok
                                }).catch(() => {
                                    s = !1
                                })))
                            },
                            setVolume(e) {
                                if (f = Math.max(0, Math.min(1, e)), l.setMuted(f <= 0), f <= 0) {
                                    for (let e of c) e.stop(.1);
                                    c.clear()
                                }
                            },
                            play(e, t = {}) {
                                r && f > 0 && s && l.play(e, { ...t,
                                    volume: (t.volume ? ? .7) * f
                                })
                            },
                            loop(e, t = {}) {
                                if (!(r && f > 0) || !s) return {
                                    stop() {}
                                };
                                let a = l.loop(e, { ...t,
                                        volume: (t.volume ? ? .7) * f
                                    }),
                                    o = {
                                        stop(e) {
                                            c.delete(o), a.stop(e)
                                        }
                                    };
                                return c.add(o), o
                            },
                            dispose() {
                                c.clear(), l.dispose()
                            }
                        }));
                    e.attachSound(el);
                    let en = eo(new o.Df({
                            vertexColors: !0,
                            gradientMap: W.ramp
                        })),
                        ei = eo(new o.V9B({
                            vertexColors: !0
                        })),
                        er = eo(new o.V9B({
                            visible: !1
                        })),
                        ef = new m.lP,
                        es = new m.lP,
                        ed = new m.lP,
                        ec = new p(["aDelay", "aRand"]),
                        ep = new p(["aDelay", "aRand"]),
                        eu = new p,
                        eh = new p,
                        em = (e, t, a, l, n = `${i}/${e}-v1.webp`) => eo(function(e, t, a, l, n) {
                            let i = e.createElement("canvas");
                            i.width = a, i.height = l;
                            let r = i.getContext("2d");
                            r && n(r, a, l);
                            let f = new o.GOR(i);
                            f.colorSpace = o.er$, f.anisotropy = 4;
                            let s = !1,
                                d = e.defaultView;
                            if (d && r) {
                                let e = new d.Image;
                                e.crossOrigin = "anonymous", e.decoding = "async", e.onload = () => {
                                    !s && e.naturalWidth && (r.clearRect(0, 0, a, l), r.drawImage(e, 0, 0, a, l), f.needsUpdate = !0)
                                }, e.src = t
                            }
                            return {
                                texture: f,
                                dispose() {
                                    s = !0, f.dispose()
                                }
                            }
                        }(K, n, t, a, l)).texture,
                        eb = em("jaali", 256, 256, (e, t, a) => {
                            e.fillStyle = "#ffb43c", e.fillRect(0, 0, t, a), e.fillStyle = "#5a2a12";
                            for (let o = 0; o < 6; o++)
                                for (let l = 0; l < 6; l++) e.beginPath(), e.arc(t / 6 * (l + .5), a / 6 * (o + .5), t / 22, 0, 2 * v), e.fill();
                            e.strokeStyle = "#5a2a12", e.lineWidth = t / 20, e.strokeRect(0, 0, t, a)
                        }),
                        ev = em("door", 256, 256, (e, t, a) => {
                            e.fillStyle = "#6b3a22", e.fillRect(0, 0, t, a), e.fillStyle = "#4a2514", e.fillRect(.12 * t, .18 * a, .36 * t, .82 * a), e.fillRect(.52 * t, .18 * a, .36 * t, .82 * a), e.fillStyle = "#d9a441";
                            for (let o = 0; o < 6; o++)
                                for (let l of [.22, .38, .62, .78]) e.fillRect(t * l, a * (.28 + .12 * o), 4, 4)
                        }),
                        ew = em("toran-strip", 512, 256, (e, t, a) => {
                            for (let o = 0; o < 16; o++) {
                                let l = t / 16 * (o + .5);
                                e.fillStyle = o % 2 ? "#ffa31a" : "#ff7a1a", e.beginPath(), e.arc(l, .16 * a, t / 30, 0, 2 * v), e.fill(), e.fillStyle = "#3f8a3a", e.beginPath(), e.ellipse(l, .45 * a, t / 60, .22 * a, 0, 0, 2 * v), e.fill()
                            }
                        }),
                        ex = em("kandil-paper", 256, 256, (e, t, a) => {
                            let o = e.createRadialGradient(t / 2, a / 2, 4, t / 2, a / 2, .7 * t);
                            o.addColorStop(0, "#ffd27a"), o.addColorStop(1, "#ff7a1a"), e.fillStyle = o, e.fillRect(0, 0, t, a), e.fillStyle = "#fff3c4";
                            for (let o = 0; o < 9; o++) {
                                let l = t / 3 * (o % 3 + .5),
                                    n = a / 3 * (Math.floor(o / 3) + .5);
                                e.beginPath();
                                for (let a = 0; a < 10; a++) {
                                    let o = a / 10 * v * 2 - v / 2,
                                        i = a % 2 ? .03 * t : .07 * t;
                                    e.lineTo(l + Math.cos(o) * i, n + Math.sin(o) * i)
                                }
                                e.fill()
                            }
                        });
                    ex.wrapS = o.GJx, ex.wrapT = o.GJx;
                    let eg = em("paisley", 256, 256, (e, t, a) => {
                            e.fillStyle = "#7a1426", e.fillRect(0, 0, t, a), e.fillStyle = "#e2b04a";
                            for (let o = 0; o < 4; o++)
                                for (let l = 0; l < 4; l++) e.beginPath(), e.ellipse(t / 4 * (l + .5 + o % 2 * .5), a / 4 * (o + .5), t / 18, t / 11, .6, 0, 2 * v), e.fill()
                        }),
                        ey = em("rangoli-3d", 512, 512, (e, t) => {
                            let a = t / 2;
                            for (let [o, l, n] of [
                                    [.48, "#ffd23f", 22],
                                    [.4, "#e84a7f", 16],
                                    [.31, "#3fb8a0", 12],
                                    [.22, "#ff8a3d", 10],
                                    [.13, "#b18cff", 8]
                                ]) {
                                e.fillStyle = l;
                                for (let l = 0; l < n; l++) {
                                    let i = l / n * v * 2;
                                    e.beginPath(), e.ellipse(a + Math.cos(i) * o * t * .82, a + Math.sin(i) * o * t * .82, o * t * .2, o * t * .08, i, 0, 2 * v), e.fill()
                                }
                            }
                            e.fillStyle = "#fff3d6", e.beginPath(), e.arc(a, a, .06 * t, 0, 2 * v), e.fill()
                        }),
                        eM = new o.YJl;
                    eM.name = "diwali-sky";
                    let ek = w[e.mood],
                        eS = W.sky(ek.sky);
                    eM.add(eS);
                    let ez = W.starDome(X ? 1500 : 700, 250);
                    eM.add(ez);
                    let eT = eo((0, h.pt)(K, J));
                    eT.setColors(...ek.skyline), eM.add(eT.mesh);
                    let eA = new o.dth(ek.hemi[0], ek.hemi[1], ek.hemi[2]);
                    et.add(eA);
                    let eP = new o.$p8("#ffffff", .07);
                    et.add(eP);
                    let eF = new o.ZyN(ek.star[0], ek.star[1]);
                    if (eF.position.set(-9, 16, 8), eF.target.position.set(0, 0, -2), X) {
                        eF.shadow.mapSize.set(2048, 2048);
                        let e = eF.shadow.camera;
                        e.left = -17, e.right = 17, e.top = 17, e.bottom = -17, e.near = 1, e.far = 60, eF.shadow.bias = -6e-4, eF.shadow.normalBias = .03
                    }
                    et.add(eF, eF.target);
                    let eR = [],
                        eB = (e, t, a) => {
                            let l = new o.HiM("#ffa75a", 0, a, 2);
                            l.position.set(e[0], e[1], e[2]), et.add(l), eR.push({
                                light: l,
                                base: t
                            })
                        };
                    X ? (eB([0, 2.6, 8.4], 9, 11), eB([0, 3, 3], 8, 11), eB([-3.5, 3.4, -6.5], 12, 16)) : eB([0, 4.2, -1], 18, 26);
                    let eC = X ? new o.HiM("#ffc070", 0, 7, 2) : null;
                    eC && et.add(eC);
                    let e_ = W.canvasTexture("dw-floor", 512, 512, (e, t, a) => {
                        let o = a / 8;
                        for (let a = 0; a < 8; a++) {
                            let l = a % 2 ? -(.6 * o) : 0;
                            for (; l < t;) {
                                let t = o * (1.1 + .8 * J()),
                                    n = J();
                                e.fillStyle = n < .33 ? "#b59a82" : n < .66 ? "#a88d78" : "#bea48c", e.fillRect(l + 2, a * o + 2, t - 4, o - 4), l += t
                            }
                        }
                        for (let o = 0; o < 6; o++) {
                            let o = e.createRadialGradient(J() * t, J() * a, 4, J() * t, J() * a, 90);
                            o.addColorStop(0, "rgba(60,40,40,.14)"), o.addColorStop(1, "rgba(60,40,40,0)"), e.fillStyle = o, e.fillRect(0, 0, t, a)
                        }
                    });
                    e_.wrapS = o.GJx, e_.wrapT = o.GJx;
                    let eD = eo(new o.Df({
                        map: e_,
                        gradientMap: W.ramp
                    })); {
                        e_.repeat.set(50.6 / 3, 80 / 3);
                        let e = eo(new o.bdM(50.6, 80));
                        e.rotateX(-v / 2);
                        let t = new o.eaF(e, eD);
                        t.position.set(10.6 - 25.3, 0, 0), et.add(W.noShadow(t, !0))
                    }
                    let eH = new o.nzx([new o.I9Y(0, 0), new o.I9Y(.045, 0), new o.I9Y(.07, .025), new o.I9Y(.082, .048), new o.I9Y(.058, .044)], X ? 9 : 6),
                        ej = [],
                        eY = [],
                        eQ = [],
                        eV = (e, t, a, o = G(e, t, a), l = 1) => {
                            ef.add(eH, (0, m.Qw)("#c4643a", ee(-.12, .12)), [e, t, a], [0, 0, 0], [l, l, l]), ej.push(e, t + .085 * l, a), eY.push(o + .06 * J()), eQ.push((X ? .13 : .15) * l)
                        },
                        eq = (e, t, a) => {
                            let o = Math.max(1, Math.round(e.distanceTo(t) / a));
                            for (let a = 0; a <= o; a++) {
                                let l = e.clone().lerp(t, a / o);
                                eV(l.x, l.y, l.z)
                            }
                        };
                    eV(2.3, .16, 9.5, 0, 1.7);
                    let eG = "#fff1dc",
                        e$ = new o.Ho_(1, 1, 1, 16, 1, !1, -v / 2, v).rotateX(-v / 2),
                        eI = X ? .5 : .85,
                        eO = [],
                        eE = [],
                        eU = [];
                    for (let e of z) {
                        let {
                            fx: t,
                            fz: a,
                            rot: o,
                            w: l,
                            d: n,
                            floors: i,
                            color: r
                        } = e, f = Math.cos(o), s = Math.sin(o), d = (e, o, l) => [t + f * e + s * l, o, a - s * e + f * l], c = [0, o, 0], p = 2.5 * i, u = (0, m.Qw)(r, -.18);
                        for (let e of (ef.box([l, p, n], d(0, p / 2, -n / 2), r, c), ef.box([l + .04, .3, .12], d(0, .15, .04), (0, m.Qw)(r, -.32), c), [-1, 1])) ef.box([.22, p, .1], d(e * (l / 2 - .11), p / 2, .03), u, c);
                        for (let e = 1; e < i; e++) ef.box([l + .12, .14, .22], d(0, 2.5 * e, .06), eG, c);
                        ef.box([l + .16, .16, .28], d(0, p, .08), eG, c), ef.box([l, .5, .16], d(0, p + .33, -.04), r, c), ef.box([l + .08, .06, .24], d(0, p + .6, -.04), eG, c);
                        let h = Math.max(2, Math.round((l - .4) / eI));
                        for (let e = 0; e <= h; e++) {
                            let t = -l / 2 + .2 + e * (l - .4) / h;
                            if (ef.box([.14, .16, .16], d(t, p + .71, -.08), eG, c), e < h) {
                                let e = d(t + (l - .4) / h / 2, p + .63, 0);
                                eV(e[0], e[1], e[2])
                            }
                        }
                        eE.push(M(...d(0, p + .7, -.5)));
                        let b = e.door;
                        if (null != b && !e.shop)
                            for (let e of (ef.box([1.78, 2.3, .1], d(b, 1.15, .03), (0, m.Qw)(r, -.4), c), ef.add(e$, eG, d(b, 2.3, .04), c, [.92, .42, .14]), eu.plane(1.5, 2.1, d(b, 1.07, .085), c), eh.plane(1.7, .8, d(b, 2.08, .14), c), ef.box([1.85, .16, .5], d(b, .08, .25), "#c9b8a3", c), [-1, 1])) {
                                let t = d(b + .68 * e, .16, .36);
                                eV(t[0], t[1], t[2])
                            }
                        if (e.shop) {
                            ed.box([l - .7, 2, .04], d(0, 1.25, .02), "#ffc878", c), ef.box([l - .9, 1, .6], d(0, .5, .45), "#8a4b2a", c), ef.box([l - .8, .06, .66], d(0, 1.03, .45), "#f3e3c8", c);
                            let e = ["#ffa31a", "#fff3e0", "#ffcf40", "#e84a7f", "#9ed36a"];
                            for (let t = 0; t < 5; t++) {
                                let a = -1.45 + .62 * t;
                                if (!(.4 > Math.abs(a))) {
                                    ef.cyl(.2, .025, d(a, 1.075, .42), "#d9b45a", 12, c);
                                    for (let o = 0; o < 6; o++) ef.sph(.045, d(a + ee(-.11, .11), 1.12 + .06 * (o > 3), .42 + ee(-.1, .1)), (0, m.Qw)(e[t], ee(-.1, .1)), c)
                                }
                            }
                            for (let e = 0; e < 10; e++) ef.box([l / 10, .05, .95], d(-l / 2 + l / 10 * (e + .5), 2.4, .45), e % 2 ? "#fff1dc" : "#e8475f", c);
                            for (let e of [-1, 1]) ef.rod(d(e * (l / 2 - .1), 2.4, .9), d(e * (l / 2 - .1), 0, .9), .025, "#6b3a22");
                            eh.plane(l - .6, .6, d(0, 2.2, .95), c)
                        }
                        for (let t = 0; t < i; t++) {
                            let a = 2.5 * t + (0 === t ? 1.45 : 1.3),
                                o = l >= 3.6 ? [-(.25 * l), .25 * l] : [0];
                            for (let n of (0 === t && (e.shop ? o = [] : null != b && (o = [-l / 2 + .75, l / 2 - .75].filter(e => Math.abs(e - b) > 1.45))), 1 === t && e.balcony && (o = [0]), void 0 !== e.jharokha && t === Math.min(2, i - 1) && (o = o.filter(t => Math.abs(t - e.jharokha) > 1.2)), o)) {
                                ef.box([.9, 1.1, .1], d(n, a, .03), eG, c);
                                let e = d(n, a, .085);
                                if (ep.plane(.72, .92, e, c, {
                                        aDelay: G(e[0], e[1], e[2]) + .25,
                                        aRand: J()
                                    }), eO.push(e[0], e[1], e[2]), ef.box([1.08, .07, .42], d(n, a + .68, .2), u, c), ef.box([.98, .06, .24], d(n, a - .58, .1), eG, c), X || 0 === t) {
                                    let e = d(n, a - .55, .15);
                                    eV(e[0], e[1], e[2])
                                }
                            }
                        }
                        if (e.balcony && i >= 2) {
                            let e = Math.min(l - .7, 2.4);
                            ef.box([e, .12, .78], d(0, 2.56, .39), eG, c);
                            for (let t = -e / 2 + .05; t <= e / 2; t += .18) ef.box([.035, .7, .035], d(t, 2.5 + .47, .75), "#4a3346", c);
                            for (let t of [-1, 1])
                                for (let a = .1; a < .75; a += .18) ef.box([.035, .7, .035], d(t * (e / 2 - .02), 2.5 + .47, a), "#4a3346", c);
                            ef.box([e + .04, .05, .06], d(0, 3.34, .75), "#4a3346", c);
                            let t = Math.max(2, Math.round(e / (X ? .42 : .7)));
                            for (let a = 0; a <= t; a++) {
                                let o = d(-e / 2 + .1 + a * (e - .2) / t, 3.37, .75);
                                eV(o[0], o[1], o[2])
                            }
                            eU.push(M(...d(0, 3.36, .76)))
                        }
                        if (void 0 !== e.jharokha) {
                            let t = 2.5 * Math.min(2, i - 1) + 1.3,
                                a = e.jharokha;
                            for (let e of (ef.box([1.1, 1.2, .55], d(a, t, .28), (0, m.Qw)(r, .1), c), ef.sph([.62, .34, .34], d(a, t + .62, .28), eG, c), ef.sph(.08, d(a, t + .98, .28), "#e2b04a"), ef.box([1.2, .1, .62], d(a, t - .62, .28), eG, c), [-1, 1])) ef.cone(.06, .02, .4, d(a + .4 * e, t - .85, .22), u, 6);
                            let o = d(a, t, .56);
                            ep.plane(.82, .92, o, c, {
                                aDelay: G(o[0], o[1], o[2]) + .3,
                                aRand: J()
                            })
                        }
                    }
                    for (let e of [-1, 1]) ef.box([.7, 4, .8], [2.45 * e, 2, 12.6], "#f2d2a8"), ef.box([.86, .18, .96], [2.45 * e, 4.08, 12.6], eG), ef.sph([.36, .42, .36], [2.45 * e, 4.62, 12.6], "#e2b04a");
                    for (let e of (ef.box([4.2, .7, .7], [0, 3.95, 12.6], "#f2d2a8"), ef.box([5.6, .16, .86], [0, 4.36, 12.6], eG), ef.sph([.7, .55, .45], [0, 4.44, 12.6], "#f2d2a8"), ef.sph(.1, [0, 5.05, 12.6], "#e2b04a"), eq(M(-1.9, 4.44, 12.27), M(-.8, 4.44, 12.27), .36), eq(M(.8, 4.44, 12.27), M(1.9, 4.44, 12.27), .36), eh.plane(3.6, .9, [0, 3.35, 12.6 - .38], [0, v, 0]), eh.plane(3.6, .9, [0, 3.35, 12.98], [0, 0, 0]), es.box([5.2, .05, 6], [0, -.02, 16], "#8a7464"), [-1, 1])) es.box([3, 5.5, 6], [4.1 * e, 2.75, 16], (0, m.Qw)(e < 0 ? "#b59ae6" : "#f29bb5", -.25)); {
                        ef.box([.24, .95, 13.2], [10.6, .475, -6], "#efc3a2"), ef.box([.36, .06, 13.26], [10.6, .98, -6], eG);
                        for (let e = -11.5; e < .6; e += 2.2) ef.box([.32, 1.15, .32], [10.6, .575, e], "#e8b796");
                        eq(M(10.6, 1.01, -12.1), M(10.6, 1.01, -4.4), X ? .6 : 1), eq(M(10.6, 1.01, -1.9), M(10.6, 1.01, .6 - .5), X ? .6 : 1), es.box([.4, 14, 21.2], [10.6 + .2, -7, -6], "#6a4a52"), es.box([400, .4, 400], [0, -14.2, 0], "#2a2034");
                        let t = ["#c98aa0", "#7fb0c8", "#d9b46a", "#a48ad0", "#82b894", "#d88a6a"],
                            a = [],
                            o = [],
                            l = X ? 70 : 42;
                        for (let e = 0; e < l; e++) {
                            let l = ee(14, 75),
                                n = ee(-55, 45),
                                i = ee(3, 7),
                                r = ee(3, 7),
                                f = ee(-12, -3) + (l > 45 ? ee(0, 4) : 0),
                                s = (0, m.Qw)(t[e % t.length], -.35);
                            es.box([i, f + 14, r], [l, (f - 14) / 2, n], s), es.box([i + .2, .25, r + .2], [l, f + .12, n], (0, m.Qw)(s, .2));
                            for (let e = f - 1.2; e > f - 7; e -= 2.2)
                                for (let t = n - r / 2 + .8; t < n + r / 2 - .5; t += 1.3) .55 > J() && (a.push(l - i / 2 - .05, e, t), o.push(.7 > J() ? "#ffc070" : "#ffe0a0"));
                            for (let e = 0; e < 4; e++) a.push(l - i / 2 + .1, f + .35, n - r / 2 + r / 4 * (e + .5)), o.push(["#ff9a3a", "#ffd27a", "#ff7aa8", "#7ad7ff"][e % 4])
                        }
                        let n = (e, t, a) => e > -14.6 - a && e < 10.6 + a && t > -16.6 - a && t < 4.6 + a || e > -6.6 - a && e < 6.6 + a && t > -1 && t < 16.4 + a,
                            i = X ? 5 : 6.5;
                        for (let e = -38; e < 10.6; e += i)
                            for (let l = -38; l < 38; l += i) {
                                let i = e + ee(-.6, .6),
                                    r = l + ee(-.6, .6);
                                if (n(i, r, 2.4)) continue;
                                let f = ee(3.6, 4.6),
                                    s = ee(3.6, 4.6),
                                    d = ee(4.5, 8.5),
                                    c = (0, m.Qw)(t[Math.floor(J() * t.length)], -.15);
                                es.box([f, d, s], [i, d / 2, r], c), es.box([f + .16, .3, s + .16], [i, d + .15, r], (0, m.Qw)(c, .3));
                                for (let e = 0; e < 3; e++) a.push(i + ee(-f / 2, f / 2), d + .42, r + ee(-s / 2, s / 2)), o.push(["#ff9a3a", "#ffd27a", "#ff7aa8"][e])
                            }
                        let r = (0, m.zq)({
                            positions: a,
                            colors: o,
                            sizes: .7,
                            time: e.time,
                            px: e.px,
                            rand: J,
                            twinkle: Z ? .1 : .35,
                            core: .18
                        });
                        et.add(r)
                    }
                    let eW = new o.YJl; {
                        let {
                            x: e,
                            z: t
                        } = T;
                        for (let a of (ef.box([3, .45, 2.9], [e, .225, t], "#efe2cf"), ef.box([1.5, .15, .45], [e, .075, T.front + .1], "#e5d6c0"), ef.box([1.5, .3, .3], [e, .15, T.front - .1], "#e5d6c0"), ef.box([1.9, 2, 1.9], [e, 1.45, t - .3], "#fbf1e3"), ed.box([.72, 1.15, .04], [e, 1.03, t + .66], "#ffcf86"), ef.add(e$, "#e9b552", [e, 1.6, t + .67], [0, 0, 0], [.42, .24, .06]), [-1, 1])) ef.cyl(.1, 2.25, [e + 1.2 * a, 1.575, T.front - .2], "#f3d9a8", 10), ef.box([.3, .12, .3], [e + 1.2 * a, 2.72, T.front - .2], "#e9b552");
                        ef.box([2.8, .16, 1.3], [e, 2.84, T.front - .6], "#e9b552"), ef.box([2.9, .06, 1.4], [e, 2.95, T.front - .6], "#f6d37a");
                        let a = new o.nzx([new o.I9Y(0, 0), new o.I9Y(1.05, 0), new o.I9Y(1, .5), new o.I9Y(.85, 1.2), new o.I9Y(.55, 1.9), new o.I9Y(.3, 2.3), new o.I9Y(0, 2.4)], X ? 12 : 8);
                        ef.addOnce(a, "#f2a65a", [e, 2.45, t - .3]);
                        for (let a = 1; a < 4; a++) ef.cyl(1.04 - .2 * a, .06, [e, 2.45 + .55 * a, t - .3], "#fff1dc", X ? 12 : 8);
                        ef.cyl(.3, .12, [e, 4.92, t - .3], "#e9b552", 12), ef.sph([.16, .22, .16], [e, 5.12, t - .3], "#e2b04a"), ef.rod([e, 5.1, t - .3], [e, 5.9, t - .3], .018, "#6b3a22"), ef.box([.42, .26, .01], [e + .22, 5.74, t - .3], "#ff7a1a"), eh.plane(2.3, .6, [e, 2.55, T.front - .12], [0, 0, 0]), eq(M(e - 1.35, .46, T.front + 0), M(e + 1.35, .46, T.front + 0), X ? .42 : .7), eW.position.set(e, 2.76, T.front - .05);
                        let l = eo(new o.nzx([new o.I9Y(0, 0), new o.I9Y(.15, 0), new o.I9Y(.14, .04), new o.I9Y(.1, .14), new o.I9Y(.08, .26), new o.I9Y(.04, .3), new o.I9Y(0, .31)], 14)),
                            n = new o.eaF(l, W.toon("#d9a441"));
                        n.position.y = -.5;
                        let i = new o.eaF(W.geo("dw-rope", () => new o.Ho_(.012, .012, .2, 5)), W.toon("#b8322b"));
                        i.position.y = -.1, eW.add(n, i), et.add(eW)
                    }
                    let eL = W.particles({
                        count: X ? 70 : 40,
                        area: [2.8, 3.2, 2.2],
                        pos: [T.x, 0, T.front + 1],
                        color: "#ffa31a",
                        size: .07,
                        mode: "fall",
                        petal: !0
                    });
                    eL.visible = !1, et.add(eL); {
                        let {
                            x: e,
                            z: t
                        } = A;
                        ef.cyl(1.25, .5, [e, .25, t], "#e5d6c0", 16), ef.cyl(1.32, .07, [e, .53, t], "#fff1dc", 16), ef.cone(.18, .3, 3.4, [e, 2.2, t], "#6b4a32", 8);
                        let a = new o.Ufg(1, 1);
                        for (let o = 0; o < (X ? 16 : 10); o++) {
                            let l = J() * v * 2,
                                n = 1.4 * J();
                            ef.add(a, (0, m.Qw)(o % 3 ? "#3f7a4a" : "#2f6a4f", ee(-.12, .12)), [e + Math.cos(l) * n, 3.6 + 1.4 * J(), t + Math.sin(l) * n], [3 * J(), 3 * J(), 0], [.9, .7, .9])
                        }
                        a.dispose();
                        for (let a = 0; a < 10; a++) {
                            let o = a / 10 * v * 2;
                            eV(e + 1.15 * Math.cos(o), .56, t + 1.15 * Math.sin(o))
                        }
                    }
                    ef.cyl(.06, 6.6, [3.2, 3.3, -4.4], "#c8a55a", 8);
                    for (let e = 1; e < 6; e++) ef.cyl(.07, .05, [3.2, 1.1 * e, -4.4], "#a8853a", 8);
                    ef.cyl(.22, .14, [3.2, .07, -4.4], "#7a7f88", 10);
                    let eN = [],
                        eJ = (e, t, a, l) => {
                            let n = [];
                            for (let o = 0; o <= 16; o++) {
                                let l = o / 16,
                                    i = e.clone().lerp(t, l);
                                i.y -= Math.sin(v * l) * a, n.push(i)
                            }
                            let i = new o.B6O(n);
                            ef.addOnce(new o.j6(i, 24, .008, 3), "#2b2522", [0, 0, 0]);
                            let r = Math.max(2, Math.floor(i.getLength() / l));
                            for (let e = 1; e < r; e++) {
                                let t = i.getPointAt(e / r);
                                eN.push(t.x, t.y - .03, t.z)
                            }
                            return i
                        },
                        eX = X ? .3 : .48,
                        eZ = [];
                    for (let [e, t, a] of [
                            [11.6, 5.3, 5],
                            [9.2, 5.6, 5.2],
                            [7, 4.9, 5.3],
                            [5.2, 5.6, 5.6],
                            [3.2, 5.1, 4.8],
                            [1.4, 5.4, 5.6]
                        ]) eZ.push(eJ(M(-2.55, t, e), M(2.55, a, e + .5), .55, eX));
                    for (let e of [-2.45, 2.45])
                        for (let [t, a] of [
                                [12.2, 8.7],
                                [8.6, 4.85],
                                [4.75, 1]
                            ]) eJ(M(e, 4.78, t), M(e, 4.78, a), .2, eX);
                    let eK = M(3.2, 6.5, -4.4),
                        e0 = [];
                    for (let [e, t, a] of [
                            [-3.6, 5.6, -12.4],
                            [.8, 8.1, -12.4],
                            [5.3, 5.6, -12.4],
                            [-10.4, 5.6, -6],
                            [-10.4, 8.1, -1.7],
                            [-4.5, 8.1, .45],
                            [4.6, 5.6, .45],
                            [T.x, 5.6, T.z - .3]
                        ]) e0.push(eJ(eK, M(e, t, a), 1.1, eX));
                    let e1 = x.Warm,
                        e2 = (0, m.zq)({
                            positions: eN,
                            colors: e1,
                            sizes: .2,
                            time: e.time,
                            px: e.px,
                            rand: J,
                            twinkle: Z ? .06 : .25,
                            core: .24
                        });
                    et.add(e2);
                    let e5 = [],
                        e4 = new o.Ho_(0, .2, .24, 6),
                        e3 = new o.Ho_(.2, .2, .14, 6),
                        e6 = new o.Ho_(.2, 0, .28, 6),
                        e8 = new o.Ho_(0, .065, .22, 4),
                        e7 = (e, t, a, o) => {
                            let l = {
                                    aDelay: a,
                                    aRand: J()
                                },
                                n = [t, t, t],
                                i = a => [e.x, e.y + a * t, e.z];
                            ec.add(e4, i(.19), [0, 0, 0], n, l), ec.add(e3, i(0), [0, 0, 0], n, l), ec.add(e6, i(-.21), [0, 0, 0], n, l);
                            for (let a = 0; a < 6; a++) {
                                let o = a / 6 * v * 2 + v / 6;
                                ec.add(e8, [e.x + .27 * Math.cos(o) * t, e.y, e.z - .27 * Math.sin(o) * t], [0, o, -v / 2], n, l)
                            }
                            ef.rod([e.x, o, e.z], [e.x, e.y + .31 * t, e.z], .006, "#2b2522", 3);
                            let r = ["#e8475f", "#3fb86a", "#ffcf40"];
                            for (let a = 0; a < 3; a++) ef.box([.025 * t, .26 * t, .025 * t], [e.x + (a - 1) * .04 * t, e.y - .5 * t, e.z], r[a]);
                            e5.push({
                                pos: e,
                                delay: a,
                                size: .9 * t
                            })
                        }; {
                        e7(P, 1.9, 0, eZ[3].getPointAt(.5).y);
                        let e = (e, t, a, o, l) => {
                            let n = e.getPointAt(t);
                            e7(M(n.x, n.y - a, n.z), o, l, n.y)
                        };
                        for (let [t, a] of [
                                [0, .68],
                                [1, .3],
                                [2, .66],
                                [4, .34],
                                [5, .62]
                            ]) {
                            let o = eZ[t].getPointAt(a).z;
                            e(eZ[t], a, .85, 1, .3 + .12 * Math.abs(o - P.z))
                        }[0, 2, 3, 6, 7].forEach((t, a) => e(e0[t], .55, .9, 1.05, 1.2 + .22 * a))
                    }
                    e4.dispose(), e3.dispose(), e6.dispose(), e8.dispose();
                    let e9 = (0, m.zq)({
                        positions: e5.flatMap(e => [e.pos.x, e.pos.y, e.pos.z]),
                        colors: ["#000000"],
                        sizes: e5.map(e => e.size),
                        time: e.time,
                        px: e.px,
                        rand: J,
                        twinkle: Z ? .04 : .12,
                        core: .12
                    });
                    et.add(e9);
                    let te = N.texture(1024, 220, () => {}); {
                        let e = new p;
                        e.plane(4.6, .99, [0, 4.3, 11], [0, 0, 0]), e.plane(4.6, .99, [0, 4.3, 10.99], [0, v, 0], void 0, [1, 0, 0, 1]);
                        let t = e.build(eo(new o.V9B({
                            map: te,
                            color: "#d8cfc8"
                        })));
                        for (let e of (t && (eo(t.geometry), et.add(W.noShadow(t))), [-1, 1])) ef.rod([2.3 * e, 4.8, 11], [2.58 * e, 5.1, 11], .01, "#2b2522", 3)
                    }
                    let tt = N.texture(512, 128, () => {}); {
                        let e = new o.eaF(eo(new o.bdM(1.8, .45)), eo(new o.V9B({
                            map: tt,
                            color: "#e6dcd0"
                        })));
                        e.position.set(-3.6, 2.85, -12.48), et.add(W.noShadow(e))
                    }
                    let ta = eo(new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        polygonOffset: !0,
                        polygonOffsetFactor: -2,
                        uniforms: {
                            uMap: {
                                value: ey
                            },
                            uReveal: {
                                value: 0
                            },
                            uGain: {
                                value: .9
                            }
                        },
                        vertexShader: "varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position, 1.0); }",
                        fragmentShader: `uniform sampler2D uMap; uniform float uReveal, uGain; varying vec2 vUv;
      void main(){
        vec4 t = texture2D(uMap, vUv);
        vec2 c = vUv - 0.5; float r = length(c)*2.0; float a = atan(c.y, c.x);
        float wob = 0.03*sin(a*12.0) + 0.02*sin(a*5.0 + 1.3);
        float edge = uReveal*1.1 - (r + wob);
        float shown = smoothstep(0.0, 0.05, edge);
        float drawing = step(0.001, uReveal)*(1.0 - step(0.999, uReveal));
        float rim = smoothstep(0.07, 0.0, abs(edge))*drawing;
        float chalk = 0.16*smoothstep(0.3, 0.6, t.a);
        vec3 col = t.rgb*uGain*shown + vec3(1.0, 0.86, 0.6)*rim*0.9 + vec3(0.92, 0.88, 0.84)*chalk*(1.0 - shown);
        float alpha = max(t.a*shown, max(chalk*(1.0 - shown), rim*t.a));
        if (alpha < 0.02) discard;
        gl_FragColor = vec4(col, alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                    })); {
                        let e = eo(new o.bdM(3.2, 3.2));
                        e.rotateX(-v / 2);
                        let t = new o.eaF(e, ta);
                        t.position.set(0, .012, -3.4), t.renderOrder = 1, et.add(W.noShadow(t, !0));
                        for (let e = 0; e < 14; e++) {
                            let t = e / 14 * v * 2;
                            eV(0 + 1.75 * Math.cos(t), 0, -3.4 + 1.75 * Math.sin(t))
                        }
                    }
                    let to = L.cardAspect,
                        tl = eo(new o.bdM(1, to)),
                        tn = (e, t) => {
                            let a = new o.eaF(tl, L.material(e));
                            return a.scale.setScalar(t), W.noShadow(a, !0)
                        },
                        ti = (e, t, a, o, l = 1.05, n = .36) => {
                            ef.rod([t, 0, a], [t, l - .12, a], .022, "#c8a55a", 5), ef.box([n + .05, n * to + .05, .02], [t - .012 * Math.sin(o), l, a - .012 * Math.cos(o)], "#f4ead8", [0, o, 0]);
                            let i = tn(e, n);
                            i.position.set(t + .003 * Math.sin(o), l, a + .003 * Math.cos(o)), i.rotation.y = o, et.add(i)
                        }; {
                        let e = tn(0, .42);
                        e.position.set(2.575, 1.5, 10.72), e.rotation.y = -v / 2, et.add(e), ef.box([.02, .42 * to + .06, .48], [2.59, 1.5, 10.72], "#fff1dc");
                        let t = tn(1, .36);
                        t.position.set(P.x, P.y - .02, P.z + .4), et.add(t), ef.box([.42, .36 * to + .06, .02], [P.x, P.y - .02, P.z + .39], "#e2b04a");
                        let a = tn(2, .5);
                        a.rotation.x = -v / 2, a.position.set(0, .018, -3.4), et.add(a), ti(3, -6.25, -7.95, .15), ti(5, 2.5, -7.6, Math.atan2(4, 2.3)), ti(6, 9.4, -9.9, Math.atan2(-4.8, 4.6)), ti(7, 8.9, -1.3, Math.atan2(-4.5, -4.5));
                        let o = tn(8, .36);
                        o.position.set(10.6 - .14, 1.01 + .36 * to * .5 + .02, -2.4), o.rotation.set(0, -v / 2, -.04), et.add(o), ef.box([.02, .36 * to + .05, .41], [10.475, 1.01 + .36 * to * .5 + .02, -2.4], "#f4ead8")
                    }
                    let tr = eo(new o.Df({
                            map: eg,
                            gradientMap: W.ramp
                        })),
                        tf = new o.eaF(eo(new o.Ho_(.3, .3, .15, 4, 1).rotateY(v / 4).scale(1.15, 1, .9)), tr);
                    tf.position.set(-3.6, 1.135, -12.08), et.add(tf);
                    let ts = new o.YJl;
                    ts.position.set(-3.6, 1.215, -12.28); {
                        let e = new o.eaF(eo(new o.Ho_(.3, .3, .05, 4, 1).rotateY(v / 4).scale(1.2, 1, .94)), tr);
                        e.position.set(0, .025, .2);
                        let t = tn(4, .3);
                        t.rotation.x = v / 2, t.position.set(0, -.004, .2), ts.add(e, t)
                    }
                    et.add(ts);
                    let td = (e, t) => {
                            let a = eo(new o.RoJ({
                                    map: em(e, 256, 256, t, `https://cdn.cutiepage.in/template-seeds/cp-diwali-dabba/art/${e}-v2.webp`),
                                    transparent: !0,
                                    depthWrite: !1
                                })),
                                l = new o.kxk(a);
                            return l.visible = !1, et.add(l), l
                        },
                        tc = [td("laddoo", (e, t) => {
                            e.fillStyle = "#ffa31a", e.beginPath(), e.arc(t / 2, t / 2, .4 * t, 0, 2 * v), e.fill()
                        }), td("kaju-katli", (e, t) => {
                            e.fillStyle = "#f4ead8", e.beginPath(), e.moveTo(t / 2, .15 * t), e.lineTo(.85 * t, t / 2), e.lineTo(t / 2, .85 * t), e.lineTo(.15 * t, t / 2), e.fill()
                        }), td("jalebi", (e, t) => {
                            e.strokeStyle = "#ff8a1a", e.lineWidth = .08 * t, e.beginPath();
                            for (let a = 0; a < 6 * v; a += .2) e.lineTo(t / 2 + Math.cos(a) * a * t * .022, t / 2 + Math.sin(a) * a * t * .022);
                            e.stroke()
                        })],
                        tp = W.geo("dw-stick", () => new o.Ho_(.006, .006, 1, 5).translate(0, .5, 0)),
                        tu = [new o.eaF(tp, W.toon("#8a8f99")), new o.eaF(tp, W.toon("#8a8f99"))];
                    for (let e of tu) e.visible = !1, e.scale.set(1, .42, 1), et.add(W.noShadow(e));
                    ef.cone(.04, .17, .34, [8.2, .17, -8.6], "#d8322b", 12), ef.cyl(.13, .05, [8.2, .1, -8.6], "#e2b04a", 12), ef.cyl(.09, .04, [8.2, .22, -8.6], "#e2b04a", 12);
                    let th = W.canvasTexture("dw-chakri", 128, 128, (e, t) => {
                            let a = t / 2;
                            for (let o = 0; o < 12; o++) e.fillStyle = o % 3 == 0 ? "#3fb86a" : o % 3 == 1 ? "#e84a7f" : "#ffcf40", e.beginPath(), e.moveTo(a, a), e.arc(a, a, .48 * t, o / 12 * v * 2, (o + 1) / 12 * v * 2), e.fill();
                            e.fillStyle = "#e2b04a", e.beginPath(), e.arc(a, a, .12 * t, 0, 2 * v), e.fill()
                        }),
                        tm = new o.eaF(eo(new o.tcD(.2, 20).rotateX(-v / 2)), eo(new o.Df({
                            map: th,
                            gradientMap: W.ramp,
                            side: o.$EB
                        })));
                    tm.position.set(7.4, .03, -2.4), et.add(W.noShadow(tm, !0)), ef.cyl(.055, .2, [10.32, 1.11, -3.4], "#6fa8a0", 10), ef.cyl(.025, .06, [10.32, 1.24, -3.4], "#6fa8a0", 8);
                    let tb = ((k = new m.lP).rod([0, -.35, 0], [0, .1, 0], .008, "#c8a55a", 4), k.cyl(.03, .16, [.03, .18, 0], "#d8322b", 8), k.cone(0, .03, .07, [.03, .295, 0], "#3fb86a", 8), eo((S = k.build(en)).geometry), S.position.set(10.32, 1.35, -3.4), et.add(W.noShadow(S)), S),
                        tv = tb.position.clone(),
                        tw = M(17, 13, -6),
                        tx = eo(u(ex, e.time, {
                            dim: 1.15,
                            gain: 0,
                            doubleSide: !0
                        })),
                        tg = new o.YJl; {
                        let e = eo(new o.Ho_(.24, .17, .5, 10, 1, !0)),
                            t = e.attributes.position.count;
                        e.setAttribute("aDelay", new o.THS(new Float32Array(t), 1)), e.setAttribute("aRand", new o.THS(new Float32Array(t), 1));
                        let a = new o.eaF(e, tx),
                            l = W.glow("#ffb050", 1.1, .8);
                        l.position.y = -.15;
                        let n = tn(9, .24);
                        n.position.set(0, 0, .215), n.rotation.x = -.14, tg.add(a, l, n)
                    }
                    tg.position.set(4.8, 1.05, -10.35), et.add(tg);
                    let ty = X ? 14 : 8,
                        tM = new Float32Array(3 * ty),
                        tk = (0, m.zq)({
                            positions: Array.from(tM),
                            colors: ["#ffb050", "#ffc878", "#ff9a3a"],
                            sizes: .7,
                            time: e.time,
                            px: e.px,
                            rand: J,
                            twinkle: .15,
                            core: .3
                        });
                    tk.visible = !1, et.add(tk);
                    let tS = Array.from({
                            length: ty
                        }, (e, t) => ({
                            from: eE[t % eE.length].clone(),
                            t0: -1,
                            drift: ee(-.4, .4),
                            seed: 10 * J()
                        })),
                        tz = eo(function(e) {
                            let {
                                max: t,
                                time: a,
                                px: l
                            } = e, n = new Float32Array(3 * t), i = new Float32Array(3 * t), r = new Float32Array(3 * t), f = new Float32Array(t).fill(-1e3), s = new Float32Array(t).fill(1), d = new Float32Array(t), c = new Float32Array(t), p = new o.LoY, u = {
                                position: new o.THS(n, 3),
                                aVel: new o.THS(i, 3),
                                aCol: new o.THS(r, 3),
                                aBirth: new o.THS(f, 1),
                                aLife: new o.THS(s, 1),
                                aSize: new o.THS(d, 1),
                                aGrav: new o.THS(c, 1)
                            };
                            for (let [e, t] of Object.entries(u)) p.setAttribute(e, t);
                            let h = new o.BKk({
                                    transparent: !0,
                                    depthWrite: !1,
                                    blending: o.EZo,
                                    uniforms: {
                                        uTime: a,
                                        uPx: l
                                    },
                                    vertexShader: `uniform float uTime, uPx; attribute vec3 aVel, aCol; attribute float aBirth, aLife, aSize, aGrav; varying vec3 vC; varying float vA;
      void main(){
        float t = uTime - aBirth; float u = t/aLife;
        vC = aCol; vA = 0.0;
        if (t < 0.0 || u > 1.0) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); gl_PointSize = 0.0; return; }
        vec3 p = position + aVel*(1.0 - exp(-1.6*t))/1.6; p.y -= 0.5*aGrav*t*t; p.y = max(p.y, 0.015);
        vA = pow(1.0 - u, 1.2)*(0.7 + 0.3*sin(t*70.0 + aBirth*137.0));
        vC = mix(aCol, vec3(1.0, 0.45, 0.12), u*0.7);
        vec4 mv = modelViewMatrix*vec4(p, 1.0);
        gl_Position = projectionMatrix*mv;
        gl_PointSize = clamp(aSize*(1.0 - 0.5*u)*uPx/max(-mv.z, 0.1), 1.0, 64.0);
      }`,
                                    fragmentShader: `varying vec3 vC; varying float vA;
      void main(){ float d = length(gl_PointCoord - 0.5)*2.0; if (d > 1.0) discard; float core = smoothstep(0.5, 0.0, d); float halo = pow(1.0 - d, 2.0)*0.4;
        gl_FragColor = vec4((vC*(core + halo) + vec3(core*core*0.5))*vA, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                                }),
                                m = new o.ONl(p, h);
                            m.frustumCulled = !1, m.userData.noShadow = !0;
                            let b = 0,
                                v = !1;
                            return {
                                points: m,
                                emit(e, o, l, p, u, h) {
                                    let m = b++ % t;
                                    n.set([e.x, e.y, e.z], 3 * m), i.set([o.x, o.y, o.z], 3 * m), r.set([l.r, l.g, l.b], 3 * m), f[m] = a.value, s[m] = u, d[m] = p, c[m] = h, v = !0
                                },
                                commit() {
                                    if (v)
                                        for (let e of (v = !1, Object.values(u))) e.needsUpdate = !0
                                },
                                reset() {
                                    f.fill(-1e3), u.aBirth.needsUpdate = !0
                                },
                                dispose() {
                                    p.dispose(), h.dispose()
                                }
                            }
                        }({
                            max: X ? 2400 : 1200,
                            time: e.time,
                            px: e.px
                        }));
                    et.add(tz.points);
                    let tT = eo((0, b.Pz)({
                        slots: X ? 18 : 10,
                        perSlot: X ? 150 : 80,
                        time: e.time,
                        px: e.px,
                        rand: J,
                        calm: Z
                    }));
                    et.add(tT.points);
                    let tA = eo((0, b.W5)({
                        count: X ? 1500 : 850,
                        center: M(0, 0, 0),
                        width: 26,
                        time: e.time,
                        px: e.px,
                        rand: J
                    }));
                    tA.points.position.copy(F), tA.points.rotation.y = -v / 2, et.add(tA.points);
                    let tP = N.texture(1024, 360, () => {}),
                        tF = (e, t) => {
                            let a = new o.eaF(W.geo("dw-hitbox", () => new o.Ufg(1, 1)), er);
                            return a.scale.set(e[0], e[1], e[2]), a.position.set(t[0], t[1], t[2]), et.add(W.noShadow(a)), a
                        },
                        tR = {
                            diya: tF([.5, .4, .5], [2.3, .3, 9.5]),
                            kandil: tF([.7, .9, .7], [P.x, P.y, P.z]),
                            rangoli: tF([1.6, .2, 1.6], [0, .1, -3.4]),
                            bell: tF([.5, .6, .5], [T.x, 2.3, T.front - .05]),
                            box: tF([.5, .4, .5], [-3.6, 1.06 + .1, -12.08]),
                            anar: tF([.4, .4, .4], [8.2, .2, -8.6]),
                            chakri: tF([.5, .25, .5], [7.4, .1, -2.4]),
                            rocket: tF([.4, .6, .4], [10.32, 1.31, -3.4]),
                            lantern: tF([.5, .6, .5], [4.8, 1.05, -10.35])
                        };
                    e$.dispose(), eH.dispose();
                    let tB = ($ = (a = {
                        positions: ej,
                        delays: eY,
                        sizes: eQ,
                        time: e.time,
                        px: e.px,
                        rand: J
                    }).positions.length / 3, (I = new o.LoY).setAttribute("position", new o.THS(new Float32Array(a.positions), 3)), I.setAttribute("aDelay", new o.THS(new Float32Array(a.delays), 1)), I.setAttribute("aSize", new o.THS(new Float32Array(a.sizes), 1)), I.setAttribute("aRand", new o.THS(Float32Array.from({
                        length: $
                    }, () => a.rand()), 1)), O = {
                        uTime: a.time,
                        uPx: a.px,
                        uStart: {
                            value: 1e6
                        },
                        uBoost: {
                            value: 0
                        }
                    }, E = new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: o.EZo,
                        uniforms: O,
                        vertexShader: `uniform float uTime, uPx, uStart, uBoost; attribute float aDelay, aSize, aRand; varying float vA;
      void main(){
        float t = uTime - uStart - aDelay;
        float on = step(0.0, t);
        float pop = 1.0 + 1.8*exp(-max(t, 0.0)*6.0);
        float flick = 0.86 + 0.1*sin(uTime*(8.0 + aRand*6.0) + aRand*30.0) + 0.06*sin(uTime*21.0 + aRand*11.0);
        vA = on*flick*(1.0 + uBoost*0.5);
        vec4 mv = modelViewMatrix*vec4(position, 1.0);
        gl_Position = projectionMatrix*mv;
        gl_PointSize = on > 0.5 ? clamp(aSize*pop*(1.0 + uBoost*0.3)*uPx/max(-mv.z, 0.1), 1.0, 180.0) : 0.0;
        if (on < 0.5) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      }`,
                        fragmentShader: `varying float vA;
      void main(){
        vec2 q = gl_PointCoord - 0.5; q.y = -q.y;
        float r = length(vec2(q.x*(2.4 + q.y*3.2), (q.y + 0.1)*1.5));
        float core = smoothstep(0.42, 0.08, r);
        float white = smoothstep(0.2, 0.0, r);
        float halo = pow(max(0.0, 1.0 - length(q)*2.0), 2.2)*0.55;
        vec3 c = vec3(1.0, 0.5, 0.12)*core*1.5 + vec3(1.0, 0.9, 0.62)*white*1.2 + vec3(1.0, 0.55, 0.2)*halo;
        gl_FragColor = vec4(c*vA, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                    }), (U = new o.ONl(I, E)).frustumCulled = !1, U.userData.noShadow = !0, Object.assign(U, {
                        uniforms: O,
                        count: $
                    }), U);
                    eo(tB.geometry), eo(tB.material), et.add(tB);
                    let tC = ef.build(en);
                    tC && (eo(tC.geometry), et.add(tC));
                    let t_ = es.build(en);
                    t_ && (eo(t_.geometry), et.add(W.noShadow(t_)));
                    let tD = ed.build(ei);
                    tD && (eo(tD.geometry), et.add(W.noShadow(tD)));
                    let tH = eo(u(eb, e.time, {
                            dim: .1,
                            gain: 1.25,
                            base: .14
                        })),
                        tj = ep.build(tH);
                    tj && (eo(tj.geometry), et.add(W.noShadow(tj)));
                    let tY = eo(u(ex, e.time, {
                            dim: .22,
                            gain: 1.45
                        })),
                        tQ = ec.build(tY);
                    tQ && (eo(tQ.geometry), et.add(W.noShadow(tQ)));
                    let tV = eu.build(eo(new o.Df({
                        map: ev,
                        gradientMap: W.ramp
                    })));
                    tV && (eo(tV.geometry), et.add(W.noShadow(tV, !0)));
                    let tq = eh.build(eo(new o.Df({
                        map: ew,
                        gradientMap: W.ramp,
                        alphaTest: .45,
                        side: o.$EB
                    })));
                    tq && (eo(tq.geometry), et.add(W.noShadow(tq)));
                    let tG = e.values,
                        t$ = e.mood;

                    function tI() {
                        N.redraw(tP, (e, t, a, o) => (0, m.Lf)(e, t, a, tG.toName, tG.fromName, o.display, N.fit)), tA.setCanvas(tP.image)
                    }

                    function tO(e) {
                        tG = e, N.redraw(te, (e, t, a, o) => {
                            e.fillStyle = "#7a1426", e.fillRect(0, 0, t, a), e.strokeStyle = "#e2b04a", e.lineWidth = 8, e.strokeRect(10, 10, t - 20, a - 20);
                            for (let o = 0; o < 26; o++) e.fillStyle = o % 2 ? "#ffa31a" : "#ff7a1a", e.beginPath(), e.arc(20 + o * (t - 40) / 25, a - 6, 9, 0, 2 * v), e.fill();
                            let l = tG.decor1Photo ? .image;
                            if (l) {
                                let o = t - 60,
                                    n = a - 60,
                                    i = l.width ? ? 1,
                                    r = l.height ? ? 1,
                                    f = Math.max(o / i, n / r);
                                e.save(), e.beginPath(), e.rect(30, 30, o, n), e.clip(), e.drawImage(l, 30 + (o - i * f) / 2, 30 + (n - r * f) / 2, i * f, r * f), e.restore();
                                return
                            }
                            for (let l of (e.fillStyle = "#ffd27a", e.textAlign = "center", e.textBaseline = "middle", e.font = N.fit(e, "Happy Diwali", o.display, 66, .6 * t, 700), e.fillText("Happy Diwali", t / 2, .3 * a), e.save(), e.translate(.04 * t, .5 * a), (0, m.Lf)(e, .92 * t, .38 * a, tG.toName, tG.fromName, o.script, N.fit, "#fff3e0"), e.restore(), [.1 * t, .9 * t])) e.fillStyle = "#c4643a", e.beginPath(), e.ellipse(l, .62 * a, 46, 20, 0, 0, v), e.fill(), e.fillStyle = "#ffcf5a", e.beginPath(), e.ellipse(l, .47 * a, 12, 24, 0, 0, 2 * v), e.fill()
                        }), N.redraw(tt, (e, t, a, o) => {
                            e.fillStyle = "#3d1a2a", e.fillRect(0, 0, t, a), e.strokeStyle = "#e2b04a", e.lineWidth = 6, e.strokeRect(6, 6, t - 12, a - 12), e.fillStyle = "#ffd27a", e.textAlign = "center", e.textBaseline = "middle", e.font = N.fit(e, "Mithai Ghar", o.display, 64, t - 60, 700), e.fillText("Mithai Ghar", t / 2, a / 2 + 2)
                        }), tI(), e1 = x[tG.decor1] ? ? x.Warm;
                        for (let e = 0; e < e2.count; e++) e2.setColor(e, e1[e % e1.length]);
                        e2.commit(),
                            function() {
                                let [e, t] = g[tG.decor2] ? ? g.Saffron, a = tG.decor2Photo;
                                for (let o of [tY, tx]) o.uniforms.uHue.value = a ? 0 : e, o.uniforms.uTint.value.set(a ? "#ffffff" : t), o.uniforms.uMap.value = a ? ? ex
                            }(), tA.uniforms.uColorB.value.set(tG.accent || "#ff8fab")
                    }

                    function tE(t) {
                        t$ = t;
                        let a = w[t];
                        eS.setColors(a.sky);
                        let l = e.scene.fog;
                        l instanceof o.jUj && (l.color.set(a.fog[0]), l.near = a.fog[1], l.far = a.fog[2]), eF.color.set(a.star[0]), eF.intensity = a.star[1], ez.material.uniforms.uOpacity.value = .85 * a.stars, eT.setColors(...a.skyline)
                    }
                    let tU = 0,
                        tW = 0,
                        tL = 0,
                        tN = 0,
                        tJ = 1e6,
                        tX = new o.Q1f,
                        tZ = new o.Q1f,
                        tK = new o.Q1f("#ff9a52"),
                        t0 = new o.Q1f("#9a86e0"),
                        t1 = e => {
                            tB.uniforms.uStart.value = e, tH.uniforms.uStart.value = e, tL = 1
                        },
                        t2 = e => {
                            tJ = e, tY.uniforms.uStart.value = e
                        },
                        t5 = {
                            match: "whoosh",
                            chime: "chime",
                            bell: "chime",
                            fizz: "sparkle",
                            fountain: "sparkle",
                            whirr: "sparkle",
                            whistle: "whoosh",
                            boom: "firework",
                            lid: "pop",
                            paper: "pop"
                        },
                        t4 = (t, a) => {
                            if (el.live) el.play(t, a);
                            else {
                                let a = t5[t];
                                a && e.sfx(a)
                            }
                        },
                        t3 = null,
                        t6 = (e, t) => {
                            t3 ? .stop(.2), (t3 = el.live ? el.loop(e, {
                                volume: t
                            }) : null) || t4(e)
                        },
                        t8 = () => {
                            t3 ? .stop(.4), t3 = null
                        },
                        t7 = null,
                        {
                            a: t9,
                            b: ae
                        } = e.actors,
                        at = {
                            diya: R.diya,
                            kandils: R.kandils,
                            rangoli: R.rangoli,
                            bell: R.bell,
                            mithai: R.mithai,
                            phuljhadi: R.phuljhadi,
                            anar: R.anar,
                            chakri: R.chakri,
                            rocket: R.rocket,
                            lantern: R.lantern
                        },
                        aa = () => {
                            for (let e of (t7 = null, t8(), tu)) e.visible = !1;
                            eL.visible = !1, eC && (eC.intensity = 0)
                        },
                        ao = (t = !1) => {
                            if (!t7) return;
                            let a = t7.kind;
                            aa(), t9.lookAt(null), ae.lookAt(null), t9.setExpression("happy"), ae.setExpression("happy"), t9.play("holdHandsWalk", {
                                speed: 0
                            }), ae.play("holdHandsWalk", {
                                speed: 0
                            }), t || e.stage.place(at[a]), e.stage.release()
                        },
                        al = (t, a) => {
                            t7 && ao(), t7 = {
                                kind: t,
                                t0: tU,
                                dur: a,
                                flags: new Set,
                                expect: null
                            }, e.stage.hold()
                        },
                        an = (e, t, a) => {
                            !t7 || t7.flags.has(e) || tU - t7.t0 < t || (t7.flags.add(e), a())
                        },
                        ai = e => Z ? Math.min(.8, e) : e,
                        ar = (e, t) => {
                            t9.lookAt(e), ae.lookAt(e), t9.setExpression(t), ae.setExpression("surprised" === t ? "happy" : t)
                        },
                        af = 0,
                        as = 0,
                        ad = 0,
                        ac = -10,
                        ap = 0,
                        au = 0,
                        ah = 0,
                        am = 0,
                        ab = 0,
                        av = -1,
                        aw = -1,
                        ax = 0,
                        ag = [{
                            at: [2.3, .95, 9.5],
                            stand: R.diya,
                            shot: B,
                            interaction: {
                                verb: "tap",
                                targets: [tR.diya],
                                run: () => (al("diya", 7.6), e.stage.camera({
                                    pos: [.55, .85, 8.35],
                                    look: [2.3, .3, 9.5],
                                    fov: 46
                                }, ai(1.1)), ar(M(2.3, .2, 9.5), "love"), 7.6),
                                reset() {
                                    tB.uniforms.uStart.value = 1e6, tH.uniforms.uStart.value = 1e6, tW = 0, tL = 0, tN = 0
                                }
                            },
                            onFound: () => tN++
                        }, {
                            at: [P.x, P.y + .9, P.z],
                            stand: R.kandils,
                            shot: C,
                            interaction: {
                                verb: "tap",
                                targets: [tR.kandil],
                                run: () => (al("kandils", 5.2), t2(tU + .4), ar(P, "love"), e.stage.camera({
                                    pos: [.6, 1, 8.6],
                                    look: [0, 3.5, 4.6],
                                    fov: 54
                                }, ai(1.4)), 5.2),
                                reset() {
                                    t2(1e6)
                                }
                            },
                            onFound: () => tN++
                        }, {
                            at: [0, .85, -3.4],
                            stand: R.rangoli,
                            shot: _,
                            interaction: {
                                verb: "hold",
                                holdSeconds: 2.2,
                                targets: [tR.rangoli],
                                hold(e) {
                                    as = .78 * e
                                },
                                run: () => (al("rangoli", 2.6), as = 1, ar(M(0, 0, -3.4), "love"), 2.6),
                                reset() {
                                    af = 0, as = 0
                                }
                            },
                            onFound: () => tN++
                        }, {
                            at: [T.x, 3.4, T.front + .1],
                            stand: R.bell,
                            shot: D,
                            interaction: {
                                verb: "tap",
                                targets: [tR.bell],
                                run: () => (al("bell", 4.4), ac = tU, ad = Z ? .25 : .55, ax = 1, eL.visible = !0, ar(M(T.x, 2.3, T.front), "love"), 4.4)
                            },
                            onFound: () => tN++
                        }, {
                            at: [-3.6, 1.76, -12.08],
                            stand: R.mithai,
                            shot: H,
                            interaction: {
                                verb: "tap",
                                targets: [tR.box],
                                run: () => (al("mithai", 4.4), e.stage.camera({
                                    pos: [-2.9, 1.55, -10.4],
                                    look: [-3.6, 1.21, -12.08],
                                    fov: 48
                                }, ai(1)), ar(M(-3.6, 1.26, -12.08), "love"), 4.4),
                                reset() {
                                    ap = 0, au = 0, ah = 0
                                }
                            },
                            onFound: () => tN++
                        }, {
                            at: [3.2, 1.75, -7.4],
                            stand: R.phuljhadi,
                            shot: j,
                            interaction: {
                                verb: "tap",
                                run: () => (al("phuljhadi", 6.4), t9.play("wave"), ae.play("wave"), t9.setExpression("happy"), ae.setExpression("love"), e.stage.camera({
                                    pos: [5.8, 1.35, -5.7],
                                    look: [3.5, 1.35, -6.7],
                                    fov: 48
                                }, ai(1)), 6.4)
                            },
                            onFound: () => tN++
                        }, {
                            at: [8.2, .95, -8.6],
                            stand: R.anar,
                            shot: Y,
                            interaction: {
                                verb: "tap",
                                targets: [tR.anar],
                                run: () => (al("anar", 6), ar(M(8.2, 1.2, -8.6), "surprised"), e.stage.camera({
                                    pos: [4.9, 1.2, -5.6],
                                    look: [8.2, 1.9, -9.2],
                                    fov: 52
                                }, ai(1.2)), 6)
                            },
                            onFound: () => tN++
                        }, {
                            at: [7.4, .85, -2.4],
                            stand: R.chakri,
                            shot: Q,
                            interaction: {
                                verb: "tap",
                                targets: [tR.chakri],
                                run: () => (al("chakri", 5.4), ar(M(7.4, 0, -2.4), "happy"), 5.4)
                            },
                            onFound: () => tN++
                        }, {
                            at: [10.32, 1.01 + .85, -3.4],
                            stand: R.rocket,
                            shot: V,
                            interaction: {
                                verb: "tap",
                                targets: [tR.rocket],
                                run: () => (al("rocket", 5.4), ar(tw, "surprised"), 5.4),
                                reset() {
                                    av = -1, tb.visible = !0, tb.position.copy(tv)
                                }
                            },
                            onFound: () => tN++
                        }, {
                            at: [4.8, 1.9, -10.35],
                            stand: R.lantern,
                            shot: q,
                            interaction: {
                                verb: "tap",
                                targets: [tR.lantern],
                                run: () => (al("lantern", 7), aw = 0, ar(M(4.8, 4, -10.35), "love"), 7),
                                reset() {
                                    aw = -1, tg.visible = !0, tg.position.set(4.8, 1.05, -10.35), tg.rotation.set(0, 0, 0)
                                }
                            },
                            onFound: () => tN++
                        }],
                        ay = ag.map((e, t) => ({
                            memory: t,
                            stand: e.stand,
                            shot: e.shot
                        })),
                        aM = R.spawn,
                        ak = [{
                            pos: [30, 22, 34],
                            look: [0, 1, -2],
                            fov: 45
                        }, {
                            pos: [.5, 8.5, 20],
                            look: [0, 2.2, 3],
                            fov: 50
                        }, {
                            pos: [aM.x, 1.95, aM.z + 3.3],
                            look: [aM.x, 1.1, aM.z - 4],
                            fov: 50
                        }],
                        aS = {
                            pos: [5.2, 1.15, -4.4],
                            look: [40, 13, -9],
                            fov: 52
                        },
                        az = (e, t = !1) => {
                            let a = y[Math.floor(J() * y.length)],
                                o = J();
                            if ("town" === e) tT.launch(M(ee(34, 70), ee(14, 30), ee(-34, 22)), o < .45 ? 0 : o < .62 ? 1 : o < .72 ? 2 : 3, a[0], a[1], (t ? .6 : 1) * ee(8, 12));
                            else {
                                let e = J() * v * 2,
                                    t = ee(90, 140);
                                tT.launch(M(Math.cos(e) * t, ee(14, 28), Math.sin(e) * t), .7 > J() ? 0 : 1, a[0], a[1], ee(4, 7))
                            }
                        },
                        aT = !1,
                        aA = 0,
                        aP = 0,
                        aF = 3,
                        aR = 0,
                        aB = [];

                    function aC(e, t) {
                        tk.visible = !0, tS.forEach((a, o) => {
                            (t || o < 5) && (a.t0 = e + o * (Z ? .5 : .35) + .3 * J())
                        })
                    }
                    let a_ = new o.Pq0,
                        aD = new o.Pq0,
                        aH = new o.Q1f,
                        aj = new o.Q1f("#ffd27a"),
                        aY = new o.Q1f("#fff4dc"),
                        aQ = new o.Q1f("#ff9a3a"),
                        aV = new o.Q1f("#7dffb0"),
                        aq = new o.Q1f("#ff7aa8"),
                        aG = new o.Q1f,
                        a$ = [new o.Q1f("#ffd23f"), new o.Q1f("#e84a7f"), new o.Q1f("#3fb8a0"), new o.Q1f("#ff8a3d"), new o.Q1f("#b18cff")],
                        aI = {},
                        aO = (e, t, a) => {
                            let o = (aI[e] ? ? 0) + t * a * (X ? 1 : .55),
                                l = Math.floor(o);
                            return aI[e] = o - l, l
                        };
                    tE(e.mood), tO(e.values);
                    let aE = (e, t, a, o) => [
                            [e, t],
                            [a, t],
                            [a, o],
                            [e, o]
                        ],
                        aU = {
                            boundary: [
                                [-2, 12.2],
                                [2, 12.2],
                                [2, .05],
                                [10.05, .05],
                                [10.05, -12],
                                [-10.05, -12],
                                [-10.05, .05],
                                [-2, .05]
                            ],
                            circles: [{
                                x: A.x,
                                z: A.z,
                                r: 1.35
                            }, {
                                x: 3.2,
                                z: -4.4,
                                r: .3
                            }, {
                                x: 8.2,
                                z: -8.6,
                                r: .35
                            }, {
                                x: 7.4,
                                z: -2.4,
                                r: .42
                            }, {
                                x: -6.25,
                                z: -7.95,
                                r: .22
                            }, {
                                x: 2.5,
                                z: -7.6,
                                r: .22
                            }, {
                                x: 9.4,
                                z: -9.9,
                                r: .22
                            }, {
                                x: 8.9,
                                z: -1.3,
                                r: .22
                            }],
                            blocks: [aE(-1.75, -5.15, 1.75, -1.65), aE(T.x - 1.7, T.z - 1.6, T.x + 1.7, T.front + .45), aE(-5.6, -12.6, -1.6, -11.6)]
                        };
                    return {
                        root: et,
                        sky: eM,
                        exposure: 1.2,
                        fog: w[e.mood].fog,
                        walk: aU,
                        spawn: R.spawn,
                        memories: ag,
                        tour: ay,
                        intro: ak,
                        letter: {
                            pos: [5.6, 2.3, -1.2],
                            look: [-3.5, 2.6, -9],
                            fov: 52
                        },
                        finale: {
                            spot: R.finale,
                            shot: aS,
                            start: function() {
                                aa(), aT = !0, aA = tU, tB.uniforms.uStart.value > tU && t1(tU - .5), tJ > tU && t2(tU), tI(), tA.reset(), tT.reset();
                                let t = Z ? .9 : .3,
                                    a = M(R.finale.x, 1.2, R.finale.z);
                                aB = [{
                                    at: 0,
                                    done: !1,
                                    fire: () => az("town")
                                }, {
                                    at: t,
                                    done: !1,
                                    fire: () => az("town")
                                }, {
                                    at: 2 * t,
                                    done: !1,
                                    fire: () => az("town")
                                }, {
                                    at: 2 * t + .3,
                                    done: !1,
                                    fire: () => {
                                        tA.start(tU), tT.launch(F.clone().add(M(1, 1.5, 0)), 3, "#ffd27a", "#fff3c0", 5, .1), t4("whistle", {
                                            volume: .5
                                        })
                                    }
                                }, {
                                    at: 1.5,
                                    done: !1,
                                    fire: () => aC(tU, !0)
                                }], Z || aB.push({
                                    at: 6,
                                    done: !1,
                                    fire: () => e.stage.camera({
                                        pos: [a.x - 2.6, 2.5, a.z - 3],
                                        look: [34, 12, -3],
                                        fov: 54
                                    }, 4.5)
                                }, {
                                    at: 11,
                                    done: !1,
                                    fire: () => e.stage.camera({
                                        pos: [a.x - 1.8, .8, a.z + 3.4],
                                        look: [34, 15, -12],
                                        fov: 54
                                    }, 4.5)
                                }, {
                                    at: 16,
                                    done: !1,
                                    fire: () => e.stage.camera(aS, 4.5)
                                }), aP = Z ? 4 : 2.2
                            },
                            reset: function() {
                                for (let e of (aT = !1, aB = [], tT.reset(), tA.reset(), tk.visible = !1, tS)) e.t0 = -1
                            }
                        },
                        ambience: "diwali",
                        update: function(t, a) {
                            tU = t;
                            let o = Math.min(1, .85 * (tW += (tL - tW) * Math.min(1, .5 * a)) + .02 * tN + .15 * !!aT),
                                l = w[t$];
                            for (let e of (tX.set(l.hemi[0]).lerp(t0, .35 * o), tZ.set(l.hemi[1]).lerp(tK, .75 * o), eA.color.copy(tX), eA.groundColor.copy(tZ), eA.intensity = l.hemi[2] + .4 * o + .45 * aR, eP.intensity = .06 + .08 * o, eR)) e.light.intensity = e.base * (.12 + .88 * o) * (Z ? 1 : 1 + .04 * Math.sin(2.1 * t + e.base));
                            tH.uniforms.uBase.value = .14 + .035 * tN, e2.uniforms.uOpacity.value = .18 + .82 * Math.min(1, 1.2 * tW), e2.uniforms.uChase.value = Z ? 0 : .55 * tW, tB.uniforms.uBoost.value = .35 * !!aT + .2 * ax, ax = Math.max(0, ax - .4 * a);
                            for (let e = 0; e < e5.length; e++) {
                                let a = e5[e],
                                    o = Math.max(0, Math.min(1, (t - tJ - a.delay) / .45));
                                e9.setColor(e, `#${aG.set("#ff8a2a").multiplyScalar(.08+.92*o).getHexString()}`)
                            }
                            if (e9.commit(), af += (as - af) * Math.min(1, a * (as >= 1 ? 2.2 : 6)), ta.uniforms.uReveal.value = af, as > 0 && af < .985 && as - af > .004)
                                for (let e = 0, t = aO("rangoli", 70, a); e < t; e++) {
                                    let e = J() * v * 2,
                                        t = 1.6 * Math.min(1, 1.05 * af);
                                    a_.set(0 + Math.cos(e) * t, .04, -3.4 + Math.sin(e) * t), aD.set(Math.cos(e) * ee(.1, .4), ee(.5, 1.2), Math.sin(e) * ee(.1, .4)), tz.emit(a_, aD, a$[Math.floor(J() * a$.length)], .09, ee(.6, 1.1), 1.2)
                                }
                            if (ad > 0) {
                                let e = t - ac,
                                    a = ad * Math.exp(-(.7 * e));
                                eW.rotation.z = Math.sin(5.2 * e) * a, a < .004 && (ad = 0, eW.rotation.z = 0)
                            }
                            if (ap += (au - ap) * Math.min(1, 5 * a), ts.rotation.x = -1.95 * ap, tc.forEach((e, a) => {
                                    e.visible = ah > .01;
                                    let o = ah * (.2 + .06 * (1 === a));
                                    e.position.set(-3.6 + (a - 1) * .15, 1.22 + o + (Z ? 0 : .015 * Math.sin(2 * t + a) * ah), -12.06), e.scale.setScalar(.17 * Math.min(1, 1.3 * ah))
                                }), am > 0) {
                                ab += am * a, tm.rotation.y = ab;
                                let e = .08 * (am > 6);
                                tm.position.set(7.4 + Math.sin(3.1 * t) * e, .03, -2.4 + Math.cos(2.7 * t) * e)
                            }
                            if (av >= 0) {
                                let e = Math.min(1, (av += a) / 1.3);
                                tb.position.lerpVectors(tv, tw, e * e), tb.position.y = tv.y + (tw.y - tv.y) * (1 - (1 - e) * (1 - e));
                                for (let e = 0, t = aO("rocket", 120, a); e < t; e++) aD.set(ee(-.3, .3), ee(-1.2, -.4), ee(-.3, .3)), tz.emit(tb.position, aD, .5 > J() ? aj : aQ, .07, ee(.3, .6), 2);
                                e >= 1 && tb.visible && (tb.visible = !1, tT.launch(tw, 2, "#ff6bd5", "#ffd27a", 6.5, -1.1), Z || tT.launch(tw.clone().add(M(0, 1.5, -2)), 1, "#ffd27a", "#ffffff", 5, -.75), av = -1)
                            }
                            if (aw >= 0) {
                                let e = aw += a;
                                tg.position.set(4.8 + .25 * Math.sin(.6 * e) * Math.min(1, .4 * e) + .12 * e, 1.05 + .32 * e + .17 * e * e, -10.35 - .18 * e), tg.rotation.z = Z ? 0 : .06 * Math.sin(1.1 * e), tg.position.y > 70 && (tg.visible = !1, aw = -1)
                            }
                            if (tk.visible) {
                                let e = tk.geometry.attributes.position;
                                for (let a = 0; a < ty; a++) {
                                    let o = tS[a],
                                        l = o.t0 >= 0 ? t - o.t0 : -1;
                                    l < 0 ? e.setXYZ(a, 0, -50, 0) : e.setXYZ(a, o.from.x + .6 * Math.sin(.5 * l + o.seed) + l * o.drift, o.from.y + .6 * l + .06 * l * l, o.from.z + .5 * Math.cos(.4 * l + o.seed))
                                }
                                e.needsUpdate = !0
                            }
                            if (t7 ? .kind === "phuljhadi" && tu[0].visible && ([t9.hand("left"), ae.hand("right")].forEach((e, t) => {
                                    let o = tu[t];
                                    e.getWorldPosition(o.position);
                                    let l = (0 === t ? t9 : ae).object.rotation.y;
                                    a_.set(.45 * Math.sin(l) + (0 === t ? 1 : -1) * Math.cos(l) * .15, .85, .45 * Math.cos(l) - (0 === t ? 1 : -1) * Math.sin(l) * .15).normalize(), o.quaternion.setFromUnitVectors(aD.set(0, 1, 0), a_);
                                    let n = a_.multiplyScalar(.42).add(o.position);
                                    for (let e = 0, o = aO(`stick${t}`, 85, a); e < o; e++) {
                                        let e = J() * v * 2,
                                            t = ee(-.6, 1),
                                            a = ee(.8, 2.2);
                                        aD.set(Math.cos(e) * a, t * a, Math.sin(e) * a), aH.copy(.65 > J() ? aj : aY), tz.emit(n, aD, aH, .05, ee(.18, .4), 3)
                                    }
                                    eC && 0 === t && eC.position.copy(n)
                                }), eC && (eC.intensity = 4 + 1.2 * Math.sin(40 * t))), t7 && (t7.expect ? t7.expect.distanceToSquared(t9.object.position) > .09 && ao(!0) : t7.expect = t9.object.position.clone()), t7) {
                                let o = t - t7.t0;
                                switch (t7.kind) {
                                    case "diya":
                                        an("match", .5, () => t4("match", {
                                            volume: .6
                                        })), an("light", 1.1, () => {
                                            t1(t - 1e-4), t4("flame", {
                                                volume: .7
                                            })
                                        }), an("rise", 1.9, () => e.stage.camera({
                                            pos: [.2, 7.6, 12.6],
                                            look: [0, 2, -2.5],
                                            fov: 52
                                        }, ai(2.6))), an("chime", 2.4, () => t4("chime", {
                                            volume: .4
                                        })), an("chime2", 3.6, () => t4("chime", {
                                            volume: .3,
                                            rate: 1.25
                                        })), an("sparkle", 4.2, () => e.sfx("sparkle")), an("back", 6, () => e.stage.camera(B, ai(1.4))), o >= t7.dur - .2 && ao();
                                        break;
                                    case "kandils":
                                        an("chimes", .4, () => {
                                            for (let e = 0; e < 6; e++) t4("chime", {
                                                volume: .22,
                                                rate: .85 + .09 * e,
                                                delay: .24 * e
                                            })
                                        }), an("paper", .2, () => t4("paper", {
                                            volume: .4
                                        })), o >= t7.dur - .2 && ao();
                                        break;
                                    case "rangoli":
                                        an("chime", .1, () => t4("chime", {
                                            volume: .45
                                        })), an("sparkle", .6, () => e.sfx("sparkle")), o >= t7.dur - .2 && ao();
                                        break;
                                    case "bell":
                                        an("b1", .05, () => t4("bell", {
                                            volume: .75
                                        })), an("b2", 1.3, () => t4("bell", {
                                            volume: .55
                                        })), an("b3", 2.55, () => t4("bell", {
                                            volume: .4
                                        })), ax = 1, o >= t7.dur - .2 && (eL.visible = !1, ao());
                                        break;
                                    case "mithai":
                                        an("lid", .25, () => {
                                            au = 1, t4("lid", {
                                                volume: .7
                                            })
                                        }), an("paper", .7, () => t4("paper", {
                                            volume: .4
                                        })), an("chime", 1, () => t4("chime", {
                                            volume: .4,
                                            rate: 1.1
                                        })), o > .7 && (ah = Math.min(1, ah + 1.6 * a)), o >= t7.dur - .2 && ao();
                                        break;
                                    case "phuljhadi":
                                        if (an("match", .25, () => t4("match", {
                                                volume: .6
                                            })), an("on", .7, () => {
                                                for (let e of tu) e.visible = !0;
                                                t6("fizz", .6)
                                            }), o >= t7.dur - .5) {
                                            for (let e of tu) e.visible = !1;
                                            t8()
                                        }
                                        o >= t7.dur - .2 && ao();
                                        break;
                                    case "anar":
                                        if (an("match", .2, () => t4("match", {
                                                volume: .6
                                            })), an("on", .8, () => t6("fountain", .65)), o > .8 && o < 5.2) {
                                            let e = Math.min(1, (o - .8) * 2) * Math.min(1, (5.2 - o) * 1.5);
                                            for (let t = 0, o = aO("anar", 260 * e, a); t < o; t++) {
                                                a_.set(8.2, .36, -8.6);
                                                let t = J() * v * 2,
                                                    a = ee(0, 1.1);
                                                aD.set(Math.cos(t) * a, ee(5.2, 7.6) * (.7 + .3 * e), Math.sin(t) * a), aH.copy(.5 > J() ? aj : .6 > J() ? aY : aQ), tz.emit(a_, aD, aH, .085, ee(.9, 1.5), 7.5)
                                            }
                                            eC && (eC.position.set(8.2, 1.2, -8.6), eC.intensity = 9 * e * (.85 + .15 * Math.sin(30 * t))), aR = Math.max(aR, .25 * e)
                                        }
                                        an("off", 5.2, () => t8()), o >= t7.dur - .2 && ao();
                                        break;
                                    case "chakri":
                                        {
                                            an("match", .2, () => t4("match", {
                                                volume: .6
                                            })),
                                            an("on", .7, () => t6("whirr", .6));
                                            let e = o > .7 && o < 4.6;
                                            if (am = e ? Math.min(28, am + 40 * a) : Math.max(0, am - 18 * a), e) {
                                                for (let e = 0; e < 2; e++) {
                                                    let t = ab + e * v;
                                                    for (let o = 0, l = aO(`chakri${e}`, 90, a); o < l; o++) {
                                                        a_.set(tm.position.x + .2 * Math.cos(t), .06, tm.position.z - .2 * Math.sin(t));
                                                        let e = ee(2.2, 3.6);
                                                        aD.set(-Math.sin(t) * e + ee(-.3, .3), ee(.4, 1.2), -Math.cos(t) * e + ee(-.3, .3)), tz.emit(a_, aD, .5 > J() ? aj : .5 > J() ? aV : aq, .06, ee(.3, .55), 4)
                                                    }
                                                }
                                                eC && (eC.position.set(7.4, .6, -2.4), eC.intensity = 6 * (.85 + .15 * Math.sin(25 * t)))
                                            }
                                            an("off", 4.6, () => t8()),
                                            o >= t7.dur - .2 && ao();
                                            break
                                        }
                                    case "rocket":
                                        an("match", .2, () => t4("match", {
                                            volume: .6
                                        })), an("go", .7, () => {
                                            av = 0, t4("whistle", {
                                                volume: .7
                                            }), e.stage.camera({
                                                pos: [5.8, 1.3, -.3],
                                                look: [14.5, 9.5, -5.2],
                                                fov: 56
                                            }, ai(1.3))
                                        }), an("back", 4.2, () => e.stage.camera(V, ai(1))), o >= t7.dur - .2 && ao();
                                        break;
                                    case "lantern":
                                        an("paper", .15, () => t4("paper", {
                                            volume: .5
                                        })), an("chime", 1.3, () => t4("chime", {
                                            volume: .4,
                                            rate: .9
                                        })), an("up", 1.6, () => e.stage.camera({
                                            pos: [6.6, 1.2, -6.4],
                                            look: [5.2, 7.5, -11.4],
                                            fov: 56
                                        }, ai(3))), an("others", 2.4, () => aC(t, !1)), o >= t7.dur - .2 && ao()
                                }
                            }
                            if (!aT && t > aF && (aF = t + (Z ? 7 : 3) + 4 * J(), az("far")), aT) {
                                let e = t - aA;
                                for (let t of aB) !t.done && e >= t.at && (t.done = !0, t.fire());
                                e > aP && (aP = e + (Z ? 1.8 : .55) + J() * (Z ? 1.2 : .7), az("town"), !Z && .35 > J() && az("town", !0))
                            }
                            tT.popped(t) > 0 && (aT || t7 ? .kind === "rocket" ? (t4("boom", {
                                volume: .55,
                                rate: ee(.85, 1.12)
                            }), .5 > J() && t4("crackle", {
                                volume: .35,
                                delay: .35
                            }), aR = Math.min(1, aR + (Z ? .2 : .5))) : el.live && el.play("boom", {
                                volume: .12,
                                rate: ee(.7, .9),
                                delay: .4
                            })), aR = Math.max(0, aR - a * (Z ? 1 : 2.4)), tz.commit()
                        },
                        setMood: tE,
                        setValues: tO,
                        restore(e) {
                            tN = e.filter(Boolean).length, e[0] && (t1(-1e5), tW = 1), e[1] && t2(-1e5), e[2] && (as = 1, af = 1), e[4] && (au = 1, ap = 1, ah = 1), e[8] && (tb.visible = !1), e[9] && (tg.visible = !1)
                        },
                        dispose() {
                            for (let e of (t8(), ea)) e.dispose();
                            ea.length = 0
                        }
                    }
                },
                ambience: function(e) {
                    let {
                        ctx: t,
                        out: a,
                        noise: o,
                        chirp: l
                    } = e, n = t.currentTime, i = [], r = [], f = [], s = !1, d = t.createBufferSource();
                    d.buffer = o(5), d.loop = !0;
                    let c = t.createBiquadFilter();
                    c.type = "bandpass", c.frequency.value = 420, c.Q.value = .7;
                    let p = t.createGain();
                    p.gain.setValueAtTime(0, n), p.gain.linearRampToValueAtTime(.05, n + 2.5);
                    let u = t.createOscillator();
                    u.frequency.value = .08;
                    let h = t.createGain();
                    h.gain.value = .025, u.connect(h).connect(p.gain), u.start(), d.connect(c).connect(p).connect(a), d.start(), r.push(d, u), i.push(c, p, h);
                    let m = t.createBufferSource();
                    m.buffer = o(4), m.loop = !0;
                    let b = t.createBiquadFilter();
                    b.type = "lowpass", b.frequency.value = 180;
                    let v = t.createGain();
                    v.gain.setValueAtTime(0, n), v.gain.linearRampToValueAtTime(.18, n + 2), m.connect(b).connect(v).connect(a), m.start(), r.push(m), i.push(b, v);
                    let w = (e, t) => {
                            s || f.push(setTimeout(() => !s && t(), 1e3 * e))
                        },
                        x = () => {
                            .55 > Math.random() && l(4300 + 500 * Math.random(), 3 + Math.floor(4 * Math.random()), .05, .007, 1.02), w(.8 + +Math.random(), x)
                        };
                    w(1.5, x);
                    let g = () => {
                        let e = 3 + Math.floor(9 * Math.random()),
                            l = t.currentTime;
                        for (let n = 0; n < e; n++) {
                            let e = t.createBufferSource();
                            e.buffer = o(1);
                            let n = t.createBiquadFilter();
                            n.type = "bandpass", n.frequency.value = 1300 + 1900 * Math.random();
                            let i = t.createGain();
                            i.gain.setValueAtTime(1e-4, l), i.gain.exponentialRampToValueAtTime(.025 + .03 * Math.random(), l + .004), i.gain.exponentialRampToValueAtTime(1e-4, l + .06), e.connect(n).connect(i).connect(a), e.start(l, .5 * Math.random(), .08), l += .05 + .12 * Math.random()
                        }
                        if (.35 > Math.random()) {
                            let e = t.createBufferSource();
                            e.buffer = o(1);
                            let n = t.createBiquadFilter();
                            n.type = "lowpass", n.frequency.value = 200;
                            let i = t.createGain();
                            i.gain.setValueAtTime(1e-4, l), i.gain.exponentialRampToValueAtTime(.1, l + .01), i.gain.exponentialRampToValueAtTime(1e-4, l + .8), e.connect(n).connect(i).connect(a), e.start(l, 0, .9)
                        }
                        w(2.5 + 5 * Math.random(), g)
                    };
                    return w(2, g), {
                        stop() {
                            for (let e of (s = !0, f)) clearTimeout(e);
                            let e = t.currentTime;
                            for (let t of (p.gain.cancelScheduledValues(e), v.gain.cancelScheduledValues(e), r)) try {
                                t.stop()
                            } catch {}
                            for (let e of i) e.disconnect()
                        }
                    }
                }
            }
        }
    }
]);