"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [82527], {
        8617: (e, t, a) => {
            a.d(t, {
                q6: () => u,
                sK: () => c
            });
            var o = a(84910),
                i = a(30494);
            let n = `uniform float uTime, uPx, uSize; uniform vec3 uArea; attribute float aRand; varying float vA;
void main(){
  vec3 p = position; vA = 1.0;
  #if MODE == 0
    p.y = mod(position.y - uTime*(0.35 + aRand*0.35), uArea.y);
    p.x += sin(uTime*0.8 + aRand*20.0)*0.6; p.z += cos(uTime*0.6 + aRand*13.0)*0.4;
  #elif MODE == 1
    p += vec3(sin(uTime*0.4 + aRand*30.0), sin(uTime*0.7 + aRand*11.0)*0.4, cos(uTime*0.5 + aRand*17.0))*0.8;
    vA = smoothstep(0.15, 1.0, 0.5 + 0.5*sin(uTime*(1.2 + aRand) + aRand*40.0));
  #elif MODE == 2
    vA = 0.7 + 0.3*sin(uTime*(1.5 + aRand*2.0) + aRand*50.0);
  #else
    p.y = mod(position.y + uTime*(0.3 + aRand*0.25), uArea.y);
    p.x += sin(uTime*0.3 + aRand*9.0)*0.6;
    vA = 1.0 - smoothstep(uArea.y*0.6, uArea.y, p.y);
  #endif
  vec4 mv = modelViewMatrix*vec4(p, 1.0);
  gl_Position = projectionMatrix*mv;
  gl_PointSize = max(1.5, uSize*(0.6 + aRand*0.8)*uPx / -mv.z);
}`,
                l = `uniform vec3 uColor; uniform float uOpacity; varying float vA;
void main(){
  vec2 q = gl_PointCoord - 0.5;
  #if PETAL == 1
    q *= vec2(1.0, 1.7); float a = smoothstep(0.5, 0.36, length(q)); vec3 c = uColor;
  #else
    float a = smoothstep(0.5, 0.0, length(q)); a *= a; vec3 c = uColor*(1.0 + a*1.5);
  #endif
  gl_FragColor = vec4(c, a*vA*uOpacity);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`,
                r = {
                    fall: 0,
                    firefly: 1,
                    twinkle: 2,
                    rise: 3
                },
                s = [
                    ["#ffb38a", "#ff7a8a", "#3d6b5a"],
                    ["#26335e", "#6d4f93", "#241f3a"],
                    ["#ffd29d", "#f08a5d", "#2f4b6e"],
                    ["#bfe3ff", "#f7c6e0", "#6aa36f"],
                    ["#8fa7b8", "#5d7486", "#3b4b55"],
                    ["#ffe0b5", "#ffb0a8", "#a7c58b"],
                    ["#c9b6ff", "#ff9fc4", "#5a4a7a"],
                    ["#9fe0d4", "#ffd7a8", "#3f6f63"]
                ];

            function c(e) {
                let t = e;
                return () => {
                    t |= 0;
                    let e = Math.imul((t = t + 0x6d2b79f5 | 0) ^ t >>> 15, 1 | t);
                    return (((e = e + Math.imul(e ^ e >>> 7, 61 | e) ^ e) ^ e >>> 14) >>> 0) / 0x100000000
                }
            }
            a(36744);
            let f = (e, t) => JSON.stringify(e) === JSON.stringify(t);

            function u(e) {
                let {
                    scene: t,
                    doc: a,
                    quality: u,
                    reducedMotion: d,
                    fonts: h
                } = e, p = e.values, m = c(e.seed ? ? 7), v = {
                    value: 0
                }, b = {
                    value: 800
                }, g = function(e) {
                    let {
                        quality: t,
                        time: a,
                        px: i,
                        rand: s,
                        doc: c
                    } = e, f = "high" === t, u = (e, t) => e + (t - e) * s(), d = new Map, h = new Map, p = new Map, m = [], v = new o.GYF(new Uint8Array([70, 140, 200, 255]), 4, 1, o.VT0);
                    v.minFilter = o.hxR, v.magFilter = o.hxR, v.needsUpdate = !0;
                    let b = e => (m.push(e), e);

                    function g(e, t = {}) {
                        let {
                            flatShading: a,
                            ...i
                        } = t, n = `t${e}${JSON.stringify(i,(e,t)=>t&&"object"==typeof t&&"uuid"in t?t.uuid:t)}`, l = d.get(n);
                        return l || (l = new o.Df({
                            color: e,
                            gradientMap: v,
                            ...i
                        }), d.set(n, l)), l
                    }

                    function y(e, t = {}) {
                        let a = `b${e}${JSON.stringify(t,(e,t)=>t&&"object"==typeof t&&"uuid"in t?t.uuid:t)}`,
                            i = d.get(a);
                        return i || (i = new o.V9B({
                            color: e,
                            ...t
                        }), d.set(a, i)), i
                    }

                    function w(e, t) {
                        let a = h.get(e);
                        return a || (a = t(), h.set(e, a)), a
                    }

                    function x(e, t, a, i) {
                        let n = p.get(e);
                        if (!n) {
                            let l = c.createElement("canvas");
                            l.width = t, l.height = a;
                            let r = l.getContext("2d");
                            r && i(r, t, a), (n = new o.GOR(l)).colorSpace = o.er$, n.anisotropy = 4, p.set(e, n)
                        }
                        return n
                    }
                    let S = {
                        box: () => w("box", () => new o.iNn(1, 1, 1)),
                        cyl: () => w("cyl", () => new o.Ho_(1, 1, 1, 14)),
                        ico: () => w("ico", () => new o.WBB(1, 1)),
                        sph: () => w("sph", () => new o.Gu$(1, 20, 14))
                    };

                    function k(e, t, a, i) {
                        let n = new o.eaF(S[e](), "string" == typeof t ? g(t) : t);
                        return n.scale.set(a[0], a[1], a[2]), n.position.set(i[0], i[1], i[2]), n
                    }
                    let C = () => x("glow", 128, 128, (e, t) => {
                        let a = e.createRadialGradient(t / 2, t / 2, 0, t / 2, t / 2, t / 2);
                        a.addColorStop(0, "rgba(255,255,255,1)"), a.addColorStop(.25, "rgba(255,255,255,.55)"), a.addColorStop(1, "rgba(255,255,255,0)"), e.fillStyle = a, e.fillRect(0, 0, t, t)
                    });

                    function M(e, t = !1) {
                        return e.userData.noShadow = !t, e.userData.receiveOnly = t, e
                    }

                    function z(e, t, a = 1) {
                        let i = b(new o.RoJ({
                                map: C(),
                                color: e,
                                blending: o.EZo,
                                transparent: !0,
                                depthWrite: !1,
                                opacity: a
                            })),
                            n = new o.kxk(i);
                        return n.scale.setScalar(t), M(n)
                    }

                    function T({
                        count: e,
                        area: t = [10, 5, 10],
                        pos: c = [0, 0, 0],
                        color: f,
                        size: d,
                        mode: h,
                        opacity: p = 1,
                        petal: m = !1,
                        positions: v
                    }) {
                        let g = b(new o.LoY),
                            y = v ? ? new Float32Array(3 * e),
                            w = new Float32Array(e);
                        for (let a = 0; a < e; a++) v || (y[3 * a] = u(-t[0] / 2, t[0] / 2), y[3 * a + 1] = u(0, t[1]), y[3 * a + 2] = u(-t[2] / 2, t[2] / 2)), w[a] = s();
                        g.setAttribute("position", new o.THS(y, 3)), g.setAttribute("aRand", new o.THS(w, 1));
                        let x = b(new o.BKk({
                                transparent: !0,
                                depthWrite: !1,
                                blending: m ? o.NTi : o.EZo,
                                defines: {
                                    MODE: r[h],
                                    PETAL: +!!m
                                },
                                uniforms: {
                                    uTime: a,
                                    uPx: i,
                                    uSize: {
                                        value: d
                                    },
                                    uColor: {
                                        value: new o.Q1f(f)
                                    },
                                    uOpacity: {
                                        value: p
                                    },
                                    uArea: {
                                        value: new o.Pq0(t[0], t[1], t[2])
                                    }
                                },
                                vertexShader: n,
                                fragmentShader: l
                            })),
                            S = new o.ONl(g, x);
                        return S.position.set(c[0], c[1], c[2]), S.frustumCulled = !1, M(S)
                    }
                    return {
                        quality: t,
                        high: f,
                        toon: g,
                        basic: y,
                        ramp: v,
                        geo: w,
                        canvasTexture: x,
                        part: k,
                        capsule: (e, t) => w(`cap${e}_${t}`, () => new o.qU7(e, t, 6, 14)),
                        glow: z,
                        glowTexture: C,
                        particles: T,
                        starDome: function(e, t, a = "#dfe6ff") {
                            let o = new Float32Array(3 * e);
                            for (let a = 0; a < e; a++) {
                                let e = s() * Math.PI * 2,
                                    i = u(.08, 1),
                                    n = Math.sqrt(1 - i * i);
                                o[3 * a] = Math.cos(e) * n * t, o[3 * a + 1] = i * t, o[3 * a + 2] = Math.sin(e) * n * t
                            }
                            return T({
                                count: e,
                                positions: o,
                                color: a,
                                size: 1.5,
                                mode: "twinkle",
                                opacity: .85
                            })
                        },
                        sky: function(e) {
                            let t = {
                                    uTop: {
                                        value: new o.Q1f(e.top)
                                    },
                                    uHor: {
                                        value: new o.Q1f(e.horizon)
                                    },
                                    uBot: {
                                        value: new o.Q1f(e.bottom)
                                    },
                                    uSun: {
                                        value: new o.Pq0(...e.sunDir ? ? [0, .1, -1]).normalize()
                                    },
                                    uSunCol: {
                                        value: new o.Q1f(e.sunColor ? ? "#000000")
                                    }
                                },
                                a = b(new o.BKk({
                                    side: o.hsX,
                                    depthWrite: !1,
                                    fog: !1,
                                    uniforms: t,
                                    vertexShader: "varying vec3 vD; void main(){ vD = position; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }",
                                    fragmentShader: `uniform vec3 uTop,uHor,uBot,uSun,uSunCol; varying vec3 vD;
          void main(){ vec3 d = normalize(vD); float h = d.y;
            vec3 c = h > 0.0 ? mix(uHor, uTop, pow(clamp(h,0.0,1.0), 0.55)) : mix(uHor, uBot, clamp(-h*4.0,0.0,1.0));
            float s = max(dot(d, uSun), 0.0); c += uSunCol*(pow(s, 900.0)*3.0 + pow(s, 10.0)*0.45);
            gl_FragColor = vec4(c, 1.0);
            #include <tonemapping_fragment>
            #include <colorspace_fragment>
          }`
                                })),
                                i = new o.eaF(w("skysphere", () => new o.Gu$(300, 32, 16)), a);
                            return i.renderOrder = -1, i.frustumCulled = !1, i.setColors = e => {
                                t.uTop.value.set(e.top), t.uHor.value.set(e.horizon), t.uBot.value.set(e.bottom), t.uSun.value.set(...e.sunDir ? ? [0, .1, -1]).normalize(), t.uSunCol.value.set(e.sunColor ? ? "#000000")
                            }, M(i)
                        },
                        grass: function(e, t, i, n = ["#7dbb5e", "#8fca63", "#6aa851", "#a3d06e"]) {
                            let l = b(new o.bdM(.07, .38, 1, 4));
                            l.translate(0, .19, 0);
                            let r = l.attributes.position;
                            for (let e = 0; e < r.count; e++) r.setX(e, r.getX(e) * (1 - r.getY(e) / .38 * .9));
                            let c = b(new o.Df({
                                gradientMap: v,
                                side: o.$EB
                            }));
                            c.onBeforeCompile = e => {
                                e.uniforms.uTime = a, e.vertexShader = "uniform float uTime;\nvarying float vGH;\n" + e.vertexShader.replace("#include <begin_vertex>", `#include <begin_vertex>
          float hh = transformed.y / 0.38;
          vec2 ip = vec2(instanceMatrix[3][0], instanceMatrix[3][2]);
          float sway = sin(uTime*1.7 + ip.x*0.6 + ip.y*0.45)*0.5 + sin(uTime*3.1 + ip.x*1.7)*0.2;
          transformed.x += sway*0.12*hh*hh; transformed.z += sway*0.05*hh*hh; vGH = hh;`), e.fragmentShader = "varying float vGH;\n" + e.fragmentShader.replace("#include <color_fragment>", "#include <color_fragment>\n diffuseColor.rgb *= mix(0.5, 1.08, vGH);")
                            };
                            let f = new o.ZLX(l, c, e),
                                d = new o.B69,
                                h = new o.Q1f,
                                p = 0,
                                m = 0;
                            for (; p < e && m < 20 * e;) {
                                m++;
                                let e = s() * Math.PI * 2,
                                    a = Math.sqrt(s()) * t,
                                    o = Math.cos(e) * a,
                                    l = Math.sin(e) * a;
                                !i(o, l) && (d.position.set(o, 0, l), d.rotation.set(0, s() * Math.PI, 0), d.scale.set(1, u(.6, 1.3), 1), d.updateMatrix(), f.setMatrixAt(p, d.matrix), f.setColorAt(p, h.set(n[p % n.length])), p++)
                            }
                            return f.count = p, M(f, !0)
                        },
                        water: function(e, t, i = [96, 24]) {
                            let n = {
                                    uTime: a,
                                    uDeep: {
                                        value: new o.Q1f(e.deep)
                                    },
                                    uShallow: {
                                        value: new o.Q1f(e.shallow)
                                    },
                                    uSky: {
                                        value: new o.Q1f(e.sky)
                                    },
                                    uGlint: {
                                        value: new o.Q1f(e.glint)
                                    }
                                },
                                l = b(new o.BKk({
                                    uniforms: n,
                                    vertexShader: `uniform float uTime; varying vec3 vW;
          void main(){ vec3 p = position; p.y += sin(p.x*0.9 + uTime*1.2)*0.04 + sin(p.z*1.3 - uTime*0.9)*0.03;
            vec4 w = modelMatrix*vec4(p,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }`,
                                    fragmentShader: `uniform float uTime; uniform vec3 uDeep, uShallow, uSky, uGlint; varying vec3 vW;
          float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7)))*43758.5453); }
          void main(){
            vec3 V = normalize(cameraPosition - vW);
            float dx = cos(vW.x*0.9 + uTime*1.2)*0.036 + cos(vW.x*2.7 + vW.z*1.1 + uTime*2.0)*0.02;
            float dz = cos(vW.z*1.3 - uTime*0.9)*0.039 + sin(vW.z*3.1 - vW.x*0.7 + uTime*1.7)*0.02;
            vec3 N = normalize(vec3(-dx*4.0, 1.0, -dz*4.0));
            float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
            vec3 col = mix(uDeep, uShallow, 0.35 + 0.3*sin(vW.x*0.2 + uTime*0.3));
            col = mix(col, uSky, clamp(fres*0.9, 0.0, 1.0));
            vec2 cell = floor(vW.xz*vec2(5.0, 9.0) + vec2(uTime*0.5, 0.0)); float h = hash(cell);
            float tw = step(0.972, h)*(0.5 + 0.5*sin(uTime*4.0 + h*60.0));
            col += uGlint*tw*0.8;
            gl_FragColor = vec4(col, 1.0);
            #include <tonemapping_fragment>
            #include <colorspace_fragment>
          }`
                                })),
                                r = b(new o.bdM(t[0], t[1], i[0], i[1]));
                            r.rotateX(-Math.PI / 2);
                            let s = new o.eaF(r, l);
                            return s.setColors = e => {
                                n.uDeep.value.set(e.deep), n.uShallow.value.set(e.shallow), n.uSky.value.set(e.sky), n.uGlint.value.set(e.glint)
                            }, M(s)
                        },
                        rain: function(e, t, i = "#b9c8ff") {
                            let n = new Float32Array(6 * e),
                                l = new Float32Array(2 * e);
                            for (let a = 0; a < e; a++) {
                                let e = u(-t[0] / 2, t[0] / 2),
                                    o = u(0, t[1]),
                                    i = u(-t[2] / 2, t[2] / 2);
                                for (let t = 0; t < 2; t++) n.set([e, o, i], (2 * a + t) * 3), l[2 * a + t] = t
                            }
                            let r = b(new o.LoY);
                            r.setAttribute("position", new o.THS(n, 3)), r.setAttribute("aEnd", new o.THS(l, 1));
                            let s = b(new o.BKk({
                                    transparent: !0,
                                    depthWrite: !1,
                                    uniforms: {
                                        uTime: a,
                                        uH: {
                                            value: t[1]
                                        },
                                        uColor: {
                                            value: new o.Q1f(i)
                                        }
                                    },
                                    vertexShader: `uniform float uTime, uH; attribute float aEnd; varying float vE;
          void main(){ vec3 p = position; p.y = mod(position.y - uTime*11.0, uH) + aEnd*0.42; p.x += aEnd*0.07; vE = aEnd;
            gl_Position = projectionMatrix*modelViewMatrix*vec4(p,1.0); }`,
                                    fragmentShader: `uniform vec3 uColor; varying float vE; void main(){ gl_FragColor = vec4(uColor, mix(0.55, 0.0, vE));
          #include <colorspace_fragment>
        }`
                                })),
                                c = new o.DXC(r, s);
                            return c.frustumCulled = !1, M(c)
                        },
                        ripples: function(e, t, i = "#9fb3e6") {
                            let n = b(new o.bdM(1, 1));
                            n.rotateX(-Math.PI / 2);
                            let l = new Float32Array(e);
                            for (let t = 0; t < e; t++) l[t] = s();
                            n.setAttribute("aPhase", new o.uWO(l, 1));
                            let r = b(new o.BKk({
                                    transparent: !0,
                                    depthWrite: !1,
                                    blending: o.EZo,
                                    uniforms: {
                                        uTime: a,
                                        uColor: {
                                            value: new o.Q1f(i)
                                        }
                                    },
                                    vertexShader: `attribute float aPhase; varying vec2 vUv; varying float vP;
          void main(){ vUv = uv; vP = aPhase; gl_Position = projectionMatrix*modelViewMatrix*instanceMatrix*vec4(position,1.0); }`,
                                    fragmentShader: `uniform float uTime; uniform vec3 uColor; varying vec2 vUv; varying float vP;
          void main(){ float t = fract(uTime*0.9 + vP); float r = length(vUv - 0.5)*2.0;
            float ring = smoothstep(0.08, 0.0, abs(r - t))*(1.0 - t); gl_FragColor = vec4(uColor, ring*0.55);
            #include <colorspace_fragment>
          }`
                                })),
                                c = new o.ZLX(n, r, e),
                                f = new o.B69;
                            for (let a = 0; a < e; a++) f.position.set(u(-t, t), .015, u(-t, t)), f.scale.setScalar(u(.25, .55)), f.updateMatrix(), c.setMatrixAt(a, f.matrix);
                            return M(c)
                        },
                        windows: function(e) {
                            let t = `win${e}`,
                                a = d.get(t);
                            return a || (a = new o.Df({
                                color: e,
                                gradientMap: v,
                                emissive: 0xffffff,
                                emissiveMap: x("windows", 64, 128, (e, t, a) => {
                                    e.fillStyle = "#000", e.fillRect(0, 0, t, a);
                                    let o = 3,
                                        i = () => (o = 16807 * o % 0x7fffffff) / 0x7fffffff;
                                    for (let o = 6; o < a - 8; o += 14)
                                        for (let a = 6; a < t - 6; a += 13) e.fillStyle = .42 > i() ? .5 > i() ? "#ffd48a" : "#ffb870" : "#15161d", e.fillRect(a, o, 7, 9)
                                }),
                                emissiveIntensity: .9
                            }), d.set(t, a)), a
                        },
                        tree: function(e, t, a = 1, i = "#6fae6a", n = "#7a5236") {
                            let l = new o.YJl;
                            for (let [e, t, o, r] of (l.add(k("cyl", n, [.14 * a, 1.5 * a, .14 * a], [0, .75 * a, 0])), [
                                    [0, 1.8, 0, .85],
                                    [.45, 1.5, .2, .6],
                                    [-.42, 1.55, -.15, .62],
                                    [.05, 2.35, .05, .55]
                                ])) {
                                let n = k("ico", g(i, {
                                    flatShading: !0
                                }), [r * a, r * a, r * a], [e * a, t * a, o * a]);
                                n.rotation.set(3 * s(), 3 * s(), 0), l.add(n)
                            }
                            return l.position.set(e, 0, t), l.rotation.y = s() * Math.PI * 2, l
                        },
                        lamp: function(e, t, a = {}) {
                            let {
                                floorGlow: i = !0,
                                intensity: n = 14,
                                color: l = "#ffc27a",
                                alwaysLight: r = !1
                            } = a, s = new o.YJl;
                            s.add(k("cyl", "#2c2f3a", [.05, 2.6, .05], [0, 1.3, 0])), s.add(k("box", "#2c2f3a", [.26, .22, .26], [0, 2.68, 0])), s.add(k("sph", y("#ffe7b8"), [.09, .09, .09], [0, 2.54, 0]));
                            let c = z(l, 1.8, .9);
                            if (c.position.set(0, 2.55, 0), s.add(c), f || r) {
                                let e = new o.HiM(l, n, 9, 2);
                                e.position.set(0, 2.45, 0), s.add(e)
                            }
                            if (i) {
                                let e = new o.eaF(w("flatplane", () => new o.bdM(1, 1).rotateX(-Math.PI / 2)), b(new o.V9B({
                                    map: C(),
                                    color: l,
                                    blending: o.EZo,
                                    transparent: !0,
                                    depthWrite: !1,
                                    opacity: .38
                                })));
                                e.scale.set(2.4, 1, 2.4), e.position.set(0, .012, 0), s.add(M(e))
                            }
                            return s.position.set(e, 0, t), s
                        },
                        bench: function(e, t, a = 0) {
                            let i = new o.YJl,
                                n = "#8a5a3a";
                            for (let e of (i.add(k("box", n, [1.4, .07, .42], [0, .45, 0]), k("box", n, [1.4, .32, .06], [0, .72, -.19])), [-.6, .6])) i.add(k("box", "#2a2a30", [.06, .45, .4], [e, .22, 0]));
                            return i.position.set(e, 0, t), i.rotation.y = a, i
                        },
                        string: function(e, t, a, i = "#3a2a22") {
                            let n = [];
                            for (let o = 0; o <= 24; o++) {
                                let i = o / 24,
                                    l = e.clone().lerp(t, i);
                                l.y -= Math.sin(Math.PI * i) * a, n.push(l)
                            }
                            let l = new o.B6O(n);
                            return {
                                mesh: M(new o.eaF(b(new o.j6(l, 48, .008, 5)), g(i))),
                                at: e => l.getPoint(e)
                            }
                        },
                        bulbs: function(e, t = "#ffcf7d", a = .2) {
                            let o = new Float32Array(3 * e.length);
                            return e.forEach((e, t) => {
                                o[3 * t] = e.x, o[3 * t + 1] = e.y, o[3 * t + 2] = e.z
                            }), T({
                                count: e.length,
                                positions: o,
                                color: t,
                                size: a,
                                mode: "twinkle"
                            })
                        },
                        noShadow: M,
                        dispose() {
                            for (let e of d.values()) e.dispose();
                            for (let e of h.values()) e.dispose();
                            for (let e of p.values()) e.dispose();
                            for (let e of m) e.dispose();
                            v.dispose(), d.clear(), h.clear(), p.clear(), m.length = 0
                        }
                    }
                }({
                    quality: u,
                    time: v,
                    px: b,
                    rand: m,
                    doc: a
                }), y = "siblings" === e.bond, w = function(e) {
                    let {
                        doc: t,
                        count: a,
                        scriptFont: i
                    } = e, n = [], l = [{
                        url: "",
                        texture: null
                    }, {
                        url: "",
                        texture: null
                    }], r = [];

                    function c(t, a) {
                        let o = t.canvas.getContext("2d");
                        if (!o) return;
                        o.fillStyle = "#fbf8f3", o.fillRect(0, 0, 384, 464);
                        o.save(), o.beginPath(), o.rect(20, 20, 344, 344), o.clip();
                        let n = t.image;
                        if (n && n.naturalWidth > 0) {
                            let e = Math.max(344 / n.naturalWidth, 344 / n.naturalHeight),
                                t = n.naturalWidth * e,
                                a = n.naturalHeight * e;
                            o.drawImage(n, 20 + (344 - t) / 2, 20 + (344 - a) / 2, t, a)
                        } else ! function(e, t, a = "heart") {
                            var o, i, n, l, r, c;
                            let [f, u, d] = s[t % s.length], h = e.createLinearGradient(0, 20, 0, 364);
                            for (let [t, a] of (h.addColorStop(0, f), h.addColorStop(1, u), e.fillStyle = h, e.fillRect(20, 20, 344, 344), e.fillStyle = "rgba(255,241,193,.92)", e.beginPath(), e.arc(274.56, 20 + .28 * 344, 37.84, 0, 7), e.fill(), e.fillStyle = d, e.beginPath(), e.ellipse(192, 381.2, 309.6, .33 * 344, 0, 0, 7), e.fill(), e.fillStyle = "rgba(28,18,34,.88)", [
                                    [.42, .2],
                                    [.58, .23]
                                ])) {
                                let o = 20 + 344 * t,
                                    i = 322.72;
                                e.beginPath(), e.arc(o, i - 344 * a - 22.36, 18.92, 0, 7), e.fill(), e.beginPath(), e.roundRect(o - 20.64, i - 344 * a, 41.28, 344 * a, 17.2), e.fill()
                            }
                            if ("diya" === a) {
                                let t;
                                return o = 192, i = 20 + .58 * 344, n = .07 * 344, (t = e.createRadialGradient(o, i - .5 * n, 0, o, i - .5 * n, 1.6 * n)).addColorStop(0, "rgba(255,214,120,.75)"), t.addColorStop(1, "rgba(255,214,120,0)"), e.fillStyle = t, e.fillRect(o - 1.6 * n, i - 2.1 * n, 3.2 * n, 3.2 * n), e.fillStyle = "#c8643a", e.beginPath(), e.ellipse(o, i, .95 * n, .42 * n, 0, 0, Math.PI), e.fill(), e.fillStyle = "#ffd36b", e.beginPath(), e.moveTo(o, i - 1.05 * n), e.quadraticCurveTo(o + .3 * n, i - .3 * n, o, i - .05 * n), e.quadraticCurveTo(o - .3 * n, i - .3 * n, o, i - 1.05 * n), e.fill()
                            }
                            e.fillStyle = "#ff6f91", l = 192, r = 192, c = .07 * 344, e.beginPath(), e.moveTo(l, r + .3 * c), e.bezierCurveTo(l, r, l - .5 * c, r, l - .5 * c, r + .3 * c), e.bezierCurveTo(l - .5 * c, r + .6 * c, l, r + .8 * c, l, r + c), e.bezierCurveTo(l, r + .8 * c, l + .5 * c, r + .6 * c, l + .5 * c, r + .3 * c), e.bezierCurveTo(l + .5 * c, r, l, r, l, r + .3 * c), e.fill()
                        }(o, a, e.motif);
                        o.restore();
                        let l = t.caption.trim();
                        if (l) {
                            o.fillStyle = "#3a2f33", o.textAlign = "center", o.textBaseline = "middle";
                            let e = function(e, t, a) {
                                let o = 40;
                                do {
                                    if (e.font = `700 ${o}px ${a}`, e.measureText(t).width <= 348) break;
                                    o -= 2
                                } while (o > 20);
                                if (e.measureText(t).width <= 348) return t;
                                let i = t;
                                for (; i.length > 1 && e.measureText(`${i}\u2026`).width > 348;) i = i.slice(0, -1);
                                return `${i}\u2026`
                            }(o, l, i);
                            o.fillText(e, 192, 414)
                        }
                        t.texture.needsUpdate = !0
                    }
                    for (let e = 0; e < Math.min(a, 10); e++) {
                        let a = t.createElement("canvas");
                        a.width = 384, a.height = 464;
                        let i = new o.GOR(a);
                        i.colorSpace = o.er$, i.anisotropy = 4;
                        let l = {
                            canvas: a,
                            texture: i,
                            material: null,
                            url: "",
                            caption: "",
                            image: null,
                            token: 0
                        };
                        n.push(l), c(l, e)
                    }

                    function f(e, a) {
                        let o = t.defaultView;
                        if (!o) return a(null);
                        let i = new o.Image,
                            n = e.startsWith("blob:") || e.startsWith("data:");
                        n || (i.crossOrigin = "anonymous"), i.decoding = "async", i.onload = () => a(i), i.onerror = () => a(null), i.src = n ? e : e.replace(/^(https:\/\/cdn\.cutiepage\.in)\/cdn-cgi\/image\/[^/]+(\/)/, "$1$2")
                    }
                    return {
                        count: n.length,
                        cardAspect: 1.2083333333333333,
                        card: e => n[Math.max(0, Math.min(n.length - 1, e))].texture,
                        material(e) {
                            let t = n[Math.max(0, Math.min(n.length - 1, e))];
                            return t.material || (t.material = new o._4j({
                                map: t.texture,
                                emissiveMap: t.texture,
                                emissive: 0xffffff,
                                emissiveIntensity: .42,
                                roughness: .85
                            })), t.material
                        },
                        polaroid(e, t = .42) {
                            let a = 1.2083333333333333 * t,
                                i = new o.YJl,
                                n = new o.bdM(t, a);
                            r.push(n);
                            let l = new o.eaF(n, this.material(e)),
                                s = new o._4j({
                                    color: "#f4efe6",
                                    roughness: .9
                                });
                            r.push(s);
                            let c = new o.eaF(n, s);
                            return c.rotation.y = Math.PI, c.position.z = -.003, i.add(l, c), i.userData.height = a, i
                        },
                        setSources(e, t) {
                            n.forEach((a, o) => {
                                let i = e[o] ? ? "",
                                    n = t[o] ? ? "",
                                    l = n !== a.caption;
                                if (a.caption = n, i === a.url) {
                                    l && c(a, o);
                                    return
                                }
                                a.url = i, a.image = null;
                                let r = ++a.token;
                                c(a, o), i && f(i, e => {
                                    r === a.token && (a.image = e, c(a, o))
                                })
                            })
                        },
                        decorTexture(e, a, i) {
                            let n = l[e];
                            if (n.url === a) return n.texture;
                            if (n.texture ? .dispose(), n.url = a, n.texture = null, !a) return null;
                            let r = t.createElement("canvas");
                            r.width = 512, r.height = 512;
                            let s = new o.GOR(r);
                            return s.colorSpace = o.er$, n.texture = s, f(a, e => {
                                if (n.texture !== s || !e) return;
                                let t = r.getContext("2d");
                                if (!t) return;
                                let a = Math.max(512 / e.naturalWidth, 512 / e.naturalHeight);
                                t.drawImage(e, (512 - e.naturalWidth * a) / 2, (512 - e.naturalHeight * a) / 2, e.naturalWidth * a, e.naturalHeight * a), s.needsUpdate = !0, i()
                            }), s
                        },
                        dispose() {
                            for (let e of n) e.token++, e.texture.dispose(), e.material ? .dispose();
                            for (let e of l) e.texture ? .dispose();
                            for (let e of r) e.dispose()
                        }
                    }
                }({
                    doc: a,
                    count: e.memoryCount,
                    scriptFont: h.script,
                    motif: y ? "diya" : "heart"
                });
                w.setSources(p.memoryPhotos, p.memoryCaptions);
                let x = function(e, t) {
                        let a = [];

                        function i(t, i) {
                            let n = e.createElement("canvas");
                            n.width = t, n.height = i;
                            let l = new o.GOR(n);
                            return l.colorSpace = o.er$, l.anisotropy = 4, a.push(l), l
                        }

                        function n(e, a) {
                            let o = e.image,
                                i = o.getContext("2d");
                            i && (i.clearRect(0, 0, o.width, o.height), a(i, o.width, o.height, t), e.needsUpdate = !0)
                        }

                        function l(e, t, a, o, i, n = 700) {
                            let r = o,
                                s = `${n} ${r}px ${a}`;
                            for (e.font = s; r > 12 && e.measureText(t).width > i;) r -= 2, e.font = s = `${n} ${r}px ${a}`;
                            return s
                        }
                        return {
                            fonts: t,
                            texture(e, t, a) {
                                let o = i(e, t);
                                return n(o, a), o
                            },
                            redraw: n,
                            label: function(e, r = {}) {
                                let {
                                    font: s = "body",
                                    size: c = 64,
                                    weight: f = 700,
                                    color: u = "#ffffff",
                                    background: d,
                                    height: h = .3
                                } = r, p = i(512, 128), m = new o.RoJ({
                                    map: p,
                                    transparent: !0,
                                    depthWrite: !1
                                });
                                a.push(m);
                                let v = new o.kxk(m);
                                v.userData.noShadow = !0;
                                let b = e => n(p, (a, o, i) => {
                                    a.font = l(a, e, t[s], c, o - 48, f);
                                    let n = Math.min(o - 8, a.measureText(e).width + 56);
                                    d && (a.fillStyle = d, a.beginPath(), a.roundRect((o - n) / 2, 12, n, i - 24, (i - 24) / 2), a.fill()), a.fillStyle = u, a.textAlign = "center", a.textBaseline = "middle", a.fillText(e, o / 2, i / 2 + 2)
                                });
                                return b(e), v.setText = b, v.scale.set(4 * h, h, 1), v
                            },
                            fit: l,
                            dispose() {
                                for (let e of a) e.dispose();
                                a.length = 0
                            }
                        }
                    }(a, h),
                    S = new o.YJl;
                S.name = "actors", t.add(S);
                let k = {
                        quality: u,
                        reducedMotion: d,
                        doc: a,
                        fonts: h,
                        charm: y ? "paws" : "hearts"
                    },
                    C = {
                        a: (0, i.G)(p.people[0], { ...k,
                            handSide: "right"
                        }),
                        b: (0, i.G)(p.people[1], { ...k,
                            handSide: "left"
                        }),
                        pet: "None" !== p.pet.kind ? (0, i._)(p.pet, k) : null
                    };
                S.add(C.a.object, C.b.object), C.pet && S.add(C.pet.object);
                let M = !1,
                    z = {
                        camera() {},
                        place() {}
                    },
                    T = () => {},
                    P = () => {},
                    B = y ? {
                        a: "walk",
                        b: "walk"
                    } : {
                        a: "holdHandsWalk",
                        b: "holdHandsWalk"
                    },
                    A = [null, null],
                    H = () => ({
                        toName: p.toName,
                        fromName: p.fromName,
                        decor1: p.decor1,
                        decor2: p.decor2,
                        decor1Photo: A[0],
                        decor2Photo: A[1],
                        finaleLine: p.finaleLine,
                        accent: p.accent,
                        voice: p.voice ? ? ""
                    }),
                    R = {
                        scene: t,
                        doc: a,
                        quality: u,
                        reducedMotion: d,
                        rand: m,
                        range: (e, t) => e + (t - e) * m(),
                        time: v,
                        px: b,
                        fx: g,
                        photos: w,
                        text: x,
                        actors: C,
                        stage: {
                            hold() {
                                M = !0
                            },
                            release() {
                                M = !1
                            },
                            camera(e, t = 1.6) {
                                z.camera(e, t)
                            },
                            place(e) {
                                z.place(e)
                            },
                            setWalkClips(e) {
                                e.a && (B.a = e.a), e.b && (B.b = e.b)
                            }
                        },
                        values: H(),
                        mood: p.mood,
                        sfx: e => T(e),
                        attachSound: e => P(e)
                    };
                return {
                    ctx: R,
                    actorsRoot: S,
                    photos: w,
                    text: x,
                    held: () => M,
                    walkClips: () => B,
                    setHooks(e) {
                        z = e
                    },
                    setSfx(e) {
                        T = e
                    },
                    setSoundSink(e) {
                        P = e
                    },
                    setValues(e, t) {
                        let a = p;
                        if (p = e, f(a.people[0], e.people[0]) || C.a.setConfig(e.people[0]), f(a.people[1], e.people[1]) || C.b.setConfig(e.people[1]), !f(a.pet, e.pet)) {
                            let t = "None" !== e.pet.kind;
                            if (C.pet && (!t || a.pet.kind !== e.pet.kind) && (S.remove(C.pet.object), C.pet.dispose(), C.pet = null), t && !C.pet) {
                                C.pet = (0, i._)(e.pet, k);
                                let t = C.a.object.position;
                                C.pet.object.position.set(t.x + .6, 0, t.z + .4), S.add(C.pet.object)
                            } else C.pet && C.pet.setConfig(e.pet)
                        }
                        f(a.memoryPhotos, e.memoryPhotos) && f(a.memoryCaptions, e.memoryCaptions) || w.setSources(e.memoryPhotos, e.memoryCaptions), A = [w.decorTexture(0, e.decor1Photo, t), w.decorTexture(1, e.decor2Photo, t)];
                        let o = a.toName !== e.toName || a.fromName !== e.fromName || a.decor1 !== e.decor1 || a.decor2 !== e.decor2 || a.decor1Photo !== e.decor1Photo || a.decor2Photo !== e.decor2Photo || a.finaleLine !== e.finaleLine || a.accent !== e.accent || a.voice !== e.voice;
                        return R.values = H(), R.mood = e.mood, {
                            mood: a.mood !== e.mood,
                            scene: o
                        }
                    },
                    sceneValues: H,
                    dispose() {
                        C.a.dispose(), C.b.dispose(), C.pet ? .dispose(), t.remove(S), w.dispose(), x.dispose(), g.dispose()
                    }
                }
            }
        },
        22408: (e, t, a) => {
            a.d(t, {
                A: () => o
            });

            function o(e, t = .28) {
                let a = Math.cos(e.facing) * t,
                    i = -Math.sin(e.facing) * t,
                    n = .3 * Math.sin(e.facing),
                    l = .3 * Math.cos(e.facing);
                return {
                    a: [e.x + a, e.z + i],
                    b: [e.x - a, e.z - i],
                    pet: [e.x - 3.2 * a + n, e.z - 3.2 * i + l]
                }
            }
        },
        28208: (e, t, a) => {
            a.d(t, {
                An: () => h,
                C7: () => l,
                Cl: () => d,
                Co: () => f,
                D1: () => s,
                EB: () => c,
                Lb: () => i,
                bW: () => r,
                gM: () => g,
                og: () => y,
                tY: () => u,
                us: () => x,
                x6: () => n
            });
            var o = a(36744);
            let i = {
                    Classic: {
                        chest: .155,
                        waist: .141,
                        hips: .151,
                        body: 1,
                        head: 1,
                        face: {
                            width: 1,
                            length: 1,
                            chin: 0
                        }
                    },
                    Slim: {
                        chest: .152,
                        waist: .124,
                        hips: .148,
                        body: 1.02,
                        head: .9,
                        face: {
                            width: .95,
                            length: 1.04,
                            chin: .2
                        }
                    },
                    Curvy: {
                        chest: .16,
                        waist: .124,
                        hips: .164,
                        body: 1.02,
                        head: .9,
                        face: {
                            width: .96,
                            length: 1.03,
                            chin: .18
                        }
                    },
                    Athletic: {
                        chest: .163,
                        waist: .135,
                        hips: .138,
                        body: 1.16,
                        head: .8,
                        face: {
                            width: .86,
                            length: 1.12,
                            chin: .34
                        }
                    },
                    Broad: {
                        chest: .165,
                        waist: .15,
                        hips: .162,
                        body: 1.03,
                        head: .9,
                        face: {
                            width: 1,
                            length: 1.02,
                            chin: .12
                        }
                    }
                },
                n = {
                    Classic: {
                        chest: .172,
                        waist: .152,
                        hips: .146,
                        body: 1.12,
                        head: .84,
                        shoulder: .024,
                        face: {
                            width: .92,
                            length: 1.08,
                            chin: .14
                        }
                    },
                    Slim: {
                        chest: .164,
                        waist: .142,
                        hips: .138,
                        body: 1.14,
                        head: .82,
                        shoulder: .018,
                        face: {
                            width: .88,
                            length: 1.1,
                            chin: .18
                        }
                    },
                    Curvy: {
                        chest: .176,
                        waist: .16,
                        hips: .152,
                        body: 1.12,
                        head: .84,
                        shoulder: .026,
                        face: {
                            width: .94,
                            length: 1.07,
                            chin: .12
                        }
                    },
                    Athletic: {
                        chest: .184,
                        waist: .146,
                        hips: .14,
                        body: 1.17,
                        head: .8,
                        shoulder: .034,
                        face: {
                            width: .9,
                            length: 1.1,
                            chin: .16
                        }
                    },
                    Broad: {
                        chest: .19,
                        waist: .17,
                        hips: .158,
                        body: 1.15,
                        head: .82,
                        shoulder: .04,
                        face: {
                            width: .96,
                            length: 1.06,
                            chin: .08
                        }
                    }
                },
                l = {
                    Porcelain: "#fde3d6",
                    Ivory: "#f6d3bc",
                    Sand: "#ecc3a2",
                    Honey: "#e0ad88",
                    Caramel: "#c99470",
                    Almond: "#ac7856",
                    Cocoa: "#8a5c42",
                    Espresso: "#61402f"
                },
                r = {
                    Black: "#2a2026",
                    "Dark brown": "#3f2a22",
                    Brown: "#62402a",
                    Chestnut: "#7e4126",
                    Auburn: "#9a3f2a",
                    Honey: "#c9904f",
                    Grey: "#aaa6b0",
                    Pink: "#f39ac2"
                },
                s = {
                    Rose: "#f490b2",
                    Red: "#dc4a4f",
                    Coral: "#ff8668",
                    Mustard: "#e6b23e",
                    Mint: "#93d9b8",
                    Teal: "#2fa69b",
                    Sky: "#6aa8ea",
                    Navy: "#33406a",
                    Lilac: "#bba2e2",
                    Plum: "#83406f",
                    White: "#f6f3ee",
                    Black: "#2d2933"
                },
                c = {
                    White: "#f5f2ec",
                    Black: "#2d2933",
                    Brown: "#80502f",
                    Red: "#dc4a4f",
                    Pink: "#f49cc2",
                    Blue: "#4c7bd4"
                },
                f = {
                    Short: 0,
                    "Side part": 3,
                    Curly: 2,
                    Bun: 1,
                    Ponytail: 2,
                    "Long straight": 1,
                    "Long wavy": 1,
                    Braid: 1,
                    "Buzz cut": 0,
                    Quiff: 3
                },
                u = {
                    Short: 1.29,
                    "Side part": 1.3,
                    Curly: 1.31,
                    Bun: 1.35,
                    Ponytail: 1.29,
                    "Long straight": 1.28,
                    "Long wavy": 1.29,
                    Braid: 1.28,
                    "Buzz cut": 1.27,
                    Quiff: 1.32
                },
                d = {
                    Tee: {
                        hem: .425,
                        sleeve: .085,
                        tunic: !1,
                        flare: 0,
                        neck: "crew",
                        hidesBottom: !1
                    },
                    Shirt: {
                        hem: .42,
                        sleeve: .13,
                        tunic: !1,
                        flare: 0,
                        neck: "collar",
                        hidesBottom: !1
                    },
                    Kurta: {
                        hem: .205,
                        sleeve: .29,
                        tunic: !0,
                        flare: .205,
                        neck: "band",
                        hidesBottom: !1
                    },
                    Hoodie: {
                        hem: .405,
                        sleeve: .285,
                        tunic: !1,
                        flare: 0,
                        neck: "hood",
                        hidesBottom: !1
                    },
                    Dress: {
                        hem: .225,
                        sleeve: .045,
                        tunic: !0,
                        flare: .245,
                        neck: "scoop",
                        hidesBottom: !0
                    },
                    Kurti: {
                        hem: .285,
                        sleeve: .2,
                        tunic: !0,
                        flare: .215,
                        neck: "v",
                        hidesBottom: !1
                    },
                    "Short dress": {
                        hem: .3,
                        sleeve: 0,
                        tunic: !0,
                        flare: .235,
                        neck: "scoop",
                        hidesBottom: !0
                    },
                    "Maxi dress": {
                        hem: .045,
                        sleeve: .045,
                        tunic: !0,
                        flare: .3,
                        neck: "v",
                        hidesBottom: !0
                    },
                    "Crop top": {
                        hem: .5,
                        sleeve: .06,
                        tunic: !1,
                        flare: 0,
                        neck: "scoop",
                        hidesBottom: !1
                    },
                    Sweater: {
                        hem: .41,
                        sleeve: .29,
                        tunic: !1,
                        flare: 0,
                        neck: "crew",
                        hidesBottom: !1
                    },
                    Saree: {
                        hem: .04,
                        sleeve: .07,
                        tunic: !0,
                        flare: .27,
                        neck: "scoop",
                        hidesBottom: !0
                    },
                    Anarkali: {
                        hem: .075,
                        sleeve: .29,
                        tunic: !0,
                        flare: .31,
                        neck: "v",
                        hidesBottom: !0
                    },
                    Sherwani: {
                        hem: .2,
                        sleeve: .29,
                        tunic: !0,
                        flare: .205,
                        neck: "band",
                        hidesBottom: !1
                    },
                    "Nehru jacket": {
                        hem: .205,
                        sleeve: .29,
                        tunic: !0,
                        flare: .205,
                        neck: "band",
                        hidesBottom: !1
                    }
                },
                h = {
                    Jeans: {
                        legs: "full",
                        skirtHem: 0,
                        skirtFlare: 0,
                        pleats: 0,
                        border: !1,
                        loose: 0,
                        cuff: !0,
                        belt: !1
                    },
                    Trousers: {
                        legs: "full",
                        skirtHem: 0,
                        skirtFlare: 0,
                        pleats: 0,
                        border: !1,
                        loose: .007,
                        cuff: !1,
                        belt: !0
                    },
                    Skirt: {
                        legs: "bare",
                        skirtHem: .235,
                        skirtFlare: .215,
                        pleats: 7,
                        border: !1,
                        loose: 0,
                        cuff: !1,
                        belt: !1
                    },
                    Shorts: {
                        legs: "shorts",
                        skirtHem: 0,
                        skirtFlare: 0,
                        pleats: 0,
                        border: !1,
                        loose: .006,
                        cuff: !1,
                        belt: !1
                    },
                    Lehenga: {
                        legs: "bare",
                        skirtHem: .035,
                        skirtFlare: .33,
                        pleats: 9,
                        border: !0,
                        loose: 0,
                        cuff: !1,
                        belt: !1
                    },
                    "Mini skirt": {
                        legs: "bare",
                        skirtHem: .32,
                        skirtFlare: .19,
                        pleats: 6,
                        border: !1,
                        loose: 0,
                        cuff: !1,
                        belt: !1
                    }
                };

            function p(e, t, a, o) {
                return "string" == typeof t && Object.prototype.hasOwnProperty.call(e, t) ? t : Object.prototype.hasOwnProperty.call(e, a) ? a : o
            }
            let m = {
                    None: !0,
                    Glasses: !0,
                    Bindi: !0,
                    Earrings: !0,
                    Cap: !0,
                    "Flower in hair": !0,
                    Scarf: !0,
                    Dupatta: !0
                },
                v = {
                    Female: !0,
                    Male: !0
                },
                b = {
                    None: !0,
                    Stubble: !0,
                    Moustache: !0,
                    Beard: !0
                };

            function g(e, t = "a") {
                let a = "b" === t ? o.f_ : o._v,
                    n = e && "object" == typeof e ? e : {};
                return {
                    skin: p(l, n.skin, a.skin, "Honey"),
                    hairStyle: p(u, n.hairStyle, a.hairStyle, "Short"),
                    hairColor: p(r, n.hairColor, a.hairColor, "Black"),
                    top: p(d, n.top, a.top, "Tee"),
                    topColor: p(s, n.topColor, a.topColor, "Rose"),
                    bottom: p(h, n.bottom, a.bottom, "Jeans"),
                    bottomColor: p(s, n.bottomColor, a.bottomColor, "Navy"),
                    shoes: p(c, n.shoes, a.shoes, "White"),
                    accessory: p(m, n.accessory, a.accessory, "None"),
                    build: p(i, n.build, a.build, "Classic"),
                    gender: p(v, n.gender, a.gender, "Female"),
                    facialHair: p(b, n.facialHair, a.facialHair, "None")
                }
            }
            let y = {
                    Cat: {
                        "Orange tabby": {
                            base: "#f0a056",
                            accent: "#c8682e",
                            third: "#f7b3b8",
                            belly: "#fbe9d2",
                            pattern: "tabby",
                            ears: "cat",
                            tail: "cat",
                            eye: "green",
                            nose: "#f08e9a",
                            size: 1,
                            muzzle: 0
                        },
                        Black: {
                            base: "#34303a",
                            accent: "#24212a",
                            third: "#e88fa0",
                            belly: "#3c3843",
                            pattern: "solid",
                            ears: "cat",
                            tail: "cat",
                            eye: "amber",
                            nose: "#5a4650",
                            size: 1,
                            muzzle: 0
                        },
                        White: {
                            base: "#faf7f2",
                            accent: "#ece6dc",
                            third: "#f7aab5",
                            belly: "#ffffff",
                            pattern: "solid",
                            ears: "cat",
                            tail: "cat",
                            eye: "blue",
                            nose: "#f4a0ac",
                            size: 1,
                            muzzle: 0
                        },
                        Calico: {
                            base: "#fbf5ec",
                            accent: "#ec9a4e",
                            third: "#3b3438",
                            belly: "#ffffff",
                            pattern: "calico",
                            ears: "cat",
                            tail: "cat",
                            eye: "amber",
                            nose: "#f08e9a",
                            size: 1,
                            muzzle: 0
                        },
                        Siamese: {
                            base: "#f2e6d0",
                            accent: "#5a4034",
                            third: "#d9a7a0",
                            belly: "#f8f0e2",
                            pattern: "points",
                            ears: "cat",
                            tail: "cat",
                            eye: "blue",
                            nose: "#4a3530",
                            size: 1,
                            muzzle: 0
                        }
                    },
                    Dog: {
                        Shiba: {
                            base: "#dc8749",
                            accent: "#fbecd6",
                            third: "#f2b49c",
                            belly: "#fbecd6",
                            pattern: "urajiro",
                            ears: "pointy",
                            tail: "curl",
                            eye: "dark",
                            nose: "#2d2428",
                            size: 1,
                            muzzle: .075
                        },
                        Labrador: {
                            base: "#ecc985",
                            accent: "#d9ae68",
                            third: "#d99a86",
                            belly: "#f5dfae",
                            pattern: "solid",
                            ears: "floppy",
                            tail: "otter",
                            eye: "dark",
                            nose: "#4a3430",
                            size: 1.1,
                            muzzle: .09
                        },
                        Pug: {
                            base: "#dfc59c",
                            accent: "#3a312e",
                            third: "#3a312e",
                            belly: "#e8d3b0",
                            pattern: "mask",
                            ears: "folded",
                            tail: "corkscrew",
                            eye: "dark",
                            nose: "#2a2224",
                            size: .94,
                            muzzle: .02
                        },
                        Indie: {
                            base: "#c98d55",
                            accent: "#fbf1e2",
                            third: "#e6a58f",
                            belly: "#efd2ae",
                            pattern: "blaze",
                            ears: "pointy",
                            tail: "sickle",
                            eye: "dark",
                            nose: "#33282a",
                            size: 1.04,
                            muzzle: .085
                        }
                    },
                    Bunny: {
                        White: {
                            base: "#fbf8f3",
                            accent: "#f2ebe2",
                            third: "#f8b4c0",
                            belly: "#ffffff",
                            pattern: "solid",
                            ears: "long",
                            tail: "puff",
                            eye: "dark",
                            nose: "#f39aab",
                            size: 1,
                            muzzle: 0
                        },
                        Brown: {
                            base: "#ad8058",
                            accent: "#8a6243",
                            third: "#e8b0a8",
                            belly: "#f3e2cc",
                            pattern: "solid",
                            ears: "long",
                            tail: "puff",
                            eye: "dark",
                            nose: "#d98c92",
                            size: 1,
                            muzzle: 0
                        }
                    }
                },
                w = {
                    Cat: !0,
                    Dog: !0,
                    Bunny: !0
                };

            function x(e) {
                let t = e && "object" == typeof e ? e : {},
                    a = Object.prototype.hasOwnProperty.call(w, o.Qj.kind) ? o.Qj.kind : "Cat",
                    i = "string" == typeof t.kind && Object.prototype.hasOwnProperty.call(w, t.kind) ? t.kind : a,
                    n = o.Nw[i],
                    l = y[i],
                    r = n[0] ? ? Object.keys(l)[0] ? ? "",
                    s = "string" == typeof t.coat && Object.prototype.hasOwnProperty.call(l, t.coat) ? t.coat : i === o.Qj.kind && l[o.Qj.coat] ? o.Qj.coat : r,
                    c = l[s] ? ? l[r] ? ? Object.values(l)[0];
                return {
                    kind: i,
                    coat: s,
                    name: "string" == typeof t.name ? t.name.slice(0, 16) : o.Qj.name,
                    spec: c
                }
            }
        }
    }
]);