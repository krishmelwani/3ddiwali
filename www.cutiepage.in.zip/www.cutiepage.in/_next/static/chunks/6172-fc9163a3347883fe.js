(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6172, 65421, 87802], {
        2418: (e, t, n) => {
            "use strict";
            n.d(t, {
                QE: () => c,
                ll: () => s,
                mY: () => l
            });
            var a = n(73365),
                r = n(1521);
            let i = (0, r.createContext)(!1);

            function s({
                enabled: e,
                children: t
            }) {
                return (0, a.jsx)(i.Provider, {
                    value: e,
                    children: t
                })
            }

            function l() {
                return (0, r.useContext)(i)
            }

            function c(e, t) {
                return "published" === e && t
            }
        },
        17082: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                INVITE_GUEST_ENDPOINT: () => c,
                InviteeNameProvider: () => l,
                resolveInviteeName: () => d,
                useInviteeName: () => p
            });
            var a = n(73365),
                r = n(1521),
                i = n(93510);
            let s = (0, r.createContext)(null);

            function l({
                name: e,
                children: t
            }) {
                return (0, a.jsx)(s.Provider, {
                    value: (0, i.fP)(e),
                    children: t
                })
            }
            let c = "/api/invites/guest",
                u = "cp_invitee_v1:",
                o = new Map;

            function d(e) {
                let t = function(e) {
                    try {
                        let t = window.sessionStorage.getItem(u + e);
                        if (null === t) return;
                        return (0, i.fP)(t)
                    } catch {
                        return
                    }
                }(e);
                if (void 0 !== t) return Promise.resolve(t);
                let n = o.get(e);
                if (!n) {
                    let t = new URL(window.location.href);
                    t.search = "", t.hash = "";
                    let a = new URLSearchParams({
                        page: t.toString(),
                        g: e
                    });
                    n = fetch(`${c}?${a.toString()}`, {
                        cache: "no-store"
                    }).then(async t => {
                        if (!t.ok) return null;
                        let n = await t.json().catch(() => null),
                            a = "string" == typeof n ? .data ? .name ? (0, i.fP)(n.data.name) : null;
                        return a && function(e, t) {
                            try {
                                window.sessionStorage.setItem(u + e, t)
                            } catch {}
                        }(e, a), a
                    }).catch(() => null), o.set(e, n)
                }
                return n
            }

            function p(e) {
                let t = (0, r.useContext)(s),
                    [n, a] = (0, r.useState)(null);
                return (0, r.useEffect)(() => {
                    if (t) return;
                    let e = (0, i.xU)(window.location.search);
                    if (!e) return;
                    let n = !1;
                    return d(e).then(e => {
                        n || a(e)
                    }), () => {
                        n = !0
                    }
                }, [t]), t || n || e
            }
        },
        33381: () => {},
        87802: (e, t, n) => {
            "use strict";

            function a(e, t, n, r = 120) {
                return {
                    id: e,
                    label: t,
                    type: "text",
                    default: n,
                    maxLength: r
                }
            }

            function r(e, t, n, a = 600) {
                return {
                    id: e,
                    label: t,
                    type: "textarea",
                    default: n,
                    maxLength: a
                }
            }

            function i(e, t, n) {
                return {
                    id: e,
                    label: t,
                    type: "image",
                    default: n
                }
            }

            function s(e, t, n) {
                return {
                    id: e,
                    label: t,
                    type: "link",
                    default: n
                }
            }

            function l(e, t, n) {
                return {
                    id: e,
                    label: t,
                    type: "audio",
                    default: n
                }
            }

            function c(e, t, n) {
                return {
                    id: e,
                    label: t,
                    type: "boolean",
                    default: n
                }
            }

            function u(e, t = 1600) {
                return `https://images.unsplash.com/photo-${e}?auto=format&fit=crop&w=${t}&q=80`
            }
            n.d(t, {
                Jt: () => c,
                PC: () => r,
                Qq: () => a,
                Sl: () => i,
                nf: () => s,
                pM: () => u,
                z7: () => l
            })
        },
        92407: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                BeatTapper: () => g,
                DANCE_MOVES: () => x,
                DODGE_OFFSETS: () => S,
                DanceFloor: () => $,
                DecorImage: () => f,
                DiyaLighter: () => v,
                PartySizeStepper: () => E,
                RsvpChoice: () => k,
                StampRsvp: () => M,
                WHATSAPP_PREFIX: () => L,
                WarmImages: () => h,
                WhatsAppReply: () => _,
                danceBeatEffect: () => b,
                danceHeat: () => y,
                danceMoveFor: () => j,
                dancePeak: () => w,
                danceSwapped: () => N,
                rsvpMemoryKey: () => I,
                stampRsvpStep: () => C,
                useInviteRsvp: () => R,
                whatsappHref: () => T,
                whatsappMessage: () => P
            });
            var a = n(73365),
                r = n(1521),
                i = n(87191),
                s = n(34768),
                l = n(82161),
                c = n(19071),
                u = n(93510);
            c.Ik({
                pageUrl: c.Yj().trim().url().max(2048),
                response: c.k5(["yes", "no"]),
                guestCode: c.Yj().regex(u.L$).nullable(),
                deviceId: c.Yj().regex(/^[A-Za-z0-9_-]{8,64}$/),
                partySize: c.ai().int().min(1).max(20).optional(),
                events: c.YO(c.Yj().regex(/^[a-z0-9_-]{1,40}$/)).min(1).max(8).refine(e => new Set(e).size === e.length).optional()
            });
            let o = "cp_rsvp_device_v1";
            async function d(e, t, n) {
                try {
                    let a = new URL(window.location.href),
                        r = (0, u.xU)(a.search);
                    a.search = "", a.hash = "";
                    let i = {
                        pageUrl: a.toString(),
                        response: e,
                        guestCode: r,
                        deviceId: function() {
                            let e = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), e => e.toString(16).padStart(2, "0")).join("");
                            try {
                                let t = window.localStorage.getItem(o);
                                if (t && /^[A-Za-z0-9_-]{8,64}$/.test(t)) return t;
                                let n = e();
                                return window.localStorage.setItem(o, n), n
                            } catch {
                                return e()
                            }
                        }(),
                        ..."yes" === e && t ? {
                            partySize: t
                        } : {},
                        ..."yes" === e && n && n.length > 0 ? {
                            events: [...n]
                        } : {}
                    };
                    return (await fetch("/api/invites/rsvp", {
                        method: "POST",
                        headers: {
                            "content-type": "application/json"
                        },
                        body: JSON.stringify(i),
                        keepalive: !0
                    })).ok
                } catch {
                    return !1
                }
            }
            var p = n(2418),
                m = n(17082);

            function f({
                src: e,
                width: t,
                height: n,
                priority: r = !1,
                className: i,
                style: s
            }) {
                return (0, a.jsx)("img", {
                    src: e,
                    alt: "",
                    "aria-hidden": !0,
                    width: t,
                    height: n,
                    loading: r ? "eager" : "lazy",
                    fetchPriority: r ? "high" : void 0,
                    decoding: "async",
                    draggable: !1,
                    className: i,
                    style: s
                })
            }

            function h({
                srcs: e,
                delay: t = 1200
            }) {
                let n = (0, s.useMode)(),
                    a = e.join(" ");
                return (0, r.useEffect)(() => {
                    if ("edit" === n || !a) return;
                    let e = setTimeout(() => {
                        for (let e of a.split(" ")) {
                            let t = new Image;
                            t.decoding = "async", t.src = e
                        }
                    }, t);
                    return () => clearTimeout(e)
                }, [n, a, t]), null
            }

            function v({
                lamps: e,
                lamp: t,
                center: n,
                backdrop: c,
                hint: u,
                done: o,
                label: d,
                className: p,
                stageClassName: m,
                lightEffect: f,
                doneEffect: h
            }) {
                let g = "edit" === (0, s.useMode)(),
                    x = (0, l.useSoundEffect)(),
                    [j, N] = (0, r.useState)(() => e.map(() => !1)),
                    y = (0, r.useRef)(null),
                    b = (0, r.useRef)(null);
                (0, r.useEffect)(() => () => {
                    b.current && clearTimeout(b.current)
                }, []), (0, i.useReplaySignal)(y, () => N(e.map(() => !1)));
                let w = e.length,
                    $ = g ? w : j.filter(Boolean).length,
                    S = $ >= w;
                return (0, a.jsxs)("div", {
                    ref: y,
                    className: `cpi-lamps${p?` ${p}`:""}`,
                    style: {
                        "--lit": String(Math.round($ / Math.max(1, w) * 1e3) / 1e3)
                    },
                    "data-count": $,
                    ...S ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsxs)("div", {
                        className: `cpi-lamps-stage${m?` ${m}`:""}`,
                        children: [c, n ? (0, a.jsx)("div", {
                            className: "cpi-lamps-center",
                            children: n
                        }) : null, e.map((e, n) => {
                            let r = g || !0 === j[n];
                            return (0, a.jsx)("button", {
                                type: "button",
                                className: "cpi-lamp",
                                style: {
                                    left: `${e.x}%`,
                                    top: `${e.y}%`,
                                    "--ring-delay": `${.24*n}s`
                                },
                                onClick: () => (e => {
                                    if (g || j[e]) return;
                                    let t = j.map((t, n) => t || n === e);
                                    N(t), f ? x(f) : x("jingle"), t.every(Boolean) && (b.current && clearTimeout(b.current), b.current = setTimeout(() => h ? x(h) : x("fanfare"), 260))
                                })(n),
                                "aria-label": `${d} ${n+1}`,
                                "aria-pressed": r,
                                tabIndex: g ? -1 : void 0,
                                ...r ? {
                                    "data-lit": ""
                                } : {},
                                children: t
                            }, n)
                        }), !g && S ? (0, a.jsx)(i.ConfettiBurst, {
                            seed: 23,
                            count: 34,
                            top: "42%"
                        }) : null]
                    }), (0, a.jsx)("div", {
                        className: "cpi-lamps-after",
                        "aria-live": "polite",
                        children: g ? (0, a.jsxs)(a.Fragment, {
                            children: [u, o]
                        }) : S ? (0, a.jsx)("div", {
                            className: "cpi-rise-in",
                            children: o
                        }) : u
                    })]
                })
            }

            function g({
                stage: e,
                hint: t,
                done: n,
                beats: c = 4,
                label: u,
                className: o,
                beatEffect: d,
                doneEffect: p
            }) {
                let m = "edit" === (0, s.useMode)(),
                    f = (0, l.useSoundEffect)(),
                    [h, v] = (0, r.useState)(0),
                    x = (0, r.useRef)(null),
                    j = (0, r.useRef)(null);
                (0, r.useEffect)(() => () => {
                    j.current && clearTimeout(j.current)
                }, []), (0, i.useReplaySignal)(x, () => v(0));
                let N = h >= c;
                return (0, a.jsxs)("div", {
                    ref: x,
                    className: `cpi-beat${o?` ${o}`:""}`,
                    "data-count": h,
                    ...!m && h > 0 ? {
                        "data-beat": h % 2 == 1 ? "a" : "b"
                    } : {},
                    ...N ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsxs)("button", {
                        type: "button",
                        className: "cpi-beat-stage",
                        onClick: () => {
                            if (m || N) return;
                            let e = h + 1;
                            v(e), d ? f(d(e)) : f("clack"), e >= c && (j.current && clearTimeout(j.current), j.current = setTimeout(() => p ? f(p) : f("fanfare"), 160))
                        },
                        "aria-label": u,
                        tabIndex: m ? -1 : void 0,
                        disabled: !m && N,
                        children: [e, !m && N ? (0, a.jsx)(i.ConfettiBurst, {
                            seed: 9,
                            count: 28,
                            top: "50%"
                        }) : null]
                    }), (0, a.jsx)("ol", {
                        className: "cpi-beat-dots",
                        "aria-label": `${Math.min(h,c)} of ${c}`,
                        children: Array.from({
                            length: c
                        }, (e, t) => (0, a.jsx)("li", { ...t < h ? {
                                "data-on": ""
                            } : {}
                        }, t))
                    }), (0, a.jsx)("div", {
                        className: "cpi-beat-after",
                        "aria-live": "polite",
                        children: m ? (0, a.jsxs)(a.Fragment, {
                            children: [t, n]
                        }) : N ? (0, a.jsx)("div", {
                            className: "cpi-rise-in",
                            children: n
                        }) : t
                    })]
                })
            }
            n(33381);
            let x = ["hop", "sway", "clap", "spin", "hop", "swap", "dip", "twirl"];

            function j(e, t = x) {
                return e < 1 || 0 === t.length ? null : t[(e - 1) % t.length]
            }

            function N(e, t = x) {
                if (e < 1 || 0 === t.length) return !1;
                let n = t.filter(e => "swap" === e).length,
                    a = Math.floor(e / t.length) * n;
                for (let n = 0; n < e % t.length; n += 1) "swap" === t[n] && (a += 1);
                return a % 2 == 1
            }

            function y(e, t) {
                return t < 1 ? 4 : Math.min(4, Math.floor(Math.min(Math.max(e, 0), t) / t * 4))
            }

            function b(e) {
                return e % 2 == 1 ? "dhol" : "dhamak"
            }

            function w(e) {
                return e > 0 && e % 4 == 0
            }

            function $({
                dancers: e,
                floor: t,
                burst: n,
                meterLabel: c,
                button: u,
                again: o,
                done: d,
                goal: p = 8,
                label: m,
                className: f,
                stageClassName: h,
                buttonClassName: v,
                moves: g = x,
                beatEffect: S,
                peakEffect: k,
                goalEffect: C
            }) {
                let I = "edit" === (0, s.useMode)(),
                    R = (0, l.useSoundEffect)(),
                    [M, E] = (0, r.useState)(0),
                    T = (0, r.useRef)(null),
                    L = (0, r.useRef)(null);
                (0, r.useEffect)(() => () => {
                    L.current && clearTimeout(L.current)
                }, []), (0, i.useReplaySignal)(T, () => E(0));
                let P = I ? p : M,
                    _ = !I && M >= p,
                    U = I ? null : j(M, g),
                    z = !I && w(M),
                    A = Math.round(Math.min(P, p) / Math.max(1, p) * 1e3) / 1e3;
                return (0, a.jsxs)("div", {
                    ref: T,
                    className: `cpi-dancefloor${f?` ${f}`:""}`,
                    style: {
                        "--energy": String(A)
                    },
                    "data-taps": M,
                    "data-heat": y(P, p),
                    ...U ? {
                        "data-move": U,
                        "data-beat": M % 2 == 1 ? "a" : "b"
                    } : {},
                    ...!I && N(M, g) ? {
                        "data-swapped": ""
                    } : {},
                    ...z ? {
                        "data-peak": ""
                    } : {},
                    ..._ ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsxs)("div", {
                        className: `cpi-dancefloor-stage${h?` ${h}`:""}`,
                        children: [t, (0, a.jsx)("span", {
                            "aria-hidden": !0,
                            className: "cpi-dancefloor-flash"
                        }), e.map((e, t) => (0, a.jsxs)("div", {
                            className: "cpi-dancer",
                            "data-side": 0 === t ? "left" : "right",
                            style: {
                                "--dir": 0 === t ? "1" : "-1"
                            },
                            children: [(0, a.jsx)("span", {
                                "aria-hidden": !0,
                                className: "cpi-dancer-shadow"
                            }), (0, a.jsx)("div", {
                                className: "cpi-dancer-move",
                                children: (0, a.jsx)("div", {
                                    className: "cpi-dancer-turn",
                                    children: (0, a.jsx)("div", {
                                        className: "cpi-dancer-groove",
                                        children: e
                                    })
                                })
                            })]
                        }, t)), !I && M > 0 ? (0, a.jsx)("span", {
                            "aria-hidden": !0,
                            className: "cpi-dancefloor-burst",
                            children: n
                        }, M) : null, z ? (0, a.jsx)(i.ConfettiBurst, {
                            seed: M === p ? 41 : 13,
                            count: M === p ? 44 : 18,
                            top: "34%"
                        }, `peak-${M}`) : null]
                    }), (0, a.jsxs)("div", {
                        className: "cpi-dancefloor-meter",
                        role: "meter",
                        "aria-label": m,
                        "aria-valuemin": 0,
                        "aria-valuemax": p,
                        "aria-valuenow": Math.min(P, p),
                        children: [c ? (0, a.jsx)("span", {
                            className: "cpi-dancefloor-meter-label",
                            children: c
                        }) : null, (0, a.jsx)("ol", {
                            "aria-hidden": !0,
                            children: Array.from({
                                length: p
                            }, (e, t) => (0, a.jsx)("li", {
                                style: {
                                    "--bar": String(Math.round((t + 1) / p * 100) / 100)
                                },
                                ...t < P ? {
                                    "data-on": ""
                                } : {},
                                ...!I && t === M - 1 ? {
                                    "data-new": ""
                                } : {}
                            }, t))
                        })]
                    }), I ? (0, a.jsxs)("div", {
                        className: "cpi-dancefloor-buttons",
                        children: [(0, a.jsx)("span", {
                            className: `cpi-dancefloor-button${v?` ${v}`:""}`,
                            children: u
                        }), (0, a.jsx)("span", {
                            className: `cpi-dancefloor-button${v?` ${v}`:""}`,
                            children: o
                        })]
                    }) : (0, a.jsx)("button", {
                        type: "button",
                        className: `cpi-dancefloor-button${v?` ${v}`:""}`,
                        onClick: () => {
                            if (I) return;
                            let e = M + 1;
                            E(e), S ? R(S(e)) : R(b(e)), L.current && clearTimeout(L.current), e === p ? L.current = setTimeout(() => C ? R(C) : R("fanfare"), 200) : w(e) && (L.current = setTimeout(() => k ? R(k) : R("jingle"), 140))
                        },
                        children: 0 === M ? u : o
                    }), (0, a.jsx)("div", {
                        className: "cpi-dancefloor-after",
                        "aria-live": "polite",
                        children: I ? d : _ ? (0, a.jsx)("div", {
                            className: "cpi-rise-in",
                            children: d
                        }) : null
                    })]
                })
            }
            let S = [
                [-24, 76],
                [-150, 138],
                [-56, 196]
            ];

            function k({
                question: e,
                yes: t,
                maybe: n,
                giveIn: c,
                replies: u,
                answered: o,
                className: d
            }) {
                let p = "edit" === (0, s.useMode)(),
                    m = (0, l.useSoundEffect)(),
                    [f, h] = (0, r.useState)(!1),
                    [v, g] = (0, r.useState)(0),
                    x = (0, r.useRef)(null);
                (0, i.useReplaySignal)(x, () => {
                    h(!1), g(0)
                });
                let j = v >= Math.min(u.length, S.length),
                    N = () => {
                        p || f || (h(!0), m("popper"))
                    },
                    y = () => {
                        if (!p && !f) {
                            if (j) return void N();
                            g(e => e + 1), m("nope")
                        }
                    },
                    b = v > 0 && !j ? S[(v - 1) % S.length] : null,
                    w = b ? {
                        translate: `${b[0]}px ${b[1]}px`
                    } : void 0;
                return p ? (0, a.jsxs)("div", {
                    ref: x,
                    className: `cpi-rsvp${d?` ${d}`:""}`,
                    children: [e, (0, a.jsx)("div", {
                        className: "cpi-rsvp-replies",
                        children: u.map((e, t) => (0, a.jsx)("span", {
                            className: "cpi-rsvp-reply",
                            children: e
                        }, t))
                    }), (0, a.jsxs)("div", {
                        className: "cpi-rsvp-buttons",
                        children: [(0, a.jsx)("span", {
                            className: "cpi-rsvp-yes",
                            children: t
                        }), (0, a.jsx)("span", {
                            className: "cpi-rsvp-maybe",
                            children: n
                        }), (0, a.jsx)("span", {
                            className: "cpi-rsvp-maybe",
                            children: c
                        })]
                    }), (0, a.jsx)("div", {
                        className: "cpi-rsvp-answered",
                        children: o
                    })]
                }) : (0, a.jsx)("div", {
                    ref: x,
                    className: `cpi-rsvp${d?` ${d}`:""}`,
                    ...f ? {
                        "data-said": ""
                    } : {},
                    children: f ? (0, a.jsxs)("div", {
                        className: "cpi-rsvp-answered cpi-rise-in",
                        children: [(0, a.jsx)(i.ConfettiBurst, {
                            seed: 17,
                            count: 40,
                            top: "18%"
                        }), o]
                    }) : (0, a.jsxs)(a.Fragment, {
                        children: [e, (0, a.jsx)("p", {
                            className: "cpi-rsvp-replies",
                            "aria-live": "polite",
                            children: v > 0 ? (0, a.jsx)("span", {
                                className: "cpi-rsvp-reply",
                                children: u[Math.min(v, u.length) - 1]
                            }) : null
                        }), (0, a.jsxs)("div", {
                            className: "cpi-rsvp-buttons",
                            children: [(0, a.jsx)("button", {
                                type: "button",
                                className: "cpi-rsvp-yes",
                                onClick: N,
                                children: t
                            }), (0, a.jsx)("button", {
                                type: "button",
                                className: "cpi-rsvp-maybe",
                                style: w,
                                onClick: y,
                                onPointerEnter: e => {
                                    "mouse" !== e.pointerType || j || y()
                                },
                                children: j ? c : n
                            })]
                        })]
                    })
                })
            }

            function C(e, t) {
                return "stamp" === t ? "stamped" === e ? {
                    state: e,
                    record: null
                } : {
                    state: "stamped",
                    record: "yes"
                } : "decline" === t ? "idle" === e ? {
                    state: "confirming",
                    record: null
                } : {
                    state: e,
                    record: null
                } : "confirming" === e ? {
                    state: "declined",
                    record: "no"
                } : {
                    state: e,
                    record: null
                }
            }

            function I(e) {
                try {
                    let t = new URL(e);
                    return `cp_rsvp_answer_v1:${t.origin}${t.pathname}`
                } catch {
                    return null
                }
            }

            function R(e, t = {}) {
                let n = (0, s.useMode)(),
                    a = "edit" === n,
                    l = (0, p.QE)(n, (0, p.mY)()),
                    [c, u] = (0, r.useState)("idle"),
                    [o, m] = (0, r.useState)(!1),
                    f = (0, r.useRef)(null),
                    h = (0, r.useRef)(c);
                (0, r.useEffect)(() => {
                    h.current = c
                }, [c]);
                let v = (0, r.useRef)(t.partySize ? ? null);
                (0, r.useEffect)(() => {
                    v.current = t.partySize ? ? null
                }, [t.partySize]);
                let g = (0, r.useRef)(t.events ? ? null);
                (0, r.useEffect)(() => {
                    g.current = t.events ? ? null
                }, [t.events]), (0, r.useEffect)(() => {
                    if (!l) return;
                    let e = function() {
                        try {
                            let e = I(window.location.href),
                                t = e ? window.localStorage.getItem(e) : null;
                            return "yes" === t || "no" === t ? t : null
                        } catch {
                            return null
                        }
                    }();
                    if (f.current = e, !e) return;
                    let t = setTimeout(() => {
                        u("yes" === e ? "stamped" : "declined"), m(!0)
                    }, 0);
                    return () => clearTimeout(t)
                }, [l]), (0, i.useReplaySignal)(e, () => {
                    let e = f.current;
                    u("yes" === e ? "stamped" : "no" === e ? "declined" : "idle"), m(null !== e)
                });
                let x = (0, r.useCallback)(e => {
                    if (a) return null;
                    let t = C(h.current, e);
                    if (t.state === h.current) return null;
                    if (h.current = t.state, u(t.state), m(!1), t.record && l) {
                        f.current = t.record;
                        var n = t.record;
                        try {
                            let e = I(window.location.href);
                            e && window.localStorage.setItem(e, n)
                        } catch {}
                        d(t.record, v.current, g.current)
                    }
                    return t.state
                }, [a, l]);
                return {
                    editing: a,
                    state: c,
                    restored: o,
                    act: x
                }
            }

            function M({
                pass: e,
                stamp: t,
                yes: n,
                no: s,
                confirmNote: c,
                sure: u,
                answered: o,
                declined: d,
                changeMind: p,
                stampClassName: m,
                yesClassName: f,
                noClassName: h,
                className: v,
                askPartySize: g = !1,
                partySizeLabel: x,
                events: j,
                picker: N
            }) {
                let y = (0, l.useSoundEffect)(),
                    b = (0, r.useRef)(null),
                    [w, $] = (0, r.useState)(1),
                    {
                        editing: S,
                        state: k,
                        restored: C,
                        act: I
                    } = R(b, { ...g ? {
                            partySize: w
                        } : {},
                        ...j ? {
                            events: j
                        } : {}
                    }),
                    T = (0, a.jsxs)(a.Fragment, {
                        children: [N ? ? null, g ? (0, a.jsx)(E, {
                            value: w,
                            onChange: $,
                            label: x,
                            disabled: S,
                            buttonClassName: h
                        }) : null]
                    }),
                    L = (0, r.useRef)(null);
                (0, r.useEffect)(() => () => {
                    L.current && clearTimeout(L.current)
                }, []);
                let P = e => {
                        let t = I(e);
                        t && (L.current && clearTimeout(L.current), "stamped" === t ? (y("stamp"), L.current = setTimeout(() => y("popper"), 170)) : "confirming" === t ? y("nope") : "declined" === t && y("puff"))
                    },
                    _ = `cpi-stamp-rsvp${v?` ${v}`:""}`,
                    U = (0, a.jsx)("span", {
                        className: `cpi-stamp${m?` ${m}`:""}`,
                        children: t
                    });
                if (S) return (0, a.jsxs)("div", {
                    ref: b,
                    className: _,
                    children: [(0, a.jsxs)("div", {
                        className: "cpi-stamp-target",
                        children: [e, U]
                    }), (0, a.jsx)("div", {
                        className: "cpi-stamp-notes",
                        children: (0, a.jsx)("span", {
                            className: "cpi-stamp-note",
                            children: c
                        })
                    }), T, (0, a.jsxs)("div", {
                        className: "cpi-stamp-buttons",
                        children: [(0, a.jsx)("span", {
                            className: f,
                            children: n
                        }), (0, a.jsx)("span", {
                            className: h,
                            children: s
                        }), (0, a.jsx)("span", {
                            className: h,
                            children: u
                        })]
                    }), (0, a.jsx)("div", {
                        className: "cpi-stamp-answered",
                        children: o
                    }), (0, a.jsxs)("div", {
                        className: "cpi-stamp-answered cpi-stamp-declined",
                        children: [d, (0, a.jsx)("span", {
                            className: h,
                            children: p
                        })]
                    })]
                });
                let z = "stamped" === k,
                    A = C ? "" : " cpi-rise-in";
                return (0, a.jsxs)("div", {
                    ref: b,
                    className: _,
                    "data-state": k,
                    ...z ? {
                        "data-stamped": ""
                    } : {},
                    ...C ? {
                        "data-restored": ""
                    } : {},
                    children: [(0, a.jsxs)("div", {
                        className: "cpi-stamp-target",
                        children: [e, z ? U : null, z && !C ? (0, a.jsx)(i.ConfettiBurst, {
                            seed: 31,
                            count: 38,
                            top: "40%"
                        }) : null]
                    }), z ? (0, a.jsx)("div", {
                        className: `cpi-stamp-answered${A}`,
                        children: o
                    }) : "declined" === k ? (0, a.jsxs)("div", {
                        className: `cpi-stamp-answered cpi-stamp-declined${A}`,
                        children: [d, (0, a.jsx)("button", {
                            type: "button",
                            className: h,
                            onClick: () => P("stamp"),
                            children: p
                        })]
                    }) : (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("p", {
                            className: "cpi-stamp-notes",
                            "aria-live": "polite",
                            children: "confirming" === k ? (0, a.jsx)("span", {
                                className: "cpi-stamp-note cpi-rise-in",
                                children: c
                            }) : null
                        }), T, (0, a.jsxs)("div", {
                            className: "cpi-stamp-buttons",
                            children: [(0, a.jsx)("button", {
                                type: "button",
                                className: f,
                                onClick: () => P("stamp"),
                                children: n
                            }), (0, a.jsx)("button", {
                                type: "button",
                                className: h,
                                onClick: () => P("confirming" === k ? "confirmDecline" : "decline"),
                                children: "confirming" === k ? u : s
                            })]
                        })]
                    })]
                })
            }

            function E({
                value: e,
                onChange: t,
                label: n = "How many of you are coming?",
                disabled: r = !1,
                className: i,
                buttonClassName: s
            }) {
                let l = n => {
                    var a;
                    return t(Number.isFinite(a = e + n) ? Math.min(20, Math.max(1, Math.round(a))) : 1)
                };
                return (0, a.jsxs)("div", {
                    className: `cpi-party-size${i?` ${i}`:""}`,
                    role: "group",
                    "aria-label": "How many people are coming",
                    children: [(0, a.jsx)("span", {
                        className: "cpi-party-size-label",
                        children: n
                    }), (0, a.jsxs)("span", {
                        className: "inline-flex items-center gap-3",
                        children: [(0, a.jsx)("button", {
                            type: "button",
                            className: s,
                            onClick: () => l(-1),
                            disabled: r || e <= 1,
                            "aria-label": "One fewer",
                            children: "\u2212"
                        }), (0, a.jsx)("output", {
                            "aria-live": "polite",
                            className: "min-w-[2ch] text-center tabular-nums",
                            children: e
                        }), (0, a.jsx)("button", {
                            type: "button",
                            className: s,
                            onClick: () => l(1),
                            disabled: r || e >= 20,
                            "aria-label": "One more",
                            children: "+"
                        })]
                    })]
                })
            }

            function T(e, t) {
                let n = e.replace(/\D/g, "");
                if (11 === n.length && n.startsWith("0") && (n = n.slice(1)), 10 === n.length && (n = `91${n}`), n.length < 11 || n.length > 15) return null;
                let a = t.trim();
                return a ? `https://wa.me/${n}?text=${encodeURIComponent(a)}` : `https://wa.me/${n}`
            }
            let L = "{name} here! ";

            function P(e, t, n = L) {
                let a = e.trim(),
                    r = t.trim();
                return a ? `${n.replace("{name}",a)}${r}`.trim() : r
            }

            function _({
                number: e,
                message: t,
                prefix: n,
                children: r,
                className: i
            }) {
                let l = (0, s.useMode)(),
                    c = T(e, P((0, m.useInviteeName)(""), t, n));
                return c ? "edit" === l ? (0, a.jsx)("span", {
                    className: i,
                    children: r
                }) : (0, a.jsx)("a", {
                    href: c,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: i,
                    children: r
                }) : null
            }
        },
        93510: (e, t, n) => {
            "use strict";
            n.d(t, {
                $c: () => f,
                DY: () => c,
                L$: () => o,
                O0: () => u,
                Pi: () => l,
                Wb: () => d,
                fP: () => p,
                lE: () => s,
                xU: () => m
            });
            var a = n(19071);
            let r = ["five", "unlimited"],
                i = {
                    "cp-navratri-invite": {
                        includedLinks: 5,
                        unlimitedUpgradeInr: 250,
                        unlimitedLinkCeiling: 500,
                        occasionLabel: "a Navratri invite",
                        pageSet: !0
                    },
                    "cp-durga-invite": {
                        includedLinks: 5,
                        unlimitedUpgradeInr: 250,
                        unlimitedLinkCeiling: 500,
                        occasionLabel: "\u09aa\u09c1\u099c\u09cb\u09b0 \u09a8\u09bf\u09ae\u09a8\u09cd\u09a4\u09cd\u09b0\u09a3",
                        shareText: "{name}, \u09a4\u09cb\u09ae\u09be\u09b0 \u099c\u09a8\u09cd\u09af \u09aa\u09c1\u099c\u09cb\u09b0 \u09a8\u09bf\u09ae\u09a8\u09cd\u09a4\u09cd\u09b0\u09a3 \uD83E\uDE94 \u0996\u09c1\u09b2\u09c7 \u09a6\u09c7\u0996\u09cb: {link}",
                        shareTextNoName: "\u09a4\u09cb\u09ae\u09be\u09b0 \u099c\u09a8\u09cd\u09af \u09aa\u09c1\u099c\u09cb\u09b0 \u09a8\u09bf\u09ae\u09a8\u09cd\u09a4\u09cd\u09b0\u09a3 \uD83E\uDE94 \u0996\u09c1\u09b2\u09c7 \u09a6\u09c7\u0996\u09cb: {link}",
                        pageSet: !0
                    },
                    "cp-party-invite": {
                        includedLinks: 15,
                        unlimitedUpgradeInr: 200,
                        unlimitedLinkCeiling: 500,
                        occasionLabel: "a party invite",
                        pageSet: !1,
                        rsvpCap: 600
                    },
                    "cp-wedding-invite": {
                        includedLinks: 50,
                        unlimitedUpgradeInr: 500,
                        unlimitedLinkCeiling: 1e3,
                        occasionLabel: "a wedding invite",
                        pageSet: !1,
                        rsvpCap: 1e3
                    },
                    "cp-corporate-invite": {
                        includedLinks: 50,
                        unlimitedUpgradeInr: 400,
                        unlimitedLinkCeiling: 1e3,
                        occasionLabel: "an invite",
                        pageSet: !1,
                        rsvpCap: 1e3
                    }
                };

            function s(e) {
                return e ? i[e] ? ? null : null
            }

            function l(e) {
                return "five" === e || "unlimited" === e
            }

            function c(e, t, n) {
                return "unlimited" === t ? e + n.unlimitedUpgradeInr : e
            }

            function u(e, t, n) {
                return {
                    selected: t,
                    options: r.map(t => {
                        var a, r;
                        return {
                            plan: t,
                            priceInr: c(e, t, n),
                            links: (a = t, r = n, "unlimited" === a ? null : r.includedLinks)
                        }
                    })
                }
            }
            let o = /^[a-z0-9]{8,16}$/,
                d = 40;

            function p(e) {
                if ("string" != typeof e) return null;
                let t = e.replace(/[\u0000-\u001f\u007f<>]/g, "").replace(/\s+/g, " ").trim().slice(0, d).trim();
                return t.length > 0 ? t : null
            }

            function m(e) {
                try {
                    let t = new URLSearchParams(e).get("g");
                    return "string" == typeof t && o.test(t) ? t : null
                } catch {
                    return null
                }
            }

            function f(e, t, n) {
                let a = e.trim(),
                    r = "string" == typeof n ? {
                        occasionLabel: n
                    } : n,
                    i = a ? r.shareText : r.shareTextNoName ? ? r.shareText,
                    s = i ? i.replace("{name}", a).replace("{link}", t) : `Hi ${a||"there"}! You have ${r.occasionLabel} from me. Open it here: ${t}`;
                return `https://wa.me/?text=${encodeURIComponent(s)}`
            }
            a.Yj().transform(e => p(e) ? ? "").pipe(a.Yj().min(1, "Add their name").max(d))
        }
    }
]);