(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6925], {
        6925: (e, r, t) => {
            "use strict";
            let s, a;
            t.r(r), t.d(r, {
                CakeStudio: () => g,
                ConfettiCannons: () => L,
                DanceFloor: () => $,
                GiftUnbox: () => u,
                OpeningSequence: () => f,
                PresentShow: () => M,
                candleCount: () => b
            });
            var i = t(73365),
                l = t(1521),
                n = t(46997),
                p = t(30685),
                c = t(87191),
                o = t(34768),
                d = t(82161);

            function x() {
                let e = (0, o.useStory)(),
                    r = (0, o.useSectionIndex)();
                return !e.active || e.index === r
            }

            function h(e) {
                let r = e >>> 0;
                return () => {
                    let e = r = r + 0x6d2b79f5 >>> 0;
                    return e = Math.imul(e ^ e >>> 15, 1 | e), (((e ^= e + Math.imul(e ^ e >>> 7, 61 | e)) ^ e >>> 14) >>> 0) / 0x100000000
                }
            }

            function f({
                children: e,
                className: r = ""
            }) {
                let t = "edit" === (0, o.useMode)(),
                    s = (0, l.useRef)(null),
                    [a, n] = (0, l.useState)(!1);
                return (0, l.useEffect)(() => {
                    if (t || a) return;
                    let e = window.setTimeout(() => n(!0), 7200);
                    return () => window.clearTimeout(e)
                }, [t, a]), (0, c.useReplaySignal)(s, () => n(!1)), (0, i.jsx)("div", {
                    ref: s,
                    className: `prbp-seq ${r}`,
                    ...t || a ? {
                        "data-skip": ""
                    } : {},
                    onPointerDown: () => n(!0),
                    onKeyDown: () => n(!0),
                    children: e
                })
            }

            function u({
                tailLabel: e,
                pullButton: r,
                hint: t,
                after: s
            }) {
                let a = "edit" === (0, o.useMode)(),
                    p = (0, d.useFolioSound)(),
                    x = (0, l.useRef)(null),
                    h = (0, l.useRef)(null),
                    [f, b] = (0, l.useState)(!1),
                    j = (0, l.useRef)(!1),
                    v = a || f;
                (0, c.useReplaySignal)(x, () => {
                    j.current = !1, b(!1), x.current ? .style.setProperty("--pull", "0px")
                });
                let m = e => {
                        a || j.current || (j.current = !0, p.unlock(e), p.playEffect("unlock"), p.playEffect("popper"), x.current ? .style.setProperty("--pull", "0px"), x.current ? .removeAttribute("data-dragging"), b(!0))
                    },
                    k = e => {
                        let r = h.current;
                        r && r.id === e.pointerId && ((h.current = null, e.clientY - r.y >= 64) ? m(e.currentTarget) : (x.current ? .removeAttribute("data-dragging"), x.current ? .style.setProperty("--pull", "0px")))
                    };
                return (0, i.jsxs)("div", {
                    ref: x,
                    className: "prbp-gift-wrap",
                    ...v ? {
                        "data-open": ""
                    } : {},
                    children: [(0, i.jsxs)("div", {
                        className: "prbp-gift",
                        "aria-hidden": !!v || void 0,
                        children: [v && !a ? (0, i.jsx)(c.ConfettiBurst, {
                            seed: 11,
                            count: 30,
                            top: "40%"
                        }) : null, (0, i.jsxs)("svg", {
                            viewBox: "0 0 200 150",
                            "aria-hidden": !0,
                            className: "prbp-gift-back",
                            children: [(0, i.jsx)("rect", {
                                x: "4",
                                y: "4",
                                width: "192",
                                height: "142",
                                rx: "8",
                                fill: "var(--prbp-box-in)",
                                stroke: "var(--prbp-ink)",
                                strokeWidth: "4"
                            }), (0, i.jsx)("path", {
                                d: "M14 30 H186",
                                stroke: "var(--prbp-ink)",
                                strokeWidth: "3",
                                opacity: "0.25"
                            })]
                        }), (0, i.jsx)("div", {
                            className: "prbp-gift-pop",
                            children: (0, i.jsx)(n.Zj, {
                                pose: v ? "cheer" : "wow",
                                className: "prbp-gift-guest"
                            })
                        }), (0, i.jsx)("div", {
                            className: "prbp-gift-front",
                            children: (0, i.jsxs)("svg", {
                                viewBox: "0 0 200 150",
                                "aria-hidden": !0,
                                className: "block size-full",
                                children: [(0, i.jsx)("rect", {
                                    x: "4",
                                    y: "4",
                                    width: "192",
                                    height: "142",
                                    rx: "8",
                                    fill: "var(--prbp-box)",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "4"
                                }), [0, 1, 2, 3, 4, 5].map(e => (0, i.jsx)("circle", {
                                    cx: 24 + 30 * e,
                                    cy: e % 2 ? 40 : 110,
                                    r: "7",
                                    fill: "var(--prbp-paper)",
                                    opacity: "0.55"
                                }, e)), (0, i.jsx)("rect", {
                                    x: "84",
                                    y: "4",
                                    width: "32",
                                    height: "142",
                                    fill: "var(--prbp-ribbon)",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "4"
                                })]
                            })
                        }), (0, i.jsx)("div", {
                            className: "prbp-gift-lid",
                            children: (0, i.jsxs)("svg", {
                                viewBox: "0 0 220 46",
                                "aria-hidden": !0,
                                className: "block size-full",
                                children: [(0, i.jsx)("rect", {
                                    x: "3",
                                    y: "3",
                                    width: "214",
                                    height: "40",
                                    rx: "7",
                                    fill: "var(--prbp-box)",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "4"
                                }), (0, i.jsx)("rect", {
                                    x: "94",
                                    y: "3",
                                    width: "32",
                                    height: "40",
                                    fill: "var(--prbp-ribbon)",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "4"
                                })]
                            })
                        }), (0, i.jsxs)("svg", {
                            viewBox: "0 0 140 80",
                            "aria-hidden": !0,
                            className: "prbp-gift-bow",
                            children: [(0, i.jsxs)("g", {
                                className: "prbp-bow-l",
                                children: [(0, i.jsx)("path", {
                                    d: "M70 58 C40 70 6 62 8 36 C10 12 44 18 70 52 Z",
                                    fill: "var(--prbp-ribbon)",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "4",
                                    strokeLinejoin: "round"
                                }), (0, i.jsx)("path", {
                                    d: "M58 50 C42 44 28 38 22 34",
                                    fill: "none",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "3",
                                    strokeLinecap: "round",
                                    opacity: "0.4"
                                })]
                            }), (0, i.jsxs)("g", {
                                className: "prbp-bow-r",
                                children: [(0, i.jsx)("path", {
                                    d: "M70 58 C100 70 134 62 132 36 C130 12 96 18 70 52 Z",
                                    fill: "var(--prbp-ribbon)",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "4",
                                    strokeLinejoin: "round"
                                }), (0, i.jsx)("path", {
                                    d: "M82 50 C98 44 112 38 118 34",
                                    fill: "none",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "3",
                                    strokeLinecap: "round",
                                    opacity: "0.4"
                                })]
                            }), (0, i.jsx)("ellipse", {
                                className: "prbp-bow-knot",
                                cx: "70",
                                cy: "56",
                                rx: "13",
                                ry: "11",
                                fill: "var(--prbp-ribbon)",
                                stroke: "var(--prbp-ink)",
                                strokeWidth: "4"
                            })]
                        }), v ? null : (0, i.jsx)("button", {
                            type: "button",
                            className: "prbp-gift-tail",
                            "aria-label": e,
                            tabIndex: a ? -1 : void 0,
                            onPointerDown: e => {
                                a || f || (h.current = {
                                    id: e.pointerId,
                                    y: e.clientY,
                                    moved: 0
                                }, e.currentTarget.setPointerCapture(e.pointerId), x.current ? .setAttribute("data-dragging", ""))
                            },
                            onPointerMove: e => {
                                let r = h.current;
                                if (!r || r.id !== e.pointerId) return;
                                let t = Math.max(0, Math.min(110, e.clientY - r.y));
                                r.moved = Math.max(r.moved, Math.abs(e.clientY - r.y)), x.current ? .style.setProperty("--pull", `${Math.round(t)}px`)
                            },
                            onPointerUp: k,
                            onPointerCancel: k,
                            onClick: e => m(e.currentTarget),
                            children: (0, i.jsx)("svg", {
                                viewBox: "0 0 40 150",
                                "aria-hidden": !0,
                                className: "block size-full",
                                children: (0, i.jsx)("path", {
                                    d: "M14 0 C8 40 30 70 18 112 L10 146 L22 136 L30 148 L32 112 C40 70 22 40 28 0 Z",
                                    fill: "var(--prbp-ribbon)",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "3.5",
                                    strokeLinejoin: "round"
                                })
                            })
                        })]
                    }), (0, i.jsx)("div", {
                        className: "prbp-gift-ui",
                        children: a ? (0, i.jsxs)("div", {
                            className: "flex flex-col items-center gap-3",
                            children: [t, s]
                        }) : v ? (0, i.jsx)("div", {
                            className: "prbp-gift-after",
                            children: s
                        }) : (0, i.jsxs)("div", {
                            className: "flex flex-col items-center gap-3",
                            children: [t, (0, i.jsx)("button", {
                                type: "button",
                                className: (0, n.Dv)("ghost"),
                                onClick: e => m(e.currentTarget),
                                children: r
                            })]
                        })
                    })]
                })
            }

            function b(e) {
                let r = Number.parseInt(e, 10);
                return Number.isFinite(r) ? Math.max(1, Math.min(6, r)) : 1
            }
            t(83605);
            let j = [{
                    x: 36,
                    y: 160,
                    w: 168,
                    h: 52,
                    fill: "var(--prbp-cake)",
                    cream: "var(--prbp-frosting)"
                }, {
                    x: 58,
                    y: 118,
                    w: 124,
                    h: 44,
                    fill: "var(--prbp-c)",
                    cream: "var(--prbp-cake)"
                }, {
                    x: 80,
                    y: 82,
                    w: 80,
                    h: 38,
                    fill: "var(--prbp-cake)",
                    cream: "var(--f-accent)"
                }],
                v = (s = h(29), Array.from({
                    length: 26
                }, (e, r) => {
                    let t = j[r % 3];
                    return {
                        x: Number((t.x + 10 + s() * (t.w - 20)).toFixed(2)),
                        y: Number((t.y + 20 + s() * (t.h - 28)).toFixed(2)),
                        r: Math.round(180 * s()),
                        tone: r % 4,
                        i: r
                    }
                })),
                m = ["var(--f-accent)", "var(--prbp-a)", "var(--prbp-b)", "var(--prbp-flame)"];

            function k({
                built: e,
                candles: r,
                blown: t
            }) {
                let s = j[2],
                    a = r > 1 ? Math.min(16, (s.w - 18) / (r - 1)) : 0,
                    l = 120 - a * (r - 1) / 2;
                return (0, i.jsxs)("svg", {
                    viewBox: "0 0 240 250",
                    "aria-hidden": !0,
                    className: "prbp-cake-svg",
                    children: [(0, i.jsx)("path", {
                        d: "M100 222 L94 244 H146 L140 222 Z",
                        fill: "var(--prbp-paper)",
                        stroke: "var(--prbp-ink)",
                        strokeWidth: "3.5",
                        strokeLinejoin: "round"
                    }), (0, i.jsx)("ellipse", {
                        cx: "120",
                        cy: "218",
                        rx: "108",
                        ry: "12",
                        fill: "var(--prbp-paper)",
                        stroke: "var(--prbp-ink)",
                        strokeWidth: "3.5"
                    }), j.map((r, t) => e > t ? (0, i.jsxs)("g", {
                        className: "prbp-tier",
                        style: {
                            "--i": t
                        },
                        children: [(0, i.jsx)("rect", {
                            x: r.x,
                            y: r.y,
                            width: r.w,
                            height: r.h,
                            rx: "9",
                            fill: r.fill,
                            stroke: "var(--prbp-ink)",
                            strokeWidth: "3.5"
                        }), (0, i.jsx)("path", {
                            d: function(e, r, t) {
                                let s = Math.max(3, Math.round(t / 22)),
                                    a = t / s,
                                    i = `M${e} ${r} H${e+t} V${r+8}`;
                                for (let t = s - 1; t >= 0; t -= 1) {
                                    let s = e + t * a,
                                        l = t % 2 ? 16 : 10;
                                    i += ` Q${(s+.75*a).toFixed(2)} ${r+l} ${(s+a/2).toFixed(2)} ${r+l-2} Q${(s+.25*a).toFixed(2)} ${r+8} ${s.toFixed(2)} ${r+8}`
                                }
                                return `${i} Z`
                            }(r.x, r.y, r.w),
                            fill: r.cream,
                            stroke: "var(--prbp-ink)",
                            strokeWidth: "3",
                            strokeLinejoin: "round"
                        })]
                    }, t) : null), e >= 4 ? v.map(e => (0, i.jsx)("rect", {
                        className: "prbp-sprinkle",
                        x: e.x - 4,
                        y: e.y - 1.5,
                        width: "8",
                        height: "3",
                        rx: "1.5",
                        fill: m[e.tone],
                        transform: `rotate(${e.r} ${e.x} ${e.y})`,
                        style: {
                            "--i": e.i
                        }
                    }, e.i)) : null, e >= 5 ? Array.from({
                        length: r
                    }, (e, r) => {
                        let s = Number((l + r * a).toFixed(2));
                        return (0, i.jsxs)("g", {
                            className: "prbp-candle",
                            style: {
                                "--i": r
                            },
                            children: [(0, i.jsx)("rect", {
                                x: s - 3.5,
                                y: "54",
                                width: "7",
                                height: "30",
                                rx: "2",
                                fill: m[r % 4],
                                stroke: "var(--prbp-ink)",
                                strokeWidth: "2.5"
                            }), (0, i.jsx)("path", {
                                d: `M${s-3} 62 L${s+3} 58 M${s-3} 72 L${s+3} 68`,
                                stroke: "var(--prbp-paper)",
                                strokeWidth: "2"
                            }), t ? (0, i.jsx)("path", {
                                className: "prbp-smoke",
                                pathLength: 1,
                                d: `M${s} 50 C${s-6} 40 ${s+6} 32 ${s} 22 C${s-5} 14 ${s+4} 8 ${s} 2`,
                                fill: "none",
                                stroke: "var(--prbp-ink)",
                                strokeWidth: "2.5",
                                strokeLinecap: "round",
                                opacity: "0.5"
                            }) : (0, i.jsx)("g", {
                                className: "prbp-flame-wrap",
                                style: {
                                    "--i": r
                                },
                                children: (0, i.jsx)("path", {
                                    className: "prbp-flame",
                                    d: `M${s} 34 C${s+7} 42 ${s+6} 52 ${s} 53 C${s-6} 52 ${s-7} 42 ${s} 34 Z`,
                                    fill: "var(--prbp-flame)",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "2"
                                })
                            })]
                        }, r)
                    }) : null]
                })
            }

            function g({
                age: e,
                cakeLabel: r,
                buildLabels: t,
                topper: s,
                ageBadge: a,
                hint: h,
                readyLine: f,
                micLabel: u,
                tapLabel: j,
                nomicLine: v,
                wishLine: m,
                done: y
            }) {
                let M = "edit" === (0, o.useMode)(),
                    N = x(),
                    $ = (0, d.useFolioSound)(),
                    w = (0, l.useRef)(null),
                    L = (0, l.useRef)(null),
                    W = (0, l.useRef)(0),
                    [C, Z] = (0, l.useState)(0),
                    [S, B] = (0, l.useState)(!1),
                    [A, F] = (0, l.useState)("idle"),
                    T = M ? 5 : C,
                    D = !M && S,
                    Q = b(e),
                    _ = () => {
                        W.current += 1, L.current ? .(), L.current = null
                    };
                (0, l.useEffect)(() => {
                    if (N) return () => {
                        _(), F(e => "asking" === e || "listening" === e ? "idle" : e)
                    }
                }, [N]), (0, c.useReplaySignal)(w, () => {
                    _(), Z(0), B(!1), F("idle")
                });
                let E = e => {
                        M || C >= 5 || ($.unlock(e), $.playEffect(3 === C ? "shake" : 4 === C ? "reveal" : "plop"), Z(C + 1))
                    },
                    R = () => {
                        _(), F("idle"), B(!0), $.playEffect("puff"), $.playEffect("horn")
                    },
                    P = async e => {
                        let r;
                        if (M || S || "asking" === A || "listening" === A) return;
                        $.unlock(e);
                        let t = "u" < typeof navigator ? void 0 : navigator.mediaDevices,
                            s = window.AudioContext ? ? window.webkitAudioContext;
                        if (!t ? .getUserMedia || !s) return void F("nomic");
                        F("asking");
                        let a = W.current;
                        try {
                            r = await t.getUserMedia({
                                audio: {
                                    echoCancellation: !1,
                                    noiseSuppression: !1,
                                    autoGainControl: !1
                                }
                            })
                        } catch {
                            a === W.current && F("nomic");
                            return
                        }
                        if (a !== W.current) {
                            for (let e of r.getTracks()) e.stop();
                            return
                        }
                        let i = new s,
                            l = i.createAnalyser();
                        l.fftSize = 512, i.createMediaStreamSource(r).connect(l);
                        let n = new Uint8Array(l.fftSize),
                            c = performance.now(),
                            o = 0,
                            d = 0,
                            x = w.current;
                        L.current = () => {
                            for (let e of (cancelAnimationFrame(d), r.getTracks())) e.stop();
                            i.close().catch(() => void 0), x ? .removeAttribute("data-wind")
                        }, F("listening");
                        let h = e => {
                            l.getByteTimeDomainData(n);
                            let r = (0, p.Ov)(n);
                            if (r >= p.br / 3 ? x ? .setAttribute("data-wind", "") : x ? .removeAttribute("data-wind"), r >= p.br) {
                                if (o || = e, e - o >= p.Ac) return void R()
                            } else o = 0;
                            if (e - c > p.U8) {
                                _(), F("nomic");
                                return
                            }
                            d = requestAnimationFrame(h)
                        };
                        d = requestAnimationFrame(h)
                    },
                    z = T < 5 ? "wave" : D ? "cheer" : "listening" === A ? "blow" : "wow",
                    H = T >= 5;
                return (0, i.jsxs)("div", {
                    ref: w,
                    className: "prbp-cake-studio",
                    "data-stage": T,
                    ...D ? {
                        "data-blown": ""
                    } : {},
                    children: [(0, i.jsxs)("div", {
                        className: "prbp-cake-scene",
                        children: [D ? (0, i.jsx)(c.ConfettiBurst, {
                            seed: 23,
                            count: 28,
                            top: "35%"
                        }) : null, (0, i.jsxs)("button", {
                            type: "button",
                            className: "prbp-cake",
                            "aria-label": r,
                            disabled: !M && H,
                            tabIndex: M ? -1 : void 0,
                            onClick: e => E(e.currentTarget),
                            children: [(0, i.jsx)(k, {
                                built: T,
                                candles: Q,
                                blown: D
                            }), T >= 4 ? (0, i.jsx)("span", {
                                className: "prbp-topper",
                                children: s
                            }) : null, T >= 1 ? (0, i.jsx)("span", {
                                className: "prbp-age",
                                children: a
                            }) : null]
                        }), (0, i.jsx)(n.Zj, {
                            pose: z,
                            className: "prbp-cake-guest"
                        })]
                    }), (0, i.jsx)("div", {
                        className: "prbp-cake-ui",
                        children: M ? (0, i.jsxs)("div", {
                            className: "flex flex-col items-center gap-2 text-center",
                            children: [h, (0, i.jsx)("div", {
                                className: "flex flex-wrap justify-center gap-2",
                                children: t.map((e, r) => (0, i.jsx)("span", {
                                    className: (0, n.Dv)("ghost", "sm"),
                                    children: e
                                }, r))
                            }), f, (0, i.jsxs)("div", {
                                className: "flex flex-wrap justify-center gap-2",
                                children: [(0, i.jsx)("span", {
                                    className: (0, n.Dv)("solid", "sm"),
                                    children: u
                                }), (0, i.jsx)("span", {
                                    className: (0, n.Dv)("ghost", "sm"),
                                    children: j
                                })]
                            }), v, m, y]
                        }) : H ? D ? (0, i.jsxs)("div", {
                            className: "prbp-rise flex flex-col items-center gap-4 text-center",
                            children: [m, y]
                        }) : (0, i.jsxs)("div", {
                            className: "prbp-rise flex flex-col items-center gap-3 text-center",
                            children: [f, (0, i.jsxs)("div", {
                                className: "flex flex-wrap justify-center gap-3",
                                children: [(0, i.jsx)("button", {
                                    type: "button",
                                    className: (0, n.Dv)(),
                                    disabled: "asking" === A || "listening" === A,
                                    onClick: e => void P(e.currentTarget),
                                    children: u
                                }), (0, i.jsx)("button", {
                                    type: "button",
                                    className: (0, n.Dv)("ghost"),
                                    onClick: e => {
                                        var r;
                                        return r = e.currentTarget, void(!M && !S && ($.unlock(r), R()))
                                    },
                                    children: j
                                })]
                            }), "nomic" === A ? v : null]
                        }) : (0, i.jsxs)("div", {
                            className: "flex flex-col items-center gap-3 text-center",
                            children: [(0, i.jsx)("span", {
                                className: "prbp-steps",
                                "aria-hidden": !0,
                                children: Array.from({
                                    length: 5
                                }, (e, r) => (0, i.jsx)("i", {
                                    className: r < C ? "prbp-on" : void 0
                                }, r))
                            }), (0, i.jsx)("button", {
                                type: "button",
                                className: (0, n.Dv)(),
                                onClick: e => E(e.currentTarget),
                                children: t[C]
                            }), h]
                        })
                    })]
                })
            }

            function y({
                variant: e
            }) {
                let r = `prbp${(0,l.useId)().replace(/[^a-zA-Z0-9]/g,"")}`,
                    t = 0 === e ? (0, i.jsxs)("pattern", {
                        id: `${r}p`,
                        width: "18",
                        height: "18",
                        patternUnits: "userSpaceOnUse",
                        patternTransform: "rotate(35)",
                        children: [(0, i.jsx)("rect", {
                            width: "18",
                            height: "18",
                            fill: "var(--prbp-a)"
                        }), (0, i.jsx)("rect", {
                            width: "7",
                            height: "18",
                            fill: "var(--prbp-paper)",
                            opacity: "0.6"
                        })]
                    }) : 1 === e ? (0, i.jsxs)("pattern", {
                        id: `${r}p`,
                        width: "22",
                        height: "22",
                        patternUnits: "userSpaceOnUse",
                        children: [(0, i.jsx)("rect", {
                            width: "22",
                            height: "22",
                            fill: "var(--prbp-b)"
                        }), (0, i.jsx)("circle", {
                            cx: "6",
                            cy: "6",
                            r: "4",
                            fill: "var(--prbp-paper)",
                            opacity: "0.7"
                        }), (0, i.jsx)("circle", {
                            cx: "17",
                            cy: "17",
                            r: "4",
                            fill: "var(--prbp-flame)"
                        })]
                    }) : (0, i.jsxs)("pattern", {
                        id: `${r}p`,
                        width: "24",
                        height: "14",
                        patternUnits: "userSpaceOnUse",
                        children: [(0, i.jsx)("rect", {
                            width: "24",
                            height: "14",
                            fill: "var(--prbp-c)"
                        }), (0, i.jsx)("path", {
                            d: "M0 10 L6 4 L12 10 L18 4 L24 10",
                            fill: "none",
                            stroke: "var(--prbp-paper)",
                            strokeWidth: "3"
                        })]
                    });
                return (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)("svg", {
                        viewBox: "0 0 220 200",
                        "aria-hidden": !0,
                        className: "prbp-paper-l",
                        children: [(0, i.jsx)("defs", {
                            children: t
                        }), (0, i.jsx)("path", {
                            d: "M8 0 H110 L104 36 L118 64 L100 92 L120 122 L102 150 L116 176 L108 200 H8 Z",
                            fill: `url(#${r}p)`,
                            stroke: "var(--prbp-ink)",
                            strokeWidth: "4",
                            strokeLinejoin: "round"
                        }), (0, i.jsx)("path", {
                            d: "M8 86 H112",
                            stroke: "var(--f-accent)",
                            strokeWidth: "16"
                        })]
                    }), (0, i.jsxs)("svg", {
                        viewBox: "0 0 220 200",
                        "aria-hidden": !0,
                        className: "prbp-paper-r",
                        children: [(0, i.jsx)("path", {
                            d: "M110 0 H212 V200 H108 L116 176 L102 150 L120 122 L100 92 L118 64 L104 36 Z",
                            fill: `url(#${r}p)`,
                            stroke: "var(--prbp-ink)",
                            strokeWidth: "4",
                            strokeLinejoin: "round"
                        }), (0, i.jsx)("path", {
                            d: "M110 86 H212",
                            stroke: "var(--f-accent)",
                            strokeWidth: "16"
                        })]
                    }), (0, i.jsxs)("svg", {
                        viewBox: "0 0 120 60",
                        "aria-hidden": !0,
                        className: "prbp-present-bow",
                        children: [(0, i.jsx)("path", {
                            d: "M60 44 C36 58 6 50 8 28 C10 8 38 14 60 40 Z M60 44 C84 58 114 50 112 28 C110 8 82 14 60 40 Z",
                            fill: "var(--f-accent)",
                            stroke: "var(--prbp-ink)",
                            strokeWidth: "4",
                            strokeLinejoin: "round"
                        }), (0, i.jsx)("circle", {
                            cx: "60",
                            cy: "42",
                            r: "9",
                            fill: "var(--f-accent)",
                            stroke: "var(--prbp-ink)",
                            strokeWidth: "4"
                        })]
                    })]
                })
            }

            function M({
                items: e,
                hint: r,
                nextLabel: t,
                done: s
            }) {
                let a = "edit" === (0, o.useMode)(),
                    p = (0, d.useFolioSound)(),
                    x = (0, l.useRef)(null),
                    h = (0, l.useRef)(null),
                    [f, u] = (0, l.useState)(0),
                    [b, j] = (0, l.useState)(!1);
                (0, c.useReplaySignal)(x, () => {
                    u(0), j(!1)
                });
                let v = e => {
                    a || b || (p.unlock(e), p.playEffect("rustle"), p.playEffect("reveal"), h.current = null, j(!0))
                };
                if (a) return (0, i.jsxs)("div", {
                    ref: x,
                    className: "prbp-presents flex flex-col items-center gap-6",
                    children: [r, e.map((e, r) => (0, i.jsxs)("div", {
                        className: "prbp-present",
                        "data-open": "",
                        children: [(0, i.jsx)("span", {
                            className: "prbp-present-tag",
                            children: e.tag
                        }), (0, i.jsxs)("div", {
                            className: "prbp-polaroid",
                            children: [e.photo, e.caption]
                        })]
                    }, r)), (0, i.jsx)("span", {
                        className: (0, n.Dv)("ghost"),
                        children: t
                    }), s]
                });
                let m = e[f];
                if (!m) return null;
                let k = f >= e.length - 1;
                return (0, i.jsxs)("div", {
                    ref: x,
                    className: "prbp-presents flex flex-col items-center gap-5",
                    children: [(0, i.jsx)("span", {
                        className: "prbp-steps",
                        "aria-hidden": !0,
                        children: e.map((e, r) => (0, i.jsx)("i", {
                            className: r < f || r === f && b ? "prbp-on" : void 0
                        }, r))
                    }), (0, i.jsxs)("div", {
                        className: "prbp-present prbp-present-in",
                        ...b ? {
                            "data-open": ""
                        } : {},
                        children: [(0, i.jsx)("span", {
                            className: "prbp-present-tag",
                            children: m.tag
                        }), (0, i.jsxs)("div", {
                            className: "prbp-polaroid",
                            "aria-hidden": !b || void 0,
                            children: [m.photo, m.caption]
                        }), b ? (0, i.jsx)(c.ConfettiBurst, {
                            seed: 31 + f,
                            count: 22,
                            top: "45%"
                        }) : null, (0, i.jsx)("button", {
                            type: "button",
                            className: "prbp-present-hit",
                            "aria-label": m.label,
                            disabled: b,
                            "aria-hidden": !!b || void 0,
                            onPointerDown: e => {
                                h.current = {
                                    id: e.pointerId,
                                    x: e.clientX
                                }
                            },
                            onPointerMove: e => {
                                let r = h.current;
                                r && r.id === e.pointerId && Math.abs(e.clientX - r.x) >= 44 && v(e.currentTarget)
                            },
                            onClick: e => v(e.currentTarget),
                            children: (0, i.jsx)(y, {
                                variant: f % 3
                            })
                        })]
                    }, f), (0, i.jsx)("div", {
                        className: "prbp-present-ui",
                        children: b ? k ? (0, i.jsx)("div", {
                            className: "prbp-rise",
                            children: s
                        }) : (0, i.jsx)("button", {
                            type: "button",
                            className: `${(0,n.Dv)()} prbp-rise`,
                            onClick: e => {
                                p.unlock(e.currentTarget), p.playEffect("next"), j(!1), u(f + 1)
                            },
                            children: t
                        }) : r
                    })]
                })
            }
            let N = ["thumka", "bhangra", "spin"];

            function $({
                moves: e,
                dancerLabel: r
            }) {
                let t = "edit" === (0, o.useMode)(),
                    s = (0, d.useFolioSound)(),
                    a = (0, l.useRef)(null),
                    [p, x] = (0, l.useState)(0);
                (0, c.useReplaySignal)(a, () => x(0));
                let h = (e, r) => {
                        t || (s.unlock(r), s.playEffect(1 === e ? "dhol" : 2 === e ? "switch" : "shake"), x(e))
                    },
                    f = N[p % N.length];
                return (0, i.jsxs)("div", {
                    ref: a,
                    className: "prbp-dance",
                    "data-move": p,
                    children: [(0, i.jsxs)("div", {
                        className: "prbp-dance-stage",
                        "aria-hidden": !!t || void 0,
                        children: [(0, i.jsxs)("div", {
                            className: "prbp-dance-far",
                            children: [(0, i.jsx)("i", {
                                className: "prbp-beam prbp-beam-1"
                            }), (0, i.jsx)("i", {
                                className: "prbp-beam prbp-beam-2"
                            }), (0, i.jsx)("i", {
                                className: "prbp-beam prbp-beam-3"
                            }), (0, i.jsxs)("svg", {
                                viewBox: "0 0 60 70",
                                "aria-hidden": !0,
                                className: "prbp-mirrorball",
                                children: [(0, i.jsx)("path", {
                                    d: "M30 0 V12",
                                    stroke: "var(--prbp-ink)",
                                    strokeWidth: "2.5"
                                }), (0, i.jsxs)("g", {
                                    className: "prbp-mirrorball-spin",
                                    children: [(0, i.jsx)("circle", {
                                        cx: "30",
                                        cy: "40",
                                        r: "24",
                                        fill: "var(--prbp-paper)",
                                        stroke: "var(--prbp-ink)",
                                        strokeWidth: "3.5"
                                    }), (0, i.jsx)("path", {
                                        d: "M8 32 H52 M6 42 H54 M9 52 H51 M30 16 V64 M18 19 C14 32 14 50 18 61 M42 19 C46 32 46 50 42 61",
                                        stroke: "var(--prbp-ink)",
                                        strokeWidth: "1.6",
                                        opacity: "0.45",
                                        fill: "none"
                                    }), (0, i.jsx)("rect", {
                                        x: "20",
                                        y: "24",
                                        width: "7",
                                        height: "7",
                                        fill: "var(--prbp-a)"
                                    }), (0, i.jsx)("rect", {
                                        x: "34",
                                        y: "44",
                                        width: "7",
                                        height: "7",
                                        fill: "var(--prbp-c)"
                                    })]
                                })]
                            })]
                        }), (0, i.jsxs)("div", {
                            className: "prbp-dance-mid",
                            children: [(0, i.jsx)("div", {
                                className: "prbp-bubble",
                                children: t ? (0, i.jsx)("div", {
                                    className: "flex flex-col gap-1",
                                    children: e.map((e, r) => (0, i.jsx)("div", {
                                        children: e.line
                                    }, r))
                                }) : (0, i.jsx)("div", {
                                    className: "prbp-bubble-line",
                                    children: e[p] ? .line
                                }, p)
                            }), t ? (0, i.jsx)(n.Zj, {
                                pose: f,
                                className: "prbp-dancer"
                            }) : (0, i.jsx)("button", {
                                type: "button",
                                className: "prbp-dancer-hit",
                                "aria-label": r,
                                onClick: r => h((p + 1) % e.length, r.currentTarget),
                                children: (0, i.jsx)(n.Zj, {
                                    pose: f,
                                    className: "prbp-dancer"
                                }, p)
                            })]
                        }), (0, i.jsx)("div", {
                            className: "prbp-dance-floor",
                            children: Array.from({
                                length: 10
                            }, (e, r) => (0, i.jsx)("i", {
                                style: {
                                    "--i": r
                                }
                            }, r))
                        }), (0, i.jsx)("div", {
                            className: "prbp-dance-near",
                            children: ["\u266a", "\u266b", "\u266a", "\u266b"].map((e, r) => (0, i.jsx)("span", {
                                className: "prbp-note",
                                style: {
                                    "--i": r
                                },
                                children: e
                            }, r))
                        })]
                    }), (0, i.jsx)("div", {
                        className: "prbp-moves",
                        role: "group",
                        children: e.map((e, r) => t ? (0, i.jsx)("span", {
                            className: (0, n.Dv)("solid", "sm"),
                            children: e.label
                        }, r) : (0, i.jsx)("button", {
                            type: "button",
                            "aria-pressed": p === r,
                            className: (0, n.Dv)(p === r ? "solid" : "ghost", "sm"),
                            onClick: e => h(r, e.currentTarget),
                            children: e.label
                        }, r))
                    })]
                })
            }
            let w = (a = h(77), Array.from({
                length: 22
            }, (e, r) => {
                let t = (-80 + 55 * a()) * (Math.PI / 180),
                    s = 170 + 170 * a();
                return {
                    dx: Math.round(Math.cos(t) * s),
                    dy: Math.round(Math.sin(t) * s),
                    r: Math.round(180 + 540 * a()),
                    d: Math.round(140 * a()),
                    tone: r % 5,
                    shape: r % 4
                }
            }));

            function L({
                left: e,
                right: r,
                fireLabel: t
            }) {
                let s = "edit" === (0, o.useMode)(),
                    a = x(),
                    p = (0, d.useFolioSound)(),
                    c = (0, d.useSoundEffect)(),
                    [h, f] = (0, l.useState)(0),
                    u = a && !s;
                (0, l.useEffect)(() => {
                    u && c("popper")
                }, [u, c]);
                let b = e => u ? (0, i.jsx)("span", {
                    className: `prbp-burst prbp-burst-${e}`,
                    "aria-hidden": !0,
                    children: w.map((r, t) => (0, i.jsx)("i", {
                        "data-shape": r.shape,
                        style: {
                            "--dx": `${"l"===e?r.dx:-r.dx}px`,
                            "--dy": `${r.dy}px`,
                            "--r": `${r.r}deg`,
                            "--d": `${r.d}ms`,
                            background: `var(--prbp-tone-${r.tone})`
                        }
                    }, t))
                }, `${e}${h}`) : null;
                return (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)("div", {
                        className: "prbp-cannons",
                        "aria-hidden": !0,
                        children: [(0, i.jsx)("span", {
                            className: "prbp-cannon prbp-cannon-l",
                            "data-shot": h > 0 ? "" : void 0,
                            children: e
                        }, `cl${h}`), (0, i.jsx)("span", {
                            className: "prbp-cannon prbp-cannon-r",
                            "data-shot": h > 0 ? "" : void 0,
                            children: r
                        }, `cr${h}`), b("l"), b("r")]
                    }), s ? (0, i.jsx)("span", {
                        className: (0, n.Dv)("ghost"),
                        children: t
                    }) : (0, i.jsx)("button", {
                        type: "button",
                        className: (0, n.Dv)("ghost"),
                        onClick: e => {
                            var r;
                            return r = e.currentTarget, void(!s && (p.unlock(r), p.playEffect("popper"), p.playEffect("confetti"), f(h + 1)))
                        },
                        children: t
                    })]
                })
            }
        },
        30685: (e, r, t) => {
            "use strict";

            function s(e) {
                let r = 0;
                for (let t = 0; t < e.length; t += 1) {
                    let s = (e[t] - 128) / 128;
                    r += s * s
                }
                return 0 === e.length ? 0 : Math.sqrt(r / e.length)
            }
            t.d(r, {
                Ac: () => i,
                Ov: () => s,
                U8: () => l,
                br: () => a
            });
            let a = .16,
                i = 220,
                l = 2e4
        },
        46997: (e, r, t) => {
            "use strict";
            t.d(r, {
                Bw: () => b,
                Dv: () => M,
                O6: () => h,
                Rr: () => g,
                Ym: () => j,
                Yu: () => f,
                Zj: () => x,
                hM: () => m,
                iY: () => k
            });
            var s = t(73365);
            t(83605);
            let a = e => Number(e.toFixed(2)),
                i = "var(--prbp-ink)",
                l = {
                    stroke: i,
                    strokeWidth: 3.5,
                    strokeLinejoin: "round",
                    strokeLinecap: "round"
                },
                n = ["var(--f-accent)", "var(--prbp-a)", "var(--prbp-b)", "var(--prbp-c)"],
                p = {
                    wave: "happy",
                    wow: "wow",
                    cheer: "cheer",
                    blow: "blow",
                    thumka: "cheer",
                    bhangra: "cheer",
                    spin: "happy"
                };

            function c({
                mood: e
            }) {
                if ("cheer" === e) return (0, s.jsxs)("g", {
                    children: [(0, s.jsx)("path", {
                        d: "M71 99 Q80 87 89 99",
                        fill: "none",
                        ...l,
                        strokeWidth: 4.5
                    }), (0, s.jsx)("path", {
                        d: "M111 99 Q120 87 129 99",
                        fill: "none",
                        ...l,
                        strokeWidth: 4.5
                    })]
                });
                if ("blow" === e) return (0, s.jsxs)("g", {
                    children: [(0, s.jsx)("path", {
                        d: "M71 96 Q80 101 89 96",
                        fill: "none",
                        ...l,
                        strokeWidth: 4.5
                    }), (0, s.jsx)("path", {
                        d: "M111 96 Q120 101 129 96",
                        fill: "none",
                        ...l,
                        strokeWidth: 4.5
                    })]
                });
                let r = "wow" === e;
                return (0, s.jsxs)("g", {
                    className: "prbp-g-eyes",
                    children: [(0, s.jsx)("ellipse", {
                        cx: "80",
                        cy: "96",
                        rx: r ? 8.5 : 7,
                        ry: r ? 11 : 9,
                        fill: i
                    }), (0, s.jsx)("ellipse", {
                        cx: "120",
                        cy: "96",
                        rx: r ? 8.5 : 7,
                        ry: r ? 11 : 9,
                        fill: i
                    }), (0, s.jsx)("circle", {
                        cx: "82.5",
                        cy: "91.5",
                        r: "2.6",
                        fill: "#fff"
                    }), (0, s.jsx)("circle", {
                        cx: "122.5",
                        cy: "91.5",
                        r: "2.6",
                        fill: "#fff"
                    }), r ? (0, s.jsxs)(s.Fragment, {
                        children: [(0, s.jsx)("path", {
                            d: "M69 76 Q80 68 91 75",
                            fill: "none",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M109 75 Q120 68 131 76",
                            fill: "none",
                            ...l
                        })]
                    }) : null]
                })
            }

            function o({
                mood: e
            }) {
                let r = (0, s.jsx)("path", {
                    d: "M95 106 L105 106 L100 112 Z",
                    fill: "var(--prbp-frosting)",
                    ...l,
                    strokeWidth: 2.5
                });
                return "wow" === e ? (0, s.jsxs)("g", {
                    children: [r, (0, s.jsx)("ellipse", {
                        cx: "100",
                        cy: "124",
                        rx: "7",
                        ry: "9",
                        fill: i
                    })]
                }) : "cheer" === e ? (0, s.jsxs)("g", {
                    children: [r, (0, s.jsx)("path", {
                        d: "M85 114 Q100 140 115 114 Z",
                        fill: i,
                        ...l,
                        strokeWidth: 2.5
                    }), (0, s.jsx)("path", {
                        d: "M92 125 Q100 133 108 125 Q100 120 92 125 Z",
                        fill: "var(--f-accent)"
                    })]
                }) : "blow" === e ? (0, s.jsxs)("g", {
                    children: [(0, s.jsx)("ellipse", {
                        cx: "68",
                        cy: "114",
                        rx: "15",
                        ry: "12",
                        fill: "var(--prbp-frosting)",
                        ...l,
                        strokeWidth: 2.5
                    }), (0, s.jsx)("ellipse", {
                        cx: "132",
                        cy: "114",
                        rx: "15",
                        ry: "12",
                        fill: "var(--prbp-frosting)",
                        ...l,
                        strokeWidth: 2.5
                    }), r, (0, s.jsx)("circle", {
                        cx: "100",
                        cy: "121",
                        r: "5",
                        fill: "none",
                        ...l,
                        strokeWidth: 3
                    })]
                }) : (0, s.jsxs)("g", {
                    children: [r, (0, s.jsx)("path", {
                        d: "M100 112 Q100 119 91 119 M100 112 Q100 119 109 119",
                        fill: "none",
                        ...l,
                        strokeWidth: 3
                    })]
                })
            }

            function d({
                d: e,
                paw: r
            }) {
                return (0, s.jsxs)(s.Fragment, {
                    children: [(0, s.jsx)("path", {
                        d: e,
                        fill: "none",
                        stroke: i,
                        strokeWidth: "21",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: e,
                        fill: "none",
                        stroke: "var(--prbp-fur)",
                        strokeWidth: "14",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("circle", {
                        cx: r[0],
                        cy: r[1],
                        r: "9.5",
                        fill: "var(--prbp-fur)",
                        ...l,
                        strokeWidth: 3
                    })]
                })
            }

            function x({
                pose: e = "wave",
                className: r = ""
            }) {
                let t = p[e];
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 200 250",
                    "aria-hidden": !0,
                    className: `prbp-guest ${r}`,
                    "data-pose": e,
                    "data-mood": t,
                    children: [(0, s.jsx)("ellipse", {
                        cx: "100",
                        cy: "241",
                        rx: "54",
                        ry: "7",
                        fill: i,
                        opacity: "0.16"
                    }), (0, s.jsxs)("g", {
                        className: "prbp-g-rig",
                        children: [(0, s.jsxs)("g", {
                            className: "prbp-g-tail",
                            children: [(0, s.jsx)("path", {
                                d: "M138 214 C168 214 178 186 166 168 C160 160 150 164 154 173 C161 186 154 200 136 202 Z",
                                fill: "var(--prbp-fur)",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M160 178 L168 174 M162 190 L171 189",
                                ...l,
                                strokeWidth: 3
                            })]
                        }), (0, s.jsx)("ellipse", {
                            cx: "80",
                            cy: "232",
                            rx: "18",
                            ry: "9.5",
                            fill: "var(--prbp-fur)",
                            ...l
                        }), (0, s.jsx)("ellipse", {
                            cx: "120",
                            cy: "232",
                            rx: "18",
                            ry: "9.5",
                            fill: "var(--prbp-fur)",
                            ...l
                        }), (0, s.jsxs)("g", {
                            className: "prbp-g-torso",
                            children: [(0, s.jsx)("path", {
                                d: "M100 134 C133 134 149 166 147 196 C145 222 127 234 100 234 C73 234 55 222 53 196 C51 166 67 134 100 134 Z",
                                fill: "var(--prbp-fur)",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M100 166 C119 166 127 185 125 204 C123 220 113 226 100 226 C87 226 77 220 75 204 C73 185 81 166 100 166 Z",
                                fill: "var(--prbp-cake)"
                            }), (0, s.jsx)("path", {
                                d: "M58 182 Q66 184 70 190 M57 200 Q65 201 70 206 M142 182 Q134 184 130 190 M143 200 Q135 201 130 206",
                                fill: "none",
                                ...l,
                                strokeWidth: 3
                            }), (0, s.jsx)("path", {
                                d: "M100 146 L81 135 L81 157 Z M100 146 L119 135 L119 157 Z",
                                fill: "var(--f-accent)",
                                ...l,
                                strokeWidth: 3
                            }), (0, s.jsx)("circle", {
                                cx: "100",
                                cy: "146",
                                r: "5.5",
                                fill: "var(--prbp-a)",
                                ...l,
                                strokeWidth: 3
                            })]
                        }), (0, s.jsx)("g", {
                            className: "prbp-g-armL",
                            children: (0, s.jsx)(d, {
                                d: "M64 160 C54 172 46 186 40 200",
                                paw: [39, 203]
                            })
                        }), (0, s.jsx)("g", {
                            className: "prbp-g-armR",
                            children: (0, s.jsx)(d, {
                                d: "M136 160 C146 172 154 186 160 200",
                                paw: [161, 203]
                            })
                        }), (0, s.jsxs)("g", {
                            className: "prbp-g-head",
                            children: [(0, s.jsx)("path", {
                                d: "M60 84 L57 36 L93 60 Z",
                                fill: "var(--prbp-fur)",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M66 74 L64 50 L84 62 Z",
                                fill: "var(--prbp-frosting)"
                            }), (0, s.jsx)("path", {
                                d: "M140 84 L143 36 L107 60 Z",
                                fill: "var(--prbp-fur)",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M134 74 L136 50 L116 62 Z",
                                fill: "var(--prbp-frosting)"
                            }), (0, s.jsx)("ellipse", {
                                cx: "100",
                                cy: "97",
                                rx: "57",
                                ry: "48",
                                fill: "var(--prbp-fur)",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M100 51 V63 M87 53 L89 63 M113 53 L111 63",
                                ...l,
                                strokeWidth: 3
                            }), (0, s.jsx)("path", {
                                d: "M48 104 L28 100 M48 112 L28 116 M152 104 L172 100 M152 112 L172 116",
                                ...l,
                                strokeWidth: 2.5
                            }), (0, s.jsx)("ellipse", {
                                cx: "65",
                                cy: "114",
                                rx: "9",
                                ry: "5.5",
                                fill: "var(--prbp-frosting)",
                                opacity: "0.85"
                            }), (0, s.jsx)("ellipse", {
                                cx: "135",
                                cy: "114",
                                rx: "9",
                                ry: "5.5",
                                fill: "var(--prbp-frosting)",
                                opacity: "0.85"
                            }), (0, s.jsxs)("g", {
                                className: "prbp-g-hat",
                                children: [(0, s.jsx)("path", {
                                    d: "M80 55 L111 2 L126 50 Z",
                                    fill: "var(--prbp-b)",
                                    ...l
                                }), (0, s.jsx)("path", {
                                    d: "M89 40 L120 34 M98 24 L116 20",
                                    fill: "none",
                                    stroke: "var(--prbp-a)",
                                    strokeWidth: "5",
                                    strokeLinecap: "round"
                                }), (0, s.jsx)("circle", {
                                    cx: "111",
                                    cy: "4",
                                    r: "8",
                                    fill: "var(--f-accent)",
                                    ...l,
                                    strokeWidth: 3
                                })]
                            }), (0, s.jsx)(c, {
                                mood: t
                            }), (0, s.jsx)(o, {
                                mood: t
                            })]
                        })]
                    })]
                })
            }

            function h({
                tone: e = 0,
                className: r = "",
                style: t
            }) {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 60 120",
                    "aria-hidden": !0,
                    className: r,
                    style: t,
                    children: [(0, s.jsx)("path", {
                        d: "M30 78 C26 88 36 94 30 104 C25 112 33 116 30 120",
                        fill: "none",
                        stroke: i,
                        strokeWidth: "2.2",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M30 4 C48 4 57 20 57 36 C57 56 42 72 30 76 C18 72 3 56 3 36 C3 20 12 4 30 4 Z",
                        fill: n[e % 4],
                        ...l,
                        strokeWidth: 3
                    }), (0, s.jsx)("path", {
                        d: "M25 76 L35 76 L30 82 Z",
                        fill: n[e % 4],
                        ...l,
                        strokeWidth: 2.5
                    }), (0, s.jsx)("path", {
                        d: "M15 24 C18 16 24 12 30 12",
                        fill: "none",
                        stroke: "#fff",
                        strokeWidth: "4.5",
                        strokeLinecap: "round",
                        opacity: "0.75"
                    })]
                })
            }

            function f({
                tone: e = 1,
                className: r = "",
                style: t
            }) {
                let p = Array.from({
                        length: 32
                    }, (e, r) => {
                        let t = r / 32 * Math.PI * 2,
                            s = r % 2 == 0 ? 48 : 38;
                        return `${a(50+Math.cos(t)*s)},${a(50+Math.sin(t)*s)}`
                    }).join(" "),
                    c = Array.from({
                        length: 16
                    }, (e, r) => {
                        let t = r / 16 * Math.PI * 2;
                        return `M50 50 L${a(50+46*Math.cos(t))} ${a(50+46*Math.sin(t))}`
                    }).join(" ");
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    "aria-hidden": !0,
                    className: r,
                    style: t,
                    children: [(0, s.jsx)("polygon", {
                        points: p,
                        fill: n[e % 4],
                        ...l,
                        strokeWidth: 2.5
                    }), (0, s.jsx)("path", {
                        d: c,
                        stroke: i,
                        strokeWidth: "1.4",
                        opacity: "0.35"
                    }), (0, s.jsx)("circle", {
                        cx: "50",
                        cy: "50",
                        r: "11",
                        fill: "var(--prbp-paper)",
                        ...l,
                        strokeWidth: 2.5
                    })]
                })
            }

            function u(e, r, t, s) {
                return Array.from({
                    length: e
                }, (i, l) => {
                    let n = (l + .5) / e;
                    return {
                        x: a(n * r),
                        y: a(t + 4 * s * n * (1 - n)),
                        t: n
                    }
                })
            }

            function b({
                className: e = "",
                wide: r = !1
            }) {
                let t = r ? 760 : 360,
                    p = u(r ? 18 : 9, t, 8, 30);
                return (0, s.jsxs)("svg", {
                    viewBox: `0 0 ${t} 70`,
                    "aria-hidden": !0,
                    className: e,
                    children: [(0, s.jsx)("path", {
                        className: "prbp-draw",
                        pathLength: 1,
                        d: `M0 8 Q${t/2} 68 ${t} 8`,
                        fill: "none",
                        stroke: i,
                        strokeWidth: "2.5"
                    }), p.map((e, r) => (0, s.jsx)("g", {
                        className: "prbp-flag",
                        style: {
                            "--i": r
                        },
                        children: (0, s.jsx)("path", {
                            d: `M${a(e.x-14)} ${e.y} L${a(e.x+14)} ${e.y} L${e.x} ${a(e.y+30)} Z`,
                            fill: n[r % 4],
                            ...l,
                            strokeWidth: 2.5
                        })
                    }, r))]
                })
            }
            let j = {
                    Bunting: (0, s.jsx)(function() {
                        let e = u(8, 320, 10, 30);
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 320 90",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("path", {
                                d: "M0 10 Q160 70 320 10",
                                fill: "none",
                                stroke: i,
                                strokeWidth: "2.5"
                            }), e.map((e, r) => (0, s.jsxs)("g", {
                                children: [(0, s.jsx)("path", {
                                    d: `M${a(e.x-15)} ${e.y} L${a(e.x+15)} ${e.y} L${e.x} ${a(e.y+34)} Z`,
                                    fill: n[r % 4],
                                    ...l,
                                    strokeWidth: 2.5
                                }), (0, s.jsx)("circle", {
                                    cx: e.x,
                                    cy: a(e.y + 12),
                                    r: "3.5",
                                    fill: "var(--prbp-paper)"
                                })]
                            }, r))]
                        })
                    }, {}),
                    Lanterns: (0, s.jsx)(function() {
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 320 90",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("path", {
                                d: "M0 6 Q160 26 320 6",
                                fill: "none",
                                stroke: i,
                                strokeWidth: "2.5"
                            }), [40, 120, 200, 280].map((e, r) => {
                                let t = a(6 + e / 320 * 80 * (1 - e / 320));
                                return (0, s.jsxs)("g", {
                                    children: [(0, s.jsx)("path", {
                                        d: `M${e} ${t} V${a(t+8)}`,
                                        ...l,
                                        strokeWidth: 2.5
                                    }), (0, s.jsx)("path", {
                                        d: `M${e} ${a(t+8)} L${e+20} ${a(t+30)} L${e} ${a(t+52)} L${e-20} ${a(t+30)} Z`,
                                        fill: n[(r + 1) % 4],
                                        ...l,
                                        strokeWidth: 3
                                    }), (0, s.jsx)("path", {
                                        d: `M${e-20} ${a(t+30)} H${e+20} M${e} ${a(t+8)} V${a(t+52)}`,
                                        ...l,
                                        strokeWidth: 2,
                                        opacity: "0.6"
                                    }), (0, s.jsx)("path", {
                                        d: `M${e-6} ${a(t+54)} L${e-8} ${a(t+72)} M${e} ${a(t+54)} V${a(t+76)} M${e+6} ${a(t+54)} L${e+8} ${a(t+72)}`,
                                        stroke: "var(--prbp-flame)",
                                        strokeWidth: "3",
                                        strokeLinecap: "round"
                                    })]
                                }, e)
                            })]
                        })
                    }, {}),
                    "Fairy lights": (0, s.jsx)(function() {
                        let e = u(11, 320, 8, 26);
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 320 90",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("path", {
                                d: "M0 8 Q40 40 80 22 T160 30 T240 22 T320 8",
                                fill: "none",
                                stroke: i,
                                strokeWidth: "2.5"
                            }), e.map((e, r) => (0, s.jsxs)("g", {
                                children: [(0, s.jsx)("circle", {
                                    cx: e.x,
                                    cy: a(e.y + 18),
                                    r: "11",
                                    fill: "var(--prbp-flame)",
                                    opacity: "0.28"
                                }), (0, s.jsx)("rect", {
                                    x: a(e.x - 3),
                                    y: a(e.y + 4),
                                    width: "6",
                                    height: "6",
                                    fill: i
                                }), (0, s.jsx)("ellipse", {
                                    cx: e.x,
                                    cy: a(e.y + 17),
                                    rx: "6",
                                    ry: "8",
                                    fill: n[r % 4],
                                    ...l,
                                    strokeWidth: 2.2
                                })]
                            }, r))]
                        })
                    }, {}),
                    Tassels: (0, s.jsx)(function() {
                        let e = u(10, 320, 8, 24);
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 320 90",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("path", {
                                d: "M0 8 Q160 56 320 8",
                                fill: "none",
                                stroke: i,
                                strokeWidth: "2.5"
                            }), e.map((e, r) => (0, s.jsxs)("g", {
                                children: [(0, s.jsx)("path", {
                                    d: `M${a(e.x-9)} ${e.y} L${a(e.x+9)} ${e.y} L${a(e.x+5)} ${a(e.y+38)} L${a(e.x-5)} ${a(e.y+38)} Z`,
                                    fill: n[(r + 2) % 4],
                                    ...l,
                                    strokeWidth: 2.2
                                }), (0, s.jsx)("path", {
                                    d: `M${e.x} ${a(e.y+4)} V${a(e.y+36)}`,
                                    stroke: "var(--prbp-paper)",
                                    strokeWidth: "2",
                                    opacity: "0.7"
                                })]
                            }, r))]
                        })
                    }, {})
                },
                v = (0, s.jsx)("path", {
                    d: "M40 92 V52",
                    stroke: i,
                    strokeWidth: "4",
                    strokeLinecap: "round"
                }),
                m = {
                    Star: (0, s.jsxs)("svg", {
                        viewBox: "0 0 80 92",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [v, (0, s.jsx)("path", {
                            d: "M40 6 L48 24 L68 26 L53 39 L58 58 L40 48 L22 58 L27 39 L12 26 L32 24 Z",
                            fill: "var(--prbp-flame)",
                            ...l
                        }), (0, s.jsx)("circle", {
                            cx: "40",
                            cy: "34",
                            r: "4",
                            fill: i,
                            opacity: "0.2"
                        })]
                    }),
                    Heart: (0, s.jsxs)("svg", {
                        viewBox: "0 0 80 92",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [v, (0, s.jsx)("path", {
                            d: "M40 58 C20 44 10 34 10 22 C10 13 17 6 26 6 C32 6 37 9 40 15 C43 9 48 6 54 6 C63 6 70 13 70 22 C70 34 60 44 40 58 Z",
                            fill: "var(--f-accent)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M20 20 C21 15 25 12 29 12",
                            fill: "none",
                            stroke: "#fff",
                            strokeWidth: "4",
                            strokeLinecap: "round",
                            opacity: "0.7"
                        })]
                    }),
                    Crown: (0, s.jsxs)("svg", {
                        viewBox: "0 0 80 92",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [v, (0, s.jsx)("path", {
                            d: "M10 52 L14 16 L28 32 L40 8 L52 32 L66 16 L70 52 Z",
                            fill: "var(--prbp-flame)",
                            ...l
                        }), (0, s.jsx)("circle", {
                            cx: "40",
                            cy: "38",
                            r: "5",
                            fill: "var(--f-accent)",
                            ...l,
                            strokeWidth: 2.5
                        }), (0, s.jsx)("circle", {
                            cx: "22",
                            cy: "42",
                            r: "4",
                            fill: "var(--prbp-a)",
                            ...l,
                            strokeWidth: 2.5
                        }), (0, s.jsx)("circle", {
                            cx: "58",
                            cy: "42",
                            r: "4",
                            fill: "var(--prbp-b)",
                            ...l,
                            strokeWidth: 2.5
                        })]
                    }),
                    Flower: (0, s.jsxs)("svg", {
                        viewBox: "0 0 80 92",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [v, [0, 72, 144, 216, 288].map(e => (0, s.jsx)("ellipse", {
                            cx: "40",
                            cy: "16",
                            rx: "10",
                            ry: "15",
                            fill: "var(--prbp-c)",
                            ...l,
                            strokeWidth: 3,
                            transform: `rotate(${e} 40 32)`
                        }, e)), (0, s.jsx)("circle", {
                            cx: "40",
                            cy: "32",
                            r: "9",
                            fill: "var(--prbp-flame)",
                            ...l,
                            strokeWidth: 3
                        })]
                    })
                };

            function k({
                className: e = ""
            }) {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 90 90",
                    "aria-hidden": !0,
                    className: e,
                    children: [(0, s.jsx)("path", {
                        d: "M8 84 L30 30 L62 60 Z",
                        fill: "var(--prbp-b)",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M16 64 L42 70 M22 48 L50 62",
                        stroke: "var(--prbp-flame)",
                        strokeWidth: "5",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("ellipse", {
                        cx: "46",
                        cy: "45",
                        rx: "22",
                        ry: "7",
                        transform: "rotate(43 46 45)",
                        fill: "var(--f-accent)",
                        ...l
                    })]
                })
            }

            function g({
                className: e = "",
                style: r
            }) {
                return (0, s.jsx)("svg", {
                    viewBox: "0 0 60 110",
                    "aria-hidden": !0,
                    className: e,
                    style: r,
                    children: (0, s.jsx)("path", {
                        className: "prbp-draw",
                        pathLength: 1,
                        d: "M30 4 C48 4 57 20 57 36 C57 56 42 72 30 76 C18 72 3 56 3 36 C3 20 12 4 30 4 Z M30 76 C25 86 36 92 30 102 C27 106 31 108 30 110",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "3",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                })
            }
            let y = {
                solid: "bg-(--f-accent) text-(--f-onAccent) shadow-[0_0_0_2.5px_var(--f-fg),0_5px_0_2.5px_var(--f-fg)]",
                ghost: "bg-(--f-surface) text-(--f-fg) shadow-[0_0_0_2.5px_var(--f-fg),0_4px_0_2.5px_var(--f-fg)]"
            };

            function M(e = "solid", r = "md") {
                return `inline-flex ${"sm"===r?"min-h-[48px] px-5 text-[15px]":"min-h-[56px] px-8 text-[17px]"} items-center justify-center gap-2 rounded-full font-(family-name:--f-body) font-bold leading-[1.4] transition-transform active:translate-y-[3px] disabled:opacity-60 ${y[e]}`
            }
        },
        83605: () => {}
    }
]);