"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [77420], {
        77420: (e, t, n) => {
            n.d(t, {
                L3: () => h,
                Lx: () => D
            });
            var s = n(83367),
                l = n(23419),
                i = n(23614),
                o = n(69534),
                a = n(85319),
                d = n(95398),
                r = n(80152),
                c = n(32061),
                u = n(67868),
                m = n(89973),
                p = n(44186);
            class f extends Error {}
            let h = ["design", "variant", "css", "buyerEditable", "linked", "name"];

            function g(e) {
                throw new f(e)
            }

            function I(e) {
                let t = new Set;
                for (let n of e.pages)
                    for (let e of n.sections) {
                        for (let n of (t.add(e.id), Object.values(e.stacks)))
                            for (let e of n)
                                for (let n of (t.add(e.id), e.items ? ? [])) t.add(n.id);
                        for (let n of e.elements ? ? [])
                            for (let e of (t.add(n.id), n.items ? ? [])) t.add(e.id)
                    }
                return t
            }

            function v(e, t, n) {
                if (void 0 !== e) return u.Yi.test(e) || g(`Id "${e}" is not a valid id`), t.has(e) && g(`Id "${e}" is already in use`), t.add(e), e;
                let s = n();
                for (; t.has(s);) s = n();
                return t.add(s), s
            }

            function k(e, t, n) {
                (!Number.isInteger(e) || e < 0) && g(`Index ${e} must be a whole number from 0`), e > t && g(`Index ${e} is ${n}`)
            }

            function b(e, t) {
                return e.pages.find(e => e.id === t) ? ? g(`No page "${t}"`)
            }

            function y(e, t, n, s) {
                let l = b(e, n),
                    i = l.sections.findIndex(e => e.id === s); - 1 === i && g(`No section "${s}" on page "${n}"`);
                let o = l.sections[i],
                    a = (0, p.Z)(t.sections, o.type) ? ? g(`Unknown section type "${o.type}"`);
                return {
                    page: l,
                    section: o,
                    def: a,
                    index: i
                }
            }

            function $(e, t, n) {
                (0, p.Z)(t.stacks, n) || g(`"${t.label}" has no stack "${n}"`);
                let s = (0, p.Z)(e.stacks, n);
                if (s) return s;
                let l = [];
                return e.stacks[n] = l, l
            }

            function x(e, t) {
                return (0, p.Z)(e.stacks, t) ? ? g(`"${e.label}" has no stack "${t}"`)
            }

            function w(e, t) {
                return (0, p.Z)(e.items, t) ? .label ? ? t
            }

            function S(e, t) {
                let n = e.findIndex(e => e.id === t);
                return -1 === n && g(`No item "${t}"`), {
                    entry: e[n],
                    index: n
                }
            }

            function O(e, t) {
                void 0 !== e.max && t.length >= e.max && g(`"${e.label}" allows at most ${e.max} item(s)`), t.length >= r.jJ && g(`"${e.label}" holds at most ${r.jJ} items`)
            }

            function E(e, t) {
                let n = 0;
                for (; n < t.length && (0, p.Z)(e.sections, t[n].type) ? .pinned === "top";) n++;
                let s = t.length;
                for (; s > n && (0, p.Z)(e.sections, t[s - 1].type) ? .pinned === "bottom";) s--;
                return {
                    first: n,
                    last: s
                }
            }

            function j(e, t, n, s) {
                for (let [l, i] of Object.entries(t)) {
                    let t = e.find(e => e.id === l);
                    t || g(`"${n}" has no field "${l}"`);
                    let o = (0, a.y$)(t, i, s);
                    o && g(o)
                }
            }

            function C(e, t, n, s) {
                let {
                    section: l,
                    def: i
                } = y(e, t, n, s);
                return l.type !== r.aY && g(`"${i.label}" is not a free section; components can only be placed on a free section`), l.elements || (l.elements = []), {
                    section: l,
                    elements: l.elements
                }
            }

            function T(e, t) {
                let n = e.findIndex(e => e.id === t);
                return -1 === n && g(`No component "${t}"`), {
                    element: e[n],
                    index: n
                }
            }

            function A(e, t) {
                let n = (0, s.$V)(e) ? ? g(`Unknown component "${e}"`),
                    l = (0, s.dh)(n, t);
                return l && g(l), n
            }

            function V(e, t) {
                let n = t.limits ? .sectionsPerPage;
                void 0 !== n && e.sections.length >= n && g(`You can have up to ${n} pages`), e.sections.length >= r.C6 && g(`A page holds at most ${r.C6} sections`)
            }

            function P(e, t) {
                let n = t.limits ? .elementsPerSection;
                void 0 !== n && e.length >= n && g(`A page can hold up to ${n} pieces`), e.length >= r.ns && g(`A free section holds at most ${r.ns} components`)
            }
            let U = "This page is phone-only: every piece keeps its own phone box";

            function Z(e, t, n) {
                let s = void 0 !== n.elementId;
                if (s === (void 0 !== n.stackId && void 0 !== n.entryId) && g("An element item needs exactly one element or blocks-entry host"), s) {
                    let {
                        elements: s
                    } = C(e, t, n.pageId, n.sectionId), {
                        element: l
                    } = T(s, n.elementId), i = A(l.component, t).items ? ? g(`"${l.component}" does not support items`);
                    return l.items || (l.items = []), {
                        items: i,
                        list: l.items,
                        owner: l
                    }
                }
                let {
                    section: l,
                    def: i
                } = y(e, t, n.pageId, n.sectionId);
                l.type !== r.WM && g("Element items on entries require a blocks section");
                let o = S($(l, i, n.stackId), n.entryId).entry,
                    a = A(o.kind, t).items ? ? g(`"${o.kind}" does not support items`);
                return o.items || (o.items = []), {
                    items: a,
                    list: o.items,
                    owner: o
                }
            }

            function M(e, t, n) {
                if (!e.items) return;
                let s = n ? ? e.items.seed;
                return (s.length < e.items.min || s.length > e.items.max || s.length > 12) && g(`"${e.label}" needs ${e.items.min} to ${e.items.max} item(s)`), s.map(n => (Object.keys(n).length > 6 && g(`"${e.label}" items allow at most 6 fields`), j(e.items.fields, n, e.label), {
                    id: v(void 0, t, u.RV),
                    values: { ...n
                    }
                }))
            }

            function N(e, t, n, s = !1) {
                let l = (0, d.Aw)(e, t.styleSchema.keys, n, t.label, {
                    override: s
                });
                l && g(l)
            }

            function R(e, t) {
                let n = (0, r.OO)(e, t);
                return n && g(n), (0, r.KD)(e)
            }

            function H(e, t, n, s, l) {
                let i = { ...e
                };
                if (t)
                    for (let [e, n] of (N(t, s, l), Object.entries(t))) void 0 !== n && (i[e] = n);
                for (let e of n ? ? [])(0, d.R$)(e) || g(`Unknown style "${String(e)}"`), t && e in t && g(`Style "${e}" cannot be set and removed in one change`), delete i[e];
                return i
            }

            function Y(e, t, n) {
                (!r.m0.test(e) || e.length > r.hW) && g(`Page path "${e}" must look like /about (lowercase letters, numbers and dashes, at most ${r.hW} characters)`), t.some(t => t.path === e && t.id !== n) && g(`Another page already uses the path "${e}"`)
            }
            let B = `Index 0 is the home page ("${a.Eo}"), which must stay first. Use index 1 or later.`;

            function F(e) {
                "" === e.trim() && g("A page needs a title"), e.length > r.IA && g(`Page titles are limited to ${r.IA} characters`)
            }

            function W(e, t, n) {
                let s = Object.entries(t);
                0 === s.length && g("A style change needs at least one value");
                let l = { ...e
                };
                for (let [e, t] of s) {
                    let s = (0, p.Z)(n.tokens, e) ? ? g(`Unknown theme token "${e}"`);
                    if (null === t) {
                        delete l[e];
                        continue
                    }
                    let i = (0, a.RW)(s, t);
                    i && g(i), l[e] = t
                }
                return Object.keys(l).length > 0 ? l : void 0
            }
            let L = new Set(["addElement", "insertPreset", "addSection"]),
                _ = new Set(["setSectionField", "setItemField", "setSectionHidden", "setSectionTheme", "setItemTheme", "updateElement", "setElementFrame", "moveElementZ", "setElementHidden", "setElementLocked", "updateElementItem", "setFreeHeight", "setItemStyle", "setOffset", "setElementCreator"]);

            function D(e, t, n, d) {
                return function(e, t, n, d, D) {
                    let q = Array.isArray(t) ? t : [t];
                    if (e.template !== n.key) return {
                        ok: !1,
                        error: "Document and template do not match",
                        index: 0
                    };
                    let J = D && q.every(e => _.has(e.op)),
                        Q = J ? { ...e,
                            pages: e.pages.slice()
                        } : structuredClone(e),
                        K = J ? new Set : I(Q);
                    for (let t = 0; t < q.length; t++) try {
                        let f = q[t];
                        J && function(e, t, n, s) {
                            let l = e.pages.findIndex(e => e.id === n);
                            if (-1 === l) return;
                            let i = t.pages[l];
                            e.pages[l] === i && (e.pages[l] = { ...i,
                                sections: i.sections.slice()
                            });
                            let o = e.pages[l].sections,
                                a = o.findIndex(e => e.id === s); - 1 !== a && o[a] === i.sections[a] && (o[a] = structuredClone(o[a]))
                        }(Q, e, f.pageId, f.sectionId);
                        let _ = Q.layouts && L.has(f.op) ? structuredClone(Q) : null;
                        ! function e(t, n, d, f, L) {
                            switch (n.op) {
                                case "setTheme":
                                    {
                                        let e = Object.entries(n.values);
                                        for (let [n, s] of (0 === e.length && g("setTheme needs at least one value"), e)) {
                                            let e = (0, p.Z)(d.tokens, n) ? ? g(`Unknown theme token "${n}"`),
                                                l = (0, a.RW)(e, s);
                                            l && g(l), t.theme[n] = s
                                        }
                                        return
                                    }
                                case "applyPreset":
                                    for (let [e, s] of Object.entries((d.presets.find(e => e.id === n.presetId) ? ? g(`Unknown preset "${n.presetId}"`)).values)) {
                                        let n = (0, p.Z)(d.tokens, e);
                                        if (!n) continue;
                                        let l = (0, a.RW)(n, s);
                                        l && g(l), t.theme[e] = s
                                    }
                                    return;
                                case "setMeta":
                                    void 0 === n.title && void 0 === n.description && g("setMeta needs a title or a description"), void 0 !== n.title && (n.title.length > 120 && g("Site title is limited to 120 characters"), t.meta.title = n.title), void 0 !== n.description && (n.description.length > 300 && g("Site description is limited to 300 characters"), t.meta.description = n.description);
                                    return;
                                case "setSectionField":
                                    {
                                        let {
                                            section: e,
                                            def: s
                                        } = y(t, d, n.pageId, n.sectionId);j(s.fields, {
                                            [n.fieldId]: n.value
                                        }, s.label, L),
                                        e.values[n.fieldId] = n.value;
                                        return
                                    }
                                case "setItemField":
                                    {
                                        let {
                                            section: e,
                                            def: s
                                        } = y(t, d, n.pageId, n.sectionId),
                                        {
                                            entry: l
                                        } = S($(e, s, n.stackId), n.itemId),
                                        i = (0, p.Z)(s.items, l.kind) ? ? g(`Unknown item kind "${l.kind}"`);j(i.fields, {
                                            [n.fieldId]: n.value
                                        }, i.label, L),
                                        l.values[n.fieldId] = n.value;
                                        return
                                    }
                                case "addSection":
                                    {
                                        let e = b(t, n.pageId),
                                            s = (0, p.Z)(d.sections, n.type) ? ? g(`This template has no "${n.type}" section`);V(e, d);
                                        let l = (0, a.vS)(d, n.type, void 0, v(n.id, f, u.H5)) ? ? g(`Cannot create "${n.type}"`);
                                        for (let e of Object.values(l.stacks))
                                            for (let t of e) t.id = v(void 0, f, u.RV);
                                        if (s.pinned) {
                                            e.sections.some(e => e.type === n.type) && g(`The page already has a "${s.label}"`), "top" === s.pinned ? e.sections.unshift(l) : e.sections.push(l);
                                            return
                                        }
                                        let {
                                            first: i,
                                            last: o
                                        } = E(d, e.sections),
                                        r = n.index ? ? o;k(r, o, `outside the movable range ${i}\u2013${o}`),
                                        r < i && g(`Index ${r} is outside the movable range ${i}\u2013${o}`),
                                        e.sections.splice(r, 0, l);
                                        return
                                    }
                                case "duplicateSection":
                                    {
                                        let {
                                            page: e,
                                            section: s,
                                            def: l,
                                            index: i
                                        } = y(t, d, n.pageId, n.sectionId);l.pinned && g(`"${l.label}" cannot be duplicated`),
                                        V(e, d),
                                        e.sections.splice(i + 1, 0, function(e, t, n) {
                                            let s = structuredClone(e);
                                            for (let e of (s.id = v(n, t, u.H5), Object.values(s.stacks)))
                                                for (let n of e)
                                                    for (let e of (n.id = v(void 0, t, u.RV), n.items ? ? [])) e.id = v(void 0, t, u.RV);
                                            for (let e of s.elements ? ? [])
                                                for (let n of (e.id = v(void 0, t, u.Yu), e.items ? ? [])) n.id = v(void 0, t, u.RV);
                                            return s
                                        }(s, f, n.id));
                                        return
                                    }
                                case "removeSection":
                                    {
                                        let {
                                            page: e,
                                            index: s
                                        } = y(t, d, n.pageId, n.sectionId);e.sections.length <= 1 && g("A page needs at least one section"),
                                        e.sections.splice(s, 1);
                                        return
                                    }
                                case "moveSection":
                                    {
                                        let {
                                            page: e,
                                            section: s,
                                            def: l,
                                            index: i
                                        } = y(t, d, n.pageId, n.sectionId);l.pinned && g(`"${l.label}" is pinned and cannot be moved`),
                                        e.sections.splice(i, 1);
                                        let {
                                            first: o,
                                            last: a
                                        } = E(d, e.sections);k(n.toIndex, a, `outside the movable range ${o}\u2013${a}`),
                                        n.toIndex < o && g(`Index ${n.toIndex} is outside the movable range ${o}\u2013${a}`),
                                        e.sections.splice(n.toIndex, 0, s);
                                        return
                                    }
                                case "setSectionHidden":
                                    {
                                        let {
                                            section: e
                                        } = y(t, d, n.pageId, n.sectionId);n.hidden ? e.hidden = !0 : delete e.hidden;
                                        return
                                    }
                                case "addItem":
                                    {
                                        let {
                                            section: e,
                                            def: l
                                        } = y(t, d, n.pageId, n.sectionId),
                                        i = $(e, l, n.stackId),
                                        o = x(l, n.stackId);o.accepts.includes(n.kind) || g(`"${w(l,n.kind)}" is not allowed in "${o.label}"`),
                                        O(o, i);
                                        let c = (0, p.Z)(l.items, n.kind) ? ? g(`Unknown item kind "${n.kind}"`);n.values && j(c.fields, n.values, c.label, L);
                                        let m = (0, a.dv)(l, {
                                                kind: n.kind,
                                                values: n.values
                                            }, v(n.id, f, u.RV)) ? ? g(`Cannot create "${n.kind}"`),
                                            h = e.type === r.WM ? A(n.kind, d) : (0, s.$V)(n.kind);h ? .items && (m.items = M(h, f));
                                        let I = n.index ? ? i.length;k(I, i.length, `past the end of "${o.label}"`),
                                        i.splice(I, 0, m);
                                        return
                                    }
                                case "duplicateItem":
                                    {
                                        let {
                                            section: e,
                                            def: s
                                        } = y(t, d, n.pageId, n.sectionId),
                                        l = $(e, s, n.stackId);O(x(s, n.stackId), l);
                                        let {
                                            entry: i,
                                            index: o
                                        } = S(l, n.itemId),
                                        a = structuredClone(i);a.id = v(n.id, f, u.RV),
                                        l.splice(o + 1, 0, a);
                                        return
                                    }
                                case "removeItem":
                                    {
                                        let {
                                            section: e,
                                            def: s
                                        } = y(t, d, n.pageId, n.sectionId),
                                        l = $(e, s, n.stackId),
                                        i = x(s, n.stackId),
                                        {
                                            index: o
                                        } = S(l, n.itemId);void 0 !== i.min && l.length <= i.min && g(`"${i.label}" needs at least ${i.min} item(s)`),
                                        l.splice(o, 1);
                                        return
                                    }
                                case "moveItem":
                                    {
                                        let {
                                            section: e,
                                            def: s
                                        } = y(t, d, n.pageId, n.sectionId),
                                        l = $(e, s, n.stackId),
                                        {
                                            entry: i,
                                            index: o
                                        } = S(l, n.itemId),
                                        a = n.toStackId ? ? n.stackId,
                                        r = $(e, s, a);
                                        if (a !== n.stackId) {
                                            let e = x(s, n.stackId),
                                                t = x(s, a);
                                            t.accepts.includes(i.kind) || g(`"${w(s,i.kind)}" is not allowed in "${t.label}"`), O(t, r), void 0 !== e.min && l.length <= e.min && g(`"${e.label}" needs at least ${e.min} item(s)`)
                                        }
                                        l.splice(o, 1),
                                        k(n.toIndex, r.length, "past the end of the stack"),
                                        r.splice(n.toIndex, 0, i);
                                        return
                                    }
                                case "setItemHidden":
                                    {
                                        let {
                                            section: e,
                                            def: s
                                        } = y(t, d, n.pageId, n.sectionId),
                                        {
                                            entry: l
                                        } = S($(e, s, n.stackId), n.itemId);n.hidden ? l.hidden = !0 : delete l.hidden;
                                        return
                                    }
                                case "setSectionTheme":
                                    {
                                        let {
                                            section: e
                                        } = y(t, d, n.pageId, n.sectionId);e.theme = W(e.theme, n.values, d),
                                        e.theme || delete e.theme;
                                        return
                                    }
                                case "setItemTheme":
                                    {
                                        let {
                                            section: e,
                                            def: s
                                        } = y(t, d, n.pageId, n.sectionId),
                                        {
                                            entry: l
                                        } = S($(e, s, n.stackId), n.itemId);l.theme = W(l.theme, n.values, d),
                                        l.theme || delete l.theme;
                                        return
                                    }
                                case "setSound":
                                    {
                                        if (null === n.sound) return void delete t.sound;
                                        let e = (0, a.sK)(n.sound, L);e && g(e),
                                        t.sound = (0, a.wp)(n.sound);
                                        return
                                    }
                                case "addElement":
                                    {
                                        let {
                                            section: e,
                                            elements: l
                                        } = C(t, d, n.pageId, n.sectionId);P(l, d);
                                        let i = A(n.component, d);n.values && j(i.fields, n.values, i.label, L),
                                        void 0 === n.items || i.items || g(`"${i.label}" does not support items`);
                                        let o = n.style ? ? {};N(o, i, d);
                                        let a = n.frames ? ? {};null === a.desktop && g("The desktop box cannot be empty");
                                        let c = {
                                            desktop: void 0 !== a.desktop ? R(a.desktop, "Desktop box") : (0, r.$_)(i, e, e => (0, s.$V)(e.component) ? .approxHeight ? ? 6)
                                        };void 0 !== a.tablet && (c.tablet = R(a.tablet, "Tablet box")),
                                        void 0 !== a.phone && ("phone" === d.frame && "auto" === a.phone && g(U), c.phone = "auto" === a.phone ? "auto" : R(a.phone, "Phone box")),
                                        "phone" === d.frame && void 0 === c.phone && (c.phone = { ...c.desktop
                                        });
                                        let m = n.index ? ? l.length;k(m, l.length, `past the top of the section (${l.length})`),
                                        l.splice(m, 0, {
                                            id: v(n.id, f, u.Yu),
                                            component: i.key,
                                            values: { ...(0, s.fM)(i),
                                                ...n.values ? ? {}
                                            },
                                            ...i.items ? {
                                                items: M(i, f, n.items)
                                            } : {},
                                            style: { ...o
                                            },
                                            frames: c
                                        });
                                        return
                                    }
                                case "updateElement":
                                    {
                                        let {
                                            elements: e
                                        } = C(t, d, n.pageId, n.sectionId),
                                        {
                                            element: s
                                        } = T(e, n.elementId),
                                        l = A(s.component, d);
                                        if (void 0 === n.values && void 0 === n.style && (void 0 === n.unsetStyle || 0 === n.unsetStyle.length) && void 0 === n.styleBy && g("updateElement needs values, style, unsetStyle or styleBy"), n.values && (j(l.fields, n.values, l.label, L), Object.assign(s.values, n.values)), (void 0 !== n.style || void 0 !== n.unsetStyle) && (s.style = H(s.style, n.style, n.unsetStyle, l, d)), void 0 !== n.styleBy) {
                                            let e = { ...s.styleBy
                                            };
                                            for (let t of ["tablet", "phone"]) {
                                                let s = n.styleBy[t];
                                                if (void 0 !== s) {
                                                    if (null === s) {
                                                        delete e[t];
                                                        continue
                                                    }
                                                    N(s, l, d, !0), 0 === Object.keys(s).length ? delete e[t] : e[t] = { ...s
                                                    }
                                                }
                                            }
                                            Object.keys(e).length > 0 ? s.styleBy = e : delete s.styleBy
                                        }
                                        return
                                    }
                                case "setElementFrame":
                                    {
                                        let {
                                            elements: e
                                        } = C(t, d, n.pageId, n.sectionId),
                                        {
                                            element: s
                                        } = T(e, n.elementId);
                                        if ((0, r.mT)(n.breakpoint) || g(`Unknown breakpoint "${String(n.breakpoint)}"`), "desktop" === n.breakpoint) {
                                            (null === n.box || "auto" === n.box) && g("The desktop box must be a box"), s.frames.desktop = R(n.box, "Desktop box");
                                            return
                                        }
                                        if ("auto" === n.box && "phone" !== n.breakpoint && g('"auto" is only for the phone layout'), "phone" === d.frame && "phone" === n.breakpoint && (null === n.box || "auto" === n.box) && g(U), null === n.box) return void delete s.frames[n.breakpoint];
                                        if ("auto" === n.box) {
                                            s.frames.phone = "auto";
                                            return
                                        }
                                        s.frames[n.breakpoint] = R(n.box, "tablet" === n.breakpoint ? "Tablet box" : "Phone box");
                                        return
                                    }
                                case "moveElementZ":
                                    {
                                        let {
                                            elements: e
                                        } = C(t, d, n.pageId, n.sectionId),
                                        {
                                            element: s,
                                            index: l
                                        } = T(e, n.elementId);k(n.toIndex, e.length - 1, `outside 0\u2013${e.length-1}`),
                                        e.splice(l, 1),
                                        e.splice(n.toIndex, 0, s);
                                        return
                                    }
                                case "duplicateElement":
                                    {
                                        let {
                                            elements: e
                                        } = C(t, d, n.pageId, n.sectionId);P(e, d);
                                        let {
                                            element: s,
                                            index: l
                                        } = T(e, n.elementId),
                                        i = structuredClone(s);
                                        for (let e of (i.id = v(n.id, f, u.Yu), i.items ? ? [])) e.id = v(void 0, f, u.RV);e.splice(l + 1, 0, i);
                                        return
                                    }
                                case "removeElement":
                                    {
                                        let {
                                            elements: e
                                        } = C(t, d, n.pageId, n.sectionId),
                                        {
                                            index: s
                                        } = T(e, n.elementId);e.splice(s, 1);
                                        return
                                    }
                                case "setElementHidden":
                                    {
                                        let {
                                            elements: e
                                        } = C(t, d, n.pageId, n.sectionId),
                                        {
                                            element: s
                                        } = T(e, n.elementId);n.hidden ? s.hidden = !0 : delete s.hidden;
                                        return
                                    }
                                case "setElementLocked":
                                    {
                                        let {
                                            elements: e
                                        } = C(t, d, n.pageId, n.sectionId),
                                        {
                                            element: s
                                        } = T(e, n.elementId);n.locked ? s.locked = !0 : delete s.locked;
                                        return
                                    }
                                case "addElementItem":
                                    {
                                        let e = Z(t, d, n);
                                        (e.list.length >= e.items.max || e.list.length >= 12) && g(`"${e.items.label}" allows at most ${Math.min(e.items.max,12)} item(s)`);
                                        let s = n.values ? ? e.items.seed[0] ? ? {};Object.keys(s).length > 6 && g(`"${e.items.label}" items allow at most 6 fields`),
                                        j(e.items.fields, s, e.items.label, L);
                                        let l = n.index ? ? e.list.length;k(l, e.list.length, "past the end of the items"),
                                        e.list.splice(l, 0, {
                                            id: v(n.id, f, u.RV),
                                            values: { ...s
                                            }
                                        });
                                        return
                                    }
                                case "updateElementItem":
                                    {
                                        let e = Z(t, d, n),
                                            s = e.list.find(e => e.id === n.itemId) ? ? g(`No element item "${n.itemId}"`);0 === Object.keys(n.values).length && g("updateElementItem needs values"),
                                        j(e.items.fields, n.values, e.items.label, L),
                                        Object.assign(s.values, n.values);
                                        return
                                    }
                                case "moveElementItem":
                                    {
                                        let e = Z(t, d, n),
                                            s = e.list.findIndex(e => e.id === n.itemId);s < 0 && g(`No element item "${n.itemId}"`),
                                        k(n.toIndex, e.list.length - 1, `outside 0\u2013${e.list.length-1}`);
                                        let [l] = e.list.splice(s, 1);e.list.splice(n.toIndex, 0, l);
                                        return
                                    }
                                case "removeElementItem":
                                    {
                                        let e = Z(t, d, n),
                                            s = e.list.findIndex(e => e.id === n.itemId);s < 0 && g(`No element item "${n.itemId}"`),
                                        e.list.length <= e.items.min && g(`"${e.items.label}" needs at least ${e.items.min} item(s)`),
                                        e.list.splice(s, 1);
                                        return
                                    }
                                case "setElementItemHidden":
                                    {
                                        let e = Z(t, d, n).list.find(e => e.id === n.itemId) ? ? g(`No element item "${n.itemId}"`);n.hidden ? e.hidden = !0 : delete e.hidden;
                                        return
                                    }
                                case "insertPreset":
                                    {
                                        let s = (0, o.BG)(n.preset) ? ? g(`Unknown section preset "${n.preset}"`);
                                        (s.product ? ? "folio") !== (d.product ? ? "folio") && g(`Preset "${n.preset}" is not available for this template`);
                                        let l = b(t, n.pageId);V(l, d);
                                        let i = "free" === s.section ? r.aY : r.WM,
                                            c = (0, p.Z)(d.sections, i) ? ? g(`This template has no "${i}" section`);s.values && j(c.fields, s.values, c.label, L);
                                        let m = v(n.id, f, u.H5),
                                            h = (0, a.vS)(d, i, s.values ? {
                                                values: s.values
                                            } : void 0, m) ? ? g(`Cannot create "${i}"`),
                                            {
                                                first: I,
                                                last: y
                                            } = E(d, l.sections),
                                            $ = n.index ? ? y;
                                        for (let i of (k($, y, `outside the movable range ${I}\u2013${y}`), $ < I && g(`Index ${$} is outside the movable range ${I}\u2013${y}`), l.sections.splice($, 0, h), s.height && "free" === s.section && (h.free = {
                                                height: { ...s.height
                                                }
                                            }), s.elements)) "free" === s.section ? e(t, {
                                            op: "addElement",
                                            pageId: n.pageId,
                                            sectionId: m,
                                            component: i.component,
                                            values: i.values,
                                            items: i.items,
                                            style: i.style,
                                            frames: i.frames
                                        }, d, f, L) : e(t, {
                                            op: "addItem",
                                            pageId: n.pageId,
                                            sectionId: m,
                                            stackId: "blocks",
                                            kind: i.component,
                                            values: i.values
                                        }, d, f, L);
                                        return
                                    }
                                case "setFreeHeight":
                                    {
                                        let {
                                            section: e
                                        } = C(t, d, n.pageId, n.sectionId);
                                        (0, r.mT)(n.breakpoint) || g(`Unknown breakpoint "${String(n.breakpoint)}"`);
                                        let s = { ...e.free ? .height ? ? {
                                                desktop: r.VU
                                            }
                                        };
                                        if (null === n.value) "desktop" === n.breakpoint && g("The desktop height cannot be cleared"),
                                        delete s[n.breakpoint];
                                        else {
                                            let e = (0, r.fk)(n.value);
                                            e && g(e), s[n.breakpoint] = n.value
                                        }
                                        e.free = {
                                            height: s
                                        };
                                        return
                                    }
                                case "setItemStyle":
                                    {
                                        let {
                                            section: e,
                                            def: s
                                        } = y(t, d, n.pageId, n.sectionId);e.type !== r.WM && g(`Items in "${s.label}" have no component style`);
                                        let {
                                            entry: l
                                        } = S($(e, s, n.stackId), n.itemId),
                                        i = A(l.kind, d);0 === Object.keys(n.style).length && (void 0 === n.unsetStyle || 0 === n.unsetStyle.length) && g("setItemStyle needs a style or unsetStyle");
                                        let o = H(l.style, n.style, n.unsetStyle, i, d);Object.keys(o).length > 0 ? l.style = o : delete l.style;
                                        return
                                    }
                                case "setOffset":
                                    {
                                        if ((0, c.ku)(d) || g(c.oA), null !== n.offset) {
                                            let e = (0, c.g9)(n.offset);
                                            e && g(e)
                                        }
                                        let e = null === n.offset ? null : (0, c._9)(n.offset),
                                            {
                                                section: s,
                                                def: l
                                            } = y(t, d, n.pageId, n.sectionId),
                                            i = (t, n) => {
                                                let s = { ...t.offsets
                                                };
                                                e ? s[n] = e : delete s[n], Object.keys(s).length > 0 ? t.offsets = s : delete t.offsets
                                            };
                                        if (void 0 !== n.stackId || void 0 !== n.itemId) {
                                            (void 0 === n.stackId || void 0 === n.itemId) && g("setOffset needs both stackId and itemId");
                                            let {
                                                entry: t
                                            } = S($(s, l, n.stackId), n.itemId);
                                            if (void 0 === n.fieldId) return void(e ? t.offset = e : delete t.offset);
                                            let o = (0, p.Z)(l.items, t.kind) ? ? g(`Unknown item kind "${t.kind}"`);
                                            o.fields.some(e => e.id === n.fieldId) || g(`"${o.label}" has no field "${n.fieldId}"`), i(t, n.fieldId);
                                            return
                                        }
                                        void 0 === n.fieldId && g("setOffset needs an item or a field"),
                                        l.fields.some(e => e.id === n.fieldId) || g(`"${l.label}" has no field "${n.fieldId}"`),
                                        i(s, n.fieldId);
                                        return
                                    }
                                case "addPage":
                                    {
                                        "phone" === d.frame && g("This template has one page: add a section instead"),
                                        t.pages.length >= r.Y0 && g(`A site has at most ${r.Y0} pages`),
                                        (0, p.Z)(d.sections, r.aY) || g("This template cannot add pages"),
                                        F(n.title),
                                        Y(n.path, t.pages);
                                        let e = n.index ? ? t.pages.length;k(e, t.pages.length, "past the last page"),
                                        0 === e && g(B);
                                        let s = function(e, t) {
                                                let n = new Set(t.map(e => e.id));
                                                if (void 0 !== e) return u.Yi.test(e) || g(`Id "${e}" is not a valid id`), n.has(e) && g(`Page id "${e}" is already in use`), e;
                                                let s = (0, u.d3)();
                                                for (; n.has(s);) s = (0, u.d3)();
                                                return s
                                            }(n.id, t.pages),
                                            l = (0, a.vS)(d, r.aY, void 0, v(n.sectionId, f, u.H5)) ? ? g("Cannot create a free section");t.pages.splice(e, 0, {
                                            id: s,
                                            path: n.path,
                                            title: n.title,
                                            sections: [l]
                                        });
                                        return
                                    }
                                case "removePage":
                                    {
                                        let e = t.pages.findIndex(e => e.id === n.pageId); - 1 === e && g(`No page "${n.pageId}"`),
                                        t.pages.length <= 1 && g("A site needs at least one page"),
                                        0 === e && g(`The home page ("${a.Eo}") cannot be removed. Remove another page instead.`),
                                        t.pages.splice(e, 1);
                                        return
                                    }
                                case "renamePage":
                                    {
                                        let e = b(t, n.pageId);void 0 === n.title && void 0 === n.path && g("renamePage needs a title or a path"),
                                        void 0 !== n.title && F(n.title),
                                        void 0 !== n.path && e === t.pages[0] && n.path !== a.Eo && g(`The home page's path must stay "${a.Eo}". Rename its title instead, or rename another page's path.`),
                                        void 0 !== n.path && Y(n.path, t.pages, e.id),
                                        void 0 !== n.title && (e.title = n.title),
                                        void 0 !== n.path && (e.path = n.path);
                                        return
                                    }
                                case "movePage":
                                    {
                                        let e = t.pages.findIndex(e => e.id === n.pageId); - 1 === e && g(`No page "${n.pageId}"`),
                                        k(n.toIndex, t.pages.length - 1, `outside 0\u2013${t.pages.length-1}`),
                                        0 === e && 0 !== n.toIndex && g(`The home page ("${a.Eo}") must stay first. Move the other pages around it instead.`),
                                        0 !== e && 0 === n.toIndex && g(B);
                                        let [s] = t.pages.splice(e, 1);t.pages.splice(n.toIndex, 0, s);
                                        return
                                    }
                                case "setElementCreator":
                                    {
                                        "cutiepage" !== d.product && g("Creator styles are for Cutiepage templates only");
                                        let {
                                            elements: e
                                        } = C(t, d, n.pageId, n.sectionId),
                                        {
                                            element: o
                                        } = T(e, n.elementId),
                                        a = { ...o
                                        };
                                        for (let e of h) {
                                            if (!Object.hasOwn(n, e)) continue;
                                            let t = n[e];
                                            null === t ? delete a[e] : a[e] = t
                                        }
                                        let r = l.Oz.safeParse(Object.fromEntries(h.map(e => [e, a[e]])));r.success || g(r.error.issues[0] ? .message ? ? "Invalid creator style");
                                        let c = (0, s.$V)(o.component) ? ? g(`Unknown component "${o.component}"`),
                                            u = (0, i.xd)(d, c, a);
                                        for (let e of (u.error && g(u.error), h)) delete o[e];Object.assign(o, u.ext);
                                        return
                                    }
                                case "setDocumentCss":
                                    {
                                        if ("cutiepage" !== d.product && g("Custom CSS is for Cutiepage templates only"), null === n.css) return void delete t.customCss;
                                        let e = l.ee.safeParse(n.css);e.success || g(e.error.issues[0] ? .message ? ? "Invalid custom CSS"),
                                        t.customCss = e.data;
                                        return
                                    }
                                case "setLogic":
                                    {
                                        if ("cutiepage" !== d.product && g("Interactions are for Cutiepage templates only"), null === n.logic) return void delete t.logic;
                                        let e = l.U5.safeParse(n.logic);e.success || g(e.error.issues[0] ? .message ? ? "Invalid interaction");
                                        let o = (0, i.uq)(d, {
                                            pages: t.pages,
                                            logic: e.data
                                        }, s.$V);o.error && g(o.error),
                                        t.logic = e.data;
                                        return
                                    }
                                case "setFlow":
                                    {
                                        if ("cutiepage" !== d.product && g("The flow map is for Cutiepage templates only"), null === n.flow) return void delete t.flow;
                                        let e = l.Cq.safeParse(n.flow);e.success || g(e.error.issues[0] ? .message ? ? "Invalid flow map");
                                        let o = (0, i.uq)(d, {
                                            pages: t.pages,
                                            flow: e.data
                                        }, s.$V);o.error && g(o.error),
                                        o.flow ? t.flow = o.flow : delete t.flow;
                                        return
                                    }
                                case "setLayoutOwn":
                                    "phone" !== d.frame && g("Only phone-first templates have device layouts"), (0, m.Sn)(n.breakpoint) || g(`Unknown layout "${String(n.breakpoint)}"`), (0, m.VL)(t, d, n.breakpoint, !0 === n.own);
                                    return;
                                case "resetToTemplate":
                                    {
                                        let e = (0, a.ui)(d);
                                        for (let n of (t.version = e.version, t.template = e.template, t.theme = e.theme, t.meta = e.meta, t.pages = e.pages, void 0 !== e.sound ? t.sound = e.sound : delete t.sound, delete t.layouts, delete t.customCss, delete t.logic, delete t.flow, f.clear(), I(t))) f.add(n);
                                        return
                                    }
                            }
                        }(Q, f, n, K, d), _ && (0, m.om)(_, Q, n)
                    } catch (e) {
                        if (e instanceof f) return {
                            ok: !1,
                            error: e.message,
                            index: t
                        };
                        throw e
                    }
                    if (Q.logic && (Q.logic = (0, i.Bb)(Q)), Q.flow) {
                        let e = (0, i.j4)(Q);
                        e ? Q.flow = e : delete Q.flow
                    }
                    return {
                        ok: !0,
                        doc: function e(t, n) {
                            if (t === n) return t;
                            if ("object" != typeof t || "object" != typeof n || null === t || null === n || Array.isArray(t) !== Array.isArray(n)) return n;
                            let s = !0;
                            if (Array.isArray(n)) {
                                t.length !== n.length && (s = !1);
                                for (let l = 0; l < n.length; l++) {
                                    let i = l < t.length ? e(t[l], n[l]) : n[l];
                                    n[l] = i, i !== t[l] && (s = !1)
                                }
                            } else {
                                let l = Object.keys(n);
                                for (let i of (l.length !== Object.keys(t).length && (s = !1), l)) {
                                    let l = Object.hasOwn(t, i) ? e(t[i], n[i]) : n[i];
                                    n[i] = l, l === t[i] && Object.hasOwn(t, i) || (s = !1)
                                }
                            }
                            return s ? t : n
                        }(e, Q)
                    }
                }(e, t, n, d, !0)
            }
        },
        89973: (e, t, n) => {
            n.d(t, {
                Sn: () => i,
                VL: () => f,
                ll: () => o,
                om: () => h
            });
            var s = n(80152);
            let l = ["tablet", "desktop"];

            function i(e) {
                return "desktop" === e || "tablet" === e
            }

            function o(e, t) {
                return e.layouts ? .[t] === !0
            }
            let a = e => Math.round(100 * e) / 100,
                d = (e, [t, n]) => Math.min(n, Math.max(t, e));

            function r(e) {
                return s.Q.phone / s.Q[e]
            }

            function c(e, t) {
                let n = (0, s.UQ)(e, "phone", t);
                return e.free = {
                    height: { ...e.free ? .height ? ? {
                            desktop: n
                        },
                        phone : n
                    }
                }, n
            }

            function u(e, t) {
                var n;
                let l;
                e.frames[t] = (n = function(e) {
                    let t = (0, s.ov)(e);
                    if (t) return t;
                    let n = (0, s.cE)(e, "phone", !1);
                    return e.frames.phone = { ...n
                    }, n
                }(e), {
                    x: a(d((1 - (l = r(t))) / 2 * 100 + n.x * l, s.Vu.x)),
                    y: a(d(n.y * l, s.Vu.y)),
                    w: a(d(n.w * l, s.Vu.w)),
                    h: "auto" === n.h ? "auto" : a(d(n.h * l, s.Vu.h)),
                    ...n.rotate ? {
                        rotate: n.rotate
                    } : {}
                })
            }

            function m(e, t, n) {
                let l = c(e, n);
                for (let n of (e.free.height[t] = a(d(l * r(t), s.lM)), e.elements ? ? [])) u(n, t)
            }

            function p(e) {
                return e.pages.flatMap(e => e.sections.filter(e => void 0 !== e.elements))
            }

            function f(e, t, n, s) {
                if (!s) {
                    if (!e.layouts) return;
                    let {
                        [n]: t, ...s
                    } = e.layouts;
                    Object.keys(s).length > 0 ? e.layouts = s : delete e.layouts;
                    return
                }
                for (let s of p(e)) m(s, n, t);
                e.layouts = { ...e.layouts,
                    [n]: !0
                }
            }

            function h(e, t, n) {
                let i = l.filter(e => o(t, e));
                if (0 === i.length) return;
                let r = new Map;
                for (let t of p(e)) r.set(t.id, new Set((t.elements ? ? []).map(e => e.id)));
                for (let e of p(t)) {
                    let t = r.get(e.id);
                    for (let l of i)
                        if (t)
                            for (let i of e.elements ? ? []) t.has(i.id) || function(e, t, n, l) {
                                let i, o = t.frames[n];
                                o && (i = t.frames.phone, JSON.stringify(o) !== JSON.stringify(i)) || u(t, n);
                                let r = t.frames[n];
                                if ("auto" === r.h) return;
                                let m = (0, s.UQ)(e, n, l),
                                    p = a(r.y + r.h);
                                p > m && (c(e, l), e.free.height[n] = a(d(p, s.lM)))
                            }(e, i, l, n);
                        else m(e, l, n)
                }
            }
        }
    }
]);