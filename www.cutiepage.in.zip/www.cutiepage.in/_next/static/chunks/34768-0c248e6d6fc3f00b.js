"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [34768], {
        2572: (e, t, n) => {
            n.d(t, {
                r0: () => f,
                uS: () => p
            });
            let a = /\.(?:mp3|m4a|mp4|aac|ogg|oga|opus|wav|flac|webm|weba)$/i,
                s = /[\p{Extended_Pictographic}\u{1F1E6}-\u{1F1FF}\u{1F3FB}-\u{1F3FF}\u200d\ufe0e\ufe0f\u20e3]/gu,
                r = /(^|\s)#[^\s#]+/g,
                o = /[([{][^)\]}]*\b(?:official|lyrics?|lyrical|audio|video|visuali[sz]er|aesthetic|hd|hq|4k|remaster(?:ed)?|slowed|reverb|sped|8d|bass\s*boosted)\b[^)\]}]*[)\]}]/gi,
                l = /\b(?:official\s+(?:music\s+)?(?:video|audio)|lyric(?:al)?\s+video|lyrics?|aesthetic\s+video|full\s+(?:song|video)|music\s+video|audio|video|visuali[sz]er|hd|hq|4k|slowed(?:\s*(?:\+|and|&)\s*reverb(?:ed)?)?|reverb(?:ed)?|sped\s+up|8d\s+audio|bass\s+boosted|shorts?(?:\s*feed)?)\b/gi,
                i = /\s+[-\u2013\u2014|~\u2022·]+\s+|\s*[|\u2022·]\s*/;

            function u(e) {
                return e.replace(/\s+/g, " ").replace(/^[\s\-\u2013\u2014|~\u2022·:,.]+|[\s\-\u2013\u2014|~\u2022·:,]+$/g, "").trim()
            }

            function c(e, t = 28) {
                let n = e.trim(),
                    a = [...n];
                if (a.length <= t) return n;
                let s = a.slice(0, t - 1).join(""),
                    r = s.replace(/\s+\S*$/, ""),
                    o = r.length >= .6 * t ? r : s;
                return `${u(o)}\u2026`
            }

            function d(e) {
                return e.replace(a, "").replace(/_+/g, " ").replace(o, " ").replace(r, " ").replace(s, " ").replace(l, " ").replace(/[([{]\s*[)\]}]/g, " ").split(i).map(u).filter(e => e.length > 0).slice(0, 2).join(" \xb7 ")
            }

            function f(e, t = 28) {
                return c(d(e), t)
            }

            function p(e, t, n = 28) {
                let a = (e ? ? "").trim();
                return a ? [...a].length <= n ? a : c(d(a) || a, n) : t
            }
        },
        26244: (e, t, n) => {
            n.d(t, {
                wb: () => s
            });
            let a = ["\u09e6", "\u09e7", "\u09e8", "\u09e9", "\u09ea", "\u09eb", "\u09ec", "\u09ed", "\u09ee", "\u09ef"];

            function s(e) {
                return String(e).replace(/[0-9]/g, e => a[Number(e)])
            }
        },
        34768: (e, t, n) => {
            n.r(t), n.d(t, {
                ElementItemScope: () => ei,
                ElementItems: () => el,
                ElementScope: () => eo,
                FAudio: () => ef,
                FImage: () => ed,
                FLink: () => ep,
                FText: () => ec,
                FolioEditFocusProvider: () => N,
                FolioRenderer: () => T,
                STORY_TURN_MS: () => h,
                Stack: () => V,
                storyTurnFor: () => m,
                useAssetResolver: () => J,
                useAssetUrl: () => X,
                useComponentHost: () => es,
                useEditDispatch: () => P,
                useEditFocusItemId: () => F,
                useElement: () => er,
                useField: () => Z,
                useFieldValues: () => B,
                useFlag: () => z,
                useFolioSiteInfo: () => et,
                useItemPosition: () => K,
                useMode: () => D,
                useMountedAfterHydration: () => H,
                useSectionIndex: () => Q,
                useSectionInstance: () => ea,
                useSite: () => ee,
                useStackCount: () => Y,
                useStackEntryIds: () => U,
                useStory: () => W,
                useTemplate: () => en,
                useText: () => _
            });
            var a = n(73365),
                s = n(1521),
                r = n(83367),
                o = n(85319),
                l = n(32061),
                i = n(44186),
                u = n(77710),
                c = n(82161);
            let d = {
                    slug: null
                },
                f = {
                    active: !1,
                    index: 0,
                    count: 0,
                    next: () => !1,
                    back: () => !1,
                    goTo: () => !1
                },
                p = (0, s.createContext)(f),
                h = 420;

            function m(e, t, n) {
                return n || e === t || e < 0 || t < 0 ? null : {
                    from: e,
                    dir: t > e ? "forward" : "back"
                }
            }
            let g = (0, s.createContext)(null),
                x = (0, s.createContext)(null),
                v = (0, s.createContext)(null),
                y = (0, s.createContext)(null),
                k = (0, s.createContext)(null),
                b = (0, s.createContext)(null),
                C = (e, t) => "edit" === e ? t : {};

            function w(e, t) {
                let n = (0, o.hz)(e, t);
                return n ? {
                    style: n.style,
                    "data-folio-scope": n.scope
                } : {}
            }

            function j(e, t, n) {
                let a = (0, l.CQ)(t);
                return a ? {
                    style: { ...e,
                        translate: a,
                        ...e ? .zIndex === void 0 ? {
                            zIndex: 1
                        } : {}
                    },
                    ...C(n, {
                        "data-folio-moved": ""
                    })
                } : e ? {
                    style: e
                } : {}
            }

            function S(e) {
                let t = (0, s.useContext)(g),
                    n = (0, s.useContext)(v),
                    a = (0, s.useContext)(y),
                    r = (0, s.useContext)(k),
                    o = (0, s.useContext)(b);
                return !t || !(0, l.ku)(t.template) || r || o ? .fields.some(t => t.id === e) ? null : a ? .def.fields.some(t => t.id === e) ? a.entry.offsets ? .[e] ? ? null : n ? .def.fields.some(t => t.id === e) ? n.instance.offsets ? .[e] ? ? null : null
            }
            let M = (0, s.createContext)(null);

            function N({
                value: e,
                children: t
            }) {
                return (0, a.jsx)(M.Provider, {
                    value: e,
                    children: t
                })
            }
            let q = () => () => {},
                E = () => null;

            function F() {
                let e = (0, s.useContext)(M);
                return (0, s.useSyncExternalStore)(e ? .subscribe ? ? q, e ? .getItemId ? ? E, E)
            }

            function P() {
                return (0, s.useContext)(M) ? .dispatch ? ? null
            }

            function T({
                template: e,
                document: t,
                pageId: n,
                mode: r,
                className: l,
                style: u,
                resolveAsset: v,
                storyFocus: y,
                initialStep: k,
                site: b,
                onlySection: C
            }) {
                let w = t.pages.find(e => e.id === n) ? ? t.pages[0],
                    j = w ? w.sections.filter(t => !t.hidden && (0, i.Z)(e.sections, t.type)) : [],
                    S = w ? .layout === "story" && "edit" !== r && j.length > 1,
                    [M, N] = (0, s.useState)(() => Math.max(0, k ? j.findIndex(e => e.id === k) : 0)),
                    q = Math.min(M, Math.max(0, j.length - 1)),
                    E = (0, s.useRef)(null),
                    F = S ? e.storyTransition ? ? null : null,
                    [P, R] = (0, s.useState)(null),
                    [V, Z] = (0, s.useState)("forward"),
                    B = (0, s.useCallback)(e => {
                        if (!S || e < 0 || e >= j.length || e === q) return !1;
                        if (F) {
                            let t = m(q, e, function() {
                                try {
                                    return window.matchMedia("(prefers-reduced-motion: reduce)").matches
                                } catch {
                                    return !1
                                }
                            }());
                            R(t), t && Z(t.dir)
                        }
                        return N(e), !0
                    }, [S, j.length, q, F]);
                (0, s.useEffect)(() => {
                    if (!P) return;
                    let e = setTimeout(() => R(null), h + 80);
                    return () => clearTimeout(e)
                }, [P]);
                let L = P && P.from !== q && P.from < j.length ? P.from : -1,
                    _ = (0, s.useMemo)(() => S ? {
                        active: !0,
                        index: q,
                        count: j.length,
                        next: () => B(q + 1),
                        back: () => B(q - 1),
                        goTo: B
                    } : f, [S, q, j.length, B]),
                    z = j.map(e => e.id).join(" ");
                (0, s.useEffect)(() => {
                    if (!S || !y) return;
                    let e = z.split(" ").indexOf(y);
                    if (e < 0) return;
                    let t = setTimeout(() => N(e), 0);
                    return () => clearTimeout(t)
                }, [S, y, z]);
                let D = (0, s.useRef)(q);
                (0, s.useEffect)(() => {
                    if (!S || D.current === q) return;
                    D.current = q;
                    let e = E.current;
                    e && e.getBoundingClientRect().top < 0 && e.scrollIntoView({
                        block: "start",
                        behavior: "smooth"
                    })
                }, [S, q]);
                let G = (0, c.useStandsInForPage)(r),
                    H = b ? .slug ? ? null,
                    K = (0, s.useMemo)(() => ({
                        template: e,
                        mode: r,
                        resolveAsset: v,
                        site: null === H ? d : {
                            slug: H
                        }
                    }), [e, r, v, H]),
                    Q = (0, s.useMemo)(() => w ? {
                        document: t,
                        page: w
                    } : null, [t, w]);
                if (!w) return null;
                let U = G && e.intro ? w.sections.findIndex(t => t.type === e.intro.section) : -1,
                    Y = U >= 0 ? w.sections[U] : null,
                    W = e.intro ? .render,
                    X = "edit" === r && e.intro ? w.sections.find(t => t.type === e.intro.section) ? .id : void 0,
                    J = e.ownsSound ? null : t.sound ? ? null,
                    ee = (0, c.hasPlayableSound)(J, r),
                    et = (0, o.av)(e, w.sections);
                return (0, a.jsx)(g.Provider, {
                    value: K,
                    children: (0, a.jsx)(x.Provider, {
                        value: Q,
                        children: (0, a.jsx)(p.Provider, {
                            value: _,
                            children: (0, a.jsx)(c.FolioSoundProvider, {
                                sound: J,
                                mode: r,
                                resolveSrc: v,
                                lang: e.lang,
                                children: (0, a.jsxs)($, {
                                    template: e,
                                    document: t,
                                    mode: r,
                                    className: l,
                                    style: u,
                                    rootRef: E,
                                    listenForGesture: ee,
                                    storyMode: S,
                                    transitionAttrs: F ? {
                                        "data-folio-transition": F,
                                        "data-folio-turn": V,
                                        ...L >= 0 ? {
                                            "data-folio-turning": ""
                                        } : {}
                                    } : void 0,
                                    children: [Y && W ? (0, a.jsx)(A, {
                                        instance: Y,
                                        def: (0, i.Z)(e.sections, Y.type),
                                        index: U,
                                        Intro: W
                                    }) : null, j.map((t, n) => C && "edit" === r && t.id !== C ? null : (0, a.jsx)(I, {
                                        instance: t,
                                        def: (0, i.Z)(e.sections, t.type),
                                        index: n,
                                        template: e,
                                        mode: r,
                                        anchor: et.get(t.id),
                                        hidden: S && n !== q && n !== L,
                                        leaving: n === L,
                                        Intro: W && t.id === X ? W : void 0
                                    }, t.id)), S && "none" !== e.storyNav ? (0, a.jsx)(O, {
                                        template: e,
                                        sections: j
                                    }) : null]
                                })
                            })
                        })
                    })
                })
            }

            function R(e, t, n) {
                return (0, s.useMemo)(() => ({
                    instance: e,
                    def: t,
                    index: n
                }), [e, t, n])
            }
            let A = (0, s.memo)(function({
                    instance: e,
                    def: t,
                    index: n,
                    Intro: s
                }) {
                    return (0, a.jsx)(v.Provider, {
                        value: R(e, t, n),
                        children: (0, a.jsx)(s, {})
                    })
                }),
                I = (0, s.memo)(function({
                    instance: e,
                    def: t,
                    index: n,
                    template: s,
                    mode: r,
                    anchor: o,
                    hidden: l,
                    leaving: i,
                    Intro: u
                }) {
                    let c = R(e, t, n),
                        d = t.render,
                        f = t.entrance && "none" !== t.entrance ? t.entrance : null,
                        p = f ? `folio-section folio-enter-${f}` : "folio-section",
                        h = w(s, e.theme);
                    return (0, a.jsx)(v.Provider, {
                        value: c,
                        children: (0, a.jsxs)("div", {
                            className: p,
                            ...o ? {
                                id: o
                            } : {},
                            ...h,
                            ...l ? {
                                hidden: !0
                            } : {},
                            ...i ? {
                                "data-folio-leaving": "",
                                "aria-hidden": !0,
                                inert: !0
                            } : {},
                            ...C(r, {
                                "data-folio-section": e.id
                            }),
                            children: [u ? (0, a.jsx)(u, {}) : null, (0, a.jsx)(d, {})]
                        })
                    })
                });

            function $({
                template: e,
                document: t,
                mode: n,
                className: s,
                style: r,
                rootRef: l,
                listenForGesture: i,
                storyMode: u,
                transitionAttrs: d,
                children: f
            }) {
                let p = (0, c.useFolioSound)(),
                    h = i ? e => p.unlock(e.target) : void 0,
                    m = (0, o.un)(e, t.theme),
                    g = "phone" === e.frame,
                    x = (0, a.jsxs)("div", {
                        ref: l,
                        "data-folio-root": "",
                        "data-folio-template": e.key,
                        "data-folio-mode": n,
                        ...e.lang ? {
                            lang: e.lang
                        } : {},
                        ...u ? {
                            "data-folio-layout": "story"
                        } : {},
                        ...u && e.storyNav ? {
                            "data-folio-story-nav": e.storyNav
                        } : {},
                        ...e.soundChip ? {
                            "data-folio-sound-chip": e.soundChip
                        } : {},
                        ...d,
                        className: g ? "@container folio-site" : `@container folio-site ${s??""}`,
                        style: g ? m : { ...m,
                            ...r
                        },
                        onPointerDownCapture: h,
                        onClickCapture: h,
                        onKeyDownCapture: h,
                        children: [f, p.chip]
                    });
                return g ? (0, a.jsx)("div", {
                    "data-folio-frame": "phone",
                    "data-folio-template": e.key,
                    ...t.layouts ? .desktop ? {
                        "data-own-desktop": ""
                    } : {},
                    ...t.layouts ? .tablet ? {
                        "data-own-tablet": ""
                    } : {},
                    className : `folio-phone-frame ${s??""}`,
                    style : { ...m,
                        ...r
                    },
                    children: x
                }) : x
            }

            function O({
                template: e,
                sections: t
            }) {
                let n = (0, s.useContext)(p),
                    r = (0, s.useContext)(g),
                    o = (0, c.useFolioSound)(),
                    l = t[n.index],
                    d = !!l && (0, i.Z)(e.sections, l.type) ? .ownsStoryNext === !0,
                    f = n.index >= n.count - 1,
                    h = (0, u.G)(e.lang),
                    {
                        next: m,
                        back: x
                    } = n;
                return (0, s.useEffect)(() => {
                    if (r ? .mode !== "published") return;
                    let e = e => {
                        let t = e.target;
                        !(t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) && ("ArrowRight" !== e.key || d ? "ArrowLeft" === e.key && x() : m() && o.playEffect("next"))
                    };
                    return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e)
                }, [r ? .mode, m, x, d, o]), (0, a.jsxs)("nav", {
                    className: "folio-story-nav",
                    "aria-label": h.storyLabel,
                    children: [(0, a.jsx)("button", {
                        type: "button",
                        className: "folio-story-button",
                        onClick: () => n.back(),
                        disabled: 0 === n.index,
                        "aria-label": h.previous,
                        children: "\u2039"
                    }), (0, a.jsx)("ol", {
                        className: "folio-story-dots",
                        "aria-label": h.step(n.index + 1, n.count),
                        children: t.map((e, t) => (0, a.jsx)("li", {
                            "aria-current": t === n.index ? "step" : void 0
                        }, e.id))
                    }), (0, a.jsx)("button", {
                        type: "button",
                        className: "folio-story-button",
                        onClick: () => {
                            n.next() && o.playEffect("next")
                        },
                        disabled: f || d,
                        "aria-label": h.next,
                        children: "\u203a"
                    })]
                })
            }

            function V({
                id: e,
                className: t,
                itemClassName: n,
                style: r,
                as: o = "div"
            }) {
                let u = (0, s.useContext)(g),
                    c = (0, s.useContext)(v);
                if (!u || !c) return null;
                let d = (0, i.Z)(c.def.stacks, e);
                if (!d) return null;
                let f = ((0, i.Z)(c.instance.stacks, e) ? ? []).filter(e => !e.hidden && d.accepts.includes(e.kind) && (0, i.Z)(c.def.items, e.kind));
                return (0, a.jsx)(o, {
                    className: t,
                    style: r,
                    ...C(u.mode, {
                        "data-folio-stack": e,
                        "data-folio-axis": d.axis
                    }),
                    children: f.map((t, s) => {
                        let r = (0, i.Z)(c.def.items, t.kind),
                            o = r.render,
                            d = "function" == typeof n ? n(s) : n,
                            p = w(u.template, t.theme),
                            h = (0, l.ku)(u.template) ? t.offset : void 0;
                        return (0, a.jsx)(y.Provider, {
                            value: {
                                stackId: e,
                                entry: t,
                                def: r,
                                index: s,
                                count: f.length
                            },
                            children: (0, a.jsx)("div", {
                                className: `folio-item${d?` ${d}`:""}`,
                                ...p,
                                ...j(p.style, h, u.mode),
                                ...C(u.mode, {
                                    "data-folio-item": t.id
                                }),
                                children: (0, a.jsx)(o, {})
                            })
                        }, t.id)
                    })
                })
            }

            function Z(e) {
                return L((0, s.useContext)(v), (0, s.useContext)(y), (0, s.useContext)(k), (0, s.useContext)(b), e)
            }

            function B(e) {
                let t = (0, s.useContext)(v),
                    n = (0, s.useContext)(y),
                    a = (0, s.useContext)(k),
                    r = (0, s.useContext)(b),
                    o = {};
                for (let s of e) o[s] = L(t, n, a, r, s);
                return o
            }

            function L(e, t, n, a, s) {
                if (a) {
                    let e = a.fields.find(e => e.id === s);
                    if (e) return a.item.values ? .[s] ? ? e.default
                }
                if (n) {
                    let e = n.fields.find(e => e.id === s);
                    if (e) return n.element.values ? .[s] ? ? e.default
                }
                if (t) {
                    let e = t.def.fields.find(e => e.id === s);
                    if (e) return t.entry.values[s] ? ? e.default
                }
                if (e) {
                    let t = e.def.fields.find(e => e.id === s);
                    if (t) return e.instance.values[s] ? ? t.default
                }
            }

            function _(e) {
                let t = Z(e);
                return "string" == typeof t ? t : ""
            }

            function z(e) {
                return !0 === Z(e)
            }

            function D() {
                return (0, s.useContext)(g) ? .mode ? ? "published"
            }
            let G = () => () => {};

            function H() {
                let [e] = (0, s.useState)((0, s.useSyncExternalStore)(G, () => !0, () => !1));
                return e
            }

            function K() {
                let e = (0, s.useContext)(y);
                return {
                    index: e ? .index ? ? 0,
                    count: e ? .count ? ? 0
                }
            }

            function Q() {
                return (0, s.useContext)(v) ? .index ? ? 0
            }

            function U(e) {
                let t = (0, s.useContext)(v);
                if (!t) return [];
                let n = (0, i.Z)(t.def.stacks, e);
                return ((0, i.Z)(t.instance.stacks, e) ? ? []).filter(e => !e.hidden && (!n || n.accepts.includes(e.kind)) && (0, i.Z)(t.def.items, e.kind)).map(e => e.id)
            }

            function Y(e) {
                let t = (0, s.useContext)(v);
                return ((0, i.Z)(t ? .instance.stacks, e) ? ? []).filter(e => !e.hidden).length
            }

            function W() {
                return (0, s.useContext)(p)
            }

            function X(e) {
                let t = (0, s.useContext)(g),
                    n = _(e);
                return n ? t ? .resolveAsset ? t.resolveAsset(n) ? ? "" : n : ""
            }

            function J() {
                let e = (0, s.useContext)(g);
                return t => t ? e ? .resolveAsset ? e.resolveAsset(t) ? ? "" : t : ""
            }

            function ee() {
                return (0, s.useContext)(x)
            }

            function et() {
                return (0, s.useContext)(g) ? .site ? ? d
            }

            function en() {
                return (0, s.useContext)(g) ? .template ? ? null
            }

            function ea() {
                return (0, s.useContext)(v) ? .instance ? ? null
            }

            function es() {
                let e = (0, s.useContext)(v),
                    t = (0, s.useContext)(y),
                    n = (0, s.useContext)(k);
                return n ? {
                    kind: "element",
                    id: n.element.id,
                    style: n.element.style,
                    styleBy: n.element.styleBy
                } : t ? {
                    kind: "item",
                    id: t.entry.id,
                    style: t.entry.style
                } : e ? {
                    kind: "section",
                    id: e.instance.id
                } : null
            }

            function er() {
                return (0, s.useContext)(k) ? .element ? ? null
            }

            function eo({
                element: e,
                fields: t,
                children: n
            }) {
                return (0, a.jsx)(k.Provider, {
                    value: {
                        element: e,
                        fields: t
                    },
                    children: n
                })
            }

            function el({
                children: e
            }) {
                let t = (0, s.useContext)(k),
                    n = (0, s.useContext)(y),
                    r = t ? eu(t.element.component) ? ? [] : n ? eu(n.entry.kind) ? ? [] : [],
                    o = t ? .element.items ? ? n ? .entry.items ? ? [];
                return (0, a.jsx)(a.Fragment, {
                    children: o.filter(e => !e.hidden).map((t, n, s) => (0, a.jsx)(ei, {
                        item: t,
                        fields: r,
                        index: n,
                        count: s.length,
                        children: e(t, n, s.length)
                    }, t.id))
                })
            }

            function ei({
                item: e,
                fields: t,
                index: n,
                count: s,
                children: r
            }) {
                let o = D();
                return (0, a.jsx)(b.Provider, {
                    value: {
                        item: e,
                        fields: t,
                        index: n,
                        count: s
                    },
                    children: (0, a.jsx)("div", { ...C(o, {
                            "data-folio-element-item": e.id
                        }),
                        children: r
                    })
                })
            }

            function eu(e) {
                return (0, r.$V)(e) ? .items ? .fields ? ? null
            }

            function ec({
                field: e,
                as: t = "span",
                className: n,
                style: r,
                part: o
            }) {
                let l = D(),
                    i = (0, s.useContext)(v),
                    u = (0, s.useContext)(y),
                    c = (0, s.useContext)(k),
                    d = _(e),
                    f = S(e);
                return d || "edit" === l ? (0, a.jsx)(t, {
                    className: `folio-text${n?` ${n}`:""}`,
                    style: r,
                    ...o ? {
                        "data-cp-part": o
                    } : {},
                    ...j(r, f, l),
                    ...C(l, {
                        "data-folio-field": e,
                        "data-folio-placeholder": c ? .fields.find(t => t.id === e) ? .label ? ? u ? .def.fields.find(t => t.id === e) ? .label ? ? i ? .def.fields.find(t => t.id === e) ? .label ? ? e
                    }),
                    children: d
                }) : null
            }

            function ed({
                field: e,
                className: t,
                style: n,
                alt: s,
                altField: r,
                priority: o = !1,
                part: l
            }) {
                let i = D(),
                    u = X(e),
                    c = _(r ? ? ""),
                    d = { ...l ? {
                            "data-cp-part": l
                        } : {},
                        ...j(n, S(e), i),
                        ...C(i, {
                            "data-folio-field": e
                        })
                    };
                return u ? (0, a.jsx)("img", {
                    src: u,
                    alt: r ? c : s ? ? "",
                    className: t,
                    style: n,
                    loading: o ? "eager" : "lazy",
                    fetchPriority: o ? "high" : void 0,
                    decoding: "async",
                    draggable: !1,
                    ...d
                }) : "edit" !== i ? null : (0, a.jsx)("div", {
                    className: `folio-image-empty${t?` ${t}`:""}`,
                    style: n,
                    ...d
                })
            }

            function ef({
                field: e,
                className: t,
                style: n,
                part: s
            }) {
                let r = D(),
                    o = X(e),
                    l = { ...s ? {
                            "data-cp-part": s
                        } : {},
                        ...j(n, S(e), r),
                        ...C(r, {
                            "data-folio-field": e
                        })
                    };
                return o ? (0, a.jsx)("audio", {
                    src: o,
                    controls: !0,
                    preload: "none",
                    className: t,
                    style: n,
                    ...l
                }) : "edit" !== r ? null : (0, a.jsx)("div", {
                    className: `folio-image-empty folio-audio-empty${t?` ${t}`:""}`,
                    style: n,
                    ...l
                })
            }

            function ep({
                field: e,
                className: t,
                style: n,
                children: s,
                part: r,
                onClick: o
            }) {
                let l = D(),
                    i = _(e),
                    u = S(e),
                    c = /^https?:\/\//i.test(i);
                return (0, a.jsx)("a", {
                    href: i || "#",
                    className: t,
                    style: n,
                    ...r ? {
                        "data-cp-part": r
                    } : {},
                    ...o ? {
                        onClick: o
                    } : {},
                    ...j(n, u, l),
                    ...c ? {
                        target: "_blank",
                        rel: "noopener noreferrer"
                    } : {},
                    ...C(l, {
                        "data-folio-link": e
                    }),
                    children: s
                })
            }
        },
        77710: (e, t, n) => {
            n.d(t, {
                G: () => o
            });
            var a = n(26244);
            let s = {
                    storyLabel: "Story",
                    previous: "Previous",
                    next: "Next",
                    step: (e, t) => `Step ${e} of ${t}`,
                    pauseMusic: "Pause music",
                    playMusic: "Play music",
                    musicOn: "Music on",
                    playOurSong: "Play our song",
                    soundsOn: "Turn sounds on",
                    muteSounds: "Mute sounds",
                    soundOn: "Sound on",
                    soundOff: "Sound off"
                },
                r = {
                    storyLabel: "\u0997\u09b2\u09cd\u09aa",
                    previous: "\u0986\u0997\u09c7\u09b0 \u09aa\u09be\u09a4\u09be",
                    next: "\u09aa\u09b0\u09c7\u09b0 \u09aa\u09be\u09a4\u09be",
                    step: (e, t) => `${(0,a.wb)(t)}-\u098f\u09b0 \u09ae\u09a7\u09cd\u09af\u09c7 ${(0,a.wb)(e)} \u09a8\u09ae\u09cd\u09ac\u09b0 \u09aa\u09be\u09a4\u09be`,
                    pauseMusic: "\u0997\u09be\u09a8 \u09a5\u09be\u09ae\u09be\u0993",
                    playMusic: "\u0997\u09be\u09a8 \u099a\u09be\u09b2\u09be\u0993",
                    musicOn: "\u0997\u09be\u09a8 \u099a\u09b2\u099b\u09c7",
                    playOurSong: "\u0997\u09be\u09a8\u099f\u09be \u099a\u09be\u09b2\u09be\u0993",
                    soundsOn: "\u09b6\u09ac\u09cd\u09a6 \u099a\u09be\u09b2\u09c1 \u0995\u09b0\u09cb",
                    muteSounds: "\u09b6\u09ac\u09cd\u09a6 \u09ac\u09a8\u09cd\u09a7 \u0995\u09b0\u09cb",
                    soundOn: "\u09b6\u09ac\u09cd\u09a6 \u099a\u09be\u09b2\u09c1",
                    soundOff: "\u09b6\u09ac\u09cd\u09a6 \u09ac\u09a8\u09cd\u09a7"
                };

            function o(e) {
                return "bn" === e ? r : s
            }
        },
        78922: (e, t, n) => {
            n.d(t, {
                DA: () => r,
                ZS: () => P,
                tN: () => a
            });
            let a = {
                    default: .9,
                    min: .3,
                    max: 1.6
                },
                s = {
                    unlock: "open",
                    switch: "tap",
                    puff: "reveal",
                    cut: "pop",
                    shake: "tick",
                    popper: "confetti",
                    charge: "reveal",
                    shutter: "tap",
                    horn: "win",
                    dhol: "tap",
                    dhamak: "pop",
                    clack: "tap",
                    jingle: "confetti",
                    rustle: "next",
                    stamp: "pop",
                    fanfare: "win",
                    dhaak: "tap",
                    dhaakRoll: "confetti",
                    kashor: "reveal",
                    shankh: "win",
                    ghonta: "confetti",
                    crunch: "pop",
                    plop: "tap"
                },
                r = {
                    none: "No effects",
                    soft: "Soft chimes",
                    sparkle: "Sparkle",
                    y2k: "Y2K arcade",
                    party: "Party",
                    garba: "Garba (dhol + dandiya)",
                    pujo: "Pujo (dhaak + kashor + shankh)"
                },
                o = (e, t, n, a, s = "sine") => ({
                    frequency: e,
                    start: t,
                    duration: n,
                    gain: a,
                    wave: s
                }),
                l = (e, t, n, a, s, r = "sine") => ({
                    frequency: e,
                    to: t,
                    start: n,
                    duration: a,
                    gain: s,
                    wave: r
                }),
                i = (e, t, n, a, s, r) => ({
                    frequency: t,
                    start: n,
                    duration: a,
                    gain: s,
                    wave: "noise",
                    filter: e,
                    ...r ? {
                        to: r
                    } : {}
                }),
                u = {
                    open: [i("highpass", 3e3, 0, .05, .12), o(1046.5, .03, .3, .11, "triangle"), o(1318.51, .09, .4, .08, "triangle")],
                    reveal: [o(1046.5, 0, .22, .1, "triangle"), o(1318.51, .07, .26, .09, "triangle"), o(1567.98, .14, .45, .07, "triangle")],
                    scratch: [i("highpass", 2600, 0, .05, .07)],
                    next: [i("bandpass", 3200, 0, .12, .07, 1400), o(1318.51, .04, .1, .04)],
                    tick: [o(1318.51, 0, .025, .04, "triangle")],
                    tap: [i("highpass", 2400, 0, .018, .08), o(783.99, 0, .07, .07, "triangle")],
                    pop: [l(440, 880, 0, .08, .16), i("highpass", 3e3, 0, .02, .06)],
                    win: [o(523.25, 0, .14, .09, "triangle"), o(659.25, .08, .14, .09, "triangle"), o(783.99, .16, .14, .09, "triangle"), o(1046.5, .24, .5, .09, "triangle"), o(1318.51, .3, .5, .05)],
                    boot: [l(523.25, 1046.5, 0, .35, .09), o(1318.51, .3, .45, .07, "triangle"), o(1567.98, .38, .45, .05)],
                    confetti: [i("highpass", 2e3, 0, .09, .14, 5e3), o(1318.51, .05, .12, .05), o(1567.98, .1, .14, .05), o(2093, .15, .22, .04)],
                    nope: [l(659.25, 523.25, 0, .26, .09, "triangle")],
                    unlock: [i("highpass", 4e3, 0, .025, .16), i("bandpass", 1800, .05, .03, .12), o(783.99, .08, .22, .09), o(1046.5, .15, .4, .08)],
                    switch: [i("highpass", 3200, 0, .02, .22), i("bandpass", 1200, .045, .03, .16), o(1318.51, .1, .5, .04)],
                    puff: [i("lowpass", 900, 0, .45, .2, 220)],
                    cut: [i("bandpass", 1800, 0, .26, .15, 6e3), l(110, 98, .22, .14, .22)],
                    shake: [i("bandpass", 1600, 0, .06, .15), i("bandpass", 2200, .09, .06, .13), i("bandpass", 1600, .18, .06, .15), l(261.63, 392, 0, .08, .08, "triangle")],
                    popper: [i("highpass", 1800, 0, .11, .25), l(523.25, 1046.5, .02, .16, .1), o(1318.51, .14, .14, .06), o(1567.98, .2, .16, .05), o(2093, .26, .3, .04)],
                    charge: [l(523.25, 1046.5, 0, .9, .08), l(783.99, 1567.98, 0, .9, .04, "triangle"), i("highpass", 6e3, .3, .6, .03)],
                    shutter: [i("highpass", 2500, 0, .025, .2), i("bandpass", 1100, .06, .04, .16)],
                    horn: [l(523.25, 587.33, 0, .13, .06, "sawtooth"), l(783.99, 880, .15, .5, .06, "sawtooth"), i("bandpass", 1500, .15, .4, .03)]
                },
                c = {
                    dhol: "shake",
                    dhamak: "shutter",
                    clack: "tap",
                    jingle: "popper",
                    rustle: "next",
                    stamp: "cut",
                    fanfare: "horn",
                    dhaak: "shake",
                    dhaakRoll: "shake",
                    kashor: "popper",
                    shankh: "horn",
                    ghonta: "popper",
                    crunch: "cut",
                    plop: "puff"
                },
                d = (e, t, n, a, s) => ({
                    frequency: e,
                    ...t ? {
                        to: t
                    } : {},
                    start: n,
                    duration: a,
                    gain: s,
                    wave: "sawtooth",
                    cutoff: 2400,
                    vibrato: {
                        rate: 6,
                        cents: 22
                    }
                }),
                f = [l(150, 68, 0, .24, .3), l(260, 175, 0, .09, .12, "triangle"), i("lowpass", 900, 0, .03, .12)],
                p = [i("bandpass", 2300, 0, .06, .2), l(340, 290, 0, .09, .06, "triangle")],
                h = (e, t) => [i("highpass", 6e3, e, .04, t), o(2959.96, e, .45, .45 * t), o(2966.96, e, .4, .35 * t), o(3520, e, .35, .3 * t), o(4698.64, e, .3, .22 * t)],
                m = (e, t) => [i("bandpass", 2600, e, .025, t), o(1174.66, e, .035, .4 * t, "triangle")],
                g = [i("bandpass", 2200, 0, .1, .08, 4200), i("bandpass", 3600, .07, .12, .06, 1800), i("highpass", 5e3, .15, .05, .035)],
                x = [i("highpass", 2800, 0, .015, .1), i("lowpass", 500, 0, .09, .28, 200), l(120, 55, 0, .16, .28), l(240, 160, 0, .06, .1, "triangle")],
                v = [o(1174.66, 0, .55, .08), o(1479.98, .06, .5, .06), o(1760, .12, .6, .05)],
                y = {
                    open: [...g, ...h(.12, .1)],
                    reveal: [...v, ...h(0, .06)],
                    scratch: [i("bandpass", 3800, 0, .05, .07, 2600)],
                    next: g,
                    tick: [i("bandpass", 3200, 0, .012, .09), o(1760, 0, .015, .025, "triangle")],
                    tap: m(0, .16),
                    pop: [i("highpass", 4e3, 0, .012, .08), o(1760, 0, .12, .06, "triangle")],
                    win: [...v, d(880, 987.77, .22, .14, .045), d(1174.66, void 0, .36, .5, .05)],
                    boot: [...f, ...h(.1, .08), d(587.33, 739.99, .1, .5, .045)],
                    confetti: [...h(0, .12), ...h(.1, .09)],
                    nope: [o(880, 0, .16, .07, "triangle"), l(739.99, 659.25, .14, .3, .07, "triangle")],
                    unlock: [...g, ...h(.12, .1)],
                    switch: m(0, .18),
                    puff: [i("lowpass", 900, 0, .42, .14, 240)],
                    cut: x,
                    shake: f,
                    popper: [...m(0, .2), ...h(.05, .12)],
                    charge: [l(587.33, 1174.66, 0, .7, .06), i("highpass", 6e3, .25, .5, .03)],
                    shutter: [...f, ...p],
                    horn: [d(440, 493.88, 0, .12, .05), d(587.33, void 0, .12, .14, .055), d(659.25, 739.99, .26, .55, .055)],
                    dhol: f,
                    dhamak: [...f, ...p],
                    clack: m(0, .2),
                    jingle: [...h(0, .12), ...h(.09, .09)],
                    rustle: g,
                    stamp: x,
                    dhaak: f,
                    dhaakRoll: [...f, ...p],
                    kashor: [...h(0, .12), ...h(.09, .09)],
                    shankh: [d(440, 493.88, 0, .12, .05), d(587.33, void 0, .12, .14, .055), d(659.25, 739.99, .26, .55, .055)],
                    ghonta: v,
                    crunch: m(0, .16),
                    plop: [i("highpass", 4e3, 0, .012, .08), o(1760, 0, .12, .06, "triangle")],
                    fanfare: [...f, d(440, 493.88, 0, .12, .05), d(587.33, void 0, .12, .14, .055), d(659.25, 739.99, .26, .6, .055), ...h(.26, .09)]
                },
                k = (e, t) => [l(118, 52, e, .3, t), l(210, 128, e, .1, .38 * t, "triangle"), i("lowpass", 700, e, .035, .4 * t)],
                b = (e, t) => [i("bandpass", 3100, e, .03, t)],
                C = [...k(0, .28), ...b(0, .18)],
                w = [...k(0, .15), ...[0, .065, .13, .19, .25, .32].map((e, t) => b(e, .06 + .015 * t)[0]), ...k(.32, .17)],
                j = (e, t) => [i("highpass", 3500, e, .03, .9 * t), o(612, e, .9, .55 * t), o(1497, e, .75, .4 * t), o(2342, e, .55, .3 * t), o(3277, e, .4, .2 * t)],
                S = [0, .13, .26].flatMap((e, t) => [o(1174.66, e, .42, .07 - .012 * t), o(2640, e, .3, .035 - .006 * t), i("highpass", 6500, e, .015, .05)]);

            function M(e) {
                let t = Math.min(a.max, Math.max(a.min, e)),
                    n = .7 * t;
                return [{
                    frequency: 293.66,
                    to: 295.42196,
                    start: 0,
                    duration: t,
                    gain: .065,
                    wave: "sawtooth",
                    cutoff: 1300,
                    vibrato: {
                        rate: 4.5,
                        cents: 14
                    },
                    attack: n
                }, {
                    frequency: 587.33,
                    start: .04,
                    duration: t - .04,
                    gain: .03,
                    wave: "sawtooth",
                    cutoff: 2200,
                    vibrato: {
                        rate: 4.5,
                        cents: 14
                    },
                    attack: n
                }, {
                    frequency: 880,
                    start: .06,
                    duration: t - .06,
                    gain: .03,
                    wave: "sine",
                    attack: n
                }, i("bandpass", 1100, 0, t, .03)]
            }
            let N = [i("bandpass", 1900, 0, .05, .2), i("highpass", 3600, .03, .04, .12), i("bandpass", 1200, .07, .05, .1)],
                q = [l(330, 220, 0, .1, .16), i("lowpass", 700, 0, .05, .1), i("highpass", 4200, .02, .025, .04)],
                E = { ...y,
                    open: [...C, ...j(.06, .1)],
                    tap: b(0, .2),
                    pop: q,
                    win: [...v, ...k(.2, .2)],
                    boot: [...C, ...j(.06, .08)],
                    confetti: S,
                    switch: b(0, .2),
                    popper: [...b(0, .18), ...S],
                    shake: C,
                    shutter: C,
                    dhol: C,
                    dhamak: [...C, ...b(.09, .14)],
                    clack: b(0, .2),
                    jingle: S,
                    fanfare: [...M(.7), ...k(.1, .2)],
                    dhaak: C,
                    dhaakRoll: w,
                    kashor: j(0, .14),
                    shankh: M(a.default),
                    ghonta: S,
                    crunch: N,
                    plop: q
                },
                F = {
                    soft: {
                        open: [o(523.25, 0, .5, .18), o(783.99, .09, .6, .14)],
                        reveal: [o(659.25, 0, .45, .16), o(880, .08, .55, .12)],
                        scratch: [o(587.33, 0, .08, .05, "triangle")],
                        next: [o(783.99, 0, .18, .08)],
                        tick: [o(1046.5, 0, .05, .04, "triangle")],
                        tap: [o(659.25, 0, .1, .07)],
                        pop: [o(880, 0, .09, .1), o(659.25, .04, .12, .06)],
                        win: [o(523.25, 0, .3, .12), o(659.25, .1, .3, .11), o(783.99, .2, .5, .11)],
                        boot: [o(523.25, 0, .6, .12), o(783.99, .12, .6, .1), o(1318.51, .26, .6, .06)],
                        confetti: [o(783.99, 0, .18, .07), o(1046.5, .07, .25, .06)],
                        nope: [o(659.25, 0, .16, .09), o(523.25, .12, .26, .08)]
                    },
                    sparkle: {
                        open: [o(1046.5, 0, .3, .12), o(1318.51, .06, .3, .1), o(783.99, .12, .5, .1)],
                        reveal: [o(783.99, 0, .25, .12), o(1046.5, .07, .3, .1), o(1318.51, .14, .45, .08)],
                        scratch: [o(1318.51, 0, .05, .04, "triangle")],
                        next: [o(880, 0, .12, .08), o(1046.5, .06, .16, .06)],
                        tick: [o(1318.51, 0, .04, .03, "triangle")],
                        tap: [o(880, 0, .08, .07)],
                        pop: [o(1318.51, 0, .07, .09), o(880, .03, .1, .06)],
                        win: [o(1046.5, 0, .2, .1), o(1318.51, .08, .2, .09), o(1567.98, .16, .45, .08)],
                        boot: [o(783.99, 0, .4, .1), o(1046.5, .1, .45, .09), o(1318.51, .2, .55, .07)],
                        confetti: [o(1318.51, 0, .1, .06), o(1567.98, .05, .12, .05), o(1046.5, .1, .2, .05)],
                        nope: [o(880, 0, .12, .08), o(659.25, .1, .22, .07)]
                    },
                    y2k: {
                        open: [o(523.25, 0, .08, .06, "square"), o(659.25, .07, .08, .06, "square"), o(783.99, .14, .08, .06, "square"), o(1046.5, .21, .22, .05, "square")],
                        reveal: [o(783.99, 0, .1, .1, "triangle"), o(1046.5, .07, .1, .1, "triangle"), o(1318.51, .14, .25, .08, "triangle")],
                        scratch: [o(1318.51, 0, .03, .03, "square")],
                        next: [o(783.99, 0, .06, .05, "square"), o(1046.5, .05, .09, .05, "square")],
                        tick: [o(1174.66, 0, .025, .035, "square")],
                        tap: [o(440, 0, .05, .06, "square"), o(659.25, .035, .07, .05, "square")],
                        pop: [o(1046.5, 0, .04, .12, "triangle"), o(783.99, .03, .07, .1, "triangle")],
                        win: [o(523.25, 0, .09, .06, "square"), o(659.25, .09, .09, .06, "square"), o(783.99, .18, .09, .06, "square"), o(1046.5, .27, .4, .06, "square"), o(1318.51, .27, .45, .08, "triangle")],
                        boot: [o(523.25, 0, .5, .12, "triangle"), o(783.99, 0, .5, .1, "triangle"), o(1318.51, .16, .5, .08, "triangle"), o(1567.98, .3, .45, .05, "triangle")],
                        confetti: [o(1318.51, 0, .05, .05, "square"), o(1567.98, .05, .05, .04, "square"), o(1046.5, .1, .12, .05, "square")],
                        nope: [o(440, 0, .12, .06, "square"), o(392, .13, .22, .06, "square")]
                    }
                };

            function P(e, t, n) {
                if (!e || "none" === e) return [];
                if ("garba" === e) return y[t] ? ? [];
                if ("pujo" === e) return "shankh" === t && n ? .length !== void 0 ? M(n.length) : E[t] ? ? [];
                if ("party" === e) return u[t in c ? c[t] : t] ? ? [];
                let a = F[e];
                return a ? a[!(t in s) ? t : s[t]] ? ? [] : []
            }
        },
        82161: (e, t, n) => {
            n.r(t), n.d(t, {
                FolioPreviewSound: () => f,
                FolioSoundProvider: () => v,
                hasPlayableSound: () => x,
                useFolioSound: () => g,
                useSoundEffect: () => m,
                useStandsInForPage: () => h
            });
            var a = n(73365),
                s = n(1521),
                r = n(77710),
                o = n(78922),
                l = n(2572);
            let i = () => {},
                u = {
                    unlocked: !1,
                    playing: !1,
                    muted: !1,
                    unlock: () => {},
                    toggle: () => {},
                    toggleMute: () => {},
                    playEffect: () => i,
                    chip: null
                },
                c = (0, s.createContext)(u),
                d = (0, s.createContext)(null);

            function f({
                children: e
            }) {
                let t = (0, s.useRef)(null),
                    [n] = (0, s.useState)(() => ({
                        register: e => (t.current = e, () => {
                            t.current === e && (t.current = null)
                        })
                    })),
                    r = e => t.current ? .(e.target);
                return (0, a.jsx)(d.Provider, {
                    value: n,
                    children: (0, a.jsx)("div", {
                        style: {
                            display: "contents"
                        },
                        onPointerDownCapture: r,
                        onClickCapture: r,
                        onKeyDownCapture: r,
                        children: e
                    })
                })
            }

            function p(e, t) {
                return t && "preview" === e ? "published" : e
            }

            function h(e) {
                return "published" === p(e, null !== (0, s.useContext)(d))
            }

            function m() {
                return (0, s.useContext)(c).playEffect
            }

            function g() {
                return (0, s.useContext)(c)
            }

            function x(e, t) {
                return "published" === t && !!e && (!!e.src || (e.effects ? ? "none") !== "none")
            }

            function v({
                sound: e,
                mode: t,
                resolveSrc: n,
                lang: f,
                children: h
            }) {
                let m = (0, r.G)(f),
                    g = (0, s.useContext)(d),
                    y = x(e, p(t, null !== g)),
                    k = (0, s.useRef)(null),
                    b = (0, s.useRef)(null),
                    C = (0, s.useRef)(null),
                    w = (0, s.useRef)(null),
                    [j, S] = (0, s.useState)(!1),
                    [M, N] = (0, s.useState)(!1),
                    [q, E] = (0, s.useState)(!1),
                    F = (0, s.useRef)(!1),
                    P = (0, s.useRef)(!1),
                    T = e ? .src ? n ? n(e.src) : e.src : null,
                    R = e ? .volume ? ? .8,
                    A = e ? .effects ? ? "none";
                (0, s.useEffect)(() => {
                    k.current && (k.current.volume = Math.min(1, Math.max(0, R)))
                }, [R, T]), (0, s.useEffect)(() => {
                    let e = k.current;
                    return () => {
                        e ? .pause()
                    }
                }, [T]), (0, s.useEffect)(() => () => {
                    b.current ? .close().catch(() => {}), b.current = null, C.current = null
                }, []);
                let I = (0, s.useCallback)(() => {
                        let e = k.current;
                        e && e.play().then(() => {
                            F.current = !0, N(!0)
                        }, () => N(!1))
                    }, []),
                    $ = (0, s.useCallback)(() => {
                        let e;
                        if ("none" === A) return;
                        let t = (e = window).AudioContext ? ? e.webkitAudioContext ? ? null;
                        if (t && !b.current) try {
                            b.current = new t;
                            let e = b.current,
                                n = e.createBuffer(1, 1, 22050),
                                a = e.createBufferSource();
                            a.buffer = n, a.connect(e.destination), a.start(0);
                            let s = e.createDynamicsCompressor();
                            s.threshold.value = -10, s.knee.value = 6, s.ratio.value = 8, s.attack.value = .002, s.release.value = .12, s.connect(e.destination), C.current = s
                        } catch {
                            b.current = null, C.current = null
                        }
                        let n = b.current;
                        n && "suspended" === n.state && n.resume().catch(() => {})
                    }, [A]),
                    O = (0, s.useCallback)(e => {
                        if (!y) return;
                        j || S(!0), $();
                        let t = e instanceof Element && null !== e.closest("[data-sound-chip]");
                        !T || t || F.current || P.current || q || I()
                    }, [y, j, $, T, q, I]);
                (0, s.useEffect)(() => g ? .register(O), [g, O]);
                let V = (0, s.useCallback)(() => {
                        let e = k.current;
                        e && (j || S(!0), $(), e.paused ? (P.current = !1, E(!1), I()) : (P.current = !0, E(!0), e.pause(), N(!1)))
                    }, [j, $, I]),
                    Z = (0, s.useCallback)(() => {
                        j || S(!0), $();
                        let e = !q;
                        E(e);
                        let t = k.current;
                        t && (P.current = e, e ? t.pause() : I())
                    }, [j, q, $, I]),
                    B = (0, s.useCallback)((e, t) => {
                        if (!y || !j || q) return i;
                        let n = b.current;
                        if (!n) return i;
                        "suspended" === n.state && n.resume().catch(() => {});
                        let a = (0, o.ZS)(A, e, t);
                        if (0 === a.length) return i;
                        let s = [],
                            r = k.current && !k.current.paused ? 3 : 1,
                            l = C.current ? ? n.destination;
                        try {
                            let e = n.currentTime;
                            for (let t of a) {
                                let a, o = n.createGain(),
                                    i = Math.min(.9, t.gain * Math.min(1, Math.max(0, R)) * r),
                                    u = e + t.start,
                                    c = u + t.duration,
                                    d = "noise" === t.wave ? .003 : t.attack ? ? .012;
                                if (o.gain.setValueAtTime(1e-4, u), o.gain.exponentialRampToValueAtTime(Math.max(i, 2e-4), u + d), o.gain.exponentialRampToValueAtTime(1e-4, c), "noise" === t.wave) {
                                    let e = function(e, t) {
                                            if (t.current && t.current.sampleRate === e.sampleRate) return t.current;
                                            let n = e.createBuffer(1, e.sampleRate, e.sampleRate),
                                                a = n.getChannelData(0);
                                            for (let e = 0; e < a.length; e += 1) a[e] = 2 * Math.random() - 1;
                                            return t.current = n, n
                                        }(n, w),
                                        s = n.createBufferSource();
                                    s.buffer = e, s.loop = !0;
                                    let r = n.createBiquadFilter();
                                    r.type = t.filter ? ? "bandpass", r.frequency.setValueAtTime(t.frequency, u), t.to && r.frequency.exponentialRampToValueAtTime(t.to, c), r.Q.value = "bandpass" === r.type ? 1.4 : .7, s.connect(r).connect(o).connect(l), a = s
                                } else {
                                    let e = n.createOscillator();
                                    if (e.type = t.wave, e.frequency.setValueAtTime(t.frequency, u), t.to && e.frequency.exponentialRampToValueAtTime(t.to, c), t.vibrato) {
                                        let a = n.createOscillator(),
                                            s = n.createGain();
                                        a.frequency.value = t.vibrato.rate, s.gain.value = t.vibrato.cents, a.connect(s).connect(e.detune), a.start(u), a.stop(c + .02)
                                    }
                                    if (t.cutoff) {
                                        let a = n.createBiquadFilter();
                                        a.type = "lowpass", a.frequency.value = t.cutoff, a.Q.value = .7, e.connect(a).connect(o).connect(l)
                                    } else e.connect(o).connect(l);
                                    a = e
                                }
                                a.start(u), a.stop(c + .02), s.push({
                                    gain: o,
                                    source: a
                                })
                            }
                        } catch {}
                        return () => {
                            try {
                                let e = n.currentTime;
                                for (let {
                                        gain: t,
                                        source: n
                                    } of s) t.gain.cancelScheduledValues(e), t.gain.setValueAtTime(Math.max(t.gain.value, 2e-4), e), t.gain.exponentialRampToValueAtTime(1e-4, e + .08), n.stop(e + .1)
                            } catch {}
                        }
                    }, [y, j, q, A, R]),
                    L = y ? (0, a.jsxs)(a.Fragment, {
                        children: [y && T ? (0, a.jsxs)("div", {
                            className: "folio-sound",
                            "data-sound-chip": "",
                            children: [(0, a.jsxs)("button", {
                                type: "button",
                                className: "folio-sound-button",
                                "aria-pressed": M,
                                "aria-label": M ? m.pauseMusic : m.playMusic,
                                onClick: V,
                                children: [(0, a.jsxs)("span", {
                                    "aria-hidden": !0,
                                    className: `folio-sound-bars${M?" is-playing":""}`,
                                    children: [(0, a.jsx)("i", {}), (0, a.jsx)("i", {}), (0, a.jsx)("i", {})]
                                }), M ? null : (0, a.jsx)("svg", {
                                    "aria-hidden": !0,
                                    className: "folio-sound-note",
                                    viewBox: "0 0 24 24",
                                    width: "18",
                                    height: "18",
                                    fill: "currentColor",
                                    children: (0, a.jsx)("path", {
                                        d: "M9 17.5V6.2a1 1 0 0 1 .76-.97l9-2.25A1 1 0 0 1 20 3.95V15.5a2.5 2.5 0 1 1-2-2.45V7.03l-7 1.75v8.72A2.5 2.5 0 1 1 9 17.5z"
                                    })
                                }), (0, a.jsx)("span", {
                                    className: "folio-sound-label",
                                    children: M ? m.musicOn : (0, l.uS)(e ? .title, m.playOurSong)
                                })]
                            }), (0, a.jsx)("audio", {
                                ref: k,
                                src: T,
                                preload: "none",
                                loop: e ? .loop ? ? !0,
                                onPause: () => N(!1),
                                onPlay: () => N(!0)
                            })]
                        }) : null, y && !T && "none" !== A ? (0, a.jsx)("div", {
                            className: "folio-sound",
                            "data-sound-chip": "",
                            children: (0, a.jsxs)("button", {
                                type: "button",
                                className: "folio-sound-button",
                                "aria-pressed": !q,
                                "aria-label": q ? m.soundsOn : m.muteSounds,
                                onClick: Z,
                                children: [(0, a.jsxs)("svg", {
                                    "aria-hidden": !0,
                                    viewBox: "0 0 24 24",
                                    width: "16",
                                    height: "16",
                                    fill: "none",
                                    stroke: "currentColor",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    children: [(0, a.jsx)("path", {
                                        d: "M4 9v6h4l5 4V5L8 9H4z"
                                    }), q ? (0, a.jsx)("path", {
                                        d: "M17 9l5 6M22 9l-5 6"
                                    }) : (0, a.jsx)("path", {
                                        d: "M16.5 8.5a5 5 0 0 1 0 7M19.5 5.5a9 9 0 0 1 0 13"
                                    })]
                                }), (0, a.jsx)("span", {
                                    className: "folio-sound-label",
                                    children: q ? m.soundOff : m.soundOn
                                })]
                            })
                        }) : null]
                    }) : null,
                    _ = y ? {
                        unlocked: j,
                        playing: M,
                        muted: q,
                        unlock: O,
                        toggle: V,
                        toggleMute: Z,
                        playEffect: B,
                        chip: L
                    } : u;
                return (0, a.jsx)(c.Provider, {
                    value: _,
                    children: h
                })
            }
        }
    }
]);