"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [74339], {
        97194: (e, t, s) => {
            s.d(t, {
                A: () => p
            });
            var r = s(8882),
                i = s(93516),
                a = s(328),
                n = s(86209),
                o = s(43092),
                l = s(31858),
                u = s(44225),
                h = s(58253),
                c = s(73661),
                d = s(86465),
                _ = s(72876),
                w = s(11285);
            (0, h.V)();
            let g = {
                    url: i.nf,
                    storageKey: i.AQ,
                    autoRefreshToken: !0,
                    persistSession: !0,
                    detectSessionInUrl: !0,
                    headers: i.Rn,
                    flowType: "implicit",
                    debug: !1,
                    hasCustomAuthorizationHeader: !1,
                    throwOnError: !1,
                    lockAcquireTimeout: 5e3,
                    skipAutoInitialize: !1,
                    experimental: {}
                },
                f = {};
            class y {
                get jwks() {
                    var e, t;
                    return null != (t = null == (e = f[this.storageKey]) ? void 0 : e.jwks) ? t : {
                        keys: []
                    }
                }
                set jwks(e) {
                    f[this.storageKey] = Object.assign(Object.assign({}, f[this.storageKey]), {
                        jwks: e
                    })
                }
                get jwks_cached_at() {
                    var e, t;
                    return null != (t = null == (e = f[this.storageKey]) ? void 0 : e.cachedAt) ? t : Number.MIN_SAFE_INTEGER
                }
                set jwks_cached_at(e) {
                    f[this.storageKey] = Object.assign(Object.assign({}, f[this.storageKey]), {
                        cachedAt: e
                    })
                }
                constructor(e) {
                    var t, s, i;
                    this.userStorage = null, this.memoryStorage = null, this.stateChangeEmitters = new Map, this.autoRefreshTicker = null, this.autoRefreshTickTimeout = null, this.visibilityChangedCallback = null, this.refreshingDeferred = null, this._sessionRemovalEpoch = 0, this.initializePromise = null, this.detectSessionInUrl = !0, this.hasCustomAuthorizationHeader = !1, this.suppressGetSessionWarning = !1, this.lock = null, this.lockAcquired = !1, this.pendingInLock = [], this.broadcastChannel = null, this.logger = console.log;
                    const a = Object.assign(Object.assign({}, g), e);
                    if (this.storageKey = a.storageKey, this.instanceID = null != (t = y.nextInstanceID[this.storageKey]) ? t : 0, y.nextInstanceID[this.storageKey] = this.instanceID + 1, this.logDebugMessages = !!a.debug, "function" == typeof a.debug && (this.logger = a.debug), this.instanceID > 0 && (0, o.Bd)()) {
                        const e = `${this._logPrefix()} Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.`;
                        console.warn(e), this.logDebugMessages && console.trace(e)
                    }
                    if (this.persistSession = a.persistSession, this.autoRefreshToken = a.autoRefreshToken, this.experimental = null != (s = a.experimental) ? s : {}, this.admin = new r.A({
                            url: a.url,
                            headers: a.headers,
                            fetch: a.fetch,
                            experimental: this.experimental
                        }), this.url = a.url, this.headers = a.headers, this.fetch = (0, o.lA)(a.fetch), this.detectSessionInUrl = a.detectSessionInUrl, this.flowType = a.flowType, this.hasCustomAuthorizationHeader = a.hasCustomAuthorizationHeader, this.throwOnError = a.throwOnError, this.lockAcquireTimeout = a.lockAcquireTimeout, null != a.lock && (this.lock = a.lock), this.jwks || (this.jwks = {
                            keys: []
                        }, this.jwks_cached_at = Number.MIN_SAFE_INTEGER), this.mfa = {
                            verify: this._verify.bind(this),
                            enroll: this._enroll.bind(this),
                            unenroll: this._unenroll.bind(this),
                            challenge: this._challenge.bind(this),
                            listFactors: this._listFactors.bind(this),
                            challengeAndVerify: this._challengeAndVerify.bind(this),
                            getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this),
                            webauthn: new w.H1(this)
                        }, this.oauth = {
                            getAuthorizationDetails: this._getAuthorizationDetails.bind(this),
                            approveAuthorization: this._approveAuthorization.bind(this),
                            denyAuthorization: this._denyAuthorization.bind(this),
                            listGrants: this._listOAuthGrants.bind(this),
                            revokeGrant: this._revokeOAuthGrant.bind(this)
                        }, this.passkey = {
                            startRegistration: this._startPasskeyRegistration.bind(this),
                            verifyRegistration: this._verifyPasskeyRegistration.bind(this),
                            startAuthentication: this._startPasskeyAuthentication.bind(this),
                            verifyAuthentication: this._verifyPasskeyAuthentication.bind(this),
                            list: this._listPasskeys.bind(this),
                            update: this._updatePasskey.bind(this),
                            delete: this._deletePasskey.bind(this)
                        }, this.persistSession ? (a.storage ? this.storage = a.storage : (0, o.LJ)() ? this.storage = globalThis.localStorage : (this.memoryStorage = {}, this.storage = (0, l.r)(this.memoryStorage)), a.userStorage && (this.userStorage = a.userStorage)) : (this.memoryStorage = {}, this.storage = (0, l.r)(this.memoryStorage)), (0, o.Bd)() && globalThis.BroadcastChannel && this.persistSession && this.storageKey) {
                        try {
                            this.broadcastChannel = new globalThis.BroadcastChannel(this.storageKey)
                        } catch (e) {
                            console.error("Failed to create a new BroadcastChannel, multi-tab state changes will not be available", e)
                        }
                        null == (i = this.broadcastChannel) || i.addEventListener("message", async e => {
                            this._debug("received broadcast notification from other tab or client", e);
                            try {
                                await this._notifyAllSubscribers(e.data.event, e.data.session, !1)
                            } catch (e) {
                                this._debug("#broadcastChannel", "error", e)
                            }
                        })
                    }
                    a.skipAutoInitialize || this.initialize().catch(e => {
                        this._debug("#initialize()", "error", e)
                    })
                }
                isThrowOnErrorEnabled() {
                    return this.throwOnError
                }
                _returnResult(e) {
                    if (this.throwOnError && e && e.error) throw e.error;
                    return e
                }
                _logPrefix() {
                    return `GoTrueClient@${this.storageKey}:${this.instanceID} (${c.r}) ${new Date().toISOString()}`
                }
                _debug(...e) {
                    return this.logDebugMessages && this.logger(this._logPrefix(), ...e), this
                }
                async initialize() {
                    return this.initializePromise || (this.initializePromise = (async () => null != this.lock ? await this._acquireLock(this.lockAcquireTimeout, async () => await this._initialize()) : await this._initialize())()), await this.initializePromise
                }
                async _initialize() {
                    var e;
                    try {
                        let t = {},
                            s = "none";
                        if ((0, o.Bd)() && (t = (0, o.XR)(window.location.href), this._isImplicitGrantCallback(t) ? s = "implicit" : await this._isPKCECallback(t) && (s = "pkce")), (0, o.Bd)() && this.detectSessionInUrl && "none" !== s) {
                            let {
                                data: r,
                                error: i
                            } = await this._getSessionFromURL(t, s);
                            if (i) {
                                (this._debug("#_initialize()", "error detecting session from URL", i), (0, a.MJ)(i)) && (null == (e = i.details) || e.code);
                                return {
                                    error: i
                                }
                            }
                            let {
                                session: n,
                                redirectType: o
                            } = r;
                            return this._debug("#_initialize()", "detected session in URL", n, "redirect type", o), await this._saveSession(n), setTimeout(async () => {
                                "recovery" === o ? await this._notifyAllSubscribers("PASSWORD_RECOVERY", n) : await this._notifyAllSubscribers("SIGNED_IN", n)
                            }, 0), {
                                error: null
                            }
                        }
                        return await this._recoverAndRefresh(), {
                            error: null
                        }
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            error: e
                        });
                        return this._returnResult({
                            error: new a.HU("Unexpected error during initialization", e)
                        })
                    } finally {
                        await this._handleVisibilityChange(), this._debug("#_initialize()", "end")
                    }
                }
                async signInAnonymously(e) {
                    var t, s, r;
                    try {
                        let {
                            data: i,
                            error: a
                        } = await (0, n.vE)(this.fetch, "POST", `${this.url}/signup`, {
                            headers: this.headers,
                            body: {
                                data: null != (s = null == (t = null == e ? void 0 : e.options) ? void 0 : t.data) ? s : {},
                                gotrue_meta_security: {
                                    captcha_token: null == (r = null == e ? void 0 : e.options) ? void 0 : r.captchaToken
                                }
                            },
                            xform: n.R_
                        });
                        if (a || !i) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: a
                        });
                        let o = i.session,
                            l = i.user;
                        return i.session && (await this._saveSession(i.session), await this._notifyAllSubscribers("SIGNED_IN", o)), this._returnResult({
                            data: {
                                user: l,
                                session: o
                            },
                            error: null
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async signUp(e) {
                    var t, s, r;
                    try {
                        let i;
                        if ("email" in e) {
                            let {
                                email: s,
                                password: r,
                                options: a
                            } = e, l = null, u = null;
                            "pkce" === this.flowType && ([l, u] = await (0, o.dS)(this.storage, this.storageKey)), i = await (0, n.vE)(this.fetch, "POST", `${this.url}/signup`, {
                                headers: this.headers,
                                redirectTo: null == a ? void 0 : a.emailRedirectTo,
                                body: {
                                    email: s,
                                    password: r,
                                    data: null != (t = null == a ? void 0 : a.data) ? t : {},
                                    gotrue_meta_security: {
                                        captcha_token: null == a ? void 0 : a.captchaToken
                                    },
                                    code_challenge: l,
                                    code_challenge_method: u
                                },
                                xform: n.R_
                            })
                        } else if ("phone" in e) {
                            let {
                                phone: t,
                                password: a,
                                options: o
                            } = e;
                            i = await (0, n.vE)(this.fetch, "POST", `${this.url}/signup`, {
                                headers: this.headers,
                                body: {
                                    phone: t,
                                    password: a,
                                    data: null != (s = null == o ? void 0 : o.data) ? s : {},
                                    channel: null != (r = null == o ? void 0 : o.channel) ? r : "sms",
                                    gotrue_meta_security: {
                                        captcha_token: null == o ? void 0 : o.captchaToken
                                    }
                                },
                                xform: n.R_
                            })
                        } else throw new a.U_("You must provide either an email or phone number and a password");
                        let {
                            data: l,
                            error: u
                        } = i;
                        if (u || !l) return await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: u
                        });
                        let h = l.session,
                            c = l.user;
                        return l.session && (await this._saveSession(l.session), await this._notifyAllSubscribers("SIGNED_IN", h)), this._returnResult({
                            data: {
                                user: c,
                                session: h
                            },
                            error: null
                        })
                    } catch (e) {
                        if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), (0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async signInWithPassword(e) {
                    try {
                        let t;
                        if ("email" in e) {
                            let {
                                email: s,
                                password: r,
                                options: i
                            } = e;
                            t = await (0, n.vE)(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                                headers: this.headers,
                                body: {
                                    email: s,
                                    password: r,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    }
                                },
                                xform: n.GC
                            })
                        } else if ("phone" in e) {
                            let {
                                phone: s,
                                password: r,
                                options: i
                            } = e;
                            t = await (0, n.vE)(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                                headers: this.headers,
                                body: {
                                    phone: s,
                                    password: r,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    }
                                },
                                xform: n.GC
                            })
                        } else throw new a.U_("You must provide either an email or phone number and a password");
                        let {
                            data: s,
                            error: r
                        } = t;
                        if (r) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: r
                        });
                        if (!s || !s.session || !s.user) {
                            let e = new a.Ox;
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: e
                            })
                        }
                        return s.session && (await this._saveSession(s.session), await this._notifyAllSubscribers("SIGNED_IN", s.session)), this._returnResult({
                            data: Object.assign({
                                user: s.user,
                                session: s.session
                            }, s.weak_password ? {
                                weakPassword: s.weak_password
                            } : null),
                            error: r
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async signInWithOAuth(e) {
                    var t, s, r, i;
                    return await this._handleProviderSignIn(e.provider, {
                        redirectTo: null == (t = e.options) ? void 0 : t.redirectTo,
                        scopes: null == (s = e.options) ? void 0 : s.scopes,
                        queryParams: null == (r = e.options) ? void 0 : r.queryParams,
                        skipBrowserRedirect: null == (i = e.options) ? void 0 : i.skipBrowserRedirect
                    })
                }
                async exchangeCodeForSession(e) {
                    return (await this.initializePromise, null != this.lock) ? this._acquireLock(this.lockAcquireTimeout, async () => this._exchangeCodeForSession(e)) : this._exchangeCodeForSession(e)
                }
                async signInWithWeb3(e) {
                    let {
                        chain: t
                    } = e;
                    switch (t) {
                        case "ethereum":
                            return await this.signInWithEthereum(e);
                        case "solana":
                            return await this.signInWithSolana(e);
                        default:
                            throw Error(`@supabase/auth-js: Unsupported chain "${t}"`)
                    }
                }
                async signInWithEthereum(e) {
                    var t, s, r, i, l, u, h, c, d, w, g;
                    let f, y;
                    if ("message" in e) f = e.message, y = e.signature;
                    else {
                        let a, {
                            chain: n,
                            wallet: w,
                            statement: g,
                            options: p
                        } = e;
                        if ((0, o.Bd)())
                            if ("object" == typeof w) a = w;
                            else {
                                let e = window;
                                if ("ethereum" in e && "object" == typeof e.ethereum && "request" in e.ethereum && "function" == typeof e.ethereum.request) a = e.ethereum;
                                else throw Error("@supabase/auth-js: No compatible Ethereum wallet interface on the window object (window.ethereum) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'ethereum', wallet: resolvedUserWallet }) instead.")
                            }
                        else {
                            if ("object" != typeof w || !(null == p ? void 0 : p.url)) throw Error("@supabase/auth-js: Both wallet and url must be specified in non-browser environments.");
                            a = w
                        }
                        let b = new URL(null != (t = null == p ? void 0 : p.url) ? t : window.location.href),
                            v = await a.request({
                                method: "eth_requestAccounts"
                            }).then(e => e).catch(() => {
                                throw Error("@supabase/auth-js: Wallet method eth_requestAccounts is missing or invalid")
                            });
                        if (!v || 0 === v.length) throw Error("@supabase/auth-js: No accounts available. Please ensure the wallet is connected.");
                        let k = (0, _.bv)(v[0]),
                            m = null == (s = null == p ? void 0 : p.signInWithEthereum) ? void 0 : s.chainId;
                        if (!m) {
                            let e = await a.request({
                                method: "eth_chainId"
                            });
                            m = (0, _.aD)(e)
                        }
                        let S = {
                            domain: b.host,
                            address: k,
                            statement: g,
                            uri: b.href,
                            version: "1",
                            chainId: m,
                            nonce: null == (r = null == p ? void 0 : p.signInWithEthereum) ? void 0 : r.nonce,
                            issuedAt: null != (l = null == (i = null == p ? void 0 : p.signInWithEthereum) ? void 0 : i.issuedAt) ? l : new Date,
                            expirationTime: null == (u = null == p ? void 0 : p.signInWithEthereum) ? void 0 : u.expirationTime,
                            notBefore: null == (h = null == p ? void 0 : p.signInWithEthereum) ? void 0 : h.notBefore,
                            requestId: null == (c = null == p ? void 0 : p.signInWithEthereum) ? void 0 : c.requestId,
                            resources: null == (d = null == p ? void 0 : p.signInWithEthereum) ? void 0 : d.resources
                        };
                        f = (0, _.ob)(S), y = await a.request({
                            method: "personal_sign",
                            params: [(0, _.nj)(f), k]
                        })
                    }
                    try {
                        let {
                            data: t,
                            error: s
                        } = await (0, n.vE)(this.fetch, "POST", `${this.url}/token?grant_type=web3`, {
                            headers: this.headers,
                            body: Object.assign({
                                chain: "ethereum",
                                message: f,
                                signature: y
                            }, (null == (w = e.options) ? void 0 : w.captchaToken) ? {
                                gotrue_meta_security: {
                                    captcha_token: null == (g = e.options) ? void 0 : g.captchaToken
                                }
                            } : null),
                            xform: n.R_
                        });
                        if (s) throw s;
                        if (!t || !t.session || !t.user) {
                            let e = new a.Ox;
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: e
                            })
                        }
                        return t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers("SIGNED_IN", t.session)), this._returnResult({
                            data: Object.assign({}, t),
                            error: s
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async signInWithSolana(e) {
                    var t, s, r, i, l, u, h, c, _, w, g, f;
                    let y, p;
                    if ("message" in e) y = e.message, p = e.signature;
                    else {
                        let a, {
                            chain: n,
                            wallet: d,
                            statement: g,
                            options: f
                        } = e;
                        if ((0, o.Bd)())
                            if ("object" == typeof d) a = d;
                            else {
                                let e = window;
                                if ("solana" in e && "object" == typeof e.solana && ("signIn" in e.solana && "function" == typeof e.solana.signIn || "signMessage" in e.solana && "function" == typeof e.solana.signMessage)) a = e.solana;
                                else throw Error("@supabase/auth-js: No compatible Solana wallet interface on the window object (window.solana) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'solana', wallet: resolvedUserWallet }) instead.")
                            }
                        else {
                            if ("object" != typeof d || !(null == f ? void 0 : f.url)) throw Error("@supabase/auth-js: Both wallet and url must be specified in non-browser environments.");
                            a = d
                        }
                        let b = new URL(null != (t = null == f ? void 0 : f.url) ? t : window.location.href);
                        if ("signIn" in a && a.signIn) {
                            let e, t = await a.signIn(Object.assign(Object.assign(Object.assign({
                                issuedAt: new Date().toISOString()
                            }, null == f ? void 0 : f.signInWithSolana), {
                                version: "1",
                                domain: b.host,
                                uri: b.href
                            }), g ? {
                                statement: g
                            } : null));
                            if (Array.isArray(t) && t[0] && "object" == typeof t[0]) e = t[0];
                            else if (t && "object" == typeof t && "signedMessage" in t && "signature" in t) e = t;
                            else throw Error("@supabase/auth-js: Wallet method signIn() returned unrecognized value");
                            if ("signedMessage" in e && "signature" in e && ("string" == typeof e.signedMessage || e.signedMessage instanceof Uint8Array) && e.signature instanceof Uint8Array) y = "string" == typeof e.signedMessage ? e.signedMessage : new TextDecoder().decode(e.signedMessage), p = e.signature;
                            else throw Error("@supabase/auth-js: Wallet method signIn() API returned object without signedMessage and signature fields")
                        } else {
                            if (!("signMessage" in a) || "function" != typeof a.signMessage || !("publicKey" in a) || "object" != typeof a || !a.publicKey || !("toBase58" in a.publicKey) || "function" != typeof a.publicKey.toBase58) throw Error("@supabase/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API");
                            y = [`${b.host} wants you to sign in with your Solana account:`, a.publicKey.toBase58(), ...g ? ["", g, ""] : [""], "Version: 1", `URI: ${b.href}`, `Issued At: ${null!=(r=null==(s=null==f?void 0:f.signInWithSolana)?void 0:s.issuedAt)?r:new Date().toISOString()}`, ...(null == (i = null == f ? void 0 : f.signInWithSolana) ? void 0 : i.notBefore) ? [`Not Before: ${f.signInWithSolana.notBefore}`] : [], ...(null == (l = null == f ? void 0 : f.signInWithSolana) ? void 0 : l.expirationTime) ? [`Expiration Time: ${f.signInWithSolana.expirationTime}`] : [], ...(null == (u = null == f ? void 0 : f.signInWithSolana) ? void 0 : u.chainId) ? [`Chain ID: ${f.signInWithSolana.chainId}`] : [], ...(null == (h = null == f ? void 0 : f.signInWithSolana) ? void 0 : h.nonce) ? [`Nonce: ${f.signInWithSolana.nonce}`] : [], ...(null == (c = null == f ? void 0 : f.signInWithSolana) ? void 0 : c.requestId) ? [`Request ID: ${f.signInWithSolana.requestId}`] : [], ...(null == (w = null == (_ = null == f ? void 0 : f.signInWithSolana) ? void 0 : _.resources) ? void 0 : w.length) ? ["Resources", ...f.signInWithSolana.resources.map(e => `- ${e}`)] : []].join("\n");
                            let e = await a.signMessage(new TextEncoder().encode(y), "utf8");
                            if (!e || !(e instanceof Uint8Array)) throw Error("@supabase/auth-js: Wallet signMessage() API returned an recognized value");
                            p = e
                        }
                    }
                    try {
                        let {
                            data: t,
                            error: s
                        } = await (0, n.vE)(this.fetch, "POST", `${this.url}/token?grant_type=web3`, {
                            headers: this.headers,
                            body: Object.assign({
                                chain: "solana",
                                message: y,
                                signature: (0, d.no)(p)
                            }, (null == (g = e.options) ? void 0 : g.captchaToken) ? {
                                gotrue_meta_security: {
                                    captcha_token: null == (f = e.options) ? void 0 : f.captchaToken
                                }
                            } : null),
                            xform: n.R_
                        });
                        if (s) throw s;
                        if (!t || !t.session || !t.user) {
                            let e = new a.Ox;
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: e
                            })
                        }
                        return t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers("SIGNED_IN", t.session)), this._returnResult({
                            data: Object.assign({}, t),
                            error: s
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async _exchangeCodeForSession(e) {
                    let t = await (0, o.U9)(this.storage, `${this.storageKey}-code-verifier`),
                        [s, r] = (null != t ? t : "").split("/");
                    try {
                        if (!s && "pkce" === this.flowType) throw new a.lh;
                        let {
                            data: t,
                            error: i
                        } = await (0, n.vE)(this.fetch, "POST", `${this.url}/token?grant_type=pkce`, {
                            headers: this.headers,
                            body: {
                                auth_code: e,
                                code_verifier: s
                            },
                            xform: n.R_
                        });
                        if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), i) throw i;
                        if (!t || !t.session || !t.user) {
                            let e = new a.Ox;
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null,
                                    redirectType: null
                                },
                                error: e
                            })
                        }
                        return t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers("recovery" === r ? "PASSWORD_RECOVERY" : "SIGNED_IN", t.session)), this._returnResult({
                            data: Object.assign(Object.assign({}, t), {
                                redirectType: null != r ? r : null
                            }),
                            error: i
                        })
                    } catch (e) {
                        if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), (0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null,
                                redirectType: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async signInWithIdToken(e) {
                    try {
                        let {
                            options: t,
                            provider: s,
                            token: r,
                            access_token: i,
                            nonce: o
                        } = e, {
                            data: l,
                            error: u
                        } = await (0, n.vE)(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
                            headers: this.headers,
                            body: {
                                provider: s,
                                id_token: r,
                                access_token: i,
                                nonce: o,
                                gotrue_meta_security: {
                                    captcha_token: null == t ? void 0 : t.captchaToken
                                }
                            },
                            xform: n.R_
                        });
                        if (u) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: u
                        });
                        if (!l || !l.session || !l.user) {
                            let e = new a.Ox;
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: e
                            })
                        }
                        return l.session && (await this._saveSession(l.session), await this._notifyAllSubscribers("SIGNED_IN", l.session)), this._returnResult({
                            data: l,
                            error: u
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async signInWithOtp(e) {
                    var t, s, r, i, l;
                    try {
                        if ("email" in e) {
                            let {
                                email: r,
                                options: i
                            } = e, a = null, l = null;
                            "pkce" === this.flowType && ([a, l] = await (0, o.dS)(this.storage, this.storageKey));
                            let {
                                error: u
                            } = await (0, n.vE)(this.fetch, "POST", `${this.url}/otp`, {
                                headers: this.headers,
                                body: {
                                    email: r,
                                    data: null != (t = null == i ? void 0 : i.data) ? t : {},
                                    create_user: null == (s = null == i ? void 0 : i.shouldCreateUser) || s,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    },
                                    code_challenge: a,
                                    code_challenge_method: l
                                },
                                redirectTo: null == i ? void 0 : i.emailRedirectTo
                            });
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: u
                            })
                        }
                        if ("phone" in e) {
                            let {
                                phone: t,
                                options: s
                            } = e, {
                                data: a,
                                error: o
                            } = await (0, n.vE)(this.fetch, "POST", `${this.url}/otp`, {
                                headers: this.headers,
                                body: {
                                    phone: t,
                                    data: null != (r = null == s ? void 0 : s.data) ? r : {},
                                    create_user: null == (i = null == s ? void 0 : s.shouldCreateUser) || i,
                                    gotrue_meta_security: {
                                        captcha_token: null == s ? void 0 : s.captchaToken
                                    },
                                    channel: null != (l = null == s ? void 0 : s.channel) ? l : "sms"
                                }
                            });
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null,
                                    messageId: null == a ? void 0 : a.message_id
                                },
                                error: o
                            })
                        }
                        throw new a.U_("You must provide either an email or phone number.")
                    } catch (e) {
                        if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), (0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async verifyOtp(e) {
                    var t, s;
                    try {
                        let r, i;
                        "options" in e && (r = null == (t = e.options) ? void 0 : t.redirectTo, i = null == (s = e.options) ? void 0 : s.captchaToken);
                        let {
                            data: a,
                            error: o
                        } = await (0, n.vE)(this.fetch, "POST", `${this.url}/verify`, {
                            headers: this.headers,
                            body: Object.assign(Object.assign({}, e), {
                                gotrue_meta_security: {
                                    captcha_token: i
                                }
                            }),
                            redirectTo: r,
                            xform: n.R_
                        });
                        if (o) throw o;
                        if (!a) throw Error("An error occurred on token verification.");
                        let l = a.session,
                            u = a.user;
                        return (null == l ? void 0 : l.access_token) && (await this._saveSession(l), await this._notifyAllSubscribers("recovery" == e.type ? "PASSWORD_RECOVERY" : "SIGNED_IN", l)), this._returnResult({
                            data: {
                                user: u,
                                session: l
                            },
                            error: null
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async signInWithSSO(e) {
                    var t, s, r, i, l;
                    try {
                        let a = null,
                            u = null;
                        "pkce" === this.flowType && ([a, u] = await (0, o.dS)(this.storage, this.storageKey));
                        let h = await (0, n.vE)(this.fetch, "POST", `${this.url}/sso`, {
                            body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, "providerId" in e ? {
                                provider_id: e.providerId
                            } : null), "domain" in e ? {
                                domain: e.domain
                            } : null), {
                                redirect_to: null != (s = null == (t = e.options) ? void 0 : t.redirectTo) ? s : void 0
                            }), (null == (r = null == e ? void 0 : e.options) ? void 0 : r.captchaToken) ? {
                                gotrue_meta_security: {
                                    captcha_token: e.options.captchaToken
                                }
                            } : null), {
                                skip_http_redirect: !0,
                                code_challenge: a,
                                code_challenge_method: u
                            }),
                            headers: this.headers,
                            xform: n.c2
                        });
                        return (null == (i = h.data) ? void 0 : i.url) && (0, o.Bd)() && !(null == (l = e.options) ? void 0 : l.skipBrowserRedirect) && window.location.assign(h.data.url), this._returnResult(h)
                    } catch (e) {
                        if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), (0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async reauthenticate() {
                    return (await this.initializePromise, null != this.lock) ? await this._acquireLock(this.lockAcquireTimeout, async () => await this._reauthenticate()) : await this._reauthenticate()
                }
                async _reauthenticate() {
                    try {
                        return await this._useSession(async e => {
                            let {
                                data: {
                                    session: t
                                },
                                error: s
                            } = e;
                            if (s) throw s;
                            if (!t) throw new a.jG;
                            let {
                                error: r
                            } = await (0, n.vE)(this.fetch, "GET", `${this.url}/reauthenticate`, {
                                headers: this.headers,
                                jwt: t.access_token
                            });
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: r
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async resend(e) {
                    try {
                        let t = `${this.url}/resend`;
                        if ("email" in e) {
                            let {
                                email: s,
                                type: r,
                                options: i
                            } = e, a = null, l = null;
                            "pkce" === this.flowType && ([a, l] = await (0, o.dS)(this.storage, this.storageKey));
                            let {
                                error: u
                            } = await (0, n.vE)(this.fetch, "POST", t, {
                                headers: this.headers,
                                body: {
                                    email: s,
                                    type: r,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    },
                                    code_challenge: a,
                                    code_challenge_method: l
                                },
                                redirectTo: null == i ? void 0 : i.emailRedirectTo
                            });
                            return u && await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: u
                            })
                        }
                        if ("phone" in e) {
                            let {
                                phone: s,
                                type: r,
                                options: i
                            } = e, {
                                data: a,
                                error: o
                            } = await (0, n.vE)(this.fetch, "POST", t, {
                                headers: this.headers,
                                body: {
                                    phone: s,
                                    type: r,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    }
                                }
                            });
                            return this._returnResult({
                                data: {
                                    user: null,
                                    session: null,
                                    messageId: null == a ? void 0 : a.message_id
                                },
                                error: o
                            })
                        }
                        throw new a.U_("You must provide either an email or phone number and a type")
                    } catch (e) {
                        if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), (0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async getSession() {
                    return (await this.initializePromise, null != this.lock) ? await this._acquireLock(this.lockAcquireTimeout, async () => this._useSession(async e => e)) : await this._useSession(async e => e)
                }
                async _acquireLock(e, t) {
                    this._debug("#_acquireLock", "begin", e);
                    try {
                        if (this.lockAcquired) {
                            let e = this.pendingInLock.length ? this.pendingInLock[this.pendingInLock.length - 1] : Promise.resolve(),
                                s = (async () => (await e, await t()))();
                            return this.pendingInLock.push((async () => {
                                try {
                                    await s
                                } catch (e) {}
                            })()), s
                        }
                        return await this.lock(`lock:${this.storageKey}`, e, async () => {
                            this._debug("#_acquireLock", "lock acquired for storage key", this.storageKey);
                            try {
                                this.lockAcquired = !0;
                                let e = t();
                                for (this.pendingInLock.push((async () => {
                                        try {
                                            await e
                                        } catch (e) {}
                                    })()), await e; this.pendingInLock.length;) {
                                    let e = [...this.pendingInLock];
                                    await Promise.all(e), this.pendingInLock.splice(0, e.length)
                                }
                                return await e
                            } finally {
                                this._debug("#_acquireLock", "lock released for storage key", this.storageKey), this.lockAcquired = !1
                            }
                        })
                    } finally {
                        this._debug("#_acquireLock", "end")
                    }
                }
                async _useSession(e) {
                    this._debug("#_useSession", "begin");
                    try {
                        let t = await this.__loadSession();
                        return await e(t)
                    } finally {
                        this._debug("#_useSession", "end")
                    }
                }
                async __loadSession() {
                    this._debug("#__loadSession()", "begin"), null == this.lock || this.lockAcquired || this._debug("#__loadSession()", "used outside of an acquired lock!", Error().stack);
                    try {
                        let e = null,
                            t = await (0, o.U9)(this.storage, this.storageKey);
                        if (this._debug("#getSession()", "session from storage", t), null !== t && (this._isValidSession(t) ? e = t : (this._debug("#getSession()", "session from storage is not valid"), await this._removeSession())), !e) return {
                            data: {
                                session: null
                            },
                            error: null
                        };
                        let s = !!e.expires_at && 1e3 * e.expires_at - Date.now() < i.CT;
                        if (this._debug("#__loadSession()", `session has${s?"":" not"} expired`, "expires_at", e.expires_at), !s) {
                            if (this.userStorage) {
                                let t = await (0, o.U9)(this.userStorage, this.storageKey + "-user");
                                (null == t ? void 0 : t.user) ? e.user = t.user: e.user = (0, o.QE)()
                            }
                            if (this.storage.isServer && e.user && !e.user.__isUserNotAvailableProxy) {
                                let t = {
                                    value: this.suppressGetSessionWarning
                                };
                                e.user = (0, o.uO)(e.user, t), t.value && (this.suppressGetSessionWarning = !0)
                            }
                            return {
                                data: {
                                    session: e
                                },
                                error: null
                            }
                        }
                        let {
                            data: r,
                            error: a
                        } = await this._callRefreshToken(e.refresh_token);
                        if (a) return this._returnResult({
                            data: {
                                session: null
                            },
                            error: a
                        });
                        return this._returnResult({
                            data: {
                                session: r
                            },
                            error: null
                        })
                    } finally {
                        this._debug("#__loadSession()", "end")
                    }
                }
                async getUser(e) {
                    let t;
                    return e ? await this._getUser(e) : (await this.initializePromise, (t = null != this.lock ? await this._acquireLock(this.lockAcquireTimeout, async () => await this._getUser()) : await this._getUser()).data.user && (this.suppressGetSessionWarning = !0), t)
                }
                async _getUser(e) {
                    try {
                        if (e) return await (0, n.vE)(this.fetch, "GET", `${this.url}/user`, {
                            headers: this.headers,
                            jwt: e,
                            xform: n.Cl
                        });
                        return await this._useSession(async e => {
                            var t, s, r;
                            let {
                                data: i,
                                error: o
                            } = e;
                            if (o) throw o;
                            return (null == (t = i.session) ? void 0 : t.access_token) || this.hasCustomAuthorizationHeader ? await (0, n.vE)(this.fetch, "GET", `${this.url}/user`, {
                                headers: this.headers,
                                jwt: null != (r = null == (s = i.session) ? void 0 : s.access_token) ? r : void 0,
                                xform: n.Cl
                            }) : {
                                data: {
                                    user: null
                                },
                                error: new a.jG
                            }
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return (0, a.zq)(e) && (await this._removeSession(), await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`)), this._returnResult({
                            data: {
                                user: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async updateUser(e, t = {}) {
                    return (await this.initializePromise, null != this.lock) ? await this._acquireLock(this.lockAcquireTimeout, async () => await this._updateUser(e, t)) : await this._updateUser(e, t)
                }
                async _updateUser(e, t = {}) {
                    try {
                        return await this._useSession(async s => {
                            let {
                                data: r,
                                error: i
                            } = s;
                            if (i) throw i;
                            if (!r.session) throw new a.jG;
                            let l = r.session,
                                u = null,
                                h = null;
                            "pkce" === this.flowType && null != e.email && ([u, h] = await (0, o.dS)(this.storage, this.storageKey));
                            let {
                                data: c,
                                error: d
                            } = await (0, n.vE)(this.fetch, "PUT", `${this.url}/user`, {
                                headers: this.headers,
                                redirectTo: null == t ? void 0 : t.emailRedirectTo,
                                body: Object.assign(Object.assign({}, e), {
                                    code_challenge: u,
                                    code_challenge_method: h
                                }),
                                jwt: l.access_token,
                                xform: n.Cl
                            });
                            if (d) throw d;
                            return l.user = c.user, await this._saveSession(l), await this._notifyAllSubscribers("USER_UPDATED", l), this._returnResult({
                                data: {
                                    user: l.user
                                },
                                error: null
                            })
                        })
                    } catch (e) {
                        if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), (0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async setSession(e) {
                    return (await this.initializePromise, null != this.lock) ? await this._acquireLock(this.lockAcquireTimeout, async () => await this._setSession(e)) : await this._setSession(e)
                }
                async _setSession(e) {
                    try {
                        if (!e.access_token || !e.refresh_token) throw new a.jG;
                        let t = Date.now() / 1e3,
                            s = t,
                            r = !0,
                            i = null,
                            {
                                payload: n
                            } = (0, o.Cq)(e.access_token);
                        if (n.exp && (r = (s = n.exp) <= t), r) {
                            let {
                                data: t,
                                error: s
                            } = await this._callRefreshToken(e.refresh_token);
                            if (s) return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: s
                            });
                            if (!t) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: null
                            };
                            i = t
                        } else {
                            let {
                                data: r,
                                error: a
                            } = await this._getUser(e.access_token);
                            if (a) return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: a
                            });
                            i = {
                                access_token: e.access_token,
                                refresh_token: e.refresh_token,
                                user: r.user,
                                token_type: "bearer",
                                expires_in: s - t,
                                expires_at: s
                            }, await this._saveSession(i), await this._notifyAllSubscribers("SIGNED_IN", i)
                        }
                        return this._returnResult({
                            data: {
                                user: i.user,
                                session: i
                            },
                            error: null
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                session: null,
                                user: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async refreshSession(e) {
                    return (await this.initializePromise, null != this.lock) ? await this._acquireLock(this.lockAcquireTimeout, async () => await this._refreshSession(e)) : await this._refreshSession(e)
                }
                async _refreshSession(e) {
                    try {
                        return await this._useSession(async t => {
                            var s;
                            if (!e) {
                                let {
                                    data: r,
                                    error: i
                                } = t;
                                if (i) throw i;
                                e = null != (s = r.session) ? s : void 0
                            }
                            if (!(null == e ? void 0 : e.refresh_token)) throw new a.jG;
                            let {
                                data: r,
                                error: i
                            } = await this._callRefreshToken(e.refresh_token);
                            return i ? this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: i
                            }) : r ? this._returnResult({
                                data: {
                                    user: r.user,
                                    session: r
                                },
                                error: null
                            }) : this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                async _getSessionFromURL(e, t) {
                    var s;
                    try {
                        if (!(0, o.Bd)()) throw new a.MR("No browser detected.");
                        if (e.error || e.error_description || e.error_code) throw new a.MR(e.error_description || "Error in URL with unspecified error_description", {
                            error: e.error || "unspecified_error",
                            code: e.error_code || "unspecified_code"
                        });
                        switch (t) {
                            case "implicit":
                                if ("pkce" === this.flowType) throw new a.Uw("Not a valid PKCE flow url.");
                                break;
                            case "pkce":
                                if ("implicit" === this.flowType) throw new a.MR("Not a valid implicit grant flow url.")
                        }
                        if ("pkce" === t) {
                            if (this._debug("#_initialize()", "begin", "is PKCE flow", !0), !e.code) throw new a.Uw("No code detected.");
                            let {
                                data: t,
                                error: r
                            } = await this._exchangeCodeForSession(e.code);
                            if (r) throw r;
                            let i = new URL(window.location.href);
                            return i.searchParams.delete("code"), window.history.replaceState(window.history.state, "", i.toString()), {
                                data: {
                                    session: t.session,
                                    redirectType: null != (s = t.redirectType) ? s : null
                                },
                                error: null
                            }
                        }
                        let {
                            provider_token: r,
                            provider_refresh_token: n,
                            access_token: l,
                            refresh_token: u,
                            expires_in: h,
                            expires_at: c,
                            token_type: d
                        } = e;
                        if (!l || !h || !u || !d) throw new a.MR("No session defined in URL");
                        let _ = Math.round(Date.now() / 1e3),
                            w = parseInt(h),
                            g = _ + w;
                        c && (g = parseInt(c));
                        let f = g - _;
                        1e3 * f <= i.a4 && console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${f}s, should have been closer to ${w}s`);
                        let y = g - w;
                        _ - y >= 120 ? console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale", y, g, _) : _ - y < 0 && console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew", y, g, _);
                        let {
                            data: p,
                            error: b
                        } = await this._getUser(l);
                        if (b) throw b;
                        let v = {
                            provider_token: r,
                            provider_refresh_token: n,
                            access_token: l,
                            expires_in: w,
                            expires_at: g,
                            refresh_token: u,
                            token_type: d,
                            user: p.user
                        };
                        return window.location.hash = "", this._debug("#_getSessionFromURL()", "clearing window.location.hash"), this._returnResult({
                            data: {
                                session: v,
                                redirectType: e.type
                            },
                            error: null
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: {
                                session: null,
                                redirectType: null
                            },
                            error: e
                        });
                        throw e
                    }
                }
                _isImplicitGrantCallback(e) {
                    return "function" == typeof this.detectSessionInUrl ? this.detectSessionInUrl(new URL(window.location.href), e) : !!(e.access_token || e.error || e.error_description || e.error_code)
                }
                async _isPKCECallback(e) {
                    let t = await (0, o.U9)(this.storage, `${this.storageKey}-code-verifier`);
                    return !!(e.code && t)
                }
                async signOut(e = {
                    scope: "global"
                }) {
                    return (await this.initializePromise, null != this.lock) ? await this._acquireLock(this.lockAcquireTimeout, async () => await this._signOut(e)) : await this._signOut(e)
                }
                async _signOut({
                    scope: e
                } = {
                    scope: "global"
                }) {
                    return await this._useSession(async t => {
                        var s;
                        let {
                            data: r,
                            error: i
                        } = t;
                        if (i && !(0, a.zq)(i)) return this._returnResult({
                            error: i
                        });
                        let n = null == (s = r.session) ? void 0 : s.access_token;
                        if (n) {
                            let {
                                error: t
                            } = await this.admin.signOut(n, e);
                            if (t && !((0, a.NA)(t) && (404 === t.status || 401 === t.status || 403 === t.status) || (0, a.zq)(t))) return this._returnResult({
                                error: t
                            })
                        }
                        return "others" !== e && (await this._removeSession(), await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`)), this._returnResult({
                            error: null
                        })
                    })
                }
                onAuthStateChange(e) {
                    let t = (0, o.KY)(),
                        s = {
                            id: t,
                            callback: e,
                            unsubscribe: () => {
                                this._debug("#unsubscribe()", "state change callback with id removed", t), this.stateChangeEmitters.delete(t)
                            }
                        };
                    return this._debug("#onAuthStateChange()", "registered callback with id", t), this.stateChangeEmitters.set(t, s), (async () => {
                        await this.initializePromise, null != this.lock ? await this._acquireLock(this.lockAcquireTimeout, async () => {
                            this._emitInitialSession(t)
                        }) : await this._emitInitialSession(t)
                    })(), {
                        data: {
                            subscription: s
                        }
                    }
                }
                async _emitInitialSession(e) {
                    return await this._useSession(async t => {
                        var s, r;
                        try {
                            let {
                                data: {
                                    session: r
                                },
                                error: i
                            } = t;
                            if (i) throw i;
                            await (null == (s = this.stateChangeEmitters.get(e)) ? void 0 : s.callback("INITIAL_SESSION", r)), this._debug("INITIAL_SESSION", "callback id", e, "session", r)
                        } catch (t) {
                            await (null == (r = this.stateChangeEmitters.get(e)) ? void 0 : r.callback("INITIAL_SESSION", null)), this._debug("INITIAL_SESSION", "callback id", e, "error", t), (0, a.zq)(t) ? console.warn(t) : console.error(t)
                        }
                    })
                }
                async resetPasswordForEmail(e, t = {}) {
                    let s = null,
                        r = null;
                    "pkce" === this.flowType && ([s, r] = await (0, o.dS)(this.storage, this.storageKey, !0));
                    try {
                        return await (0, n.vE)(this.fetch, "POST", `${this.url}/recover`, {
                            body: {
                                email: e,
                                code_challenge: s,
                                code_challenge_method: r,
                                gotrue_meta_security: {
                                    captcha_token: t.captchaToken
                                }
                            },
                            headers: this.headers,
                            redirectTo: t.redirectTo
                        })
                    } catch (e) {
                        if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), (0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async getUserIdentities() {
                    var e;
                    try {
                        let {
                            data: t,
                            error: s
                        } = await this.getUser();
                        if (s) throw s;
                        return this._returnResult({
                            data: {
                                identities: null != (e = t.user.identities) ? e : []
                            },
                            error: null
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async linkIdentity(e) {
                    return "token" in e ? this.linkIdentityIdToken(e) : this.linkIdentityOAuth(e)
                }
                async linkIdentityOAuth(e) {
                    var t;
                    try {
                        let {
                            data: s,
                            error: r
                        } = await this._useSession(async t => {
                            var s, r, i, a, o;
                            let {
                                data: l,
                                error: u
                            } = t;
                            if (u) throw u;
                            let h = await this._getUrlForProvider(`${this.url}/user/identities/authorize`, e.provider, {
                                redirectTo: null == (s = e.options) ? void 0 : s.redirectTo,
                                scopes: null == (r = e.options) ? void 0 : r.scopes,
                                queryParams: null == (i = e.options) ? void 0 : i.queryParams,
                                skipBrowserRedirect: !0
                            });
                            return await (0, n.vE)(this.fetch, "GET", h, {
                                headers: this.headers,
                                jwt: null != (o = null == (a = l.session) ? void 0 : a.access_token) ? o : void 0
                            })
                        });
                        if (r) throw r;
                        return !(0, o.Bd)() || (null == (t = e.options) ? void 0 : t.skipBrowserRedirect) || window.location.assign(null == s ? void 0 : s.url), this._returnResult({
                            data: {
                                provider: e.provider,
                                url: null == s ? void 0 : s.url
                            },
                            error: null
                        })
                    } catch (t) {
                        if ((0, a.HY)(t)) return this._returnResult({
                            data: {
                                provider: e.provider,
                                url: null
                            },
                            error: t
                        });
                        throw t
                    }
                }
                async linkIdentityIdToken(e) {
                    return await this._useSession(async t => {
                        var s;
                        try {
                            let {
                                error: r,
                                data: {
                                    session: i
                                }
                            } = t;
                            if (r) throw r;
                            let {
                                options: o,
                                provider: l,
                                token: u,
                                access_token: h,
                                nonce: c
                            } = e, {
                                data: d,
                                error: _
                            } = await (0, n.vE)(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
                                headers: this.headers,
                                jwt: null != (s = null == i ? void 0 : i.access_token) ? s : void 0,
                                body: {
                                    provider: l,
                                    id_token: u,
                                    access_token: h,
                                    nonce: c,
                                    link_identity: !0,
                                    gotrue_meta_security: {
                                        captcha_token: null == o ? void 0 : o.captchaToken
                                    }
                                },
                                xform: n.R_
                            });
                            if (_) return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: _
                            });
                            if (!d || !d.session || !d.user) return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: new a.Ox
                            });
                            return d.session && (await this._saveSession(d.session), await this._notifyAllSubscribers("USER_UPDATED", d.session)), this._returnResult({
                                data: d,
                                error: _
                            })
                        } catch (e) {
                            if (await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`), (0, a.HY)(e)) return this._returnResult({
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: e
                            });
                            throw e
                        }
                    })
                }
                async unlinkIdentity(e) {
                    try {
                        return await this._useSession(async t => {
                            var s, r;
                            let {
                                data: i,
                                error: a
                            } = t;
                            if (a) throw a;
                            return await (0, n.vE)(this.fetch, "DELETE", `${this.url}/user/identities/${e.identity_id}`, {
                                headers: this.headers,
                                jwt: null != (r = null == (s = i.session) ? void 0 : s.access_token) ? r : void 0
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _refreshAccessToken(e) {
                    let t = "#_refreshAccessToken()";
                    this._debug(t, "begin");
                    try {
                        let s = Date.now();
                        return await (0, o.PB)(async s => (s > 0 && await (0, o.yy)(200 * Math.pow(2, s - 1)), this._debug(t, "refreshing attempt", s), await (0, n.vE)(this.fetch, "POST", `${this.url}/token?grant_type=refresh_token`, {
                            body: {
                                refresh_token: e
                            },
                            headers: this.headers,
                            xform: n.R_
                        })), (e, t) => {
                            let r = 200 * Math.pow(2, e);
                            return t && (0, a.Fw)(t) && Date.now() + r - s < i.a4
                        })
                    } catch (e) {
                        if (this._debug(t, "error", e), (0, a.HY)(e)) return this._returnResult({
                            data: {
                                session: null,
                                user: null
                            },
                            error: e
                        });
                        throw e
                    } finally {
                        this._debug(t, "end")
                    }
                }
                _isValidSession(e) {
                    return "object" == typeof e && null !== e && "access_token" in e && "refresh_token" in e && "expires_at" in e
                }
                async _handleProviderSignIn(e, t) {
                    let s = await this._getUrlForProvider(`${this.url}/authorize`, e, {
                        redirectTo: t.redirectTo,
                        scopes: t.scopes,
                        queryParams: t.queryParams
                    });
                    return this._debug("#_handleProviderSignIn()", "provider", e, "options", t, "url", s), (0, o.Bd)() && !t.skipBrowserRedirect && window.location.assign(s), {
                        data: {
                            provider: e,
                            url: s
                        },
                        error: null
                    }
                }
                async _recoverAndRefresh() {
                    var e, t;
                    let s = "#_recoverAndRefresh()";
                    this._debug(s, "begin");
                    try {
                        let r = await (0, o.U9)(this.storage, this.storageKey);
                        if (r && this.userStorage) {
                            let t = await (0, o.U9)(this.userStorage, this.storageKey + "-user");
                            !this.storage.isServer && Object.is(this.storage, this.userStorage) && !t && (t = {
                                user: r.user
                            }, await (0, o.Oi)(this.userStorage, this.storageKey + "-user", t)), r.user = null != (e = null == t ? void 0 : t.user) ? e : (0, o.QE)()
                        } else if (r && !r.user && !r.user) {
                            let e = await (0, o.U9)(this.storage, this.storageKey + "-user");
                            e && (null == e ? void 0 : e.user) ? (r.user = e.user, await (0, o.Gb)(this.storage, this.storageKey + "-user"), await (0, o.Oi)(this.storage, this.storageKey, r)) : r.user = (0, o.QE)()
                        }
                        if (this._debug(s, "session from storage", r), !this._isValidSession(r)) {
                            this._debug(s, "session is not valid"), null !== r && await this._removeSession();
                            return
                        }
                        let n = (null != (t = r.expires_at) ? t : 1 / 0) * 1e3 - Date.now() < i.CT;
                        if (this._debug(s, `session has${n?"":" not"} expired with margin of ${i.CT}s`), n) {
                            if (this.autoRefreshToken && r.refresh_token) {
                                let {
                                    error: e
                                } = await this._callRefreshToken(r.refresh_token);
                                e && ((0, a.Ru)(e) ? this._debug(s, "refresh discarded by commit guard", e) : (this._debug(s, "refresh failed", e), (0, a.Fw)(e) || (this._debug(s, "refresh failed with a non-retryable error, removing the session", e), await this._removeSession())))
                            }
                        } else if (r.user && !0 === r.user.__isUserNotAvailableProxy) try {
                            let {
                                data: e,
                                error: t
                            } = await this._getUser(r.access_token);
                            !t && (null == e ? void 0 : e.user) ? (r.user = e.user, await this._saveSession(r), await this._notifyAllSubscribers("SIGNED_IN", r)) : this._debug(s, "could not get user data, skipping SIGNED_IN notification")
                        } catch (e) {
                            console.error("Error getting user data:", e), this._debug(s, "error getting user data, skipping SIGNED_IN notification", e)
                        } else await this._notifyAllSubscribers("SIGNED_IN", r)
                    } catch (e) {
                        this._debug(s, "error", e), console.error(e);
                        return
                    } finally {
                        this._debug(s, "end")
                    }
                }
                async _callRefreshToken(e) {
                    var t, s;
                    if (!e) throw new a.jG;
                    if (this.refreshingDeferred) return this.refreshingDeferred.promise;
                    let r = "#_callRefreshToken()";
                    this._debug(r, "begin");
                    try {
                        this.refreshingDeferred = new o.cY;
                        let t = await (0, o.U9)(this.storage, this.storageKey),
                            {
                                data: s,
                                error: i
                            } = await this._refreshAccessToken(e);
                        if (i) throw i;
                        if (!s.session) throw new a.jG;
                        let n = await (0, o.U9)(this.storage, this.storageKey);
                        if (null !== t && (null === n || n.refresh_token !== t.refresh_token)) {
                            this._debug(r, "commit guard: storage changed since refresh started, discarding rotated tokens", {
                                startedWith: "present",
                                nowHolds: n ? "replaced" : "cleared"
                            });
                            let e = {
                                data: null,
                                error: new a.FE
                            };
                            return this.refreshingDeferred.resolve(e), e
                        }
                        let l = this._sessionRemovalEpoch;
                        if (await this._saveSession(s.session), this._sessionRemovalEpoch !== l) {
                            this._debug(r, "commit guard (post-save): _removeSession ran during _saveSession, undoing write"), await (0, o.Gb)(this.storage, this.storageKey), this.userStorage && await (0, o.Gb)(this.userStorage, this.storageKey + "-user");
                            let e = {
                                data: null,
                                error: new a.FE
                            };
                            return this.refreshingDeferred.resolve(e), e
                        }
                        await this._notifyAllSubscribers("TOKEN_REFRESHED", s.session);
                        let u = {
                            data: s.session,
                            error: null
                        };
                        return this.refreshingDeferred.resolve(u), u
                    } catch (e) {
                        if (this._debug(r, "error", e), (0, a.HY)(e)) {
                            let s = {
                                data: null,
                                error: e
                            };
                            return (0, a.Fw)(e) || await this._removeSession(), null == (t = this.refreshingDeferred) || t.resolve(s), s
                        }
                        throw null == (s = this.refreshingDeferred) || s.reject(e), e
                    } finally {
                        this.refreshingDeferred = null, this._debug(r, "end")
                    }
                }
                async _notifyAllSubscribers(e, t, s = !0) {
                    let r = `#_notifyAllSubscribers(${e})`;
                    this._debug(r, "begin", t, `broadcast = ${s}`);
                    try {
                        this.broadcastChannel && s && this.broadcastChannel.postMessage({
                            event: e,
                            session: t
                        });
                        let r = [],
                            i = Array.from(this.stateChangeEmitters.values()).map(async s => {
                                try {
                                    await s.callback(e, t)
                                } catch (e) {
                                    r.push(e)
                                }
                            });
                        if (await Promise.all(i), r.length > 0) {
                            for (let e = 0; e < r.length; e += 1) console.error(r[e]);
                            throw r[0]
                        }
                    } finally {
                        this._debug(r, "end")
                    }
                }
                async _saveSession(e) {
                    this._debug("#_saveSession()", e), this.suppressGetSessionWarning = !0, await (0, o.Gb)(this.storage, `${this.storageKey}-code-verifier`);
                    let t = Object.assign({}, e),
                        s = t.user && !0 === t.user.__isUserNotAvailableProxy;
                    if (this.userStorage) {
                        !s && t.user && await (0, o.Oi)(this.userStorage, this.storageKey + "-user", {
                            user: t.user
                        });
                        let e = Object.assign({}, t);
                        delete e.user;
                        let r = (0, o.Go)(e);
                        await (0, o.Oi)(this.storage, this.storageKey, r)
                    } else {
                        let e = (0, o.Go)(t);
                        await (0, o.Oi)(this.storage, this.storageKey, e)
                    }
                }
                async _removeSession() {
                    this._sessionRemovalEpoch += 1, this._debug("#_removeSession()"), this.suppressGetSessionWarning = !1, await (0, o.Gb)(this.storage, this.storageKey), await (0, o.Gb)(this.storage, this.storageKey + "-code-verifier"), await (0, o.Gb)(this.storage, this.storageKey + "-user"), this.userStorage && await (0, o.Gb)(this.userStorage, this.storageKey + "-user"), await this._notifyAllSubscribers("SIGNED_OUT", null)
                }
                _removeVisibilityChangedCallback() {
                    this._debug("#_removeVisibilityChangedCallback()");
                    let e = this.visibilityChangedCallback;
                    this.visibilityChangedCallback = null;
                    try {
                        e && (0, o.Bd)() && (null == window ? void 0 : window.removeEventListener) && window.removeEventListener("visibilitychange", e)
                    } catch (e) {
                        console.error("removing visibilitychange callback failed", e)
                    }
                }
                async _startAutoRefresh() {
                    await this._stopAutoRefresh(), this._debug("#_startAutoRefresh()");
                    let e = setInterval(() => this._autoRefreshTokenTick(), i.a4);
                    this.autoRefreshTicker = e, e && "object" == typeof e && "function" == typeof e.unref ? e.unref() : "u" > typeof Deno && "function" == typeof Deno.unrefTimer && Deno.unrefTimer(e);
                    let t = setTimeout(async () => {
                        await this.initializePromise, await this._autoRefreshTokenTick()
                    }, 0);
                    this.autoRefreshTickTimeout = t, t && "object" == typeof t && "function" == typeof t.unref ? t.unref() : "u" > typeof Deno && "function" == typeof Deno.unrefTimer && Deno.unrefTimer(t)
                }
                async _stopAutoRefresh() {
                    this._debug("#_stopAutoRefresh()");
                    let e = this.autoRefreshTicker;
                    this.autoRefreshTicker = null, e && clearInterval(e);
                    let t = this.autoRefreshTickTimeout;
                    this.autoRefreshTickTimeout = null, t && clearTimeout(t)
                }
                async startAutoRefresh() {
                    this._removeVisibilityChangedCallback(), await this._startAutoRefresh()
                }
                async stopAutoRefresh() {
                    this._removeVisibilityChangedCallback(), await this._stopAutoRefresh()
                }
                async dispose() {
                    var e;
                    this._removeVisibilityChangedCallback(), await this._stopAutoRefresh(), null == (e = this.broadcastChannel) || e.close(), this.broadcastChannel = null, this.stateChangeEmitters.clear()
                }
                async _autoRefreshTokenTick() {
                    if (this._debug("#_autoRefreshTokenTick()", "begin"), null != this.lock) {
                        try {
                            await this._acquireLock(0, async () => {
                                try {
                                    let e = Date.now();
                                    try {
                                        return await this._useSession(async t => {
                                            let {
                                                data: {
                                                    session: s
                                                }
                                            } = t;
                                            if (!s || !s.refresh_token || !s.expires_at) return void this._debug("#_autoRefreshTokenTick()", "no session");
                                            let r = Math.floor((1e3 * s.expires_at - e) / i.a4);
                                            this._debug("#_autoRefreshTokenTick()", `access token expires in ${r} ticks, a tick lasts ${i.a4}ms, refresh threshold is ${i.YI} ticks`), r <= i.YI && await this._callRefreshToken(s.refresh_token)
                                        })
                                    } catch (e) {
                                        console.error("Auto refresh tick failed with error. This is likely a transient error.", e)
                                    }
                                } finally {
                                    this._debug("#_autoRefreshTokenTick()", "end")
                                }
                            })
                        } catch (e) {
                            if (e instanceof u.nb) this._debug("auto refresh token tick lock not available");
                            else throw e
                        }
                        return
                    }
                    if (null !== this.refreshingDeferred) return void this._debug("#_autoRefreshTokenTick()", "refresh already in flight, skipping");
                    try {
                        let e = Date.now();
                        try {
                            await this._useSession(async t => {
                                let {
                                    data: {
                                        session: s
                                    }
                                } = t;
                                if (!s || !s.refresh_token || !s.expires_at) return void this._debug("#_autoRefreshTokenTick()", "no session");
                                let r = Math.floor((1e3 * s.expires_at - e) / i.a4);
                                this._debug("#_autoRefreshTokenTick()", `access token expires in ${r} ticks, a tick lasts ${i.a4}ms, refresh threshold is ${i.YI} ticks`), r <= i.YI && await this._callRefreshToken(s.refresh_token)
                            })
                        } catch (e) {
                            console.error("Auto refresh tick failed with error. This is likely a transient error.", e)
                        }
                    } finally {
                        this._debug("#_autoRefreshTokenTick()", "end")
                    }
                }
                async _handleVisibilityChange() {
                    if (this._debug("#_handleVisibilityChange()"), !(0, o.Bd)() || !(null == window ? void 0 : window.addEventListener)) return this.autoRefreshToken && this.startAutoRefresh(), !1;
                    try {
                        this.visibilityChangedCallback = async () => {
                            try {
                                await this._onVisibilityChanged(!1)
                            } catch (e) {
                                this._debug("#visibilityChangedCallback", "error", e)
                            }
                        }, null == window || window.addEventListener("visibilitychange", this.visibilityChangedCallback), await this._onVisibilityChanged(!0)
                    } catch (e) {
                        console.error("_handleVisibilityChange", e)
                    }
                }
                async _onVisibilityChanged(e) {
                    let t = `#_onVisibilityChanged(${e})`;
                    if (this._debug(t, "visibilityState", document.visibilityState), "visible" === document.visibilityState) {
                        if (this.autoRefreshToken && this._startAutoRefresh(), !e)
                            if (await this.initializePromise, null != this.lock) await this._acquireLock(this.lockAcquireTimeout, async () => {
                                "visible" !== document.visibilityState ? this._debug(t, "acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting") : await this._recoverAndRefresh()
                            });
                            else {
                                if ("visible" !== document.visibilityState) return void this._debug(t, "visibilityState is no longer visible, skipping recovery");
                                await this._recoverAndRefresh()
                            }
                    } else "hidden" === document.visibilityState && this.autoRefreshToken && this._stopAutoRefresh()
                }
                async _getUrlForProvider(e, t, s) {
                    let r = [`provider=${encodeURIComponent(t)}`];
                    if ((null == s ? void 0 : s.redirectTo) && r.push(`redirect_to=${encodeURIComponent(s.redirectTo)}`), (null == s ? void 0 : s.scopes) && r.push(`scopes=${encodeURIComponent(s.scopes)}`), "pkce" === this.flowType) {
                        let [e, t] = await (0, o.dS)(this.storage, this.storageKey), s = new URLSearchParams({
                            code_challenge: `${encodeURIComponent(e)}`,
                            code_challenge_method: `${encodeURIComponent(t)}`
                        });
                        r.push(s.toString())
                    }
                    if (null == s ? void 0 : s.queryParams) {
                        let e = new URLSearchParams(s.queryParams);
                        r.push(e.toString())
                    }
                    return (null == s ? void 0 : s.skipBrowserRedirect) && r.push(`skip_http_redirect=${s.skipBrowserRedirect}`), `${e}?${r.join("&")}`
                }
                async _unenroll(e) {
                    try {
                        return await this._useSession(async t => {
                            var s;
                            let {
                                data: r,
                                error: i
                            } = t;
                            return i ? this._returnResult({
                                data: null,
                                error: i
                            }) : await (0, n.vE)(this.fetch, "DELETE", `${this.url}/factors/${e.factorId}`, {
                                headers: this.headers,
                                jwt: null == (s = null == r ? void 0 : r.session) ? void 0 : s.access_token
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _enroll(e) {
                    try {
                        return await this._useSession(async t => {
                            var s, r;
                            let {
                                data: i,
                                error: a
                            } = t;
                            if (a) return this._returnResult({
                                data: null,
                                error: a
                            });
                            let o = Object.assign({
                                    friendly_name: e.friendlyName,
                                    factor_type: e.factorType
                                }, "phone" === e.factorType ? {
                                    phone: e.phone
                                } : "totp" === e.factorType ? {
                                    issuer: e.issuer
                                } : {}),
                                {
                                    data: l,
                                    error: u
                                } = await (0, n.vE)(this.fetch, "POST", `${this.url}/factors`, {
                                    body: o,
                                    headers: this.headers,
                                    jwt: null == (s = null == i ? void 0 : i.session) ? void 0 : s.access_token
                                });
                            return u ? this._returnResult({
                                data: null,
                                error: u
                            }) : ("totp" === e.factorType && "totp" === l.type && (null == (r = null == l ? void 0 : l.totp) ? void 0 : r.qr_code) && (l.totp.qr_code = `data:image/svg+xml;utf-8,${l.totp.qr_code}`), this._returnResult({
                                data: l,
                                error: null
                            }))
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _verify(e) {
                    let t = async () => {
                        try {
                            return await this._useSession(async t => {
                                var s;
                                let {
                                    data: r,
                                    error: i
                                } = t;
                                if (i) return this._returnResult({
                                    data: null,
                                    error: i
                                });
                                let a = Object.assign({
                                        challenge_id: e.challengeId
                                    }, "webauthn" in e ? {
                                        webauthn: Object.assign(Object.assign({}, e.webauthn), {
                                            credential_response: "create" === e.webauthn.type ? (0, w.sy)(e.webauthn.credential_response) : (0, w.CP)(e.webauthn.credential_response)
                                        })
                                    } : {
                                        code: e.code
                                    }),
                                    {
                                        data: o,
                                        error: l
                                    } = await (0, n.vE)(this.fetch, "POST", `${this.url}/factors/${e.factorId}/verify`, {
                                        body: a,
                                        headers: this.headers,
                                        jwt: null == (s = null == r ? void 0 : r.session) ? void 0 : s.access_token
                                    });
                                return l ? this._returnResult({
                                    data: null,
                                    error: l
                                }) : (await this._saveSession(Object.assign({
                                    expires_at: Math.round(Date.now() / 1e3) + o.expires_in
                                }, o)), await this._notifyAllSubscribers("MFA_CHALLENGE_VERIFIED", o), this._returnResult({
                                    data: o,
                                    error: l
                                }))
                            })
                        } catch (e) {
                            if ((0, a.HY)(e)) return this._returnResult({
                                data: null,
                                error: e
                            });
                            throw e
                        }
                    };
                    return null != this.lock ? this._acquireLock(this.lockAcquireTimeout, t) : t()
                }
                async _challenge(e) {
                    let t = async () => {
                        try {
                            return await this._useSession(async t => {
                                var s;
                                let {
                                    data: r,
                                    error: i
                                } = t;
                                if (i) return this._returnResult({
                                    data: null,
                                    error: i
                                });
                                let a = await (0, n.vE)(this.fetch, "POST", `${this.url}/factors/${e.factorId}/challenge`, {
                                    body: e,
                                    headers: this.headers,
                                    jwt: null == (s = null == r ? void 0 : r.session) ? void 0 : s.access_token
                                });
                                if (a.error) return a;
                                let {
                                    data: o
                                } = a;
                                if ("webauthn" !== o.type) return {
                                    data: o,
                                    error: null
                                };
                                switch (o.webauthn.type) {
                                    case "create":
                                        return {
                                            data: Object.assign(Object.assign({}, o), {
                                                webauthn: Object.assign(Object.assign({}, o.webauthn), {
                                                    credential_options: Object.assign(Object.assign({}, o.webauthn.credential_options), {
                                                        publicKey: (0, w.sC)(o.webauthn.credential_options.publicKey)
                                                    })
                                                })
                                            }),
                                            error: null
                                        };
                                    case "request":
                                        return {
                                            data: Object.assign(Object.assign({}, o), {
                                                webauthn: Object.assign(Object.assign({}, o.webauthn), {
                                                    credential_options: Object.assign(Object.assign({}, o.webauthn.credential_options), {
                                                        publicKey: (0, w.KE)(o.webauthn.credential_options.publicKey)
                                                    })
                                                })
                                            }),
                                            error: null
                                        }
                                }
                            })
                        } catch (e) {
                            if ((0, a.HY)(e)) return this._returnResult({
                                data: null,
                                error: e
                            });
                            throw e
                        }
                    };
                    return null != this.lock ? this._acquireLock(this.lockAcquireTimeout, t) : t()
                }
                async _challengeAndVerify(e) {
                    let {
                        data: t,
                        error: s
                    } = await this._challenge({
                        factorId: e.factorId
                    });
                    return s ? this._returnResult({
                        data: null,
                        error: s
                    }) : await this._verify({
                        factorId: e.factorId,
                        challengeId: t.id,
                        code: e.code
                    })
                }
                async _listFactors() {
                    var e;
                    let {
                        data: {
                            user: t
                        },
                        error: s
                    } = await this.getUser();
                    if (s) return {
                        data: null,
                        error: s
                    };
                    let r = {
                        all: [],
                        phone: [],
                        totp: [],
                        webauthn: []
                    };
                    for (let s of null != (e = null == t ? void 0 : t.factors) ? e : []) r.all.push(s), "verified" === s.status && r[s.factor_type].push(s);
                    return {
                        data: r,
                        error: null
                    }
                }
                async _getAuthenticatorAssuranceLevel(e) {
                    var t, s, r, i;
                    if (e) try {
                        let {
                            payload: r
                        } = (0, o.Cq)(e), i = null;
                        r.aal && (i = r.aal);
                        let a = i,
                            {
                                data: {
                                    user: n
                                },
                                error: l
                            } = await this.getUser(e);
                        if (l) return this._returnResult({
                            data: null,
                            error: l
                        });
                        (null != (s = null == (t = null == n ? void 0 : n.factors) ? void 0 : t.filter(e => "verified" === e.status)) ? s : []).length > 0 && (a = "aal2");
                        let u = r.amr || [];
                        return {
                            data: {
                                currentLevel: i,
                                nextLevel: a,
                                currentAuthenticationMethods: u
                            },
                            error: null
                        }
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                    let {
                        data: {
                            session: n
                        },
                        error: l
                    } = await this.getSession();
                    if (l) return this._returnResult({
                        data: null,
                        error: l
                    });
                    if (!n) return {
                        data: {
                            currentLevel: null,
                            nextLevel: null,
                            currentAuthenticationMethods: []
                        },
                        error: null
                    };
                    let {
                        payload: u
                    } = (0, o.Cq)(n.access_token), h = null;
                    u.aal && (h = u.aal);
                    let c = h;
                    return (null != (i = null == (r = n.user.factors) ? void 0 : r.filter(e => "verified" === e.status)) ? i : []).length > 0 && (c = "aal2"), {
                        data: {
                            currentLevel: h,
                            nextLevel: c,
                            currentAuthenticationMethods: u.amr || []
                        },
                        error: null
                    }
                }
                async _getAuthorizationDetails(e) {
                    try {
                        return await this._useSession(async t => {
                            let {
                                data: {
                                    session: s
                                },
                                error: r
                            } = t;
                            return r ? this._returnResult({
                                data: null,
                                error: r
                            }) : s ? await (0, n.vE)(this.fetch, "GET", `${this.url}/oauth/authorizations/${e}`, {
                                headers: this.headers,
                                jwt: s.access_token,
                                xform: e => ({
                                    data: e,
                                    error: null
                                })
                            }) : this._returnResult({
                                data: null,
                                error: new a.jG
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _approveAuthorization(e, t) {
                    try {
                        return await this._useSession(async s => {
                            let {
                                data: {
                                    session: r
                                },
                                error: i
                            } = s;
                            if (i) return this._returnResult({
                                data: null,
                                error: i
                            });
                            if (!r) return this._returnResult({
                                data: null,
                                error: new a.jG
                            });
                            let l = await (0, n.vE)(this.fetch, "POST", `${this.url}/oauth/authorizations/${e}/consent`, {
                                headers: this.headers,
                                jwt: r.access_token,
                                body: {
                                    action: "approve"
                                },
                                xform: e => ({
                                    data: e,
                                    error: null
                                })
                            });
                            return l.data && l.data.redirect_url && (0, o.Bd)() && !(null == t ? void 0 : t.skipBrowserRedirect) && window.location.assign(l.data.redirect_url), l
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _denyAuthorization(e, t) {
                    try {
                        return await this._useSession(async s => {
                            let {
                                data: {
                                    session: r
                                },
                                error: i
                            } = s;
                            if (i) return this._returnResult({
                                data: null,
                                error: i
                            });
                            if (!r) return this._returnResult({
                                data: null,
                                error: new a.jG
                            });
                            let l = await (0, n.vE)(this.fetch, "POST", `${this.url}/oauth/authorizations/${e}/consent`, {
                                headers: this.headers,
                                jwt: r.access_token,
                                body: {
                                    action: "deny"
                                },
                                xform: e => ({
                                    data: e,
                                    error: null
                                })
                            });
                            return l.data && l.data.redirect_url && (0, o.Bd)() && !(null == t ? void 0 : t.skipBrowserRedirect) && window.location.assign(l.data.redirect_url), l
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _listOAuthGrants() {
                    try {
                        return await this._useSession(async e => {
                            let {
                                data: {
                                    session: t
                                },
                                error: s
                            } = e;
                            return s ? this._returnResult({
                                data: null,
                                error: s
                            }) : t ? await (0, n.vE)(this.fetch, "GET", `${this.url}/user/oauth/grants`, {
                                headers: this.headers,
                                jwt: t.access_token,
                                xform: e => ({
                                    data: e,
                                    error: null
                                })
                            }) : this._returnResult({
                                data: null,
                                error: new a.jG
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _revokeOAuthGrant(e) {
                    try {
                        return await this._useSession(async t => {
                            let {
                                data: {
                                    session: s
                                },
                                error: r
                            } = t;
                            return r ? this._returnResult({
                                data: null,
                                error: r
                            }) : s ? (await (0, n.vE)(this.fetch, "DELETE", `${this.url}/user/oauth/grants`, {
                                headers: this.headers,
                                jwt: s.access_token,
                                query: {
                                    client_id: e.clientId
                                },
                                noResolveJson: !0
                            }), {
                                data: {},
                                error: null
                            }) : this._returnResult({
                                data: null,
                                error: new a.jG
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async fetchJwk(e, t = {
                    keys: []
                }) {
                    let s = t.keys.find(t => t.kid === e);
                    if (s) return s;
                    let r = Date.now();
                    if ((s = this.jwks.keys.find(t => t.kid === e)) && this.jwks_cached_at + i.$W > r) return s;
                    let {
                        data: a,
                        error: o
                    } = await (0, n.vE)(this.fetch, "GET", `${this.url}/.well-known/jwks.json`, {
                        headers: this.headers
                    });
                    if (o) throw o;
                    return a.keys && 0 !== a.keys.length && (this.jwks = a, this.jwks_cached_at = r, s = a.keys.find(t => t.kid === e)) ? s : null
                }
                async getClaims(e, t = {}) {
                    try {
                        let s = e;
                        if (!s) {
                            let {
                                data: e,
                                error: t
                            } = await this.getSession();
                            if (t || !e.session) return this._returnResult({
                                data: null,
                                error: t
                            });
                            s = e.session.access_token
                        }
                        let {
                            header: r,
                            payload: i,
                            signature: n,
                            raw: {
                                header: l,
                                payload: u
                            }
                        } = (0, o.Cq)(s);
                        if (!(null == t ? void 0 : t.allowExpired)) try {
                            (0, o.c2)(i.exp)
                        } catch (e) {
                            throw new a.xL(e instanceof Error ? e.message : "JWT validation failed")
                        }
                        let h = !r.alg || r.alg.startsWith("HS") || !r.kid || !("crypto" in globalThis && "subtle" in globalThis.crypto) ? null : await this.fetchJwk(r.kid, (null == t ? void 0 : t.keys) ? {
                            keys: t.keys
                        } : null == t ? void 0 : t.jwks);
                        if (!h) {
                            let {
                                error: e
                            } = await this.getUser(s);
                            if (e) throw e;
                            return {
                                data: {
                                    claims: i,
                                    header: r,
                                    signature: n
                                },
                                error: null
                            }
                        }
                        let c = (0, o.K8)(r.alg),
                            _ = await crypto.subtle.importKey("jwk", h, c, !0, ["verify"]);
                        if (!await crypto.subtle.verify(c, _, n, (0, d.Al)(`${l}.${u}`))) throw new a.xL("Invalid JWT signature");
                        return {
                            data: {
                                claims: i,
                                header: r,
                                signature: n
                            },
                            error: null
                        }
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async signInWithPasskey(e) {
                    var t, s, r;
                    (0, o.aA)(this.experimental);
                    try {
                        if (!(0, w.zZ)()) return this._returnResult({
                            data: null,
                            error: new a.HU("Browser does not support WebAuthn", null)
                        });
                        let {
                            data: i,
                            error: n
                        } = await this._startPasskeyAuthentication({
                            options: {
                                captchaToken: null == (t = null == e ? void 0 : e.options) ? void 0 : t.captchaToken
                            }
                        });
                        if (n || !i) return this._returnResult({
                            data: null,
                            error: n
                        });
                        let o = (0, w.KE)(i.options),
                            l = null != (r = null == (s = null == e ? void 0 : e.options) ? void 0 : s.signal) ? r : w.uL.createNewAbortSignal(),
                            {
                                data: u,
                                error: h
                            } = await (0, w.w_)({
                                publicKey: o,
                                signal: l
                            });
                        if (h || !u) return this._returnResult({
                            data: null,
                            error: null != h ? h : new a.HU("WebAuthn ceremony failed", null)
                        });
                        let c = (0, w.CP)(u);
                        return this._verifyPasskeyAuthentication({
                            challengeId: i.challenge_id,
                            credential: c
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async registerPasskey(e) {
                    var t, s;
                    (0, o.aA)(this.experimental);
                    try {
                        if (!(0, w.zZ)()) return this._returnResult({
                            data: null,
                            error: new a.HU("Browser does not support WebAuthn", null)
                        });
                        let {
                            data: r,
                            error: i
                        } = await this._startPasskeyRegistration();
                        if (i || !r) return this._returnResult({
                            data: null,
                            error: i
                        });
                        let n = (0, w.sC)(r.options),
                            o = null != (s = null == (t = null == e ? void 0 : e.options) ? void 0 : t.signal) ? s : w.uL.createNewAbortSignal(),
                            {
                                data: l,
                                error: u
                            } = await (0, w.GO)({
                                publicKey: n,
                                signal: o
                            });
                        if (u || !l) return this._returnResult({
                            data: null,
                            error: null != u ? u : new a.HU("WebAuthn ceremony failed", null)
                        });
                        let h = (0, w.sy)(l);
                        return this._verifyPasskeyRegistration({
                            challengeId: r.challenge_id,
                            credential: h
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _startPasskeyRegistration() {
                    (0, o.aA)(this.experimental);
                    try {
                        return await this._useSession(async e => {
                            let {
                                data: {
                                    session: t
                                },
                                error: s
                            } = e;
                            if (s) return this._returnResult({
                                data: null,
                                error: s
                            });
                            if (!t) return this._returnResult({
                                data: null,
                                error: new a.jG
                            });
                            let {
                                data: r,
                                error: i
                            } = await (0, n.vE)(this.fetch, "POST", `${this.url}/passkeys/registration/options`, {
                                headers: this.headers,
                                jwt: t.access_token,
                                body: {}
                            });
                            return i ? this._returnResult({
                                data: null,
                                error: i
                            }) : this._returnResult({
                                data: r,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _verifyPasskeyRegistration(e) {
                    (0, o.aA)(this.experimental);
                    try {
                        return await this._useSession(async t => {
                            let {
                                data: {
                                    session: s
                                },
                                error: r
                            } = t;
                            if (r) return this._returnResult({
                                data: null,
                                error: r
                            });
                            if (!s) return this._returnResult({
                                data: null,
                                error: new a.jG
                            });
                            let {
                                data: i,
                                error: o
                            } = await (0, n.vE)(this.fetch, "POST", `${this.url}/passkeys/registration/verify`, {
                                headers: this.headers,
                                jwt: s.access_token,
                                body: {
                                    challenge_id: e.challengeId,
                                    credential: e.credential
                                }
                            });
                            return o ? this._returnResult({
                                data: null,
                                error: o
                            }) : this._returnResult({
                                data: i,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _startPasskeyAuthentication(e) {
                    var t;
                    (0, o.aA)(this.experimental);
                    try {
                        let {
                            data: s,
                            error: r
                        } = await (0, n.vE)(this.fetch, "POST", `${this.url}/passkeys/authentication/options`, {
                            headers: this.headers,
                            body: {
                                gotrue_meta_security: {
                                    captcha_token: null == (t = null == e ? void 0 : e.options) ? void 0 : t.captchaToken
                                }
                            }
                        });
                        if (r) return this._returnResult({
                            data: null,
                            error: r
                        });
                        return this._returnResult({
                            data: s,
                            error: null
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _verifyPasskeyAuthentication(e) {
                    (0, o.aA)(this.experimental);
                    try {
                        let {
                            data: t,
                            error: s
                        } = await (0, n.vE)(this.fetch, "POST", `${this.url}/passkeys/authentication/verify`, {
                            headers: this.headers,
                            body: {
                                challenge_id: e.challengeId,
                                credential: e.credential
                            },
                            xform: n.R_
                        });
                        if (s) return this._returnResult({
                            data: null,
                            error: s
                        });
                        return t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers("SIGNED_IN", t.session)), this._returnResult({
                            data: t,
                            error: null
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _listPasskeys() {
                    (0, o.aA)(this.experimental);
                    try {
                        return await this._useSession(async e => {
                            let {
                                data: {
                                    session: t
                                },
                                error: s
                            } = e;
                            if (s) return this._returnResult({
                                data: null,
                                error: s
                            });
                            if (!t) return this._returnResult({
                                data: null,
                                error: new a.jG
                            });
                            let {
                                data: r,
                                error: i
                            } = await (0, n.vE)(this.fetch, "GET", `${this.url}/passkeys`, {
                                headers: this.headers,
                                jwt: t.access_token,
                                xform: e => ({
                                    data: e,
                                    error: null
                                })
                            });
                            return i ? this._returnResult({
                                data: null,
                                error: i
                            }) : this._returnResult({
                                data: r,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _updatePasskey(e) {
                    (0, o.aA)(this.experimental);
                    try {
                        return await this._useSession(async t => {
                            let {
                                data: {
                                    session: s
                                },
                                error: r
                            } = t;
                            if (r) return this._returnResult({
                                data: null,
                                error: r
                            });
                            if (!s) return this._returnResult({
                                data: null,
                                error: new a.jG
                            });
                            let {
                                data: i,
                                error: o
                            } = await (0, n.vE)(this.fetch, "PATCH", `${this.url}/passkeys/${e.passkeyId}`, {
                                headers: this.headers,
                                jwt: s.access_token,
                                body: {
                                    friendly_name: e.friendlyName
                                }
                            });
                            return o ? this._returnResult({
                                data: null,
                                error: o
                            }) : this._returnResult({
                                data: i,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
                async _deletePasskey(e) {
                    (0, o.aA)(this.experimental);
                    try {
                        return await this._useSession(async t => {
                            let {
                                data: {
                                    session: s
                                },
                                error: r
                            } = t;
                            if (r) return this._returnResult({
                                data: null,
                                error: r
                            });
                            if (!s) return this._returnResult({
                                data: null,
                                error: new a.jG
                            });
                            let {
                                error: i
                            } = await (0, n.vE)(this.fetch, "DELETE", `${this.url}/passkeys/${e.passkeyId}`, {
                                headers: this.headers,
                                jwt: s.access_token,
                                noResolveJson: !0
                            });
                            return i ? this._returnResult({
                                data: null,
                                error: i
                            }) : this._returnResult({
                                data: null,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, a.HY)(e)) return this._returnResult({
                            data: null,
                            error: e
                        });
                        throw e
                    }
                }
            }
            y.nextInstanceID = {};
            let p = y
        }
    }
]);