(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [87191], {
        34059: () => {},
        66111: (e, t, n) => {
            "use strict";

            function l(e) {
                let t = e % 360;
                return t < 0 ? t + 360 : 0 === t ? 0 : t
            }

            function o(e) {
                return 360 / Math.max(1, e)
            }

            function r({
                current: e,
                index: t,
                count: n,
                turns: i = 5,
                offset: a = .5
            }) {
                let s = Math.max(1, n),
                    u = l(-((Math.min(s - 1, Math.max(0, Math.floor(t))) + Math.min(.82, Math.max(.18, a))) * o(s))),
                    c = e + 360 * Math.max(0, Math.floor(i));
                return c + l(u - l(c))
            }

            function i(e, t, n, l, o = 5) {
                let a = Math.max(1, t),
                    s = Math.min(a - 1, Math.floor(Math.max(0, n) * a)),
                    u = r({
                        current: e,
                        index: s,
                        count: a,
                        turns: o,
                        offset: l
                    });
                return {
                    index: s,
                    rotation: u
                }
            }

            function a(e, t, n) {
                let l = o(n);
                return Math.abs(Math.floor(t / l) - Math.floor(e / l))
            }

            function s(e, t, n) {
                if (n <= 1) return 0;
                let l = e % n;
                if (t > 1 && e === t - 1 && 0 === l) {
                    let e = (t - 2) % n;
                    for (let t = 1; t < n; t += 1)
                        if (t !== e) return t
                }
                return l
            }

            function u(e, t) {
                let n = Math.max(1, e),
                    l = o(n),
                    r = [];
                for (let e = 0; e < n; e += 1) {
                    let o = t[s(e, n, t.length)] ? ? "currentColor";
                    r.push(`${o} ${$(e*l)}deg ${$((e+1)*l)}deg`)
                }
                return `conic-gradient(from 0deg, ${r.join(", ")})`
            }

            function c(e, t) {
                return (e + .5) * o(t)
            }

            function d(e, t, n, l) {
                let o = 3 * e,
                    r = 3 * (n - e) - o,
                    i = 1 - o - r,
                    a = 3 * t,
                    s = 3 * (l - t) - a,
                    u = 1 - a - s,
                    c = e => ((i * e + r) * e + o) * e,
                    d = e => ((u * e + s) * e + a) * e,
                    f = e => (3 * i * e + 2 * r) * e + o;
                return e => {
                    if (e <= 0) return 0;
                    if (e >= 1) return 1;
                    let t = e;
                    for (let n = 0; n < 8; n += 1) {
                        let n = c(t) - e;
                        if (1e-6 > Math.abs(n)) return d(t);
                        let l = f(t);
                        if (1e-6 > Math.abs(l)) break;
                        t -= n / l
                    }
                    let n = 0,
                        l = 1;
                    t = e;
                    for (let o = 0; o < 40; o += 1) {
                        let o = c(t);
                        if (1e-6 > Math.abs(o - e)) break;
                        o < e ? n = t : l = t, t = (n + l) / 2
                    }
                    return d(t)
                }
            }
            n.d(t, {
                AK: () => d,
                FN: () => x,
                MH: () => u,
                Ol: () => p,
                Xv: () => o,
                YJ: () => N,
                _9: () => w,
                c$: () => h,
                cR: () => C,
                eM: () => y,
                ed: () => c,
                fP: () => m,
                g1: () => g,
                iX: () => r,
                jb: () => b,
                oy: () => i,
                qr: () => k,
                qs: () => f,
                v7: () => s,
                vp: () => a,
                wA: () => M,
                wC: () => j
            });
            let f = [.12, .72, .16, 1],
                h = `cubic-bezier(${f.join(", ")})`,
                p = 4200,
                m = 450;

            function x(e, t) {
                let n = Math.max(0, Math.floor(t)),
                    l = new Set;
                for (let t of e) t >= 0 && t < n && l.add(t);
                let o = l.size;
                return {
                    popped: o,
                    total: n,
                    remaining: n - o,
                    done: n > 0 && o >= n
                }
            }

            function v(e) {
                let t = Math.imul(0x9e3779b9 ^ e, 0x85ebca6b);
                return t ^= t >>> 13, t = Math.imul(t, 0xc2b2ae35), ((t ^= t >>> 16) >>> 0) / 0x100000000
            }

            function b(e) {
                return {
                    duration: $(3.2 + 2.2 * v(7 * e + 1)),
                    delay: -$(3 * v(7 * e + 2)),
                    drift: $(6 + 8 * v(7 * e + 3)),
                    tilt: $((v(7 * e + 4) - .5) * 16)
                }
            }

            function j(e, t = 1, n = 5) {
                let l = ["dot", "strip", "heart"];
                return Array.from({
                    length: Math.max(0, e)
                }, (o, r) => {
                    let i = e => v(1009 * t + 31 * r + e);
                    return {
                        angle: $(r / Math.max(1, e) * 360 + (i(1) - .5) * 30),
                        distance: $(90 + 150 * i(2)),
                        spin: $((i(3) - .5) * 720),
                        delay: Math.round(90 * i(4)),
                        colour: Math.floor(i(5) * Math.max(1, n)),
                        shape: l[Math.floor(i(6) * l.length)]
                    }
                })
            }

            function M(e, t) {
                return Math.min(100, Math.max(0, e) + Math.max(1, t))
            }

            function g(e) {
                let t = /-?\d+(?:\.\d+)?/.exec(e);
                if (!t) return 0;
                let n = Number(t[0]);
                return Number.isFinite(n) ? Math.min(100, Math.max(0, Math.round(n))) : 0
            }

            function y(e, t, n = 14) {
                let l = Math.min(1, Math.max(0, e));
                return {
                    rotateX: $((.5 - Math.min(1, Math.max(0, t))) * 2 * n),
                    rotateY: $((l - .5) * 2 * n)
                }
            }

            function C(e, t, n = .12) {
                return e >= t ? e : $(t - (t - e) * n)
            }

            function N(e, t) {
                return Math.max(t, e)
            }

            function w(e, t) {
                return e >= t ? {
                    kind: "overflow"
                } : {
                    kind: "percent",
                    value: Math.max(0, Math.round(e))
                }
            }

            function k(e, t) {
                return t <= 0 ? -1 : Math.max(0, e) % t
            }

            function $(e) {
                return Math.round(1e3 * e) / 1e3
            }
        },
        87191: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                BootPopup: () => X,
                BootScreen: () => W,
                Comeback: () => H,
                ConfettiBurst: () => S,
                ConfettiOnShow: () => E,
                Countdown: () => M,
                EnvelopeGate: () => u,
                FOLIO_REPLAY_EVENT: () => w,
                LoveMeter: () => z,
                PhotoReveal: () => c,
                PopBubble: () => O,
                PopBubbles: () => F,
                ReplayButton: () => $,
                SCRATCH_CLEAR_THRESHOLD: () => p,
                ScratchCard: () => x,
                SpinWheel: () => L,
                StatBar: () => Y,
                TapWiggle: () => P,
                TradingCard: () => D,
                WheelSlice: () => T,
                clearedFraction: () => m,
                usePrefersReducedMotion: () => N,
                useReplaySignal: () => k
            });
            var l = n(73365),
                o = n(1521),
                r = n(92241),
                i = n(66111),
                a = n(34768),
                s = n(82161);

            function u({
                front: e,
                openLabel: t,
                children: n,
                className: r
            }) {
                let i = (0, a.useMode)(),
                    c = (0, a.useStory)(),
                    d = (0, s.useFolioSound)(),
                    f = d.playEffect,
                    [h, p] = (0, o.useState)(!1),
                    [m, x] = (0, o.useState)(!1),
                    v = (0, o.useRef)(null);
                (0, o.useEffect)(() => () => {
                    v.current && clearTimeout(v.current)
                }, []);
                let b = "edit" === i,
                    j = (0, o.useCallback)(() => {
                        b || h || (p(!0), d.unlock(), f("open"), v.current = setTimeout(() => {
                            c.next() || x(!0), p(!1)
                        }, 420))
                    }, [b, h, f, d, c]),
                    M = b || m;
                return (0, l.jsxs)("div", {
                    className: `folio-envelope${r?` ${r}`:""}`,
                    children: [!m || b ? (0, l.jsxs)("div", {
                        className: `folio-envelope-body${h?" is-opening":""}`,
                        children: [(0, l.jsx)("div", {
                            "aria-hidden": !0,
                            className: "folio-envelope-flap"
                        }), (0, l.jsx)("div", {
                            className: "folio-envelope-front",
                            children: e
                        }), (0, l.jsx)("button", {
                            type: "button",
                            className: "folio-envelope-open",
                            onClick: j,
                            tabIndex: b ? -1 : void 0,
                            children: t
                        })]
                    }) : null, M && n ? (0, l.jsx)("div", {
                        className: "folio-envelope-contents",
                        children: n
                    }) : null]
                })
            }

            function c({
                children: e,
                label: t,
                className: n
            }) {
                let r = (0, a.useMode)(),
                    i = (0, s.useSoundEffect)(),
                    [u, d] = (0, o.useState)(!1),
                    f = u || "edit" === r;
                return (0, l.jsxs)("div", {
                    className: `folio-photo-reveal${f?" is-revealed":""}${n?` ${n}`:""}`,
                    children: [(0, l.jsx)("div", {
                        className: "folio-photo-reveal-media",
                        children: e
                    }), f ? null : (0, l.jsx)("button", {
                        type: "button",
                        className: "folio-photo-reveal-button",
                        onClick: () => {
                            d(!0), i("reveal")
                        },
                        children: t
                    })]
                })
            }
            n(34059);
            let d = () => () => {},
                f = () => !0,
                h = () => !1,
                p = .5;

            function m(e, t = 16) {
                let n = 0,
                    l = 0;
                for (let o = 3; o < e.length; o += 4 * t) n += 1, e[o] < 32 && (l += 1);
                return 0 === n ? 0 : l / n
            }

            function x({
                children: e,
                coverLabel: t,
                revealLabel: n = "Reveal",
                className: r
            }) {
                let i = (0, a.useMode)(),
                    u = (0, s.useSoundEffect)(),
                    c = (0, o.useRef)(null),
                    v = (0, o.useRef)(null),
                    b = (0, o.useSyncExternalStore)(d, f, h),
                    [j, M] = (0, o.useState)(!1),
                    g = (0, o.useRef)(!1),
                    y = (0, o.useRef)(0),
                    C = j || "edit" === i,
                    N = (0, o.useCallback)(() => {
                        M(e => (e || u("reveal"), !0))
                    }, [u]);
                (0, o.useEffect)(() => {
                    if (!b || C) return;
                    let e = c.current,
                        n = v.current;
                    if (!e || !n) return;
                    let l = e.ownerDocument.defaultView;
                    if (!l) return;
                    let o = () => {
                        let o = e.getBoundingClientRect(),
                            r = l.devicePixelRatio || 1;
                        n.width = Math.max(1, Math.round(o.width * r)), n.height = Math.max(1, Math.round(o.height * r));
                        let i = n.getContext("2d");
                        if (!i) return;
                        let a = l.getComputedStyle(e),
                            s = a.getPropertyValue("--f-accent").trim() || "#5b3fe8",
                            u = a.getPropertyValue("--f-onAccent").trim() || "#ffffff";
                        i.setTransform(r, 0, 0, r, 0, 0), i.globalCompositeOperation = "source-over", i.fillStyle = s, i.fillRect(0, 0, o.width, o.height), i.fillStyle = u, i.font = `600 ${Math.max(14,Math.min(22,o.width/14))}px ${a.fontFamily}`, i.textAlign = "center", i.textBaseline = "middle", i.fillText(t, o.width / 2, o.height / 2)
                    };
                    o();
                    let r = "u" < typeof ResizeObserver ? null : new ResizeObserver(o);
                    return r ? .observe(e), () => r ? .disconnect()
                }, [b, C, t]);
                let w = (e, t) => {
                    let n = v.current,
                        l = c.current;
                    if (!n || !l) return;
                    let o = n.getContext("2d");
                    if (!o) return;
                    let r = n.getBoundingClientRect();
                    o.globalCompositeOperation = "destination-out", o.beginPath(), o.arc(e - r.left, t - r.top, Math.max(18, r.width / 12), 0, 2 * Math.PI), o.fill();
                    let i = Date.now();
                    i - y.current > 140 && (y.current = i, u("scratch"))
                };
                return (0, l.jsxs)("div", {
                    ref: c,
                    className: `folio-scratch${C?" is-revealed":""}${r?` ${r}`:""}`,
                    children: [(0, l.jsx)("div", {
                        className: "folio-scratch-secret",
                        children: e
                    }), C ? null : b ? (0, l.jsx)("canvas", {
                        ref: v,
                        className: "folio-scratch-canvas",
                        "aria-hidden": !0,
                        onPointerDown: e => {
                            g.current = !0, e.currentTarget.setPointerCapture ? .(e.pointerId), w(e.clientX, e.clientY)
                        },
                        onPointerMove: e => {
                            g.current && w(e.clientX, e.clientY)
                        },
                        onPointerUp: () => {
                            g.current = !1;
                            let e = v.current,
                                t = e ? .getContext("2d");
                            if (e && t) try {
                                let n = t.getImageData(0, 0, e.width, e.height).data;
                                m(n) >= p && N()
                            } catch {
                                N()
                            }
                        },
                        onPointerCancel: () => {
                            g.current = !1
                        }
                    }) : (0, l.jsx)("div", {
                        "aria-hidden": !0,
                        className: "folio-scratch-cover",
                        children: t
                    }), C ? null : (0, l.jsx)("button", {
                        type: "button",
                        className: "folio-scratch-skip",
                        onClick: N,
                        children: n
                    })]
                })
            }

            function v(e) {
                let t = setInterval(e, 1e3);
                return () => clearInterval(t)
            }
            let b = () => 1e3 * Math.floor(Date.now() / 1e3),
                j = () => null;

            function M({
                target: e,
                labels: t = ["Days", "Hours", "Minutes", "Seconds"],
                after: n,
                className: i
            }) {
                let s = (0, a.useMode)(),
                    u = (0, o.useSyncExternalStore)(v, b, j),
                    c = (0, r.yv)(e),
                    d = c && null !== u ? (0, r.Cp)(c.getTime(), u) : null,
                    f = d ? .done ? ? !1,
                    h = d ? [String(d.days), (0, r.wl)(d.hours), (0, r.wl)(d.minutes), (0, r.wl)(d.seconds)] : ["--", "--", "--", "--"];
                return (0, l.jsxs)("div", {
                    className: `folio-countdown${i?` ${i}`:""}`,
                    children: [f ? null : (0, l.jsx)("div", {
                        className: "folio-countdown-grid",
                        role: "timer",
                        "aria-live": "off",
                        children: h.map((e, n) => (0, l.jsxs)("div", {
                            className: "folio-countdown-cell",
                            children: [(0, l.jsx)("span", {
                                className: "folio-countdown-value",
                                children: e
                            }), (0, l.jsx)("span", {
                                className: "folio-countdown-label",
                                children: t[n]
                            })]
                        }, t[n]))
                    }), n && (f || "edit" === s) ? (0, l.jsx)("div", {
                        className: `folio-countdown-after${!f?" is-preview":""}`,
                        children: n
                    }) : null]
                })
            }
            let g = e => {
                    if (!window.matchMedia) return () => {};
                    let t = window.matchMedia("(prefers-reduced-motion: reduce)");
                    return t.addEventListener ? .("change", e), () => t.removeEventListener ? .("change", e)
                },
                y = () => !!window.matchMedia ? .("(prefers-reduced-motion: reduce)").matches,
                C = () => !1;

            function N() {
                return (0, o.useSyncExternalStore)(g, y, C)
            }
            let w = "folio:replay";

            function k(e, t) {
                let n = (0, o.useRef)(t);
                (0, o.useEffect)(() => {
                    n.current = t
                }), (0, o.useEffect)(() => {
                    let t = e.current ? .closest("[data-folio-root]");
                    if (!t) return;
                    let l = () => n.current();
                    return t.addEventListener(w, l), () => t.removeEventListener(w, l)
                }, [e])
            }

            function $({
                children: e,
                className: t
            }) {
                let n = (0, a.useMode)(),
                    r = (0, a.useStory)(),
                    i = (0, s.useSoundEffect)(),
                    u = (0, o.useRef)(null);
                return (0, l.jsx)("button", {
                    ref: u,
                    type: "button",
                    className: `folio-pill${t?` ${t}`:""}`,
                    tabIndex: "edit" === n ? -1 : void 0,
                    onClick: () => {
                        if ("edit" === n) return;
                        let e = u.current ? .closest("[data-folio-root]");
                        e ? .dispatchEvent(new CustomEvent(w)), i("next"), r.goTo(0) || e ? .scrollIntoView({
                            block: "start",
                            behavior: "smooth"
                        })
                    },
                    children: e
                })
            }

            function S({
                seed: e = 1,
                count: t = 26,
                top: n
            }) {
                let o = (0, i.wC)(t, e, 5);
                return (0, l.jsx)("span", {
                    "aria-hidden": !0,
                    className: "folio-confetti",
                    style: n ? {
                        "--confetti-top": n
                    } : void 0,
                    children: o.map((e, t) => {
                        let n = e.angle * Math.PI / 180,
                            o = Math.round(Math.sin(n) * e.distance),
                            r = Math.round(-Math.cos(n) * e.distance * .8);
                        return (0, l.jsx)("i", {
                            "data-shape": e.shape,
                            style: {
                                "--x": `${o}px`,
                                "--y": `${r}px`,
                                "--s": `${e.spin}deg`,
                                "--d": `${e.delay}ms`,
                                background: `var(--folio-confetti-${e.colour})`
                            }
                        }, t)
                    })
                })
            }

            function E({
                seed: e = 3,
                count: t = 34,
                effect: n = "confetti"
            }) {
                let r = (0, a.useMode)(),
                    i = (0, a.useStory)(),
                    u = (0, a.useSectionIndex)(),
                    c = (0, s.useSoundEffect)(),
                    d = "edit" !== r && (!i.active || i.index === u);
                return (0, o.useEffect)(() => {
                    d && c(n)
                }, [d, c, n]), d ? (0, l.jsx)(S, {
                    seed: e,
                    count: t,
                    top: "30%"
                }) : null
            }

            function P({
                children: e,
                kind: t = "wiggle",
                effect: n = "pop",
                className: r,
                style: i
            }) {
                let u = (0, a.useMode)(),
                    c = (0, s.useSoundEffect)(),
                    [d, f] = (0, o.useState)(0),
                    h = "edit" === u;
                return (0, l.jsx)("div", {
                    className: `folio-tap${r?` ${r}`:""}`,
                    style: i,
                    "data-tap-kind": t,
                    ...!h && d > 0 ? {
                        "data-tap": d % 2 == 1 ? "a" : "b"
                    } : {},
                    onClick: h ? void 0 : () => {
                        f(e => e + 1), c(n)
                    },
                    children: e
                })
            }
            let R = (0, o.createContext)(null);

            function L({
                count: e,
                colours: t,
                hubLabel: n,
                spinLabel: r,
                againLabel: u,
                resultTitle: c,
                resultNote: d,
                done: f,
                children: h,
                className: p
            }) {
                let m = (0, a.useMode)(),
                    x = (0, s.useFolioSound)(),
                    v = N(),
                    b = "edit" === m,
                    j = (0, o.useRef)(new Map),
                    M = (0, o.useRef)(null),
                    g = (0, o.useRef)(null),
                    y = (0, o.useRef)(null),
                    C = (0, o.useRef)(null),
                    [w, $] = (0, o.useState)(0),
                    [E, P] = (0, o.useState)(0),
                    [T, A] = (0, o.useState)(!1),
                    [F, I] = (0, o.useState)(null),
                    [B, O] = (0, o.useState)(0),
                    [_, W] = (0, o.useState)(""),
                    X = (0, o.useCallback)((e, t) => {
                        j.current.set(e, t), 0 === e && W(t)
                    }, []),
                    D = (0, o.useCallback)(() => {
                        null !== y.current && cancelAnimationFrame(y.current), C.current && clearTimeout(C.current), y.current = null, C.current = null, g.current && (g.current.style.transform = "")
                    }, []);
                (0, o.useEffect)(() => D, [D]), k(M, () => {
                    D(), A(!1), I(null)
                });
                let Y = t => {
                        if (b || T || e < 1) return;
                        x.unlock(t.currentTarget);
                        let n = (0, i.oy)(w, e, Math.random(), Math.random()),
                            l = v ? i.fP : i.Ol,
                            o = (0, i.Xv)(e);
                        I(null), P(l), $(n.rotation), A(!0);
                        let r = (0, i.AK)(...i.qs),
                            a = performance.now(),
                            s = 0,
                            u = w,
                            c = t => {
                                let d, f = Math.min(1, (t - a) / l),
                                    h = w + (n.rotation - w) * r(f);
                                (0, i.vp)(u, h, e) > 0 && t - s > 42 && (s = t, x.playEffect("tick")), u = h, g.current && !v && (g.current.style.transform = `rotate(${((d=h/o-Math.floor(h/o))<.22?-24*(1-d/.22):0).toFixed(1)}deg)`), y.current = f < 1 ? requestAnimationFrame(c) : null
                            };
                        y.current = requestAnimationFrame(c), C.current = setTimeout(() => {
                            D(), A(!1), I({
                                index: n.index,
                                label: j.current.get(n.index) ? ? ""
                            }), O(e => e + 1), x.playEffect("win")
                        }, l + 60)
                    },
                    q = {
                        "--n": String(Math.max(1, e)),
                        background: (0, i.MH)(e, t),
                        transform: `rotate(${w}deg)`,
                        transition: T ? `transform ${E}ms ${i.c$}` : "none"
                    };
                return (0, l.jsxs)("div", {
                    ref: M,
                    className: `folio-wheel${p?` ${p}`:""}`,
                    children: [(0, l.jsxs)("div", {
                        className: "folio-wheel-stage",
                        onClick: b ? void 0 : Y,
                        children: [(0, l.jsx)("div", {
                            className: "folio-wheel-rim"
                        }), Array.from({
                            length: 12
                        }, (e, t) => (0, l.jsx)("span", {
                            className: "folio-wheel-bulb folio-loop-blink",
                            style: {
                                rotate: `${30*t}deg`,
                                "--loop-delay": `${-(t%2*.6)}s`
                            }
                        }, t)), (0, l.jsx)("div", {
                            className: "folio-wheel-disc",
                            style: q,
                            children: (0, l.jsx)(R.Provider, {
                                value: {
                                    register: X
                                },
                                children: h
                            })
                        }), (0, l.jsx)("div", {
                            ref: g,
                            className: "folio-wheel-pointer",
                            children: (0, l.jsxs)("svg", {
                                viewBox: "0 0 40 52",
                                "aria-hidden": !0,
                                children: [(0, l.jsx)("path", {
                                    d: "M20 50 L4 16 A17 17 0 1 1 36 16 Z",
                                    fill: "var(--f-accent, #e8323c)",
                                    stroke: "var(--fp-ink)",
                                    strokeWidth: "4",
                                    strokeLinejoin: "round"
                                }), (0, l.jsx)("circle", {
                                    cx: "20",
                                    cy: "17",
                                    r: "6",
                                    fill: "var(--fp-card)",
                                    stroke: "var(--fp-ink)",
                                    strokeWidth: "3"
                                })]
                            })
                        }), (0, l.jsx)("button", {
                            type: "button",
                            className: "folio-wheel-hub",
                            disabled: b || T,
                            tabIndex: -1,
                            children: n
                        }), F && !b ? (0, l.jsx)("div", {
                            className: "folio-wheel-result",
                            role: "status",
                            "aria-live": "polite",
                            children: (0, l.jsxs)("div", {
                                className: "folio-wheel-result-card",
                                children: [c, (0, l.jsx)("span", {
                                    className: "folio-wheel-prize",
                                    children: F.label
                                }), d]
                            })
                        }) : null, B > 0 && !b ? (0, l.jsx)(S, {
                            seed: B,
                            count: 30
                        }, B) : null]
                    }), b ? (0, l.jsxs)("div", {
                        className: "folio-wheel-preview",
                        children: [c, (0, l.jsx)("span", {
                            className: "folio-wheel-prize",
                            children: _ || "\u2026"
                        }), d]
                    }) : null, (0, l.jsxs)("div", {
                        className: "folio-wheel-controls",
                        children: [(0, l.jsx)("button", {
                            type: "button",
                            className: "folio-pill",
                            onClick: b ? void 0 : Y,
                            disabled: T,
                            tabIndex: b ? -1 : void 0,
                            children: F && !b ? u : r
                        }), f && (b || F && !T) ? f : null]
                    })]
                })
            }

            function T({
                label: e,
                children: t
            }) {
                let n = (0, o.useContext)(R),
                    {
                        index: r
                    } = (0, a.useItemPosition)(),
                    i = n ? .register;
                return (0, o.useEffect)(() => {
                    i ? .(r, e)
                }, [i, r, e]), (0, l.jsx)("span", {
                    className: "folio-wheel-label",
                    children: t
                })
            }
            let A = (0, o.createContext)(null);

            function F({
                total: e,
                counterLabel: t,
                done: n,
                continueLabel: r,
                children: u,
                className: c
            }) {
                let d = (0, a.useMode)(),
                    f = (0, a.useStory)(),
                    h = (0, s.useSoundEffect)(),
                    p = (0, o.useRef)(null),
                    [m, x] = (0, o.useState)([]),
                    [v, b] = (0, o.useState)(0),
                    j = "edit" === d,
                    M = Array.from({
                        length: Math.max(0, e)
                    }, (e, t) => t),
                    g = (0, i.FN)(j ? M : m, e);
                k(p, () => {
                    x([]), b(0)
                });
                let y = (0, o.useCallback)(t => {
                    if (j || m.includes(t)) return;
                    let n = [...m, t];
                    x(n), (0, i.FN)(n, e).done ? (h("win"), b(e => e + 1)) : h("pop")
                }, [j, m, e, h]);
                return (0, l.jsxs)("div", {
                    ref: p,
                    className: `folio-bubbles${c?` ${c}`:""}`,
                    children: [(0, l.jsxs)("p", {
                        className: "folio-bubbles-counter",
                        "aria-live": "polite",
                        children: [(0, l.jsxs)("b", {
                            children: [g.popped, "/", g.total]
                        }), t]
                    }), (0, l.jsx)(A.Provider, {
                        value: {
                            editing: j,
                            popped: m,
                            pop: y
                        },
                        children: u
                    }), g.done ? (0, l.jsxs)("div", {
                        className: "folio-bubbles-done",
                        children: [n, f.active && !j ? (0, l.jsx)("button", {
                            type: "button",
                            className: "folio-pill",
                            onClick: () => f.next(),
                            children: r
                        }) : null]
                    }) : null, v > 0 && !j ? (0, l.jsx)(S, {
                        seed: v + 20,
                        count: 34,
                        top: "70%"
                    }, v) : null]
                })
            }
            let I = ["M50 4 C76 4 96 24 96 50 C96 76 76 96 50 96 C24 96 4 76 4 50 C4 24 24 4 50 4 Z", "M50 92 C22 74 4 56 6 32 C8 14 24 6 36 8 C44 9 48 14 50 20 C52 14 56 9 64 8 C76 6 92 14 94 32 C96 56 78 74 50 92 Z", "M50 8 C58 8 62 16 62 22 C66 16 76 12 82 18 C88 24 84 34 78 38 C84 38 92 42 92 50 C92 58 84 62 78 62 C84 66 88 76 82 82 C76 88 66 84 62 78 C62 84 58 92 50 92 C42 92 38 84 38 78 C34 84 24 88 18 82 C12 76 16 66 22 62 C16 62 8 58 8 50 C8 42 16 38 22 38 C16 34 12 24 18 18 C24 12 34 16 38 22 C38 16 42 8 50 8 Z", "M50 6 L61 36 L94 38 L68 58 L78 92 L50 72 L22 92 L32 58 L6 38 L39 36 Z"],
                B = ["var(--fp-pop4)", "var(--fp-pop2)", "var(--fp-pop1)", "var(--fp-pop3)"];

            function O({
                children: e,
                face: t
            }) {
                let n = (0, o.useContext)(A),
                    {
                        index: r
                    } = (0, a.useItemPosition)(),
                    s = (0, i.jb)(r),
                    u = I[r % I.length],
                    c = B[r % B.length],
                    d = !n || n.editing || n.popped.includes(r),
                    f = !!n && !n.editing && n.popped.at(-1) === r,
                    h = {
                        "--tilt": `${s.tilt/2}deg`
                    };
                return (0, l.jsx)("div", {
                    className: "folio-bubble-cell",
                    children: d ? (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("div", {
                            className: `folio-bubble-message${f?" is-fresh":""}`,
                            style: h,
                            children: e
                        }), f ? (0, l.jsx)("span", {
                            "aria-hidden": !0,
                            className: "folio-bubble-ring"
                        }) : null, f ? (0, l.jsx)(S, {
                            seed: r + 40,
                            count: 10,
                            top: "50%"
                        }, r) : null]
                    }) : (0, l.jsxs)("button", {
                        type: "button",
                        className: "folio-bubble folio-loop-float",
                        "aria-label": "Pop this bubble",
                        onClick: () => n ? .pop(r),
                        style: {
                            "--tilt": `${s.tilt}deg`,
                            "--loop-dur": `${s.duration}s`,
                            "--loop-delay": `${s.delay}s`,
                            "--loop-drift": `${s.drift}px`
                        },
                        children: [(0, l.jsxs)("svg", {
                            viewBox: "0 0 100 100",
                            "aria-hidden": !0,
                            children: [(0, l.jsx)("path", {
                                d: u,
                                fill: c,
                                stroke: "var(--fp-ink)",
                                strokeWidth: "4",
                                strokeLinejoin: "round"
                            }), (0, l.jsx)("path", {
                                d: "M30 26 C36 20 44 18 50 19",
                                fill: "none",
                                stroke: "var(--fp-card)",
                                strokeWidth: "5",
                                strokeLinecap: "round",
                                opacity: "0.85"
                            }), (0, l.jsx)("circle", {
                                cx: "27",
                                cy: "36",
                                r: "3.5",
                                fill: "var(--fp-card)",
                                opacity: "0.85"
                            })]
                        }), t ? (0, l.jsx)("span", {
                            className: "folio-bubble-face",
                            children: t
                        }) : null]
                    })
                })
            }
            let _ = (0, o.createContext)({
                booted: !1
            });

            function W({
                title: e,
                status: t,
                hint: n,
                headline: r,
                continueLabel: u,
                popups: c,
                perTap: d = 34,
                className: f
            }) {
                let h = (0, a.useMode)(),
                    p = (0, a.useStory)(),
                    m = (0, s.useFolioSound)(),
                    x = (0, o.useRef)(null),
                    v = (0, o.useRef)(null),
                    [b, j] = (0, o.useState)(0),
                    [M, g] = (0, o.useState)(0),
                    [y, C] = (0, o.useState)(!1),
                    N = "edit" === h,
                    w = N || y,
                    $ = N ? 100 : b;
                (0, o.useEffect)(() => () => {
                    v.current && clearTimeout(v.current)
                }, []), k(x, () => {
                    v.current && clearTimeout(v.current), j(0), g(0), C(!1)
                });
                let E = Math.round($ / 10);
                return (0, l.jsx)(_.Provider, {
                    value: {
                        booted: w
                    },
                    children: (0, l.jsxs)("div", {
                        ref: x,
                        className: `folio-boot${f?` ${f}`:""}`,
                        ...w ? {
                            "data-booted": ""
                        } : {},
                        children: [(0, l.jsxs)("div", {
                            className: "folio-boot-window",
                            children: [(0, l.jsxs)("div", {
                                className: "folio-boot-titlebar",
                                children: [(0, l.jsx)("span", {
                                    children: e
                                }), (0, l.jsxs)("span", {
                                    "aria-hidden": !0,
                                    className: "folio-boot-controls",
                                    children: [(0, l.jsx)("i", {}), (0, l.jsx)("i", {}), (0, l.jsx)("i", {})]
                                })]
                            }), (0, l.jsxs)("div", {
                                className: "folio-boot-body",
                                children: [(0, l.jsx)("div", {
                                    className: "folio-boot-status",
                                    children: t
                                }), (0, l.jsx)("div", {
                                    className: "folio-boot-bar",
                                    role: "progressbar",
                                    "aria-valuemin": 0,
                                    "aria-valuemax": 100,
                                    "aria-valuenow": $,
                                    children: Array.from({
                                        length: 10
                                    }, (e, t) => (0, l.jsx)("i", {
                                        className: t < E ? "is-on" : void 0
                                    }, t))
                                }), (0, l.jsxs)("span", {
                                    className: "folio-boot-percent",
                                    children: [$, "%"]
                                }), (0, l.jsxs)("button", {
                                    type: "button",
                                    className: "folio-boot-heart folio-loop-pulse",
                                    onClick: e => {
                                        if (N || y) return;
                                        m.unlock(e.currentTarget);
                                        let t = (0, i.wA)(b, d);
                                        j(t), g(e => e + 1), t >= 100 ? (C(!0), m.playEffect("boot"), v.current = setTimeout(() => {
                                            p.next()
                                        }, 1500)) : m.playEffect("tap")
                                    },
                                    disabled: w,
                                    tabIndex: N ? -1 : void 0,
                                    "aria-label": "Tap to load",
                                    children: [(0, l.jsxs)("svg", {
                                        viewBox: "0 0 120 110",
                                        "aria-hidden": !0,
                                        children: [(0, l.jsx)("path", {
                                            d: "M60 104 C26 82 4 62 6 34 C8 14 26 4 40 6 C50 7 56 13 60 21 C64 13 70 7 80 6 C94 4 112 14 114 34 C116 62 94 82 60 104 Z",
                                            fill: "var(--fp-pop2)",
                                            stroke: "var(--fp-ink)",
                                            strokeWidth: "6",
                                            strokeLinejoin: "round"
                                        }), (0, l.jsx)("path", {
                                            d: "M26 30 C30 22 38 18 46 19",
                                            fill: "none",
                                            stroke: "var(--fp-card)",
                                            strokeWidth: "6",
                                            strokeLinecap: "round"
                                        })]
                                    }), M > 0 && !y ? (0, l.jsxs)("span", {
                                        className: "folio-boot-plus",
                                        children: ["+", Math.min(d, 100), "%"]
                                    }, M) : null]
                                }), (0, l.jsx)("div", {
                                    className: "folio-boot-hint",
                                    children: n
                                })]
                            })]
                        }), c, (0, l.jsx)("div", {
                            className: "folio-boot-headline",
                            children: r
                        }), y && !N ? (0, l.jsx)(S, {
                            seed: 11,
                            count: 36,
                            top: "40%"
                        }) : null, y && !N && p.active ? (0, l.jsx)("button", {
                            type: "button",
                            className: "folio-pill",
                            onClick: () => p.next(),
                            children: u
                        }) : null]
                    })
                })
            }

            function X({
                title: e,
                children: t
            }) {
                return (0, l.jsxs)("div", {
                    className: "folio-boot-popup",
                    children: [(0, l.jsxs)("div", {
                        className: "folio-boot-titlebar",
                        children: [(0, l.jsx)("span", {
                            children: e ? ? "!"
                        }), (0, l.jsxs)("span", {
                            "aria-hidden": !0,
                            className: "folio-boot-controls",
                            children: [(0, l.jsx)("i", {}), (0, l.jsx)("i", {})]
                        })]
                    }), (0, l.jsx)("div", {
                        className: "folio-boot-popup-body",
                        children: t
                    })]
                })
            }

            function D({
                children: e,
                className: t
            }) {
                let n = (0, a.useMode)(),
                    r = (0, s.useFolioSound)(),
                    u = (0, o.useRef)(null),
                    c = (0, o.useRef)(null),
                    d = (0, o.useRef)(null),
                    f = (0, o.useRef)(!1),
                    h = "edit" === n;
                (0, o.useEffect)(() => () => {
                    null !== c.current && cancelAnimationFrame(c.current)
                }, []);
                let p = () => {
                        c.current = null;
                        let e = u.current,
                            t = d.current;
                        if (!e || !t) return;
                        let n = (0, i.eM)(t.x, t.y);
                        e.style.setProperty("--rx", `${n.rotateX}deg`), e.style.setProperty("--ry", `${n.rotateY}deg`), e.style.setProperty("--fx", `${Math.round((t.x-.5)*40)}%`), e.style.setProperty("--fy", `${Math.round((t.y-.5)*40)}%`)
                    },
                    m = () => {
                        let e = u.current;
                        if (e)
                            for (let t of (null !== c.current && cancelAnimationFrame(c.current), c.current = null, e.classList.remove("is-tracking"), ["--rx", "--ry", "--fx", "--fy"])) e.style.removeProperty(t)
                    };
                return (0, l.jsx)("div", {
                    ref: u,
                    className: `folio-tcard${t?` ${t}`:""}`,
                    onPointerMove: h ? void 0 : e => {
                        let t = u.current;
                        if (h || !t) return;
                        let n = t.getBoundingClientRect();
                        0 !== n.width && 0 !== n.height && (d.current = {
                            x: (e.clientX - n.left) / n.width,
                            y: (e.clientY - n.top) / n.height
                        }, t.classList.add("is-tracking"), null === c.current && (c.current = requestAnimationFrame(p)))
                    },
                    onPointerLeave: h ? void 0 : m,
                    onPointerCancel: h ? void 0 : m,
                    onPointerUp: h ? void 0 : e => "mouse" === e.pointerType ? void 0 : m(),
                    onClick: h ? void 0 : e => {
                        r.unlock(e.currentTarget), f.current || (f.current = !0, r.playEffect("reveal"))
                    },
                    children: (0, l.jsxs)("div", {
                        className: "folio-tcard-inner",
                        children: [e, (0, l.jsx)("span", {
                            "aria-hidden": !0,
                            className: "folio-tcard-foil"
                        }), (0, l.jsx)("span", {
                            "aria-hidden": !0,
                            className: "folio-tcard-sheen"
                        })]
                    })
                })
            }

            function Y({
                value: e,
                className: t
            }) {
                return (0, l.jsx)("span", {
                    "aria-hidden": !0,
                    className: `folio-stat-bar${t?` ${t}`:""}`,
                    children: (0, l.jsx)("i", {
                        style: {
                            transform: `scaleX(${(0,i.g1)(e)/100})`
                        }
                    })
                })
            }
            let q = (0, o.createContext)({
                editing: !1,
                current: -1
            });

            function z({
                count: e,
                base: t = 100,
                max: n = 120,
                caption: r,
                overflowReadout: u,
                overflowLabel: c,
                children: d,
                className: f
            }) {
                let h = (0, a.useMode)(),
                    p = (0, s.useFolioSound)(),
                    m = (0, o.useRef)(null),
                    [x, v] = (0, o.useState)(t),
                    [b, j] = (0, o.useState)(t),
                    [M, g] = (0, o.useState)(-1),
                    [y, C] = (0, o.useState)(0),
                    [N, w] = (0, o.useState)(0),
                    $ = "edit" === h,
                    E = (0, i._9)(x, n),
                    P = "overflow" === E.kind;
                k(m, () => {
                    v(t), j(t), g(-1), C(0), w(0)
                });
                let R = () => {
                        x >= b ? j((0, i.YJ)(x, t)) : (v(b), g(e => e + 1), C(e => e + 1), p.playEffect("nope"))
                    },
                    L = M >= 0 ? (0, i.qr)(M, e) : -1;
                return (0, l.jsxs)("div", {
                    ref: m,
                    className: `folio-slider${P&&!$?" is-over":""}${f?` ${f}`:""}`,
                    children: [(0, l.jsx)("span", {
                        className: `folio-slider-readout${y>0?" is-nope":""}${P&&!$?" is-over":""}`,
                        "aria-hidden": !0,
                        children: P && !$ ? u : `${"percent"===E.kind?E.value:n}%`
                    }, y), $ || P ? (0, l.jsx)("div", {
                        className: "folio-meter-overflow",
                        children: c
                    }) : null, (0, l.jsxs)("label", {
                        className: "relative flex w-full flex-col items-center gap-2",
                        children: [(0, l.jsx)("input", {
                            type: "range",
                            min: 0,
                            max: n,
                            step: 1,
                            value: x,
                            disabled: $,
                            "aria-valuetext": P ? u : `${Math.round(x)}%`,
                            onPointerDown: e => p.unlock(e.currentTarget),
                            onChange: e => (e => {
                                if (e >= b) {
                                    e >= n && x < n ? (p.playEffect("win"), w(e => e + 1)) : Math.floor(e / 5) > Math.floor(x / 5) && e > t && p.playEffect("tick"), v(e);
                                    return
                                }
                                v((0, i.cR)(e, b))
                            })(Number(e.currentTarget.value)),
                            onPointerUp: R,
                            onPointerCancel: R,
                            onKeyUp: R,
                            onBlur: R,
                            style: {
                                "--meter-base": `${t/n*100}%`
                            }
                        }), r, N > 0 && !$ ? (0, l.jsx)(S, {
                            seed: N + 60,
                            count: 30,
                            top: "0%"
                        }, N) : null]
                    }), (0, l.jsx)(q.Provider, {
                        value: {
                            editing: $,
                            current: L
                        },
                        children: (0, l.jsx)("div", {
                            "aria-live": "polite",
                            className: "w-full",
                            children: d
                        })
                    })]
                })
            }

            function H({
                children: e
            }) {
                let t = (0, o.useContext)(q),
                    {
                        index: n
                    } = (0, a.useItemPosition)();
                return t.editing || n === t.current ? (0, l.jsx)("div", {
                    className: "folio-comeback",
                    children: e
                }, t.editing ? void 0 : t.current) : null
            }
        }
    }
]);