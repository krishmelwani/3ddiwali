(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [79081], {
        14139: (e, r, s) => {
            "use strict";
            s.d(r, {
                $A: () => B,
                Aq: () => v,
                ET: () => p,
                Fq: () => h,
                IA: () => y,
                II: () => z,
                Ig: () => b,
                LJ: () => g,
                Li: () => W,
                Nu: () => w,
                Od: () => L,
                RE: () => A,
                UP: () => f,
                WS: () => M,
                Yp: () => m,
                _t: () => Q,
                hm: () => R,
                i9: () => C,
                it: () => S,
                jJ: () => u,
                mR: () => j,
                tz: () => k,
                y_: () => N,
                yy: () => $
            });
            var a = s(73365);
            s(49945);
            let l = "var(--f-ink)",
                i = {
                    stroke: l,
                    strokeWidth: 4,
                    strokeLinejoin: "round",
                    strokeLinecap: "round"
                },
                t = e => Number(e.toFixed(2));

            function c(e, r, s, a, l = 0) {
                return Array.from({
                    length: a
                }, (i, c) => {
                    let n = l + c / a * Math.PI * 2;
                    return {
                        x: t(e + Math.cos(n) * s),
                        y: t(r + Math.sin(n) * s)
                    }
                })
            }

            function n({
                cx: e,
                cy: r,
                r: s
            }) {
                return (0, a.jsxs)("g", {
                    className: "prbm-r-reel",
                    children: [(0, a.jsx)("circle", {
                        cx: e,
                        cy: r,
                        r: s,
                        fill: "var(--f-gold)",
                        ...i
                    }), (0, a.jsx)("circle", {
                        cx: e,
                        cy: r,
                        r: t(.78 * s),
                        fill: "none",
                        stroke: l,
                        strokeWidth: "2",
                        opacity: "0.35"
                    }), c(e, r, .5 * s, 5, -Math.PI / 2).map(e => (0, a.jsx)("circle", {
                        cx: e.x,
                        cy: e.y,
                        r: t(.18 * s),
                        fill: "var(--prbm-shadow)",
                        stroke: l,
                        strokeWidth: "2.5"
                    }, `${e.x}-${e.y}`)), (0, a.jsx)("circle", {
                        cx: e,
                        cy: r,
                        r: t(.14 * s),
                        fill: l
                    })]
                })
            }

            function d({
                x: e,
                y: r,
                s = 1
            }) {
                return (0, a.jsx)("path", {
                    transform: `translate(${e} ${r}) scale(${s})`,
                    d: "M0 7 C-8 1 -9 -6 -4 -7 C-1.5 -7.6 0 -5 0 -3.6 C0 -5 1.5 -7.6 4 -7 C9 -6 8 1 0 7 Z",
                    fill: "var(--f-carpet)",
                    stroke: l,
                    strokeWidth: "2",
                    strokeLinejoin: "round"
                })
            }

            function o({
                mood: e
            }) {
                if ("love" === e) return (0, a.jsxs)("g", {
                    children: [(0, a.jsx)(d, {
                        x: 80,
                        y: 116,
                        s: 1.25
                    }), (0, a.jsx)(d, {
                        x: 116,
                        y: 116,
                        s: 1.25
                    }), (0, a.jsx)("path", {
                        d: "M84 131 Q98 152 112 131 Z",
                        fill: l,
                        ...i,
                        strokeWidth: 3
                    }), (0, a.jsx)("path", {
                        d: "M92 140 Q98 146 104 140",
                        fill: "var(--f-carpet)"
                    })]
                });
                if ("proud" === e) return (0, a.jsxs)("g", {
                    children: [(0, a.jsx)("path", {
                        d: "M72 119 Q80 110 88 119 M108 119 Q116 110 124 119",
                        fill: "none",
                        ...i,
                        strokeWidth: 4.5
                    }), (0, a.jsx)("path", {
                        d: "M86 133 Q98 146 110 133",
                        fill: "none",
                        ...i,
                        strokeWidth: 4
                    }), (0, a.jsx)("path", {
                        d: "M94 138 h8",
                        stroke: "var(--f-screen)",
                        strokeWidth: "3",
                        strokeLinecap: "round"
                    })]
                });
                let r = "wow" === e;
                return (0, a.jsxs)("g", {
                    children: [(0, a.jsxs)("g", {
                        className: "prbm-r-eyes",
                        children: [(0, a.jsx)("ellipse", {
                            cx: "80",
                            cy: "116",
                            rx: r ? 7 : 5.5,
                            ry: r ? 9 : 7.5,
                            fill: l
                        }), (0, a.jsx)("ellipse", {
                            cx: "116",
                            cy: "116",
                            rx: r ? 7 : 5.5,
                            ry: r ? 9 : 7.5,
                            fill: l
                        }), (0, a.jsx)("circle", {
                            cx: "82",
                            cy: "112.5",
                            r: "2.2",
                            fill: "var(--f-screen)"
                        }), (0, a.jsx)("circle", {
                            cx: "118",
                            cy: "112.5",
                            r: "2.2",
                            fill: "var(--f-screen)"
                        })]
                    }), r ? (0, a.jsxs)(a.Fragment, {
                        children: [(0, a.jsx)("path", {
                            d: "M72 101 Q80 96 88 101 M108 101 Q116 96 124 101",
                            fill: "none",
                            ...i,
                            strokeWidth: 3
                        }), (0, a.jsx)("ellipse", {
                            cx: "98",
                            cy: "139",
                            rx: "5.5",
                            ry: "7",
                            fill: l
                        })]
                    }) : (0, a.jsx)("path", {
                        d: "M87 133 Q98 145 109 133",
                        fill: "none",
                        ...i,
                        strokeWidth: 4
                    })]
                })
            }

            function p({
                mood: e = "happy",
                pose: r = "idle",
                rolling: s = !1,
                className: t = ""
            }) {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 200 212",
                    "aria-hidden": !0,
                    className: `prbm-reelu ${t}`,
                    "data-pose": r,
                    ...s ? {
                        "data-rolling": ""
                    } : {},
                    children: (0, a.jsxs)("g", {
                        className: "prbm-r-rig",
                        children: [(0, a.jsx)("path", {
                            d: "M98 150 L64 204 M98 150 L98 208 M98 150 L132 204",
                            fill: "none",
                            ...i,
                            strokeWidth: 6
                        }), (0, a.jsx)("path", {
                            d: "M58 205 h12 M92 208 h12 M126 205 h12",
                            ...i,
                            strokeWidth: 6,
                            stroke: "var(--f-gold)"
                        }), (0, a.jsxs)("g", {
                            className: "prbm-r-body",
                            children: [(0, a.jsx)("path", {
                                d: "M66 84 C58 100 74 104 84 94 M120 80 C134 96 148 92 156 104",
                                fill: "none",
                                stroke: l,
                                strokeWidth: "5",
                                strokeLinecap: "round"
                            }), (0, a.jsx)(n, {
                                cx: 70,
                                cy: 58,
                                r: 26
                            }), (0, a.jsx)(n, {
                                cx: 126,
                                cy: 50,
                                r: 30
                            }), (0, a.jsx)("rect", {
                                x: "38",
                                y: "80",
                                width: "118",
                                height: "78",
                                rx: "22",
                                fill: "var(--f-camera)",
                                ...i,
                                strokeWidth: 5
                            }), (0, a.jsx)("path", {
                                d: "M52 90 Q96 82 140 90",
                                fill: "none",
                                stroke: "var(--f-screen)",
                                strokeWidth: "4",
                                strokeLinecap: "round",
                                opacity: "0.45"
                            }), (0, a.jsx)("path", {
                                d: "M156 100 L186 86 L186 154 L156 140 Z",
                                fill: "var(--prbm-shadow)",
                                ...i
                            }), (0, a.jsx)("ellipse", {
                                cx: "186",
                                cy: "120",
                                rx: "6",
                                ry: "34",
                                fill: "var(--f-screen)",
                                ...i,
                                strokeWidth: 3.5
                            }), (0, a.jsx)("path", {
                                d: "M184 98 v12",
                                stroke: "var(--f-camera)",
                                strokeWidth: "3",
                                strokeLinecap: "round"
                            }), (0, a.jsx)("circle", {
                                className: "prbm-r-tally",
                                cx: "54",
                                cy: "98",
                                r: "5",
                                fill: "var(--f-carpet)",
                                stroke: l,
                                strokeWidth: "2.5"
                            }), (0, a.jsx)("ellipse", {
                                cx: "66",
                                cy: "134",
                                rx: "8",
                                ry: "5",
                                fill: "var(--f-carpet)",
                                opacity: "0.45"
                            }), (0, a.jsx)("ellipse", {
                                cx: "130",
                                cy: "134",
                                rx: "8",
                                ry: "5",
                                fill: "var(--f-carpet)",
                                opacity: "0.45"
                            }), (0, a.jsx)(o, {
                                mood: e
                            }), (0, a.jsxs)("g", {
                                className: "prbm-r-arm-l",
                                children: [(0, a.jsx)("path", {
                                    d: "M40 116 C28 124 24 138 26 150",
                                    fill: "none",
                                    ...i,
                                    strokeWidth: 6
                                }), (0, a.jsx)("circle", {
                                    cx: "26",
                                    cy: "152",
                                    r: "7",
                                    fill: "var(--f-camera)",
                                    ...i,
                                    strokeWidth: 3.5
                                })]
                            }), (0, a.jsxs)("g", {
                                className: "prbm-r-arm-r",
                                children: [(0, a.jsx)("path", {
                                    d: "M150 150 C158 156 162 162 164 170",
                                    fill: "none",
                                    ...i,
                                    strokeWidth: 6
                                }), (0, a.jsx)("circle", {
                                    cx: "165",
                                    cy: "172",
                                    r: "7",
                                    fill: "var(--f-camera)",
                                    ...i,
                                    strokeWidth: 3.5
                                })]
                            })]
                        })]
                    })
                })
            }
            let x = (() => {
                let e = [];
                for (let r = 0; r <= 4.6 * Math.PI; r += .18) {
                    let s = 3 + 3.5 * r;
                    e.push(`${t(60+Math.cos(r)*s)} ${t(60+Math.sin(r)*s)}`)
                }
                return `M${e.join(" L")}`
            })();

            function h() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 120",
                    "aria-hidden": !0,
                    className: "prbm-logo-art",
                    children: [(0, a.jsx)("circle", {
                        cx: "60",
                        cy: "60",
                        r: "56",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "3",
                        pathLength: 1,
                        className: "prbm-draw prbm-draw-ring"
                    }), (0, a.jsx)("path", {
                        d: x,
                        fill: "none",
                        stroke: "var(--prbm-jalebi)",
                        strokeWidth: "9",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        pathLength: 1,
                        className: "prbm-draw prbm-draw-spiral"
                    }), (0, a.jsx)("path", {
                        d: x,
                        fill: "none",
                        stroke: "var(--f-screen)",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        opacity: "0.55",
                        pathLength: 1,
                        className: "prbm-draw prbm-draw-spiral"
                    })]
                })
            }

            function m() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 160 160",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("circle", {
                        cx: "80",
                        cy: "80",
                        r: "74",
                        fill: "var(--prbm-shadow)",
                        stroke: "var(--f-screen)",
                        strokeWidth: "3"
                    }), (0, a.jsx)("circle", {
                        cx: "80",
                        cy: "80",
                        r: "58",
                        fill: "none",
                        stroke: "var(--f-screen)",
                        strokeWidth: "2",
                        opacity: "0.7"
                    }), (0, a.jsx)("path", {
                        d: "M80 2 V158 M2 80 H158",
                        stroke: "var(--f-screen)",
                        strokeWidth: "1.5",
                        opacity: "0.5"
                    }), (0, a.jsx)("g", {
                        className: "prbm-leader-sweep",
                        children: (0, a.jsx)("path", {
                            d: "M80 80 L80 6 A74 74 0 0 1 132 28 Z",
                            fill: "var(--f-screen)",
                            opacity: "0.22"
                        })
                    }), ["3", "2", "1"].map((e, r) => (0, a.jsx)("text", {
                        x: "80",
                        y: "104",
                        textAnchor: "middle",
                        className: `prbm-leader-n prbm-leader-n${r}`,
                        fill: "var(--f-screen)",
                        style: {
                            fontFamily: "var(--f-display)",
                            fontSize: 72
                        },
                        children: e
                    }, e))]
                })
            }

            function f() {
                return (0, a.jsxs)("svg", {
                    "aria-hidden": !0,
                    className: "prbm-grain",
                    preserveAspectRatio: "none",
                    children: [(0, a.jsxs)("filter", {
                        id: "prbm-grain-f",
                        children: [(0, a.jsx)("feTurbulence", {
                            type: "fractalNoise",
                            baseFrequency: "0.9",
                            numOctaves: "2",
                            stitchTiles: "stitch"
                        }), (0, a.jsx)("feColorMatrix", {
                            values: "0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.55 0"
                        })]
                    }), (0, a.jsx)("rect", {
                        width: "100%",
                        height: "100%",
                        filter: "url(#prbm-grain-f)"
                    })]
                })
            }

            function j() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "prbm-beam",
                    children: [(0, a.jsx)("defs", {
                        children: (0, a.jsxs)("linearGradient", {
                            id: "prbm-beam-g",
                            x1: "0",
                            y1: "0",
                            x2: "0",
                            y2: "1",
                            children: [(0, a.jsx)("stop", {
                                offset: "0",
                                stopColor: "var(--f-screen)",
                                stopOpacity: "0.55"
                            }), (0, a.jsx)("stop", {
                                offset: "1",
                                stopColor: "var(--f-screen)",
                                stopOpacity: "0"
                            })]
                        })
                    }), (0, a.jsx)("path", {
                        d: "M47 0 H53 L92 100 H8 Z",
                        fill: "url(#prbm-beam-g)"
                    }), (0, a.jsx)("g", {
                        className: "prbm-motes",
                        children: [{
                            x: 46,
                            y: 30,
                            r: 1.6
                        }, {
                            x: 54,
                            y: 52,
                            r: 1.1
                        }, {
                            x: 42,
                            y: 68,
                            r: 1.4
                        }, {
                            x: 60,
                            y: 40,
                            r: 1
                        }, {
                            x: 50,
                            y: 84,
                            r: 1.8
                        }, {
                            x: 38,
                            y: 48,
                            r: 1.2
                        }, {
                            x: 64,
                            y: 72,
                            r: 1.3
                        }].map(e => (0, a.jsx)("ellipse", {
                            cx: e.x,
                            cy: e.y,
                            rx: .6 * e.r,
                            ry: .32 * e.r,
                            fill: "var(--f-screen)",
                            opacity: "0.65"
                        }, `${e.x}-${e.y}`))
                    })]
                })
            }

            function u() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 400",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        width: "100",
                        height: "400",
                        fill: "var(--prbm-velvet)"
                    }), [10, 28, 46, 64, 82].map(e => (0, a.jsx)("path", {
                        d: `M${e} 0 C${e-4} 140 ${e+4} 260 ${e} 400`,
                        fill: "none",
                        stroke: "var(--prbm-shadow)",
                        strokeWidth: "7",
                        opacity: "0.55"
                    }, e)), [19, 37, 55, 73, 91].map(e => (0, a.jsx)("path", {
                        d: `M${e} 0 C${e-3} 140 ${e+3} 260 ${e} 400`,
                        fill: "none",
                        stroke: "var(--f-screen)",
                        strokeWidth: "2",
                        opacity: "0.12"
                    }, e)), (0, a.jsx)("path", {
                        d: "M0 384 Q6 396 12 384 Q18 396 24 384 Q30 396 36 384 Q42 396 48 384 Q54 396 60 384 Q66 396 72 384 Q78 396 84 384 Q90 396 96 384 L100 384 V400 H0 Z",
                        fill: "var(--f-gold)"
                    })]
                })
            }

            function v() {
                let e = [8, 22, 36, 50, 64, 78, 92].map((e, r) => ({
                    x: e,
                    y: 30 + r % 2 * 6
                }));
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 60",
                    preserveAspectRatio: "xMidYMax slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [
                        [{
                            x: 12,
                            y: 12,
                            r: 5
                        }, {
                            x: 34,
                            y: 6,
                            r: 3.5
                        }, {
                            x: 58,
                            y: 14,
                            r: 6
                        }, {
                            x: 80,
                            y: 8,
                            r: 4
                        }, {
                            x: 94,
                            y: 18,
                            r: 3
                        }].map((e, r) => (0, a.jsx)("circle", {
                            className: `prbm-bokeh prbm-bokeh-${r}`,
                            cx: e.x,
                            cy: e.y,
                            r: e.r,
                            fill: "var(--f-accent)",
                            opacity: "0.35"
                        }, e.x)), e.map(e => (0, a.jsxs)("g", {
                            fill: "var(--prbm-crowd)",
                            children: [(0, a.jsx)("circle", {
                                cx: e.x,
                                cy: e.y,
                                r: "6"
                            }), (0, a.jsx)("path", {
                                d: `M${e.x-10} 60 Q${e.x-10} ${e.y+8} ${e.x} ${e.y+8} Q${e.x+10} ${e.y+8} ${e.x+10} 60 Z`
                            })]
                        }, e.x))
                    ]
                })
            }

            function y() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 30",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("path", {
                        d: "M6 8 Q28 24 50 8 Q72 24 94 8",
                        fill: "none",
                        stroke: "var(--prbm-velvet)",
                        strokeWidth: "3.4",
                        strokeLinecap: "round"
                    }), [6, 50, 94].map(e => (0, a.jsxs)("g", {
                        children: [(0, a.jsx)("rect", {
                            x: e - 1.4,
                            y: "6",
                            width: "2.8",
                            height: "22",
                            fill: "var(--f-gold)"
                        }), (0, a.jsx)("circle", {
                            cx: e,
                            cy: "6",
                            r: "2.6",
                            fill: "var(--f-gold)"
                        }), (0, a.jsx)("ellipse", {
                            cx: e,
                            cy: "28.5",
                            rx: "4.5",
                            ry: "1.5",
                            fill: "var(--f-gold)"
                        })]
                    }, e))]
                })
            }

            function b() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 200 120",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("path", {
                        d: "M78 0 H122 L196 120 H4 Z",
                        fill: "var(--f-carpet)"
                    }), (0, a.jsx)("path", {
                        d: "M78 0 L4 120 M122 0 L196 120",
                        stroke: "var(--f-gold)",
                        strokeWidth: "3"
                    }), [20, 46, 78].map(e => (0, a.jsx)("path", {
                        d: `M${t(78-e/120*74)} ${e} H${t(122+e/120*74)}`,
                        stroke: "var(--prbm-shadow)",
                        strokeWidth: "1.4",
                        opacity: "0.4"
                    }, e))]
                })
            }

            function k() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 80 72",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        x: "30",
                        y: "2",
                        width: "22",
                        height: "16",
                        rx: "3",
                        fill: "var(--f-screen)",
                        ...i,
                        strokeWidth: 3
                    }), (0, a.jsx)("path", {
                        d: "M36 18 v6 M46 18 v6",
                        ...i,
                        strokeWidth: 3
                    }), (0, a.jsx)("rect", {
                        x: "6",
                        y: "24",
                        width: "68",
                        height: "40",
                        rx: "9",
                        fill: "var(--prbm-shadow)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("circle", {
                        cx: "40",
                        cy: "44",
                        r: "14",
                        fill: "var(--f-camera)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("circle", {
                        cx: "40",
                        cy: "44",
                        r: "6",
                        fill: l
                    }), (0, a.jsx)("circle", {
                        cx: "44",
                        cy: "40",
                        r: "2.4",
                        fill: "var(--f-screen)"
                    }), (0, a.jsx)("rect", {
                        x: "12",
                        y: "30",
                        width: "10",
                        height: "6",
                        rx: "2",
                        fill: "var(--f-accent)"
                    })]
                })
            }

            function g() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("path", {
                        d: "M50 0 L58 38 L100 50 L58 62 L50 100 L42 62 L0 50 L42 38 Z",
                        fill: "var(--f-screen)"
                    }), (0, a.jsx)("circle", {
                        cx: "50",
                        cy: "50",
                        r: "18",
                        fill: "var(--f-screen)"
                    })]
                })
            }

            function L() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 70",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        x: "2",
                        y: "2",
                        width: "116",
                        height: "66",
                        rx: "8",
                        fill: "var(--prbm-shadow)",
                        stroke: "var(--f-gold)",
                        strokeWidth: "3"
                    }), (0, a.jsx)("path", {
                        d: "M60 6 L64.3 15.9 L74.9 16.5 L66.8 23.3 L69.3 33.7 L60 28.1 L50.7 33.7 L53.2 23.3 L45.1 16.5 L55.7 15.9 Z",
                        fill: "var(--f-gold)"
                    })]
                })
            }

            function N() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 200 34",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        x: "2",
                        y: "4",
                        width: "196",
                        height: "26",
                        rx: "4",
                        fill: "var(--f-screen)",
                        ...i,
                        strokeWidth: 3.5
                    }), [0, 1, 2, 3, 4].map(e => (0, a.jsx)("path", {
                        d: `M${20+40*e} 4 L${40+40*e} 4 L${24+40*e} 30 L${4+40*e} 30 Z`,
                        fill: l
                    }, e))]
                })
            }

            function M() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 200 26",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        x: "2",
                        y: "2",
                        width: "196",
                        height: "22",
                        fill: "var(--f-screen)",
                        ...i,
                        strokeWidth: 3.5
                    }), [0, 1, 2, 3, 4].map(e => (0, a.jsx)("path", {
                        d: `M${4+40*e} 2 L${24+40*e} 2 L${40+40*e} 24 L${20+40*e} 24 Z`,
                        fill: l
                    }, e))]
                })
            }

            function w() {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 40 40",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: (0, a.jsx)("path", {
                        d: "M20 3 L25 15 L38 16 L28 25 L31 37 L20 30 L9 37 L12 25 L2 16 L15 15 Z",
                        fill: "var(--f-gold)",
                        stroke: l,
                        strokeWidth: "2.5",
                        strokeLinejoin: "round"
                    })
                })
            }

            function W() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 100 300",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("defs", {
                        children: (0, a.jsxs)("linearGradient", {
                            id: "prbm-spot-g",
                            x1: "0",
                            y1: "1",
                            x2: "0",
                            y2: "0",
                            children: [(0, a.jsx)("stop", {
                                offset: "0",
                                stopColor: "var(--f-screen)",
                                stopOpacity: "0.5"
                            }), (0, a.jsx)("stop", {
                                offset: "1",
                                stopColor: "var(--f-screen)",
                                stopOpacity: "0"
                            })]
                        })
                    }), (0, a.jsx)("path", {
                        d: "M44 300 H56 L100 0 H0 Z",
                        fill: "url(#prbm-spot-g)"
                    })]
                })
            }

            function $({
                flip: e = !1
            }) {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 70 180",
                    "aria-hidden": !0,
                    className: "block size-full",
                    style: e ? {
                        transform: "scaleX(-1)"
                    } : void 0,
                    children: [(0, a.jsx)("path", {
                        d: "M52 172 C18 140 6 80 48 12",
                        fill: "none",
                        stroke: "var(--f-gold)",
                        strokeWidth: "4",
                        strokeLinecap: "round",
                        pathLength: 1,
                        className: "prbm-draw prbm-draw-laurel"
                    }), [{
                        x: 30,
                        y: 150,
                        a: -30
                    }, {
                        x: 20,
                        y: 124,
                        a: -12
                    }, {
                        x: 16,
                        y: 96,
                        a: 4
                    }, {
                        x: 18,
                        y: 68,
                        a: 18
                    }, {
                        x: 28,
                        y: 42,
                        a: 34
                    }, {
                        x: 44,
                        y: 20,
                        a: 52
                    }].map((e, r) => (0, a.jsx)("ellipse", {
                        className: `prbm-leaf prbm-leaf-${r}`,
                        cx: e.x,
                        cy: e.y,
                        rx: "6",
                        ry: "13",
                        transform: `rotate(${e.a} ${e.x} ${e.y})`,
                        fill: "var(--f-gold)",
                        stroke: l,
                        strokeWidth: "2"
                    }, e.y))]
                })
            }

            function C() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 220 140",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("rect", {
                        x: "3",
                        y: "3",
                        width: "214",
                        height: "134",
                        rx: "8",
                        fill: "var(--f-gold)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("path", {
                        d: "M3 137 L110 70 L217 137",
                        fill: "none",
                        stroke: l,
                        strokeWidth: "3",
                        strokeLinejoin: "round",
                        opacity: "0.5"
                    })]
                })
            }

            function S() {
                return (0, a.jsxs)("svg", {
                    viewBox: "0 0 220 90",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("path", {
                        d: "M3 3 H217 L110 86 Z",
                        fill: "var(--prbm-gold-dark)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("circle", {
                        cx: "110",
                        cy: "62",
                        r: "15",
                        fill: "var(--f-carpet)",
                        stroke: l,
                        strokeWidth: "3"
                    }), (0, a.jsx)("path", {
                        d: "M110 53 L113 59 L119 60 L114.5 64 L116 70 L110 67 L104 70 L105.5 64 L101 60 L107 59 Z",
                        fill: "var(--f-gold)"
                    })]
                })
            }
            let B = c(0, 0, 1, 10, .2).map((e, r) => ({
                x: t(100 * e.x),
                y: t(100 * e.y),
                i: r
            }));

            function Z({
                kind: e
            }) {
                return "Clapper" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 120",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsxs)("g", {
                        transform: "rotate(-18 14 40)",
                        children: [(0, a.jsx)("rect", {
                            x: "14",
                            y: "26",
                            width: "92",
                            height: "16",
                            rx: "3",
                            fill: "var(--f-screen)",
                            ...i,
                            strokeWidth: 3.5
                        }), [0, 1, 2, 3].map(e => (0, a.jsx)("path", {
                            d: `M${24+22*e} 26 h11 l-9 16 h-11 Z`,
                            fill: l
                        }, e))]
                    }), (0, a.jsx)("rect", {
                        x: "14",
                        y: "44",
                        width: "92",
                        height: "62",
                        rx: "6",
                        fill: "var(--prbm-shadow)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("path", {
                        d: "M24 64 H96 M24 82 H96 M60 64 V106",
                        stroke: "var(--f-screen)",
                        strokeWidth: "2.5",
                        opacity: "0.7"
                    }), (0, a.jsx)("circle", {
                        cx: "14",
                        cy: "44",
                        r: "4",
                        fill: "var(--f-gold)",
                        stroke: l,
                        strokeWidth: "2"
                    })]
                }) : "Reel" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 120",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, a.jsx)("path", {
                        d: "M84 82 C100 96 110 104 118 100",
                        fill: "none",
                        stroke: l,
                        strokeWidth: "9",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("path", {
                        d: "M84 82 C100 96 110 104 118 100",
                        fill: "none",
                        stroke: "var(--prbm-shadow)",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        strokeDasharray: "3 4"
                    }), (0, a.jsx)("circle", {
                        cx: "56",
                        cy: "56",
                        r: "46",
                        fill: "var(--f-gold)",
                        ...i
                    }), c(56, 56, 24, 6, -Math.PI / 2).map(e => (0, a.jsx)("circle", {
                        cx: e.x,
                        cy: e.y,
                        r: "9",
                        fill: "var(--prbm-shadow)",
                        stroke: l,
                        strokeWidth: "3"
                    }, `${e.x}-${e.y}`)), (0, a.jsx)("circle", {
                        cx: "56",
                        cy: "56",
                        r: "7",
                        fill: l
                    })]
                }) : "Ticket" === e ? (0, a.jsx)("svg", {
                    viewBox: "0 0 120 120",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: (0, a.jsxs)("g", {
                        transform: "rotate(-14 60 60)",
                        children: [(0, a.jsx)("path", {
                            d: "M10 34 H110 V50 A10 10 0 0 0 110 70 V86 H10 V70 A10 10 0 0 0 10 50 Z",
                            fill: "var(--f-accent)",
                            ...i
                        }), (0, a.jsx)("path", {
                            d: "M80 36 V84",
                            stroke: l,
                            strokeWidth: "2.5",
                            strokeDasharray: "4 4"
                        }), (0, a.jsx)("path", {
                            d: "M22 50 H68 M22 60 H60 M22 70 H66",
                            stroke: "var(--f-onAccent)",
                            strokeWidth: "4",
                            strokeLinecap: "round",
                            opacity: "0.8"
                        }), (0, a.jsx)("path", {
                            d: "M95 52 L98 58 L104 59 L99.5 63 L101 69 L95 66 L89 69 L90.5 63 L86 59 L92 58 Z",
                            fill: "var(--f-onAccent)"
                        })]
                    })
                }) : (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 120",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [
                        [{
                            x: 36,
                            y: 32,
                            r: 12
                        }, {
                            x: 56,
                            y: 24,
                            r: 14
                        }, {
                            x: 78,
                            y: 30,
                            r: 12
                        }, {
                            x: 46,
                            y: 40,
                            r: 11
                        }, {
                            x: 68,
                            y: 40,
                            r: 11
                        }].map(e => (0, a.jsx)("circle", {
                            cx: e.x,
                            cy: e.y,
                            r: e.r,
                            fill: "var(--f-screen)",
                            ...i,
                            strokeWidth: 3
                        }, `${e.x}-${e.y}`)), (0, a.jsx)("path", {
                            d: "M26 44 H94 L84 114 H36 Z",
                            fill: "var(--f-screen)",
                            ...i
                        }), [38, 56, 74].map(e => (0, a.jsx)("path", {
                            d: `M${e} 44 L${e+(e-60)*.12+4} 114 H${e+(e-60)*.12+14} L${e+10} 44 Z`,
                            fill: "var(--f-carpet)"
                        }, e)), (0, a.jsx)("path", {
                            d: "M26 44 H94 L84 114 H36 Z",
                            fill: "none",
                            ...i
                        })
                    ]
                })
            }
            let z = {
                Popcorn: (0, a.jsx)(Z, {
                    kind: "Popcorn"
                }),
                Clapper: (0, a.jsx)(Z, {
                    kind: "Clapper"
                }),
                Reel: (0, a.jsx)(Z, {
                    kind: "Reel"
                }),
                Ticket: (0, a.jsx)(Z, {
                    kind: "Ticket"
                })
            };

            function H({
                kind: e
            }) {
                let r = (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)("path", {
                        d: "M44 150 H76 L80 166 H40 Z",
                        fill: "var(--prbm-gold-dark)",
                        ...i,
                        strokeWidth: 3
                    }), (0, a.jsx)("rect", {
                        x: "30",
                        y: "166",
                        width: "60",
                        height: "12",
                        rx: "3",
                        fill: "var(--prbm-shadow)",
                        ...i,
                        strokeWidth: 3
                    }), (0, a.jsx)("path", {
                        d: "M54 120 H66 V150 H54 Z",
                        fill: "var(--f-gold)",
                        ...i,
                        strokeWidth: 3
                    })]
                });
                return "Star" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 180",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [r, (0, a.jsx)("path", {
                        d: "M60 10 L74 46 L112 48 L82 72 L92 110 L60 89 L28 110 L38 72 L8 48 L46 46 Z",
                        fill: "var(--f-gold)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("path", {
                        d: "M60 30 L66 48",
                        stroke: "var(--f-screen)",
                        strokeWidth: "4",
                        strokeLinecap: "round",
                        opacity: "0.7"
                    })]
                }) : "Camera" === e ? (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 180",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [r, (0, a.jsx)("circle", {
                        cx: "42",
                        cy: "38",
                        r: "20",
                        fill: "var(--f-gold)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("circle", {
                        cx: "80",
                        cy: "34",
                        r: "24",
                        fill: "var(--f-gold)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("rect", {
                        x: "22",
                        y: "58",
                        width: "72",
                        height: "52",
                        rx: "12",
                        fill: "var(--f-gold)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("path", {
                        d: "M94 70 L112 62 V106 L94 98 Z",
                        fill: "var(--prbm-gold-dark)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("path", {
                        d: "M32 68 H60",
                        stroke: "var(--f-screen)",
                        strokeWidth: "4",
                        strokeLinecap: "round",
                        opacity: "0.7"
                    })]
                }) : (0, a.jsxs)("svg", {
                    viewBox: "0 0 120 180",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [r, (0, a.jsx)("path", {
                        d: "M26 18 C4 18 4 58 34 64 M94 18 C116 18 116 58 86 64",
                        fill: "none",
                        stroke: "var(--f-gold)",
                        strokeWidth: "8",
                        strokeLinecap: "round"
                    }), (0, a.jsx)("path", {
                        d: "M26 18 C4 18 4 58 34 64 M94 18 C116 18 116 58 86 64",
                        fill: "none",
                        stroke: l,
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        opacity: "0.4"
                    }), (0, a.jsx)("path", {
                        d: "M24 10 H96 C96 70 80 112 60 120 C40 112 24 70 24 10 Z",
                        fill: "var(--f-gold)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, a.jsx)("path", {
                        d: "M38 22 C38 60 46 84 54 98",
                        fill: "none",
                        stroke: "var(--f-screen)",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        opacity: "0.6"
                    }), (0, a.jsx)("path", {
                        d: "M60 36 L65 48 L78 49 L68 57 L71 70 L60 63 L49 70 L52 57 L42 49 L55 48 Z",
                        fill: "var(--prbm-gold-dark)"
                    })]
                })
            }
            let R = {
                    Golden: (0, a.jsx)(H, {
                        kind: "Golden"
                    }),
                    Star: (0, a.jsx)(H, {
                        kind: "Star"
                    }),
                    Camera: (0, a.jsx)(H, {
                        kind: "Camera"
                    })
                },
                Q = [{
                    x: 8,
                    d: 0,
                    s: 14
                }, {
                    x: 22,
                    d: 1.1,
                    s: 10
                }, {
                    x: 36,
                    d: .4,
                    s: 16
                }, {
                    x: 52,
                    d: 1.6,
                    s: 11
                }, {
                    x: 66,
                    d: .8,
                    s: 15
                }, {
                    x: 80,
                    d: 2,
                    s: 10
                }, {
                    x: 92,
                    d: 1.3,
                    s: 13
                }];

            function A() {
                return (0, a.jsx)("svg", {
                    viewBox: "0 0 20 20",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: (0, a.jsx)("path", {
                        d: "M10 0 Q11.5 8.5 20 10 Q11.5 11.5 10 20 Q8.5 11.5 0 10 Q8.5 8.5 10 0 Z",
                        fill: "var(--f-gold)"
                    })
                })
            }
        },
        49945: () => {},
        79081: (e, r, s) => {
            "use strict";
            s.r(r), s.d(r, {
                AwardEnvelope: () => j,
                CreditsRoll: () => u,
                PaparazziWall: () => x,
                PremiereOpening: () => d,
                ReviewBoard: () => f,
                SceneReel: () => m,
                StarName: () => o
            });
            var a = s(73365),
                l = s(1521),
                i = s(14139),
                t = s(87191),
                c = s(34768),
                n = s(82161);

            function d({
                skip: e,
                children: r
            }) {
                let s = "edit" === (0, c.useMode)(),
                    i = (0, n.useFolioSound)(),
                    o = (0, l.useRef)(null),
                    [p, x] = (0, l.useState)(!1);
                return (0, t.useReplaySignal)(o, () => x(!1)), (0, a.jsxs)("div", {
                    ref: o,
                    className: "prbm-open",
                    onClickCapture: e => {
                        let r;
                        !s && !p && (r = o.current ? .querySelector(".prbm-final")) && .99 > Number(getComputedStyle(r).opacity) && (e.preventDefault(), e.stopPropagation(), i.unlock(e.currentTarget), x(!0))
                    },
                    ...p ? {
                        "data-skip": ""
                    } : {},
                    children: [r, s ? null : (0, a.jsx)("button", {
                        type: "button",
                        className: "prbm-skip prbm-beat",
                        children: e
                    })]
                })
            }

            function o({
                className: e = ""
            }) {
                let r = (0, c.useSite)(),
                    s = (0, c.useTemplate)(),
                    l = r ? .page.sections.find(e => "cover" === e.type),
                    i = e => {
                        let r = l ? .values[e];
                        if ("string" == typeof r) return r;
                        let a = s ? .sections.cover ? .fields.find(r => r.id === e) ? .default;
                        return "string" == typeof a ? a : ""
                    },
                    t = i("toName").trim() || i("toFallback");
                return (0, a.jsx)("span", {
                    className: e,
                    children: t
                })
            }
            s(49945);
            let p = [{
                x: 2,
                y: 30,
                turn: 10,
                side: "l"
            }, {
                x: 70,
                y: 30,
                turn: -12,
                side: "r"
            }, {
                x: 38,
                y: 2,
                turn: 4,
                side: "c"
            }];

            function x({
                labels: e,
                shouts: r,
                star: s,
                hint: d,
                done: o
            }) {
                let h = "edit" === (0, c.useMode)(),
                    m = (0, n.useFolioSound)(),
                    f = (0, l.useRef)(null),
                    [j, u] = (0, l.useState)([0, 0, 0]);
                (0, t.useReplaySignal)(f, () => u([0, 0, 0]));
                let v = j.reduce((e, r) => e + r, 0),
                    y = h || j.every(e => e > 0);
                return (0, a.jsxs)("div", {
                    ref: f,
                    className: "prbm-carpet",
                    ...y ? {
                        "data-done": ""
                    } : {},
                    children: [(0, a.jsxs)("div", {
                        className: "prbm-stage",
                        children: [(0, a.jsx)("div", {
                            className: "prbm-layer prbm-layer-back",
                            children: (0, a.jsx)(i.Aq, {})
                        }), (0, a.jsxs)("div", {
                            className: "prbm-layer prbm-layer-mid",
                            children: [(0, a.jsx)("div", {
                                className: "prbm-ropes",
                                children: (0, a.jsx)(i.IA, {})
                            }), p.map((s, l) => {
                                let t = h || j[l] > 0;
                                return (0, a.jsxs)("div", {
                                    className: "prbm-press",
                                    "data-side": s.side,
                                    style: {
                                        left: `${s.x}%`,
                                        top: `${s.y}%`
                                    },
                                    children: [(0, a.jsxs)("button", {
                                        type: "button",
                                        className: "prbm-press-btn",
                                        "aria-label": e[l],
                                        tabIndex: h ? -1 : void 0,
                                        style: {
                                            rotate: `${s.turn}deg`
                                        },
                                        onClick: e => {
                                            var r;
                                            return r = e.currentTarget, void(!h && (m.unlock(r), m.playEffect("shutter"), u(e => e.map((e, r) => r === l ? e + 1 : e))))
                                        },
                                        children: [(0, a.jsx)(i.tz, {}), j[l] > 0 ? (0, a.jsx)("span", {
                                            className: "prbm-burst",
                                            children: (0, a.jsx)(i.LJ, {})
                                        }, j[l]) : null]
                                    }), (0, a.jsx)("div", {
                                        className: "prbm-shout",
                                        ...t ? {
                                            "data-on": ""
                                        } : {},
                                        children: r[l]
                                    })]
                                }, l)
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "prbm-layer prbm-layer-front",
                            children: [(0, a.jsx)("div", {
                                className: "prbm-carpet-floor",
                                children: (0, a.jsx)(i.Ig, {})
                            }), (0, a.jsx)("div", {
                                className: "prbm-fame",
                                children: s
                            }), (0, a.jsx)("div", {
                                className: "prbm-carpet-reelu",
                                children: (0, a.jsx)(i.ET, {
                                    mood: v > 0 ? "wow" : "happy",
                                    pose: y ? "wave" : "idle",
                                    rolling: v > 0
                                })
                            })]
                        }), v > 0 && !h ? (0, a.jsx)("span", {
                            className: "prbm-whiteout",
                            "aria-hidden": !0
                        }, v) : null]
                    }), (0, a.jsx)("div", {
                        className: "prbm-meter",
                        "aria-hidden": !0,
                        children: j.map((e, r) => (0, a.jsx)("i", { ...h || e > 0 ? {
                                "data-on": ""
                            } : {}
                        }, r))
                    }), (0, a.jsx)("div", {
                        className: "prbm-hint",
                        children: d
                    }), (0, a.jsx)("div", {
                        className: "prbm-done",
                        children: o
                    })]
                })
            }

            function h({
                scene: e,
                lit: r,
                dir: s
            }) {
                return (0, a.jsxs)("figure", {
                    className: "prbm-screen",
                    "data-dir": s,
                    ...r ? {
                        "data-lit": ""
                    } : {},
                    children: [(0, a.jsxs)("div", {
                        className: "prbm-screen-frame",
                        children: [(0, a.jsx)("div", {
                            className: "prbm-screen-empty",
                            "aria-hidden": !0
                        }), (0, a.jsx)("div", {
                            className: "prbm-kb",
                            children: e.photo
                        }), (0, a.jsx)("span", {
                            className: "prbm-flicker",
                            "aria-hidden": !0
                        })]
                    }), (0, a.jsx)("figcaption", {
                        className: "prbm-subtitle",
                        children: e.caption
                    })]
                })
            }

            function m({
                scenes: e,
                clapLabel: r,
                nextScene: s,
                hint: d,
                done: o
            }) {
                let p = "edit" === (0, c.useMode)(),
                    x = (0, n.useFolioSound)(),
                    f = (0, l.useRef)(null),
                    j = (0, l.useRef)(null),
                    [u, v] = (0, l.useState)(0),
                    [y, b] = (0, l.useState)(!1);
                (0, t.useReplaySignal)(f, () => {
                    v(0), b(!1)
                });
                let k = e => {
                    p || y || (x.unlock(e), x.playEffect("cut"), b(!0))
                };
                if (p) return (0, a.jsxs)("div", {
                    className: "prbm-scenes",
                    children: [e.map((e, r) => (0, a.jsxs)("div", {
                        className: "prbm-scene-edit",
                        children: [(0, a.jsx)("div", {
                            className: "prbm-board-mini",
                            children: e.board
                        }), (0, a.jsx)(h, {
                            scene: e,
                            lit: !0,
                            dir: r % 2
                        })]
                    }, r)), (0, a.jsx)("div", {
                        className: "prbm-done",
                        "data-show": "",
                        children: o
                    })]
                });
                let g = e[u],
                    L = u >= e.length - 1;
                return (0, a.jsxs)("div", {
                    ref: f,
                    className: "prbm-scenes",
                    children: [(0, a.jsxs)("div", {
                        className: "prbm-scene-row",
                        children: [(0, a.jsxs)("button", {
                            type: "button",
                            className: "prbm-clapper",
                            "aria-label": r,
                            onPointerDown: e => {
                                j.current = e.clientY
                            },
                            onPointerMove: e => {
                                null !== j.current && e.clientY - j.current > 24 && (j.current = null, k(e.currentTarget))
                            },
                            onPointerUp: () => j.current = null,
                            onClick: e => k(e.currentTarget),
                            ...y ? {
                                "data-clapped": ""
                            } : {},
                            children: [(0, a.jsx)("span", {
                                className: "prbm-clap-arm",
                                children: (0, a.jsx)(i.y_, {})
                            }), (0, a.jsxs)("span", {
                                className: "prbm-clap-board",
                                children: [(0, a.jsx)("span", {
                                    className: "prbm-clap-stripes",
                                    children: (0, a.jsx)(i.WS, {})
                                }), (0, a.jsx)("span", {
                                    className: "prbm-clap-text",
                                    children: g.board
                                })]
                            })]
                        }), (0, a.jsx)("div", {
                            className: "prbm-scene-reelu",
                            children: (0, a.jsx)(i.ET, {
                                mood: y ? "happy" : "proud",
                                rolling: y
                            })
                        })]
                    }), (0, a.jsx)(h, {
                        scene: g,
                        lit: y,
                        dir: u % 2
                    }, u), (0, a.jsx)("div", {
                        className: "prbm-dots",
                        "aria-hidden": !0,
                        children: e.map((e, r) => (0, a.jsx)("i", { ...r <= u ? {
                                "data-on": ""
                            } : {}
                        }, r))
                    }), y ? null : (0, a.jsx)("div", {
                        className: "prbm-hint",
                        children: d
                    }), y && !L ? (0, a.jsx)("button", {
                        type: "button",
                        className: "prbm-ghost-btn prbm-pop",
                        onClick: e => {
                            x.unlock(e.currentTarget), x.playEffect("next"), v(e => e + 1), b(!1)
                        },
                        children: s
                    }) : null, (0, a.jsx)("div", {
                        className: "prbm-done",
                        ...y && L ? {
                            "data-show": ""
                        } : {},
                        children: o
                    })]
                })
            }

            function f({
                reviews: e,
                stamp: r,
                done: s
            }) {
                let d = "edit" === (0, c.useMode)(),
                    o = (0, n.useFolioSound)(),
                    p = (0, l.useRef)(null),
                    [x, h] = (0, l.useState)(() => e.map(() => !1));
                (0, t.useReplaySignal)(p, () => h(e.map(() => !1)));
                let m = d || x.every(Boolean);
                return (0, a.jsxs)("div", {
                    ref: p,
                    className: "prbm-reviews",
                    children: [e.map((s, l) => {
                        let t = d || x[l];
                        return (0, a.jsxs)("button", {
                            type: "button",
                            className: "prbm-clip",
                            "aria-label": s.label,
                            "aria-pressed": !!t,
                            tabIndex: d ? -1 : void 0,
                            style: {
                                rotate: `${[-2,1.5,-1][l%3]}deg`
                            },
                            onClick: r => {
                                d || x[l] || (o.unlock(r.currentTarget), o.playEffect(x.filter(Boolean).length === e.length - 1 ? "win" : "pop"), h(e => e.map((e, r) => r === l || e)))
                            },
                            ...t ? {
                                "data-on": ""
                            } : {},
                            children: [(0, a.jsx)("span", {
                                className: "prbm-clip-outlet",
                                children: s.outlet
                            }), (0, a.jsx)("span", {
                                className: "prbm-clip-quote",
                                children: s.quote
                            }), (0, a.jsx)("span", {
                                className: "prbm-stars",
                                "aria-hidden": !0,
                                children: [0, 1, 2, 3, 4].map(e => (0, a.jsx)("span", {
                                    className: "prbm-star",
                                    style: {
                                        "--prbm-i": e
                                    },
                                    children: (0, a.jsx)(i.Nu, {})
                                }, e))
                            }), (0, a.jsx)("span", {
                                className: "prbm-stamp",
                                "aria-hidden": !0,
                                children: r
                            })]
                        }, l)
                    }), (0, a.jsx)("div", {
                        className: "prbm-done",
                        ...m ? {
                            "data-show": ""
                        } : {},
                        children: s
                    })]
                })
            }

            function j({
                openLabel: e,
                card: r,
                trophy: s,
                done: d
            }) {
                let o = "edit" === (0, c.useMode)(),
                    p = (0, n.useFolioSound)(),
                    x = (0, l.useRef)(null),
                    [h, m] = (0, l.useState)(!1);
                (0, t.useReplaySignal)(x, () => m(!1));
                let f = o || h;
                return (0, a.jsxs)("div", {
                    ref: x,
                    className: "prbm-award",
                    ...f ? {
                        "data-open": ""
                    } : {},
                    children: [(0, a.jsx)("span", {
                        className: "prbm-spot prbm-spot-l",
                        "aria-hidden": !0,
                        children: (0, a.jsx)(i.Li, {})
                    }), (0, a.jsx)("span", {
                        className: "prbm-spot prbm-spot-r",
                        "aria-hidden": !0,
                        children: (0, a.jsx)(i.Li, {})
                    }), (0, a.jsxs)("div", {
                        className: "prbm-trophy-stage",
                        "aria-hidden": !0,
                        children: [(0, a.jsx)("div", {
                            className: "prbm-trophy-rise",
                            children: (0, a.jsxs)("div", {
                                className: "prbm-trophy",
                                children: [(0, a.jsx)("span", {
                                    className: "prbm-trophy-face",
                                    children: s
                                }), (0, a.jsx)("span", {
                                    className: "prbm-trophy-face prbm-trophy-face-b",
                                    children: s
                                })]
                            })
                        }), f && !o ? (0, a.jsx)("span", {
                            className: "prbm-sparks",
                            children: i.$A.map(e => (0, a.jsx)("span", {
                                className: "prbm-spark",
                                style: {
                                    "--prbm-x": `${e.x}px`,
                                    "--prbm-y": `${e.y}px`,
                                    animationDelay: `${600+e.i%4*60}ms`
                                },
                                children: (0, a.jsx)(i.RE, {})
                            }, e.i))
                        }) : null]
                    }), (0, a.jsxs)("div", {
                        className: "prbm-envelope",
                        children: [(0, a.jsxs)("div", {
                            className: "prbm-card",
                            children: [(0, a.jsx)("span", {
                                className: "prbm-laurel prbm-laurel-l",
                                children: (0, a.jsx)(i.yy, {})
                            }), (0, a.jsx)("span", {
                                className: "prbm-laurel prbm-laurel-r",
                                children: (0, a.jsx)(i.yy, {
                                    flip: !0
                                })
                            }), r]
                        }), (0, a.jsx)("div", {
                            className: "prbm-env-front",
                            children: (0, a.jsx)(i.i9, {})
                        }), (0, a.jsx)("div", {
                            className: "prbm-env-flap",
                            children: (0, a.jsx)(i.it, {})
                        })]
                    }), f ? null : (0, a.jsx)("button", {
                        type: "button",
                        className: "prbm-solid-btn",
                        onClick: e => {
                            var r;
                            return r = e.currentTarget, void(!o && !h && (p.unlock(r), p.playEffect("win"), m(!0)))
                        },
                        children: e
                    }), (0, a.jsx)("div", {
                        className: "prbm-done",
                        ...f ? {
                            "data-show": ""
                        } : {},
                        children: d
                    })]
                })
            }

            function u({
                children: e
            }) {
                let r, s, l, i = (r = (0, c.useMode)(), s = (0, c.useStory)(), l = (0, c.useSectionIndex)(), "edit" !== r && (!s.active || s.index === l)),
                    t = (0, c.useStackCount)("credits");
                return (0, a.jsx)("div", {
                    className: "prbm-roll-window",
                    children: (0, a.jsx)("div", {
                        className: "prbm-roll",
                        style: {
                            "--prbm-roll": `${(9+1.8*t).toFixed(1)}s`
                        },
                        ...i ? {
                            "data-run": ""
                        } : {},
                        children: e
                    })
                })
            }
        }
    }
]);