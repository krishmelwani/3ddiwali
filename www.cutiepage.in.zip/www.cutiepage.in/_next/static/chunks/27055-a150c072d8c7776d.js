(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [27055], {
        10671: () => {},
        27055: (e, r, l) => {
            "use strict";
            l.r(r), l.d(r, {
                BoatRide: () => b,
                ChaiPour: () => f,
                FogWipe: () => x,
                OpeningSkip: () => d,
                SharedBoat: () => j,
                StayQuestion: () => v,
                UmbrellaShare: () => u
            });
            var t = l(73365),
                s = l(1521),
                a = l(87191),
                i = l(34768),
                n = l(82161),
                o = l(70291);
            l(10671);
            let c = e => Math.min(1, Math.max(0, e));

            function d({
                skipLabel: e,
                children: r
            }) {
                let l = "edit" === (0, i.useMode)(),
                    n = (0, s.useRef)(null),
                    [o, c] = (0, s.useState)(!1);
                return (0, a.useReplaySignal)(n, () => c(!1)), (0, t.jsxs)("div", {
                    ref: n,
                    className: "prbl-open",
                    ...o || l ? {
                        "data-skip": ""
                    } : {},
                    onClickCapture: () => c(!0),
                    children: [r, l ? null : (0, t.jsx)("button", {
                        type: "button",
                        className: "prbl-skip",
                        onClick: () => c(!0),
                        children: e
                    })]
                })
            }
            let p = [0, 1, 2].map(e => {
                let r = 32 + 75 * e + 14,
                    l = [];
                for (let e = 46; e <= 354; e += 12) l.push(e, r + (e / 12 % 2 ? 0 : 44));
                return l
            });

            function h(e, r) {
                for (let l = 0; l < e.length; l += 2) {
                    let t = e[l],
                        s = e[l + 1];
                    for (let e = 0; e < 8; e++)
                        for (let l = 0; l < 6; l++) {
                            let a = 32 + (l + .5) * 224 / 6;
                            30 > Math.abs(40 + (e + .5) * 320 / 8 - t) && 28 > Math.abs(a - s) && r.add(6 * e + l)
                        }
                }
            }

            function x({
                label: e,
                view: r,
                frame: l,
                line: o,
                wipeButton: c,
                hint: d,
                done: u
            }) {
                let b = "edit" === (0, i.useMode)(),
                    j = (0, n.useFolioSound)(),
                    f = (0, s.useRef)(null),
                    v = `prbl-fog-${(0,s.useId)().replace(/[^a-zA-Z0-9]/g,"")}`,
                    [k, M] = (0, s.useState)([]),
                    [m, y] = (0, s.useState)(0),
                    g = (0, s.useRef)(new Set),
                    W = (0, s.useRef)(!1),
                    [w, N] = (0, s.useState)(!1);
                (0, a.useReplaySignal)(f, () => {
                    g.current = new Set, M([]), y(0), N(!1)
                });
                let Q = e => {
                        !w && g.current.size >= 29.759999999999998 && (N(!0), j.unlock(e), j.playEffect("reveal"))
                    },
                    $ = e => {
                        let r = e.currentTarget.getBoundingClientRect();
                        return [(e.clientX - r.left) / r.width * 400, (e.clientY - r.top) / r.height * 300]
                    },
                    L = e => {
                        if (!W.current) return;
                        W.current = !1;
                        let r = k.at(-1);
                        r && h(r, g.current), Q(e.currentTarget)
                    };
                return (0, t.jsxs)("div", {
                    ref: f,
                    className: "prbl-wipe",
                    ...b || w ? {
                        "data-done": ""
                    } : {},
                    children: [(0, t.jsxs)("div", {
                        className: "prbl-stage prbl-stage-window",
                        role: "img",
                        "aria-label": e,
                        children: [r, (0, t.jsx)("div", {
                            className: "prbl-glass-line",
                            children: o
                        }), b ? null : (0, t.jsxs)("svg", {
                            viewBox: "0 0 400 300",
                            preserveAspectRatio: "none",
                            "aria-hidden": !0,
                            className: "prbl-fog",
                            onPointerDown: e => {
                                if (b || w) return;
                                e.currentTarget.setPointerCapture ? .(e.pointerId), W.current = !0, j.unlock(e.currentTarget), j.playEffect("scratch");
                                let [r, l] = $(e);
                                M(e => [...e, [r, l, r + .1, l]])
                            },
                            onPointerMove: e => {
                                if (!W.current) return;
                                let [r, l] = $(e);
                                M(e => {
                                    let t = e.at(-1);
                                    if (!t || t.length > 400) return e;
                                    let s = r - t[t.length - 2],
                                        a = l - t[t.length - 1];
                                    return s * s + a * a < 36 ? e : (h([r, l], g.current), [...e.slice(0, -1), [...t, r, l]])
                                })
                            },
                            onPointerUp: L,
                            onPointerCancel: L,
                            children: [(0, t.jsx)("defs", {
                                children: (0, t.jsxs)("mask", {
                                    id: v,
                                    maskUnits: "userSpaceOnUse",
                                    x: "0",
                                    y: "0",
                                    width: "400",
                                    height: "300",
                                    children: [(0, t.jsx)("rect", {
                                        width: "400",
                                        height: "300",
                                        fill: "#fff"
                                    }), k.map((e, r) => (0, t.jsx)("path", {
                                        d: e.length < 2 ? "" : e.reduce((e, r, l) => l % 2 ? `${e} ${r.toFixed(1)}` : `${e}${l?" L":"M"}${r.toFixed(1)}`, ""),
                                        fill: "none",
                                        stroke: "#000",
                                        strokeWidth: "42",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round"
                                    }, r))]
                                })
                            }), (0, t.jsxs)("g", {
                                mask: `url(#${v})`,
                                children: [(0, t.jsx)("rect", {
                                    width: "400",
                                    height: "300",
                                    className: "prbl-fog-fill"
                                }), [60, 140, 220, 300].map((e, r) => (0, t.jsx)("circle", {
                                    cx: e,
                                    cy: 80 + r % 2 * 110,
                                    r: "56",
                                    className: "prbl-fog-puff"
                                }, e))]
                            })]
                        }), l]
                    }), b ? null : (0, t.jsx)("button", {
                        type: "button",
                        className: "prbl-tool",
                        onClick: e => (e => {
                            if (b || w) return;
                            let r = p[m % p.length];
                            h(r, g.current), M(e => [...e, r]), y(e => e + 1), j.unlock(e), j.playEffect("scratch"), Q(e)
                        })(e.currentTarget),
                        children: c
                    }), (0, t.jsx)("div", {
                        className: "prbl-under",
                        children: d
                    }), (0, t.jsx)("div", {
                        className: "prbl-done",
                        children: u
                    })]
                })
            }

            function u({
                label: e,
                scene: r,
                canopy: l,
                shareButton: d,
                hint: p,
                done: h
            }) {
                let x = "edit" === (0, i.useMode)(),
                    b = (0, n.useFolioSound)(),
                    j = (0, s.useRef)(null),
                    f = (0, s.useRef)(null),
                    v = (0, s.useRef)(null),
                    [k, M] = (0, s.useState)(0),
                    [m, y] = (0, s.useState)(!1),
                    g = x || m;
                (0, a.useReplaySignal)(j, () => {
                    M(0), y(!1)
                });
                let W = e => {
                        g || (y(!0), M(1), b.unlock(e), b.playEffect("win"))
                    },
                    w = e => {
                        if (!v.current) return;
                        let r = Math.abs(e.clientX - v.current.x);
                        v.current = null, k > .5 || r < 6 ? W(e.currentTarget) : M(0)
                    },
                    N = !g && k > .15;
                return (0, t.jsxs)("div", {
                    ref: j,
                    className: "prbl-share",
                    ...g ? {
                        "data-done": ""
                    } : {},
                    children: [(0, t.jsxs)("div", {
                        ref: f,
                        className: "prbl-stage prbl-stage-stop",
                        role: "img",
                        "aria-label": e,
                        style: {
                            "--prbl-drag": g ? 1 : k
                        },
                        children: [r, (0, t.jsx)("div", {
                            className: "prbl-pa",
                            children: (0, t.jsx)(o._A, {
                                who: "a",
                                mood: g ? "shy" : "smile",
                                pose: "umbrella"
                            })
                        }), (0, t.jsxs)("div", {
                            className: "prbl-pb",
                            children: [(0, t.jsx)(o._A, {
                                who: "b",
                                mood: g ? "laugh" : N ? "wow" : "sad",
                                pose: g ? "stand" : "umbrella"
                            }), (0, t.jsx)("span", {
                                className: "prbl-broken",
                                children: (0, t.jsx)(o.ET, {})
                            }), (0, t.jsx)("span", {
                                className: "prbl-pb-rain",
                                children: (0, t.jsx)(o.h7, {
                                    depth: "near",
                                    count: 6
                                })
                            })]
                        }), (0, t.jsx)("button", {
                            type: "button",
                            className: "prbl-canopy",
                            tabIndex: -1,
                            "aria-hidden": !0,
                            onPointerDown: e => {
                                g || (e.currentTarget.setPointerCapture ? .(e.pointerId), v.current = {
                                    x: e.clientX,
                                    width: f.current ? .getBoundingClientRect().width ? ? 320
                                }, b.unlock(e.currentTarget))
                            },
                            onPointerMove: e => {
                                v.current && M(c((e.clientX - v.current.x) / (.3 * v.current.width)))
                            },
                            onPointerUp: w,
                            onPointerCancel: w,
                            children: l
                        })]
                    }), g ? null : (0, t.jsx)("button", {
                        type: "button",
                        className: "prbl-tool",
                        onClick: e => W(e.currentTarget),
                        children: d
                    }), (0, t.jsx)("div", {
                        className: "prbl-under",
                        children: p
                    }), (0, t.jsx)("div", {
                        className: "prbl-done",
                        children: h
                    })]
                })
            }

            function b({
                label: e,
                far: r,
                mid: l,
                near: d,
                boat: p,
                photo: h,
                pushButton: x,
                hint: u,
                done: j
            }) {
                let f = "edit" === (0, i.useMode)(),
                    v = (0, n.useFolioSound)(),
                    k = (0, s.useRef)(null),
                    M = (0, s.useRef)(null),
                    [m, y] = (0, s.useState)(0),
                    [g, W] = (0, s.useState)(!1),
                    w = f || g;
                (0, a.useReplaySignal)(k, () => {
                    W(!1), y(0)
                });
                let N = e => {
                    w || (W(!0), y(0), v.unlock(e), v.playEffect("open"))
                };
                return (0, t.jsxs)("div", {
                    ref: k,
                    className: "prbl-ride",
                    ...w ? {
                        "data-done": ""
                    } : {},
                    children: [(0, t.jsxs)("div", {
                        className: "prbl-stage prbl-stage-river",
                        role: "img",
                        "aria-label": e,
                        children: [(0, t.jsx)("div", {
                            className: "prbl-layer prbl-layer-far",
                            children: r
                        }), (0, t.jsx)("div", {
                            className: "prbl-layer prbl-layer-mid",
                            children: l
                        }), (0, t.jsx)(o.h7, {
                            depth: "far",
                            count: 12
                        }), (0, t.jsx)("div", {
                            className: "prbl-layer prbl-layer-near",
                            children: d
                        }), (0, t.jsx)("div", {
                            className: "prbl-raft",
                            children: h
                        }), (0, t.jsx)("button", {
                            type: "button",
                            className: "prbl-boat",
                            tabIndex: -1,
                            "aria-hidden": !0,
                            style: {
                                "--prbl-nudge": m
                            },
                            onPointerDown: e => {
                                w || (e.currentTarget.setPointerCapture ? .(e.pointerId), M.current = e.clientX, v.unlock(e.currentTarget))
                            },
                            onPointerMove: e => {
                                null !== M.current && y(c((e.clientX - M.current) / 90))
                            },
                            onPointerUp: e => {
                                if (null === M.current) return;
                                let r = e.clientX - M.current;
                                M.current = null, r > 30 || 6 > Math.abs(r) ? N(e.currentTarget) : y(0)
                            },
                            onPointerCancel: () => {
                                M.current = null, y(0)
                            },
                            children: (0, t.jsx)("span", {
                                className: "prbl-boat-bob",
                                children: p
                            })
                        }), (0, t.jsx)(o.h7, {
                            depth: "near",
                            count: 7
                        })]
                    }), w ? null : (0, t.jsx)("button", {
                        type: "button",
                        className: "prbl-tool",
                        onClick: e => N(e.currentTarget),
                        children: x
                    }), (0, t.jsx)("div", {
                        className: "prbl-under",
                        children: u
                    }), (0, t.jsx)("div", {
                        className: "prbl-done",
                        children: j
                    })]
                })
            }

            function j() {
                let e = (0, i.useSite)(),
                    r = (0, i.useAssetResolver)(),
                    l = e ? .page.sections.find(e => "meet" === e.type),
                    s = "string" == typeof l ? .values.boat ? l.values.boat : "",
                    a = r("string" == typeof l ? .values.boatPhoto ? l.values.boatPhoto : "");
                return a ? (0, t.jsx)("img", {
                    src: a,
                    alt: "",
                    className: "block size-full object-contain"
                }) : (0, t.jsx)(t.Fragment, {
                    children: o.v9[s] ? ? o.v9.Newspaper
                })
            }

            function f({
                label: e,
                scene: r,
                pair: l,
                pourButton: c,
                hint: d,
                done: p
            }) {
                let h = "edit" === (0, i.useMode)(),
                    x = (0, n.useFolioSound)(),
                    u = (0, s.useRef)(null),
                    b = (0, s.useRef)(0),
                    j = (0, s.useRef)(null),
                    [v, k] = (0, s.useState)(!1),
                    M = h || v,
                    m = () => {
                        let e = u.current;
                        e && e.style.setProperty("--prbl-fill", b.current.toFixed(3))
                    },
                    y = () => {
                        b.current < 1 || v || (u.current ? .removeAttribute("data-pouring"), k(!0), x.playEffect("win"))
                    };
                (0, a.useReplaySignal)(u, () => {
                    b.current = 0, m(), k(!1)
                });
                let g = e => {
                        let r = j.current;
                        if (r) {
                            if (b.current = Math.min(1, b.current + (e - r.last) / 1800), r.last = e, m(), b.current >= 1) {
                                j.current = null, y();
                                return
                            }
                            r.frame = requestAnimationFrame(g)
                        }
                    },
                    W = () => {
                        let e = j.current;
                        e && cancelAnimationFrame(e.frame), j.current = null, u.current ? .removeAttribute("data-pouring")
                    },
                    w = (0, s.useRef)(0),
                    N = {
                        onPointerDown: e => {
                            if (h || M) return;
                            x.unlock(e.currentTarget), x.playEffect("tap");
                            let r = performance.now();
                            j.current = {
                                from: b.current,
                                last: r,
                                frame: requestAnimationFrame(g)
                            }, u.current ? .setAttribute("data-pouring", "")
                        },
                        onPointerUp: () => {
                            w.current = j.current ? b.current - j.current.from : 1, W()
                        },
                        onPointerLeave: W,
                        onPointerCancel: W,
                        onClick: () => {
                            h || M || (w.current < .08 && (b.current = Math.min(1, b.current + .34), m(), y()), w.current = 0)
                        }
                    };
                return (0, t.jsxs)("div", {
                    ref: u,
                    className: "prbl-chai",
                    ...M ? {
                        "data-done": ""
                    } : {},
                    children: [(0, t.jsxs)("div", {
                        className: "prbl-stage prbl-stage-tapri",
                        role: "img",
                        "aria-label": e,
                        ...M ? {} : N,
                        children: [r, (0, t.jsxs)("div", {
                            className: "prbl-kettle",
                            children: [(0, t.jsx)(o.Eu, {}), (0, t.jsx)("span", {
                                className: "prbl-stream"
                            })]
                        }), (0, t.jsxs)("div", {
                            className: "prbl-kulhad",
                            children: [(0, t.jsx)(o.Ah, {}), (0, t.jsx)("span", {
                                className: "prbl-kulhad-steam",
                                children: (0, t.jsx)(o.Rv, {})
                            })]
                        }), (0, t.jsx)("div", {
                            className: "prbl-chai-pair",
                            children: l
                        })]
                    }), M ? null : (0, t.jsx)("button", {
                        type: "button",
                        className: "prbl-tool prbl-tool-hold",
                        ...N,
                        children: c
                    }), (0, t.jsx)("div", {
                        className: "prbl-under",
                        children: d
                    }), (0, t.jsx)("div", {
                        className: "prbl-done",
                        children: p
                    })]
                })
            }

            function v({
                label: e,
                question: r,
                yes: l,
                yesToo: c,
                children: d
            }) {
                let p = "edit" === (0, i.useMode)(),
                    h = (0, n.useFolioSound)(),
                    x = (0, s.useRef)(null),
                    [u, b] = (0, s.useState)(0),
                    j = p || u > 0;
                (0, a.useReplaySignal)(x, () => b(0));
                let f = e => {
                    h.unlock(e), h.playEffect("confetti"), b(e => e + 1)
                };
                return (0, t.jsxs)("div", {
                    ref: x,
                    className: "prbl-stay",
                    ...j ? {
                        "data-yes": ""
                    } : {},
                    children: [(0, t.jsxs)("div", {
                        className: "prbl-stage prbl-stage-sky",
                        role: "img",
                        "aria-label": e,
                        children: [(0, t.jsx)("span", {
                            className: "prbl-sun",
                            children: (0, t.jsx)(o.bd, {})
                        }), (0, t.jsx)("span", {
                            className: "prbl-bow",
                            children: j ? (0, t.jsx)(o.tC, {}) : null
                        }), (0, t.jsxs)("span", {
                            className: "prbl-rain-wrap",
                            children: [(0, t.jsx)(o.h7, {
                                depth: "mid",
                                count: 14
                            }), (0, t.jsx)(o.h7, {
                                depth: "near",
                                count: 8
                            })]
                        }), (0, t.jsx)("span", {
                            className: "prbl-cloud prbl-cloud-l",
                            children: (0, t.jsx)(o.Es, {})
                        }), (0, t.jsx)("span", {
                            className: "prbl-cloud prbl-cloud-r",
                            children: (0, t.jsx)(o.Es, {})
                        }), (0, t.jsxs)("div", {
                            className: "prbl-stay-pair",
                            children: [(0, t.jsx)(o._A, {
                                who: "a",
                                mood: j ? "love" : "shy",
                                pose: j ? "heart" : "stand"
                            }), (0, t.jsx)(o._A, {
                                who: "b",
                                mood: j ? "laugh" : "wow",
                                pose: j ? "wave" : "stand"
                            })]
                        }), j && !p ? (0, t.jsx)(o.Ed, {}, u) : null, j && !p ? (0, t.jsx)(a.ConfettiBurst, {
                            seed: 21,
                            count: 34,
                            top: "40%"
                        }, `c${u}`) : null]
                    }), (0, t.jsxs)("div", {
                        className: "prbl-ask",
                        children: [r, j ? null : (0, t.jsxs)("div", {
                            className: "prbl-ask-row",
                            children: [(0, t.jsx)("button", {
                                type: "button",
                                className: "prbl-yes",
                                onClick: e => f(e.currentTarget),
                                children: l
                            }), (0, t.jsx)("button", {
                                type: "button",
                                className: "prbl-yes prbl-yes-2",
                                onClick: e => f(e.currentTarget),
                                children: c
                            })]
                        })]
                    }), (0, t.jsx)("div", {
                        className: "prbl-after",
                        children: d
                    })]
                })
            }
        },
        70291: (e, r, l) => {
            "use strict";
            l.d(r, {
                $s: () => $,
                Ah: () => A,
                ET: () => h,
                Ed: () => H,
                Es: () => R,
                Eu: () => V,
                FJ: () => j,
                H3: () => w,
                OQ: () => m,
                Rv: () => C,
                SM: () => u,
                U9: () => k,
                Uk: () => g,
                XP: () => P,
                _A: () => o,
                a1: () => N,
                bd: () => S,
                h7: () => v,
                hv: () => y,
                hw: () => Q,
                kB: () => F,
                nM: () => L,
                rP: () => W,
                tC: () => B,
                u7: () => b,
                v9: () => f,
                vj: () => M
            });
            var t = l(73365);
            let s = {
                stroke: "var(--prbl-line)",
                strokeLinejoin: "round",
                strokeLinecap: "round"
            };

            function a({
                mood: e
            }) {
                if ("laugh" === e) return (0, t.jsx)("path", {
                    d: "M36 57 Q40.5 51.5 45 57 M55 57 Q59.5 51.5 64 57",
                    fill: "none",
                    ...s,
                    strokeWidth: 2.8
                });
                if ("love" === e) {
                    let e = e => `M${e} 60.5 C${e-6} 56.5 ${e-5.5} 51 ${e-2.6} 51 C${e-1.2} 51 ${e} 52 ${e} 53.4 C${e} 52 ${e+1.2} 51 ${e+2.6} 51 C${e+5.5} 51 ${e+6} 56.5 ${e} 60.5 Z`;
                    return (0, t.jsxs)("g", {
                        className: "prbl-love-eyes",
                        children: [(0, t.jsx)("path", {
                            d: e(40.5),
                            fill: "var(--prbl-coatA)",
                            ...s,
                            strokeWidth: 1.4
                        }), (0, t.jsx)("path", {
                            d: e(59.5),
                            fill: "var(--prbl-coatA)",
                            ...s,
                            strokeWidth: 1.4
                        })]
                    })
                }
                let r = "wow" === e ? 4.6 : "shy" === e ? 2.6 : 3.7,
                    l = "shy" === e ? 58.5 : 56;
                return (0, t.jsxs)("g", {
                    className: "prbl-eyes",
                    children: [(0, t.jsx)("ellipse", {
                        cx: "40.5",
                        cy: l,
                        rx: "2.9",
                        ry: r,
                        fill: "var(--prbl-line)"
                    }), (0, t.jsx)("ellipse", {
                        cx: "59.5",
                        cy: l,
                        rx: "2.9",
                        ry: r,
                        fill: "var(--prbl-line)"
                    }), (0, t.jsx)("circle", {
                        cx: "41.6",
                        cy: l - 1.4,
                        r: "1",
                        fill: "var(--prbl-paper)"
                    }), (0, t.jsx)("circle", {
                        cx: "60.6",
                        cy: l - 1.4,
                        r: "1",
                        fill: "var(--prbl-paper)"
                    })]
                })
            }

            function i({
                mood: e
            }) {
                let r = "shy" === e || "love" === e || "laugh" === e;
                return (0, t.jsxs)("g", {
                    children: ["sad" === e ? (0, t.jsx)("path", {
                        d: "M35 49 L45 46 M65 49 L55 46",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.2
                    }) : null, "wow" === e ? (0, t.jsx)("path", {
                        d: "M35 47 Q40 43 45 46 M55 46 Q60 43 65 47",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.2
                    }) : null, (0, t.jsx)(a, {
                        mood: e
                    }), "smile" === e || "love" === e ? (0, t.jsx)("path", {
                        d: "M44 65 Q50 71.5 56 65",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.6
                    }) : null, "sad" === e ? (0, t.jsx)("path", {
                        d: "M44.5 69 Q50 64 55.5 69",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.6
                    }) : null, "shy" === e ? (0, t.jsx)("path", {
                        d: "M46.5 66.5 Q50 68.6 53.5 66.5",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.4
                    }) : null, "wow" === e ? (0, t.jsx)("ellipse", {
                        cx: "50",
                        cy: "67.5",
                        rx: "3.4",
                        ry: "4.4",
                        fill: "var(--prbl-line)"
                    }) : null, "laugh" === e ? (0, t.jsxs)("g", {
                        children: [(0, t.jsx)("path", {
                            d: "M42.5 63 Q50 76 57.5 63 Z",
                            fill: "var(--prbl-line)",
                            ...s,
                            strokeWidth: 2
                        }), (0, t.jsx)("path", {
                            d: "M46 69.5 Q50 67 54 69.5 Q50 72.5 46 69.5 Z",
                            fill: "var(--prbl-coatA)"
                        })]
                    }) : null, "sad" === e ? (0, t.jsx)("path", {
                        d: "M36 62 q-2.4 3.6 0 5 q2.4 -1.4 0 -5 Z",
                        fill: "var(--prbl-rain)",
                        ...s,
                        strokeWidth: 1
                    }) : null, r ? (0, t.jsxs)("g", {
                        opacity: "0.55",
                        children: [(0, t.jsx)("ellipse", {
                            cx: "34.5",
                            cy: "63",
                            rx: "4.4",
                            ry: "2.6",
                            fill: "var(--prbl-coatA)"
                        }), (0, t.jsx)("ellipse", {
                            cx: "65.5",
                            cy: "63",
                            rx: "4.4",
                            ry: "2.6",
                            fill: "var(--prbl-coatA)"
                        })]
                    }) : null]
                })
            }

            function n({
                side: e,
                coat: r
            }) {
                let l = "l" === e ? 35.5 : 64.5;
                return (0, t.jsxs)("g", {
                    className: `prbl-arm prbl-arm-${e}`,
                    children: [(0, t.jsx)("path", {
                        d: `M${l} 93 V119`,
                        fill: "none",
                        stroke: "var(--prbl-line)",
                        strokeWidth: 12.5,
                        strokeLinecap: "round"
                    }), (0, t.jsx)("path", {
                        d: `M${l} 93 V119`,
                        fill: "none",
                        stroke: r,
                        strokeWidth: 7.5,
                        strokeLinecap: "round"
                    }), (0, t.jsx)("circle", {
                        cx: l,
                        cy: "123",
                        r: "5.2",
                        fill: "var(--prbl-skin)",
                        ...s,
                        strokeWidth: 2.4
                    })]
                })
            }

            function o({
                who: e,
                mood: r,
                pose: l = "stand",
                className: a = ""
            }) {
                let c = "a" === e ? "var(--prbl-coatA)" : "var(--prbl-coatB)";
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 100 172",
                    "aria-hidden": !0,
                    className: `prbl-person ${a}`,
                    "data-who": e,
                    "data-pose": l,
                    "data-mood": r,
                    children: [(0, t.jsx)("ellipse", {
                        cx: "50",
                        cy: "165",
                        rx: "26",
                        ry: "4.5",
                        fill: "var(--prbl-line)",
                        opacity: "0.18"
                    }), (0, t.jsxs)("g", {
                        className: "prbl-rig",
                        children: [(0, t.jsxs)("g", {
                            className: "prbl-legs",
                            children: [(0, t.jsx)("path", {
                                d: "M42 128 V152 M58 128 V152",
                                fill: "none",
                                stroke: "var(--prbl-line)",
                                strokeWidth: 12,
                                strokeLinecap: "round"
                            }), (0, t.jsx)("path", {
                                d: "M42 128 V152 M58 128 V152",
                                fill: "none",
                                stroke: "var(--prbl-pant)",
                                strokeWidth: 7,
                                strokeLinecap: "round"
                            }), (0, t.jsx)("path", {
                                d: "M34.5 149 h14 v8 q0 4 -4 4 h-10 q-3 0 -3 -3 z M51.5 149 h14 v9 q0 3 -3 3 h-10 q-4 0 -4 -4 z",
                                fill: "var(--prbl-boot)",
                                ...s,
                                strokeWidth: 2.6
                            })]
                        }), "b" === e ? (0, t.jsx)("path", {
                            d: "M24 58 Q19 30 50 25 Q81 30 76 58 L81 106 Q66 114 50 111 Q34 114 19 106 Z",
                            fill: "var(--prbl-hair)",
                            ...s,
                            strokeWidth: 3
                        }) : null, (0, t.jsx)("path", {
                            d: "M34 134 Q31 102 37.5 91 Q50 83 62.5 91 Q69 102 66 134 Q50 140 34 134 Z",
                            fill: c,
                            ...s,
                            strokeWidth: 3
                        }), (0, t.jsx)("path", {
                            d: "M50 88 V136",
                            fill: "none",
                            ...s,
                            strokeWidth: 2,
                            opacity: "0.55"
                        }), (0, t.jsx)("circle", {
                            cx: "54.5",
                            cy: "104",
                            r: "1.9",
                            fill: "var(--prbl-line)"
                        }), (0, t.jsx)("circle", {
                            cx: "54.5",
                            cy: "117",
                            r: "1.9",
                            fill: "var(--prbl-line)"
                        }), (0, t.jsx)("path", {
                            d: "M39 118 h8 v7 h-8 z",
                            fill: "none",
                            ...s,
                            strokeWidth: 1.8,
                            opacity: "0.55"
                        }), (0, t.jsx)("path", {
                            d: "M44 84 Q50 90 56 84",
                            fill: "var(--prbl-skin)",
                            ...s,
                            strokeWidth: 2.4
                        }), (0, t.jsxs)("g", {
                            className: "prbl-head",
                            children: [(0, t.jsx)("circle", {
                                cx: "25",
                                cy: "59",
                                r: "4.4",
                                fill: "var(--prbl-skin)",
                                ...s,
                                strokeWidth: 2.4
                            }), (0, t.jsx)("circle", {
                                cx: "75",
                                cy: "59",
                                r: "4.4",
                                fill: "var(--prbl-skin)",
                                ...s,
                                strokeWidth: 2.4
                            }), "b" === e ? (0, t.jsxs)("g", {
                                fill: "var(--prbl-accent)",
                                ...s,
                                strokeWidth: 1.4,
                                children: [(0, t.jsx)("circle", {
                                    cx: "24",
                                    cy: "66",
                                    r: "2.4"
                                }), (0, t.jsx)("path", {
                                    d: "M20.5 70 Q24 66.5 27.5 70 L24 75 Z"
                                }), (0, t.jsx)("circle", {
                                    cx: "76",
                                    cy: "66",
                                    r: "2.4"
                                }), (0, t.jsx)("path", {
                                    d: "M72.5 70 Q76 66.5 79.5 70 L76 75 Z"
                                })]
                            }) : null, (0, t.jsx)("circle", {
                                cx: "50",
                                cy: "55",
                                r: "25.5",
                                fill: "var(--prbl-skin)",
                                ...s,
                                strokeWidth: 3
                            }), "a" === e ? (0, t.jsx)("path", {
                                d: "M24.6 56 Q21 25 50 24.5 Q79 25 75.4 56 Q72 41 63.5 37 Q57 45.5 43.5 42 Q35 41 29.5 47 Q26.4 51 24.6 56 Z M49 25 q3 -7 10 -4",
                                fill: "var(--prbl-hair)",
                                ...s,
                                strokeWidth: 3
                            }) : (0, t.jsxs)("g", {
                                children: [(0, t.jsx)("path", {
                                    d: "M24.6 56 Q24 28 50 26 Q76 28 75.4 56 Q72 40 60 35 Q54 32.5 50 30.5 Q46 32.5 40 35 Q28 40 24.6 56 Z",
                                    fill: "var(--prbl-hair)",
                                    ...s,
                                    strokeWidth: 3
                                }), (0, t.jsx)("circle", {
                                    cx: "50",
                                    cy: "44",
                                    r: "1.7",
                                    fill: "var(--prbl-coatA)"
                                })]
                            }), (0, t.jsx)(i, {
                                mood: r
                            })]
                        }), (0, t.jsx)(n, {
                            side: "l",
                            coat: c
                        }), (0, t.jsx)(n, {
                            side: "r",
                            coat: c
                        }), "heart" === l ? (0, t.jsx)("path", {
                            className: "prbl-pop-heart",
                            d: "M50 16 C40 9 41 0 46 0 C48.4 0 50 1.8 50 3.6 C50 1.8 51.6 0 54 0 C59 0 60 9 50 16 Z",
                            fill: "var(--prbl-coatA)",
                            ...s,
                            strokeWidth: 1.8
                        }) : null]
                    })]
                })
            }
            let c = (e, r, l) => `M${e} ${r+6*l} C${e-7*l} ${r+ +l} ${e-5*l} ${r-5*l} ${e-2*l} ${r-5*l} C${e-.8*l} ${r-5*l} ${e} ${r-4*l} ${e} ${r-3*l} C${e} ${r-4*l} ${e+.8*l} ${r-5*l} ${e+2*l} ${r-5*l} C${e+5*l} ${r-5*l} ${e+7*l} ${r+ +l} ${e} ${r+6*l} Z`,
                d = ["M80 30 Q44 30 8 70 Q26 60 44 70 Q44 42 80 30 Z", "M80 30 Q44 42 44 70 Q62 60 80 70 Z", "M80 30 L80 70 Q98 60 116 70 Q116 42 80 30 Z", "M80 30 Q116 42 116 70 Q134 60 152 70 Q116 30 80 30 Z"];

            function p({
                kind: e
            }) {
                let r = "Hearts" === e ? "var(--prbl-coatB)" : "var(--prbl-accent)";
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 160 150",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        d: "M80 70 V134 Q80 146 71 146 Q63 146 63 138",
                        fill: "none",
                        ...s,
                        strokeWidth: 4.5
                    }), (0, t.jsx)("path", {
                        d: "M80 30 V19",
                        fill: "none",
                        ...s,
                        strokeWidth: 4
                    }), (0, t.jsx)("circle", {
                        cx: "80",
                        cy: "17",
                        r: "4",
                        fill: "var(--prbl-accent)",
                        ...s,
                        strokeWidth: 2.5
                    }), d.map((l, a) => (0, t.jsx)("path", {
                        d: l,
                        fill: "Stripes" === e && a % 2 == 1 ? "var(--prbl-coatA)" : r,
                        ...s,
                        strokeWidth: 3.5
                    }, l)), "Polka" === e ? [
                        [30, 58],
                        [52, 46],
                        [66, 60],
                        [96, 58],
                        [108, 44],
                        [130, 60],
                        [80, 44]
                    ].map(([e, r]) => (0, t.jsx)("circle", {
                        cx: e,
                        cy: r,
                        r: "4.6",
                        fill: "var(--prbl-paper)"
                    }, `${e}-${r}`)) : null, "Hearts" === e ? [
                        [32, 58, 1],
                        [62, 52, 1.2],
                        [98, 52, 1.2],
                        [128, 58, 1]
                    ].map(([e, r, l]) => (0, t.jsx)("path", {
                        d: c(e, r, l),
                        fill: "var(--prbl-paper)"
                    }, `${e}`)) : null, (0, t.jsx)("path", {
                        d: "M8 70 Q44 30 80 30 Q116 30 152 70",
                        fill: "none",
                        ...s,
                        strokeWidth: 4
                    })]
                })
            }

            function h() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 120 130",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        d: "M60 50 V118 Q60 126 53 126 Q47 126 47 120",
                        fill: "none",
                        ...s,
                        strokeWidth: 4
                    }), (0, t.jsx)("path", {
                        d: "M14 14 Q34 30 60 50 Q86 30 106 14 Q90 22 78 18 Q70 30 60 26 Q50 30 42 18 Q30 22 14 14 Z",
                        fill: "var(--prbl-muted-art)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M60 50 L42 18 M60 50 L78 18 M60 50 L30 8",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.4
                    })]
                })
            }

            function x({
                kind: e
            }) {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 160 110",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        d: "M40 62 L80 6 L120 62 Z",
                        fill: "Rangeen" === e ? "var(--prbl-accent)" : "var(--prbl-paper)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M80 6 V62",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.2,
                        opacity: "0.5"
                    }), "Newspaper" === e ? (0, t.jsxs)("g", {
                        stroke: "var(--prbl-line)",
                        strokeLinecap: "round",
                        opacity: "0.45",
                        children: [(0, t.jsx)("path", {
                            d: "M60 40 h14 M58 46 h16 M55 52 h19 M86 30 h6 M86 36 h10 M86 42 h14 M86 48 h18 M86 54 h22",
                            strokeWidth: "2"
                        }), (0, t.jsx)("path", {
                            d: "M64 30 h10",
                            strokeWidth: "4"
                        })]
                    }) : null, "Notebook" === e ? (0, t.jsxs)("g", {
                        fill: "none",
                        strokeLinecap: "round",
                        children: [(0, t.jsx)("path", {
                            d: "M62 34 h36 M56 42 h48 M50 50 h60 M44 58 h72",
                            stroke: "var(--prbl-water)",
                            strokeWidth: "1.8",
                            opacity: "0.7"
                        }), (0, t.jsx)("path", {
                            d: "M70 20 V62",
                            stroke: "var(--prbl-coatA)",
                            strokeWidth: "1.8",
                            opacity: "0.8"
                        })]
                    }) : null, "Rangeen" === e ? (0, t.jsx)("path", {
                        d: c(80, 42, 1.6),
                        fill: "var(--prbl-coatA)",
                        ...s,
                        strokeWidth: 2
                    }) : null, (0, t.jsx)("path", {
                        d: "M8 60 L152 60 L128 94 L32 94 Z",
                        fill: "Rangeen" === e ? "var(--prbl-coatA)" : "var(--prbl-paper)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M8 60 L48 76 L80 60 L112 76 L152 60",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.4,
                        opacity: "0.55"
                    }), "Notebook" === e ? (0, t.jsx)("path", {
                        d: "M30 72 h100 M38 84 h84",
                        stroke: "var(--prbl-water)",
                        strokeWidth: "1.6",
                        opacity: "0.6"
                    }) : null, "Newspaper" === e ? (0, t.jsx)("path", {
                        d: "M36 80 h30 M90 80 h34 M44 88 h22",
                        stroke: "var(--prbl-line)",
                        strokeWidth: "2",
                        opacity: "0.4",
                        strokeLinecap: "round"
                    }) : null]
                })
            }
            let u = ["Polka", "Stripes", "Hearts"],
                b = ["Newspaper", "Notebook", "Rangeen"],
                j = {
                    Polka: (0, t.jsx)(p, {
                        kind: "Polka"
                    }),
                    Stripes: (0, t.jsx)(p, {
                        kind: "Stripes"
                    }),
                    Hearts: (0, t.jsx)(p, {
                        kind: "Hearts"
                    })
                },
                f = {
                    Newspaper: (0, t.jsx)(x, {
                        kind: "Newspaper"
                    }),
                    Notebook: (0, t.jsx)(x, {
                        kind: "Notebook"
                    }),
                    Rangeen: (0, t.jsx)(x, {
                        kind: "Rangeen"
                    })
                };

            function v({
                depth: e,
                count: r
            }) {
                let l = "far" === e ? 1.25 : "mid" === e ? .9 : .62;
                return (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className: "prbl-rain",
                    "data-depth": e,
                    children: Array.from({
                        length: r
                    }, (r, s) => (0, t.jsx)("i", {
                        style: {
                            left: `${(37.7*s+("near"===e?11:5*("mid"===e)))%104-2}%`,
                            animationDuration: `${(l+7*s%5*.06).toFixed(2)}s`,
                            animationDelay: `-${(.371*s%1*l).toFixed(2)}s`
                        }
                    }, s))
                })
            }

            function k({
                count: e = 7
            }) {
                return (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className: "prbl-beads",
                    children: Array.from({
                        length: e
                    }, (e, r) => (0, t.jsx)("i", {
                        style: {
                            left: `${8+29*r%84}%`,
                            top: `${4+17*r%30}%`,
                            width: `${7+r%3*3}px`,
                            height: `${9+r%3*3}px`,
                            animationDuration: `${(5.5+r%4*1.3).toFixed(1)}s`,
                            animationDelay: `-${(1.9*r%6).toFixed(1)}s`
                        }
                    }, r))
                })
            }

            function M() {
                return (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className: "prbl-drips",
                    children: [6, 20, 34, 49, 63, 78, 92].map((e, r) => (0, t.jsx)("i", {
                        style: {
                            left: `${e}%`,
                            animationDelay: `-${(.43*r%1.4).toFixed(2)}s`
                        }
                    }, e))
                })
            }

            function m() {
                let e = [
                    [0, 150, 46],
                    [40, 120, 38],
                    [74, 168, 30],
                    [100, 100, 44],
                    [170, 132, 40],
                    [206, 92, 34],
                    [236, 146, 48],
                    [280, 110, 36],
                    [312, 138, 44],
                    [352, 104, 50]
                ];
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 400 300",
                    preserveAspectRatio: "xMidYMax slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, t.jsxs)("g", {
                        fill: "var(--prbl-far)",
                        children: [e.map(([e, r, l]) => (0, t.jsx)("rect", {
                            x: e,
                            y: r,
                            width: l,
                            height: 300 - r
                        }, e)), (0, t.jsx)("path", {
                            d: "M140 300 V130 L150 118 L156 84 L160 70 L164 84 L170 118 L180 130 V300 Z"
                        }), (0, t.jsx)("rect", {
                            x: "108",
                            y: "86",
                            width: "22",
                            height: "16",
                            rx: "3"
                        }), (0, t.jsx)("rect", {
                            x: "290",
                            y: "96",
                            width: "18",
                            height: "16",
                            rx: "3"
                        }), (0, t.jsx)("path", {
                            d: "M159 70 V58 M159 58 l8 4 l-8 4",
                            fill: "none",
                            stroke: "var(--prbl-far)",
                            strokeWidth: "2.4"
                        })]
                    }), (0, t.jsx)("g", {
                        fill: "var(--prbl-lamp)",
                        className: "prbl-windows",
                        children: e.flatMap(([e, r, l], s) => Array.from({
                            length: 6
                        }, (a, i) => (5 * s + 3 * i) % 4 != 0 ? (0, t.jsx)("rect", {
                            x: e + 6 + i % 2 * (l / 2 - 2),
                            y: r + 14 + 22 * Math.floor(i / 2),
                            width: "7",
                            height: "9",
                            rx: "1"
                        }, `${s}-${i}`) : null))
                    })]
                })
            }

            function y() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 400 300",
                    preserveAspectRatio: "xMidYMax slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, t.jsx)("path", {
                        d: "M0 214 Q120 236 230 210 T400 222",
                        fill: "none",
                        ...s,
                        strokeWidth: 2,
                        opacity: "0.7"
                    }), (0, t.jsx)("path", {
                        d: "M0 196 Q140 216 250 190 T400 200",
                        fill: "none",
                        ...s,
                        strokeWidth: 2,
                        opacity: "0.7"
                    }), [40, 96, 152, 208, 264, 320].map((e, r) => (0, t.jsx)("circle", {
                        cx: e,
                        cy: r % 2 ? 222 : 205,
                        r: "2.4",
                        fill: "var(--prbl-rain)"
                    }, e)), (0, t.jsx)("path", {
                        d: "M318 300 V170 M302 182 H336",
                        fill: "none",
                        ...s,
                        strokeWidth: 5
                    }), (0, t.jsx)("path", {
                        d: "M-10 300 V236 L60 214 L130 236 V300 Z",
                        fill: "var(--prbl-mid)",
                        ...s,
                        strokeWidth: 3
                    }), (0, t.jsx)("path", {
                        d: "M-14 238 L60 210 L134 238",
                        fill: "none",
                        ...s,
                        strokeWidth: 5
                    }), [0, 12, 24, 36, 48, 60, 72, 84, 96, 108, 120].map(e => (0, t.jsx)("path", {
                        d: `M${e} ${236-(e<60?.36*e:(120-e)*.36)} V${242-(e<60?.36*e:(120-e)*.36)}`,
                        ...s,
                        strokeWidth: 1.5,
                        opacity: "0.5"
                    }, e)), (0, t.jsx)("rect", {
                        x: "40",
                        y: "250",
                        width: "22",
                        height: "26",
                        rx: "2",
                        fill: "var(--prbl-lamp)",
                        ...s,
                        strokeWidth: 2.4
                    }), (0, t.jsx)("path", {
                        d: "M190 300 V248 L250 226 L310 248 V300 Z",
                        fill: "var(--prbl-mid)",
                        ...s,
                        strokeWidth: 3
                    }), (0, t.jsx)("rect", {
                        x: "236",
                        y: "256",
                        width: "26",
                        height: "20",
                        rx: "2",
                        fill: "var(--prbl-lamp)",
                        ...s,
                        strokeWidth: 2.4
                    }), (0, t.jsx)("path", {
                        d: "M249 256 V276 M236 266 H262",
                        ...s,
                        strokeWidth: 2
                    }), (0, t.jsx)("rect", {
                        x: "150",
                        y: "226",
                        width: "26",
                        height: "22",
                        rx: "4",
                        fill: "var(--prbl-mid)",
                        ...s,
                        strokeWidth: 2.6
                    })]
                })
            }

            function g({
                sill: e = !0
            }) {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 400 300",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, t.jsx)("path", {
                        d: "M0 0 H400 V300 H0 Z M34 26 V262 H366 V26 Z",
                        fill: "var(--prbl-wall)",
                        fillRule: "evenodd"
                    }), (0, t.jsx)("rect", {
                        x: "34",
                        y: "26",
                        width: "332",
                        height: "236",
                        fill: "none",
                        stroke: "var(--prbl-wood)",
                        strokeWidth: "12"
                    }), (0, t.jsx)("rect", {
                        x: "34",
                        y: "26",
                        width: "332",
                        height: "236",
                        fill: "none",
                        ...s,
                        strokeWidth: 3
                    }), (0, t.jsx)("path", {
                        d: "M200 26 V262",
                        stroke: "var(--prbl-wood)",
                        strokeWidth: "9"
                    }), (0, t.jsxs)("g", {
                        fill: "none",
                        stroke: "var(--prbl-line)",
                        strokeWidth: "2.6",
                        opacity: "0.85",
                        children: [
                            [90, 145, 255, 310].map(e => (0, t.jsx)("path", {
                                d: `M${e} 32 V256`
                            }, e)), [90, 255].map(e => (0, t.jsx)("path", {
                                d: `M${e} 144 q27 -30 55 0 q-27 30 -55 0 M${e} 92 q27 -18 55 0 M${e} 196 q27 18 55 0`
                            }, `s${e}`))
                        ]
                    }), e ? (0, t.jsxs)("g", {
                        children: [(0, t.jsx)("rect", {
                            x: "18",
                            y: "258",
                            width: "364",
                            height: "20",
                            rx: "4",
                            fill: "var(--prbl-wood)",
                            ...s,
                            strokeWidth: 3
                        }), (0, t.jsx)("path", {
                            d: "M300 258 L306 226 H338 L344 258 Z",
                            fill: "var(--prbl-coatA)",
                            ...s,
                            strokeWidth: 2.6
                        }), (0, t.jsx)("path", {
                            d: "M322 226 Q312 200 300 196 M322 226 Q324 196 334 184 M322 226 Q334 206 348 204",
                            fill: "none",
                            stroke: "var(--prbl-coatB)",
                            strokeWidth: "4",
                            strokeLinecap: "round"
                        }), (0, t.jsx)("path", {
                            d: "M70 258 L74 238 H96 L100 258 Z",
                            fill: "var(--prbl-clay)",
                            ...s,
                            strokeWidth: 2.6
                        }), (0, t.jsx)("path", {
                            d: "M78 232 q-4 -8 2 -14 M90 232 q4 -8 -2 -14",
                            fill: "none",
                            stroke: "var(--prbl-paper)",
                            strokeWidth: "2",
                            strokeLinecap: "round",
                            opacity: "0.7",
                            className: "prbl-steam-line"
                        })]
                    }) : null]
                })
            }

            function W() {
                return (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className: "prbl-glassfog"
                })
            }

            function w() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 400 300",
                    preserveAspectRatio: "xMidYMax slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, t.jsx)("rect", {
                        x: "0",
                        y: "246",
                        width: "400",
                        height: "54",
                        fill: "var(--prbl-road)"
                    }), (0, t.jsx)("path", {
                        d: "M0 250 H400",
                        ...s,
                        strokeWidth: 3
                    }), (0, t.jsx)("path", {
                        d: "M20 282 h40 M120 282 h40 M220 282 h40 M320 282 h40",
                        stroke: "var(--prbl-paper)",
                        strokeWidth: "4",
                        strokeLinecap: "round",
                        opacity: "0.6"
                    }), (0, t.jsx)("path", {
                        d: "M60 96 L340 80 L346 98 L54 114 Z",
                        fill: "var(--prbl-roof)",
                        ...s,
                        strokeWidth: 3.5
                    }), [80, 110, 140, 170, 200, 230, 260, 290, 320].map((e, r) => (0, t.jsx)("path", {
                        d: `M${e} ${95-1.6*r} L${e+1} ${111-1.6*r}`,
                        ...s,
                        strokeWidth: 1.6,
                        opacity: "0.5"
                    }, e)), (0, t.jsx)("path", {
                        d: "M78 112 V248 M322 98 V248",
                        ...s,
                        strokeWidth: 6
                    }), (0, t.jsx)("path", {
                        d: "M118 206 H282 M126 206 V232 M274 206 V232",
                        fill: "none",
                        ...s,
                        strokeWidth: 5
                    }), (0, t.jsx)("rect", {
                        x: "114",
                        y: "198",
                        width: "172",
                        height: "10",
                        rx: "3",
                        fill: "var(--prbl-wood)",
                        ...s,
                        strokeWidth: 2.6
                    }), (0, t.jsx)("path", {
                        d: "M364 248 V150",
                        ...s,
                        strokeWidth: 4
                    }), (0, t.jsx)("circle", {
                        cx: "364",
                        cy: "140",
                        r: "18",
                        fill: "var(--prbl-paper)",
                        ...s,
                        strokeWidth: 3
                    }), (0, t.jsx)("rect", {
                        x: "354",
                        y: "131",
                        width: "20",
                        height: "14",
                        rx: "3",
                        fill: "var(--prbl-accent)",
                        ...s,
                        strokeWidth: 2
                    }), (0, t.jsx)("circle", {
                        cx: "358",
                        cy: "147",
                        r: "2.4",
                        fill: "var(--prbl-line)"
                    }), (0, t.jsx)("circle", {
                        cx: "370",
                        cy: "147",
                        r: "2.4",
                        fill: "var(--prbl-line)"
                    }), (0, t.jsx)("ellipse", {
                        className: "prbl-ripple",
                        cx: "110",
                        cy: "270",
                        rx: "34",
                        ry: "5",
                        fill: "none",
                        stroke: "var(--prbl-rain)",
                        strokeWidth: "2"
                    }), (0, t.jsx)("ellipse", {
                        className: "prbl-ripple prbl-ripple-2",
                        cx: "290",
                        cy: "276",
                        rx: "30",
                        ry: "4.5",
                        fill: "none",
                        stroke: "var(--prbl-rain)",
                        strokeWidth: "2"
                    })]
                })
            }

            function N() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 520 300",
                    "aria-hidden": !0,
                    className: "block h-full w-auto",
                    children: [(0, t.jsx)("path", {
                        d: "M0 170 Q60 120 130 150 T260 140 T400 130 T520 150 V300 H0 Z",
                        fill: "var(--prbl-far)"
                    }), (0, t.jsx)("path", {
                        d: "M300 150 V108 L312 96 L318 70 L324 96 L336 108 V150 Z",
                        fill: "var(--prbl-far)"
                    }), (0, t.jsx)("path", {
                        d: "M318 70 V58 l9 4 l-9 4",
                        fill: "none",
                        stroke: "var(--prbl-far)",
                        strokeWidth: "2.4"
                    })]
                })
            }

            function Q() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 640 300",
                    "aria-hidden": !0,
                    className: "block h-full w-auto",
                    children: [(0, t.jsx)("path", {
                        d: "M0 184 Q160 172 320 182 T640 178 V196 H0 Z",
                        fill: "var(--prbl-mid)",
                        ...s,
                        strokeWidth: 2.6
                    }), [30, 120, 230, 350, 470, 560].map((e, r) => (0, t.jsxs)("g", {
                        children: [(0, t.jsx)("path", {
                            d: `M${e} 186 V${150-r%2*14}`,
                            ...s,
                            strokeWidth: 5
                        }), (0, t.jsx)("circle", {
                            cx: e,
                            cy: 136 - r % 2 * 14,
                            r: 20 + r % 3 * 4,
                            fill: "var(--prbl-coatB)",
                            ...s,
                            strokeWidth: 3
                        }), (0, t.jsx)("circle", {
                            cx: e - 12,
                            cy: 146 - r % 2 * 14,
                            r: "13",
                            fill: "var(--prbl-coatB)",
                            ...s,
                            strokeWidth: 3
                        })]
                    }, e)), [80, 290, 410].map(e => (0, t.jsxs)("g", {
                        children: [(0, t.jsx)("path", {
                            d: `M${e} 184 V120 M${e-8} 120 H${e+8}`,
                            ...s,
                            strokeWidth: 3.5
                        }), (0, t.jsx)("circle", {
                            cx: e,
                            cy: "114",
                            r: "6",
                            fill: "var(--prbl-lamp)",
                            ...s,
                            strokeWidth: 2.4
                        })]
                    }, e))]
                })
            }

            function $({
                children: e
            }) {
                return (0, t.jsxs)("div", {
                    className: "prbl-near",
                    children: [(0, t.jsxs)("svg", {
                        viewBox: "0 0 800 300",
                        "aria-hidden": !0,
                        className: "block h-full w-auto",
                        children: [(0, t.jsx)("g", {
                            fill: "none",
                            stroke: "var(--prbl-paper)",
                            strokeWidth: "2.4",
                            strokeLinecap: "round",
                            opacity: "0.5",
                            children: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(e => (0, t.jsx)("path", {
                                d: `M${80*e+e%2*30} ${226+e%3*22} q10 -6 20 0 t20 0`
                            }, e))
                        }), (0, t.jsx)("path", {
                            d: "M520 300 V200 H800 V300 Z",
                            fill: "var(--prbl-stone)",
                            ...s,
                            strokeWidth: 3
                        }), (0, t.jsx)("path", {
                            d: "M500 300 V222 H520 M480 300 V244 H520 M460 300 V266 H520",
                            fill: "none",
                            ...s,
                            strokeWidth: 2.6
                        }), (0, t.jsxs)("g", {
                            fill: "none",
                            stroke: "var(--prbl-coatB)",
                            strokeWidth: "4",
                            strokeLinecap: "round",
                            children: [(0, t.jsx)("path", {
                                d: "M20 300 Q16 250 4 226 M34 300 Q34 240 44 214 M48 300 Q54 262 70 246"
                            }), (0, t.jsx)("path", {
                                d: "M520 300 Q512 262 500 246 M536 300 Q540 250 552 232"
                            })]
                        }), (0, t.jsx)("circle", {
                            cx: "44",
                            cy: "214",
                            r: "4",
                            fill: "var(--prbl-accent)"
                        })]
                    }), e]
                })
            }

            function L() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 400 300",
                    preserveAspectRatio: "xMidYMax slice",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, t.jsx)("path", {
                        d: "M-10 0 H410 V46 Q200 60 -10 46 Z",
                        fill: "var(--prbl-roof)",
                        ...s,
                        strokeWidth: 3.5
                    }), Array.from({
                        length: 21
                    }, (e, r) => (0, t.jsx)("path", {
                        d: `M${20*r} 0 V${48+Math.round(6*Math.sin(r/20*Math.PI))}`,
                        ...s,
                        strokeWidth: 1.6,
                        opacity: "0.45"
                    }, r)), (0, t.jsx)("path", {
                        d: "M-10 46 Q200 60 410 46",
                        fill: "none",
                        ...s,
                        strokeWidth: 4
                    }), (0, t.jsx)("rect", {
                        x: "-6",
                        y: "232",
                        width: "412",
                        height: "74",
                        fill: "var(--prbl-wood)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M-6 250 H406",
                        ...s,
                        strokeWidth: 2,
                        opacity: "0.5"
                    }), (0, t.jsx)("path", {
                        d: "M40 270 h60 M150 284 h80 M280 268 h70",
                        ...s,
                        strokeWidth: 2,
                        opacity: "0.3"
                    })]
                })
            }

            function V() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 120 100",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        d: "M30 34 Q30 14 56 14 Q82 14 82 34",
                        fill: "none",
                        ...s,
                        strokeWidth: 5
                    }), (0, t.jsx)("path", {
                        d: "M22 40 Q22 30 34 30 H78 Q90 30 90 40 L94 82 Q94 92 82 92 H34 Q20 92 20 82 Z",
                        fill: "var(--prbl-steel)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M90 50 L114 34 L118 40 L94 66",
                        fill: "var(--prbl-steel)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M30 46 Q32 72 40 82",
                        fill: "none",
                        stroke: "var(--prbl-paper)",
                        strokeWidth: "4",
                        strokeLinecap: "round",
                        opacity: "0.5"
                    }), (0, t.jsx)("ellipse", {
                        cx: "56",
                        cy: "30",
                        rx: "18",
                        ry: "5",
                        fill: "var(--prbl-steel)",
                        ...s,
                        strokeWidth: 3
                    }), (0, t.jsx)("circle", {
                        cx: "56",
                        cy: "23",
                        r: "4",
                        fill: "var(--prbl-line)"
                    })]
                })
            }

            function A({
                children: e
            }) {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        d: "M16 22 L26 88 Q50 98 74 88 L84 22 Z",
                        fill: "var(--prbl-clay)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("g", {
                        className: "prbl-chai-level",
                        children: (0, t.jsx)("path", {
                            d: "M19 30 L26 88 Q50 98 74 88 L81 30 Z",
                            fill: "var(--prbl-chai)"
                        })
                    }), (0, t.jsx)("path", {
                        d: "M16 22 L26 88 Q50 98 74 88 L84 22",
                        fill: "none",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("ellipse", {
                        cx: "50",
                        cy: "22",
                        rx: "34",
                        ry: "7",
                        fill: "none",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M30 50 h40 M33 66 h34",
                        stroke: "var(--prbl-line)",
                        strokeWidth: "2",
                        strokeDasharray: "3 5",
                        opacity: "0.4"
                    }), e]
                })
            }

            function C() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 100 80",
                    "aria-hidden": !0,
                    className: "prbl-steam block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        d: "M36 76 Q24 58 36 44 Q48 30 36 12",
                        pathLength: 1
                    }), (0, t.jsx)("path", {
                        d: "M52 76 Q40 56 52 40 Q64 26 52 6",
                        pathLength: 1
                    }), (0, t.jsx)("path", {
                        d: "M68 76 Q56 60 68 46 Q80 32 68 16",
                        pathLength: 1
                    })]
                })
            }

            function R() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 220 110",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        d: "M30 96 Q4 96 6 74 Q8 54 32 56 Q34 28 64 28 Q80 4 112 12 Q140 0 156 28 Q190 22 196 54 Q218 58 214 80 Q210 98 186 96 Z",
                        fill: "var(--prbl-cloud)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M44 74 Q60 64 78 72 M120 60 Q138 50 156 60",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.4,
                        opacity: "0.35"
                    })]
                })
            }
            let Z = ["var(--prbl-coatA)", "var(--prbl-accent)", "var(--prbl-lamp)", "var(--prbl-coatB)", "var(--prbl-rain)", "var(--prbl-violet)"];

            function B() {
                return (0, t.jsx)("svg", {
                    viewBox: "0 0 400 210",
                    "aria-hidden": !0,
                    className: "prbl-rainbow block size-full overflow-visible",
                    children: Z.map((e, r) => (0, t.jsx)("path", {
                        d: `M${30+12*r} 206 A${170-12*r} ${170-12*r} 0 0 1 ${370-12*r} 206`,
                        pathLength: 1,
                        fill: "none",
                        stroke: e,
                        strokeWidth: "13",
                        style: {
                            animationDelay: `${(.25+.16*r).toFixed(2)}s`
                        }
                    }, r))
                })
            }

            function S() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, t.jsx)("g", {
                        className: "prbl-sun-rays",
                        stroke: "var(--prbl-lamp)",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        children: Array.from({
                            length: 10
                        }, (e, r) => {
                            let l = r / 10 * Math.PI * 2;
                            return (0, t.jsx)("path", {
                                d: `M${(50+32*Math.cos(l)).toFixed(2)} ${(50+32*Math.sin(l)).toFixed(2)} L${(50+44*Math.cos(l)).toFixed(2)} ${(50+44*Math.sin(l)).toFixed(2)}`
                            }, r)
                        })
                    }), (0, t.jsx)("circle", {
                        cx: "50",
                        cy: "50",
                        r: "24",
                        fill: "var(--prbl-lamp)",
                        ...s,
                        strokeWidth: 3.5
                    }), (0, t.jsx)("path", {
                        d: "M41 52 Q50 60 59 52",
                        fill: "none",
                        ...s,
                        strokeWidth: 2.6
                    }), (0, t.jsx)("circle", {
                        cx: "42",
                        cy: "45",
                        r: "2.2",
                        fill: "var(--prbl-line)"
                    }), (0, t.jsx)("circle", {
                        cx: "58",
                        cy: "45",
                        r: "2.2",
                        fill: "var(--prbl-line)"
                    })]
                })
            }

            function P() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 120 110",
                    "aria-hidden": !0,
                    className: "prbl-drawn block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        pathLength: 1,
                        d: "M60 98 C20 72 8 50 14 32 C20 14 46 10 60 32 C74 10 100 14 106 32 C112 50 100 72 60 98 Z"
                    }), (0, t.jsx)("path", {
                        pathLength: 1,
                        d: "M36 44 L52 60 M84 40 L68 62",
                        className: "prbl-drawn-late"
                    })]
                })
            }

            function F() {
                return (0, t.jsxs)("svg", {
                    viewBox: "0 0 100 100",
                    "aria-hidden": !0,
                    className: "prbl-drawn block size-full overflow-visible",
                    children: [(0, t.jsx)("path", {
                        pathLength: 1,
                        d: "M10 48 Q50 2 90 48 Q80 40 70 48 Q60 40 50 48 Q40 40 30 48 Q20 40 10 48 Z"
                    }), (0, t.jsx)("path", {
                        pathLength: 1,
                        d: "M50 48 V84 Q50 92 43 92 Q37 92 37 86",
                        className: "prbl-drawn-late"
                    })]
                })
            }

            function H() {
                return (0, t.jsx)("span", {
                    "aria-hidden": !0,
                    className: "prbl-hearts",
                    children: Array.from({
                        length: 9
                    }, (e, r) => (0, t.jsx)("i", {
                        style: {
                            left: `${6+41*r%88}%`,
                            animationDelay: `${(.6+.37*r%2).toFixed(2)}s`,
                            animationDuration: `${(3.6+r%3*.8).toFixed(1)}s`,
                            "--prbl-tone": r % 3 == 0 ? "var(--prbl-coatA)" : r % 3 == 1 ? "var(--prbl-accent)" : "var(--prbl-coatB)"
                        }
                    }, r))
                })
            }
        }
    }
]);