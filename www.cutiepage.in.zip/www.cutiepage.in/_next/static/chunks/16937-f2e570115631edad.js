(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [16937], {
        328: (e, t, r) => {
            "use strict";
            r.d(t, {
                FE: () => w,
                Fw: () => b,
                HU: () => o,
                HY: () => s,
                MJ: () => p,
                MR: () => f,
                NA: () => a,
                OI: () => E,
                Ox: () => u,
                RC: () => i,
                Ru: () => v,
                U_: () => d,
                Uw: () => g,
                jG: () => c,
                lR: () => n,
                lh: () => m,
                xL: () => k,
                zh: () => y,
                zq: () => h
            });
            class n extends Error {
                constructor(e, t, r) {
                    super(e), this.__isAuthError = !0, this.name = "AuthError", this.status = t, this.code = r
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status,
                        code: this.code
                    }
                }
            }

            function s(e) {
                return "object" == typeof e && null !== e && "__isAuthError" in e
            }
            class i extends n {
                constructor(e, t, r) {
                    super(e, t, r), this.name = "AuthApiError", this.status = t, this.code = r
                }
            }

            function a(e) {
                return s(e) && "AuthApiError" === e.name
            }
            class o extends n {
                constructor(e, t) {
                    super(e), this.name = "AuthUnknownError", this.originalError = t
                }
            }
            class l extends n {
                constructor(e, t, r, n) {
                    super(e, r, n), this.name = t, this.status = r
                }
            }
            class c extends l {
                constructor() {
                    super("Auth session missing!", "AuthSessionMissingError", 400, void 0)
                }
            }

            function h(e) {
                return s(e) && "AuthSessionMissingError" === e.name
            }
            class u extends l {
                constructor() {
                    super("Auth session or user missing", "AuthInvalidTokenResponseError", 500, void 0)
                }
            }
            class d extends l {
                constructor(e) {
                    super(e, "AuthInvalidCredentialsError", 400, void 0)
                }
            }
            class f extends l {
                constructor(e, t = null) {
                    super(e, "AuthImplicitGrantRedirectError", 500, void 0), this.details = null, this.details = t
                }
                toJSON() {
                    return Object.assign(Object.assign({}, super.toJSON()), {
                        details: this.details
                    })
                }
            }

            function p(e) {
                return s(e) && "AuthImplicitGrantRedirectError" === e.name
            }
            class g extends l {
                constructor(e, t = null) {
                    super(e, "AuthPKCEGrantCodeExchangeError", 500, void 0), this.details = null, this.details = t
                }
                toJSON() {
                    return Object.assign(Object.assign({}, super.toJSON()), {
                        details: this.details
                    })
                }
            }
            class m extends l {
                constructor() {
                    super("PKCE code verifier not found in storage. This can happen if the auth flow was initiated in a different browser or device, or if the storage was cleared. For SSR frameworks (Next.js, SvelteKit, etc.), use @supabase/ssr on both the server and client to store the code verifier in cookies.", "AuthPKCECodeVerifierMissingError", 400, "pkce_code_verifier_not_found")
                }
            }
            class y extends l {
                constructor(e, t) {
                    super(e, "AuthRetryableFetchError", t, void 0)
                }
            }

            function b(e) {
                return s(e) && "AuthRetryableFetchError" === e.name
            }
            class w extends l {
                constructor(e = "Refresh result discarded: session state changed mid-flight (e.g., concurrent signOut)") {
                    super(e, "AuthRefreshDiscardedError", 409, void 0)
                }
            }

            function v(e) {
                return s(e) && "AuthRefreshDiscardedError" === e.name
            }
            class E extends l {
                constructor(e, t, r) {
                    super(e, "AuthWeakPasswordError", t, "weak_password"), this.reasons = r
                }
                toJSON() {
                    return Object.assign(Object.assign({}, super.toJSON()), {
                        reasons: this.reasons
                    })
                }
            }
            class k extends l {
                constructor(e) {
                    super(e, "AuthInvalidJwtError", 400, "invalid_jwt")
                }
            }
        },
        8882: (e, t, r) => {
            "use strict";
            r.d(t, {
                A: () => l
            });
            var n = r(46715),
                s = r(86209),
                i = r(43092);
            let a = ["global", "local", "others"];
            var o = r(328);
            class l {
                constructor({
                    url: e = "",
                    headers: t = {},
                    fetch: r,
                    experimental: n
                }) {
                    this.url = e, this.headers = t, this.fetch = (0, i.lA)(r), this.experimental = null != n ? n : {}, this.mfa = {
                        listFactors: this._listFactors.bind(this),
                        deleteFactor: this._deleteFactor.bind(this)
                    }, this.oauth = {
                        listClients: this._listOAuthClients.bind(this),
                        createClient: this._createOAuthClient.bind(this),
                        getClient: this._getOAuthClient.bind(this),
                        updateClient: this._updateOAuthClient.bind(this),
                        deleteClient: this._deleteOAuthClient.bind(this),
                        regenerateClientSecret: this._regenerateOAuthClientSecret.bind(this)
                    }, this.customProviders = {
                        listProviders: this._listCustomProviders.bind(this),
                        createProvider: this._createCustomProvider.bind(this),
                        getProvider: this._getCustomProvider.bind(this),
                        updateProvider: this._updateCustomProvider.bind(this),
                        deleteProvider: this._deleteCustomProvider.bind(this)
                    }, this.passkey = {
                        listPasskeys: this._adminListPasskeys.bind(this),
                        deletePasskey: this._adminDeletePasskey.bind(this)
                    }
                }
                async signOut(e, t = a[0]) {
                    if (0 > a.indexOf(t)) throw Error(`@supabase/auth-js: Parameter scope must be one of ${a.join(", ")}`);
                    try {
                        return await (0, s.vE)(this.fetch, "POST", `${this.url}/logout?scope=${t}`, {
                            headers: this.headers,
                            jwt: e,
                            noResolveJson: !0
                        }), {
                            data: null,
                            error: null
                        }
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async inviteUserByEmail(e, t = {}) {
                    try {
                        return await (0, s.vE)(this.fetch, "POST", `${this.url}/invite`, {
                            body: {
                                email: e,
                                data: t.data
                            },
                            headers: this.headers,
                            redirectTo: t.redirectTo,
                            xform: s.Cl
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async generateLink(e) {
                    try {
                        let {
                            options: t
                        } = e, r = (0, n.Tt)(e, ["options"]), i = Object.assign(Object.assign({}, r), t);
                        return "newEmail" in r && (i.new_email = null == r ? void 0 : r.newEmail, delete i.newEmail), await (0, s.vE)(this.fetch, "POST", `${this.url}/admin/generate_link`, {
                            body: i,
                            headers: this.headers,
                            xform: s.EY,
                            redirectTo: null == t ? void 0 : t.redirectTo
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                properties: null,
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async createUser(e) {
                    try {
                        return await (0, s.vE)(this.fetch, "POST", `${this.url}/admin/users`, {
                            body: e,
                            headers: this.headers,
                            xform: s.Cl
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async listUsers(e) {
                    var t, r, n, i, a, l, c;
                    try {
                        let o = {
                                nextPage: null,
                                lastPage: 0,
                                total: 0
                            },
                            h = await (0, s.vE)(this.fetch, "GET", `${this.url}/admin/users`, {
                                headers: this.headers,
                                noResolveJson: !0,
                                query: {
                                    page: null != (r = null == (t = null == e ? void 0 : e.page) ? void 0 : t.toString()) ? r : "",
                                    per_page: null != (i = null == (n = null == e ? void 0 : e.perPage) ? void 0 : n.toString()) ? i : ""
                                },
                                xform: s.w4
                            });
                        if (h.error) throw h.error;
                        let u = await h.json(),
                            d = null != (a = h.headers.get("x-total-count")) ? a : 0,
                            f = null != (c = null == (l = h.headers.get("link")) ? void 0 : l.split(",")) ? c : [];
                        return f.length > 0 && (f.forEach(e => {
                            let t = parseInt(e.split(";")[0].split("=")[1].substring(0, 1)),
                                r = JSON.parse(e.split(";")[1].split("=")[1]);
                            o[`${r}Page`] = t
                        }), o.total = parseInt(d)), {
                            data: Object.assign(Object.assign({}, u), o),
                            error: null
                        }
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                users: []
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async getUserById(e) {
                    (0, i.W0)(e);
                    try {
                        return await (0, s.vE)(this.fetch, "GET", `${this.url}/admin/users/${e}`, {
                            headers: this.headers,
                            xform: s.Cl
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async updateUserById(e, t) {
                    (0, i.W0)(e);
                    try {
                        return await (0, s.vE)(this.fetch, "PUT", `${this.url}/admin/users/${e}`, {
                            body: t,
                            headers: this.headers,
                            xform: s.Cl
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async deleteUser(e, t = !1) {
                    (0, i.W0)(e);
                    try {
                        return await (0, s.vE)(this.fetch, "DELETE", `${this.url}/admin/users/${e}`, {
                            headers: this.headers,
                            body: {
                                should_soft_delete: t
                            },
                            xform: s.Cl
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async _listFactors(e) {
                    (0, i.W0)(e.userId);
                    try {
                        let {
                            data: t,
                            error: r
                        } = await (0, s.vE)(this.fetch, "GET", `${this.url}/admin/users/${e.userId}/factors`, {
                            headers: this.headers,
                            xform: e => ({
                                data: {
                                    factors: e
                                },
                                error: null
                            })
                        });
                        return {
                            data: t,
                            error: r
                        }
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _deleteFactor(e) {
                    (0, i.W0)(e.userId), (0, i.W0)(e.id);
                    try {
                        return {
                            data: await (0, s.vE)(this.fetch, "DELETE", `${this.url}/admin/users/${e.userId}/factors/${e.id}`, {
                                headers: this.headers
                            }),
                            error: null
                        }
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _listOAuthClients(e) {
                    var t, r, n, i, a, l, c;
                    try {
                        let o = {
                                nextPage: null,
                                lastPage: 0,
                                total: 0
                            },
                            h = await (0, s.vE)(this.fetch, "GET", `${this.url}/admin/oauth/clients`, {
                                headers: this.headers,
                                noResolveJson: !0,
                                query: {
                                    page: null != (r = null == (t = null == e ? void 0 : e.page) ? void 0 : t.toString()) ? r : "",
                                    per_page: null != (i = null == (n = null == e ? void 0 : e.perPage) ? void 0 : n.toString()) ? i : ""
                                },
                                xform: s.w4
                            });
                        if (h.error) throw h.error;
                        let u = await h.json(),
                            d = null != (a = h.headers.get("x-total-count")) ? a : 0,
                            f = null != (c = null == (l = h.headers.get("link")) ? void 0 : l.split(",")) ? c : [];
                        return f.length > 0 && (f.forEach(e => {
                            let t = parseInt(e.split(";")[0].split("=")[1].substring(0, 1)),
                                r = JSON.parse(e.split(";")[1].split("=")[1]);
                            o[`${r}Page`] = t
                        }), o.total = parseInt(d)), {
                            data: Object.assign(Object.assign({}, u), o),
                            error: null
                        }
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                clients: []
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async _createOAuthClient(e) {
                    try {
                        return await (0, s.vE)(this.fetch, "POST", `${this.url}/admin/oauth/clients`, {
                            body: e,
                            headers: this.headers,
                            xform: e => ({
                                data: e,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _getOAuthClient(e) {
                    try {
                        return await (0, s.vE)(this.fetch, "GET", `${this.url}/admin/oauth/clients/${e}`, {
                            headers: this.headers,
                            xform: e => ({
                                data: e,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _updateOAuthClient(e, t) {
                    try {
                        return await (0, s.vE)(this.fetch, "PUT", `${this.url}/admin/oauth/clients/${e}`, {
                            body: t,
                            headers: this.headers,
                            xform: e => ({
                                data: e,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _deleteOAuthClient(e) {
                    try {
                        return await (0, s.vE)(this.fetch, "DELETE", `${this.url}/admin/oauth/clients/${e}`, {
                            headers: this.headers,
                            noResolveJson: !0
                        }), {
                            data: null,
                            error: null
                        }
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _regenerateOAuthClientSecret(e) {
                    try {
                        return await (0, s.vE)(this.fetch, "POST", `${this.url}/admin/oauth/clients/${e}/regenerate_secret`, {
                            headers: this.headers,
                            xform: e => ({
                                data: e,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _listCustomProviders(e) {
                    try {
                        let t = {};
                        return (null == e ? void 0 : e.type) && (t.type = e.type), await (0, s.vE)(this.fetch, "GET", `${this.url}/admin/custom-providers`, {
                            headers: this.headers,
                            query: t,
                            xform: e => {
                                var t;
                                return {
                                    data: {
                                        providers: null != (t = null == e ? void 0 : e.providers) ? t : []
                                    },
                                    error: null
                                }
                            }
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: {
                                providers: []
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async _createCustomProvider(e) {
                    try {
                        return await (0, s.vE)(this.fetch, "POST", `${this.url}/admin/custom-providers`, {
                            body: e,
                            headers: this.headers,
                            xform: e => ({
                                data: e,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _getCustomProvider(e) {
                    try {
                        return await (0, s.vE)(this.fetch, "GET", `${this.url}/admin/custom-providers/${e}`, {
                            headers: this.headers,
                            xform: e => ({
                                data: e,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _updateCustomProvider(e, t) {
                    try {
                        return await (0, s.vE)(this.fetch, "PUT", `${this.url}/admin/custom-providers/${e}`, {
                            body: t,
                            headers: this.headers,
                            xform: e => ({
                                data: e,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _deleteCustomProvider(e) {
                    try {
                        return await (0, s.vE)(this.fetch, "DELETE", `${this.url}/admin/custom-providers/${e}`, {
                            headers: this.headers,
                            noResolveJson: !0
                        }), {
                            data: null,
                            error: null
                        }
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _adminListPasskeys(e) {
                    (0, i.aA)(this.experimental), (0, i.W0)(e.userId);
                    try {
                        return await (0, s.vE)(this.fetch, "GET", `${this.url}/admin/users/${e.userId}/passkeys`, {
                            headers: this.headers,
                            xform: e => ({
                                data: e,
                                error: null
                            })
                        })
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _adminDeletePasskey(e) {
                    (0, i.aA)(this.experimental), (0, i.W0)(e.userId), (0, i.W0)(e.passkeyId);
                    try {
                        return await (0, s.vE)(this.fetch, "DELETE", `${this.url}/admin/users/${e.userId}/passkeys/${e.passkeyId}`, {
                            headers: this.headers,
                            noResolveJson: !0
                        }), {
                            data: null,
                            error: null
                        }
                    } catch (e) {
                        if ((0, o.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
            }
        },
        8919: e => {
            var t = {
                    675: function(e, t) {
                        "use strict";
                        t.byteLength = function(e) {
                            var t = l(e),
                                r = t[0],
                                n = t[1];
                            return (r + n) * 3 / 4 - n
                        }, t.toByteArray = function(e) {
                            var t, r, i = l(e),
                                a = i[0],
                                o = i[1],
                                c = new s((a + o) * 3 / 4 - o),
                                h = 0,
                                u = o > 0 ? a - 4 : a;
                            for (r = 0; r < u; r += 4) t = n[e.charCodeAt(r)] << 18 | n[e.charCodeAt(r + 1)] << 12 | n[e.charCodeAt(r + 2)] << 6 | n[e.charCodeAt(r + 3)], c[h++] = t >> 16 & 255, c[h++] = t >> 8 & 255, c[h++] = 255 & t;
                            return 2 === o && (t = n[e.charCodeAt(r)] << 2 | n[e.charCodeAt(r + 1)] >> 4, c[h++] = 255 & t), 1 === o && (t = n[e.charCodeAt(r)] << 10 | n[e.charCodeAt(r + 1)] << 4 | n[e.charCodeAt(r + 2)] >> 2, c[h++] = t >> 8 & 255, c[h++] = 255 & t), c
                        }, t.fromByteArray = function(e) {
                            for (var t, n = e.length, s = n % 3, i = [], a = 0, o = n - s; a < o; a += 16383) i.push(function(e, t, n) {
                                for (var s, i = [], a = t; a < n; a += 3) s = (e[a] << 16 & 0xff0000) + (e[a + 1] << 8 & 65280) + (255 & e[a + 2]), i.push(r[s >> 18 & 63] + r[s >> 12 & 63] + r[s >> 6 & 63] + r[63 & s]);
                                return i.join("")
                            }(e, a, a + 16383 > o ? o : a + 16383));
                            return 1 === s ? i.push(r[(t = e[n - 1]) >> 2] + r[t << 4 & 63] + "==") : 2 === s && i.push(r[(t = (e[n - 2] << 8) + e[n - 1]) >> 10] + r[t >> 4 & 63] + r[t << 2 & 63] + "="), i.join("")
                        };
                        for (var r = [], n = [], s = "u" > typeof Uint8Array ? Uint8Array : Array, i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0, o = i.length; a < o; ++a) r[a] = i[a], n[i.charCodeAt(a)] = a;

                        function l(e) {
                            var t = e.length;
                            if (t % 4 > 0) throw Error("Invalid string. Length must be a multiple of 4");
                            var r = e.indexOf("="); - 1 === r && (r = t);
                            var n = r === t ? 0 : 4 - r % 4;
                            return [r, n]
                        }
                        n[45] = 62, n[95] = 63
                    },
                    72: function(e, t, r) {
                        "use strict";
                        var n = r(675),
                            s = r(783),
                            i = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;

                        function a(e) {
                            if (e > 0x7fffffff) throw RangeError('The value "' + e + '" is invalid for option "size"');
                            var t = new Uint8Array(e);
                            return Object.setPrototypeOf(t, o.prototype), t
                        }

                        function o(e, t, r) {
                            if ("number" == typeof e) {
                                if ("string" == typeof t) throw TypeError('The "string" argument must be of type string. Received type number');
                                return h(e)
                            }
                            return l(e, t, r)
                        }

                        function l(e, t, r) {
                            if ("string" == typeof e) {
                                var n = e,
                                    s = t;
                                if (("string" != typeof s || "" === s) && (s = "utf8"), !o.isEncoding(s)) throw TypeError("Unknown encoding: " + s);
                                var i = 0 | f(n, s),
                                    l = a(i),
                                    c = l.write(n, s);
                                return c !== i && (l = l.slice(0, c)), l
                            }
                            if (ArrayBuffer.isView(e)) return u(e);
                            if (null == e) throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e);
                            if (R(e, ArrayBuffer) || e && R(e.buffer, ArrayBuffer) || "u" > typeof SharedArrayBuffer && (R(e, SharedArrayBuffer) || e && R(e.buffer, SharedArrayBuffer))) return function(e, t, r) {
                                var n;
                                if (t < 0 || e.byteLength < t) throw RangeError('"offset" is outside of buffer bounds');
                                if (e.byteLength < t + (r || 0)) throw RangeError('"length" is outside of buffer bounds');
                                return Object.setPrototypeOf(n = void 0 === t && void 0 === r ? new Uint8Array(e) : void 0 === r ? new Uint8Array(e, t) : new Uint8Array(e, t, r), o.prototype), n
                            }(e, t, r);
                            if ("number" == typeof e) throw TypeError('The "value" argument must not be of type number. Received type number');
                            var h = e.valueOf && e.valueOf();
                            if (null != h && h !== e) return o.from(h, t, r);
                            var p = function(e) {
                                if (o.isBuffer(e)) {
                                    var t = 0 | d(e.length),
                                        r = a(t);
                                    return 0 === r.length || e.copy(r, 0, 0, t), r
                                }
                                return void 0 !== e.length ? "number" != typeof e.length || function(e) {
                                    return e != e
                                }(e.length) ? a(0) : u(e) : "Buffer" === e.type && Array.isArray(e.data) ? u(e.data) : void 0
                            }(e);
                            if (p) return p;
                            if ("u" > typeof Symbol && null != Symbol.toPrimitive && "function" == typeof e[Symbol.toPrimitive]) return o.from(e[Symbol.toPrimitive]("string"), t, r);
                            throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e)
                        }

                        function c(e) {
                            if ("number" != typeof e) throw TypeError('"size" argument must be of type number');
                            if (e < 0) throw RangeError('The value "' + e + '" is invalid for option "size"')
                        }

                        function h(e) {
                            return c(e), a(e < 0 ? 0 : 0 | d(e))
                        }

                        function u(e) {
                            for (var t = e.length < 0 ? 0 : 0 | d(e.length), r = a(t), n = 0; n < t; n += 1) r[n] = 255 & e[n];
                            return r
                        }
                        t.Buffer = o, t.SlowBuffer = function(e) {
                            return +e != e && (e = 0), o.alloc(+e)
                        }, t.INSPECT_MAX_BYTES = 50, t.kMaxLength = 0x7fffffff, o.TYPED_ARRAY_SUPPORT = function() {
                            try {
                                var e = new Uint8Array(1),
                                    t = {
                                        foo: function() {
                                            return 42
                                        }
                                    };
                                return Object.setPrototypeOf(t, Uint8Array.prototype), Object.setPrototypeOf(e, t), 42 === e.foo()
                            } catch (e) {
                                return !1
                            }
                        }(), !o.TYPED_ARRAY_SUPPORT && "u" > typeof console && "function" == typeof console.error && console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(o.prototype, "parent", {
                            enumerable: !0,
                            get: function() {
                                if (o.isBuffer(this)) return this.buffer
                            }
                        }), Object.defineProperty(o.prototype, "offset", {
                            enumerable: !0,
                            get: function() {
                                if (o.isBuffer(this)) return this.byteOffset
                            }
                        }), o.poolSize = 8192, o.from = function(e, t, r) {
                            return l(e, t, r)
                        }, Object.setPrototypeOf(o.prototype, Uint8Array.prototype), Object.setPrototypeOf(o, Uint8Array), o.alloc = function(e, t, r) {
                            return (c(e), e <= 0) ? a(e) : void 0 !== t ? "string" == typeof r ? a(e).fill(t, r) : a(e).fill(t) : a(e)
                        }, o.allocUnsafe = function(e) {
                            return h(e)
                        }, o.allocUnsafeSlow = function(e) {
                            return h(e)
                        };

                        function d(e) {
                            if (e >= 0x7fffffff) throw RangeError("Attempt to allocate Buffer larger than maximum size: 0x7fffffff bytes");
                            return 0 | e
                        }

                        function f(e, t) {
                            if (o.isBuffer(e)) return e.length;
                            if (ArrayBuffer.isView(e) || R(e, ArrayBuffer)) return e.byteLength;
                            if ("string" != typeof e) throw TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof e);
                            var r = e.length,
                                n = arguments.length > 2 && !0 === arguments[2];
                            if (!n && 0 === r) return 0;
                            for (var s = !1;;) switch (t) {
                                case "ascii":
                                case "latin1":
                                case "binary":
                                    return r;
                                case "utf8":
                                case "utf-8":
                                    return T(e).length;
                                case "ucs2":
                                case "ucs-2":
                                case "utf16le":
                                case "utf-16le":
                                    return 2 * r;
                                case "hex":
                                    return r >>> 1;
                                case "base64":
                                    return C(e).length;
                                default:
                                    if (s) return n ? -1 : T(e).length;
                                    t = ("" + t).toLowerCase(), s = !0
                            }
                        }

                        function p(e, t, r) {
                            var s, i, a, o = !1;
                            if ((void 0 === t || t < 0) && (t = 0), t > this.length || ((void 0 === r || r > this.length) && (r = this.length), r <= 0 || (r >>>= 0) <= (t >>>= 0))) return "";
                            for (e || (e = "utf8");;) switch (e) {
                                case "hex":
                                    return function(e, t, r) {
                                        var n = e.length;
                                        (!t || t < 0) && (t = 0), (!r || r < 0 || r > n) && (r = n);
                                        for (var s = "", i = t; i < r; ++i) s += P[e[i]];
                                        return s
                                    }(this, t, r);
                                case "utf8":
                                case "utf-8":
                                    return b(this, t, r);
                                case "ascii":
                                    return function(e, t, r) {
                                        var n = "";
                                        r = Math.min(e.length, r);
                                        for (var s = t; s < r; ++s) n += String.fromCharCode(127 & e[s]);
                                        return n
                                    }(this, t, r);
                                case "latin1":
                                case "binary":
                                    return function(e, t, r) {
                                        var n = "";
                                        r = Math.min(e.length, r);
                                        for (var s = t; s < r; ++s) n += String.fromCharCode(e[s]);
                                        return n
                                    }(this, t, r);
                                case "base64":
                                    return s = this, i = t, a = r, 0 === i && a === s.length ? n.fromByteArray(s) : n.fromByteArray(s.slice(i, a));
                                case "ucs2":
                                case "ucs-2":
                                case "utf16le":
                                case "utf-16le":
                                    return function(e, t, r) {
                                        for (var n = e.slice(t, r), s = "", i = 0; i < n.length; i += 2) s += String.fromCharCode(n[i] + 256 * n[i + 1]);
                                        return s
                                    }(this, t, r);
                                default:
                                    if (o) throw TypeError("Unknown encoding: " + e);
                                    e = (e + "").toLowerCase(), o = !0
                            }
                        }

                        function g(e, t, r) {
                            var n = e[t];
                            e[t] = e[r], e[r] = n
                        }

                        function m(e, t, r, n, s) {
                            var i;
                            if (0 === e.length) return -1;
                            if ("string" == typeof r ? (n = r, r = 0) : r > 0x7fffffff ? r = 0x7fffffff : r < -0x80000000 && (r = -0x80000000), (i = r *= 1) != i && (r = s ? 0 : e.length - 1), r < 0 && (r = e.length + r), r >= e.length)
                                if (s) return -1;
                                else r = e.length - 1;
                            else if (r < 0)
                                if (!s) return -1;
                                else r = 0;
                            if ("string" == typeof t && (t = o.from(t, n)), o.isBuffer(t)) return 0 === t.length ? -1 : y(e, t, r, n, s);
                            if ("number" == typeof t) {
                                if (t &= 255, "function" == typeof Uint8Array.prototype.indexOf)
                                    if (s) return Uint8Array.prototype.indexOf.call(e, t, r);
                                    else return Uint8Array.prototype.lastIndexOf.call(e, t, r);
                                return y(e, [t], r, n, s)
                            }
                            throw TypeError("val must be string, number or Buffer")
                        }

                        function y(e, t, r, n, s) {
                            var i, a = 1,
                                o = e.length,
                                l = t.length;
                            if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
                                if (e.length < 2 || t.length < 2) return -1;
                                a = 2, o /= 2, l /= 2, r /= 2
                            }

                            function c(e, t) {
                                return 1 === a ? e[t] : e.readUInt16BE(t * a)
                            }
                            if (s) {
                                var h = -1;
                                for (i = r; i < o; i++)
                                    if (c(e, i) === c(t, -1 === h ? 0 : i - h)) {
                                        if (-1 === h && (h = i), i - h + 1 === l) return h * a
                                    } else -1 !== h && (i -= i - h), h = -1
                            } else
                                for (r + l > o && (r = o - l), i = r; i >= 0; i--) {
                                    for (var u = !0, d = 0; d < l; d++)
                                        if (c(e, i + d) !== c(t, d)) {
                                            u = !1;
                                            break
                                        }
                                    if (u) return i
                                }
                            return -1
                        }
                        o.isBuffer = function(e) {
                            return null != e && !0 === e._isBuffer && e !== o.prototype
                        }, o.compare = function(e, t) {
                            if (R(e, Uint8Array) && (e = o.from(e, e.offset, e.byteLength)), R(t, Uint8Array) && (t = o.from(t, t.offset, t.byteLength)), !o.isBuffer(e) || !o.isBuffer(t)) throw TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
                            if (e === t) return 0;
                            for (var r = e.length, n = t.length, s = 0, i = Math.min(r, n); s < i; ++s)
                                if (e[s] !== t[s]) {
                                    r = e[s], n = t[s];
                                    break
                                }
                            return r < n ? -1 : +(n < r)
                        }, o.isEncoding = function(e) {
                            switch (String(e).toLowerCase()) {
                                case "hex":
                                case "utf8":
                                case "utf-8":
                                case "ascii":
                                case "latin1":
                                case "binary":
                                case "base64":
                                case "ucs2":
                                case "ucs-2":
                                case "utf16le":
                                case "utf-16le":
                                    return !0;
                                default:
                                    return !1
                            }
                        }, o.concat = function(e, t) {
                            if (!Array.isArray(e)) throw TypeError('"list" argument must be an Array of Buffers');
                            if (0 === e.length) return o.alloc(0);
                            if (void 0 === t)
                                for (r = 0, t = 0; r < e.length; ++r) t += e[r].length;
                            var r, n = o.allocUnsafe(t),
                                s = 0;
                            for (r = 0; r < e.length; ++r) {
                                var i = e[r];
                                if (R(i, Uint8Array) && (i = o.from(i)), !o.isBuffer(i)) throw TypeError('"list" argument must be an Array of Buffers');
                                i.copy(n, s), s += i.length
                            }
                            return n
                        }, o.byteLength = f, o.prototype._isBuffer = !0, o.prototype.swap16 = function() {
                            var e = this.length;
                            if (e % 2 != 0) throw RangeError("Buffer size must be a multiple of 16-bits");
                            for (var t = 0; t < e; t += 2) g(this, t, t + 1);
                            return this
                        }, o.prototype.swap32 = function() {
                            var e = this.length;
                            if (e % 4 != 0) throw RangeError("Buffer size must be a multiple of 32-bits");
                            for (var t = 0; t < e; t += 4) g(this, t, t + 3), g(this, t + 1, t + 2);
                            return this
                        }, o.prototype.swap64 = function() {
                            var e = this.length;
                            if (e % 8 != 0) throw RangeError("Buffer size must be a multiple of 64-bits");
                            for (var t = 0; t < e; t += 8) g(this, t, t + 7), g(this, t + 1, t + 6), g(this, t + 2, t + 5), g(this, t + 3, t + 4);
                            return this
                        }, o.prototype.toString = function() {
                            var e = this.length;
                            return 0 === e ? "" : 0 == arguments.length ? b(this, 0, e) : p.apply(this, arguments)
                        }, o.prototype.toLocaleString = o.prototype.toString, o.prototype.equals = function(e) {
                            if (!o.isBuffer(e)) throw TypeError("Argument must be a Buffer");
                            return this === e || 0 === o.compare(this, e)
                        }, o.prototype.inspect = function() {
                            var e = "",
                                r = t.INSPECT_MAX_BYTES;
                            return e = this.toString("hex", 0, r).replace(/(.{2})/g, "$1 ").trim(), this.length > r && (e += " ... "), "<Buffer " + e + ">"
                        }, i && (o.prototype[i] = o.prototype.inspect), o.prototype.compare = function(e, t, r, n, s) {
                            if (R(e, Uint8Array) && (e = o.from(e, e.offset, e.byteLength)), !o.isBuffer(e)) throw TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof e);
                            if (void 0 === t && (t = 0), void 0 === r && (r = e ? e.length : 0), void 0 === n && (n = 0), void 0 === s && (s = this.length), t < 0 || r > e.length || n < 0 || s > this.length) throw RangeError("out of range index");
                            if (n >= s && t >= r) return 0;
                            if (n >= s) return -1;
                            if (t >= r) return 1;
                            if (t >>>= 0, r >>>= 0, n >>>= 0, s >>>= 0, this === e) return 0;
                            for (var i = s - n, a = r - t, l = Math.min(i, a), c = this.slice(n, s), h = e.slice(t, r), u = 0; u < l; ++u)
                                if (c[u] !== h[u]) {
                                    i = c[u], a = h[u];
                                    break
                                }
                            return i < a ? -1 : +(a < i)
                        }, o.prototype.includes = function(e, t, r) {
                            return -1 !== this.indexOf(e, t, r)
                        }, o.prototype.indexOf = function(e, t, r) {
                            return m(this, e, t, r, !0)
                        }, o.prototype.lastIndexOf = function(e, t, r) {
                            return m(this, e, t, r, !1)
                        };

                        function b(e, t, r) {
                            r = Math.min(e.length, r);
                            for (var n = [], s = t; s < r;) {
                                var i, a, o, l, c = e[s],
                                    h = null,
                                    u = c > 239 ? 4 : c > 223 ? 3 : c > 191 ? 2 : 1;
                                if (s + u <= r) switch (u) {
                                    case 1:
                                        c < 128 && (h = c);
                                        break;
                                    case 2:
                                        (192 & (i = e[s + 1])) == 128 && (l = (31 & c) << 6 | 63 & i) > 127 && (h = l);
                                        break;
                                    case 3:
                                        i = e[s + 1], a = e[s + 2], (192 & i) == 128 && (192 & a) == 128 && (l = (15 & c) << 12 | (63 & i) << 6 | 63 & a) > 2047 && (l < 55296 || l > 57343) && (h = l);
                                        break;
                                    case 4:
                                        i = e[s + 1], a = e[s + 2], o = e[s + 3], (192 & i) == 128 && (192 & a) == 128 && (192 & o) == 128 && (l = (15 & c) << 18 | (63 & i) << 12 | (63 & a) << 6 | 63 & o) > 65535 && l < 1114112 && (h = l)
                                }
                                null === h ? (h = 65533, u = 1) : h > 65535 && (h -= 65536, n.push(h >>> 10 & 1023 | 55296), h = 56320 | 1023 & h), n.push(h), s += u
                            }
                            var d = n,
                                f = d.length;
                            if (f <= 4096) return String.fromCharCode.apply(String, d);
                            for (var p = "", g = 0; g < f;) p += String.fromCharCode.apply(String, d.slice(g, g += 4096));
                            return p
                        }

                        function w(e, t, r) {
                            if (e % 1 != 0 || e < 0) throw RangeError("offset is not uint");
                            if (e + t > r) throw RangeError("Trying to access beyond buffer length")
                        }

                        function v(e, t, r, n, s, i) {
                            if (!o.isBuffer(e)) throw TypeError('"buffer" argument must be a Buffer instance');
                            if (t > s || t < i) throw RangeError('"value" argument is out of bounds');
                            if (r + n > e.length) throw RangeError("Index out of range")
                        }

                        function E(e, t, r, n, s, i) {
                            if (r + n > e.length || r < 0) throw RangeError("Index out of range")
                        }

                        function k(e, t, r, n, i) {
                            return t *= 1, r >>>= 0, i || E(e, t, r, 4, 34028234663852886e22, -34028234663852886e22), s.write(e, t, r, n, 23, 4), r + 4
                        }

                        function S(e, t, r, n, i) {
                            return t *= 1, r >>>= 0, i || E(e, t, r, 8, 17976931348623157e292, -17976931348623157e292), s.write(e, t, r, n, 52, 8), r + 8
                        }
                        o.prototype.write = function(e, t, r, n) {
                            if (void 0 === t) n = "utf8", r = this.length, t = 0;
                            else if (void 0 === r && "string" == typeof t) n = t, r = this.length, t = 0;
                            else if (isFinite(t)) t >>>= 0, isFinite(r) ? (r >>>= 0, void 0 === n && (n = "utf8")) : (n = r, r = void 0);
                            else throw Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                            var s, i, a, o, l, c, h, u, d = this.length - t;
                            if ((void 0 === r || r > d) && (r = d), e.length > 0 && (r < 0 || t < 0) || t > this.length) throw RangeError("Attempt to write outside buffer bounds");
                            n || (n = "utf8");
                            for (var f = !1;;) switch (n) {
                                case "hex":
                                    return function(e, t, r, n) {
                                        r = Number(r) || 0;
                                        var s = e.length - r;
                                        n ? (n = Number(n)) > s && (n = s) : n = s;
                                        var i = t.length;
                                        n > i / 2 && (n = i / 2);
                                        for (var a = 0; a < n; ++a) {
                                            var o, l = parseInt(t.substr(2 * a, 2), 16);
                                            if ((o = l) != o) break;
                                            e[r + a] = l
                                        }
                                        return a
                                    }(this, e, t, r);
                                case "utf8":
                                case "utf-8":
                                    return s = t, i = r, _(T(e, this.length - s), this, s, i);
                                case "ascii":
                                    return a = t, o = r, _(O(e), this, a, o);
                                case "latin1":
                                case "binary":
                                    return function(e, t, r, n) {
                                        return _(O(t), e, r, n)
                                    }(this, e, t, r);
                                case "base64":
                                    return l = t, c = r, _(C(e), this, l, c);
                                case "ucs2":
                                case "ucs-2":
                                case "utf16le":
                                case "utf-16le":
                                    return h = t, u = r, _(function(e, t) {
                                        for (var r, n, s = [], i = 0; i < e.length && !((t -= 2) < 0); ++i) n = (r = e.charCodeAt(i)) >> 8, s.push(r % 256), s.push(n);
                                        return s
                                    }(e, this.length - h), this, h, u);
                                default:
                                    if (f) throw TypeError("Unknown encoding: " + n);
                                    n = ("" + n).toLowerCase(), f = !0
                            }
                        }, o.prototype.toJSON = function() {
                            return {
                                type: "Buffer",
                                data: Array.prototype.slice.call(this._arr || this, 0)
                            }
                        }, o.prototype.slice = function(e, t) {
                            var r = this.length;
                            e = ~~e, t = void 0 === t ? r : ~~t, e < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), t < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), t < e && (t = e);
                            var n = this.subarray(e, t);
                            return Object.setPrototypeOf(n, o.prototype), n
                        }, o.prototype.readUIntLE = function(e, t, r) {
                            e >>>= 0, t >>>= 0, r || w(e, t, this.length);
                            for (var n = this[e], s = 1, i = 0; ++i < t && (s *= 256);) n += this[e + i] * s;
                            return n
                        }, o.prototype.readUIntBE = function(e, t, r) {
                            e >>>= 0, t >>>= 0, r || w(e, t, this.length);
                            for (var n = this[e + --t], s = 1; t > 0 && (s *= 256);) n += this[e + --t] * s;
                            return n
                        }, o.prototype.readUInt8 = function(e, t) {
                            return e >>>= 0, t || w(e, 1, this.length), this[e]
                        }, o.prototype.readUInt16LE = function(e, t) {
                            return e >>>= 0, t || w(e, 2, this.length), this[e] | this[e + 1] << 8
                        }, o.prototype.readUInt16BE = function(e, t) {
                            return e >>>= 0, t || w(e, 2, this.length), this[e] << 8 | this[e + 1]
                        }, o.prototype.readUInt32LE = function(e, t) {
                            return e >>>= 0, t || w(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 0x1000000 * this[e + 3]
                        }, o.prototype.readUInt32BE = function(e, t) {
                            return e >>>= 0, t || w(e, 4, this.length), 0x1000000 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3])
                        }, o.prototype.readIntLE = function(e, t, r) {
                            e >>>= 0, t >>>= 0, r || w(e, t, this.length);
                            for (var n = this[e], s = 1, i = 0; ++i < t && (s *= 256);) n += this[e + i] * s;
                            return n >= (s *= 128) && (n -= Math.pow(2, 8 * t)), n
                        }, o.prototype.readIntBE = function(e, t, r) {
                            e >>>= 0, t >>>= 0, r || w(e, t, this.length);
                            for (var n = t, s = 1, i = this[e + --n]; n > 0 && (s *= 256);) i += this[e + --n] * s;
                            return i >= (s *= 128) && (i -= Math.pow(2, 8 * t)), i
                        }, o.prototype.readInt8 = function(e, t) {
                            return (e >>>= 0, t || w(e, 1, this.length), 128 & this[e]) ? -((255 - this[e] + 1) * 1) : this[e]
                        }, o.prototype.readInt16LE = function(e, t) {
                            e >>>= 0, t || w(e, 2, this.length);
                            var r = this[e] | this[e + 1] << 8;
                            return 32768 & r ? 0xffff0000 | r : r
                        }, o.prototype.readInt16BE = function(e, t) {
                            e >>>= 0, t || w(e, 2, this.length);
                            var r = this[e + 1] | this[e] << 8;
                            return 32768 & r ? 0xffff0000 | r : r
                        }, o.prototype.readInt32LE = function(e, t) {
                            return e >>>= 0, t || w(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24
                        }, o.prototype.readInt32BE = function(e, t) {
                            return e >>>= 0, t || w(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]
                        }, o.prototype.readFloatLE = function(e, t) {
                            return e >>>= 0, t || w(e, 4, this.length), s.read(this, e, !0, 23, 4)
                        }, o.prototype.readFloatBE = function(e, t) {
                            return e >>>= 0, t || w(e, 4, this.length), s.read(this, e, !1, 23, 4)
                        }, o.prototype.readDoubleLE = function(e, t) {
                            return e >>>= 0, t || w(e, 8, this.length), s.read(this, e, !0, 52, 8)
                        }, o.prototype.readDoubleBE = function(e, t) {
                            return e >>>= 0, t || w(e, 8, this.length), s.read(this, e, !1, 52, 8)
                        }, o.prototype.writeUIntLE = function(e, t, r, n) {
                            if (e *= 1, t >>>= 0, r >>>= 0, !n) {
                                var s = Math.pow(2, 8 * r) - 1;
                                v(this, e, t, r, s, 0)
                            }
                            var i = 1,
                                a = 0;
                            for (this[t] = 255 & e; ++a < r && (i *= 256);) this[t + a] = e / i & 255;
                            return t + r
                        }, o.prototype.writeUIntBE = function(e, t, r, n) {
                            if (e *= 1, t >>>= 0, r >>>= 0, !n) {
                                var s = Math.pow(2, 8 * r) - 1;
                                v(this, e, t, r, s, 0)
                            }
                            var i = r - 1,
                                a = 1;
                            for (this[t + i] = 255 & e; --i >= 0 && (a *= 256);) this[t + i] = e / a & 255;
                            return t + r
                        }, o.prototype.writeUInt8 = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 1, 255, 0), this[t] = 255 & e, t + 1
                        }, o.prototype.writeUInt16LE = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 2, 65535, 0), this[t] = 255 & e, this[t + 1] = e >>> 8, t + 2
                        }, o.prototype.writeUInt16BE = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 2, 65535, 0), this[t] = e >>> 8, this[t + 1] = 255 & e, t + 2
                        }, o.prototype.writeUInt32LE = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 4, 0xffffffff, 0), this[t + 3] = e >>> 24, this[t + 2] = e >>> 16, this[t + 1] = e >>> 8, this[t] = 255 & e, t + 4
                        }, o.prototype.writeUInt32BE = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 4, 0xffffffff, 0), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e, t + 4
                        }, o.prototype.writeIntLE = function(e, t, r, n) {
                            if (e *= 1, t >>>= 0, !n) {
                                var s = Math.pow(2, 8 * r - 1);
                                v(this, e, t, r, s - 1, -s)
                            }
                            var i = 0,
                                a = 1,
                                o = 0;
                            for (this[t] = 255 & e; ++i < r && (a *= 256);) e < 0 && 0 === o && 0 !== this[t + i - 1] && (o = 1), this[t + i] = (e / a | 0) - o & 255;
                            return t + r
                        }, o.prototype.writeIntBE = function(e, t, r, n) {
                            if (e *= 1, t >>>= 0, !n) {
                                var s = Math.pow(2, 8 * r - 1);
                                v(this, e, t, r, s - 1, -s)
                            }
                            var i = r - 1,
                                a = 1,
                                o = 0;
                            for (this[t + i] = 255 & e; --i >= 0 && (a *= 256);) e < 0 && 0 === o && 0 !== this[t + i + 1] && (o = 1), this[t + i] = (e / a | 0) - o & 255;
                            return t + r
                        }, o.prototype.writeInt8 = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 1, 127, -128), e < 0 && (e = 255 + e + 1), this[t] = 255 & e, t + 1
                        }, o.prototype.writeInt16LE = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 2, 32767, -32768), this[t] = 255 & e, this[t + 1] = e >>> 8, t + 2
                        }, o.prototype.writeInt16BE = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 2, 32767, -32768), this[t] = e >>> 8, this[t + 1] = 255 & e, t + 2
                        }, o.prototype.writeInt32LE = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 4, 0x7fffffff, -0x80000000), this[t] = 255 & e, this[t + 1] = e >>> 8, this[t + 2] = e >>> 16, this[t + 3] = e >>> 24, t + 4
                        }, o.prototype.writeInt32BE = function(e, t, r) {
                            return e *= 1, t >>>= 0, r || v(this, e, t, 4, 0x7fffffff, -0x80000000), e < 0 && (e = 0xffffffff + e + 1), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e, t + 4
                        }, o.prototype.writeFloatLE = function(e, t, r) {
                            return k(this, e, t, !0, r)
                        }, o.prototype.writeFloatBE = function(e, t, r) {
                            return k(this, e, t, !1, r)
                        }, o.prototype.writeDoubleLE = function(e, t, r) {
                            return S(this, e, t, !0, r)
                        }, o.prototype.writeDoubleBE = function(e, t, r) {
                            return S(this, e, t, !1, r)
                        }, o.prototype.copy = function(e, t, r, n) {
                            if (!o.isBuffer(e)) throw TypeError("argument should be a Buffer");
                            if (r || (r = 0), n || 0 === n || (n = this.length), t >= e.length && (t = e.length), t || (t = 0), n > 0 && n < r && (n = r), n === r || 0 === e.length || 0 === this.length) return 0;
                            if (t < 0) throw RangeError("targetStart out of bounds");
                            if (r < 0 || r >= this.length) throw RangeError("Index out of range");
                            if (n < 0) throw RangeError("sourceEnd out of bounds");
                            n > this.length && (n = this.length), e.length - t < n - r && (n = e.length - t + r);
                            var s = n - r;
                            if (this === e && "function" == typeof Uint8Array.prototype.copyWithin) this.copyWithin(t, r, n);
                            else if (this === e && r < t && t < n)
                                for (var i = s - 1; i >= 0; --i) e[i + t] = this[i + r];
                            else Uint8Array.prototype.set.call(e, this.subarray(r, n), t);
                            return s
                        }, o.prototype.fill = function(e, t, r, n) {
                            if ("string" == typeof e) {
                                if ("string" == typeof t ? (n = t, t = 0, r = this.length) : "string" == typeof r && (n = r, r = this.length), void 0 !== n && "string" != typeof n) throw TypeError("encoding must be a string");
                                if ("string" == typeof n && !o.isEncoding(n)) throw TypeError("Unknown encoding: " + n);
                                if (1 === e.length) {
                                    var s, i = e.charCodeAt(0);
                                    ("utf8" === n && i < 128 || "latin1" === n) && (e = i)
                                }
                            } else "number" == typeof e ? e &= 255 : "boolean" == typeof e && (e = Number(e));
                            if (t < 0 || this.length < t || this.length < r) throw RangeError("Out of range index");
                            if (r <= t) return this;
                            if (t >>>= 0, r = void 0 === r ? this.length : r >>> 0, e || (e = 0), "number" == typeof e)
                                for (s = t; s < r; ++s) this[s] = e;
                            else {
                                var a = o.isBuffer(e) ? e : o.from(e, n),
                                    l = a.length;
                                if (0 === l) throw TypeError('The value "' + e + '" is invalid for argument "value"');
                                for (s = 0; s < r - t; ++s) this[s + t] = a[s % l]
                            }
                            return this
                        };
                        var A = /[^+/0-9A-Za-z-_]/g;

                        function T(e, t) {
                            t = t || 1 / 0;
                            for (var r, n = e.length, s = null, i = [], a = 0; a < n; ++a) {
                                if ((r = e.charCodeAt(a)) > 55295 && r < 57344) {
                                    if (!s) {
                                        if (r > 56319 || a + 1 === n) {
                                            (t -= 3) > -1 && i.push(239, 191, 189);
                                            continue
                                        }
                                        s = r;
                                        continue
                                    }
                                    if (r < 56320) {
                                        (t -= 3) > -1 && i.push(239, 191, 189), s = r;
                                        continue
                                    }
                                    r = (s - 55296 << 10 | r - 56320) + 65536
                                } else s && (t -= 3) > -1 && i.push(239, 191, 189);
                                if (s = null, r < 128) {
                                    if ((t -= 1) < 0) break;
                                    i.push(r)
                                } else if (r < 2048) {
                                    if ((t -= 2) < 0) break;
                                    i.push(r >> 6 | 192, 63 & r | 128)
                                } else if (r < 65536) {
                                    if ((t -= 3) < 0) break;
                                    i.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128)
                                } else if (r < 1114112) {
                                    if ((t -= 4) < 0) break;
                                    i.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128)
                                } else throw Error("Invalid code point")
                            }
                            return i
                        }

                        function O(e) {
                            for (var t = [], r = 0; r < e.length; ++r) t.push(255 & e.charCodeAt(r));
                            return t
                        }

                        function C(e) {
                            return n.toByteArray(function(e) {
                                if ((e = (e = e.split("=")[0]).trim().replace(A, "")).length < 2) return "";
                                for (; e.length % 4 != 0;) e += "=";
                                return e
                            }(e))
                        }

                        function _(e, t, r, n) {
                            for (var s = 0; s < n && !(s + r >= t.length) && !(s >= e.length); ++s) t[s + r] = e[s];
                            return s
                        }

                        function R(e, t) {
                            return e instanceof t || null != e && null != e.constructor && null != e.constructor.name && e.constructor.name === t.name
                        }
                        var P = function() {
                            for (var e = "0123456789abcdef", t = Array(256), r = 0; r < 16; ++r)
                                for (var n = 16 * r, s = 0; s < 16; ++s) t[n + s] = e[r] + e[s];
                            return t
                        }()
                    },
                    783: function(e, t) {
                        t.read = function(e, t, r, n, s) {
                            var i, a, o = 8 * s - n - 1,
                                l = (1 << o) - 1,
                                c = l >> 1,
                                h = -7,
                                u = r ? s - 1 : 0,
                                d = r ? -1 : 1,
                                f = e[t + u];
                            for (u += d, i = f & (1 << -h) - 1, f >>= -h, h += o; h > 0; i = 256 * i + e[t + u], u += d, h -= 8);
                            for (a = i & (1 << -h) - 1, i >>= -h, h += n; h > 0; a = 256 * a + e[t + u], u += d, h -= 8);
                            if (0 === i) i = 1 - c;
                            else {
                                if (i === l) return a ? NaN : 1 / 0 * (f ? -1 : 1);
                                a += Math.pow(2, n), i -= c
                            }
                            return (f ? -1 : 1) * a * Math.pow(2, i - n)
                        }, t.write = function(e, t, r, n, s, i) {
                            var a, o, l, c = 8 * i - s - 1,
                                h = (1 << c) - 1,
                                u = h >> 1,
                                d = 5960464477539062e-23 * (23 === s),
                                f = n ? 0 : i - 1,
                                p = n ? 1 : -1,
                                g = +(t < 0 || 0 === t && 1 / t < 0);
                            for (isNaN(t = Math.abs(t)) || t === 1 / 0 ? (o = +!!isNaN(t), a = h) : (a = Math.floor(Math.log(t) / Math.LN2), t * (l = Math.pow(2, -a)) < 1 && (a--, l *= 2), a + u >= 1 ? t += d / l : t += d * Math.pow(2, 1 - u), t * l >= 2 && (a++, l /= 2), a + u >= h ? (o = 0, a = h) : a + u >= 1 ? (o = (t * l - 1) * Math.pow(2, s), a += u) : (o = t * Math.pow(2, u - 1) * Math.pow(2, s), a = 0)); s >= 8; e[r + f] = 255 & o, f += p, o /= 256, s -= 8);
                            for (a = a << s | o, c += s; c > 0; e[r + f] = 255 & a, f += p, a /= 256, c -= 8);
                            e[r + f - p] |= 128 * g
                        }
                    }
                },
                r = {};

            function n(e) {
                var s = r[e];
                if (void 0 !== s) return s.exports;
                var i = r[e] = {
                        exports: {}
                    },
                    a = !0;
                try {
                    t[e](i, i.exports, n), a = !1
                } finally {
                    a && delete r[e]
                }
                return i.exports
            }
            n.ab = "//", e.exports = n(72)
        },
        11285: (e, t, r) => {
            "use strict";
            r.d(t, {
                H1: () => k,
                zZ: () => m,
                GO: () => y,
                sC: () => u,
                KE: () => d,
                w_: () => b,
                Ll: () => g,
                sy: () => f,
                CP: () => p,
                uL: () => h
            });
            var n = r(46715),
                s = r(86465),
                i = r(328),
                a = r(43092);
            class o extends Error {
                constructor({
                    message: e,
                    code: t,
                    cause: r,
                    name: n
                }) {
                    var s;
                    super(e, {
                        cause: r
                    }), this.__isWebAuthnError = !0, this.name = null != (s = null != n ? n : r instanceof Error ? r.name : void 0) ? s : "Unknown Error", this.code = t
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        code: this.code
                    }
                }
            }
            class l extends o {
                constructor(e, t) {
                    super({
                        code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
                        cause: t,
                        message: e
                    }), this.name = "WebAuthnUnknownError", this.originalError = t
                }
            }
            class c {
                createNewAbortSignal() {
                    if (this.controller) {
                        let e = Error("Cancelling existing WebAuthn API call for new one");
                        e.name = "AbortError", this.controller.abort(e)
                    }
                    let e = new AbortController;
                    return this.controller = e, e.signal
                }
                cancelCeremony() {
                    if (this.controller) {
                        let e = Error("Manually cancelling existing WebAuthn API call");
                        e.name = "AbortError", this.controller.abort(e), this.controller = void 0
                    }
                }
            }
            let h = new c;

            function u(e) {
                if (!e) throw Error("Credential creation options are required");
                if ("u" > typeof PublicKeyCredential && "parseCreationOptionsFromJSON" in PublicKeyCredential && "function" == typeof PublicKeyCredential.parseCreationOptionsFromJSON) return PublicKeyCredential.parseCreationOptionsFromJSON(e);
                let {
                    challenge: t,
                    user: r,
                    excludeCredentials: i
                } = e, a = (0, n.Tt)(e, ["challenge", "user", "excludeCredentials"]), o = (0, s.xf)(t).buffer, l = Object.assign(Object.assign({}, r), {
                    id: (0, s.xf)(r.id).buffer
                }), c = Object.assign(Object.assign({}, a), {
                    challenge: o,
                    user: l
                });
                if (i && i.length > 0) {
                    c.excludeCredentials = Array(i.length);
                    for (let e = 0; e < i.length; e++) {
                        let t = i[e];
                        c.excludeCredentials[e] = Object.assign(Object.assign({}, t), {
                            id: (0, s.xf)(t.id).buffer,
                            type: t.type || "public-key",
                            transports: t.transports
                        })
                    }
                }
                return c
            }

            function d(e) {
                if (!e) throw Error("Credential request options are required");
                if ("u" > typeof PublicKeyCredential && "parseRequestOptionsFromJSON" in PublicKeyCredential && "function" == typeof PublicKeyCredential.parseRequestOptionsFromJSON) return PublicKeyCredential.parseRequestOptionsFromJSON(e);
                let {
                    challenge: t,
                    allowCredentials: r
                } = e, i = (0, n.Tt)(e, ["challenge", "allowCredentials"]), a = (0, s.xf)(t).buffer, o = Object.assign(Object.assign({}, i), {
                    challenge: a
                });
                if (r && r.length > 0) {
                    o.allowCredentials = Array(r.length);
                    for (let e = 0; e < r.length; e++) {
                        let t = r[e];
                        o.allowCredentials[e] = Object.assign(Object.assign({}, t), {
                            id: (0, s.xf)(t.id).buffer,
                            type: t.type || "public-key",
                            transports: t.transports
                        })
                    }
                }
                return o
            }

            function f(e) {
                var t;
                return "toJSON" in e && "function" == typeof e.toJSON ? e.toJSON() : {
                    id: e.id,
                    rawId: e.id,
                    response: {
                        attestationObject: (0, s.no)(new Uint8Array(e.response.attestationObject)),
                        clientDataJSON: (0, s.no)(new Uint8Array(e.response.clientDataJSON))
                    },
                    type: "public-key",
                    clientExtensionResults: e.getClientExtensionResults(),
                    authenticatorAttachment: null != (t = e.authenticatorAttachment) ? t : void 0
                }
            }

            function p(e) {
                var t;
                if ("toJSON" in e && "function" == typeof e.toJSON) return e.toJSON();
                let r = e.getClientExtensionResults(),
                    n = e.response;
                return {
                    id: e.id,
                    rawId: e.id,
                    response: {
                        authenticatorData: (0, s.no)(new Uint8Array(n.authenticatorData)),
                        clientDataJSON: (0, s.no)(new Uint8Array(n.clientDataJSON)),
                        signature: (0, s.no)(new Uint8Array(n.signature)),
                        userHandle: n.userHandle ? (0, s.no)(new Uint8Array(n.userHandle)) : void 0
                    },
                    type: "public-key",
                    clientExtensionResults: r,
                    authenticatorAttachment: null != (t = e.authenticatorAttachment) ? t : void 0
                }
            }

            function g(e) {
                return "localhost" === e || /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i.test(e)
            }

            function m() {
                var e, t;
                return !!((0, a.Bd)() && "PublicKeyCredential" in window && window.PublicKeyCredential && "credentials" in navigator && "function" == typeof(null == (e = null == navigator ? void 0 : navigator.credentials) ? void 0 : e.create) && "function" == typeof(null == (t = null == navigator ? void 0 : navigator.credentials) ? void 0 : t.get))
            }
            async function y(e) {
                try {
                    let t = await navigator.credentials.create(e);
                    if (!t) return {
                        data: null,
                        error: new l("Empty credential response", t)
                    };
                    if (!(t instanceof PublicKeyCredential)) return {
                        data: null,
                        error: new l("Browser returned unexpected credential type", t)
                    };
                    return {
                        data: t,
                        error: null
                    }
                } catch (t) {
                    return {
                        data: null,
                        error: function({
                            error: e,
                            options: t
                        }) {
                            var r, n, s;
                            let {
                                publicKey: i
                            } = t;
                            if (!i) throw Error("options was missing required publicKey property");
                            if ("AbortError" === e.name) {
                                if (t.signal instanceof AbortSignal) return new o({
                                    message: "Registration ceremony was sent an abort signal",
                                    code: "ERROR_CEREMONY_ABORTED",
                                    cause: e
                                })
                            } else if ("ConstraintError" === e.name) {
                                if ((null == (r = i.authenticatorSelection) ? void 0 : r.requireResidentKey) === !0) return new o({
                                    message: "Discoverable credentials were required but no available authenticator supported it",
                                    code: "ERROR_AUTHENTICATOR_MISSING_DISCOVERABLE_CREDENTIAL_SUPPORT",
                                    cause: e
                                });
                                else if ("conditional" === t.mediation && (null == (n = i.authenticatorSelection) ? void 0 : n.userVerification) === "required") return new o({
                                    message: "User verification was required during automatic registration but it could not be performed",
                                    code: "ERROR_AUTO_REGISTER_USER_VERIFICATION_FAILURE",
                                    cause: e
                                });
                                else if ((null == (s = i.authenticatorSelection) ? void 0 : s.userVerification) === "required") return new o({
                                    message: "User verification was required but no available authenticator supported it",
                                    code: "ERROR_AUTHENTICATOR_MISSING_USER_VERIFICATION_SUPPORT",
                                    cause: e
                                })
                            } else if ("InvalidStateError" === e.name) return new o({
                                message: "The authenticator was previously registered",
                                code: "ERROR_AUTHENTICATOR_PREVIOUSLY_REGISTERED",
                                cause: e
                            });
                            else if ("NotAllowedError" === e.name) return new o({
                                message: e.message,
                                code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
                                cause: e
                            });
                            else if ("NotSupportedError" === e.name) return new o(0 === i.pubKeyCredParams.filter(e => "public-key" === e.type).length ? {
                                message: 'No entry in pubKeyCredParams was of type "public-key"',
                                code: "ERROR_MALFORMED_PUBKEYCREDPARAMS",
                                cause: e
                            } : {
                                message: "No available authenticator supported any of the specified pubKeyCredParams algorithms",
                                code: "ERROR_AUTHENTICATOR_NO_SUPPORTED_PUBKEYCREDPARAMS_ALG",
                                cause: e
                            });
                            else if ("SecurityError" === e.name) {
                                let t = window.location.hostname;
                                if (!g(t)) return new o({
                                    message: `${window.location.hostname} is an invalid domain`,
                                    code: "ERROR_INVALID_DOMAIN",
                                    cause: e
                                });
                                if (i.rp.id !== t) return new o({
                                    message: `The RP ID "${i.rp.id}" is invalid for this domain`,
                                    code: "ERROR_INVALID_RP_ID",
                                    cause: e
                                })
                            } else if ("TypeError" === e.name) {
                                if (i.user.id.byteLength < 1 || i.user.id.byteLength > 64) return new o({
                                    message: "User ID was not between 1 and 64 characters",
                                    code: "ERROR_INVALID_USER_ID_LENGTH",
                                    cause: e
                                })
                            } else if ("UnknownError" === e.name) return new o({
                                message: "The authenticator was unable to process the specified options, or could not create a new credential",
                                code: "ERROR_AUTHENTICATOR_GENERAL_ERROR",
                                cause: e
                            });
                            return new o({
                                message: "a Non-Webauthn related error has occurred",
                                code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
                                cause: e
                            })
                        }({
                            error: t,
                            options: e
                        })
                    }
                }
            }
            async function b(e) {
                try {
                    let t = await navigator.credentials.get(e);
                    if (!t) return {
                        data: null,
                        error: new l("Empty credential response", t)
                    };
                    if (!(t instanceof PublicKeyCredential)) return {
                        data: null,
                        error: new l("Browser returned unexpected credential type", t)
                    };
                    return {
                        data: t,
                        error: null
                    }
                } catch (t) {
                    return {
                        data: null,
                        error: function({
                            error: e,
                            options: t
                        }) {
                            let {
                                publicKey: r
                            } = t;
                            if (!r) throw Error("options was missing required publicKey property");
                            if ("AbortError" === e.name) {
                                if (t.signal instanceof AbortSignal) return new o({
                                    message: "Authentication ceremony was sent an abort signal",
                                    code: "ERROR_CEREMONY_ABORTED",
                                    cause: e
                                })
                            } else if ("NotAllowedError" === e.name) return new o({
                                message: e.message,
                                code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
                                cause: e
                            });
                            else if ("SecurityError" === e.name) {
                                let t = window.location.hostname;
                                if (!g(t)) return new o({
                                    message: `${window.location.hostname} is an invalid domain`,
                                    code: "ERROR_INVALID_DOMAIN",
                                    cause: e
                                });
                                if (r.rpId !== t) return new o({
                                    message: `The RP ID "${r.rpId}" is invalid for this domain`,
                                    code: "ERROR_INVALID_RP_ID",
                                    cause: e
                                })
                            } else if ("UnknownError" === e.name) return new o({
                                message: "The authenticator was unable to process the specified options, or could not create a new assertion signature",
                                code: "ERROR_AUTHENTICATOR_GENERAL_ERROR",
                                cause: e
                            });
                            return new o({
                                message: "a Non-Webauthn related error has occurred",
                                code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
                                cause: e
                            })
                        }({
                            error: t,
                            options: e
                        })
                    }
                }
            }
            let w = {
                    hints: ["security-key"],
                    authenticatorSelection: {
                        authenticatorAttachment: "cross-platform",
                        requireResidentKey: !1,
                        userVerification: "preferred",
                        residentKey: "discouraged"
                    },
                    attestation: "direct"
                },
                v = {
                    userVerification: "preferred",
                    hints: ["security-key"],
                    attestation: "direct"
                };

            function E(...e) {
                let t = e => null !== e && "object" == typeof e && !Array.isArray(e),
                    r = e => e instanceof ArrayBuffer || ArrayBuffer.isView(e),
                    n = {};
                for (let s of e)
                    if (s)
                        for (let e in s) {
                            let i = s[e];
                            if (void 0 !== i)
                                if (Array.isArray(i)) n[e] = i;
                                else if (r(i)) n[e] = i;
                            else if (t(i)) {
                                let r = n[e];
                                t(r) ? n[e] = E(r, i) : n[e] = E(i)
                            } else n[e] = i
                        }
                return n
            }
            class k {
                constructor(e) {
                    this.client = e, this.enroll = this._enroll.bind(this), this.challenge = this._challenge.bind(this), this.verify = this._verify.bind(this), this.authenticate = this._authenticate.bind(this), this.register = this._register.bind(this)
                }
                async _enroll(e) {
                    return this.client.mfa.enroll(Object.assign(Object.assign({}, e), {
                        factorType: "webauthn"
                    }))
                }
                async _challenge({
                    factorId: e,
                    webauthn: t,
                    friendlyName: r,
                    signal: n
                }, s) {
                    var a, o, l, c, u;
                    try {
                        let {
                            data: i,
                            error: d
                        } = await this.client.mfa.challenge({
                            factorId: e,
                            webauthn: t
                        });
                        if (!i) return {
                            data: null,
                            error: d
                        };
                        let f = null != n ? n : h.createNewAbortSignal();
                        if ("create" === i.webauthn.type) {
                            let {
                                user: e
                            } = i.webauthn.credential_options.publicKey;
                            if (!e.name)
                                if (r) e.name = `${e.id}:${r}`;
                                else {
                                    let t = (await this.client.getUser()).data.user,
                                        r = (null == (a = null == t ? void 0 : t.user_metadata) ? void 0 : a.name) || (null == t ? void 0 : t.email) || (null == t ? void 0 : t.id) || "User";
                                    e.name = `${e.id}:${r}`
                                }
                            e.displayName || (e.displayName = e.name)
                        }
                        switch (i.webauthn.type) {
                            case "create":
                                {
                                    let t = (o = i.webauthn.credential_options.publicKey, l = null == s ? void 0 : s.create, E(w, o, l || {})),
                                        {
                                            data: r,
                                            error: n
                                        } = await y({
                                            publicKey: t,
                                            signal: f
                                        });
                                    if (r) return {
                                        data: {
                                            factorId: e,
                                            challengeId: i.id,
                                            webauthn: {
                                                type: i.webauthn.type,
                                                credential_response: r
                                            }
                                        },
                                        error: null
                                    };
                                    return {
                                        data: null,
                                        error: n
                                    }
                                }
                            case "request":
                                {
                                    let t = (c = i.webauthn.credential_options.publicKey, u = null == s ? void 0 : s.request, E(v, c, u || {})),
                                        {
                                            data: r,
                                            error: n
                                        } = await b(Object.assign(Object.assign({}, i.webauthn.credential_options), {
                                            publicKey: t,
                                            signal: f
                                        }));
                                    if (r) return {
                                        data: {
                                            factorId: e,
                                            challengeId: i.id,
                                            webauthn: {
                                                type: i.webauthn.type,
                                                credential_response: r
                                            }
                                        },
                                        error: null
                                    };
                                    return {
                                        data: null,
                                        error: n
                                    }
                                }
                        }
                    } catch (e) {
                        if ((0, i.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        return {
                            data: null,
                            error: new i.HU("Unexpected error in challenge", e)
                        }
                    }
                }
                async _verify({
                    challengeId: e,
                    factorId: t,
                    webauthn: r
                }) {
                    return this.client.mfa.verify({
                        factorId: t,
                        challengeId: e,
                        webauthn: r
                    })
                }
                async _authenticate({
                    factorId: e,
                    webauthn: {
                        rpId: t = "u" > typeof window ? window.location.hostname : void 0,
                        rpOrigins: r = "u" > typeof window ? [window.location.origin] : void 0,
                        signal: n
                    } = {}
                }, s) {
                    if (!t) return {
                        data: null,
                        error: new i.lR("rpId is required for WebAuthn authentication")
                    };
                    try {
                        if (!m()) return {
                            data: null,
                            error: new i.HU("Browser does not support WebAuthn", null)
                        };
                        let {
                            data: a,
                            error: o
                        } = await this.challenge({
                            factorId: e,
                            webauthn: {
                                rpId: t,
                                rpOrigins: r
                            },
                            signal: n
                        }, {
                            request: s
                        });
                        if (!a) return {
                            data: null,
                            error: o
                        };
                        let {
                            webauthn: l
                        } = a;
                        return this._verify({
                            factorId: e,
                            challengeId: a.challengeId,
                            webauthn: {
                                type: l.type,
                                rpId: t,
                                rpOrigins: r,
                                credential_response: l.credential_response
                            }
                        })
                    } catch (e) {
                        if ((0, i.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        return {
                            data: null,
                            error: new i.HU("Unexpected error in authenticate", e)
                        }
                    }
                }
                async _register({
                    friendlyName: e,
                    webauthn: {
                        rpId: t = "u" > typeof window ? window.location.hostname : void 0,
                        rpOrigins: r = "u" > typeof window ? [window.location.origin] : void 0,
                        signal: n
                    } = {}
                }, s) {
                    if (!t) return {
                        data: null,
                        error: new i.lR("rpId is required for WebAuthn registration")
                    };
                    try {
                        if (!m()) return {
                            data: null,
                            error: new i.HU("Browser does not support WebAuthn", null)
                        };
                        let {
                            data: a,
                            error: o
                        } = await this._enroll({
                            friendlyName: e
                        });
                        if (!a) return await this.client.mfa.listFactors().then(t => {
                            var r;
                            return null == (r = t.data) ? void 0 : r.all.find(t => "webauthn" === t.factor_type && t.friendly_name === e && "unverified" !== t.status)
                        }).then(e => e ? this.client.mfa.unenroll({
                            factorId: null == e ? void 0 : e.id
                        }) : void 0), {
                            data: null,
                            error: o
                        };
                        let {
                            data: l,
                            error: c
                        } = await this._challenge({
                            factorId: a.id,
                            friendlyName: a.friendly_name,
                            webauthn: {
                                rpId: t,
                                rpOrigins: r
                            },
                            signal: n
                        }, {
                            create: s
                        });
                        if (!l) return {
                            data: null,
                            error: c
                        };
                        return this._verify({
                            factorId: a.id,
                            challengeId: l.challengeId,
                            webauthn: {
                                rpId: t,
                                rpOrigins: r,
                                type: l.webauthn.type,
                                credential_response: l.webauthn.credential_response
                            }
                        })
                    } catch (e) {
                        if ((0, i.HY)(e)) return {
                            data: null,
                            error: e
                        };
                        return {
                            data: null,
                            error: new i.HU("Unexpected error in register", e)
                        }
                    }
                }
            }
        },
        31858: (e, t, r) => {
            "use strict";

            function n(e = {}) {
                return {
                    getItem: t => e[t] || null,
                    setItem: (t, r) => {
                        e[t] = r
                    },
                    removeItem: t => {
                        delete e[t]
                    }
                }
            }
            r.d(t, {
                r: () => n
            })
        },
        38787: (e, t, r) => {
            "use strict";
            let n, s, i, a;
            r.d(t, {
                k: () => tz
            });
            var o, l, c, h, u, d, f, p, g, m, y, b, w, v, E = r(46715);
            class k extends Error {
                constructor(e, t = "FunctionsError", r) {
                    super(e), this.name = t, this.context = r
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        context: this.context
                    }
                }
            }
            class S extends k {
                constructor(e) {
                    super("Failed to send a request to the Edge Function", "FunctionsFetchError", e)
                }
            }
            class A extends k {
                constructor(e) {
                    super("Relay Error invoking the Edge Function", "FunctionsRelayError", e)
                }
            }
            class T extends k {
                constructor(e) {
                    super("Edge Function returned a non-2xx status code", "FunctionsHttpError", e)
                }
            }(o = f || (f = {})).Any = "any", o.ApNortheast1 = "ap-northeast-1", o.ApNortheast2 = "ap-northeast-2", o.ApSouth1 = "ap-south-1", o.ApSoutheast1 = "ap-southeast-1", o.ApSoutheast2 = "ap-southeast-2", o.CaCentral1 = "ca-central-1", o.EuCentral1 = "eu-central-1", o.EuWest1 = "eu-west-1", o.EuWest2 = "eu-west-2", o.EuWest3 = "eu-west-3", o.SaEast1 = "sa-east-1", o.UsEast1 = "us-east-1", o.UsWest1 = "us-west-1", o.UsWest2 = "us-west-2";
            class O {
                constructor(e, {
                    headers: t = {},
                    customFetch: r,
                    region: n = f.Any
                } = {}) {
                    this.url = e, this.headers = t, this.region = n, this.fetch = (e => e ? (...t) => e(...t) : (...e) => fetch(...e))(r)
                }
                setAuth(e) {
                    this.headers.Authorization = `Bearer ${e}`
                }
                invoke(e) {
                    return (0, E.sH)(this, arguments, void 0, function*(e, t = {}) {
                        var r;
                        let n, s;
                        try {
                            let i, {
                                    headers: a,
                                    method: o,
                                    body: l,
                                    signal: c,
                                    timeout: h
                                } = t,
                                u = {},
                                {
                                    region: d
                                } = t;
                            d || (d = this.region);
                            let f = new URL(`${this.url}/${e}`);
                            d && "any" !== d && (u["x-region"] = d, f.searchParams.set("forceFunctionRegion", d)), l && (a && !Object.prototype.hasOwnProperty.call(a, "Content-Type") || !a) ? "u" > typeof Blob && l instanceof Blob || l instanceof ArrayBuffer ? (u["Content-Type"] = "application/octet-stream", i = l) : "string" == typeof l ? (u["Content-Type"] = "text/plain", i = l) : "u" > typeof FormData && l instanceof FormData ? i = l : (u["Content-Type"] = "application/json", i = JSON.stringify(l)) : i = !l || "string" == typeof l || "u" > typeof Blob && l instanceof Blob || l instanceof ArrayBuffer || "u" > typeof FormData && l instanceof FormData ? l : JSON.stringify(l);
                            let p = c;
                            h && (s = new AbortController, n = setTimeout(() => s.abort(), h), c ? (p = s.signal, c.addEventListener("abort", () => s.abort())) : p = s.signal);
                            let g = yield this.fetch(f.toString(), {
                                method: o || "POST",
                                headers: Object.assign(Object.assign(Object.assign({}, u), this.headers), a),
                                body: i,
                                signal: p
                            }).catch(e => {
                                throw new S(e)
                            }), m = g.headers.get("x-relay-error");
                            if (m && "true" === m) throw new A(g);
                            if (!g.ok) throw new T(g);
                            let y = (null != (r = g.headers.get("Content-Type")) ? r : "text/plain").split(";")[0].trim();
                            return {
                                data: "application/json" === y ? yield g.json(): "application/octet-stream" === y || "application/pdf" === y ? yield g.blob(): "text/event-stream" === y ? g : "multipart/form-data" === y ? yield g.formData(): yield g.text(), error: null, response: g
                            }
                        } catch (e) {
                            return {
                                data: null,
                                error: e,
                                response: e instanceof T || e instanceof A ? e.context : void 0
                            }
                        } finally {
                            n && clearTimeout(n)
                        }
                    })
                }
            }
            let C = e => Math.min(1e3 * 2 ** e, 3e4),
                _ = [520, 503],
                R = ["GET", "HEAD", "OPTIONS"];
            var P = class extends Error {
                constructor(e) {
                    super(e.message), this.name = "PostgrestError", this.details = e.details, this.hint = e.hint, this.code = e.code
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        details: this.details,
                        hint: this.hint,
                        code: this.code
                    }
                }
            };

            function j(e, t) {
                return new Promise(r => {
                    if (null == t ? void 0 : t.aborted) return void r();
                    let n = setTimeout(() => {
                        null == t || t.removeEventListener("abort", s), r()
                    }, e);

                    function s() {
                        clearTimeout(n), r()
                    }
                    null == t || t.addEventListener("abort", s)
                })
            }
            var $ = class {
                    constructor(e) {
                        var t, r, n, s, i;
                        this.shouldThrowOnError = !1, this.retryEnabled = !0, this.method = e.method, this.url = e.url, this.headers = new Headers(e.headers), this.schema = e.schema, this.body = e.body, this.shouldThrowOnError = null != (t = e.shouldThrowOnError) && t, this.signal = e.signal, this.isMaybeSingle = null != (r = e.isMaybeSingle) && r, this.shouldStripNulls = null != (n = e.shouldStripNulls) && n, this.urlLengthLimit = null != (s = e.urlLengthLimit) ? s : 8e3, this.retryEnabled = null == (i = e.retry) || i, e.fetch ? this.fetch = e.fetch : this.fetch = fetch
                    }
                    throwOnError() {
                        return this.shouldThrowOnError = !0, this
                    }
                    stripNulls() {
                        if ("text/csv" === this.headers.get("Accept")) throw Error("stripNulls() cannot be used with csv()");
                        return this.shouldStripNulls = !0, this
                    }
                    setHeader(e, t) {
                        return this.headers = new Headers(this.headers), this.headers.set(e, t), this
                    }
                    retry(e) {
                        return this.retryEnabled = e, this
                    }
                    then(e, t) {
                        var r = this;
                        if (void 0 === this.schema || (["GET", "HEAD"].includes(this.method) ? this.headers.set("Accept-Profile", this.schema) : this.headers.set("Content-Profile", this.schema)), "GET" !== this.method && "HEAD" !== this.method && this.headers.set("Content-Type", "application/json"), this.shouldStripNulls) {
                            let e = this.headers.get("Accept");
                            "application/vnd.pgrst.object+json" === e ? this.headers.set("Accept", "application/vnd.pgrst.object+json;nulls=stripped") : e && "application/json" !== e || this.headers.set("Accept", "application/vnd.pgrst.array+json;nulls=stripped")
                        }
                        let n = this.fetch,
                            s = (async () => {
                                let e = 0;
                                for (;;) {
                                    var t, s, i, a, o;
                                    let l, c = {};
                                    r.headers.forEach((e, t) => {
                                        c[t] = e
                                    }), e > 0 && (c["X-Retry-Count"] = String(e));
                                    try {
                                        l = await n(r.url.toString(), {
                                            method: r.method,
                                            headers: c,
                                            body: JSON.stringify(r.body, (e, t) => "bigint" == typeof t ? t.toString() : t),
                                            signal: r.signal
                                        })
                                    } catch (t) {
                                        if ((null == t ? void 0 : t.name) === "AbortError" || (null == t ? void 0 : t.code) === "ABORT_ERR" || !R.includes(r.method)) throw t;
                                        if (r.retryEnabled && e < 3) {
                                            let t = C(e);
                                            e++, await j(t, r.signal);
                                            continue
                                        }
                                        throw t
                                    }
                                    if (t = r.method, s = l.status, i = e, r.retryEnabled && !(i >= 3) && R.includes(t) && _.includes(s) && 1) {
                                        let t = null != (a = null == (o = l.headers) ? void 0 : o.get("Retry-After")) ? a : null,
                                            n = null !== t ? 1e3 * Math.max(0, parseInt(t, 10) || 0) : C(e);
                                        await l.text(), e++, await j(n, r.signal);
                                        continue
                                    }
                                    return await r.processResponse(l)
                                }
                            })();
                        return this.shouldThrowOnError || (s = s.catch(e => {
                            var t, r, n, s, i, a;
                            let o = "",
                                l = "",
                                c = "",
                                h = null == e ? void 0 : e.cause;
                            if (h) {
                                let t = null != (r = null == h ? void 0 : h.message) ? r : "",
                                    a = null != (n = null == h ? void 0 : h.code) ? n : "";
                                o = `${null!=(s=null==e?void 0:e.name)?s:"FetchError"}: ${null==e?void 0:e.message}

Caused by: ${null!=(i=null==h?void 0:h.name)?i:"Error"}: ${t}`, a && (o += ` (${a})`), (null == h ? void 0 : h.stack) && (o += `
${h.stack}`)
                            } else o = null != (a = null == e ? void 0 : e.stack) ? a : "";
                            let u = this.url.toString().length;
                            return (null == e ? void 0 : e.name) === "AbortError" || (null == e ? void 0 : e.code) === "ABORT_ERR" ? (c = "", l = "Request was aborted (timeout or manual cancellation)", u > this.urlLengthLimit && (l += `. Note: Your request URL is ${u} characters, which may exceed server limits. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [many IDs])), consider using an RPC function to pass values server-side.`)) : ((null == h ? void 0 : h.name) === "HeadersOverflowError" || (null == h ? void 0 : h.code) === "UND_ERR_HEADERS_OVERFLOW") && (c = "", l = "HTTP headers exceeded server limits (typically 16KB)", u > this.urlLengthLimit && (l += `. Your request URL is ${u} characters. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [200+ IDs])), consider using an RPC function instead.`)), {
                                success: !1,
                                error: {
                                    message: `${null!=(t=null==e?void 0:e.name)?t:"FetchError"}: ${null==e?void 0:e.message}`,
                                    details: o,
                                    hint: l,
                                    code: c
                                },
                                data: null,
                                count: null,
                                status: 0,
                                statusText: ""
                            }
                        })), s.then(e, t)
                    }
                    async processResponse(e) {
                        var t, r, n;
                        let s = null,
                            i = null,
                            a = null,
                            o = e.status,
                            l = e.statusText;
                        if (e.ok) {
                            if ("HEAD" !== this.method) {
                                let t = await e.text();
                                if ("" === t);
                                else if ("text/csv" === this.headers.get("Accept")) i = t;
                                else if (this.headers.get("Accept") && (null == (n = this.headers.get("Accept")) ? void 0 : n.includes("application/vnd.pgrst.plan+text"))) i = t;
                                else try {
                                    i = JSON.parse(t)
                                } catch (e) {
                                    if (s = {
                                            message: t
                                        }, i = null, this.shouldThrowOnError) throw new P({
                                        message: t,
                                        details: "",
                                        hint: "",
                                        code: ""
                                    })
                                }
                            }
                            let c = null == (t = this.headers.get("Prefer")) ? void 0 : t.match(/count=(exact|planned|estimated)/),
                                h = null == (r = e.headers.get("content-range")) ? void 0 : r.split("/");
                            c && h && h.length > 1 && (a = parseInt(h[1])), this.isMaybeSingle && Array.isArray(i) && (i.length > 1 ? (s = {
                                code: "PGRST116",
                                details: `Results contain ${i.length} rows, application/vnd.pgrst.object+json requires 1 row`,
                                hint: null,
                                message: "JSON object requested, multiple (or no) rows returned"
                            }, i = null, a = null, o = 406, l = "Not Acceptable") : i = 1 === i.length ? i[0] : null)
                        } else {
                            let t = await e.text();
                            try {
                                s = JSON.parse(t), Array.isArray(s) && 404 === e.status && (i = [], s = null, o = 200, l = "OK")
                            } catch (r) {
                                404 === e.status && "" === t ? (o = 204, l = "No Content") : s = {
                                    message: t
                                }
                            }
                            if (s && this.shouldThrowOnError) throw new P(s)
                        }
                        return {
                            success: null === s,
                            error: s,
                            data: i,
                            count: a,
                            status: o,
                            statusText: l
                        }
                    }
                    returns() {
                        return this
                    }
                    overrideTypes() {
                        return this
                    }
                },
                x = class extends $ {
                    select(e) {
                        let t = !1,
                            r = (null != e ? e : "*").split("").map(e => /\s/.test(e) && !t ? "" : ('"' === e && (t = !t), e)).join("");
                        return this.url.searchParams.set("select", r), this.headers.append("Prefer", "return=representation"), this
                    }
                    order(e, {
                        ascending: t = !0,
                        nullsFirst: r,
                        foreignTable: n,
                        referencedTable: s = n
                    } = {}) {
                        let i = s ? `${s}.order` : "order",
                            a = this.url.searchParams.get(i);
                        return this.url.searchParams.set(i, `${a?`${a},`:""}${e}.${t?"asc":"desc"}${void 0===r?"":r?".nullsfirst":".nullslast"}`), this
                    }
                    limit(e, {
                        foreignTable: t,
                        referencedTable: r = t
                    } = {}) {
                        let n = void 0 === r ? "limit" : `${r}.limit`;
                        return this.url.searchParams.set(n, `${e}`), this
                    }
                    range(e, t, {
                        foreignTable: r,
                        referencedTable: n = r
                    } = {}) {
                        let s = void 0 === n ? "offset" : `${n}.offset`,
                            i = void 0 === n ? "limit" : `${n}.limit`;
                        return this.url.searchParams.set(s, `${e}`), this.url.searchParams.set(i, `${t-e+1}`), this
                    }
                    abortSignal(e) {
                        return this.signal = e, this
                    }
                    single() {
                        return this.headers.set("Accept", "application/vnd.pgrst.object+json"), this
                    }
                    maybeSingle() {
                        return this.isMaybeSingle = !0, this
                    }
                    csv() {
                        return this.headers.set("Accept", "text/csv"), this
                    }
                    geojson() {
                        return this.headers.set("Accept", "application/geo+json"), this
                    }
                    explain({
                        analyze: e = !1,
                        verbose: t = !1,
                        settings: r = !1,
                        buffers: n = !1,
                        wal: s = !1,
                        format: i = "text"
                    } = {}) {
                        var a;
                        let o = [e ? "analyze" : null, t ? "verbose" : null, r ? "settings" : null, n ? "buffers" : null, s ? "wal" : null].filter(Boolean).join("|"),
                            l = null != (a = this.headers.get("Accept")) ? a : "application/json";
                        return this.headers.set("Accept", `application/vnd.pgrst.plan+${i}; for="${l}"; options=${o};`), this
                    }
                    rollback() {
                        return this.headers.append("Prefer", "tx=rollback"), this
                    }
                    returns() {
                        return this
                    }
                    maxAffected(e) {
                        return this.headers.append("Prefer", "handling=strict"), this.headers.append("Prefer", `max-affected=${e}`), this
                    }
                };
            let U = RegExp("[,()]");
            var I = class extends x {
                    eq(e, t) {
                        return this.url.searchParams.append(e, `eq.${t}`), this
                    }
                    neq(e, t) {
                        return this.url.searchParams.append(e, `neq.${t}`), this
                    }
                    gt(e, t) {
                        return this.url.searchParams.append(e, `gt.${t}`), this
                    }
                    gte(e, t) {
                        return this.url.searchParams.append(e, `gte.${t}`), this
                    }
                    lt(e, t) {
                        return this.url.searchParams.append(e, `lt.${t}`), this
                    }
                    lte(e, t) {
                        return this.url.searchParams.append(e, `lte.${t}`), this
                    }
                    like(e, t) {
                        return this.url.searchParams.append(e, `like.${t}`), this
                    }
                    likeAllOf(e, t) {
                        return this.url.searchParams.append(e, `like(all).{${t.join(",")}}`), this
                    }
                    likeAnyOf(e, t) {
                        return this.url.searchParams.append(e, `like(any).{${t.join(",")}}`), this
                    }
                    ilike(e, t) {
                        return this.url.searchParams.append(e, `ilike.${t}`), this
                    }
                    ilikeAllOf(e, t) {
                        return this.url.searchParams.append(e, `ilike(all).{${t.join(",")}}`), this
                    }
                    ilikeAnyOf(e, t) {
                        return this.url.searchParams.append(e, `ilike(any).{${t.join(",")}}`), this
                    }
                    regexMatch(e, t) {
                        return this.url.searchParams.append(e, `match.${t}`), this
                    }
                    regexIMatch(e, t) {
                        return this.url.searchParams.append(e, `imatch.${t}`), this
                    }
                    is(e, t) {
                        return this.url.searchParams.append(e, `is.${t}`), this
                    }
                    isDistinct(e, t) {
                        return this.url.searchParams.append(e, `isdistinct.${t}`), this
                    } in (e, t) {
                        let r = Array.from(new Set(t)).map(e => "string" == typeof e && U.test(e) ? `"${e}"` : `${e}`).join(",");
                        return this.url.searchParams.append(e, `in.(${r})`), this
                    }
                    notIn(e, t) {
                        let r = Array.from(new Set(t)).map(e => "string" == typeof e && U.test(e) ? `"${e}"` : `${e}`).join(",");
                        return this.url.searchParams.append(e, `not.in.(${r})`), this
                    }
                    contains(e, t) {
                        return "string" == typeof t ? this.url.searchParams.append(e, `cs.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cs.{${t.join(",")}}`) : this.url.searchParams.append(e, `cs.${JSON.stringify(t)}`), this
                    }
                    containedBy(e, t) {
                        return "string" == typeof t ? this.url.searchParams.append(e, `cd.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cd.{${t.join(",")}}`) : this.url.searchParams.append(e, `cd.${JSON.stringify(t)}`), this
                    }
                    rangeGt(e, t) {
                        return this.url.searchParams.append(e, `sr.${t}`), this
                    }
                    rangeGte(e, t) {
                        return this.url.searchParams.append(e, `nxl.${t}`), this
                    }
                    rangeLt(e, t) {
                        return this.url.searchParams.append(e, `sl.${t}`), this
                    }
                    rangeLte(e, t) {
                        return this.url.searchParams.append(e, `nxr.${t}`), this
                    }
                    rangeAdjacent(e, t) {
                        return this.url.searchParams.append(e, `adj.${t}`), this
                    }
                    overlaps(e, t) {
                        return "string" == typeof t ? this.url.searchParams.append(e, `ov.${t}`) : this.url.searchParams.append(e, `ov.{${t.join(",")}}`), this
                    }
                    textSearch(e, t, {
                        config: r,
                        type: n
                    } = {}) {
                        let s = "";
                        "plain" === n ? s = "pl" : "phrase" === n ? s = "ph" : "websearch" === n && (s = "w");
                        let i = void 0 === r ? "" : `(${r})`;
                        return this.url.searchParams.append(e, `${s}fts${i}.${t}`), this
                    }
                    match(e) {
                        return Object.entries(e).filter(([e, t]) => void 0 !== t).forEach(([e, t]) => {
                            this.url.searchParams.append(e, `eq.${t}`)
                        }), this
                    }
                    not(e, t, r) {
                        return this.url.searchParams.append(e, `not.${t}.${r}`), this
                    }
                    or(e, {
                        foreignTable: t,
                        referencedTable: r = t
                    } = {}) {
                        let n = r ? `${r}.or` : "or";
                        return this.url.searchParams.append(n, `(${e})`), this
                    }
                    filter(e, t, r) {
                        return this.url.searchParams.append(e, `${t}.${r}`), this
                    }
                },
                N = class {
                    constructor(e, {
                        headers: t = {},
                        schema: r,
                        fetch: n,
                        urlLengthLimit: s = 8e3,
                        retry: i
                    }) {
                        this.url = e, this.headers = new Headers(t), this.schema = r, this.fetch = n, this.urlLengthLimit = s, this.retry = i
                    }
                    cloneRequestState() {
                        return {
                            url: new URL(this.url.toString()),
                            headers: new Headers(this.headers)
                        }
                    }
                    select(e, t) {
                        let {
                            head: r = !1,
                            count: n
                        } = null != t ? t : {}, s = !1, i = (null != e ? e : "*").split("").map(e => /\s/.test(e) && !s ? "" : ('"' === e && (s = !s), e)).join(""), {
                            url: a,
                            headers: o
                        } = this.cloneRequestState();
                        return a.searchParams.set("select", i), n && o.append("Prefer", `count=${n}`), new I({
                            method: r ? "HEAD" : "GET",
                            url: a,
                            headers: o,
                            schema: this.schema,
                            fetch: this.fetch,
                            urlLengthLimit: this.urlLengthLimit,
                            retry: this.retry
                        })
                    }
                    insert(e, {
                        count: t,
                        defaultToNull: r = !0
                    } = {}) {
                        var n;
                        let {
                            url: s,
                            headers: i
                        } = this.cloneRequestState();
                        if (t && i.append("Prefer", `count=${t}`), r || i.append("Prefer", "missing=default"), Array.isArray(e)) {
                            let t = e.reduce((e, t) => e.concat(Object.keys(t)), []);
                            if (t.length > 0) {
                                let e = [...new Set(t)].map(e => `"${e}"`);
                                s.searchParams.set("columns", e.join(","))
                            }
                        }
                        return new I({
                            method: "POST",
                            url: s,
                            headers: i,
                            schema: this.schema,
                            body: e,
                            fetch: null != (n = this.fetch) ? n : fetch,
                            urlLengthLimit: this.urlLengthLimit,
                            retry: this.retry
                        })
                    }
                    upsert(e, {
                        onConflict: t,
                        ignoreDuplicates: r = !1,
                        count: n,
                        defaultToNull: s = !0
                    } = {}) {
                        var i;
                        let {
                            url: a,
                            headers: o
                        } = this.cloneRequestState();
                        if (o.append("Prefer", `resolution=${r?"ignore":"merge"}-duplicates`), void 0 !== t && a.searchParams.set("on_conflict", t), n && o.append("Prefer", `count=${n}`), s || o.append("Prefer", "missing=default"), Array.isArray(e)) {
                            let t = e.reduce((e, t) => e.concat(Object.keys(t)), []);
                            if (t.length > 0) {
                                let e = [...new Set(t)].map(e => `"${e}"`);
                                a.searchParams.set("columns", e.join(","))
                            }
                        }
                        return new I({
                            method: "POST",
                            url: a,
                            headers: o,
                            schema: this.schema,
                            body: e,
                            fetch: null != (i = this.fetch) ? i : fetch,
                            urlLengthLimit: this.urlLengthLimit,
                            retry: this.retry
                        })
                    }
                    update(e, {
                        count: t
                    } = {}) {
                        var r;
                        let {
                            url: n,
                            headers: s
                        } = this.cloneRequestState();
                        return t && s.append("Prefer", `count=${t}`), new I({
                            method: "PATCH",
                            url: n,
                            headers: s,
                            schema: this.schema,
                            body: e,
                            fetch: null != (r = this.fetch) ? r : fetch,
                            urlLengthLimit: this.urlLengthLimit,
                            retry: this.retry
                        })
                    }
                    delete({
                        count: e
                    } = {}) {
                        var t;
                        let {
                            url: r,
                            headers: n
                        } = this.cloneRequestState();
                        return e && n.append("Prefer", `count=${e}`), new I({
                            method: "DELETE",
                            url: r,
                            headers: n,
                            schema: this.schema,
                            fetch: null != (t = this.fetch) ? t : fetch,
                            urlLengthLimit: this.urlLengthLimit,
                            retry: this.retry
                        })
                    }
                };

            function B(e) {
                return (B = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function L(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), r.push.apply(r, n)
                }
                return r
            }

            function D(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? L(Object(r), !0).forEach(function(t) {
                        ! function(e, t, r) {
                            var n;
                            (n = function(e, t) {
                                if ("object" != B(e) || !e) return e;
                                var r = e[Symbol.toPrimitive];
                                if (void 0 !== r) {
                                    var n = r.call(e, t || "default");
                                    if ("object" != B(n)) return n;
                                    throw TypeError("@@toPrimitive must return a primitive value.")
                                }
                                return ("string" === t ? String : Number)(e)
                            }(t, "string"), (t = "symbol" == B(n) ? n : n + "") in e) ? Object.defineProperty(e, t, {
                                value: r,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }): e[t] = r
                        }(e, t, r[t])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : L(Object(r)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    })
                }
                return e
            }
            var H = class e {
                constructor(e, {
                    headers: t = {},
                    schema: r,
                    fetch: n,
                    timeout: s,
                    urlLengthLimit: i = 8e3,
                    retry: a
                } = {}) {
                    this.url = e, this.headers = new Headers(t), this.schemaName = r, this.urlLengthLimit = i;
                    const o = null != n ? n : globalThis.fetch;
                    void 0 !== s && s > 0 ? this.fetch = (e, t) => {
                        let r = new AbortController,
                            n = setTimeout(() => r.abort(), s),
                            i = null == t ? void 0 : t.signal;
                        if (i) {
                            if (i.aborted) return clearTimeout(n), o(e, t);
                            let s = () => {
                                clearTimeout(n), r.abort()
                            };
                            return i.addEventListener("abort", s, {
                                once: !0
                            }), o(e, D(D({}, t), {}, {
                                signal: r.signal
                            })).finally(() => {
                                clearTimeout(n), i.removeEventListener("abort", s)
                            })
                        }
                        return o(e, D(D({}, t), {}, {
                            signal: r.signal
                        })).finally(() => clearTimeout(n))
                    } : this.fetch = o, this.retry = a
                }
                from(e) {
                    if (!e || "string" != typeof e || "" === e.trim()) throw Error("Invalid relation name: relation must be a non-empty string.");
                    return new N(new URL(`${this.url}/${e}`), {
                        headers: new Headers(this.headers),
                        schema: this.schemaName,
                        fetch: this.fetch,
                        urlLengthLimit: this.urlLengthLimit,
                        retry: this.retry
                    })
                }
                schema(t) {
                    return new e(this.url, {
                        headers: this.headers,
                        schema: t,
                        fetch: this.fetch,
                        urlLengthLimit: this.urlLengthLimit,
                        retry: this.retry
                    })
                }
                rpc(e, t = {}, {
                    head: r = !1,
                    get: n = !1,
                    count: s
                } = {}) {
                    var i;
                    let a, o, l = new URL(`${this.url}/rpc/${e}`),
                        c = e => null !== e && "object" == typeof e && (!Array.isArray(e) || e.some(c)),
                        h = r && Object.values(t).some(c);
                    h ? (a = "POST", o = t) : r || n ? (a = r ? "HEAD" : "GET", Object.entries(t).filter(([e, t]) => void 0 !== t).map(([e, t]) => [e, Array.isArray(t) ? `{${t.join(",")}}` : `${t}`]).forEach(([e, t]) => {
                        l.searchParams.append(e, t)
                    })) : (a = "POST", o = t);
                    let u = new Headers(this.headers);
                    return h ? u.set("Prefer", s ? `count=${s},return=minimal` : "return=minimal") : s && u.set("Prefer", `count=${s}`), new I({
                        method: a,
                        url: l,
                        headers: u,
                        schema: this.schemaName,
                        body: o,
                        fetch: null != (i = this.fetch) ? i : fetch,
                        urlLengthLimit: this.urlLengthLimit,
                        retry: this.retry
                    })
                }
            };
            class q {
                static detectEnvironment() {
                    var e;
                    if ("u" > typeof WebSocket) return {
                        type: "native",
                        wsConstructor: WebSocket
                    };
                    let t = globalThis;
                    if ("u" > typeof globalThis && void 0 !== t.WebSocket) return {
                        type: "native",
                        wsConstructor: t.WebSocket
                    };
                    let n = void 0 !== r.g ? r.g : void 0;
                    if (n && void 0 !== n.WebSocket) return {
                        type: "native",
                        wsConstructor: n.WebSocket
                    };
                    if ("u" > typeof globalThis && void 0 !== t.WebSocketPair && void 0 === globalThis.WebSocket) return {
                        type: "cloudflare",
                        error: "Cloudflare Workers detected. WebSocket clients are not supported in Cloudflare Workers.",
                        workaround: "Use Cloudflare Workers WebSocket API for server-side WebSocket handling, or deploy to a different runtime."
                    };
                    if ("u" > typeof globalThis && t.EdgeRuntime || "u" > typeof navigator && (null == (e = navigator.userAgent) ? void 0 : e.includes("Vercel-Edge"))) return {
                        type: "unsupported",
                        error: "Edge runtime detected (Vercel Edge/Netlify Edge). WebSockets are not supported in edge functions.",
                        workaround: "Use serverless functions or a different deployment target for WebSocket functionality."
                    };
                    let s = globalThis.process;
                    if (s) {
                        let e = s.versions;
                        if (e && e.node) {
                            let t = parseInt(e.node.replace(/^v/, "").split(".")[0]);
                            return t >= 22 ? void 0 !== globalThis.WebSocket ? {
                                type: "native",
                                wsConstructor: globalThis.WebSocket
                            } : {
                                type: "unsupported",
                                error: `Node.js ${t} detected but native WebSocket not found.`,
                                workaround: "Provide a WebSocket implementation via the transport option."
                            } : {
                                type: "unsupported",
                                error: `Node.js ${t} detected without native WebSocket support.`,
                                workaround: 'For Node.js < 22, install "ws" package and provide it via the transport option:\nimport ws from "ws"\nnew RealtimeClient(url, { transport: ws })'
                            }
                        }
                    }
                    return {
                        type: "unsupported",
                        error: "Unknown JavaScript runtime without WebSocket support.",
                        workaround: "Ensure you're running in a supported environment (browser, Node.js, Deno) or provide a custom WebSocket implementation."
                    }
                }
                static getWebSocketConstructor() {
                    let e = this.detectEnvironment();
                    if (e.wsConstructor) return e.wsConstructor;
                    let t = e.error || "WebSocket not supported in this environment.";
                    throw e.workaround && (t += `

Suggested solution: ${e.workaround}`), Error(t)
                }
                static isWebSocketSupported() {
                    try {
                        let e = this.detectEnvironment();
                        return "native" === e.type || "ws" === e.type
                    } catch (e) {
                        return !1
                    }
                }
            }
            let M = "2.0.0",
                J = "errored",
                F = "joined",
                W = {
                    close: "phx_close",
                    error: "phx_error",
                    join: "phx_join",
                    reply: "phx_reply",
                    leave: "phx_leave",
                    access_token: "access_token"
                };
            class V {
                constructor(e) {
                    this.HEADER_LENGTH = 1, this.USER_BROADCAST_PUSH_META_LENGTH = 6, this.KINDS = {
                        userBroadcastPush: 3,
                        userBroadcast: 4
                    }, this.BINARY_ENCODING = 0, this.JSON_ENCODING = 1, this.BROADCAST_EVENT = "broadcast", this.allowedMetadataKeys = [], this.allowedMetadataKeys = null != e ? e : []
                }
                encode(e, t) {
                    return e.event !== this.BROADCAST_EVENT || e.payload instanceof ArrayBuffer || "string" != typeof e.payload.event ? t(JSON.stringify([e.join_ref, e.ref, e.topic, e.event, e.payload])) : t(this._binaryEncodeUserBroadcastPush(e))
                }
                _binaryEncodeUserBroadcastPush(e) {
                    var t;
                    return this._isArrayBuffer(null == (t = e.payload) ? void 0 : t.payload) ? this._encodeBinaryUserBroadcastPush(e) : this._encodeJsonUserBroadcastPush(e)
                }
                _encodeBinaryUserBroadcastPush(e) {
                    var t, r;
                    let n = null != (r = null == (t = e.payload) ? void 0 : t.payload) ? r : new ArrayBuffer(0);
                    return this._encodeUserBroadcastPush(e, this.BINARY_ENCODING, n)
                }
                _encodeJsonUserBroadcastPush(e) {
                    var t, r;
                    let n = null != (r = null == (t = e.payload) ? void 0 : t.payload) ? r : {},
                        s = new TextEncoder().encode(JSON.stringify(n)).buffer;
                    return this._encodeUserBroadcastPush(e, this.JSON_ENCODING, s)
                }
                _encodeUserBroadcastPush(e, t, r) {
                    let n = e.topic,
                        s = null != (f = e.ref) ? f : "",
                        i = null != (p = e.join_ref) ? p : "",
                        a = e.payload.event,
                        o = this.allowedMetadataKeys ? this._pick(e.payload, this.allowedMetadataKeys) : {},
                        l = 0 === Object.keys(o).length ? "" : JSON.stringify(o);
                    if (i.length > 255) throw Error(`joinRef length ${i.length} exceeds maximum of 255`);
                    if (s.length > 255) throw Error(`ref length ${s.length} exceeds maximum of 255`);
                    if (n.length > 255) throw Error(`topic length ${n.length} exceeds maximum of 255`);
                    if (a.length > 255) throw Error(`userEvent length ${a.length} exceeds maximum of 255`);
                    if (l.length > 255) throw Error(`metadata length ${l.length} exceeds maximum of 255`);
                    let c = this.USER_BROADCAST_PUSH_META_LENGTH + i.length + s.length + n.length + a.length + l.length,
                        h = new ArrayBuffer(this.HEADER_LENGTH + c),
                        u = new DataView(h),
                        d = 0;
                    u.setUint8(d++, this.KINDS.userBroadcastPush), u.setUint8(d++, i.length), u.setUint8(d++, s.length), u.setUint8(d++, n.length), u.setUint8(d++, a.length), u.setUint8(d++, l.length), u.setUint8(d++, t), Array.from(i, e => u.setUint8(d++, e.charCodeAt(0))), Array.from(s, e => u.setUint8(d++, e.charCodeAt(0))), Array.from(n, e => u.setUint8(d++, e.charCodeAt(0))), Array.from(a, e => u.setUint8(d++, e.charCodeAt(0))), Array.from(l, e => u.setUint8(d++, e.charCodeAt(0)));
                    var f, p, g = new Uint8Array(h.byteLength + r.byteLength);
                    return g.set(new Uint8Array(h), 0), g.set(new Uint8Array(r), h.byteLength), g.buffer
                }
                decode(e, t) {
                    if (this._isArrayBuffer(e)) return t(this._binaryDecode(e));
                    if ("string" == typeof e) {
                        let [r, n, s, i, a] = JSON.parse(e);
                        return t({
                            join_ref: r,
                            ref: n,
                            topic: s,
                            event: i,
                            payload: a
                        })
                    }
                    return t({})
                }
                _binaryDecode(e) {
                    let t = new DataView(e),
                        r = t.getUint8(0),
                        n = new TextDecoder;
                    if (r === this.KINDS.userBroadcast) return this._decodeUserBroadcast(e, t, n)
                }
                _decodeUserBroadcast(e, t, r) {
                    let n = t.getUint8(1),
                        s = t.getUint8(2),
                        i = t.getUint8(3),
                        a = t.getUint8(4),
                        o = this.HEADER_LENGTH + 4,
                        l = r.decode(e.slice(o, o + n));
                    o += n;
                    let c = r.decode(e.slice(o, o + s));
                    o += s;
                    let h = r.decode(e.slice(o, o + i));
                    o += i;
                    let u = e.slice(o, e.byteLength),
                        d = a === this.JSON_ENCODING ? JSON.parse(r.decode(u)) : u,
                        f = {
                            type: this.BROADCAST_EVENT,
                            event: c,
                            payload: d
                        };
                    return i > 0 && (f.meta = JSON.parse(h)), {
                        join_ref: null,
                        ref: null,
                        topic: l,
                        event: this.BROADCAST_EVENT,
                        payload: f
                    }
                }
                _isArrayBuffer(e) {
                    var t;
                    return e instanceof ArrayBuffer || (null == (t = null == e ? void 0 : e.constructor) ? void 0 : t.name) === "ArrayBuffer"
                }
                _pick(e, t) {
                    return e && "object" == typeof e ? Object.fromEntries(Object.entries(e).filter(([e]) => t.includes(e))) : {}
                }
            }(l = p || (p = {})).abstime = "abstime", l.bool = "bool", l.date = "date", l.daterange = "daterange", l.float4 = "float4", l.float8 = "float8", l.int2 = "int2", l.int4 = "int4", l.int4range = "int4range", l.int8 = "int8", l.int8range = "int8range", l.json = "json", l.jsonb = "jsonb", l.money = "money", l.numeric = "numeric", l.oid = "oid", l.reltime = "reltime", l.text = "text", l.time = "time", l.timestamp = "timestamp", l.timestamptz = "timestamptz", l.timetz = "timetz", l.tsrange = "tsrange", l.tstzrange = "tstzrange";
            let K = (e, t, r = {}) => {
                    var n;
                    let s = null != (n = r.skipTypes) ? n : [];
                    return t ? Object.keys(t).reduce((r, n) => (r[n] = z(n, e, t, s), r), {}) : {}
                },
                z = (e, t, r, n) => {
                    let s = t.find(t => t.name === e),
                        i = null == s ? void 0 : s.type,
                        a = r[e];
                    return i && !n.includes(i) ? G(i, a) : Y(a)
                },
                G = (e, t) => {
                    if ("_" === e.charAt(0)) return ee(t, e.slice(1, e.length));
                    switch (e) {
                        case p.bool:
                            return X(t);
                        case p.float4:
                        case p.float8:
                        case p.int2:
                        case p.int4:
                        case p.int8:
                        case p.numeric:
                        case p.oid:
                            return Q(t);
                        case p.json:
                        case p.jsonb:
                            return Z(t);
                        case p.timestamp:
                            return et(t);
                        case p.abstime:
                        case p.date:
                        case p.daterange:
                        case p.int4range:
                        case p.int8range:
                        case p.money:
                        case p.reltime:
                        case p.text:
                        case p.time:
                        case p.timestamptz:
                        case p.timetz:
                        case p.tsrange:
                        case p.tstzrange:
                        default:
                            return Y(t)
                    }
                },
                Y = e => e,
                X = e => {
                    switch (e) {
                        case "t":
                            return !0;
                        case "f":
                            return !1;
                        default:
                            return e
                    }
                },
                Q = e => {
                    if ("string" == typeof e) {
                        let t = parseFloat(e);
                        if (!Number.isNaN(t)) return t
                    }
                    return e
                },
                Z = e => {
                    if ("string" == typeof e) try {
                        return JSON.parse(e)
                    } catch (e) {}
                    return e
                },
                ee = (e, t) => {
                    if ("string" != typeof e) return e;
                    let r = e.length - 1,
                        n = e[r];
                    if ("{" === e[0] && "}" === n) {
                        let n, s = e.slice(1, r);
                        try {
                            n = JSON.parse("[" + s + "]")
                        } catch (e) {
                            n = s ? s.split(",") : []
                        }
                        return n.map(e => G(t, e))
                    }
                    return e
                },
                et = e => "string" == typeof e ? e.replace(" ", "T") : e,
                er = e => {
                    let t = new URL(e);
                    return t.protocol = t.protocol.replace(/^ws/i, "http"), t.pathname = t.pathname.replace(/\/+$/, "").replace(/\/socket\/websocket$/i, "").replace(/\/socket$/i, "").replace(/\/websocket$/i, ""), "" === t.pathname || "/" === t.pathname ? t.pathname = "/api/broadcast" : t.pathname = t.pathname + "/api/broadcast", t.href
                };
            var en = e => "function" == typeof e ? e : function() {
                    return e
                },
                es = "u" > typeof window ? window : null,
                ei = ("u" > typeof self ? self : null) || es || globalThis,
                ea = "closed",
                eo = "errored",
                el = "joined",
                ec = "joining",
                eh = "leaving",
                eu = "phx_close",
                ed = "phx_error",
                ef = "phx_reply",
                ep = "phx_leave",
                eg = "websocket",
                em = "base64url.bearer.phx.",
                ey = class {
                    constructor(e, t, r, n) {
                        this.channel = e, this.event = t, this.payload = r || function() {
                            return {}
                        }, this.receivedResp = null, this.timeout = n, this.timeoutTimer = null, this.recHooks = [], this.sent = !1, this.ref = void 0
                    }
                    resend(e) {
                        this.timeout = e, this.reset(), this.send()
                    }
                    send() {
                        this.hasReceived("timeout") || (this.startTimeout(), this.sent = !0, this.channel.socket.push({
                            topic: this.channel.topic,
                            event: this.event,
                            payload: this.payload(),
                            ref: this.ref,
                            join_ref: this.channel.joinRef()
                        }))
                    }
                    receive(e, t) {
                        return this.hasReceived(e) && t(this.receivedResp.response), this.recHooks.push({
                            status: e,
                            callback: t
                        }), this
                    }
                    reset() {
                        this.cancelRefEvent(), this.ref = null, this.refEvent = null, this.receivedResp = null, this.sent = !1
                    }
                    destroy() {
                        this.cancelRefEvent(), this.cancelTimeout()
                    }
                    matchReceive({
                        status: e,
                        response: t,
                        _ref: r
                    }) {
                        this.recHooks.filter(t => t.status === e).forEach(e => e.callback(t))
                    }
                    cancelRefEvent() {
                        this.refEvent && this.channel.off(this.refEvent)
                    }
                    cancelTimeout() {
                        clearTimeout(this.timeoutTimer), this.timeoutTimer = null
                    }
                    startTimeout() {
                        this.timeoutTimer && this.cancelTimeout(), this.ref = this.channel.socket.makeRef(), this.refEvent = this.channel.replyEventName(this.ref), this.channel.on(this.refEvent, e => {
                            this.cancelRefEvent(), this.cancelTimeout(), this.receivedResp = e, this.matchReceive(e)
                        }), this.timeoutTimer = setTimeout(() => {
                            this.trigger("timeout", {})
                        }, this.timeout)
                    }
                    hasReceived(e) {
                        return this.receivedResp && this.receivedResp.status === e
                    }
                    trigger(e, t) {
                        this.channel.trigger(this.refEvent, {
                            status: e,
                            response: t
                        })
                    }
                },
                eb = class {
                    constructor(e, t) {
                        this.callback = e, this.timerCalc = t, this.timer = void 0, this.tries = 0
                    }
                    reset() {
                        this.tries = 0, clearTimeout(this.timer)
                    }
                    scheduleTimeout() {
                        clearTimeout(this.timer), this.timer = setTimeout(() => {
                            this.tries = this.tries + 1, this.callback()
                        }, this.timerCalc(this.tries + 1))
                    }
                },
                ew = class {
                    constructor(e, t, r) {
                        this.state = ea, this.topic = e, this.params = en(t || {}), this.socket = r, this.bindings = [], this.bindingRef = 0, this.timeout = this.socket.timeout, this.joinedOnce = !1, this.joinPush = new ey(this, "phx_join", this.params, this.timeout), this.pushBuffer = [], this.stateChangeRefs = [], this.rejoinTimer = new eb(() => {
                            this.socket.isConnected() && this.rejoin()
                        }, this.socket.rejoinAfterMs), this.stateChangeRefs.push(this.socket.onError(() => this.rejoinTimer.reset())), this.stateChangeRefs.push(this.socket.onOpen(() => {
                            this.rejoinTimer.reset(), this.isErrored() && this.rejoin()
                        })), this.joinPush.receive("ok", () => {
                            this.state = el, this.rejoinTimer.reset(), this.pushBuffer.forEach(e => e.send()), this.pushBuffer = []
                        }), this.joinPush.receive("error", e => {
                            this.state = eo, this.socket.hasLogger() && this.socket.log("channel", `error ${this.topic}`, e), this.socket.isConnected() && this.rejoinTimer.scheduleTimeout()
                        }), this.onClose(() => {
                            this.rejoinTimer.reset(), this.socket.hasLogger() && this.socket.log("channel", `close ${this.topic}`), this.state = ea, this.socket.remove(this)
                        }), this.onError(e => {
                            this.socket.hasLogger() && this.socket.log("channel", `error ${this.topic}`, e), this.isJoining() && this.joinPush.reset(), this.state = eo, this.socket.isConnected() && this.rejoinTimer.scheduleTimeout()
                        }), this.joinPush.receive("timeout", () => {
                            this.socket.hasLogger() && this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout), new ey(this, ep, en({}), this.timeout).send(), this.state = eo, this.joinPush.reset(), this.socket.isConnected() && this.rejoinTimer.scheduleTimeout()
                        }), this.on(ef, (e, t) => {
                            this.trigger(this.replyEventName(t), e)
                        })
                    }
                    join(e = this.timeout) {
                        if (!this.joinedOnce) return this.timeout = e, this.joinedOnce = !0, this.rejoin(), this.joinPush;
                        throw Error("tried to join multiple times. 'join' can only be called a single time per channel instance")
                    }
                    teardown() {
                        this.pushBuffer.forEach(e => e.destroy()), this.pushBuffer = [], this.rejoinTimer.reset(), this.joinPush.destroy(), this.state = ea, this.bindings = []
                    }
                    onClose(e) {
                        this.on(eu, e)
                    }
                    onError(e) {
                        return this.on(ed, t => e(t))
                    }
                    on(e, t) {
                        let r = this.bindingRef++;
                        return this.bindings.push({
                            event: e,
                            ref: r,
                            callback: t
                        }), r
                    }
                    off(e, t) {
                        this.bindings = this.bindings.filter(r => r.event !== e || void 0 !== t && t !== r.ref)
                    }
                    canPush() {
                        return this.socket.isConnected() && this.isJoined()
                    }
                    push(e, t, r = this.timeout) {
                        if (t = t || {}, !this.joinedOnce) throw Error(`tried to push '${e}' to '${this.topic}' before joining. Use channel.join() before pushing events`);
                        let n = new ey(this, e, function() {
                            return t
                        }, r);
                        return this.canPush() ? n.send() : (n.startTimeout(), this.pushBuffer.push(n)), n
                    }
                    leave(e = this.timeout) {
                        this.rejoinTimer.reset(), this.joinPush.cancelTimeout(), this.state = eh;
                        let t = () => {
                                this.socket.hasLogger() && this.socket.log("channel", `leave ${this.topic}`), this.trigger(eu, "leave")
                            },
                            r = new ey(this, ep, en({}), e);
                        return r.receive("ok", () => t()).receive("timeout", () => t()), r.send(), this.canPush() || r.trigger("ok", {}), r
                    }
                    onMessage(e, t, r) {
                        return t
                    }
                    filterBindings(e, t, r) {
                        return !0
                    }
                    isMember(e, t, r, n) {
                        return this.topic === e && (!n || n === this.joinRef() || (this.socket.hasLogger() && this.socket.log("channel", "dropping outdated message", {
                            topic: e,
                            event: t,
                            payload: r,
                            joinRef: n
                        }), !1))
                    }
                    joinRef() {
                        return this.joinPush.ref
                    }
                    rejoin(e = this.timeout) {
                        this.isLeaving() || (this.socket.leaveOpenTopic(this.topic), this.state = ec, this.joinPush.resend(e))
                    }
                    trigger(e, t, r, n) {
                        let s = this.onMessage(e, t, r, n);
                        if (t && !s) throw Error("channel onMessage callbacks must return the payload, modified or unmodified");
                        let i = this.bindings.filter(n => n.event === e && this.filterBindings(n, t, r));
                        for (let e = 0; e < i.length; e++) i[e].callback(s, r, n || this.joinRef())
                    }
                    replyEventName(e) {
                        return `chan_reply_${e}`
                    }
                    isClosed() {
                        return this.state === ea
                    }
                    isErrored() {
                        return this.state === eo
                    }
                    isJoined() {
                        return this.state === el
                    }
                    isJoining() {
                        return this.state === ec
                    }
                    isLeaving() {
                        return this.state === eh
                    }
                },
                ev = class {
                    static request(e, t, r, n, s, i, a) {
                        if (ei.XDomainRequest) {
                            let r = new ei.XDomainRequest;
                            return this.xdomainRequest(r, e, t, n, s, i, a)
                        }
                        if (ei.XMLHttpRequest) {
                            let o = new ei.XMLHttpRequest;
                            return this.xhrRequest(o, e, t, r, n, s, i, a)
                        }
                        if (ei.fetch && ei.AbortController) return this.fetchRequest(e, t, r, n, s, i, a);
                        throw Error("No suitable XMLHttpRequest implementation found")
                    }
                    static fetchRequest(e, t, r, n, s, i, a) {
                        let o = {
                                method: e,
                                headers: r,
                                body: n
                            },
                            l = null;
                        return s && (l = new AbortController, setTimeout(() => l.abort(), s), o.signal = l.signal), ei.fetch(t, o).then(e => e.text()).then(e => this.parseJSON(e)).then(e => a && a(e)).catch(e => {
                            "AbortError" === e.name && i ? i() : a && a(null)
                        }), l
                    }
                    static xdomainRequest(e, t, r, n, s, i, a) {
                        return e.timeout = s, e.open(t, r), e.onload = () => {
                            let t = this.parseJSON(e.responseText);
                            a && a(t)
                        }, i && (e.ontimeout = i), e.onprogress = () => {}, e.send(n), e
                    }
                    static xhrRequest(e, t, r, n, s, i, a, o) {
                        for (let [s, a] of (e.open(t, r, !0), e.timeout = i, Object.entries(n))) e.setRequestHeader(s, a);
                        return e.onerror = () => o && o(null), e.onreadystatechange = () => {
                            4 === e.readyState && o && o(this.parseJSON(e.responseText))
                        }, a && (e.ontimeout = a), e.send(s), e
                    }
                    static parseJSON(e) {
                        if (!e || "" === e) return null;
                        try {
                            return JSON.parse(e)
                        } catch {
                            return console && console.log("failed to parse JSON response", e), null
                        }
                    }
                    static serialize(e, t) {
                        let r = [];
                        for (var n in e) {
                            if (!Object.prototype.hasOwnProperty.call(e, n)) continue;
                            let s = t ? `${t}[${n}]` : n,
                                i = e[n];
                            "object" == typeof i ? r.push(this.serialize(i, s)) : r.push(encodeURIComponent(s) + "=" + encodeURIComponent(i))
                        }
                        return r.join("&")
                    }
                    static appendParams(e, t) {
                        if (0 === Object.keys(t).length) return e;
                        let r = e.match(/\?/) ? "&" : "?";
                        return `${e}${r}${this.serialize(t)}`
                    }
                },
                eE = class {
                    constructor(e, t) {
                        t && 2 === t.length && t[1].startsWith(em) && (this.authToken = atob(t[1].slice(em.length))), this.endPoint = null, this.token = null, this.skipHeartbeat = !0, this.reqs = new Set, this.awaitingBatchAck = !1, this.currentBatch = null, this.currentBatchTimer = null, this.batchBuffer = [], this.onopen = function() {}, this.onerror = function() {}, this.onmessage = function() {}, this.onclose = function() {}, this.pollEndpoint = this.normalizeEndpoint(e), this.readyState = 0, setTimeout(() => this.poll(), 0)
                    }
                    normalizeEndpoint(e) {
                        return e.replace("ws://", "http://").replace("wss://", "https://").replace(RegExp("(.*)/" + eg), "$1/longpoll")
                    }
                    endpointURL() {
                        return ev.appendParams(this.pollEndpoint, {
                            token: this.token
                        })
                    }
                    closeAndRetry(e, t, r) {
                        this.close(e, t, r), this.readyState = 0
                    }
                    ontimeout() {
                        this.onerror("timeout"), this.closeAndRetry(1005, "timeout", !1)
                    }
                    isActive() {
                        return 1 === this.readyState || 0 === this.readyState
                    }
                    poll() {
                        let e = {
                            Accept: "application/json"
                        };
                        this.authToken && (e["X-Phoenix-AuthToken"] = this.authToken), this.ajax("GET", e, null, () => this.ontimeout(), e => {
                            if (e) {
                                var {
                                    status: t,
                                    token: r,
                                    messages: n
                                } = e;
                                if (410 === t && null !== this.token) {
                                    this.onerror(410), this.closeAndRetry(3410, "session_gone", !1);
                                    return
                                }
                                this.token = r
                            } else t = 0;
                            switch (t) {
                                case 200:
                                    n.forEach(e => {
                                        setTimeout(() => this.onmessage({
                                            data: e
                                        }), 0)
                                    }), this.poll();
                                    break;
                                case 204:
                                    this.poll();
                                    break;
                                case 410:
                                    this.readyState = 1, this.onopen({}), this.poll();
                                    break;
                                case 403:
                                    this.onerror(403), this.close(1008, "forbidden", !1);
                                    break;
                                case 0:
                                case 500:
                                    this.onerror(500), this.closeAndRetry(1011, "internal server error", 500);
                                    break;
                                default:
                                    throw Error(`unhandled poll status ${t}`)
                            }
                        })
                    }
                    send(e) {
                        "string" != typeof e && (e = (e => {
                            let t = "",
                                r = new Uint8Array(e),
                                n = r.byteLength;
                            for (let e = 0; e < n; e++) t += String.fromCharCode(r[e]);
                            return btoa(t)
                        })(e)), this.currentBatch ? this.currentBatch.push(e) : this.awaitingBatchAck ? this.batchBuffer.push(e) : (this.currentBatch = [e], this.currentBatchTimer = setTimeout(() => {
                            this.batchSend(this.currentBatch), this.currentBatch = null
                        }, 0))
                    }
                    batchSend(e) {
                        this.awaitingBatchAck = !0, this.ajax("POST", {
                            "Content-Type": "application/x-ndjson"
                        }, e.join("\n"), () => this.onerror("timeout"), e => {
                            this.awaitingBatchAck = !1, e && 200 === e.status ? this.batchBuffer.length > 0 && (this.batchSend(this.batchBuffer), this.batchBuffer = []) : (this.onerror(e && e.status), this.closeAndRetry(1011, "internal server error", !1))
                        })
                    }
                    close(e, t, r) {
                        for (let e of this.reqs) e.abort();
                        this.readyState = 3;
                        let n = Object.assign({
                            code: 1e3,
                            reason: void 0,
                            wasClean: !0
                        }, {
                            code: e,
                            reason: t,
                            wasClean: r
                        });
                        this.batchBuffer = [], clearTimeout(this.currentBatchTimer), this.currentBatchTimer = null, "u" > typeof CloseEvent ? this.onclose(new CloseEvent("close", n)) : this.onclose(n)
                    }
                    ajax(e, t, r, n, s) {
                        let i, a = () => {
                            this.reqs.delete(i), n()
                        };
                        i = ev.request(e, this.endpointURL(), t, r, this.timeout, a, e => {
                            this.reqs.delete(i), this.isActive() && s(e)
                        }), this.reqs.add(i)
                    }
                },
                ek = class e {
                    constructor(t, r = {}) {
                        let n = r.events || {
                            state: "presence_state",
                            diff: "presence_diff"
                        };
                        this.state = {}, this.pendingDiffs = [], this.channel = t, this.joinRef = null, this.caller = {
                            onJoin: function() {},
                            onLeave: function() {},
                            onSync: function() {}
                        }, this.channel.on(n.state, t => {
                            let {
                                onJoin: r,
                                onLeave: n,
                                onSync: s
                            } = this.caller;
                            this.joinRef = this.channel.joinRef(), this.state = e.syncState(this.state, t, r, n), this.pendingDiffs.forEach(t => {
                                this.state = e.syncDiff(this.state, t, r, n)
                            }), this.pendingDiffs = [], s()
                        }), this.channel.on(n.diff, t => {
                            let {
                                onJoin: r,
                                onLeave: n,
                                onSync: s
                            } = this.caller;
                            this.inPendingSyncState() ? this.pendingDiffs.push(t) : (this.state = e.syncDiff(this.state, t, r, n), s())
                        })
                    }
                    onJoin(e) {
                        this.caller.onJoin = e
                    }
                    onLeave(e) {
                        this.caller.onLeave = e
                    }
                    onSync(e) {
                        this.caller.onSync = e
                    }
                    list(t) {
                        return e.list(this.state, t)
                    }
                    inPendingSyncState() {
                        return !this.joinRef || this.joinRef !== this.channel.joinRef()
                    }
                    static syncState(e, t, r, n) {
                        let s = this.clone(e),
                            i = {},
                            a = {};
                        return this.map(s, (e, r) => {
                            t[e] || (a[e] = r)
                        }), this.map(t, (e, t) => {
                            let r = s[e];
                            if (r) {
                                let n = t.metas.map(e => e.phx_ref),
                                    s = r.metas.map(e => e.phx_ref),
                                    o = t.metas.filter(e => 0 > s.indexOf(e.phx_ref)),
                                    l = r.metas.filter(e => 0 > n.indexOf(e.phx_ref));
                                o.length > 0 && (i[e] = t, i[e].metas = o), l.length > 0 && (a[e] = this.clone(r), a[e].metas = l)
                            } else i[e] = t
                        }), this.syncDiff(s, {
                            joins: i,
                            leaves: a
                        }, r, n)
                    }
                    static syncDiff(e, t, r, n) {
                        let {
                            joins: s,
                            leaves: i
                        } = this.clone(t);
                        return r || (r = function() {}), n || (n = function() {}), this.map(s, (t, n) => {
                            let s = e[t];
                            if (e[t] = this.clone(n), s) {
                                let r = e[t].metas.map(e => e.phx_ref),
                                    n = s.metas.filter(e => 0 > r.indexOf(e.phx_ref));
                                e[t].metas.unshift(...n)
                            }
                            r(t, s, n)
                        }), this.map(i, (t, r) => {
                            let s = e[t];
                            if (!s) return;
                            let i = r.metas.map(e => e.phx_ref);
                            s.metas = s.metas.filter(e => 0 > i.indexOf(e.phx_ref)), n(t, s, r), 0 === s.metas.length && delete e[t]
                        }), e
                    }
                    static list(e, t) {
                        return t || (t = function(e, t) {
                            return t
                        }), this.map(e, (e, r) => t(e, r))
                    }
                    static map(e, t) {
                        return Object.getOwnPropertyNames(e).map(r => t(r, e[r]))
                    }
                    static clone(e) {
                        return JSON.parse(JSON.stringify(e))
                    }
                },
                eS = {
                    HEADER_LENGTH: 1,
                    META_LENGTH: 4,
                    KINDS: {
                        push: 0,
                        reply: 1,
                        broadcast: 2
                    },
                    encode(e, t) {
                        return e.payload.constructor === ArrayBuffer ? t(this.binaryEncode(e)) : t(JSON.stringify([e.join_ref, e.ref, e.topic, e.event, e.payload]))
                    },
                    decode(e, t) {
                        if (e.constructor === ArrayBuffer) return t(this.binaryDecode(e)); {
                            let [r, n, s, i, a] = JSON.parse(e);
                            return t({
                                join_ref: r,
                                ref: n,
                                topic: s,
                                event: i,
                                payload: a
                            })
                        }
                    },
                    binaryEncode(e) {
                        let {
                            join_ref: t,
                            ref: r,
                            event: n,
                            topic: s,
                            payload: i
                        } = e, a = this.META_LENGTH + t.length + r.length + s.length + n.length, o = new ArrayBuffer(this.HEADER_LENGTH + a), l = new DataView(o), c = 0;
                        l.setUint8(c++, this.KINDS.push), l.setUint8(c++, t.length), l.setUint8(c++, r.length), l.setUint8(c++, s.length), l.setUint8(c++, n.length), Array.from(t, e => l.setUint8(c++, e.charCodeAt(0))), Array.from(r, e => l.setUint8(c++, e.charCodeAt(0))), Array.from(s, e => l.setUint8(c++, e.charCodeAt(0))), Array.from(n, e => l.setUint8(c++, e.charCodeAt(0)));
                        var h = new Uint8Array(o.byteLength + i.byteLength);
                        return h.set(new Uint8Array(o), 0), h.set(new Uint8Array(i), o.byteLength), h.buffer
                    },
                    binaryDecode(e) {
                        let t = new DataView(e),
                            r = t.getUint8(0),
                            n = new TextDecoder;
                        switch (r) {
                            case this.KINDS.push:
                                return this.decodePush(e, t, n);
                            case this.KINDS.reply:
                                return this.decodeReply(e, t, n);
                            case this.KINDS.broadcast:
                                return this.decodeBroadcast(e, t, n)
                        }
                    },
                    decodePush(e, t, r) {
                        let n = t.getUint8(1),
                            s = t.getUint8(2),
                            i = t.getUint8(3),
                            a = this.HEADER_LENGTH + this.META_LENGTH - 1,
                            o = r.decode(e.slice(a, a + n));
                        a += n;
                        let l = r.decode(e.slice(a, a + s));
                        a += s;
                        let c = r.decode(e.slice(a, a + i));
                        return a += i, {
                            join_ref: o,
                            ref: null,
                            topic: l,
                            event: c,
                            payload: e.slice(a, e.byteLength)
                        }
                    },
                    decodeReply(e, t, r) {
                        let n = t.getUint8(1),
                            s = t.getUint8(2),
                            i = t.getUint8(3),
                            a = t.getUint8(4),
                            o = this.HEADER_LENGTH + this.META_LENGTH,
                            l = r.decode(e.slice(o, o + n));
                        o += n;
                        let c = r.decode(e.slice(o, o + s));
                        o += s;
                        let h = r.decode(e.slice(o, o + i));
                        o += i;
                        let u = r.decode(e.slice(o, o + a));
                        return o += a, {
                            join_ref: l,
                            ref: c,
                            topic: h,
                            event: ef,
                            payload: {
                                status: u,
                                response: e.slice(o, e.byteLength)
                            }
                        }
                    },
                    decodeBroadcast(e, t, r) {
                        let n = t.getUint8(1),
                            s = t.getUint8(2),
                            i = this.HEADER_LENGTH + 2,
                            a = r.decode(e.slice(i, i + n));
                        i += n;
                        let o = r.decode(e.slice(i, i + s));
                        return i += s, {
                            join_ref: null,
                            ref: null,
                            topic: a,
                            event: o,
                            payload: e.slice(i, e.byteLength)
                        }
                    }
                },
                eA = class {
                    constructor(e, t = {}) {
                        this.stateChangeCallbacks = {
                            open: [],
                            close: [],
                            error: [],
                            message: []
                        }, this.channels = [], this.sendBuffer = [], this.ref = 0, this.fallbackRef = null, this.timeout = t.timeout || 1e4, this.transport = t.transport || ei.WebSocket || eE, this.conn = void 0, this.primaryPassedHealthCheck = !1, this.longPollFallbackMs = t.longPollFallbackMs, this.fallbackTimer = null;
                        let r = null;
                        try {
                            r = ei && ei.sessionStorage
                        } catch {}
                        this.sessionStore = t.sessionStorage || r, this.establishedConnections = 0, this.defaultEncoder = eS.encode.bind(eS), this.defaultDecoder = eS.decode.bind(eS), this.closeWasClean = !0, this.disconnecting = !1, this.binaryType = t.binaryType || "arraybuffer", this.connectClock = 1, this.pageHidden = !1, this.encode = void 0, this.decode = void 0, this.transport !== eE ? (this.encode = t.encode || this.defaultEncoder, this.decode = t.decode || this.defaultDecoder) : (this.encode = this.defaultEncoder, this.decode = this.defaultDecoder);
                        let n = null;
                        es && es.addEventListener && (es.addEventListener("pagehide", e => {
                            this.conn && (this.disconnect(), n = this.connectClock)
                        }), es.addEventListener("pageshow", e => {
                            n === this.connectClock && (n = null, this.connect())
                        }), es.addEventListener("visibilitychange", () => {
                            "hidden" === document.visibilityState ? this.pageHidden = !0 : (this.pageHidden = !1, this.isConnected() || this.closeWasClean || this.teardown(() => this.connect()))
                        })), this.heartbeatIntervalMs = t.heartbeatIntervalMs || 3e4, this.autoSendHeartbeat = t.autoSendHeartbeat ? ? !0, this.heartbeatCallback = t.heartbeatCallback ? ? (() => {}), this.rejoinAfterMs = e => t.rejoinAfterMs ? t.rejoinAfterMs(e) : [1e3, 2e3, 5e3][e - 1] || 1e4, this.reconnectAfterMs = e => t.reconnectAfterMs ? t.reconnectAfterMs(e) : [10, 50, 100, 150, 200, 250, 500, 1e3, 2e3][e - 1] || 5e3, this.logger = t.logger || null, !this.logger && t.debug && (this.logger = (e, t, r) => {
                            console.log(`${e}: ${t}`, r)
                        }), this.longpollerTimeout = t.longpollerTimeout || 2e4, this.params = en(t.params || {}), this.endPoint = `${e}/${eg}`, this.vsn = t.vsn || "2.0.0", this.heartbeatTimeoutTimer = null, this.heartbeatTimer = null, this.heartbeatSentAt = null, this.pendingHeartbeatRef = null, this.reconnectTimer = new eb(() => {
                            if (this.pageHidden) {
                                this.log("Not reconnecting as page is hidden!"), this.teardown();
                                return
                            }
                            this.teardown(async () => {
                                t.beforeReconnect && await t.beforeReconnect(), this.connect()
                            })
                        }, this.reconnectAfterMs), this.authToken = t.authToken
                    }
                    getLongPollTransport() {
                        return eE
                    }
                    replaceTransport(e) {
                        this.connectClock++, this.closeWasClean = !0, clearTimeout(this.fallbackTimer), this.reconnectTimer.reset(), this.conn && (this.conn.close(), this.conn = null), this.transport = e
                    }
                    protocol() {
                        return location.protocol.match(/^https/) ? "wss" : "ws"
                    }
                    endPointURL() {
                        let e = ev.appendParams(ev.appendParams(this.endPoint, this.params()), {
                            vsn: this.vsn
                        });
                        return "/" !== e.charAt(0) ? e : "/" === e.charAt(1) ? `${this.protocol()}:${e}` : `${this.protocol()}://${location.host}${e}`
                    }
                    disconnect(e, t, r) {
                        this.connectClock++, this.disconnecting = !0, this.closeWasClean = !0, clearTimeout(this.fallbackTimer), this.reconnectTimer.reset(), this.teardown(() => {
                            this.disconnecting = !1, e && e()
                        }, t, r)
                    }
                    connect(e) {
                        e && (console && console.log("passing params to connect is deprecated. Instead pass :params to the Socket constructor"), this.params = en(e)), (!this.conn || this.disconnecting) && (this.longPollFallbackMs && this.transport !== eE ? this.connectWithFallback(eE, this.longPollFallbackMs) : this.transportConnect())
                    }
                    log(e, t, r) {
                        this.logger && this.logger(e, t, r)
                    }
                    hasLogger() {
                        return null !== this.logger
                    }
                    onOpen(e) {
                        let t = this.makeRef();
                        return this.stateChangeCallbacks.open.push([t, e]), t
                    }
                    onClose(e) {
                        let t = this.makeRef();
                        return this.stateChangeCallbacks.close.push([t, e]), t
                    }
                    onError(e) {
                        let t = this.makeRef();
                        return this.stateChangeCallbacks.error.push([t, e]), t
                    }
                    onMessage(e) {
                        let t = this.makeRef();
                        return this.stateChangeCallbacks.message.push([t, e]), t
                    }
                    onHeartbeat(e) {
                        this.heartbeatCallback = e
                    }
                    ping(e) {
                        if (!this.isConnected()) return !1;
                        let t = this.makeRef(),
                            r = Date.now();
                        this.push({
                            topic: "phoenix",
                            event: "heartbeat",
                            payload: {},
                            ref: t
                        });
                        let n = this.onMessage(s => {
                            s.ref === t && (this.off([n]), e(Date.now() - r))
                        });
                        return !0
                    }
                    transportName(e) {
                        return e === eE ? "LongPoll" : e.name
                    }
                    transportConnect() {
                        let e;
                        this.connectClock++, this.closeWasClean = !1, this.authToken && (e = ["phoenix", `${em}${btoa(this.authToken).replace(/=/g,"")}`]), this.conn = new this.transport(this.endPointURL(), e), this.conn.binaryType = this.binaryType, this.conn.timeout = this.longpollerTimeout, this.conn.onopen = () => this.onConnOpen(), this.conn.onerror = e => this.onConnError(e), this.conn.onmessage = e => this.onConnMessage(e), this.conn.onclose = e => this.onConnClose(e)
                    }
                    getSession(e) {
                        return this.sessionStore && this.sessionStore.getItem(e)
                    }
                    storeSession(e, t) {
                        this.sessionStore && this.sessionStore.setItem(e, t)
                    }
                    connectWithFallback(e, t = 2500) {
                        let r, n;
                        clearTimeout(this.fallbackTimer);
                        let s = !1,
                            i = !0,
                            a = this.transportName(e),
                            o = t => {
                                this.log("transport", `falling back to ${a}...`, t), this.off([r, n]), i = !1, this.replaceTransport(e), this.transportConnect()
                            };
                        if (this.getSession(`phx:fallback:${a}`)) return o("memorized");
                        this.fallbackTimer = setTimeout(o, t), n = this.onError(e => {
                            this.log("transport", "error", e), i && !s && (clearTimeout(this.fallbackTimer), o(e))
                        }), this.fallbackRef && this.off([this.fallbackRef]), this.fallbackRef = this.onOpen(() => {
                            if (s = !0, !i) {
                                let t = this.transportName(e);
                                return this.primaryPassedHealthCheck || this.storeSession(`phx:fallback:${t}`, "true"), this.log("transport", `established ${t} fallback`)
                            }
                            clearTimeout(this.fallbackTimer), this.fallbackTimer = setTimeout(o, t), this.ping(e => {
                                this.log("transport", "connected to primary after", e), this.primaryPassedHealthCheck = !0, clearTimeout(this.fallbackTimer)
                            })
                        }), this.transportConnect()
                    }
                    clearHeartbeats() {
                        clearTimeout(this.heartbeatTimer), clearTimeout(this.heartbeatTimeoutTimer)
                    }
                    onConnOpen() {
                        this.hasLogger() && this.log("transport", `connected to ${this.endPointURL()}`), this.closeWasClean = !1, this.disconnecting = !1, this.establishedConnections++, this.flushSendBuffer(), this.reconnectTimer.reset(), this.autoSendHeartbeat && this.resetHeartbeat(), this.triggerStateCallbacks("open")
                    }
                    heartbeatTimeout() {
                        if (this.pendingHeartbeatRef) {
                            this.pendingHeartbeatRef = null, this.heartbeatSentAt = null, this.hasLogger() && this.log("transport", "heartbeat timeout. Attempting to re-establish connection");
                            try {
                                this.heartbeatCallback("timeout")
                            } catch (e) {
                                this.log("error", "error in heartbeat callback", e)
                            }
                            this.triggerChanError(Error("heartbeat timeout")), this.closeWasClean = !1, this.teardown(() => this.reconnectTimer.scheduleTimeout(), 1e3, "heartbeat timeout")
                        }
                    }
                    resetHeartbeat() {
                        this.conn && this.conn.skipHeartbeat || (this.pendingHeartbeatRef = null, this.clearHeartbeats(), this.heartbeatTimer = setTimeout(() => this.sendHeartbeat(), this.heartbeatIntervalMs))
                    }
                    teardown(e, t, r) {
                        if (!this.conn) return e && e();
                        let n = this.conn;
                        this.waitForBufferDone(n, () => {
                            t ? n.close(t, r || "") : n.close(), this.waitForSocketClosed(n, () => {
                                this.conn === n && (this.conn.onopen = function() {}, this.conn.onerror = function() {}, this.conn.onmessage = function() {}, this.conn.onclose = function() {}, this.conn = null), e && e()
                            })
                        })
                    }
                    waitForBufferDone(e, t, r = 1) {
                        5 !== r && e.bufferedAmount ? setTimeout(() => {
                            this.waitForBufferDone(e, t, r + 1)
                        }, 150 * r) : t()
                    }
                    waitForSocketClosed(e, t, r = 1) {
                        5 === r || 3 === e.readyState ? t() : setTimeout(() => {
                            this.waitForSocketClosed(e, t, r + 1)
                        }, 150 * r)
                    }
                    onConnClose(e) {
                        this.conn && (this.conn.onclose = () => {}), this.hasLogger() && this.log("transport", "close", e), this.triggerChanError(e), this.clearHeartbeats(), this.closeWasClean || this.reconnectTimer.scheduleTimeout(), this.triggerStateCallbacks("close", e)
                    }
                    onConnError(e) {
                        this.hasLogger() && this.log("transport", "error", e);
                        let t = this.transport,
                            r = this.establishedConnections;
                        this.triggerStateCallbacks("error", e, t, r), (t === this.transport || r > 0) && this.triggerChanError(e)
                    }
                    triggerChanError(e) {
                        this.channels.forEach(t => {
                            t.isErrored() || t.isLeaving() || t.isClosed() || t.trigger(ed, e)
                        })
                    }
                    connectionState() {
                        switch (this.conn && this.conn.readyState) {
                            case 0:
                                return "connecting";
                            case 1:
                                return "open";
                            case 2:
                                return "closing";
                            default:
                                return "closed"
                        }
                    }
                    isConnected() {
                        return "open" === this.connectionState()
                    }
                    remove(e) {
                        this.off(e.stateChangeRefs), this.channels = this.channels.filter(t => t !== e)
                    }
                    off(e) {
                        for (let t in this.stateChangeCallbacks) this.stateChangeCallbacks[t] = this.stateChangeCallbacks[t].filter(([t]) => -1 === e.indexOf(t))
                    }
                    channel(e, t = {}) {
                        let r = new ew(e, t, this);
                        return this.channels.push(r), r
                    }
                    push(e) {
                        if (this.hasLogger()) {
                            let {
                                topic: t,
                                event: r,
                                payload: n,
                                ref: s,
                                join_ref: i
                            } = e;
                            this.log("push", `${t} ${r} (${i}, ${s})`, n)
                        }
                        this.isConnected() ? this.encode(e, e => this.conn.send(e)) : this.sendBuffer.push(() => this.encode(e, e => this.conn.send(e)))
                    }
                    makeRef() {
                        let e = this.ref + 1;
                        return e === this.ref ? this.ref = 0 : this.ref = e, this.ref.toString()
                    }
                    sendHeartbeat() {
                        if (!this.isConnected()) {
                            try {
                                this.heartbeatCallback("disconnected")
                            } catch (e) {
                                this.log("error", "error in heartbeat callback", e)
                            }
                            return
                        }
                        if (this.pendingHeartbeatRef) return void this.heartbeatTimeout();
                        this.pendingHeartbeatRef = this.makeRef(), this.heartbeatSentAt = Date.now(), this.push({
                            topic: "phoenix",
                            event: "heartbeat",
                            payload: {},
                            ref: this.pendingHeartbeatRef
                        });
                        try {
                            this.heartbeatCallback("sent")
                        } catch (e) {
                            this.log("error", "error in heartbeat callback", e)
                        }
                        this.heartbeatTimeoutTimer = setTimeout(() => this.heartbeatTimeout(), this.heartbeatIntervalMs)
                    }
                    flushSendBuffer() {
                        this.isConnected() && this.sendBuffer.length > 0 && (this.sendBuffer.forEach(e => e()), this.sendBuffer = [])
                    }
                    onConnMessage(e) {
                        this.decode(e.data, e => {
                            let {
                                topic: t,
                                event: r,
                                payload: n,
                                ref: s,
                                join_ref: i
                            } = e;
                            if (s && s === this.pendingHeartbeatRef) {
                                let e = this.heartbeatSentAt ? Date.now() - this.heartbeatSentAt : void 0;
                                this.clearHeartbeats();
                                try {
                                    this.heartbeatCallback("ok" === n.status ? "ok" : "error", e)
                                } catch (e) {
                                    this.log("error", "error in heartbeat callback", e)
                                }
                                this.pendingHeartbeatRef = null, this.heartbeatSentAt = null, this.autoSendHeartbeat && (this.heartbeatTimer = setTimeout(() => this.sendHeartbeat(), this.heartbeatIntervalMs))
                            }
                            this.hasLogger() && this.log("receive", `${n.status||""} ${t} ${r} ${s&&"("+s+")"||""}`.trim(), n);
                            for (let e = 0; e < this.channels.length; e++) {
                                let a = this.channels[e];
                                a.isMember(t, r, n, i) && a.trigger(r, n, s, i)
                            }
                            this.triggerStateCallbacks("message", e)
                        })
                    }
                    triggerStateCallbacks(e, ...t) {
                        try {
                            this.stateChangeCallbacks[e].forEach(([r, n]) => {
                                try {
                                    n(...t)
                                } catch (t) {
                                    this.log("error", `error in ${e} callback`, t)
                                }
                            })
                        } catch (t) {
                            this.log("error", `error triggering ${e} callbacks`, t)
                        }
                    }
                    leaveOpenTopic(e) {
                        let t = this.channels.find(t => t.topic === e && (t.isJoined() || t.isJoining()));
                        t && (this.hasLogger() && this.log("transport", `leaving duplicate topic "${e}"`), t.leave())
                    }
                };
            class eT {
                constructor(e, t) {
                    const r = function(e) {
                        return (null == e ? void 0 : e.events) && {
                            events: e.events
                        }
                    }(t);
                    this.presence = new ek(e.getChannel(), r), this.presence.onJoin((t, r, n) => {
                        let s = eT.onJoinPayload(t, r, n);
                        e.getChannel().trigger("presence", s)
                    }), this.presence.onLeave((t, r, n) => {
                        let s = eT.onLeavePayload(t, r, n);
                        e.getChannel().trigger("presence", s)
                    }), this.presence.onSync(() => {
                        e.getChannel().trigger("presence", {
                            event: "sync"
                        })
                    })
                }
                get state() {
                    return eT.transformState(this.presence.state)
                }
                static transformState(e) {
                    return Object.getOwnPropertyNames(e = JSON.parse(JSON.stringify(e))).reduce((t, r) => {
                        let n = e[r];
                        return t[r] = eO(n), t
                    }, {})
                }
                static onJoinPayload(e, t, r) {
                    return {
                        event: "join",
                        key: e,
                        currentPresences: eC(t),
                        newPresences: eO(r)
                    }
                }
                static onLeavePayload(e, t, r) {
                    return {
                        event: "leave",
                        key: e,
                        currentPresences: eC(t),
                        leftPresences: eO(r)
                    }
                }
            }

            function eO(e) {
                return e.metas.map(e => (e.presence_ref = e.phx_ref, delete e.phx_ref, delete e.phx_ref_prev, e))
            }

            function eC(e) {
                return (null == e ? void 0 : e.metas) ? eO(e) : []
            }(c = g || (g = {})).SYNC = "sync", c.JOIN = "join", c.LEAVE = "leave";
            class e_ {
                get state() {
                    return this.presenceAdapter.state
                }
                constructor(e, t) {
                    this.channel = e, this.presenceAdapter = new eT(this.channel.channelAdapter, t)
                }
            }
            class eR {
                constructor(e, t, r) {
                    const n = function(e) {
                        return {
                            config: Object.assign({
                                broadcast: {
                                    ack: !1,
                                    self: !1
                                },
                                presence: {
                                    key: "",
                                    enabled: !1
                                },
                                private: !1
                            }, e.config)
                        }
                    }(r);
                    this.channel = e.getSocket().channel(t, n), this.socket = e
                }
                get state() {
                    return this.channel.state
                }
                set state(e) {
                    this.channel.state = e
                }
                get joinedOnce() {
                    return this.channel.joinedOnce
                }
                get joinPush() {
                    return this.channel.joinPush
                }
                get rejoinTimer() {
                    return this.channel.rejoinTimer
                }
                on(e, t) {
                    return this.channel.on(e, t)
                }
                off(e, t) {
                    this.channel.off(e, t)
                }
                subscribe(e) {
                    return this.channel.join(e)
                }
                unsubscribe(e) {
                    return this.channel.leave(e)
                }
                teardown() {
                    this.channel.teardown()
                }
                onClose(e) {
                    this.channel.onClose(e)
                }
                onError(e) {
                    return this.channel.onError(e)
                }
                push(e, t, r) {
                    let n;
                    try {
                        n = this.channel.push(e, t, r)
                    } catch (t) {
                        throw Error(`tried to push '${e}' to '${this.channel.topic}' before joining. Use channel.subscribe() before pushing events`)
                    }
                    if (this.channel.pushBuffer.length > 100) {
                        let e = this.channel.pushBuffer.shift();
                        e.cancelTimeout(), this.socket.log("channel", `discarded push due to buffer overflow: ${e.event}`, e.payload())
                    }
                    return n
                }
                updateJoinPayload(e) {
                    let t = this.channel.joinPush.payload();
                    this.channel.joinPush.payload = () => Object.assign(Object.assign({}, t), e)
                }
                canPush() {
                    return this.socket.isConnected() && this.state === F
                }
                isJoined() {
                    return this.state === F
                }
                isJoining() {
                    return "joining" === this.state
                }
                isClosed() {
                    return "closed" === this.state
                }
                isLeaving() {
                    return "leaving" === this.state
                }
                updateFilterBindings(e) {
                    this.channel.filterBindings = e
                }
                updatePayloadTransform(e) {
                    this.channel.onMessage = e
                }
                getChannel() {
                    return this.channel
                }
            }(h = m || (m = {})).ALL = "*", h.INSERT = "INSERT", h.UPDATE = "UPDATE", h.DELETE = "DELETE", (u = y || (y = {})).BROADCAST = "broadcast", u.PRESENCE = "presence", u.POSTGRES_CHANGES = "postgres_changes", u.SYSTEM = "system", (d = b || (b = {})).SUBSCRIBED = "SUBSCRIBED", d.TIMED_OUT = "TIMED_OUT", d.CLOSED = "CLOSED", d.CHANNEL_ERROR = "CHANNEL_ERROR";
            class eP {
                get state() {
                    return this.channelAdapter.state
                }
                set state(e) {
                    this.channelAdapter.state = e
                }
                get joinedOnce() {
                    return this.channelAdapter.joinedOnce
                }
                get timeout() {
                    return this.socket.timeout
                }
                get joinPush() {
                    return this.channelAdapter.joinPush
                }
                get rejoinTimer() {
                    return this.channelAdapter.rejoinTimer
                }
                constructor(e, t = {
                    config: {}
                }, r) {
                    var n, s;
                    if (this.topic = e, this.params = t, this.socket = r, this.bindings = {}, this.subTopic = e.replace(/^realtime:/i, ""), this.params.config = Object.assign({
                            broadcast: {
                                ack: !1,
                                self: !1
                            },
                            presence: {
                                key: "",
                                enabled: !1
                            },
                            private: !1
                        }, t.config), this.channelAdapter = new eR(this.socket.socketAdapter, e, this.params), this.presence = new e_(this), this._onClose(() => {
                            this.socket._remove(this)
                        }), this._updateFilterTransform(), this.broadcastEndpointURL = er(this.socket.socketAdapter.endPointURL()), this.private = this.params.config.private || !1, !this.private && (null == (s = null == (n = this.params.config) ? void 0 : n.broadcast) ? void 0 : s.replay)) throw Error(`tried to use replay on public channel '${this.topic}'. It must be a private channel.`)
                }
                subscribe(e, t = this.timeout) {
                    var r, n, s;
                    if (this.socket.isConnected() || this.socket.connect(), this.channelAdapter.isClosed()) {
                        let {
                            config: {
                                broadcast: i,
                                presence: a,
                                private: o
                            }
                        } = this.params, l = null != (n = null == (r = this.bindings.postgres_changes) ? void 0 : r.map(e => e.filter)) ? n : [], c = !!this.bindings[y.PRESENCE] && this.bindings[y.PRESENCE].length > 0 || (null == (s = this.params.config.presence) ? void 0 : s.enabled) === !0, h = {}, u = {
                            broadcast: i,
                            presence: Object.assign(Object.assign({}, a), {
                                enabled: c
                            }),
                            postgres_changes: l,
                            private: o
                        };
                        this.socket.accessTokenValue && (h.access_token = this.socket.accessTokenValue), this._onError(t => {
                            null == e || e(b.CHANNEL_ERROR, function(e) {
                                if (e instanceof Error) return e;
                                if ("string" == typeof e) return Error(e);
                                if (e && "object" == typeof e) {
                                    if ("number" == typeof e.code) {
                                        let t = "string" == typeof e.reason && e.reason ? ` (${e.reason})` : "";
                                        return Error(`socket closed: ${e.code}${t}`, {
                                            cause: e
                                        })
                                    }
                                    return Error("channel error: transport failure", {
                                        cause: e
                                    })
                                }
                                return Error("channel error: connection lost")
                            }(t))
                        }), this._onClose(() => null == e ? void 0 : e(b.CLOSED)), this.updateJoinPayload(Object.assign({
                            config: u
                        }, h)), this._updateFilterMessage(), this.channelAdapter.subscribe(t).receive("ok", async ({
                            postgres_changes: t
                        }) => {
                            if (this.socket._isManualToken() || this.socket.setAuth(), void 0 === t) {
                                null == e || e(b.SUBSCRIBED);
                                return
                            }
                            this._updatePostgresBindings(t, e)
                        }).receive("error", t => {
                            this.state = J;
                            let r = Object.values(t).join(", ") || "error";
                            null == e || e(b.CHANNEL_ERROR, Error(r, {
                                cause: t
                            }))
                        }).receive("timeout", () => {
                            null == e || e(b.TIMED_OUT)
                        })
                    }
                    return this
                }
                _updatePostgresBindings(e, t) {
                    var r;
                    let n = this.bindings.postgres_changes,
                        s = null != (r = null == n ? void 0 : n.length) ? r : 0,
                        i = [];
                    for (let r = 0; r < s; r++) {
                        let s = n[r],
                            {
                                filter: {
                                    event: a,
                                    schema: o,
                                    table: l,
                                    filter: c
                                }
                            } = s,
                            h = e && e[r];
                        if (h && h.event === a && eP.isFilterValueEqual(h.schema, o) && eP.isFilterValueEqual(h.table, l) && eP.isFilterValueEqual(h.filter, c)) i.push(Object.assign(Object.assign({}, s), {
                            id: h.id
                        }));
                        else {
                            this.unsubscribe(), this.state = J, null == t || t(b.CHANNEL_ERROR, Error("mismatch between server and client bindings for postgres changes"));
                            return
                        }
                    }
                    this.bindings.postgres_changes = i, this.state != J && t && t(b.SUBSCRIBED)
                }
                presenceState() {
                    return this.presence.state
                }
                async track(e, t = {}) {
                    return await this.send({
                        type: "presence",
                        event: "track",
                        payload: e
                    }, t.timeout || this.timeout)
                }
                async untrack(e = {}) {
                    return await this.send({
                        type: "presence",
                        event: "untrack"
                    }, e)
                }
                on(e, t, r) {
                    let n = this.channelAdapter.isJoined() || this.channelAdapter.isJoining(),
                        s = e === y.PRESENCE || e === y.POSTGRES_CHANGES;
                    if (n && s) throw this.socket.log("channel", `cannot add \`${e}\` callbacks for ${this.topic} after \`subscribe()\`.`), Error(`cannot add \`${e}\` callbacks for ${this.topic} after \`subscribe()\`.`);
                    return this._on(e, t, r)
                }
                async httpSend(e, t, r = {}) {
                    var n;
                    if (null == t) return Promise.reject(Error("Payload is required for httpSend()"));
                    let s = t instanceof ArrayBuffer || ArrayBuffer.isView(t),
                        i = {
                            apikey: this.socket.apiKey ? this.socket.apiKey : "",
                            "Content-Type": s ? "application/octet-stream" : "application/json"
                        };
                    this.socket.accessTokenValue && (i.Authorization = `Bearer ${this.socket.accessTokenValue}`);
                    let a = new URL(this.broadcastEndpointURL);
                    a.pathname += `/${encodeURIComponent(this.subTopic)}/events/${encodeURIComponent(e)}`, this.private && a.searchParams.set("private", "true");
                    let o = {
                            method: "POST",
                            headers: i,
                            body: s ? t : JSON.stringify(t)
                        },
                        l = await this._fetchWithTimeout(a.toString(), o, null != (n = r.timeout) ? n : this.timeout);
                    if (202 === l.status) return {
                        success: !0
                    };
                    let c = l.statusText;
                    try {
                        let e = await l.json();
                        c = e.error || e.message || c
                    } catch (e) {}
                    return Promise.reject(Error(c))
                }
                async send(e, t = {}) {
                    var r, n;
                    if (this.channelAdapter.canPush() || "broadcast" !== e.type) return new Promise(r => {
                        var n, s, i;
                        let a = this.channelAdapter.push(e.type, e, t.timeout || this.timeout);
                        "broadcast" !== e.type || (null == (i = null == (s = null == (n = this.params) ? void 0 : n.config) ? void 0 : s.broadcast) ? void 0 : i.ack) || r("ok"), a.receive("ok", () => r("ok")), a.receive("error", () => r("error")), a.receive("timeout", () => r("timed out"))
                    }); {
                        console.warn("Realtime send() is automatically falling back to REST API. This behavior will be deprecated in the future. Please use httpSend() explicitly for REST delivery.");
                        let {
                            event: s,
                            payload: i
                        } = e, a = {
                            apikey: this.socket.apiKey ? this.socket.apiKey : "",
                            "Content-Type": "application/json"
                        };
                        this.socket.accessTokenValue && (a.Authorization = `Bearer ${this.socket.accessTokenValue}`);
                        let o = {
                            method: "POST",
                            headers: a,
                            body: JSON.stringify({
                                messages: [{
                                    topic: this.subTopic,
                                    event: s,
                                    payload: i,
                                    private: this.private
                                }]
                            })
                        };
                        try {
                            let e = await this._fetchWithTimeout(this.broadcastEndpointURL, o, null != (r = t.timeout) ? r : this.timeout);
                            return await (null == (n = e.body) ? void 0 : n.cancel()), e.ok ? "ok" : "error"
                        } catch (e) {
                            if (e instanceof Error && "AbortError" === e.name) return "timed out";
                            return "error"
                        }
                    }
                }
                updateJoinPayload(e) {
                    this.channelAdapter.updateJoinPayload(e)
                }
                async unsubscribe(e = this.timeout) {
                    return new Promise(t => {
                        this.channelAdapter.unsubscribe(e).receive("ok", () => t("ok")).receive("timeout", () => t("timed out")).receive("error", () => t("error"))
                    })
                }
                teardown() {
                    this.channelAdapter.teardown()
                }
                async _fetchWithTimeout(e, t, r) {
                    let n = new AbortController,
                        s = setTimeout(() => n.abort(), r),
                        i = await this.socket.fetch(e, Object.assign(Object.assign({}, t), {
                            signal: n.signal
                        }));
                    return clearTimeout(s), i
                }
                _on(e, t, r) {
                    let n = e.toLocaleLowerCase(),
                        s = this.channelAdapter.on(e, r),
                        i = {
                            type: n,
                            filter: t,
                            callback: r,
                            ref: s
                        };
                    return this.bindings[n] ? this.bindings[n].push(i) : this.bindings[n] = [i], this._updateFilterMessage(), this
                }
                _onClose(e) {
                    this.channelAdapter.onClose(e)
                }
                _onError(e) {
                    this.channelAdapter.onError(e)
                }
                _updateFilterMessage() {
                    this.channelAdapter.updateFilterBindings((e, t, r) => {
                        var n, s, i, a, o, l, c;
                        let h = e.event.toLocaleLowerCase();
                        if (this._notThisChannelEvent(h, r)) return !1;
                        let u = null == (n = this.bindings[h]) ? void 0 : n.find(t => t.ref === e.ref);
                        if (!u) return !0;
                        if (!["broadcast", "presence", "postgres_changes"].includes(h)) return u.type.toLocaleLowerCase() === h;
                        if ("id" in u) {
                            let e = u.id,
                                r = null == (s = u.filter) ? void 0 : s.event;
                            return e && (null == (i = t.ids) ? void 0 : i.includes(e)) && ("*" === r || (null == r ? void 0 : r.toLocaleLowerCase()) === (null == (a = t.data) ? void 0 : a.type.toLocaleLowerCase()))
                        } {
                            let e = null == (l = null == (o = null == u ? void 0 : u.filter) ? void 0 : o.event) ? void 0 : l.toLocaleLowerCase();
                            return "*" === e || e === (null == (c = null == t ? void 0 : t.event) ? void 0 : c.toLocaleLowerCase())
                        }
                    })
                }
                _notThisChannelEvent(e, t) {
                    let {
                        close: r,
                        error: n,
                        leave: s,
                        join: i
                    } = W;
                    return t && [r, n, s, i].includes(e) && t !== this.joinPush.ref
                }
                _updateFilterTransform() {
                    this.channelAdapter.updatePayloadTransform((e, t, r) => {
                        if ("object" == typeof t && "ids" in t) {
                            let e = t.data,
                                {
                                    schema: r,
                                    table: n,
                                    commit_timestamp: s,
                                    type: i,
                                    errors: a
                                } = e;
                            return Object.assign(Object.assign({}, {
                                schema: r,
                                table: n,
                                commit_timestamp: s,
                                eventType: i,
                                new: {},
                                old: {},
                                errors: a
                            }), this._getPayloadRecords(e))
                        }
                        return t
                    })
                }
                copyBindings(e) {
                    if (this.joinedOnce) throw Error("cannot copy bindings into joined channel");
                    for (let t in e.bindings)
                        for (let r of e.bindings[t]) this._on(r.type, r.filter, r.callback)
                }
                static isFilterValueEqual(e, t) {
                    return (null != e ? e : void 0) === (null != t ? t : void 0)
                }
                _getPayloadRecords(e) {
                    let t = {
                        new: {},
                        old: {}
                    };
                    return ("INSERT" === e.type || "UPDATE" === e.type) && (t.new = K(e.columns, e.record)), ("UPDATE" === e.type || "DELETE" === e.type) && (t.old = K(e.columns, e.old_record)), t
                }
            }
            class ej {
                constructor(e, t) {
                    this.socket = new eA(e, t)
                }
                get timeout() {
                    return this.socket.timeout
                }
                get endPoint() {
                    return this.socket.endPoint
                }
                get transport() {
                    return this.socket.transport
                }
                get heartbeatIntervalMs() {
                    return this.socket.heartbeatIntervalMs
                }
                get heartbeatCallback() {
                    return this.socket.heartbeatCallback
                }
                set heartbeatCallback(e) {
                    this.socket.heartbeatCallback = e
                }
                get heartbeatTimer() {
                    return this.socket.heartbeatTimer
                }
                get pendingHeartbeatRef() {
                    return this.socket.pendingHeartbeatRef
                }
                get reconnectTimer() {
                    return this.socket.reconnectTimer
                }
                get vsn() {
                    return this.socket.vsn
                }
                get encode() {
                    return this.socket.encode
                }
                get decode() {
                    return this.socket.decode
                }
                get reconnectAfterMs() {
                    return this.socket.reconnectAfterMs
                }
                get sendBuffer() {
                    return this.socket.sendBuffer
                }
                get stateChangeCallbacks() {
                    return this.socket.stateChangeCallbacks
                }
                connect() {
                    this.socket.connect()
                }
                disconnect(e, t, r, n = 1e4) {
                    return new Promise(s => {
                        setTimeout(() => s("timeout"), n), this.socket.disconnect(() => {
                            e(), s("ok")
                        }, t, r)
                    })
                }
                push(e) {
                    this.socket.push(e)
                }
                log(e, t, r) {
                    this.socket.log(e, t, r)
                }
                makeRef() {
                    return this.socket.makeRef()
                }
                onOpen(e) {
                    this.socket.onOpen(e)
                }
                onClose(e) {
                    this.socket.onClose(e)
                }
                onError(e) {
                    this.socket.onError(e)
                }
                onMessage(e) {
                    this.socket.onMessage(e)
                }
                isConnected() {
                    return this.socket.isConnected()
                }
                isConnecting() {
                    return "connecting" == this.socket.connectionState()
                }
                isDisconnecting() {
                    return "closing" == this.socket.connectionState()
                }
                connectionState() {
                    return this.socket.connectionState()
                }
                endPointURL() {
                    return this.socket.endPointURL()
                }
                sendHeartbeat() {
                    this.socket.sendHeartbeat()
                }
                getSocket() {
                    return this.socket
                }
            }
            let e$ = [1e3, 2e3, 5e3, 1e4],
                ex = `
  addEventListener("message", (e) => {
    if (e.data.event === "start") {
      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);
    }
  });`;
            class eU {
                get endPoint() {
                    return this.socketAdapter.endPoint
                }
                get timeout() {
                    return this.socketAdapter.timeout
                }
                get transport() {
                    return this.socketAdapter.transport
                }
                get heartbeatCallback() {
                    return this.socketAdapter.heartbeatCallback
                }
                get heartbeatIntervalMs() {
                    return this.socketAdapter.heartbeatIntervalMs
                }
                get heartbeatTimer() {
                    return this.worker ? this._workerHeartbeatTimer : this.socketAdapter.heartbeatTimer
                }
                get pendingHeartbeatRef() {
                    return this.worker ? this._pendingWorkerHeartbeatRef : this.socketAdapter.pendingHeartbeatRef
                }
                get reconnectTimer() {
                    return this.socketAdapter.reconnectTimer
                }
                get vsn() {
                    return this.socketAdapter.vsn
                }
                get encode() {
                    return this.socketAdapter.encode
                }
                get decode() {
                    return this.socketAdapter.decode
                }
                get reconnectAfterMs() {
                    return this.socketAdapter.reconnectAfterMs
                }
                get sendBuffer() {
                    return this.socketAdapter.sendBuffer
                }
                get stateChangeCallbacks() {
                    return this.socketAdapter.stateChangeCallbacks
                }
                constructor(e, t) {
                    var r;
                    if (this.channels = [], this.accessTokenValue = null, this.accessToken = null, this.apiKey = null, this.httpEndpoint = "", this.headers = {}, this.params = {}, this.ref = 0, this.serializer = new V, this._manuallySetToken = !1, this._authPromise = null, this._workerHeartbeatTimer = void 0, this._pendingWorkerHeartbeatRef = null, this._pendingDisconnectTimer = null, this._disconnectOnEmptyChannelsAfterMs = 0, this._resolveFetch = e => e ? (...t) => e(...t) : (...e) => fetch(...e), !(null == (r = null == t ? void 0 : t.params) ? void 0 : r.apikey)) throw Error("API key is required to connect to Realtime");
                    this.apiKey = t.params.apikey;
                    const n = this._initializeOptions(t);
                    this.socketAdapter = new ej(e, n), this.httpEndpoint = er(e), this.fetch = this._resolveFetch(null == t ? void 0 : t.fetch)
                }
                connect() {
                    if (!(this.isConnecting() || this.isDisconnecting() || this.isConnected())) {
                        this.accessToken && !this._authPromise && this._setAuthSafely("connect"), this._setupConnectionHandlers();
                        try {
                            this.socketAdapter.connect()
                        } catch (t) {
                            let e = t.message;
                            if (e.includes("Node.js")) throw Error(`${e}

To use Realtime in Node.js, you need to provide a WebSocket implementation:

Option 1: Use Node.js 22+ which has native WebSocket support
Option 2: Install and provide the "ws" package:

  npm install ws

  import ws from "ws"
  const client = new RealtimeClient(url, {
    ...options,
    transport: ws
  })`);
                            throw Error(`WebSocket not available: ${e}`)
                        }
                        this._handleNodeJsRaceCondition()
                    }
                }
                endpointURL() {
                    return this.socketAdapter.endPointURL()
                }
                async disconnect(e, t) {
                    return (this._cancelPendingDisconnect(), this.isDisconnecting()) ? "ok" : await this.socketAdapter.disconnect(() => {
                        clearInterval(this._workerHeartbeatTimer), this._terminateWorker()
                    }, e, t)
                }
                getChannels() {
                    return this.channels
                }
                async removeChannel(e) {
                    let t = await e.unsubscribe();
                    return "ok" === t && e.teardown(), t
                }
                async removeAllChannels() {
                    let e = this.channels.map(async e => {
                            let t = await e.unsubscribe();
                            return e.teardown(), t
                        }),
                        t = await Promise.all(e);
                    return await this.disconnect(), t
                }
                log(e, t, r) {
                    this.socketAdapter.log(e, t, r)
                }
                connectionState() {
                    return this.socketAdapter.connectionState() || "closed"
                }
                isConnected() {
                    return this.socketAdapter.isConnected()
                }
                isConnecting() {
                    return this.socketAdapter.isConnecting()
                }
                isDisconnecting() {
                    return this.socketAdapter.isDisconnecting()
                }
                channel(e, t = {
                    config: {}
                }) {
                    let r = `realtime:${e}`,
                        n = this.getChannels().find(e => e.topic === r);
                    if (n) return n; {
                        let r = new eP(`realtime:${e}`, t, this);
                        return this._cancelPendingDisconnect(), this.channels.push(r), r
                    }
                }
                push(e) {
                    this.socketAdapter.push(e)
                }
                async setAuth(e = null) {
                    this._authPromise = this._performAuth(e);
                    try {
                        await this._authPromise
                    } finally {
                        this._authPromise = null
                    }
                }
                _isManualToken() {
                    return this._manuallySetToken
                }
                async sendHeartbeat() {
                    this.socketAdapter.sendHeartbeat()
                }
                onHeartbeat(e) {
                    this.socketAdapter.heartbeatCallback = this._wrapHeartbeatCallback(e)
                }
                _makeRef() {
                    return this.socketAdapter.makeRef()
                }
                _remove(e) {
                    this.channels = this.channels.filter(t => t.topic !== e.topic), 0 === this.channels.length && (this.log("transport", "no channels remaining, scheduling disconnect"), this._schedulePendingDisconnect())
                }
                _schedulePendingDisconnect() {
                    if (this._cancelPendingDisconnect(), 0 === this._disconnectOnEmptyChannelsAfterMs) {
                        this.log("transport", "disconnecting immediately - no channels"), this.disconnect();
                        return
                    }
                    this._pendingDisconnectTimer = setTimeout(() => {
                        this._pendingDisconnectTimer = null, 0 === this.channels.length && (this.log("transport", "deferred disconnect fired - no channels, disconnecting"), this.disconnect())
                    }, this._disconnectOnEmptyChannelsAfterMs), this.log("transport", `deferred disconnect scheduled in ${this._disconnectOnEmptyChannelsAfterMs}ms`)
                }
                _cancelPendingDisconnect() {
                    null !== this._pendingDisconnectTimer && (this.log("transport", "pending disconnect cancelled - channel activity detected"), clearTimeout(this._pendingDisconnectTimer), this._pendingDisconnectTimer = null)
                }
                async _performAuth(e = null) {
                    let t, r = !1;
                    if (e) t = e, r = !0;
                    else if (this.accessToken) try {
                        t = await this.accessToken()
                    } catch (e) {
                        this.log("error", "Error fetching access token from callback", e), t = this.accessTokenValue
                    } else t = this.accessTokenValue;
                    r ? this._manuallySetToken = !0 : this.accessToken && (this._manuallySetToken = !1), this.accessTokenValue != t && (this.accessTokenValue = t, this.channels.forEach(e => {
                        let r = {
                            access_token: t,
                            version: "realtime-js/2.108.0"
                        };
                        t && e.updateJoinPayload(r), e.joinedOnce && e.channelAdapter.isJoined() && e.channelAdapter.push(W.access_token, {
                            access_token: t
                        })
                    }))
                }
                async _waitForAuthIfNeeded() {
                    this._authPromise && await this._authPromise
                }
                _setAuthSafely(e = "general") {
                    this._isManualToken() || this.setAuth().catch(t => {
                        this.log("error", `Error setting auth in ${e}`, t)
                    })
                }
                _setupConnectionHandlers() {
                    this.socketAdapter.onOpen(() => {
                        (this._authPromise || (this.accessToken && !this.accessTokenValue ? this.setAuth() : Promise.resolve())).catch(e => {
                            this.log("error", "error waiting for auth on connect", e)
                        }), this.worker && !this.workerRef && this._startWorkerHeartbeat()
                    }), this.socketAdapter.onClose(() => {
                        this.worker && this.workerRef && this._terminateWorker()
                    }), this.socketAdapter.onMessage(e => {
                        e.ref && e.ref === this._pendingWorkerHeartbeatRef && (this._pendingWorkerHeartbeatRef = null)
                    })
                }
                _handleNodeJsRaceCondition() {
                    this.socketAdapter.isConnected() && this.socketAdapter.getSocket().onConnOpen()
                }
                _wrapHeartbeatCallback(e) {
                    return (t, r) => {
                        "sent" == t && this._setAuthSafely(), e && e(t, r)
                    }
                }
                _startWorkerHeartbeat() {
                    this.workerUrl ? this.log("worker", `starting worker for from ${this.workerUrl}`) : this.log("worker", "starting default worker");
                    let e = this._workerObjectUrl(this.workerUrl);
                    this.workerRef = new Worker(e), this.workerRef.onerror = e => {
                        this.log("worker", "worker error", e.message), this._terminateWorker(), this.disconnect()
                    }, this.workerRef.onmessage = e => {
                        "keepAlive" === e.data.event && this.sendHeartbeat()
                    }, this.workerRef.postMessage({
                        event: "start",
                        interval: this.heartbeatIntervalMs
                    })
                }
                _terminateWorker() {
                    this.workerRef && (this.log("worker", "terminating worker"), this.workerRef.terminate(), this.workerRef = void 0)
                }
                _workerObjectUrl(e) {
                    let t;
                    if (e) t = e;
                    else {
                        let e = new Blob([ex], {
                            type: "application/javascript"
                        });
                        t = URL.createObjectURL(e)
                    }
                    return t
                }
                _initializeOptions(e) {
                    var t, r, n, s, i, a, o, l, c, h, u, d;
                    let f, p;
                    this.worker = null != (t = null == e ? void 0 : e.worker) && t, this.accessToken = null != (r = null == e ? void 0 : e.accessToken) ? r : null;
                    let g = {};
                    g.timeout = null != (n = null == e ? void 0 : e.timeout) ? n : 1e4, g.heartbeatIntervalMs = null != (s = null == e ? void 0 : e.heartbeatIntervalMs) ? s : 25e3, this._disconnectOnEmptyChannelsAfterMs = null != (i = null == e ? void 0 : e.disconnectOnEmptyChannelsAfterMs) ? i : 2 * (null != (a = null == e ? void 0 : e.heartbeatIntervalMs) ? a : 25e3), g.transport = null != (o = null == e ? void 0 : e.transport) ? o : q.getWebSocketConstructor(), g.params = null == e ? void 0 : e.params, g.logger = null == e ? void 0 : e.logger, g.heartbeatCallback = this._wrapHeartbeatCallback(null == e ? void 0 : e.heartbeatCallback), g.sessionStorage = null != (l = null == e ? void 0 : e.sessionStorage) ? l : function() {
                        let e;
                        try {
                            if ("u" > typeof globalThis && globalThis.sessionStorage) return globalThis.sessionStorage
                        } catch (e) {}
                        return e = new Map, {
                            get length() {
                                return e.size
                            },
                            clear() {
                                e.clear()
                            },
                            getItem: t => e.has(t) ? e.get(t) : null,
                            key(t) {
                                var r;
                                return null != (r = Array.from(e.keys())[t]) ? r : null
                            },
                            removeItem(t) {
                                e.delete(t)
                            },
                            setItem(t, r) {
                                e.set(t, String(r))
                            }
                        }
                    }(), g.reconnectAfterMs = null != (c = null == e ? void 0 : e.reconnectAfterMs) ? c : e => e$[e - 1] || 1e4;
                    let m = null != (h = null == e ? void 0 : e.vsn) ? h : M;
                    switch (m) {
                        case "1.0.0":
                            f = (e, t) => t(JSON.stringify(e)), p = (e, t) => t(JSON.parse(e));
                            break;
                        case M:
                            f = this.serializer.encode.bind(this.serializer), p = this.serializer.decode.bind(this.serializer);
                            break;
                        default:
                            throw Error(`Unsupported serializer version: ${g.vsn}`)
                    }
                    if (g.vsn = m, g.encode = null != (u = null == e ? void 0 : e.encode) ? u : f, g.decode = null != (d = null == e ? void 0 : e.decode) ? d : p, g.beforeReconnect = this._reconnectAuth.bind(this), ((null == e ? void 0 : e.logLevel) || (null == e ? void 0 : e.log_level)) && (this.logLevel = e.logLevel || e.log_level, g.params = Object.assign(Object.assign({}, g.params), {
                            log_level: this.logLevel
                        })), this.worker) {
                        if ("u" > typeof window && !window.Worker) throw Error("Web Worker is not supported");
                        this.workerUrl = null == e ? void 0 : e.workerUrl, g.autoSendHeartbeat = !this.worker
                    }
                    return g
                }
                async _reconnectAuth() {
                    await this._waitForAuthIfNeeded(), this.isConnected() || this.connect()
                }
            }
            var eI = class extends Error {
                constructor(e, t) {
                    super(e), this.name = "IcebergError", this.status = t.status, this.icebergType = t.icebergType, this.icebergCode = t.icebergCode, this.details = t.details, this.isCommitStateUnknown = "CommitStateUnknownException" === t.icebergType || [500, 502, 504].includes(t.status) && t.icebergType ? .includes("CommitState") === !0
                }
                isNotFound() {
                    return 404 === this.status
                }
                isConflict() {
                    return 409 === this.status
                }
                isAuthenticationTimeout() {
                    return 419 === this.status
                }
            };
            async function eN(e) {
                return e && "none" !== e.type ? "bearer" === e.type ? {
                    Authorization: `Bearer ${e.token}`
                } : "header" === e.type ? {
                    [e.name]: e.value
                } : "custom" === e.type ? await e.getHeaders() : {} : {}
            }

            function eB(e) {
                return e.join("\x1f")
            }
            var eL = class {
                constructor(e, t = "") {
                    this.client = e, this.prefix = t
                }
                async listNamespaces(e) {
                    let t = e ? {
                        parent: eB(e.namespace)
                    } : void 0;
                    return (await this.client.request({
                        method: "GET",
                        path: `${this.prefix}/namespaces`,
                        query: t
                    })).data.namespaces.map(e => ({
                        namespace: e
                    }))
                }
                async createNamespace(e, t) {
                    let r = {
                        namespace: e.namespace,
                        properties: t ? .properties
                    };
                    return (await this.client.request({
                        method: "POST",
                        path: `${this.prefix}/namespaces`,
                        body: r
                    })).data
                }
                async dropNamespace(e) {
                    await this.client.request({
                        method: "DELETE",
                        path: `${this.prefix}/namespaces/${eB(e.namespace)}`
                    })
                }
                async loadNamespaceMetadata(e) {
                    return {
                        properties: (await this.client.request({
                            method: "GET",
                            path: `${this.prefix}/namespaces/${eB(e.namespace)}`
                        })).data.properties
                    }
                }
                async namespaceExists(e) {
                    try {
                        return await this.client.request({
                            method: "HEAD",
                            path: `${this.prefix}/namespaces/${eB(e.namespace)}`
                        }), !0
                    } catch (e) {
                        if (e instanceof eI && 404 === e.status) return !1;
                        throw e
                    }
                }
                async createNamespaceIfNotExists(e, t) {
                    try {
                        return await this.createNamespace(e, t)
                    } catch (e) {
                        if (e instanceof eI && 409 === e.status) return;
                        throw e
                    }
                }
            };

            function eD(e) {
                return e.join("\x1f")
            }
            var eH = class {
                    constructor(e, t = "", r) {
                        this.client = e, this.prefix = t, this.accessDelegation = r
                    }
                    async listTables(e) {
                        return (await this.client.request({
                            method: "GET",
                            path: `${this.prefix}/namespaces/${eD(e.namespace)}/tables`
                        })).data.identifiers
                    }
                    async createTable(e, t) {
                        let r = {};
                        return this.accessDelegation && (r["X-Iceberg-Access-Delegation"] = this.accessDelegation), (await this.client.request({
                            method: "POST",
                            path: `${this.prefix}/namespaces/${eD(e.namespace)}/tables`,
                            body: t,
                            headers: r
                        })).data.metadata
                    }
                    async updateTable(e, t) {
                        let r = await this.client.request({
                            method: "POST",
                            path: `${this.prefix}/namespaces/${eD(e.namespace)}/tables/${e.name}`,
                            body: t
                        });
                        return {
                            "metadata-location": r.data["metadata-location"],
                            metadata: r.data.metadata
                        }
                    }
                    async dropTable(e, t) {
                        await this.client.request({
                            method: "DELETE",
                            path: `${this.prefix}/namespaces/${eD(e.namespace)}/tables/${e.name}`,
                            query: {
                                purgeRequested: String(t ? .purge ? ? !1)
                            }
                        })
                    }
                    async loadTable(e) {
                        let t = {};
                        return this.accessDelegation && (t["X-Iceberg-Access-Delegation"] = this.accessDelegation), (await this.client.request({
                            method: "GET",
                            path: `${this.prefix}/namespaces/${eD(e.namespace)}/tables/${e.name}`,
                            headers: t
                        })).data.metadata
                    }
                    async tableExists(e) {
                        let t = {};
                        this.accessDelegation && (t["X-Iceberg-Access-Delegation"] = this.accessDelegation);
                        try {
                            return await this.client.request({
                                method: "HEAD",
                                path: `${this.prefix}/namespaces/${eD(e.namespace)}/tables/${e.name}`,
                                headers: t
                            }), !0
                        } catch (e) {
                            if (e instanceof eI && 404 === e.status) return !1;
                            throw e
                        }
                    }
                    async createTableIfNotExists(e, t) {
                        try {
                            return await this.createTable(e, t)
                        } catch (r) {
                            if (r instanceof eI && 409 === r.status) return await this.loadTable({
                                namespace: e.namespace,
                                name: t.name
                            });
                            throw r
                        }
                    }
                },
                eq = class {
                    constructor(e) {
                        let t = "v1";
                        e.catalogName && (t += `/${e.catalogName}`);
                        const r = e.baseUrl.endsWith("/") ? e.baseUrl : `${e.baseUrl}/`;
                        this.client = function(e) {
                            let t = e.fetchImpl ? ? globalThis.fetch;
                            return {
                                async request({
                                    method: r,
                                    path: n,
                                    query: s,
                                    body: i,
                                    headers: a
                                }) {
                                    let o = function(e, t, r) {
                                            let n = new URL(t, e);
                                            if (r)
                                                for (let [e, t] of Object.entries(r)) void 0 !== t && n.searchParams.set(e, t);
                                            return n.toString()
                                        }(e.baseUrl, n, s),
                                        l = await eN(e.auth),
                                        c = await t(o, {
                                            method: r,
                                            headers: { ...i ? {
                                                    "Content-Type": "application/json"
                                                } : {},
                                                ...l,
                                                ...a
                                            },
                                            body: i ? JSON.stringify(i) : void 0
                                        }),
                                        h = await c.text(),
                                        u = (c.headers.get("content-type") || "").includes("application/json"),
                                        d = u && h ? JSON.parse(h) : h;
                                    if (!c.ok) {
                                        let e = u ? d : void 0,
                                            t = e ? .error;
                                        throw new eI(t ? .message ? ? `Request failed with status ${c.status}`, {
                                            status: c.status,
                                            icebergType: t ? .type,
                                            icebergCode: t ? .code,
                                            details: e
                                        })
                                    }
                                    return {
                                        status: c.status,
                                        headers: c.headers,
                                        data: d
                                    }
                                }
                            }
                        }({
                            baseUrl: r,
                            auth: e.auth,
                            fetchImpl: e.fetch
                        }), this.accessDelegation = e.accessDelegation ? .join(","), this.namespaceOps = new eL(this.client, t), this.tableOps = new eH(this.client, t, this.accessDelegation)
                    }
                    async listNamespaces(e) {
                        return this.namespaceOps.listNamespaces(e)
                    }
                    async createNamespace(e, t) {
                        return this.namespaceOps.createNamespace(e, t)
                    }
                    async dropNamespace(e) {
                        await this.namespaceOps.dropNamespace(e)
                    }
                    async loadNamespaceMetadata(e) {
                        return this.namespaceOps.loadNamespaceMetadata(e)
                    }
                    async listTables(e) {
                        return this.tableOps.listTables(e)
                    }
                    async createTable(e, t) {
                        return this.tableOps.createTable(e, t)
                    }
                    async updateTable(e, t) {
                        return this.tableOps.updateTable(e, t)
                    }
                    async dropTable(e, t) {
                        await this.tableOps.dropTable(e, t)
                    }
                    async loadTable(e) {
                        return this.tableOps.loadTable(e)
                    }
                    async namespaceExists(e) {
                        return this.namespaceOps.namespaceExists(e)
                    }
                    async tableExists(e) {
                        return this.tableOps.tableExists(e)
                    }
                    async createNamespaceIfNotExists(e, t) {
                        return this.namespaceOps.createNamespaceIfNotExists(e, t)
                    }
                    async createTableIfNotExists(e, t) {
                        return this.tableOps.createTableIfNotExists(e, t)
                    }
                },
                eM = r(8919).Buffer;

            function eJ(e) {
                return (eJ = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function eF(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), r.push.apply(r, n)
                }
                return r
            }

            function eW(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? eF(Object(r), !0).forEach(function(t) {
                        ! function(e, t, r) {
                            var n;
                            (n = function(e, t) {
                                if ("object" != eJ(e) || !e) return e;
                                var r = e[Symbol.toPrimitive];
                                if (void 0 !== r) {
                                    var n = r.call(e, t || "default");
                                    if ("object" != eJ(n)) return n;
                                    throw TypeError("@@toPrimitive must return a primitive value.")
                                }
                                return ("string" === t ? String : Number)(e)
                            }(t, "string"), (t = "symbol" == eJ(n) ? n : n + "") in e) ? Object.defineProperty(e, t, {
                                value: r,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }): e[t] = r
                        }(e, t, r[t])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : eF(Object(r)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    })
                }
                return e
            }
            var eV = class extends Error {
                constructor(e, t = "storage", r, n) {
                    super(e), this.__isStorageError = !0, this.namespace = t, this.name = "vectors" === t ? "StorageVectorsError" : "StorageError", this.status = r, this.statusCode = n
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status,
                        statusCode: this.statusCode
                    }
                }
            };

            function eK(e) {
                return "object" == typeof e && null !== e && "__isStorageError" in e
            }
            var ez = class extends eV {
                    constructor(e, t, r, n = "storage") {
                        super(e, n, t, r), this.name = "vectors" === n ? "StorageVectorsApiError" : "StorageApiError", this.status = t, this.statusCode = r
                    }
                    toJSON() {
                        return eW({}, super.toJSON())
                    }
                },
                eG = class extends eV {
                    constructor(e, t, r = "storage") {
                        super(e, r), this.name = "vectors" === r ? "StorageVectorsUnknownError" : "StorageUnknownError", this.originalError = t
                    }
                };

            function eY(e, t, r) {
                let n = eW({}, e),
                    s = t.toLowerCase();
                for (let e of Object.keys(n)) e.toLowerCase() === s && delete n[e];
                return n[s] = r, n
            }
            let eX = e => {
                    if (Array.isArray(e)) return e.map(e => eX(e));
                    if ("function" == typeof e || e !== Object(e)) return e;
                    let t = {};
                    return Object.entries(e).forEach(([e, r]) => {
                        t[e.replace(/([-_][a-z])/gi, e => e.toUpperCase().replace(/[-_]/g, ""))] = eX(r)
                    }), t
                },
                eQ = e => {
                    if ("object" == typeof e && null !== e) {
                        if ("string" == typeof e.msg) return e.msg;
                        if ("string" == typeof e.message) return e.message;
                        if ("string" == typeof e.error_description) return e.error_description;
                        if ("string" == typeof e.error) return e.error;
                        if ("object" == typeof e.error && null !== e.error) {
                            let t = e.error;
                            if ("string" == typeof t.message) return t.message
                        }
                    }
                    return JSON.stringify(e)
                },
                eZ = async (e, t, r, n) => {
                    if (null !== e && "object" == typeof e && "json" in e && "function" == typeof e.json) {
                        let r = parseInt(String(e.status), 10);
                        Number.isFinite(r) || (r = 500), e.json().then(e => {
                            let s = (null == e ? void 0 : e.statusCode) || (null == e ? void 0 : e.code) || r + "";
                            t(new ez(eQ(e), r, s, n))
                        }).catch(() => {
                            let s = r + "";
                            t(new ez(e.statusText || `HTTP ${r} error`, r, s, n))
                        })
                    } else t(new eG(eQ(e), e, n))
                };
            async function e0(e, t, r, n, s, i, a) {
                return new Promise((o, l) => {
                    e(r, ((e, t, r, n) => {
                        let s = {
                            method: e,
                            headers: (null == t ? void 0 : t.headers) || {}
                        };
                        if ("GET" === e || "HEAD" === e || !n) return eW(eW({}, s), r);
                        if ((e => {
                                if ("object" != typeof e || null === e) return !1;
                                let t = Object.getPrototypeOf(e);
                                return (null === t || t === Object.prototype || null === Object.getPrototypeOf(t)) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
                            })(n)) {
                            var i;
                            let e, r = (null == t ? void 0 : t.headers) || {};
                            for (let [t, n] of Object.entries(r)) "content-type" === t.toLowerCase() && (e = n);
                            s.headers = eY(r, "Content-Type", null != (i = e) ? i : "application/json"), s.body = JSON.stringify(n)
                        } else s.body = n;
                        return (null == t ? void 0 : t.duplex) && (s.duplex = t.duplex), eW(eW({}, s), r)
                    })(t, n, s, i)).then(e => {
                        if (!e.ok) throw e;
                        if (null == n ? void 0 : n.noResolveJson) return e;
                        if ("vectors" === a) {
                            let t = e.headers.get("content-type");
                            if ("0" === e.headers.get("content-length") || 204 === e.status || !t || !t.includes("application/json")) return {}
                        }
                        return e.json()
                    }).then(e => o(e)).catch(e => eZ(e, l, n, a))
                })
            }

            function e1(e = "storage") {
                return {
                    get: async (t, r, n, s) => e0(t, "GET", r, n, s, void 0, e),
                    post: async (t, r, n, s, i) => e0(t, "POST", r, s, i, n, e),
                    put: async (t, r, n, s, i) => e0(t, "PUT", r, s, i, n, e),
                    head: async (t, r, n, s) => e0(t, "HEAD", r, eW(eW({}, n), {}, {
                        noResolveJson: !0
                    }), s, void 0, e),
                    remove: async (t, r, n, s, i) => e0(t, "DELETE", r, s, i, n, e)
                }
            }
            let {
                get: e2,
                post: e8,
                put: e5,
                head: e6,
                remove: e3
            } = e1("storage"), e4 = e1("vectors");
            var e9 = class {
                constructor(e, t = {}, r, n = "storage") {
                    this.shouldThrowOnError = !1, this.url = e, this.headers = function(e) {
                        let t = {};
                        for (let [r, n] of Object.entries(e)) t[r.toLowerCase()] = n;
                        return t
                    }(t), this.fetch = (e => e ? (...t) => e(...t) : (...e) => fetch(...e))(r), this.namespace = n
                }
                throwOnError() {
                    return this.shouldThrowOnError = !0, this
                }
                setHeader(e, t) {
                    return this.headers = eY(this.headers, e, t), this
                }
                async handleOperation(e) {
                    try {
                        return {
                            data: await e(),
                            error: null
                        }
                    } catch (e) {
                        if (this.shouldThrowOnError) throw e;
                        if (eK(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
            };
            n = Symbol.toStringTag;
            var e7 = class {
                constructor(e, t) {
                    this.downloadFn = e, this.shouldThrowOnError = t, this[n] = "StreamDownloadBuilder", this.promise = null
                }
                then(e, t) {
                    return this.getPromise().then(e, t)
                } catch (e) {
                    return this.getPromise().catch(e)
                } finally(e) {
                    return this.getPromise().finally(e)
                }
                getPromise() {
                    return this.promise || (this.promise = this.execute()), this.promise
                }
                async execute() {
                    try {
                        return {
                            data: (await this.downloadFn()).body,
                            error: null
                        }
                    } catch (e) {
                        if (this.shouldThrowOnError) throw e;
                        if (eK(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
            };
            s = Symbol.toStringTag;
            var te = class {
                constructor(e, t) {
                    this.downloadFn = e, this.shouldThrowOnError = t, this[s] = "BlobDownloadBuilder", this.promise = null
                }
                asStream() {
                    return new e7(this.downloadFn, this.shouldThrowOnError)
                }
                then(e, t) {
                    return this.getPromise().then(e, t)
                } catch (e) {
                    return this.getPromise().catch(e)
                } finally(e) {
                    return this.getPromise().finally(e)
                }
                getPromise() {
                    return this.promise || (this.promise = this.execute()), this.promise
                }
                async execute() {
                    try {
                        return {
                            data: await (await this.downloadFn()).blob(),
                            error: null
                        }
                    } catch (e) {
                        if (this.shouldThrowOnError) throw e;
                        if (eK(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
            };
            let tt = {
                    limit: 100,
                    offset: 0,
                    sortBy: {
                        column: "name",
                        order: "asc"
                    }
                },
                tr = {
                    cacheControl: "3600",
                    contentType: "text/plain;charset=UTF-8",
                    upsert: !1
                };
            var tn = class extends e9 {
                constructor(e, t = {}, r, n) {
                    super(e, t, n, "storage"), this.bucketId = r
                }
                async uploadOrUpdate(e, t, r, n) {
                    var s = this;
                    return s.handleOperation(async () => {
                        let i, a = eW(eW({}, tr), n),
                            o = eW(eW({}, s.headers), "POST" === e && {
                                "x-upsert": String(a.upsert)
                            }),
                            l = a.metadata;
                        if ("u" > typeof Blob && r instanceof Blob ? ((i = new FormData).append("cacheControl", a.cacheControl), l && i.append("metadata", s.encodeMetadata(l)), i.append("", r)) : "u" > typeof FormData && r instanceof FormData ? ((i = r).has("cacheControl") || i.append("cacheControl", a.cacheControl), l && !i.has("metadata") && i.append("metadata", s.encodeMetadata(l))) : (i = r, o["cache-control"] = `max-age=${a.cacheControl}`, o["content-type"] = a.contentType, l && (o["x-metadata"] = s.toBase64(s.encodeMetadata(l))), ("u" > typeof ReadableStream && i instanceof ReadableStream || i && "object" == typeof i && "pipe" in i && "function" == typeof i.pipe) && !a.duplex && (a.duplex = "half")), null == n ? void 0 : n.headers)
                            for (let [e, t] of Object.entries(n.headers)) o = eY(o, e, t);
                        let c = s._removeEmptyFolders(t),
                            h = s._getFinalPath(c),
                            u = await ("PUT" == e ? e5 : e8)(s.fetch, `${s.url}/object/${h}`, i, eW({
                                headers: o
                            }, (null == a ? void 0 : a.duplex) ? {
                                duplex: a.duplex
                            } : {}));
                        return {
                            path: c,
                            id: u.Id,
                            fullPath: u.Key
                        }
                    })
                }
                async upload(e, t, r) {
                    return this.uploadOrUpdate("POST", e, t, r)
                }
                async uploadToSignedUrl(e, t, r, n) {
                    var s = this;
                    let i = s._removeEmptyFolders(e),
                        a = s._getFinalPath(i),
                        o = new URL(s.url + `/object/upload/sign/${a}`);
                    return o.searchParams.set("token", t), s.handleOperation(async () => {
                        let e, t = eW(eW({}, tr), n),
                            a = eW(eW({}, s.headers), {
                                "x-upsert": String(t.upsert)
                            }),
                            l = t.metadata;
                        if ("u" > typeof Blob && r instanceof Blob ? ((e = new FormData).append("cacheControl", t.cacheControl), l && e.append("metadata", s.encodeMetadata(l)), e.append("", r)) : "u" > typeof FormData && r instanceof FormData ? ((e = r).has("cacheControl") || e.append("cacheControl", t.cacheControl), l && !e.has("metadata") && e.append("metadata", s.encodeMetadata(l))) : (e = r, a["cache-control"] = `max-age=${t.cacheControl}`, a["content-type"] = t.contentType, l && (a["x-metadata"] = s.toBase64(s.encodeMetadata(l))), ("u" > typeof ReadableStream && e instanceof ReadableStream || e && "object" == typeof e && "pipe" in e && "function" == typeof e.pipe) && !t.duplex && (t.duplex = "half")), null == n ? void 0 : n.headers)
                            for (let [e, t] of Object.entries(n.headers)) a = eY(a, e, t);
                        return {
                            path: i,
                            fullPath: (await e5(s.fetch, o.toString(), e, eW({
                                headers: a
                            }, (null == t ? void 0 : t.duplex) ? {
                                duplex: t.duplex
                            } : {}))).Key
                        }
                    })
                }
                async createSignedUploadUrl(e, t) {
                    var r = this;
                    return r.handleOperation(async () => {
                        let n = r._getFinalPath(e),
                            s = eW({}, r.headers);
                        (null == t ? void 0 : t.upsert) && (s["x-upsert"] = "true");
                        let i = await e8(r.fetch, `${r.url}/object/upload/sign/${n}`, {}, {
                                headers: s
                            }),
                            a = new URL(r.url + i.url),
                            o = a.searchParams.get("token");
                        if (!o) throw new eV("No token returned by API");
                        return {
                            signedUrl: a.toString(),
                            path: e,
                            token: o
                        }
                    })
                }
                async update(e, t, r) {
                    return this.uploadOrUpdate("PUT", e, t, r)
                }
                async move(e, t, r) {
                    var n = this;
                    return n.handleOperation(async () => await e8(n.fetch, `${n.url}/object/move`, {
                        bucketId: n.bucketId,
                        sourceKey: e,
                        destinationKey: t,
                        destinationBucket: null == r ? void 0 : r.destinationBucket
                    }, {
                        headers: n.headers
                    }))
                }
                async copy(e, t, r) {
                    var n = this;
                    return n.handleOperation(async () => ({
                        path: (await e8(n.fetch, `${n.url}/object/copy`, {
                            bucketId: n.bucketId,
                            sourceKey: e,
                            destinationKey: t,
                            destinationBucket: null == r ? void 0 : r.destinationBucket
                        }, {
                            headers: n.headers
                        })).Key
                    }))
                }
                async createSignedUrl(e, t, r) {
                    var n = this;
                    return n.handleOperation(async () => {
                        let s = n._getFinalPath(e),
                            i = "object" == typeof(null == r ? void 0 : r.transform) && null !== r.transform && Object.keys(r.transform).length > 0,
                            a = await e8(n.fetch, `${n.url}/object/sign/${s}`, eW({
                                expiresIn: t
                            }, i ? {
                                transform: r.transform
                            } : {}), {
                                headers: n.headers
                            }),
                            o = new URLSearchParams;
                        (null == r ? void 0 : r.download) && o.set("download", !0 === r.download ? "" : r.download), (null == r ? void 0 : r.cacheNonce) != null && o.set("cacheNonce", String(r.cacheNonce));
                        let l = o.toString();
                        return {
                            signedUrl: encodeURI(`${n.url}${a.signedURL}${l?`&${l}`:""}`)
                        }
                    })
                }
                async createSignedUrls(e, t, r) {
                    var n = this;
                    return n.handleOperation(async () => {
                        let s = await e8(n.fetch, `${n.url}/object/sign/${n.bucketId}`, {
                                expiresIn: t,
                                paths: e
                            }, {
                                headers: n.headers
                            }),
                            i = new URLSearchParams;
                        (null == r ? void 0 : r.download) && i.set("download", !0 === r.download ? "" : r.download), (null == r ? void 0 : r.cacheNonce) != null && i.set("cacheNonce", String(r.cacheNonce));
                        let a = i.toString();
                        return s.map(e => eW(eW({}, e), {}, {
                            signedUrl: e.signedURL ? encodeURI(`${n.url}${e.signedURL}${a?`&${a}`:""}`) : null
                        }))
                    })
                }
                download(e, t, r) {
                    let n = "object" == typeof(null == t ? void 0 : t.transform) && null !== t.transform && Object.keys(t.transform).length > 0 ? "render/image/authenticated" : "object",
                        s = new URLSearchParams;
                    (null == t ? void 0 : t.transform) && this.applyTransformOptsToQuery(s, t.transform), (null == t ? void 0 : t.cacheNonce) != null && s.set("cacheNonce", String(t.cacheNonce));
                    let i = s.toString(),
                        a = this._getFinalPath(e);
                    return new te(() => e2(this.fetch, `${this.url}/${n}/${a}${i?`?${i}`:""}`, {
                        headers: this.headers,
                        noResolveJson: !0
                    }, r), this.shouldThrowOnError)
                }
                async info(e) {
                    var t = this;
                    let r = t._getFinalPath(e);
                    return t.handleOperation(async () => eX(await e2(t.fetch, `${t.url}/object/info/${r}`, {
                        headers: t.headers
                    })))
                }
                async exists(e) {
                    var t;
                    let r = this._getFinalPath(e);
                    try {
                        return await e6(this.fetch, `${this.url}/object/${r}`, {
                            headers: this.headers
                        }), {
                            data: !0,
                            error: null
                        }
                    } catch (e) {
                        if (this.shouldThrowOnError) throw e;
                        if (eK(e)) {
                            let r = e instanceof ez ? e.status : e instanceof eG ? null == (t = e.originalError) ? void 0 : t.status : void 0;
                            if (void 0 !== r && [400, 404].includes(r)) return {
                                data: !1,
                                error: e
                            }
                        }
                        throw e
                    }
                }
                getPublicUrl(e, t) {
                    let r = this._getFinalPath(e),
                        n = new URLSearchParams;
                    (null == t ? void 0 : t.download) && n.set("download", !0 === t.download ? "" : t.download), (null == t ? void 0 : t.transform) && this.applyTransformOptsToQuery(n, t.transform), (null == t ? void 0 : t.cacheNonce) != null && n.set("cacheNonce", String(t.cacheNonce));
                    let s = n.toString(),
                        i = "object" == typeof(null == t ? void 0 : t.transform) && null !== t.transform && Object.keys(t.transform).length > 0 ? "render/image" : "object";
                    return {
                        data: {
                            publicUrl: encodeURI(`${this.url}/${i}/public/${r}`) + (s ? `?${s}` : "")
                        }
                    }
                }
                async remove(e) {
                    var t = this;
                    return t.handleOperation(async () => await e3(t.fetch, `${t.url}/object/${t.bucketId}`, {
                        prefixes: e
                    }, {
                        headers: t.headers
                    }))
                }
                async list(e, t, r) {
                    var n = this;
                    return n.handleOperation(async () => {
                        let s = eW(eW(eW({}, tt), t), {}, {
                            prefix: e || ""
                        });
                        return await e8(n.fetch, `${n.url}/object/list/${n.bucketId}`, s, {
                            headers: n.headers
                        }, r)
                    })
                }
                async listV2(e, t) {
                    var r = this;
                    return r.handleOperation(async () => {
                        let n = eW({}, e);
                        return await e8(r.fetch, `${r.url}/object/list-v2/${r.bucketId}`, n, {
                            headers: r.headers
                        }, t)
                    })
                }
                encodeMetadata(e) {
                    return JSON.stringify(e)
                }
                toBase64(e) {
                    return void 0 !== eM ? eM.from(e).toString("base64") : btoa(e)
                }
                _getFinalPath(e) {
                    return `${this.bucketId}/${e.replace(/^\/+/,"")}`
                }
                _removeEmptyFolders(e) {
                    return e.replace(/^\/|\/$/g, "").replace(/\/+/g, "/")
                }
                applyTransformOptsToQuery(e, t) {
                    return t.width && e.set("width", t.width.toString()), t.height && e.set("height", t.height.toString()), t.resize && e.set("resize", t.resize), t.format && e.set("format", t.format), t.quality && e.set("quality", t.quality.toString()), e
                }
            };
            let ts = {
                "X-Client-Info": "storage-js/2.108.0"
            };
            var ti = class extends e9 {
                    constructor(e, t = {}, r, n) {
                        const s = new URL(e);
                        (null == n ? void 0 : n.useNewHostname) && /supabase\.(co|in|red)$/.test(s.hostname) && !s.hostname.includes("storage.supabase.") && (s.hostname = s.hostname.replace("supabase.", "storage.supabase.")), super(s.href.replace(/\/$/, ""), eW(eW({}, ts), t), r, "storage")
                    }
                    async listBuckets(e) {
                        var t = this;
                        return t.handleOperation(async () => {
                            let r = t.listBucketOptionsToQueryString(e);
                            return await e2(t.fetch, `${t.url}/bucket${r}`, {
                                headers: t.headers
                            })
                        })
                    }
                    async getBucket(e) {
                        var t = this;
                        return t.handleOperation(async () => await e2(t.fetch, `${t.url}/bucket/${e}`, {
                            headers: t.headers
                        }))
                    }
                    async createBucket(e, t = {
                        public: !1
                    }) {
                        var r = this;
                        return r.handleOperation(async () => await e8(r.fetch, `${r.url}/bucket`, {
                            id: e,
                            name: e,
                            type: t.type,
                            public: t.public,
                            file_size_limit: t.fileSizeLimit,
                            allowed_mime_types: t.allowedMimeTypes
                        }, {
                            headers: r.headers
                        }))
                    }
                    async updateBucket(e, t) {
                        var r = this;
                        return r.handleOperation(async () => await e5(r.fetch, `${r.url}/bucket/${e}`, {
                            id: e,
                            name: e,
                            public: t.public,
                            file_size_limit: t.fileSizeLimit,
                            allowed_mime_types: t.allowedMimeTypes
                        }, {
                            headers: r.headers
                        }))
                    }
                    async emptyBucket(e) {
                        var t = this;
                        return t.handleOperation(async () => await e8(t.fetch, `${t.url}/bucket/${e}/empty`, {}, {
                            headers: t.headers
                        }))
                    }
                    async deleteBucket(e) {
                        var t = this;
                        return t.handleOperation(async () => await e3(t.fetch, `${t.url}/bucket/${e}`, {}, {
                            headers: t.headers
                        }))
                    }
                    listBucketOptionsToQueryString(e) {
                        let t = {};
                        return e && ("limit" in e && (t.limit = String(e.limit)), "offset" in e && (t.offset = String(e.offset)), e.search && (t.search = e.search), e.sortColumn && (t.sortColumn = e.sortColumn), e.sortOrder && (t.sortOrder = e.sortOrder)), Object.keys(t).length > 0 ? "?" + new URLSearchParams(t).toString() : ""
                    }
                },
                ta = class extends e9 {
                    constructor(e, t = {}, r) {
                        super(e.replace(/\/$/, ""), eW(eW({}, ts), t), r, "storage")
                    }
                    async createBucket(e) {
                        var t = this;
                        return t.handleOperation(async () => await e8(t.fetch, `${t.url}/bucket`, {
                            name: e
                        }, {
                            headers: t.headers
                        }))
                    }
                    async listBuckets(e) {
                        var t = this;
                        return t.handleOperation(async () => {
                            let r = new URLSearchParams;
                            (null == e ? void 0 : e.limit) !== void 0 && r.set("limit", e.limit.toString()), (null == e ? void 0 : e.offset) !== void 0 && r.set("offset", e.offset.toString()), (null == e ? void 0 : e.sortColumn) && r.set("sortColumn", e.sortColumn), (null == e ? void 0 : e.sortOrder) && r.set("sortOrder", e.sortOrder), (null == e ? void 0 : e.search) && r.set("search", e.search);
                            let n = r.toString(),
                                s = n ? `${t.url}/bucket?${n}` : `${t.url}/bucket`;
                            return await e2(t.fetch, s, {
                                headers: t.headers
                            })
                        })
                    }
                    async deleteBucket(e) {
                        var t = this;
                        return t.handleOperation(async () => await e3(t.fetch, `${t.url}/bucket/${e}`, {}, {
                            headers: t.headers
                        }))
                    }
                    from(e) {
                        var t = this;
                        if (!(!(!e || "string" != typeof e || 0 === e.length || e.length > 100 || e.trim() !== e || e.includes("/") || e.includes("\\")) && /^[\w!.\*'() &$@=;:+,?-]+$/.test(e))) throw new eV("Invalid bucket name: File, folder, and bucket names must follow AWS object key naming guidelines and should avoid the use of any other characters.");
                        let r = new eq({
                                baseUrl: this.url,
                                catalogName: e,
                                auth: {
                                    type: "custom",
                                    getHeaders: async () => t.headers
                                },
                                fetch: this.fetch
                            }),
                            n = this.shouldThrowOnError;
                        return new Proxy(r, {
                            get(e, t) {
                                let r = e[t];
                                return "function" != typeof r ? r : async (...t) => {
                                    try {
                                        return {
                                            data: await r.apply(e, t),
                                            error: null
                                        }
                                    } catch (e) {
                                        if (n) throw e;
                                        return {
                                            data: null,
                                            error: e
                                        }
                                    }
                                }
                            }
                        })
                    }
                },
                to = class extends e9 {
                    constructor(e, t = {}, r) {
                        super(e.replace(/\/$/, ""), eW(eW({}, ts), {}, {
                            "Content-Type": "application/json"
                        }, t), r, "vectors")
                    }
                    async createIndex(e) {
                        var t = this;
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/CreateIndex`, e, {
                            headers: t.headers
                        }) || {})
                    }
                    async getIndex(e, t) {
                        var r = this;
                        return r.handleOperation(async () => await e4.post(r.fetch, `${r.url}/GetIndex`, {
                            vectorBucketName: e,
                            indexName: t
                        }, {
                            headers: r.headers
                        }))
                    }
                    async listIndexes(e) {
                        var t = this;
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/ListIndexes`, e, {
                            headers: t.headers
                        }))
                    }
                    async deleteIndex(e, t) {
                        var r = this;
                        return r.handleOperation(async () => await e4.post(r.fetch, `${r.url}/DeleteIndex`, {
                            vectorBucketName: e,
                            indexName: t
                        }, {
                            headers: r.headers
                        }) || {})
                    }
                },
                tl = class extends e9 {
                    constructor(e, t = {}, r) {
                        super(e.replace(/\/$/, ""), eW(eW({}, ts), {}, {
                            "Content-Type": "application/json"
                        }, t), r, "vectors")
                    }
                    async putVectors(e) {
                        var t = this;
                        if (e.vectors.length < 1 || e.vectors.length > 500) throw Error("Vector batch size must be between 1 and 500 items");
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/PutVectors`, e, {
                            headers: t.headers
                        }) || {})
                    }
                    async getVectors(e) {
                        var t = this;
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/GetVectors`, e, {
                            headers: t.headers
                        }))
                    }
                    async listVectors(e) {
                        var t = this;
                        if (void 0 !== e.segmentCount) {
                            if (e.segmentCount < 1 || e.segmentCount > 16) throw Error("segmentCount must be between 1 and 16");
                            if (void 0 !== e.segmentIndex && (e.segmentIndex < 0 || e.segmentIndex >= e.segmentCount)) throw Error(`segmentIndex must be between 0 and ${e.segmentCount-1}`)
                        }
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/ListVectors`, e, {
                            headers: t.headers
                        }))
                    }
                    async queryVectors(e) {
                        var t = this;
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/QueryVectors`, e, {
                            headers: t.headers
                        }))
                    }
                    async deleteVectors(e) {
                        var t = this;
                        if (e.keys.length < 1 || e.keys.length > 500) throw Error("Keys batch size must be between 1 and 500 items");
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/DeleteVectors`, e, {
                            headers: t.headers
                        }) || {})
                    }
                },
                tc = class extends e9 {
                    constructor(e, t = {}, r) {
                        super(e.replace(/\/$/, ""), eW(eW({}, ts), {}, {
                            "Content-Type": "application/json"
                        }, t), r, "vectors")
                    }
                    async createBucket(e) {
                        var t = this;
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/CreateVectorBucket`, {
                            vectorBucketName: e
                        }, {
                            headers: t.headers
                        }) || {})
                    }
                    async getBucket(e) {
                        var t = this;
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/GetVectorBucket`, {
                            vectorBucketName: e
                        }, {
                            headers: t.headers
                        }))
                    }
                    async listBuckets(e = {}) {
                        var t = this;
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/ListVectorBuckets`, e, {
                            headers: t.headers
                        }))
                    }
                    async deleteBucket(e) {
                        var t = this;
                        return t.handleOperation(async () => await e4.post(t.fetch, `${t.url}/DeleteVectorBucket`, {
                            vectorBucketName: e
                        }, {
                            headers: t.headers
                        }) || {})
                    }
                },
                th = class extends tc {
                    constructor(e, t = {}) {
                        super(e, t.headers || {}, t.fetch)
                    }
                    from(e) {
                        return new tu(this.url, this.headers, e, this.fetch)
                    }
                    async createBucket(e) {
                        return super.createBucket.call(this, e)
                    }
                    async getBucket(e) {
                        return super.getBucket.call(this, e)
                    }
                    async listBuckets(e = {}) {
                        return super.listBuckets.call(this, e)
                    }
                    async deleteBucket(e) {
                        return super.deleteBucket.call(this, e)
                    }
                },
                tu = class extends to {
                    constructor(e, t, r, n) {
                        super(e, t, n), this.vectorBucketName = r
                    }
                    async createIndex(e) {
                        return super.createIndex.call(this, eW(eW({}, e), {}, {
                            vectorBucketName: this.vectorBucketName
                        }))
                    }
                    async listIndexes(e = {}) {
                        return super.listIndexes.call(this, eW(eW({}, e), {}, {
                            vectorBucketName: this.vectorBucketName
                        }))
                    }
                    async getIndex(e) {
                        return super.getIndex.call(this, this.vectorBucketName, e)
                    }
                    async deleteIndex(e) {
                        return super.deleteIndex.call(this, this.vectorBucketName, e)
                    }
                    index(e) {
                        return new td(this.url, this.headers, this.vectorBucketName, e, this.fetch)
                    }
                },
                td = class extends tl {
                    constructor(e, t, r, n, s) {
                        super(e, t, s), this.vectorBucketName = r, this.indexName = n
                    }
                    async putVectors(e) {
                        return super.putVectors.call(this, eW(eW({}, e), {}, {
                            vectorBucketName: this.vectorBucketName,
                            indexName: this.indexName
                        }))
                    }
                    async getVectors(e) {
                        return super.getVectors.call(this, eW(eW({}, e), {}, {
                            vectorBucketName: this.vectorBucketName,
                            indexName: this.indexName
                        }))
                    }
                    async listVectors(e = {}) {
                        return super.listVectors.call(this, eW(eW({}, e), {}, {
                            vectorBucketName: this.vectorBucketName,
                            indexName: this.indexName
                        }))
                    }
                    async queryVectors(e) {
                        return super.queryVectors.call(this, eW(eW({}, e), {}, {
                            vectorBucketName: this.vectorBucketName,
                            indexName: this.indexName
                        }))
                    }
                    async deleteVectors(e) {
                        return super.deleteVectors.call(this, eW(eW({}, e), {}, {
                            vectorBucketName: this.vectorBucketName,
                            indexName: this.indexName
                        }))
                    }
                },
                tf = class extends ti {
                    constructor(e, t = {}, r, n) {
                        super(e, t, r, n)
                    }
                    from(e) {
                        return new tn(this.url, this.headers, e, this.fetch)
                    }
                    get vectors() {
                        return new th(this.url + "/vector", {
                            headers: this.headers,
                            fetch: this.fetch
                        })
                    }
                    get analytics() {
                        return new ta(this.url + "/iceberg", this.headers, this.fetch)
                    }
                };
            r(8882);
            let tp = r(97194).A;
            r(328), r(44225);
            var tg = r(89651);
            let tm = "";
            "u" > typeof Deno ? (tm = "deno", i = null == (w = Deno.version) ? void 0 : w.deno) : "u" > typeof document ? tm = "web" : "u" > typeof navigator && "ReactNative" === navigator.product ? tm = "react-native" : (tm = "node", i = void 0 !== tg ? null == (v = tg.version) ? void 0 : v.replace(/^v/, "") : void 0);
            let ty = [`runtime=${tm}`];
            i && ty.push(`runtime-version=${i}`);
            let tb = {
                    headers: {
                        "X-Client-Info": `supabase-js/2.108.0; ${ty.join("; ")}`
                    }
                },
                tw = {
                    schema: "public"
                },
                tv = {
                    autoRefreshToken: !0,
                    persistSession: !0,
                    detectSessionInUrl: !0,
                    flowType: "implicit"
                },
                tE = {},
                tk = {
                    enabled: !1,
                    respectSamplingDecision: !0
                },
                tS = null;

            function tA(e) {
                return (tA = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function tT(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), r.push.apply(r, n)
                }
                return r
            }

            function tO(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? tT(Object(r), !0).forEach(function(t) {
                        ! function(e, t, r) {
                            var n;
                            (n = function(e, t) {
                                if ("object" != tA(e) || !e) return e;
                                var r = e[Symbol.toPrimitive];
                                if (void 0 !== r) {
                                    var n = r.call(e, t || "default");
                                    if ("object" != tA(n)) return n;
                                    throw TypeError("@@toPrimitive must return a primitive value.")
                                }
                                return ("string" === t ? String : Number)(e)
                            }(t, "string"), (t = "symbol" == tA(n) ? n : n + "") in e) ? Object.defineProperty(e, t, {
                                value: r,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }): e[t] = r
                        }(e, t, r[t])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : tT(Object(r)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    })
                }
                return e
            }
            async function tC(e, t, r) {
                if (! function(e, t) {
                        let r;
                        if (!e || !t || 0 === t.length) return !1;
                        if (e instanceof URL) r = e;
                        else try {
                            r = new URL(e)
                        } catch (e) {
                            return !1
                        }
                        for (let e of t) try {
                            if ("string" == typeof e) {
                                if (function(e, t) {
                                        if (t === e) return !0;
                                        if (t.startsWith("*.")) {
                                            let r = t.slice(2);
                                            if (e.endsWith(r) && (e === r || e.endsWith("." + r))) return !0
                                        }
                                        return !1
                                    }(r.hostname, e)) return !0
                            } else if (e instanceof RegExp) {
                                if (e.test(r.hostname)) return !0
                            } else if ("function" == typeof e && e(r)) return !0
                        } catch (e) {
                            continue
                        }
                        return !1
                    }("string" == typeof e || e instanceof URL ? e : e.url, t)) return null;
                let n = await
                function() {
                    var e, t, r, n;
                    return e = this, t = void 0, r = void 0, n = function*() {
                        try {
                            let e = yield(null === tS && (tS =
                                import ("@opentelemetry/api").catch(() => null)), tS);
                            if (!e || !e.propagation || !e.context) return null;
                            let t = {};
                            e.propagation.inject(e.context.active(), t);
                            let r = t.traceparent;
                            if (!r) return null;
                            return {
                                traceparent: r,
                                tracestate: t.tracestate,
                                baggage: t.baggage
                            }
                        } catch (e) {
                            return null
                        }
                    }, new(r || (r = Promise))(function(s, i) {
                        function a(e) {
                            try {
                                l(n.next(e))
                            } catch (e) {
                                i(e)
                            }
                        }

                        function o(e) {
                            try {
                                l(n.throw(e))
                            } catch (e) {
                                i(e)
                            }
                        }

                        function l(e) {
                            var t;
                            e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                                e(t)
                            })).then(a, o)
                        }
                        l((n = n.apply(e, t || [])).next())
                    })
                }();
                if (!n || !n.traceparent) return null;
                if (r) {
                    let e = function(e) {
                        if (!e || "string" != typeof e) return null;
                        let t = e.split("-");
                        if (4 !== t.length) return null;
                        let [r, n, s, i] = t;
                        if (2 !== r.length || 32 !== n.length || 16 !== s.length || 2 !== i.length) return null;
                        let a = /^[0-9a-f]+$/i;
                        return a.test(r) && a.test(n) && a.test(s) && a.test(i) && "00000000000000000000000000000000" !== n && "0000000000000000" !== s ? {
                            version: r,
                            traceId: n,
                            parentId: s,
                            traceFlags: i,
                            isSampled: (1 & parseInt(i, 16)) == 1
                        } : null
                    }(n.traceparent);
                    if (e && !e.isSampled) return null
                }
                return n
            }

            function t_(e) {
                return "boolean" == typeof e ? {
                    enabled: e
                } : e
            }
            var tR = class extends tp {
                    constructor(e) {
                        super(e)
                    }
                },
                tP = class {
                    constructor(e, t, r) {
                        var n, s, i;
                        this.supabaseUrl = e, this.supabaseKey = t;
                        const a = function(e) {
                            let t = null == e ? void 0 : e.trim();
                            if (!t) throw Error("supabaseUrl is required.");
                            if (!t.match(/^https?:\/\//i)) throw Error("Invalid supabaseUrl: Must be a valid HTTP or HTTPS URL.");
                            try {
                                return new URL(t.endsWith("/") ? t : t + "/")
                            } catch (e) {
                                throw Error("Invalid supabaseUrl: Provided URL is malformed.")
                            }
                        }(e);
                        if (!t) throw Error("supabaseKey is required.");
                        this.realtimeUrl = new URL("realtime/v1", a), this.realtimeUrl.protocol = this.realtimeUrl.protocol.replace("http", "ws"), this.authUrl = new URL("auth/v1", a), this.storageUrl = new URL("storage/v1", a), this.functionsUrl = new URL("functions/v1", a);
                        const o = `sb-${a.hostname.split(".")[0]}-auth-token`,
                            l = function(e, t) {
                                var r, n, s, i, a, o;
                                let {
                                    db: l,
                                    auth: c,
                                    realtime: h,
                                    global: u
                                } = e, {
                                    db: d,
                                    auth: f,
                                    realtime: p,
                                    global: g
                                } = t, m = t_(e.tracePropagation), y = t_(t.tracePropagation), b = {
                                    db: tO(tO({}, d), l),
                                    auth: tO(tO({}, f), c),
                                    realtime: tO(tO({}, p), h),
                                    storage: {},
                                    global: tO(tO(tO({}, g), u), {}, {
                                        headers: tO(tO({}, null != (r = null == g ? void 0 : g.headers) ? r : {}), null != (n = null == u ? void 0 : u.headers) ? n : {})
                                    }),
                                    tracePropagation: {
                                        enabled: null != (s = null != (i = null == m ? void 0 : m.enabled) ? i : null == y ? void 0 : y.enabled) && s,
                                        respectSamplingDecision: null == (a = null != (o = null == m ? void 0 : m.respectSamplingDecision) ? o : null == y ? void 0 : y.respectSamplingDecision) || a
                                    },
                                    accessToken: async () => ""
                                };
                                return e.accessToken ? b.accessToken = e.accessToken : delete b.accessToken, b
                            }(null != r ? r : {}, {
                                db: tw,
                                realtime: tE,
                                auth: tO(tO({}, tv), {}, {
                                    storageKey: o
                                }),
                                global: tb,
                                tracePropagation: tk
                            });
                        this.settings = l, this.storageKey = null != (n = l.auth.storageKey) ? n : "", this.headers = null != (s = l.global.headers) ? s : {}, l.accessToken ? (this.accessToken = l.accessToken, this.auth = new Proxy({}, {
                            get: (e, t) => {
                                throw Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(t)} is not possible`)
                            }
                        })) : this.auth = this._initSupabaseAuthClient(null != (i = l.auth) ? i : {}, this.headers, l.global.fetch), this.fetch = ((e, t, r, n, s) => {
                            let i = n ? (...e) => n(...e) : (...e) => fetch(...e),
                                a = Headers,
                                o = (null == s ? void 0 : s.enabled) === !0,
                                l = (null == s ? void 0 : s.respectSamplingDecision) !== !1,
                                c = o ? function(e) {
                                    let t = [];
                                    try {
                                        let r = new URL(e);
                                        t.push(r.hostname)
                                    } catch (e) {}
                                    return t.push("*.supabase.co", "*.supabase.in"), t.push("localhost", "127.0.0.1", "[::1]"), t
                                }(t) : null;
                            return async (t, n) => {
                                var s;
                                let o = null != (s = await r()) ? s : e,
                                    h = new a(null == n ? void 0 : n.headers);
                                if (h.has("apikey") || h.set("apikey", e), h.has("Authorization") || h.set("Authorization", `Bearer ${o}`), c) {
                                    let e = await tC(t, c, l);
                                    e && (e.traceparent && !h.has("traceparent") && h.set("traceparent", e.traceparent), e.tracestate && !h.has("tracestate") && h.set("tracestate", e.tracestate), e.baggage && !h.has("baggage") && h.set("baggage", e.baggage))
                                }
                                return i(t, tO(tO({}, n), {}, {
                                    headers: h
                                }))
                            }
                        })(t, e, this._getAccessToken.bind(this), l.global.fetch, l.tracePropagation), this.realtime = this._initRealtimeClient(tO({
                            headers: this.headers,
                            accessToken: this._getAccessToken.bind(this),
                            fetch: this.fetch
                        }, l.realtime)), this.accessToken && Promise.resolve(this.accessToken()).then(e => this.realtime.setAuth(e)).catch(e => console.warn("Failed to set initial Realtime auth token:", e)), this.rest = new H(new URL("rest/v1", a).href, {
                            headers: this.headers,
                            schema: l.db.schema,
                            fetch: this.fetch,
                            timeout: l.db.timeout,
                            urlLengthLimit: l.db.urlLengthLimit
                        }), this.storage = new tf(this.storageUrl.href, this.headers, this.fetch, null == r ? void 0 : r.storage), l.accessToken || this._listenForAuthEvents()
                    }
                    get functions() {
                        return new O(this.functionsUrl.href, {
                            headers: this.headers,
                            customFetch: this.fetch
                        })
                    }
                    from(e) {
                        return this.rest.from(e)
                    }
                    schema(e) {
                        return this.rest.schema(e)
                    }
                    rpc(e, t = {}, r = {
                        head: !1,
                        get: !1,
                        count: void 0
                    }) {
                        return this.rest.rpc(e, t, r)
                    }
                    channel(e, t = {
                        config: {}
                    }) {
                        return this.realtime.channel(e, t)
                    }
                    getChannels() {
                        return this.realtime.getChannels()
                    }
                    removeChannel(e) {
                        return this.realtime.removeChannel(e)
                    }
                    removeAllChannels() {
                        return this.realtime.removeAllChannels()
                    }
                    async _getAccessToken() {
                        var e, t;
                        if (this.accessToken) return await this.accessToken();
                        let {
                            data: r
                        } = await this.auth.getSession();
                        return null != (e = null == (t = r.session) ? void 0 : t.access_token) ? e : this.supabaseKey
                    }
                    _initSupabaseAuthClient({
                        autoRefreshToken: e,
                        persistSession: t,
                        detectSessionInUrl: r,
                        storage: n,
                        userStorage: s,
                        storageKey: i,
                        flowType: a,
                        lock: o,
                        debug: l,
                        throwOnError: c,
                        experimental: h,
                        lockAcquireTimeout: u,
                        skipAutoInitialize: d
                    }, f, p) {
                        let g = {
                            Authorization: `Bearer ${this.supabaseKey}`,
                            apikey: `${this.supabaseKey}`
                        };
                        return new tR({
                            url: this.authUrl.href,
                            headers: tO(tO({}, g), f),
                            storageKey: i,
                            autoRefreshToken: e,
                            persistSession: t,
                            detectSessionInUrl: r,
                            storage: n,
                            userStorage: s,
                            flowType: a,
                            lock: o,
                            debug: l,
                            throwOnError: c,
                            experimental: h,
                            fetch: p,
                            lockAcquireTimeout: u,
                            skipAutoInitialize: d,
                            hasCustomAuthorizationHeader: Object.keys(this.headers).some(e => "authorization" === e.toLowerCase())
                        })
                    }
                    _initRealtimeClient(e) {
                        return new eU(this.realtimeUrl.href, tO(tO({}, e), {}, {
                            params: tO(tO({}, {
                                apikey: this.supabaseKey
                            }), null == e ? void 0 : e.params)
                        }))
                    }
                    _listenForAuthEvents() {
                        return this.auth.onAuthStateChange((e, t) => {
                            this._handleTokenChanged(e, "CLIENT", null == t ? void 0 : t.access_token)
                        })
                    }
                    _handleTokenChanged(e, t, r) {
                        ("TOKEN_REFRESHED" === e || "SIGNED_IN" === e) && this.changedAccessToken !== r ? (this.changedAccessToken = r, this.realtime.setAuth(r)) : "SIGNED_OUT" === e && (this.realtime.setAuth(), "STORAGE" == t && this.auth.signOut(), this.changedAccessToken = void 0)
                    }
                };
            (function() {
                if ("u" > typeof window) return !1;
                let e = globalThis.process;
                if (!e) return !1;
                let t = e.version;
                if (null == t) return !1;
                let r = t.match(/^v(\d+)\./);
                return !!r && 18 >= parseInt(r[1], 10)
            })() && console.warn("\u26a0\ufe0f  Node.js 18 and below are deprecated and will no longer be supported in future versions of @supabase/supabase-js. Please upgrade to Node.js 20 or later. For more information, visit: https://github.com/orgs/supabase/discussions/37217");
            var tj = r(66547);

            function t$() {
                return "u" > typeof window && void 0 !== window.document
            }
            tj.qg, tj.lK;
            let tx = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".split(""),
                tU = " 	\n\r=".split(""),
                tI = (() => {
                    let e = Array(128);
                    for (let t = 0; t < e.length; t += 1) e[t] = -1;
                    for (let t = 0; t < tU.length; t += 1) e[tU[t].charCodeAt(0)] = -2;
                    for (let t = 0; t < tx.length; t += 1) e[tx[t].charCodeAt(0)] = t;
                    return e
                })();

            function tN(e) {
                let t = [],
                    r = 0,
                    n = 0;
                if (function(e, t) {
                        for (let r = 0; r < e.length; r += 1) {
                            let n = e.charCodeAt(r);
                            if (n > 55295 && n <= 56319) {
                                let t = (n - 55296) * 1024 & 65535;
                                n = (e.charCodeAt(r + 1) - 56320 & 65535 | t) + 65536, r += 1
                            }! function(e, t) {
                                if (e <= 127) return t(e);
                                if (e <= 2047) {
                                    t(192 | e >> 6), t(128 | 63 & e);
                                    return
                                }
                                if (e <= 65535) {
                                    t(224 | e >> 12), t(128 | e >> 6 & 63), t(128 | 63 & e);
                                    return
                                }
                                if (e <= 1114111) {
                                    t(240 | e >> 18), t(128 | e >> 12 & 63), t(128 | e >> 6 & 63), t(128 | 63 & e);
                                    return
                                }
                                throw Error(`Unrecognized Unicode codepoint: ${e.toString(16)}`)
                            }(n, t)
                        }
                    }(e, e => {
                        for (r = r << 8 | e, n += 8; n >= 6;) {
                            let e = r >> n - 6 & 63;
                            t.push(tx[e]), n -= 6
                        }
                    }), n > 0)
                    for (r <<= 6 - n, n = 6; n >= 6;) {
                        let e = r >> n - 6 & 63;
                        t.push(tx[e]), n -= 6
                    }
                return t.join("")
            }
            let tB = /^(.*)[.](0|[1-9][0-9]*)$/;

            function tL(e, t) {
                if (e === t) return !0;
                let r = e.match(tB);
                return !!r && r[1] === t
            }

            function tD(e, t, r) {
                let n = r ? ? 3180,
                    s = encodeURIComponent(t);
                if (s.length <= n) return [{
                    name: e,
                    value: t
                }];
                let i = [];
                for (; s.length > 0;) {
                    let e = s.slice(0, n),
                        t = e.lastIndexOf("%");
                    t > n - 3 && (e = e.slice(0, t));
                    let r = "";
                    for (; e.length > 0;) try {
                        r = decodeURIComponent(e);
                        break
                    } catch (t) {
                        if (t instanceof URIError && "%" === e.at(-3) && e.length > 3) e = e.slice(0, e.length - 3);
                        else throw t
                    }
                    i.push(r), s = s.slice(e.length)
                }
                return i.map((t, r) => ({
                    name: `${e}.${r}`,
                    value: t
                }))
            }
            async function tH(e, t) {
                let r = await t(e);
                if (r) return r;
                let n = [];
                for (let r = 0;; r++) {
                    let s = `${e}.${r}`,
                        i = await t(s);
                    if (!i) break;
                    n.push(i)
                }
                return n.length > 0 ? n.join("") : null
            }
            let tq = {
                    path: "/",
                    sameSite: "lax",
                    httpOnly: !1,
                    maxAge: 3456e4
                },
                tM = "base64-";

            function tJ(e) {
                let t;
                if (!e.startsWith(tM)) return e;
                try {
                    t = function(e) {
                        let t = [],
                            r = e => {
                                t.push(String.fromCodePoint(e))
                            },
                            n = {
                                utf8seq: 0,
                                codepoint: 0
                            },
                            s = 0,
                            i = 0;
                        for (let t = 0; t < e.length; t += 1) {
                            let a = tI[e.charCodeAt(t)];
                            if (a > -1)
                                for (s = s << 6 | a, i += 6; i >= 8;)(function(e, t, r) {
                                    if (0 === t.utf8seq) {
                                        if (e <= 127) return r(e);
                                        for (let r = 1; r < 6; r += 1)
                                            if ((e >> 7 - r & 1) == 0) {
                                                t.utf8seq = r;
                                                break
                                            }
                                        if (2 === t.utf8seq) t.codepoint = 31 & e;
                                        else if (3 === t.utf8seq) t.codepoint = 15 & e;
                                        else if (4 === t.utf8seq) t.codepoint = 7 & e;
                                        else throw Error("Invalid UTF-8 sequence");
                                        t.utf8seq -= 1
                                    } else if (t.utf8seq > 0) {
                                        if (e <= 127) throw Error("Invalid UTF-8 sequence");
                                        t.codepoint = t.codepoint << 6 | 63 & e, t.utf8seq -= 1, 0 === t.utf8seq && r(t.codepoint)
                                    }
                                })(s >> i - 8 & 255, n, r), i -= 8;
                            else if (-2 === a) continue;
                            else throw Error(`Invalid Base64-URL character "${e.at(t)}" at position ${t}`)
                        }
                        return t.join("")
                    }(e.substring(tM.length))
                } catch (e) {
                    return console.warn("@supabase/ssr: could not base64url-decode chunked cookie value, treating as absent. Cookie chunks may have been written partially across responses.", e), null
                }
                try {
                    JSON.parse(t)
                } catch {
                    return console.warn("@supabase/ssr: chunked cookie decoded to invalid JSON, treating as absent. This usually indicates that cookie chunks from different writes were combined (e.g. response committed before all Set-Cookie headers were sent)."), null
                }
                return t
            }
            async function tF({
                getAll: e,
                setAll: t,
                setItems: r,
                removedItems: n
            }, s) {
                let i = s.cookieEncoding,
                    a = s.cookieOptions ? ? null,
                    o = await e([...r ? Object.keys(r) : [], ...n ? Object.keys(n) : []]),
                    l = o ? .map(({
                        name: e
                    }) => e) || [],
                    c = Object.keys(n).flatMap(e => l.filter(t => tL(t, e))),
                    h = Object.keys(r).flatMap(e => {
                        let t = new Set(l.filter(t => tL(t, e))),
                            n = r[e];
                        "base64url" === i && (n = tM + tN(n));
                        let s = tD(e, n);
                        return s.forEach(e => {
                            t.delete(e.name)
                        }), c.push(...t), s
                    }),
                    u = { ...tq,
                        ...a,
                        maxAge: 0
                    },
                    d = { ...tq,
                        ...a,
                        maxAge: tq.maxAge
                    };
                delete u.name, delete d.name, await t([...c.map(e => ({
                    name: e,
                    value: "",
                    options: u
                })), ...h.map(({
                    name: e,
                    value: t
                }) => ({
                    name: e,
                    value: t,
                    options: d
                }))], {
                    "Cache-Control": "private, no-cache, no-store, must-revalidate, max-age=0",
                    Expires: "0",
                    Pragma: "no-cache"
                })
            }
            var tW = r(89651);
            let tV = !1,
                tK = ["@supabase/auth-helpers-nextjs", "@supabase/auth-helpers-react", "@supabase/auth-helpers-remix", "@supabase/auth-helpers-sveltekit"];

            function tz(e, t, r) {
                ! function() {
                    if (tV || void 0 === tW || !tW.env ? .npm_package_name) return;
                    let e = tW.env.npm_package_name;
                    tK.includes(e) && (tV = !0, console.warn(`
\u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557
\u2551 \u26a0\ufe0f  IMPORTANT: Package Consolidation Notice                                \u2551
\u2551                                                                            \u2551
\u2551 The ${e.padEnd(35)} package name is deprecated.  \u2551
\u2551                                                                            \u2551
\u2551 You are now using @supabase/ssr - a unified solution for all frameworks.  \u2551
\u2551                                                                            \u2551
\u2551 The auth-helpers packages have been consolidated into @supabase/ssr       \u2551
\u2551 to provide better maintenance and consistent APIs across frameworks.      \u2551
\u2551                                                                            \u2551
\u2551 Please update your package.json to use @supabase/ssr directly:            \u2551
\u2551   npm uninstall ${e.padEnd(42)} \u2551
\u2551   npm install @supabase/ssr                                               \u2551
\u2551                                                                            \u2551
\u2551 For more information, visit:                                              \u2551
\u2551 https://supabase.com/docs/guides/auth/server-side                         \u2551
\u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d
    `))
                }();
                let n = r ? .isSingleton === !0 || (!r || !("isSingleton" in r)) && t$();
                if (n && a) return a;
                if (!e || !t) throw Error(`@supabase/ssr: Your project's URL and API key are required to create a Supabase client!

Check your Supabase project's API settings to find these values

https://supabase.com/dashboard/project/_/settings/api`);
                let {
                    storage: s
                } = function(e, t) {
                    let r, n, s = e.cookies ? ? null,
                        i = e.cookieEncoding,
                        a = {},
                        o = {},
                        l = () => {
                            let e = (0, tj.qg)(document.cookie);
                            return Object.keys(e).map(t => ({
                                name: t,
                                value: e[t] ? ? ""
                            }))
                        },
                        c = e => {
                            e.forEach(({
                                name: e,
                                value: t,
                                options: r
                            }) => {
                                document.cookie = (0, tj.lK)(e, t, r)
                            })
                        };
                    if (s)
                        if ("get" in s) {
                            let e = async e => {
                                let t = e.flatMap(e => [e, ...Array.from({
                                        length: 5
                                    }).map((t, r) => `${e}.${r}`)]),
                                    r = [];
                                for (let e = 0; e < t.length; e += 1) {
                                    let n = await s.get(t[e]);
                                    (n || "string" == typeof n) && r.push({
                                        name: t[e],
                                        value: n
                                    })
                                }
                                return r
                            };
                            if (r = async t => await e(t), "set" in s && "remove" in s) n = async e => {
                                for (let t = 0; t < e.length; t += 1) {
                                    let {
                                        name: r,
                                        value: n,
                                        options: i
                                    } = e[t];
                                    n ? await s.set(r, n, i) : await s.remove(r, i)
                                }
                            };
                            else if (t) n = async () => {
                                console.warn("@supabase/ssr: createServerClient was configured without set and remove cookie methods, but the client needs to set cookies. This can lead to issues such as random logouts, early session termination or increased token refresh requests. If in NextJS, check your middleware.ts file, route handlers and server actions for correctness. Consider switching to the getAll and setAll cookie methods instead of get, set and remove which are deprecated and can be difficult to use correctly.")
                            };
                            else throw Error("@supabase/ssr: createBrowserClient requires configuring a getAll and setAll cookie method (deprecated: alternatively both get, set and remove can be used)")
                        } else if ("getAll" in s)
                        if (r = async () => await s.getAll(), "setAll" in s) n = s.setAll;
                        else if (t) n = async () => {
                        console.warn("@supabase/ssr: createServerClient was configured without the setAll cookie method, but the client needs to set cookies. This can lead to issues such as random logouts, early session termination or increased token refresh requests. If in NextJS, check your middleware.ts file, route handlers and server actions for correctness.")
                    };
                    else throw Error("@supabase/ssr: createBrowserClient requires configuring both getAll and setAll cookie methods (deprecated: alternatively both get, set and remove can be used)");
                    else if (!t && t$()) r = () => l(), n = c;
                    else throw Error(`@supabase/ssr: ${t?"createServerClient":"createBrowserClient"} requires configuring getAll and setAll cookie methods (deprecated: alternatively use get, set and remove).${t$()?" As this is called in a browser runtime, consider removing the cookies option object to use the document.cookie API automatically.":""}`);
                    else if (!t && t$()) r = () => l(), n = c;
                    else if (t) throw Error("@supabase/ssr: createServerClient must be initialized with cookie options that specify getAll and setAll functions (deprecated, not recommended: alternatively use get, set and remove)");
                    else r = () => [], n = () => {
                        throw Error("@supabase/ssr: createBrowserClient in non-browser runtimes (including Next.js pre-rendering mode) was not initialized cookie options that specify getAll and setAll functions (deprecated: alternatively use get, set and remove), but they were needed")
                    };
                    return t ? {
                        getAll: r,
                        setAll: n,
                        setItems: a,
                        removedItems: o,
                        storage: {
                            isServer: !0,
                            getItem: async e => {
                                if ("string" == typeof a[e]) return a[e];
                                if (o[e]) return null;
                                let t = await r([e]),
                                    n = await tH(e, async e => {
                                        let r = t ? .find(({
                                            name: t
                                        }) => t === e) || null;
                                        return r ? r.value : null
                                    });
                                return n ? "string" != typeof n ? n : tJ(n) : null
                            },
                            setItem: async (t, s) => {
                                t.endsWith("-code-verifier") && await tF({
                                    getAll: r,
                                    setAll: n,
                                    setItems: {
                                        [t]: s
                                    },
                                    removedItems: {}
                                }, {
                                    cookieOptions: e ? .cookieOptions ? ? null,
                                    cookieEncoding: i
                                }), a[t] = s, delete o[t]
                            },
                            removeItem: async e => {
                                delete a[e], o[e] = !0
                            }
                        }
                    } : {
                        getAll: r,
                        setAll: n,
                        setItems: a,
                        removedItems: o,
                        storage: {
                            isServer: !1,
                            getItem: async e => {
                                let t = await r([e]),
                                    n = await tH(e, async e => {
                                        let r = t ? .find(({
                                            name: t
                                        }) => t === e) || null;
                                        return r ? r.value : null
                                    });
                                return n ? tJ(n) : null
                            },
                            setItem: async (t, s) => {
                                let a = await r([t]),
                                    o = new Set((a ? .map(({
                                        name: e
                                    }) => e) || []).filter(e => tL(e, t))),
                                    l = s;
                                "base64url" === i && (l = tM + tN(s));
                                let c = tD(t, l);
                                c.forEach(({
                                    name: e
                                }) => {
                                    o.delete(e)
                                });
                                let h = { ...tq,
                                        ...e ? .cookieOptions,
                                        maxAge : 0
                                    },
                                    u = { ...tq,
                                        ...e ? .cookieOptions,
                                        maxAge : tq.maxAge
                                    };
                                delete h.name, delete u.name;
                                let d = [...[...o].map(e => ({
                                    name: e,
                                    value: "",
                                    options: h
                                })), ...c.map(({
                                    name: e,
                                    value: t
                                }) => ({
                                    name: e,
                                    value: t,
                                    options: u
                                }))];
                                d.length > 0 && await n(d, {})
                            },
                            removeItem: async t => {
                                let s = await r([t]),
                                    i = (s ? .map(({
                                        name: e
                                    }) => e) || []).filter(e => tL(e, t)),
                                    a = { ...tq,
                                        ...e ? .cookieOptions,
                                        maxAge : 0
                                    };
                                delete a.name, i.length > 0 && await n(i.map(e => ({
                                    name: e,
                                    value: "",
                                    options: a
                                })), {})
                            }
                        }
                    }
                }({ ...r,
                    cookieEncoding: r ? .cookieEncoding ? ? "base64url"
                }, !1), i = new tP(e, t, { ...r,
                    global: { ...r ? .global,
                        headers : { ...r ? .global ? .headers,
                            "X-Client-Info" : "supabase-ssr/0.10.3 createBrowserClient"
                        }
                    },
                    auth: { ...r ? .auth,
                        ...r ? .cookieOptions ? .name ? {
                            storageKey: r.cookieOptions.name
                        } : null,
                        flowType : "pkce",
                        autoRefreshToken : r ? .auth ? .autoRefreshToken ? ? t$(),
                        detectSessionInUrl : r ? .auth ? .detectSessionInUrl ? ? t$(),
                        persistSession : r ? .auth ? .persistSession ? ? !0,
                        storage : s,
                        ...r ? .cookies && "encode" in r.cookies && "tokens-only" === r.cookies.encode ? {
                            userStorage: r ? .auth ? .userStorage ? ? window.localStorage
                        } : null
                    }
                });
                return n && (a = i), i
            }
        },
        43092: (e, t, r) => {
            "use strict";
            r.d(t, {
                Bd: () => l,
                Cq: () => b,
                Gb: () => m,
                Go: () => U,
                K8: () => _,
                KY: () => o,
                LJ: () => h,
                Oi: () => p,
                PB: () => v,
                QE: () => $,
                Rn: () => O,
                U9: () => g,
                W0: () => P,
                WJ: () => a,
                XR: () => u,
                aA: () => j,
                c2: () => C,
                cY: () => y,
                dS: () => A,
                lA: () => d,
                pF: () => f,
                uO: () => x,
                yy: () => w
            });
            var n = r(93516),
                s = r(328),
                i = r(86465);

            function a(e) {
                return Math.round(Date.now() / 1e3) + e
            }

            function o() {
                return Symbol("auth-callback")
            }
            let l = () => "u" > typeof window && "u" > typeof document,
                c = {
                    tested: !1,
                    writable: !1
                },
                h = () => {
                    if (!l()) return !1;
                    try {
                        if ("object" != typeof globalThis.localStorage) return !1
                    } catch (e) {
                        return !1
                    }
                    if (c.tested) return c.writable;
                    let e = `lswt-${Math.random()}${Math.random()}`;
                    try {
                        globalThis.localStorage.setItem(e, e), globalThis.localStorage.removeItem(e), c.tested = !0, c.writable = !0
                    } catch (e) {
                        c.tested = !0, c.writable = !1
                    }
                    return c.writable
                };

            function u(e) {
                let t = {},
                    r = new URL(e);
                if (r.hash && "#" === r.hash[0]) try {
                    new URLSearchParams(r.hash.substring(1)).forEach((e, r) => {
                        t[r] = e
                    })
                } catch (e) {}
                return r.searchParams.forEach((e, r) => {
                    t[r] = e
                }), t
            }
            let d = e => e ? (...t) => e(...t) : (...e) => fetch(...e),
                f = e => "object" == typeof e && null !== e && "status" in e && "ok" in e && "json" in e && "function" == typeof e.json,
                p = async (e, t, r) => {
                    await e.setItem(t, JSON.stringify(r))
                },
                g = async (e, t) => {
                    let r = await e.getItem(t);
                    if (!r) return null;
                    try {
                        return JSON.parse(r)
                    } catch (e) {
                        return null
                    }
                },
                m = async (e, t) => {
                    await e.removeItem(t)
                };
            class y {
                constructor() {
                    this.promise = new y.promiseConstructor((e, t) => {
                        this.resolve = e, this.reject = t
                    })
                }
            }

            function b(e) {
                let t = e.split(".");
                if (3 !== t.length) throw new s.xL("Invalid JWT structure");
                for (let e = 0; e < t.length; e++)
                    if (!n.Jj.test(t[e])) throw new s.xL("JWT not in base64url format");
                return {
                    header: JSON.parse((0, i.uE)(t[0])),
                    payload: JSON.parse((0, i.uE)(t[1])),
                    signature: (0, i.xf)(t[2]),
                    raw: {
                        header: t[0],
                        payload: t[1]
                    }
                }
            }
            async function w(e) {
                return await new Promise(t => {
                    setTimeout(() => t(null), e)
                })
            }

            function v(e, t) {
                return new Promise((r, n) => {
                    (async () => {
                        for (let s = 0; s < 1 / 0; s++) try {
                            let n = await e(s);
                            if (!t(s, null, n)) return void r(n)
                        } catch (e) {
                            if (!t(s, e)) return void n(e)
                        }
                    })()
                })
            }

            function E(e) {
                return ("0" + e.toString(16)).substr(-2)
            }
            async function k(e) {
                let t = new TextEncoder().encode(e);
                return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", t))).map(e => String.fromCharCode(e)).join("")
            }
            async function S(e) {
                return "u" > typeof crypto && void 0 !== crypto.subtle && "u" > typeof TextEncoder ? btoa(await k(e)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "") : (console.warn("WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256."), e)
            }
            async function A(e, t, r = !1) {
                let n = function() {
                        let e = new Uint32Array(56);
                        if ("u" < typeof crypto) {
                            let e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~",
                                t = e.length,
                                r = "";
                            for (let n = 0; n < 56; n++) r += e.charAt(Math.floor(Math.random() * t));
                            return r
                        }
                        return crypto.getRandomValues(e), Array.from(e, E).join("")
                    }(),
                    s = n;
                r && (s += "/recovery"), await p(e, `${t}-code-verifier`, s);
                let i = await S(n),
                    a = n === i ? "plain" : "s256";
                return [i, a]
            }
            y.promiseConstructor = Promise;
            let T = /^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;

            function O(e) {
                let t = e.headers.get(n.sk);
                if (!t || !t.match(T)) return null;
                try {
                    return new Date(`${t}T00:00:00.0Z`)
                } catch (e) {
                    return null
                }
            }

            function C(e) {
                if (!e) throw Error("Missing exp claim");
                if (e <= Math.floor(Date.now() / 1e3)) throw Error("JWT has expired")
            }

            function _(e) {
                switch (e) {
                    case "RS256":
                        return {
                            name: "RSASSA-PKCS1-v1_5",
                            hash: {
                                name: "SHA-256"
                            }
                        };
                    case "ES256":
                        return {
                            name: "ECDSA",
                            namedCurve: "P-256",
                            hash: {
                                name: "SHA-256"
                            }
                        };
                    default:
                        throw Error("Invalid alg claim")
                }
            }
            let R = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

            function P(e) {
                if (!R.test(e)) throw Error("@supabase/auth-js: Expected parameter to be UUID but is not")
            }

            function j(e) {
                if (!e.passkey) throw Error("@supabase/auth-js: the passkey API is experimental and disabled by default. Enable it by passing `auth: { experimental: { passkey: true } }` to createClient (or to the GoTrueClient constructor).")
            }

            function $() {
                return new Proxy({}, {
                    get: (e, t) => {
                        if ("__isUserNotAvailableProxy" === t) return !0;
                        if ("symbol" == typeof t) {
                            let e = t.toString();
                            if ("Symbol(Symbol.toPrimitive)" === e || "Symbol(Symbol.toStringTag)" === e || "Symbol(util.inspect.custom)" === e) return
                        }
                        throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Accessing the "${t}" property of the session object is not supported. Please use getUser() instead.`)
                    },
                    set: (e, t) => {
                        throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Setting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`)
                    },
                    deleteProperty: (e, t) => {
                        throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Deleting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`)
                    }
                })
            }

            function x(e, t) {
                return new Proxy(e, {
                    get: (e, r, n) => {
                        if ("__isInsecureUserWarningProxy" === r) return !0;
                        if ("symbol" == typeof r) {
                            let t = r.toString();
                            if ("Symbol(Symbol.toPrimitive)" === t || "Symbol(Symbol.toStringTag)" === t || "Symbol(util.inspect.custom)" === t || "Symbol(nodejs.util.inspect.custom)" === t) return Reflect.get(e, r, n)
                        }
                        return t.value || "string" != typeof r || (console.warn("Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and may not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server."), t.value = !0), Reflect.get(e, r, n)
                    }
                })
            }

            function U(e) {
                return JSON.parse(JSON.stringify(e))
            }
        },
        44225: (e, t, r) => {
            "use strict";
            r.d(t, {
                nb: () => s
            });
            var n = r(43092);
            globalThis && (0, n.LJ)() && globalThis.localStorage && globalThis.localStorage.getItem("supabase.gotrue-js.locks.debug");
            class s extends Error {
                constructor(e) {
                    super(e), this.isAcquireTimeout = !0
                }
            }
        },
        46715: (e, t, r) => {
            "use strict";
            r.d(t, {
                Tt: () => n,
                sH: () => s
            });

            function n(e, t) {
                var r = {};
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && 0 > t.indexOf(n) && (r[n] = e[n]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var s = 0, n = Object.getOwnPropertySymbols(e); s < n.length; s++) 0 > t.indexOf(n[s]) && Object.prototype.propertyIsEnumerable.call(e, n[s]) && (r[n[s]] = e[n[s]]);
                return r
            }

            function s(e, t, r, n) {
                return new(r || (r = Promise))(function(s, i) {
                    function a(e) {
                        try {
                            l(n.next(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function o(e) {
                        try {
                            l(n.throw(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                            e(t)
                        })).then(a, o)
                    }
                    l((n = n.apply(e, t || [])).next())
                })
            }
            "function" == typeof SuppressedError && SuppressedError
        },
        58253: (e, t, r) => {
            "use strict";

            function n() {
                if ("object" != typeof globalThis) try {
                    Object.defineProperty(Object.prototype, "__magic__", {
                        get: function() {
                            return this
                        },
                        configurable: !0
                    }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__
                } catch (e) {
                    "u" > typeof self && (self.globalThis = self)
                }
            }
            r.d(t, {
                V: () => n
            })
        },
        66547: (e, t) => {
            "use strict";
            let r;
            t.qg = function(e, t) {
                let r = new l,
                    n = e.length;
                if (n < 2) return r;
                let s = t ? .decode || u,
                    i = 0;
                do {
                    let t = function(e, t, r) {
                        let n = e.indexOf("=", t);
                        return n < r ? n : -1
                    }(e, i, n);
                    if (-1 === t) break;
                    let a = function(e, t, r) {
                        let n = e.indexOf(";", t);
                        return -1 === n ? r : n
                    }(e, i, n);
                    if (t > a) {
                        i = e.lastIndexOf(";", t - 1) + 1;
                        continue
                    }
                    let o = h(e, i, t);
                    void 0 === r[o] && (r[o] = s(h(e, t + 1, a))), i = a + 1
                } while (i < n);
                return r
            }, t.lK = c, t.lK = c;
            let n = /^[\u0021-\u003A\u003C\u003E-\u007E]+$/,
                s = /^[\u0021-\u003A\u003C-\u007E]*$/,
                i = /^([.]?[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)([.][a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i,
                a = /^[\u0020-\u003A\u003D-\u007E]*$/,
                o = Object.prototype.toString,
                l = ((r = function() {}).prototype = Object.create(null), r);

            function c(e, t, r) {
                let l = "object" == typeof e ? e : { ...r,
                        name: e,
                        value: String(t)
                    },
                    c = ("object" == typeof t ? t : r) ? .encode || encodeURIComponent;
                if (!n.test(l.name)) throw TypeError(`argument name is invalid: ${l.name}`);
                let h = l.value ? c(l.value) : "";
                if (!s.test(h)) throw TypeError(`argument val is invalid: ${l.value}`);
                let u = l.name + "=" + h;
                if (void 0 !== l.maxAge) {
                    if (!Number.isInteger(l.maxAge)) throw TypeError(`option maxAge is invalid: ${l.maxAge}`);
                    u += "; Max-Age=" + l.maxAge
                }
                if (l.domain) {
                    if (!i.test(l.domain)) throw TypeError(`option domain is invalid: ${l.domain}`);
                    u += "; Domain=" + l.domain
                }
                if (l.path) {
                    if (!a.test(l.path)) throw TypeError(`option path is invalid: ${l.path}`);
                    u += "; Path=" + l.path
                }
                if (l.expires) {
                    var d;
                    if (d = l.expires, "[object Date]" !== o.call(d) || !Number.isFinite(l.expires.valueOf())) throw TypeError(`option expires is invalid: ${l.expires}`);
                    u += "; Expires=" + l.expires.toUTCString()
                }
                if (l.httpOnly && (u += "; HttpOnly"), l.secure && (u += "; Secure"), l.partitioned && (u += "; Partitioned"), l.priority) switch ("string" == typeof l.priority ? l.priority.toLowerCase() : void 0) {
                    case "low":
                        u += "; Priority=Low";
                        break;
                    case "medium":
                        u += "; Priority=Medium";
                        break;
                    case "high":
                        u += "; Priority=High";
                        break;
                    default:
                        throw TypeError(`option priority is invalid: ${l.priority}`)
                }
                if (l.sameSite) switch ("string" == typeof l.sameSite ? l.sameSite.toLowerCase() : l.sameSite) {
                    case !0:
                    case "strict":
                        u += "; SameSite=Strict";
                        break;
                    case "lax":
                        u += "; SameSite=Lax";
                        break;
                    case "none":
                        u += "; SameSite=None";
                        break;
                    default:
                        throw TypeError(`option sameSite is invalid: ${l.sameSite}`)
                }
                return u
            }

            function h(e, t, r) {
                let n = t,
                    s = r;
                do {
                    let t = e.charCodeAt(n);
                    if (32 !== t && 9 !== t) break
                } while (++n < s);
                for (; s > n;) {
                    let t = e.charCodeAt(s - 1);
                    if (32 !== t && 9 !== t) break;
                    s--
                }
                return e.slice(n, s)
            }

            function u(e) {
                if (-1 === e.indexOf("%")) return e;
                try {
                    return decodeURIComponent(e)
                } catch (t) {
                    return e
                }
            }
        },
        72876: (e, t, r) => {
            "use strict";

            function n(e) {
                if (!/^0x[a-fA-F0-9]{40}$/.test(e)) throw Error(`@supabase/auth-js: Address "${e}" is invalid.`);
                return e.toLowerCase()
            }

            function s(e) {
                return parseInt(e, 16)
            }

            function i(e) {
                return "0x" + Array.from(new TextEncoder().encode(e), e => e.toString(16).padStart(2, "0")).join("")
            }

            function a(e) {
                var t;
                let {
                    chainId: r,
                    domain: s,
                    expirationTime: i,
                    issuedAt: a = new Date,
                    nonce: o,
                    notBefore: l,
                    requestId: c,
                    resources: h,
                    scheme: u,
                    uri: d,
                    version: f
                } = e;
                if (!Number.isInteger(r)) throw Error(`@supabase/auth-js: Invalid SIWE message field "chainId". Chain ID must be a EIP-155 chain ID. Provided value: ${r}`);
                if (!s) throw Error('@supabase/auth-js: Invalid SIWE message field "domain". Domain must be provided.');
                if (o && o.length < 8) throw Error(`@supabase/auth-js: Invalid SIWE message field "nonce". Nonce must be at least 8 characters. Provided value: ${o}`);
                if (!d) throw Error('@supabase/auth-js: Invalid SIWE message field "uri". URI must be provided.');
                if ("1" !== f) throw Error(`@supabase/auth-js: Invalid SIWE message field "version". Version must be '1'. Provided value: ${f}`);
                if (null == (t = e.statement) ? void 0 : t.includes("\n")) throw Error(`@supabase/auth-js: Invalid SIWE message field "statement". Statement must not include '\\n'. Provided value: ${e.statement}`);
                let p = n(e.address),
                    g = u ? `${u}://${s}` : s,
                    m = e.statement ? `${e.statement}
` : "",
                    y = `${g} wants you to sign in with your Ethereum account:
${p}

${m}`,
                    b = `URI: ${d}
Version: ${f}
Chain ID: ${r}${o?`
Nonce: ${o}`:""}
Issued At: ${a.toISOString()}`;
                if (i && (b += `
Expiration Time: ${i.toISOString()}`), l && (b += `
Not Before: ${l.toISOString()}`), c && (b += `
Request ID: ${c}`), h) {
                    let e = "\nResources:";
                    for (let t of h) {
                        if (!t || "string" != typeof t) throw Error(`@supabase/auth-js: Invalid SIWE message field "resources". Every resource must be a valid string. Provided value: ${t}`);
                        e += `
- ${t}`
                    }
                    b += e
                }
                return `${y}
${b}`
            }
            r.d(t, {
                aD: () => s,
                bv: () => n,
                nj: () => i,
                ob: () => a
            })
        },
        73661: (e, t, r) => {
            "use strict";
            r.d(t, {
                r: () => n
            });
            let n = "2.108.0"
        },
        86209: (e, t, r) => {
            "use strict";
            r.d(t, {
                Cl: () => p,
                EY: () => m,
                GC: () => f,
                R_: () => d,
                c2: () => g,
                vE: () => h,
                w4: () => y
            });
            var n = r(46715),
                s = r(93516),
                i = r(43092),
                a = r(328);
            let o = e => {
                    if ("object" == typeof e && null !== e) {
                        if ("string" == typeof e.msg) return e.msg;
                        if ("string" == typeof e.message) return e.message;
                        if ("string" == typeof e.error_description) return e.error_description;
                        if ("string" == typeof e.error) return e.error
                    }
                    return JSON.stringify(e)
                },
                l = [502, 503, 504, 520, 521, 522, 523, 524, 530];
            async function c(e) {
                var t;
                let r, n;
                if (!(0, i.pF)(e)) throw new a.zh(o(e), 0);
                if (l.includes(e.status)) throw new a.zh(o(e), e.status);
                try {
                    r = await e.json()
                } catch (e) {
                    throw new a.HU(o(e), e)
                }
                let c = (0, i.Rn)(e);
                if (c && c.getTime() >= s.Bo["2024-01-01"].timestamp && "object" == typeof r && r && "string" == typeof r.code ? n = r.code : "object" == typeof r && r && "string" == typeof r.error_code && (n = r.error_code), n) {
                    if ("weak_password" === n) throw new a.OI(o(r), e.status, (null == (t = r.weak_password) ? void 0 : t.reasons) || []);
                    else if ("session_not_found" === n) throw new a.jG
                } else if ("object" == typeof r && r && "object" == typeof r.weak_password && r.weak_password && Array.isArray(r.weak_password.reasons) && r.weak_password.reasons.length && r.weak_password.reasons.reduce((e, t) => e && "string" == typeof t, !0)) throw new a.OI(o(r), e.status, r.weak_password.reasons);
                throw new a.RC(o(r), e.status || 500, n)
            }
            async function h(e, t, r, n) {
                var i;
                let a = Object.assign({}, null == n ? void 0 : n.headers);
                a[s.sk] || (a[s.sk] = s.Bo["2024-01-01"].name), (null == n ? void 0 : n.jwt) && (a.Authorization = `Bearer ${n.jwt}`);
                let o = null != (i = null == n ? void 0 : n.query) ? i : {};
                (null == n ? void 0 : n.redirectTo) && (o.redirect_to = n.redirectTo);
                let l = Object.keys(o).length ? "?" + new URLSearchParams(o).toString() : "",
                    c = await u(e, t, r + l, {
                        headers: a,
                        noResolveJson: null == n ? void 0 : n.noResolveJson
                    }, {}, null == n ? void 0 : n.body);
                return (null == n ? void 0 : n.xform) ? null == n ? void 0 : n.xform(c) : {
                    data: Object.assign({}, c),
                    error: null
                }
            }
            async function u(e, t, r, n, s, i) {
                let l, h, u = (h = {
                    method: t,
                    headers: (null == n ? void 0 : n.headers) || {}
                }, "GET" === t ? h : (h.headers = Object.assign({
                    "Content-Type": "application/json;charset=UTF-8"
                }, null == n ? void 0 : n.headers), h.body = JSON.stringify(i), Object.assign(Object.assign({}, h), s)));
                try {
                    l = await e(r, Object.assign({}, u))
                } catch (e) {
                    throw console.error(e), new a.zh(o(e), 0)
                }
                if (l.ok || await c(l), null == n ? void 0 : n.noResolveJson) return l;
                try {
                    return await l.json()
                } catch (e) {
                    await c(e)
                }
            }

            function d(e) {
                var t, r;
                let n = null;
                return (r = e).access_token && r.refresh_token && r.expires_in && (n = Object.assign({}, e), e.expires_at || (n.expires_at = (0, i.WJ)(e.expires_in))), {
                    data: {
                        session: n,
                        user: null != (t = e.user) ? t : "string" == typeof(null == e ? void 0 : e.id) ? e : null
                    },
                    error: null
                }
            }

            function f(e) {
                let t = d(e);
                return !t.error && e.weak_password && "object" == typeof e.weak_password && Array.isArray(e.weak_password.reasons) && e.weak_password.reasons.length && e.weak_password.message && "string" == typeof e.weak_password.message && e.weak_password.reasons.reduce((e, t) => e && "string" == typeof t, !0) && (t.data.weak_password = e.weak_password), t
            }

            function p(e) {
                var t;
                return {
                    data: {
                        user: null != (t = e.user) ? t : e
                    },
                    error: null
                }
            }

            function g(e) {
                return {
                    data: e,
                    error: null
                }
            }

            function m(e) {
                let {
                    action_link: t,
                    email_otp: r,
                    hashed_token: s,
                    redirect_to: i,
                    verification_type: a
                } = e;
                return {
                    data: {
                        properties: {
                            action_link: t,
                            email_otp: r,
                            hashed_token: s,
                            redirect_to: i,
                            verification_type: a
                        },
                        user: Object.assign({}, (0, n.Tt)(e, ["action_link", "email_otp", "hashed_token", "redirect_to", "verification_type"]))
                    },
                    error: null
                }
            }

            function y(e) {
                return e
            }
        },
        86465: (e, t, r) => {
            "use strict";
            r.d(t, {
                Al: () => h,
                no: () => u,
                uE: () => l,
                xf: () => c
            });
            let n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".split(""),
                s = " 	\n\r=".split(""),
                i = (() => {
                    let e = Array(128);
                    for (let t = 0; t < e.length; t += 1) e[t] = -1;
                    for (let t = 0; t < s.length; t += 1) e[s[t].charCodeAt(0)] = -2;
                    for (let t = 0; t < n.length; t += 1) e[n[t].charCodeAt(0)] = t;
                    return e
                })();

            function a(e, t, r) {
                if (null !== e)
                    for (t.queue = t.queue << 8 | e, t.queuedBits += 8; t.queuedBits >= 6;) r(n[t.queue >> t.queuedBits - 6 & 63]), t.queuedBits -= 6;
                else if (t.queuedBits > 0)
                    for (t.queue = t.queue << 6 - t.queuedBits, t.queuedBits = 6; t.queuedBits >= 6;) r(n[t.queue >> t.queuedBits - 6 & 63]), t.queuedBits -= 6
            }

            function o(e, t, r) {
                let n = i[e];
                if (n > -1)
                    for (t.queue = t.queue << 6 | n, t.queuedBits += 6; t.queuedBits >= 8;) r(t.queue >> t.queuedBits - 8 & 255), t.queuedBits -= 8;
                else if (-2 === n) return;
                else throw Error(`Invalid Base64-URL character "${String.fromCharCode(e)}"`)
            }

            function l(e) {
                let t = [],
                    r = e => {
                        t.push(String.fromCodePoint(e))
                    },
                    n = {
                        utf8seq: 0,
                        codepoint: 0
                    },
                    s = {
                        queue: 0,
                        queuedBits: 0
                    },
                    i = e => {
                        ! function(e, t, r) {
                            if (0 === t.utf8seq) {
                                if (e <= 127) return r(e);
                                for (let r = 1; r < 6; r += 1)
                                    if ((e >> 7 - r & 1) == 0) {
                                        t.utf8seq = r;
                                        break
                                    }
                                if (2 === t.utf8seq) t.codepoint = 31 & e;
                                else if (3 === t.utf8seq) t.codepoint = 15 & e;
                                else if (4 === t.utf8seq) t.codepoint = 7 & e;
                                else throw Error("Invalid UTF-8 sequence");
                                t.utf8seq -= 1
                            } else if (t.utf8seq > 0) {
                                if (e <= 127) throw Error("Invalid UTF-8 sequence");
                                t.codepoint = t.codepoint << 6 | 63 & e, t.utf8seq -= 1, 0 === t.utf8seq && r(t.codepoint)
                            }
                        }(e, n, r)
                    };
                for (let t = 0; t < e.length; t += 1) o(e.charCodeAt(t), s, i);
                return t.join("")
            }

            function c(e) {
                let t = [],
                    r = {
                        queue: 0,
                        queuedBits: 0
                    },
                    n = e => {
                        t.push(e)
                    };
                for (let t = 0; t < e.length; t += 1) o(e.charCodeAt(t), r, n);
                return new Uint8Array(t)
            }

            function h(e) {
                let t = [];
                return ! function(e, t) {
                    for (let r = 0; r < e.length; r += 1) {
                        let n = e.charCodeAt(r);
                        if (n > 55295 && n <= 56319) {
                            let t = (n - 55296) * 1024 & 65535;
                            n = (e.charCodeAt(r + 1) - 56320 & 65535 | t) + 65536, r += 1
                        }! function(e, t) {
                            if (e <= 127) return t(e);
                            if (e <= 2047) {
                                t(192 | e >> 6), t(128 | 63 & e);
                                return
                            }
                            if (e <= 65535) {
                                t(224 | e >> 12), t(128 | e >> 6 & 63), t(128 | 63 & e);
                                return
                            }
                            if (e <= 1114111) {
                                t(240 | e >> 18), t(128 | e >> 12 & 63), t(128 | e >> 6 & 63), t(128 | 63 & e);
                                return
                            }
                            throw Error(`Unrecognized Unicode codepoint: ${e.toString(16)}`)
                        }(n, t)
                    }
                }(e, e => t.push(e)), new Uint8Array(t)
            }

            function u(e) {
                let t = [],
                    r = {
                        queue: 0,
                        queuedBits: 0
                    },
                    n = e => {
                        t.push(e)
                    };
                return e.forEach(e => a(e, r, n)), a(null, r, n), t.join("")
            }
        },
        93516: (e, t, r) => {
            "use strict";
            r.d(t, {
                $W: () => f,
                AQ: () => l,
                Bo: () => u,
                CT: () => a,
                Jj: () => d,
                Rn: () => c,
                YI: () => i,
                a4: () => s,
                nf: () => o,
                sk: () => h
            });
            var n = r(73661);
            let s = 3e4,
                i = 3,
                a = 9e4,
                o = "http://localhost:9999",
                l = "supabase.auth.token",
                c = {
                    "X-Client-Info": `gotrue-js/${n.r}`
                },
                h = "X-Supabase-Api-Version",
                u = {
                    "2024-01-01": {
                        timestamp: Date.parse("2024-01-01T00:00:00.0Z"),
                        name: "2024-01-01"
                    }
                },
                d = /^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}$|[a-z0-9_-]{2}$)$/i,
                f = 6e5
        }
    }
]);