"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [80931], {
        9235: (t, e, n) => {
            n.d(e, {
                L: () => i
            });
            let i = (0, n(1521).createContext)({})
        },
        9943: (t, e, n) => {
            n.d(e, {
                M: () => s
            });
            var i = n(1521);

            function s(t) {
                let e = (0, i.useRef)(null);
                return null === e.current && (e.current = t()), e.current
            }
        },
        31011: (t, e, n) => {
            n.d(e, {
                E: () => s
            });
            var i = n(1521);
            let s = "u" > typeof window ? i.useLayoutEffect : i.useEffect
        },
        32719: (t, e, n) => {
            n.d(e, {
                t: () => i
            });
            let i = (0, n(1521).createContext)(null)
        },
        80931: (t, e, n) => {
            n.d(e, {
                P: () => t8
            });
            var i, s = n(60806),
                o = n(47114),
                r = n(1521);
            let a = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function l(t) {
                if ("string" != typeof t || t.includes("-"));
                else if (a.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
                return !1
            }
            var u = n(73365),
                h = n(9235);
            let c = (0, r.createContext)({
                strict: !1
            });
            var d = n(83246);
            let p = (0, r.createContext)({});
            var m = n(24756),
                v = n(82342);

            function f(t) {
                return Array.isArray(t) ? t.join(" ") : t
            }
            var g = n(81425),
                y = n(12166),
                x = n(15002);
            let w = () => ({
                style: {},
                transform: {},
                transformOrigin: {},
                vars: {}
            });

            function P(t, e, n) {
                for (let i in e)(0, g.S)(e[i]) || (0, y.zK)(i, n) || (t[i] = e[i])
            }
            var E = n(18647),
                S = n(23680);
            let C = () => ({ ...w(),
                    attrs: {}
                }),
                M = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "propagate", "ignoreStrict", "viewport"]);

            function A(t) {
                return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || M.has(t)
            }
            let b = t => !A(t);
            try {
                i = require("@emotion/is-prop-valid").default, "function" == typeof i && (b = t => t.startsWith("on") ? !A(t) : i(t))
            } catch {}
            var L = n(74423),
                D = n(25051),
                k = n(57243),
                T = n(24700),
                I = n(32719),
                V = n(9943);
            let R = t => (e, n) => {
                    let i = (0, r.useContext)(p),
                        s = (0, r.useContext)(I.t),
                        o = () => (function({
                            scrapeMotionValuesFromProps: t,
                            createRenderState: e
                        }, n, i, s) {
                            return {
                                latestValues: function(t, e, n, i) {
                                    let s = {},
                                        o = i(t, {});
                                    for (let t in o) s[t] = (0, D.u)(o[t]);
                                    let {
                                        initial: r,
                                        animate: a
                                    } = t, l = (0, m.e)(t), u = (0, m.O)(t);
                                    e && u && !l && !1 !== t.inherit && (void 0 === r && (r = e.initial), void 0 === a && (a = e.animate));
                                    let h = !!n && !1 === n.initial,
                                        c = (h = h || !1 === r) ? a : r;
                                    if (c && "boolean" != typeof c && !(0, k.N)(c)) {
                                        let e = Array.isArray(c) ? c : [c];
                                        for (let n = 0; n < e.length; n++) {
                                            let i = (0, T.a)(t, e[n]);
                                            if (i) {
                                                let {
                                                    transitionEnd: t,
                                                    transition: e,
                                                    ...n
                                                } = i;
                                                for (let t in n) {
                                                    let e = n[t];
                                                    if (Array.isArray(e)) {
                                                        let t = h ? e.length - 1 : 0;
                                                        e = e[t]
                                                    }
                                                    null !== e && (s[t] = e)
                                                }
                                                for (let e in t) s[e] = t[e]
                                            }
                                        }
                                    }
                                    return s
                                }(n, i, s, t),
                                renderState: e()
                            }
                        })(t, e, i, s);
                    return n ? o() : (0, V.M)(o)
                },
                j = R({
                    scrapeMotionValuesFromProps: L.x,
                    createRenderState: w
                }),
                W = R({
                    scrapeMotionValuesFromProps: n(16960).x,
                    createRenderState: C
                });
            var O = n(40233);
            let X = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                F = !1;

            function G() {
                return ! function() {
                    if (F) return;
                    let t = {};
                    for (let e in X) t[e] = {
                        isEnabled: t => X[e].some(e => !!t[e])
                    };
                    (0, O.lr)(t), F = !0
                }(), (0, O.vK)()
            }
            let H = Symbol.for("motionComponentSymbol");
            var U = n(4121);
            let B = (0, r.createContext)({});

            function N(t) {
                return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
            }
            var Q = n(31011);

            function _(t, {
                forwardMotionProps: e = !1,
                type: n
            } = {}, i, s) {
                i && function(t) {
                    let e = G();
                    for (let n in t) e[n] = { ...e[n],
                        ...t[n]
                    };
                    (0, O.lr)(e)
                }(i);
                let o = n ? "svg" === n : l(t),
                    a = o ? W : j;

                function y(n, i) {
                    var y;
                    let M, L, D, k = { ...(0, r.useContext)(d.Q),
                            ...n,
                            layoutId: function({
                                layoutId: t
                            }) {
                                let e = (0, r.useContext)(h.L).id;
                                return e && void 0 !== t ? e + "-" + t : t
                            }(n)
                        },
                        {
                            isStatic: T
                        } = k,
                        V = function(t) {
                            let {
                                initial: e,
                                animate: n
                            } = function(t, e) {
                                if ((0, m.e)(t)) {
                                    let {
                                        initial: e,
                                        animate: n
                                    } = t;
                                    return {
                                        initial: !1 === e || (0, v.w)(e) ? e : void 0,
                                        animate: (0, v.w)(n) ? n : void 0
                                    }
                                }
                                return !1 !== t.inherit ? e : {}
                            }(t, (0, r.useContext)(p));
                            return (0, r.useMemo)(() => ({
                                initial: e,
                                animate: n
                            }), [f(e), f(n)])
                        }(n),
                        R = a(n, T);
                    if (!T && "u" > typeof window) {
                        (0, r.useContext)(c).strict;
                        let e = function(t) {
                            let {
                                drag: e,
                                layout: n
                            } = G();
                            if (!e && !n) return {};
                            let i = { ...e,
                                ...n
                            };
                            return {
                                MeasureLayout: e ? .isEnabled(t) || n ? .isEnabled(t) ? i.MeasureLayout : void 0,
                                ProjectionNode: i.ProjectionNode
                            }
                        }(k);
                        M = e.MeasureLayout, V.visualElement = function(t, e, n, i, s, o) {
                            let {
                                visualElement: a
                            } = (0, r.useContext)(p), l = (0, r.useContext)(c), u = (0, r.useContext)(I.t), h = (0, r.useContext)(d.Q), m = h.reducedMotion, v = h.skipAnimations, f = (0, r.useRef)(null), g = (0, r.useRef)(!1);
                            i = i || l.renderer, !f.current && i && (f.current = i(t, {
                                visualState: e,
                                parent: a,
                                props: n,
                                presenceContext: u,
                                blockInitialAnimation: !!u && !1 === u.initial,
                                reducedMotionConfig: m,
                                skipAnimations: v,
                                isSVG: o
                            }), g.current && f.current && (f.current.manuallyAnimateOnMount = !0));
                            let y = f.current,
                                x = (0, r.useContext)(B);
                            y && !y.projection && s && ("html" === y.type || "svg" === y.type) && function(t, e, n, i) {
                                let {
                                    layoutId: s,
                                    layout: o,
                                    drag: r,
                                    dragConstraints: a,
                                    layoutScroll: l,
                                    layoutRoot: u,
                                    layoutAnchor: h,
                                    layoutCrossfade: c
                                } = e;
                                t.projection = new n(t.latestValues, e["data-framer-portal-id"] ? void 0 : function t(e) {
                                    if (e) return !1 !== e.options.allowProjection ? e.projection : t(e.parent)
                                }(t.parent)), t.projection.setOptions({
                                    layoutId: s,
                                    layout: o,
                                    alwaysMeasureLayout: !!r || a && N(a),
                                    visualElement: t,
                                    animationType: "string" == typeof o ? o : "both",
                                    initialPromotionConfig: i,
                                    crossfade: c,
                                    layoutScroll: l,
                                    layoutRoot: u,
                                    layoutAnchor: h
                                })
                            }(f.current, n, s, x);
                            let w = (0, r.useRef)(!1);
                            (0, r.useInsertionEffect)(() => {
                                y && w.current && y.update(n, u)
                            });
                            let P = n[U.n],
                                E = (0, r.useRef)(!!P && "u" > typeof window && !window.MotionHandoffIsComplete ? .(P) && window.MotionHasOptimisedAnimation ? .(P));
                            return (0, Q.E)(() => {
                                g.current = !0, y && (w.current = !0, window.MotionIsMounted = !0, y.updateFeatures(), y.scheduleRenderMicrotask(), E.current && y.animationState && y.animationState.animateChanges())
                            }), (0, r.useEffect)(() => {
                                y && (!E.current && y.animationState && y.animationState.animateChanges(), E.current && (queueMicrotask(() => {
                                    window.MotionHandoffMarkAsComplete ? .(P)
                                }), E.current = !1), y.enteringChildren = void 0)
                            }), y
                        }(t, R, k, s, e.ProjectionNode, o)
                    }
                    return (0, u.jsxs)(p.Provider, {
                        value: V,
                        children: [M && V.visualElement ? (0, u.jsx)(M, {
                            visualElement: V.visualElement,
                            ...k
                        }) : null, function(t, e, n, {
                            latestValues: i
                        }, s, o = !1, a) {
                            let u = (a ? ? l(t) ? function(t, e, n, i) {
                                    let s = (0, r.useMemo)(() => {
                                        let n = C();
                                        return (0, E.B)(n, e, (0, S.n)(i), t.transformTemplate, t.style), { ...n.attrs,
                                            style: { ...n.style
                                            }
                                        }
                                    }, [e]);
                                    if (t.style) {
                                        let e = {};
                                        P(e, t.style, t), s.style = { ...e,
                                            ...s.style
                                        }
                                    }
                                    return s
                                } : function(t, e) {
                                    let n, i, s = {},
                                        o = (n = t.style || {}, P(i = {}, n, t), Object.assign(i, function({
                                            transformTemplate: t
                                        }, e) {
                                            return (0, r.useMemo)(() => {
                                                let n = w();
                                                return (0, x.O)(n, e, t), Object.assign({}, n.vars, n.style)
                                            }, [e])
                                        }(t, e)), i);
                                    return t.drag && !1 !== t.dragListener && (s.draggable = !1, o.userSelect = o.WebkitUserSelect = o.WebkitTouchCallout = "none", o.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (s.tabIndex = 0), s.style = o, s
                                })(e, i, s, t),
                                h = function(t, e, n) {
                                    let i = {};
                                    for (let s in t)("values" !== s || "object" != typeof t.values) && !(0, g.S)(t[s]) && (b(s) || !0 === n && A(s) || !e && !A(s) || t.draggable && s.startsWith("onDrag")) && (i[s] = t[s]);
                                    return i
                                }(e, "string" == typeof t, o),
                                c = t !== r.Fragment ? { ...h,
                                    ...u,
                                    ref: n
                                } : {},
                                {
                                    children: d
                                } = e,
                                p = (0, r.useMemo)(() => (0, g.S)(d) ? d.get() : d, [d]);
                            return (0, r.createElement)(t, { ...c,
                                children: p
                            })
                        }(t, n, (y = V.visualElement, L = (0, r.useRef)(i), (0, r.useInsertionEffect)(() => {
                            L.current = i
                        }), D = (0, r.useRef)(null), (0, r.useCallback)(t => {
                            t && R.onMount ? .(t), y && (t ? y.mount(t) : y.unmount());
                            let e = L.current;
                            if ("function" == typeof e)
                                if (t) {
                                    let n = e(t);
                                    "function" == typeof n && (D.current = n)
                                } else D.current ? (D.current(), D.current = null) : e(t);
                            else e && (e.current = t)
                        }, [y])), R, T, e, o)]
                    })
                }
                y.displayName = `motion.${"string"==typeof t?t:`create(${t.displayName??t.name??""})`}`;
                let M = (0, r.forwardRef)(y);
                return M[H] = t, M
            }
            var Y = n(3095),
                q = n(8029);
            class K extends Y.X {
                constructor(t) {
                    super(t), t.animationState || (t.animationState = (0, q.L)(t))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: t
                    } = this.node.getProps();
                    (0, k.N)(t) && (this.unmountControls = t.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: t
                    } = this.node.getProps(), {
                        animate: e
                    } = this.node.prevProps || {};
                    t !== e && this.updateAnimationControlsSubscription()
                }
                unmount() {
                    this.node.animationState.reset(), this.unmountControls ? .()
                }
            }
            var $ = n(60600);
            let z = 0;
            class J extends Y.X {
                constructor() {
                    super(...arguments), this.id = z++, this.isExitComplete = !1
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: t,
                        onExitComplete: e
                    } = this.node.presenceContext, {
                        isPresent: n
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || t === n) return;
                    if (t && !1 === n) {
                        if (this.isExitComplete) {
                            let {
                                initial: t,
                                custom: e
                            } = this.node.getProps();
                            if ("string" == typeof t || "object" == typeof t && null !== t && !Array.isArray(t)) {
                                let n = (0, $.K)(this.node, t, e);
                                if (n) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...i
                                    } = n;
                                    for (let t in i) this.node.getValue(t) ? .jump(i[t])
                                }
                            }
                            this.node.animationState.reset(), this.node.animationState.animateChanges()
                        } else this.node.animationState.setActive("exit", !1);
                        this.isExitComplete = !1;
                        return
                    }
                    let i = this.node.animationState.setActive("exit", !t);
                    e && !t && i.then(() => {
                        this.isExitComplete = !0, e(this.id)
                    })
                }
                mount() {
                    let {
                        register: t,
                        onExitComplete: e
                    } = this.node.presenceContext || {};
                    e && e(this.id), t && (this.unmount = t(this.id))
                }
                unmount() {}
            }
            var Z = n(20381),
                tt = n(40699),
                te = n(55469),
                tn = n(34859),
                ti = n(43868),
                ts = n(4761),
                to = n(86993),
                tr = n(40603),
                ta = n(89172),
                tl = n(30537),
                tu = n(59316),
                th = n(48592),
                tc = n(84050),
                td = n(16623),
                tp = n(66767),
                tm = n(99296),
                tv = n(70518);

            function tf(t) {
                return {
                    point: {
                        x: t.pageX,
                        y: t.pageY
                    }
                }
            }

            function tg(t, e, n, i) {
                return (0, td.k)(t, e, t => (0, tv.M)(t) && n(t, tf(t)), i)
            }
            let ty = ({
                current: t
            }) => t ? t.ownerDocument.defaultView : null;
            var tx = n(69413),
                tw = n(69377),
                tP = n(77504);
            let tE = new Set(["auto", "scroll"]);
            class tS {
                constructor(t, e, {
                    transformPagePoint: n,
                    contextWindow: i = window,
                    dragSnapToOrigin: s = !1,
                    distanceThreshold: o = 3,
                    element: r
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.lastRawMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.scrollPositions = new Map, this.removeScrollListeners = null, this.onElementScroll = t => {
                            this.handleScroll(t.target)
                        }, this.onWindowScroll = () => {
                            this.handleScroll(window)
                        }, this.updatePoint = () => {
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            this.lastRawMoveEventInfo && (this.lastMoveEventInfo = tC(this.lastRawMoveEventInfo, this.transformPagePoint));
                            let t = tA(this.lastMoveEventInfo, this.history),
                                e = null !== this.startEvent,
                                n = (0, tP.w)(t.offset, {
                                    x: 0,
                                    y: 0
                                }) >= this.distanceThreshold;
                            if (!e && !n) return;
                            let {
                                point: i
                            } = t, {
                                timestamp: s
                            } = to.uv;
                            this.history.push({ ...i,
                                timestamp: s
                            });
                            let {
                                onStart: o,
                                onMove: r
                            } = this.handlers;
                            e || (o && o(this.lastMoveEvent, t), this.startEvent = this.lastMoveEvent), r && r(this.lastMoveEvent, t)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastRawMoveEventInfo = e, this.lastMoveEventInfo = tC(e, this.transformPagePoint), to.Gt.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            let {
                                onEnd: n,
                                onSessionEnd: i,
                                resumeAnimation: s
                            } = this.handlers;
                            if ((this.dragSnapToOrigin || !this.startEvent) && s && s(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let o = tA("pointercancel" === t.type ? this.lastMoveEventInfo : tC(e, this.transformPagePoint), this.history);
                            this.startEvent && n && n(t, o), i && i(t, o)
                        }, !(0, tv.M)(t)) return;
                    this.dragSnapToOrigin = s, this.handlers = e, this.transformPagePoint = n, this.distanceThreshold = o, this.contextWindow = i || window;
                    const a = tC(tf(t), this.transformPagePoint),
                        {
                            point: l
                        } = a,
                        {
                            timestamp: u
                        } = to.uv;
                    this.history = [{ ...l,
                        timestamp: u
                    }];
                    const {
                        onSessionStart: h
                    } = e;
                    h && h(t, tA(a, this.history)), this.removeListeners = (0, tx.F)(tg(this.contextWindow, "pointermove", this.handlePointerMove), tg(this.contextWindow, "pointerup", this.handlePointerUp), tg(this.contextWindow, "pointercancel", this.handlePointerUp)), r && this.startScrollTracking(r)
                }
                startScrollTracking(t) {
                    let e = t.parentElement;
                    for (; e;) {
                        let t = getComputedStyle(e);
                        (tE.has(t.overflowX) || tE.has(t.overflowY)) && this.scrollPositions.set(e, {
                            x: e.scrollLeft,
                            y: e.scrollTop
                        }), e = e.parentElement
                    }
                    this.scrollPositions.set(window, {
                        x: window.scrollX,
                        y: window.scrollY
                    }), window.addEventListener("scroll", this.onElementScroll, {
                        capture: !0
                    }), window.addEventListener("scroll", this.onWindowScroll), this.removeScrollListeners = () => {
                        window.removeEventListener("scroll", this.onElementScroll, {
                            capture: !0
                        }), window.removeEventListener("scroll", this.onWindowScroll)
                    }
                }
                handleScroll(t) {
                    let e = this.scrollPositions.get(t);
                    if (!e) return;
                    let n = t === window,
                        i = n ? {
                            x: window.scrollX,
                            y: window.scrollY
                        } : {
                            x: t.scrollLeft,
                            y: t.scrollTop
                        },
                        s = {
                            x: i.x - e.x,
                            y: i.y - e.y
                        };
                    (0 !== s.x || 0 !== s.y) && (n ? this.lastMoveEventInfo && (this.lastMoveEventInfo.point.x += s.x, this.lastMoveEventInfo.point.y += s.y) : this.history.length > 0 && (this.history[0].x -= s.x, this.history[0].y -= s.y), this.scrollPositions.set(t, i), to.Gt.update(this.updatePoint, !0))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), this.removeScrollListeners && this.removeScrollListeners(), this.scrollPositions.clear(), (0, to.WG)(this.updatePoint)
                }
            }

            function tC(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function tM(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function tA({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: tM(t, tb(e)),
                    offset: tM(t, e[0]),
                    velocity: function(t) {
                        if (t.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let e = t.length - 1,
                            n = null,
                            i = tb(t);
                        for (; e >= 0 && (n = t[e], !(i.timestamp - n.timestamp > (0, tw.f)(.1)));) e--;
                        if (!n) return {
                            x: 0,
                            y: 0
                        };
                        n === t[0] && t.length > 2 && i.timestamp - n.timestamp > 2 * (0, tw.f)(.1) && (n = t[1]);
                        let s = (0, tw.X)(i.timestamp - n.timestamp);
                        if (0 === s) return {
                            x: 0,
                            y: 0
                        };
                        let o = {
                            x: (i.x - n.x) / s,
                            y: (i.y - n.y) / s
                        };
                        return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
                    }(e)
                }
            }

            function tb(t) {
                return t[t.length - 1]
            }
            var tL = n(7e4),
                tD = n(32796);

            function tk(t, e, n) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== n ? t.max + n - (t.max - t.min) : void 0
                }
            }

            function tT(t, e) {
                let n = e.min - t.min,
                    i = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([n, i] = [i, n]), {
                    min: n,
                    max: i
                }
            }

            function tI(t, e, n) {
                return {
                    min: tV(t, e),
                    max: tV(t, n)
                }
            }

            function tV(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            let tR = new WeakMap;
            class tj {
                constructor(t) {
                    this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = (0, tt.ge)(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1,
                    distanceThreshold: n
                } = {}) {
                    let {
                        presenceContext: i
                    } = this.visualElement;
                    if (i && !1 === i.isPresent) return;
                    let s = t => {
                            e && this.snapToCursor(tf(t).point), this.stopAnimation()
                        },
                        o = (t, e) => {
                            let {
                                drag: n,
                                dragPropagation: i,
                                onDragStart: s
                            } = this.getProps();
                            if (n && !i && (this.openDragLock && this.openDragLock(), this.openDragLock = (0, te.W)(n), !this.openDragLock)) return;
                            this.latestPointerEvent = t, this.latestPanInfo = e, this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), (0, tn.X)(t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (ti.KN.test(e)) {
                                    let {
                                        projection: n
                                    } = this.visualElement;
                                    if (n && n.layout) {
                                        let i = n.layout.layoutBox[t];
                                        i && (e = (0, ts.CQ)(i) * (parseFloat(e) / 100))
                                    }
                                }
                                this.originPoint[t] = e
                            }), s && to.Gt.update(() => s(t, e), !1, !0), (0, tr.g)(this.visualElement, "transform");
                            let {
                                animationState: o
                            } = this.visualElement;
                            o && o.setActive("whileDrag", !0)
                        },
                        r = (t, e) => {
                            this.latestPointerEvent = t, this.latestPanInfo = e;
                            let {
                                dragPropagation: n,
                                dragDirectionLock: i,
                                onDirectionLock: s,
                                onDrag: o
                            } = this.getProps();
                            if (!n && !this.openDragLock) return;
                            let {
                                offset: r
                            } = e;
                            if (i && null === this.currentDirection) {
                                this.currentDirection = function(t, e = 10) {
                                    let n = null;
                                    return Math.abs(t.y) > e ? n = "y" : Math.abs(t.x) > e && (n = "x"), n
                                }(r), null !== this.currentDirection && s && s(this.currentDirection);
                                return
                            }
                            this.updateAxis("x", e.point, r), this.updateAxis("y", e.point, r), this.visualElement.render(), o && to.Gt.update(() => o(t, e), !1, !0)
                        },
                        a = (t, e) => {
                            this.latestPointerEvent = t, this.latestPanInfo = e, this.stop(t, e), this.latestPointerEvent = null, this.latestPanInfo = null
                        },
                        l = () => {
                            let {
                                dragSnapToOrigin: t
                            } = this.getProps();
                            (t || this.constraints) && this.startAnimation({
                                x: 0,
                                y: 0
                            })
                        },
                        {
                            dragSnapToOrigin: u
                        } = this.getProps();
                    this.panSession = new tS(t, {
                        onSessionStart: s,
                        onStart: o,
                        onMove: r,
                        onSessionEnd: a,
                        resumeAnimation: l
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: u,
                        distanceThreshold: n,
                        contextWindow: ty(this.visualElement),
                        element: this.visualElement.current
                    })
                }
                stop(t, e) {
                    let n = t || this.latestPointerEvent,
                        i = e || this.latestPanInfo,
                        s = this.isDragging;
                    if (this.cancel(), !s || !i || !n) return;
                    let {
                        velocity: o
                    } = i;
                    this.startAnimation(o);
                    let {
                        onDragEnd: r
                    } = this.getProps();
                    r && to.Gt.postRender(() => r(n, i))
                }
                cancel() {
                    this.isDragging = !1;
                    let {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.endPanSession();
                    let {
                        dragPropagation: n
                    } = this.getProps();
                    !n && this.openDragLock && (this.openDragLock(), this.openDragLock = null), e && e.setActive("whileDrag", !1)
                }
                endPanSession() {
                    this.panSession && this.panSession.end(), this.panSession = void 0
                }
                updateAxis(t, e, n) {
                    let {
                        drag: i
                    } = this.getProps();
                    if (!n || !tO(t, i, this.currentDirection)) return;
                    let s = this.getAxisMotionValue(t),
                        o = this.originPoint[t] + n[t];
                    this.constraints && this.constraints[t] && (o = function(t, {
                        min: e,
                        max: n
                    }, i) {
                        return void 0 !== e && t < e ? t = i ? (0, th.k)(e, t, i.min) : Math.max(t, e) : void 0 !== n && t > n && (t = i ? (0, th.k)(n, t, i.max) : Math.min(t, n)), t
                    }(o, this.constraints[t], this.elastic[t])), s.set(o)
                }
                resolveConstraints() {
                    let {
                        dragConstraints: t,
                        dragElastic: e
                    } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : this.visualElement.projection ? .layout, i = this.constraints;
                    t && N(t) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : t && n ? this.constraints = function(t, {
                        top: e,
                        left: n,
                        bottom: i,
                        right: s
                    }) {
                        return {
                            x: tk(t.x, n, s),
                            y: tk(t.y, e, i)
                        }
                    }(n.layoutBox, t) : this.constraints = !1, this.elastic = function(t = .35) {
                        return !1 === t ? t = 0 : !0 === t && (t = .35), {
                            x: tI(t, "left", "right"),
                            y: tI(t, "top", "bottom")
                        }
                    }(e), i !== this.constraints && !N(t) && n && this.constraints && !this.hasMutatedConstraints && (0, tn.X)(t => {
                        var e, i;
                        let s;
                        !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = (e = n.layoutBox[t], i = this.constraints[t], s = {}, void 0 !== i.min && (s.min = i.min - e.min), void 0 !== i.max && (s.max = i.max - e.min), s))
                    })
                }
                resolveRefConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        onMeasureDragConstraints: n
                    } = this.getProps();
                    if (!e || !N(e)) return !1;
                    let i = e.current;
                    (0, tm.V)(null !== i, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.", "drag-constraints-ref");
                    let {
                        projection: s
                    } = this.visualElement;
                    if (!s || !s.layout) return !1;
                    s.root && (s.root.scroll = void 0, s.root.updateScroll());
                    let o = (0, ta.L)(i, s.root, this.visualElement.getTransformPagePoint()),
                        r = (t = s.layout.layoutBox, {
                            x: tT(t.x, o.x),
                            y: tT(t.y, o.y)
                        });
                    if (n) {
                        let t = n((0, tl.pA)(r));
                        this.hasMutatedConstraints = !!t, t && (r = (0, tl.FY)(t))
                    }
                    return r
                }
                startAnimation(t) {
                    let {
                        drag: e,
                        dragMomentum: n,
                        dragElastic: i,
                        dragTransition: s,
                        dragSnapToOrigin: o,
                        onDragTransitionEnd: r
                    } = this.getProps(), a = this.constraints || {};
                    return Promise.all((0, tn.X)(r => {
                        if (!tO(r, e, this.currentDirection)) return;
                        let l = a && a[r] || {};
                        (!0 === o || o === r) && (l = {
                            min: 0,
                            max: 0
                        });
                        let u = {
                            type: "inertia",
                            velocity: n ? t[r] : 0,
                            bounceStiffness: i ? 200 : 1e6,
                            bounceDamping: i ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...s,
                            ...l
                        };
                        return this.startAxisValueAnimation(r, u)
                    })).then(r)
                }
                startAxisValueAnimation(t, e) {
                    let n = this.getAxisMotionValue(t);
                    return (0, tr.g)(this.visualElement, t), n.start((0, tu.f)(t, n, 0, e, this.visualElement, !1))
                }
                stopAnimation() {
                    (0, tn.X)(t => this.getAxisMotionValue(t).stop())
                }
                getAxisMotionValue(t) {
                    let e = `_drag${t.toUpperCase()}`;
                    return this.visualElement.getProps()[e] || this.visualElement.getValue(t, this.visualElement.latestValues[t] ? ? 0)
                }
                snapToCursor(t) {
                    (0, tn.X)(e => {
                        let {
                            drag: n
                        } = this.getProps();
                        if (!tO(e, n, this.currentDirection)) return;
                        let {
                            projection: i
                        } = this.visualElement, s = this.getAxisMotionValue(e);
                        if (i && i.layout) {
                            let {
                                min: n,
                                max: o
                            } = i.layout.layoutBox[e], r = s.get() || 0;
                            s.set(t[e] - (0, th.k)(n, o, .5) + r)
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    let {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: n
                    } = this.visualElement;
                    if (!N(e) || !n || !this.constraints) return;
                    this.stopAnimation();
                    let i = {
                        x: 0,
                        y: 0
                    };
                    (0, tn.X)(t => {
                        let e = this.getAxisMotionValue(t);
                        if (e && !1 !== this.constraints) {
                            var n, s;
                            let o, r, a, l = e.get();
                            i[t] = (n = {
                                min: l,
                                max: l
                            }, s = this.constraints[t], o = .5, r = (0, ts.CQ)(n), (a = (0, ts.CQ)(s)) > r ? o = (0, tL.q)(s.min, s.max - r, n.min) : r > a && (o = (0, tL.q)(n.min, n.max - a, s.min)), (0, tD.q)(0, 1, o))
                        }
                    });
                    let {
                        transformTemplate: s
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = s ? s({}, "") : "none", n.root && n.root.updateScroll(), n.updateLayout(), this.constraints = !1, this.resolveConstraints(), (0, tn.X)(e => {
                        if (!tO(e, t, null)) return;
                        let n = this.getAxisMotionValue(e),
                            {
                                min: s,
                                max: o
                            } = this.constraints[e];
                        n.set((0, th.k)(s, o, i[e]))
                    }), this.visualElement.render()
                }
                addListeners() {
                    let t;
                    if (!this.visualElement.current) return;
                    tR.set(this.visualElement, this);
                    let e = this.visualElement.current,
                        n = tg(e, "pointerdown", t => {
                            let {
                                drag: n,
                                dragListener: i = !0
                            } = this.getProps(), s = t.target, o = s !== e && (0, tc.a)(s);
                            n && i && !o && this.start(t)
                        }),
                        i = () => {
                            var n, i, s;
                            let o, r, {
                                dragConstraints: a
                            } = this.getProps();
                            N(a) && a.current && (this.constraints = this.resolveRefConstraints(), t || (n = e, i = a.current, s = () => this.scalePositionWithinConstraints(), o = (0, tp.X)(n, tW(s)), r = (0, tp.X)(i, tW(s)), t = () => {
                                o(), r()
                            }))
                        },
                        {
                            projection: s
                        } = this.visualElement,
                        o = s.addEventListener("measure", i);
                    s && !s.layout && (s.root && s.root.updateScroll(), s.updateLayout()), to.Gt.read(i);
                    let r = (0, td.k)(window, "resize", () => this.scalePositionWithinConstraints()),
                        a = s.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && ((0, tn.X)(e => {
                                let n = this.getAxisMotionValue(e);
                                n && (this.originPoint[e] += t[e].translate, n.set(n.get() + t[e].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        r(), n(), o(), a && a(), t && t()
                    }
                }
                getProps() {
                    let t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: n = !1,
                            dragPropagation: i = !1,
                            dragConstraints: s = !1,
                            dragElastic: o = .35,
                            dragMomentum: r = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: n,
                        dragPropagation: i,
                        dragConstraints: s,
                        dragElastic: o,
                        dragMomentum: r
                    }
                }
            }

            function tW(t) {
                let e = !0;
                return () => {
                    if (e) {
                        e = !1;
                        return
                    }
                    t()
                }
            }

            function tO(t, e, n) {
                return (!0 === e || e === t) && (null === n || n === t)
            }
            class tX extends Y.X {
                constructor(t) {
                    super(t), this.removeGroupControls = Z.l, this.removeListeners = Z.l, this.controls = new tj(t)
                }
                mount() {
                    let {
                        dragControls: t
                    } = this.node.getProps();
                    t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || Z.l
                }
                update() {
                    let {
                        dragControls: t
                    } = this.node.getProps(), {
                        dragControls: e
                    } = this.node.prevProps || {};
                    t !== e && (this.removeGroupControls(), t && (this.removeGroupControls = t.subscribe(this.controls)))
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners(), this.controls.isDragging || this.controls.endPanSession()
                }
            }
            let tF = t => (e, n) => {
                t && to.Gt.update(() => t(e, n), !1, !0)
            };
            class tG extends Y.X {
                constructor() {
                    super(...arguments), this.removePointerDownListener = Z.l
                }
                onPointerDown(t) {
                    this.session = new tS(t, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: ty(this.node)
                    })
                }
                createPanHandlers() {
                    let {
                        onPanSessionStart: t,
                        onPanStart: e,
                        onPan: n,
                        onPanEnd: i
                    } = this.node.getProps();
                    return {
                        onSessionStart: tF(t),
                        onStart: tF(e),
                        onMove: tF(n),
                        onEnd: (t, e) => {
                            delete this.session, i && to.Gt.postRender(() => i(t, e))
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = tg(this.node.current, "pointerdown", t => this.onPointerDown(t))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
            var tH = n(4894),
                tU = n(27597),
                tB = n(85656);
            let tN = !1;
            class tQ extends r.Component {
                componentDidMount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: n,
                        layoutId: i
                    } = this.props, {
                        projection: s
                    } = t;
                    s && (e.group && e.group.add(s), n && n.register && i && n.register(s), tN && s.root.didUpdate(), s.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), s.setOptions({ ...s.options,
                        layoutDependency: this.props.layoutDependency,
                        onExitComplete: () => this.safeToRemove()
                    })), tH.w.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    let {
                        layoutDependency: e,
                        visualElement: n,
                        drag: i,
                        isPresent: s
                    } = this.props, {
                        projection: o
                    } = n;
                    return o && (o.isPresent = s, t.layoutDependency !== e && o.setOptions({ ...o.options,
                        layoutDependency: e
                    }), tN = !0, i || t.layoutDependency !== e || void 0 === e || t.isPresent !== s ? o.willUpdate() : this.safeToRemove(), t.isPresent !== s && (s ? o.promote() : o.relegate() || to.Gt.postRender(() => {
                        let t = o.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        visualElement: t,
                        layoutAnchor: e
                    } = this.props, {
                        projection: n
                    } = t;
                    n && (n.options.layoutAnchor = e, n.root.didUpdate(), tU.k.postRender(() => {
                        !n.currentAnimation && n.isLead() && this.safeToRemove()
                    }))
                }
                componentWillUnmount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: n
                    } = this.props, {
                        projection: i
                    } = t;
                    tN = !0, i && (i.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(i), n && n.deregister && n.deregister(i))
                }
                safeToRemove() {
                    let {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function t_(t) {
                let [e, n] = (0, tB.xQ)(), i = (0, r.useContext)(h.L);
                return (0, u.jsx)(tQ, { ...t,
                    layoutGroup: i,
                    switchLayoutGroup: (0, r.useContext)(B),
                    isPresent: e,
                    safeToRemove: n
                })
            }
            var tY = n(9385);
            let tq = {
                pan: {
                    Feature: tG
                },
                drag: {
                    Feature: tX,
                    ProjectionNode: tY.P,
                    MeasureLayout: t_
                }
            };
            var tK = n(58647);

            function t$(t, e, n) {
                let {
                    props: i
                } = t;
                t.animationState && i.whileHover && t.animationState.setActive("whileHover", "Start" === n);
                let s = i["onHover" + n];
                s && to.Gt.postRender(() => s(e, tf(e)))
            }
            class tz extends Y.X {
                mount() {
                    let {
                        current: t
                    } = this.node;
                    t && (this.unmount = (0, tK.P)(t, (t, e) => (t$(this.node, e, "Start"), t => t$(this.node, t, "End"))))
                }
                unmount() {}
            }
            class tJ extends Y.X {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let t = !1;
                    try {
                        t = this.node.current.matches(":focus-visible")
                    } catch (e) {
                        t = !0
                    }
                    t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = (0, tx.F)((0, td.k)(this.node.current, "focus", () => this.onFocus()), (0, td.k)(this.node.current, "blur", () => this.onBlur()))
                }
                unmount() {}
            }
            var tZ = n(50536);

            function t0(t, e, n) {
                let {
                    props: i
                } = t;
                if (t.current instanceof HTMLButtonElement && t.current.disabled) return;
                t.animationState && i.whileTap && t.animationState.setActive("whileTap", "Start" === n);
                let s = i["onTap" + ("End" === n ? "" : n)];
                s && to.Gt.postRender(() => s(e, tf(e)))
            }
            class t1 extends Y.X {
                mount() {
                    let {
                        current: t
                    } = this.node;
                    if (!t) return;
                    let {
                        globalTapTarget: e,
                        propagate: n
                    } = this.node.props;
                    this.unmount = (0, tZ.c)(t, (t, e) => (t0(this.node, e, "Start"), (t, {
                        success: e
                    }) => t0(this.node, t, e ? "End" : "Cancel")), {
                        useGlobalTarget: e,
                        stopPropagation: n ? .tap === !1
                    })
                }
                unmount() {}
            }
            let t5 = new WeakMap,
                t3 = new WeakMap,
                t2 = t => {
                    let e = t5.get(t.target);
                    e && e(t)
                },
                t6 = t => {
                    t.forEach(t2)
                },
                t9 = {
                    some: 0,
                    all: 1
                };
            class t4 extends Y.X {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    var t;
                    let e;
                    this.stopObserver ? .();
                    let {
                        viewport: n = {}
                    } = this.node.getProps(), {
                        root: i,
                        margin: s,
                        amount: o = "some",
                        once: r
                    } = n, a = {
                        root: i ? i.current : void 0,
                        rootMargin: s,
                        threshold: "number" == typeof o ? o : t9[o]
                    }, l = t => {
                        let {
                            isIntersecting: e
                        } = t;
                        if (this.isInView === e || (this.isInView = e, r && !e && this.hasEnteredView)) return;
                        e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                        let {
                            onViewportEnter: n,
                            onViewportLeave: i
                        } = this.node.getProps(), s = e ? n : i;
                        s && s(t)
                    };
                    this.stopObserver = (t = this.node.current, e = function({
                        root: t,
                        ...e
                    }) {
                        let n = t || document;
                        t3.has(n) || t3.set(n, {});
                        let i = t3.get(n),
                            s = JSON.stringify(e);
                        return i[s] || (i[s] = new IntersectionObserver(t6, {
                            root: t,
                            ...e
                        })), i[s]
                    }(a), t5.set(t, l), e.observe(t), () => {
                        t5.delete(t), e.unobserve(t)
                    })
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("u" < typeof IntersectionObserver) return;
                    let {
                        props: t,
                        prevProps: e
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: t = {}
                    }, {
                        viewport: e = {}
                    } = {}) {
                        return n => t[n] !== e[n]
                    }(t, e)) && this.startObserver()
                }
                unmount() {
                    this.stopObserver ? .(), this.hasEnteredView = !1, this.isInView = !1
                }
            }
            let t7 = {
                    layout: {
                        ProjectionNode: tY.P,
                        MeasureLayout: t_
                    }
                },
                t8 = function(t, e) {
                    if ("u" < typeof Proxy) return _;
                    let n = new Map,
                        i = (n, i) => _(n, i, t, e);
                    return new Proxy((t, e) => i(t, e), {
                        get: (s, o) => "create" === o ? i : (n.has(o) || n.set(o, _(o, void 0, t, e)), n.get(o))
                    })
                }({
                    animation: {
                        Feature: K
                    },
                    exit: {
                        Feature: J
                    },
                    inView: {
                        Feature: t4
                    },
                    tap: {
                        Feature: t1
                    },
                    focus: {
                        Feature: tJ
                    },
                    hover: {
                        Feature: tz
                    },
                    ...tq,
                    ...t7
                }, (t, e) => e.isSVG ? ? l(t) ? new s.l(e) : new o.M(e, {
                    allowProjection: t !== r.Fragment
                }))
        },
        83246: (t, e, n) => {
            n.d(e, {
                Q: () => i
            });
            let i = (0, n(1521).createContext)({
                transformPagePoint: t => t,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        85656: (t, e, n) => {
            n.d(e, {
                xQ: () => o
            });
            var i = n(1521),
                s = n(32719);

            function o(t = !0) {
                let e = (0, i.useContext)(s.t);
                if (null === e) return [!0, null];
                let {
                    isPresent: n,
                    onExitComplete: r,
                    register: a
                } = e, l = (0, i.useId)();
                (0, i.useEffect)(() => {
                    if (t) return a(l)
                }, [t]);
                let u = (0, i.useCallback)(() => t && r && r(l), [l, r, t]);
                return !n && r ? [!1, u] : [!0]
            }
        }
    }
]);