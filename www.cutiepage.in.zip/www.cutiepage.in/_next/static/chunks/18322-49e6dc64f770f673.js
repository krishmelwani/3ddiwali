(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [18322], {
        18322: (s, r, e) => {
            "use strict";
            e.r(r), e.d(r, {
                ChapterWalk: () => b,
                ForgiveAsk: () => v,
                LetterWriter: () => j,
                NO_HOPS: () => k,
                OPEN_BEATS: () => o,
                OpeningScene: () => x,
                PromiseStamps: () => y,
                SunriseScene: () => g,
                WALK_MS: () => f
            });
            var l = e(73365),
                a = e(1521),
                i = e(87191),
                t = e(34768),
                n = e(82161),
                c = e(19146);

            function d() {
                let s = (0, t.useStory)(),
                    r = (0, t.useSectionIndex)();
                return !s.active || s.index === r
            }

            function p() {
                let s = (0, a.useRef)([]);
                return (0, a.useEffect)(() => {
                    let r = s.current;
                    return () => r.forEach(clearTimeout)
                }, []), (r, e) => {
                    s.current.push(setTimeout(r, e))
                }
            }
            e(86578);
            let h = s => s ? "" : void 0,
                o = [500, 2700, 3800, 5400];

            function x({
                media: s,
                skip: r,
                children: e
            }) {
                let n = "edit" === (0, t.useMode)(),
                    p = (0, i.usePrefersReducedMotion)(),
                    j = d(),
                    f = (0, a.useRef)(null),
                    [u, b] = (0, a.useState)(0),
                    [k, m] = (0, a.useState)(0),
                    v = n || p ? 4 : u;
                return (0, i.useReplaySignal)(f, () => {
                    b(0), m(s => s + 1)
                }), (0, a.useEffect)(() => {
                    if (n || p || !j) return;
                    let s = o.map((s, r) => setTimeout(() => b(s => Math.max(s, r + 1)), s));
                    return () => s.forEach(clearTimeout)
                }, [n, p, j, k]), (0, l.jsxs)("div", {
                    ref: f,
                    className: "prsb-open",
                    "data-b1": h(v >= 1),
                    "data-b2": h(v >= 2),
                    "data-b3": h(v >= 3),
                    "data-b4": h(v >= 4),
                    children: [(0, l.jsxs)("div", {
                        className: "prsb-stage prsb-open-stage",
                        children: [(0, l.jsx)("div", {
                            className: "prsb-pan",
                            children: (0, l.jsx)(c.Zw, {
                                kind: "night"
                            })
                        }), (0, l.jsx)(c.S5, {
                            depth: "far"
                        }), (0, l.jsxs)("div", {
                            className: "prsb-walker prsb-open-walker",
                            children: [(0, l.jsx)(c.CX, {
                                className: "prsb-walker-cloud"
                            }), (0, l.jsx)("div", {
                                className: "prsb-rig",
                                children: (0, l.jsx)(c.dH, {
                                    expr: "sad",
                                    pose: v >= 2 ? "sit" : "walk"
                                })
                            })]
                        }), (0, l.jsx)(c.S5, {
                            depth: "near"
                        }), (0, l.jsx)("div", {
                            className: "prsb-open-media",
                            children: s
                        }), n ? (0, l.jsx)("span", {
                            className: "prsb-skip-chip",
                            children: r
                        }) : v < 4 ? (0, l.jsx)("button", {
                            type: "button",
                            className: "prsb-skip",
                            onClick: () => b(4),
                            children: (0, l.jsx)("span", {
                                className: "prsb-skip-chip",
                                children: r
                            })
                        }) : null]
                    }), (0, l.jsx)("div", {
                        className: "prsb-open-card",
                        children: e
                    })]
                })
            }

            function j({
                paper: s,
                seal: r,
                finish: e,
                fold: h,
                sent: o
            }) {
                let x = "edit" === (0, t.useMode)(),
                    f = (0, i.usePrefersReducedMotion)(),
                    u = d(),
                    b = (0, n.useSoundEffect)(),
                    k = p(),
                    m = (0, a.useRef)(null),
                    [v, y] = (0, a.useState)("writing"),
                    g = x ? "sent" : f && "writing" === v ? "written" : v;
                return (0, i.useReplaySignal)(m, () => y("writing")), (0, a.useEffect)(() => {
                    if (x || f || !u || "writing" !== v) return;
                    let s = setTimeout(() => y("written"), 5460);
                    return () => clearTimeout(s)
                }, [x, f, u, v]), (0, l.jsxs)("div", {
                    ref: m,
                    className: "prsb-letter",
                    "data-phase": g,
                    children: [(0, l.jsxs)("div", {
                        className: "prsb-desk",
                        "aria-hidden": !0,
                        children: [(0, l.jsx)(c.CX, {
                            className: "prsb-desk-cloud"
                        }), (0, l.jsx)("div", {
                            className: "prsb-rig prsb-desk-bear",
                            children: (0, l.jsx)(c.dH, {
                                expr: "writing" === g ? "focused" : "sent" === g ? "shy" : "sorry",
                                pose: "writing" === g ? "write" : "hold"
                            })
                        }), (0, l.jsx)("div", {
                            className: "prsb-desk-chowki",
                            children: (0, l.jsx)(c.G6, {})
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "prsb-paper-wrap",
                        children: [(0, l.jsxs)("div", {
                            className: "prsb-paper",
                            children: [s, "writing" === g ? (0, l.jsx)("span", {
                                className: "prsb-ink",
                                "aria-hidden": !0,
                                children: Array.from({
                                    length: 22
                                }, (s, r) => (0, l.jsx)("i", {
                                    style: {
                                        top: `${30*r}px`,
                                        animationDelay: `${300+230*r}ms`
                                    }
                                }, r))
                            }) : null, "writing" === g ? (0, l.jsx)("button", {
                                type: "button",
                                className: "prsb-finish",
                                onClick: () => y("written"),
                                children: (0, l.jsx)("span", {
                                    className: "prsb-skip-chip",
                                    children: e
                                })
                            }) : null]
                        }), (0, l.jsxs)("div", {
                            className: "prsb-envelope",
                            children: [(0, l.jsxs)("svg", {
                                viewBox: "0 0 220 140",
                                "aria-hidden": !0,
                                className: "block size-full",
                                children: [(0, l.jsx)("rect", {
                                    x: "6",
                                    y: "6",
                                    width: "208",
                                    height: "128",
                                    rx: "12",
                                    fill: "var(--prsb-paper)",
                                    stroke: "var(--f-fg)",
                                    strokeWidth: "4"
                                }), (0, l.jsx)("path", {
                                    d: "M8 12 L110 82 L212 12",
                                    fill: "none",
                                    stroke: "var(--f-fg)",
                                    strokeWidth: "4",
                                    strokeLinejoin: "round"
                                }), (0, l.jsx)("path", {
                                    d: "M8 130 L84 64 M212 130 L136 64",
                                    fill: "none",
                                    stroke: "var(--f-fg)",
                                    strokeWidth: "3",
                                    opacity: "0.4"
                                })]
                            }), (0, l.jsx)("span", {
                                className: "prsb-seal",
                                children: r
                            })]
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "prsb-after",
                        children: [x ? (0, l.jsx)("span", {
                            className: "prsb-btn",
                            children: h
                        }) : null, x || "written" !== g ? null : (0, l.jsx)("button", {
                            type: "button",
                            className: "prsb-btn prsb-rise",
                            onClick: () => {
                                x || "written" !== g || (b("rustle"), y("folding"), k(() => {
                                    y("sent"), b("stamp")
                                }, 700 * !f))
                            },
                            children: h
                        }), "sent" === g ? (0, l.jsx)("div", {
                            className: x ? "" : "prsb-rise",
                            children: o
                        }) : null]
                    })]
                })
            }
            let f = 2800,
                u = {
                    street: {
                        walk: "sorry",
                        stop: "oops",
                        knock: "oops",
                        up: "happy"
                    },
                    park: {
                        walk: "sad",
                        stop: "sad",
                        knock: "sad",
                        up: "shy"
                    },
                    door: {
                        walk: "sorry",
                        stop: "shy",
                        knock: "sorry",
                        up: "happy"
                    }
                };

            function b({
                kind: s,
                photo: r,
                help: e,
                after: h
            }) {
                let o = "edit" === (0, t.useMode)(),
                    x = (0, i.usePrefersReducedMotion)(),
                    j = d(),
                    k = (0, n.useSoundEffect)(),
                    m = p(),
                    v = (0, a.useRef)(null),
                    [y, g] = (0, a.useState)("walk"),
                    N = o ? "up" : x && "walk" === y ? "stop" : y;
                (0, i.useReplaySignal)(v, () => g("walk")), (0, a.useEffect)(() => {
                    if (o || x || !j || "walk" !== y) return;
                    let r = setTimeout(() => {
                        g("stop"), k("door" === s ? "tick" : "nope")
                    }, f);
                    return () => clearTimeout(r)
                }, [o, x, j, y, s, k]);
                let w = "walk" === N ? "walk" : "knock" === N ? "knock" : "door" === s || "up" === N ? "hold" : "stand";
                return (0, l.jsxs)("div", {
                    ref: v,
                    className: "prsb-chapter",
                    "data-kind": s,
                    "data-phase": N,
                    children: [(0, l.jsxs)("div", {
                        className: "prsb-stage",
                        children: [(0, l.jsx)("div", {
                            className: "prsb-pan",
                            children: (0, l.jsx)(c.Zw, {
                                kind: s
                            })
                        }), (0, l.jsx)(c.S5, {
                            depth: "far"
                        }), (0, l.jsxs)("div", {
                            className: "prsb-walker prsb-ch-walker",
                            children: [(0, l.jsx)(c.CX, {
                                className: "prsb-walker-cloud"
                            }), (0, l.jsx)("div", {
                                className: "prsb-rig",
                                children: (0, l.jsx)("div", {
                                    className: "prsb-tumble",
                                    children: (0, l.jsx)(c.dH, {
                                        expr: u[s][N],
                                        pose: w,
                                        carry: !0
                                    })
                                })
                            }), "stop" === N && "door" !== s ? (0, l.jsx)(c.wW, {}) : null, "stop" === N && "park" === s ? (0, l.jsx)("span", {
                                className: "prsb-splash",
                                "aria-hidden": !0,
                                children: [0, 1, 2, 3, 4].map(s => (0, l.jsx)("i", {
                                    style: {
                                        "--i": s
                                    }
                                }, s))
                            }) : null]
                        }), (0, l.jsx)("div", {
                            className: "prsb-hang",
                            children: r
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "prsb-after",
                        children: [o ? (0, l.jsx)("span", {
                            className: "prsb-btn",
                            children: e
                        }) : null, o || "stop" !== N ? null : (0, l.jsx)("button", {
                            type: "button",
                            className: "prsb-btn prsb-rise",
                            onClick: () => {
                                if (!o && "stop" === N) {
                                    if ("door" === s) {
                                        g("knock"), k("tap"), m(() => {
                                            g("up"), k("reveal")
                                        }, 1e3 * !x);
                                        return
                                    }
                                    g("up"), k("win")
                                }
                            },
                            children: e
                        }), "up" === N ? (0, l.jsx)("div", {
                            className: o ? "" : "prsb-rise prsb-rise-late",
                            children: h
                        }) : null]
                    })]
                })
            }
            let k = [
                    [-30, 74],
                    [-150, 128],
                    [-60, 180]
                ],
                m = ["sorry", "sad", "sad", "sorry"];

            function v({
                flag: s,
                yes: r,
                no: e,
                giveIn: d,
                replies: p,
                answered: h
            }) {
                let o = "edit" === (0, t.useMode)(),
                    x = (0, n.useSoundEffect)(),
                    j = (0, a.useRef)(null),
                    [f, u] = (0, a.useState)(!1),
                    [b, y] = (0, a.useState)(0);
                (0, i.useReplaySignal)(j, () => {
                    u(!1), y(0)
                });
                let g = b >= Math.min(p.length, k.length),
                    N = () => {
                        o || f || (u(!0), x("popper"))
                    },
                    w = () => {
                        if (!o && !f) {
                            if (g) return N();
                            y(s => s + 1), x("nope")
                        }
                    },
                    M = b > 0 && !g ? k[b - 1] : null,
                    W = f || o;
                return (0, l.jsxs)("div", {
                    ref: j,
                    className: "prsb-ask",
                    ...W ? {
                        "data-said": ""
                    } : {},
                    children: [(0, l.jsxs)("div", {
                        className: "prsb-ask-bear",
                        "aria-hidden": !0,
                        children: [f ? (0, l.jsx)(i.ConfettiBurst, {
                            seed: 23,
                            count: 30,
                            top: "40%"
                        }) : null, (0, l.jsx)("div", {
                            className: "prsb-rig",
                            children: (0, l.jsx)(c.dH, {
                                expr: W ? "happy" : m[Math.min(b, m.length - 1)],
                                pose: W ? "cheer" : "hold"
                            })
                        }), (0, l.jsx)("span", {
                            className: "prsb-ask-flag",
                            children: s
                        }), f ? (0, l.jsx)("span", {
                            className: "prsb-hearts",
                            children: [0, 1, 2, 3, 4, 5].map(s => (0, l.jsx)("span", {
                                style: {
                                    "--i": s
                                },
                                children: (0, l.jsx)(c.oV, {})
                            }, s))
                        }) : null]
                    }), o ? (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("div", {
                            className: "prsb-ask-replies",
                            children: p.map((s, r) => (0, l.jsx)("span", {
                                className: "prsb-reply",
                                children: s
                            }, r))
                        }), (0, l.jsxs)("div", {
                            className: "prsb-ask-buttons",
                            children: [(0, l.jsx)("span", {
                                className: "prsb-btn",
                                children: r
                            }), (0, l.jsx)("span", {
                                className: "prsb-btn prsb-btn-ghost",
                                children: e
                            }), (0, l.jsx)("span", {
                                className: "prsb-btn prsb-btn-ghost",
                                children: d
                            })]
                        }), (0, l.jsx)("div", {
                            children: h
                        })]
                    }) : f ? (0, l.jsx)("div", {
                        className: "prsb-rise",
                        children: h
                    }) : (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("p", {
                            className: "prsb-ask-replies",
                            "aria-live": "polite",
                            children: b > 0 ? (0, l.jsx)("span", {
                                className: "prsb-reply prsb-pop",
                                children: p[Math.min(b, p.length) - 1]
                            }, b) : null
                        }), (0, l.jsxs)("div", {
                            className: "prsb-ask-buttons",
                            children: [(0, l.jsx)("button", {
                                type: "button",
                                className: "prsb-btn",
                                onClick: N,
                                children: r
                            }), (0, l.jsx)("button", {
                                type: "button",
                                className: "prsb-btn prsb-btn-ghost prsb-no",
                                style: M ? {
                                    transform: `translate(${M[0]}px, ${M[1]}px)`
                                } : void 0,
                                onClick: w,
                                onPointerEnter: s => {
                                    "mouse" !== s.pointerType || g || w()
                                },
                                children: g ? d : e
                            })]
                        })]
                    })]
                })
            }

            function y({
                promises: s,
                stamp: r,
                done: e
            }) {
                let d = "edit" === (0, t.useMode)(),
                    p = (0, n.useSoundEffect)(),
                    o = (0, a.useRef)(null),
                    [x, j] = (0, a.useState)([]),
                    f = d || x.length >= s.length;
                return (0, i.useReplaySignal)(o, () => j([])), (0, l.jsxs)("div", {
                    ref: o,
                    className: "prsb-promises",
                    ...f ? {
                        "data-done": ""
                    } : {},
                    children: [(0, l.jsxs)("div", {
                        className: "prsb-promise-bear",
                        "aria-hidden": !0,
                        children: [(0, l.jsx)("div", {
                            className: "prsb-rig",
                            children: (0, l.jsx)(c.dH, {
                                expr: f ? "happy" : "focused",
                                pose: "stamp"
                            })
                        }), (0, l.jsx)("span", {
                            className: "prsb-slam",
                            "data-on": h(!d && x.length > 0),
                            children: (0, l.jsxs)("svg", {
                                viewBox: "0 0 40 48",
                                className: "block size-full",
                                children: [(0, l.jsx)("circle", {
                                    cx: "20",
                                    cy: "8",
                                    r: "6.5",
                                    fill: "var(--prsb-wood)",
                                    stroke: "var(--prsb-ink)",
                                    strokeWidth: "3"
                                }), (0, l.jsx)("rect", {
                                    x: "15",
                                    y: "13",
                                    width: "10",
                                    height: "16",
                                    fill: "var(--prsb-wood)",
                                    stroke: "var(--prsb-ink)",
                                    strokeWidth: "3"
                                }), (0, l.jsx)("rect", {
                                    x: "4",
                                    y: "29",
                                    width: "32",
                                    height: "10",
                                    rx: "3",
                                    fill: "var(--prsb-wood)",
                                    stroke: "var(--prsb-ink)",
                                    strokeWidth: "3"
                                }), (0, l.jsx)("rect", {
                                    x: "6",
                                    y: "39",
                                    width: "28",
                                    height: "6",
                                    rx: "2",
                                    fill: "var(--f-accent)",
                                    stroke: "var(--prsb-ink)",
                                    strokeWidth: "2.5"
                                })]
                            })
                        }, x.length)]
                    }), (0, l.jsx)("ol", {
                        className: "prsb-promise-list",
                        children: s.map((e, a) => {
                            let i = d || x.includes(a),
                                t = (0, l.jsxs)(l.Fragment, {
                                    children: [(0, l.jsx)("span", {
                                        className: "prsb-promise-dot",
                                        "aria-hidden": !0,
                                        children: a + 1
                                    }), (0, l.jsx)("span", {
                                        className: "prsb-promise-text",
                                        children: e
                                    }), i ? (0, l.jsxs)("span", {
                                        className: d ? "prsb-stamp" : "prsb-stamp prsb-stamp-in",
                                        children: [(0, l.jsx)(c.oV, {
                                            className: "prsb-stamp-heart"
                                        }), r]
                                    }) : null]
                                });
                            return (0, l.jsx)("li", {
                                children: d ? (0, l.jsx)("div", {
                                    className: "prsb-promise",
                                    children: t
                                }) : (0, l.jsx)("button", {
                                    type: "button",
                                    className: "prsb-promise",
                                    "aria-pressed": i,
                                    onClick: () => {
                                        !(d || x.includes(a)) && (j(s => [...s, a]), p(x.length + 1 >= s.length ? "fanfare" : "stamp"))
                                    },
                                    children: t
                                })
                            }, a)
                        })
                    }), (0, l.jsx)("div", {
                        className: "prsb-after",
                        children: f ? (0, l.jsx)("div", {
                            className: d ? "" : "prsb-rise",
                            children: e
                        }) : null
                    })]
                })
            }

            function g() {
                let s = "edit" === (0, t.useMode)(),
                    r = d(),
                    e = (0, a.useRef)(null),
                    [n, p] = (0, a.useState)(!1),
                    h = s || n;
                return (0, i.useReplaySignal)(e, () => p(!1)), (0, a.useEffect)(() => {
                    if (s || !r) return;
                    let e = setTimeout(() => p(!0), 450);
                    return () => clearTimeout(e)
                }, [s, r]), (0, l.jsxs)("div", {
                    ref: e,
                    className: "prsb-sunrise",
                    ...h ? {
                        "data-risen": ""
                    } : {},
                    "aria-hidden": !0,
                    children: [(0, l.jsx)("span", {
                        className: "prsb-dawn"
                    }), (0, l.jsxs)("div", {
                        className: "prsb-sunrise-stage",
                        children: [(0, l.jsx)("span", {
                            className: "prsb-sun",
                            children: (0, l.jsx)(c.ws, {})
                        }), (0, l.jsxs)("div", {
                            className: "prsb-sunrise-bear",
                            children: [(0, l.jsx)(c.CX, {
                                className: "prsb-walker-cloud prsb-cloud-leaves"
                            }), (0, l.jsx)("div", {
                                className: "prsb-rig",
                                children: (0, l.jsx)(c.dH, {
                                    expr: h ? "happy" : "sorry",
                                    pose: h ? "hug" : "stand",
                                    heart: h
                                })
                            })]
                        }), h && !s ? (0, l.jsx)("span", {
                            className: "prsb-hearts prsb-hearts-loop",
                            children: [0, 1, 2, 3, 4, 5, 6, 7].map(s => (0, l.jsx)("span", {
                                style: {
                                    "--i": s
                                },
                                children: (0, l.jsx)(c.oV, {})
                            }, s))
                        }) : null]
                    })]
                })
            }
        },
        19146: (s, r, e) => {
            "use strict";
            e.d(r, {
                Ah: () => g,
                CX: () => h,
                G6: () => v,
                Nm: () => N,
                S5: () => o,
                Zw: () => b,
                dH: () => d,
                oV: () => m,
                wW: () => k,
                ws: () => y
            });
            var l = e(73365);
            let a = "var(--prsb-ink)",
                i = {
                    stroke: a,
                    strokeWidth: 4,
                    strokeLinejoin: "round",
                    strokeLinecap: "round"
                };

            function t({
                expr: s
            }) {
                switch (s) {
                    case "sorry":
                        return (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("path", {
                                d: "M66 70 L84 64 M134 70 L116 64",
                                fill: "none",
                                ...i,
                                strokeWidth: 3.5
                            }), (0, l.jsxs)("g", {
                                className: "prsb-eyes",
                                children: [(0, l.jsx)("circle", {
                                    cx: "78",
                                    cy: "84",
                                    r: "10",
                                    fill: a
                                }), (0, l.jsx)("circle", {
                                    cx: "122",
                                    cy: "84",
                                    r: "10",
                                    fill: a
                                }), (0, l.jsx)("circle", {
                                    cx: "81.5",
                                    cy: "80.5",
                                    r: "3.6",
                                    fill: "#fff"
                                }), (0, l.jsx)("circle", {
                                    cx: "125.5",
                                    cy: "80.5",
                                    r: "3.6",
                                    fill: "#fff"
                                }), (0, l.jsx)("circle", {
                                    cx: "75",
                                    cy: "88",
                                    r: "1.8",
                                    fill: "#fff"
                                }), (0, l.jsx)("circle", {
                                    cx: "119",
                                    cy: "88",
                                    r: "1.8",
                                    fill: "#fff"
                                })]
                            }), (0, l.jsx)("path", {
                                d: "M91 121 q4.5 -4 9 0 q4.5 4 9 0",
                                fill: "none",
                                ...i,
                                strokeWidth: 3.5
                            })]
                        });
                    case "oops":
                        return (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsxs)("g", {
                                className: "prsb-eyes",
                                children: [(0, l.jsx)("path", {
                                    d: "M78 84 m-8 0 a8 8 0 1 0 8 -8 a5 5 0 1 0 5 5 a2 2 0 1 0 -2 -2",
                                    fill: "none",
                                    ...i,
                                    strokeWidth: 3
                                }), (0, l.jsx)("path", {
                                    d: "M122 84 m-8 0 a8 8 0 1 0 8 -8 a5 5 0 1 0 5 5 a2 2 0 1 0 -2 -2",
                                    fill: "none",
                                    ...i,
                                    strokeWidth: 3
                                })]
                            }), (0, l.jsx)("ellipse", {
                                cx: "100",
                                cy: "121",
                                rx: "5",
                                ry: "6.5",
                                fill: a
                            })]
                        });
                    case "happy":
                        return (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("g", {
                                className: "prsb-eyes",
                                children: (0, l.jsx)("path", {
                                    d: "M69 88 Q78 76 87 88 M113 88 Q122 76 131 88",
                                    fill: "none",
                                    ...i,
                                    strokeWidth: 4.5
                                })
                            }), (0, l.jsx)("path", {
                                d: "M89 113 Q100 131 111 113 Z",
                                fill: a,
                                ...i,
                                strokeWidth: 3
                            }), (0, l.jsx)("path", {
                                d: "M95 121 Q100 117 105 121 Q100 127 95 121 Z",
                                fill: "var(--prsb-blush)"
                            })]
                        });
                    case "shy":
                        return (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("g", {
                                className: "prsb-eyes",
                                children: (0, l.jsx)("path", {
                                    d: "M70 86 Q78 92 86 86 M114 86 Q122 92 130 86",
                                    fill: "none",
                                    ...i,
                                    strokeWidth: 4
                                })
                            }), (0, l.jsx)("ellipse", {
                                cx: "66",
                                cy: "104",
                                rx: "13",
                                ry: "8",
                                fill: "var(--prsb-blush)",
                                opacity: "0.8"
                            }), (0, l.jsx)("ellipse", {
                                cx: "134",
                                cy: "104",
                                rx: "13",
                                ry: "8",
                                fill: "var(--prsb-blush)",
                                opacity: "0.8"
                            }), (0, l.jsx)("path", {
                                d: "M94 118 Q100 123 106 118",
                                fill: "none",
                                ...i,
                                strokeWidth: 3.5
                            })]
                        });
                    case "focused":
                        return (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("path", {
                                d: "M66 70 L86 75 M134 70 L114 75",
                                fill: "none",
                                ...i,
                                strokeWidth: 3.5
                            }), (0, l.jsxs)("g", {
                                className: "prsb-eyes",
                                children: [(0, l.jsx)("circle", {
                                    cx: "79",
                                    cy: "87",
                                    r: "5.5",
                                    fill: a
                                }), (0, l.jsx)("circle", {
                                    cx: "121",
                                    cy: "87",
                                    r: "5.5",
                                    fill: a
                                })]
                            }), (0, l.jsx)("path", {
                                d: "M92 118 Q99 121 106 117",
                                fill: "none",
                                ...i,
                                strokeWidth: 3.5
                            }), (0, l.jsx)("path", {
                                d: "M103 119 q5 1 6 7 q-6 2 -8 -5 Z",
                                fill: "var(--prsb-blush)",
                                ...i,
                                strokeWidth: 2.5
                            })]
                        });
                    default:
                        return (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("path", {
                                d: "M66 76 L84 70 M134 76 L116 70",
                                fill: "none",
                                ...i,
                                strokeWidth: 3.5
                            }), (0, l.jsxs)("g", {
                                className: "prsb-eyes",
                                children: [(0, l.jsx)("circle", {
                                    cx: "78",
                                    cy: "87",
                                    r: "5.5",
                                    fill: a
                                }), (0, l.jsx)("circle", {
                                    cx: "122",
                                    cy: "87",
                                    r: "5.5",
                                    fill: a
                                })]
                            }), (0, l.jsx)("path", {
                                d: "M92 121 Q100 114 108 121",
                                fill: "none",
                                ...i,
                                strokeWidth: 3.5
                            }), (0, l.jsx)("path", {
                                className: "prsb-tear",
                                d: "M70 96 q-5 8 0 11 q5 -3 0 -11 Z",
                                fill: "var(--prsb-rain)",
                                stroke: a,
                                strokeWidth: "2"
                            })]
                        })
                }
            }

            function n() {
                return (0, l.jsxs)("g", {
                    className: "prsb-bouquet",
                    transform: "translate(0 22)",
                    children: [(0, l.jsx)("path", {
                        d: "M90 150 l-6 -14 M100 148 v-16 M110 150 l6 -14",
                        stroke: "var(--prsb-leaf)",
                        strokeWidth: "3.5",
                        strokeLinecap: "round"
                    }), (0, l.jsx)("circle", {
                        cx: "84",
                        cy: "134",
                        r: "9",
                        fill: "var(--f-accent)",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("circle", {
                        cx: "116",
                        cy: "134",
                        r: "9",
                        fill: "var(--f-accent)",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("circle", {
                        cx: "100",
                        cy: "128",
                        r: "10",
                        fill: "var(--prsb-sun)",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("circle", {
                        cx: "100",
                        cy: "128",
                        r: "3.5",
                        fill: "var(--prsb-furdark)"
                    }), (0, l.jsx)("path", {
                        d: "M81 132 q3 -4 6 0 M113 132 q3 -4 6 0",
                        fill: "none",
                        stroke: a,
                        strokeWidth: "2"
                    }), (0, l.jsx)("path", {
                        d: "M80 146 L100 200 L120 146 Z",
                        fill: "var(--prsb-paper)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, l.jsx)("path", {
                        d: "M88 158 h24 M92 168 h16",
                        stroke: a,
                        strokeWidth: "2",
                        opacity: "0.4"
                    })]
                })
            }

            function c() {
                return (0, l.jsx)("path", {
                    className: "prsb-hugheart",
                    d: "M100 190 C80 176 70 166 70 152 C70 142 78 136 86 136 C92 136 97 140 100 145 C103 140 108 136 114 136 C122 136 130 142 130 152 C130 166 120 176 100 190 Z",
                    fill: "var(--f-accent)",
                    ...i,
                    strokeWidth: 3.5
                })
            }

            function d({
                expr: s = "sad",
                pose: r = "stand",
                carry: e = !1,
                heart: p = !1,
                className: h = ""
            }) {
                return (0, l.jsxs)("svg", {
                    viewBox: "0 0 200 240",
                    "aria-hidden": !0,
                    className: `prsb-bear block ${h}`,
                    "data-pose": r,
                    "data-expr": s,
                    "data-carry": e ? "" : void 0,
                    children: [(0, l.jsxs)("g", {
                        className: "prsb-leg prsb-leg-l",
                        children: [(0, l.jsx)("rect", {
                            x: "70",
                            y: "176",
                            width: "28",
                            height: "52",
                            rx: "14",
                            fill: "var(--prsb-fur)",
                            ...i
                        }), (0, l.jsx)("ellipse", {
                            cx: "84",
                            cy: "218",
                            rx: "8",
                            ry: "5",
                            fill: "var(--prsb-muzzle)"
                        })]
                    }), (0, l.jsxs)("g", {
                        className: "prsb-leg prsb-leg-r",
                        children: [(0, l.jsx)("rect", {
                            x: "102",
                            y: "176",
                            width: "28",
                            height: "52",
                            rx: "14",
                            fill: "var(--prsb-fur)",
                            ...i
                        }), (0, l.jsx)("ellipse", {
                            cx: "116",
                            cy: "218",
                            rx: "8",
                            ry: "5",
                            fill: "var(--prsb-muzzle)"
                        })]
                    }), (0, l.jsxs)("g", {
                        className: "prsb-torso",
                        children: [(0, l.jsx)("ellipse", {
                            cx: "100",
                            cy: "164",
                            rx: "46",
                            ry: "44",
                            fill: "var(--prsb-fur)",
                            ...i
                        }), (0, l.jsx)("ellipse", {
                            cx: "100",
                            cy: "174",
                            rx: "28",
                            ry: "26",
                            fill: "var(--prsb-muzzle)"
                        }), (0, l.jsx)("path", {
                            d: "M90 168 q10 6 20 0",
                            fill: "none",
                            stroke: "var(--prsb-furdark)",
                            strokeWidth: "2.5",
                            strokeLinecap: "round",
                            opacity: "0.5"
                        })]
                    }), p ? (0, l.jsx)(c, {}) : null, (0, l.jsx)("g", {
                        className: "prsb-arm prsb-arm-l",
                        children: (0, l.jsx)("rect", {
                            x: "44",
                            y: "128",
                            width: "24",
                            height: "56",
                            rx: "12",
                            fill: "var(--prsb-fur)",
                            ...i
                        })
                    }), (0, l.jsx)("g", {
                        className: "prsb-arm prsb-arm-r",
                        children: (0, l.jsx)("rect", {
                            x: "132",
                            y: "128",
                            width: "24",
                            height: "56",
                            rx: "12",
                            fill: "var(--prsb-fur)",
                            ...i
                        })
                    }), e ? (0, l.jsx)(n, {}) : null, (0, l.jsxs)("g", {
                        className: "prsb-head",
                        children: [(0, l.jsxs)("g", {
                            className: "prsb-ear prsb-ear-l",
                            children: [(0, l.jsx)("circle", {
                                cx: "56",
                                cy: "50",
                                r: "20",
                                fill: "var(--prsb-fur)",
                                ...i
                            }), (0, l.jsx)("circle", {
                                cx: "56",
                                cy: "50",
                                r: "10",
                                fill: "var(--prsb-muzzle)"
                            })]
                        }), (0, l.jsxs)("g", {
                            className: "prsb-ear prsb-ear-r",
                            children: [(0, l.jsx)("circle", {
                                cx: "144",
                                cy: "50",
                                r: "20",
                                fill: "var(--prsb-fur)",
                                ...i
                            }), (0, l.jsx)("circle", {
                                cx: "144",
                                cy: "50",
                                r: "10",
                                fill: "var(--prsb-muzzle)"
                            })]
                        }), (0, l.jsx)("ellipse", {
                            cx: "100",
                            cy: "90",
                            rx: "56",
                            ry: "48",
                            fill: "var(--prsb-fur)",
                            ...i
                        }), (0, l.jsxs)("g", {
                            transform: "rotate(-24 129 56)",
                            children: [(0, l.jsx)("rect", {
                                x: "114",
                                y: "50",
                                width: "30",
                                height: "12",
                                rx: "6",
                                fill: "var(--prsb-paper)",
                                stroke: a,
                                strokeWidth: "2.5"
                            }), (0, l.jsx)("rect", {
                                x: "124",
                                y: "50",
                                width: "10",
                                height: "12",
                                fill: "var(--prsb-muzzle)",
                                stroke: a,
                                strokeWidth: "1.5"
                            }), (0, l.jsx)("circle", {
                                cx: "127",
                                cy: "54",
                                r: "0.9",
                                fill: a
                            }), (0, l.jsx)("circle", {
                                cx: "131",
                                cy: "58",
                                r: "0.9",
                                fill: a
                            })]
                        }), (0, l.jsx)("ellipse", {
                            cx: "100",
                            cy: "107",
                            rx: "25",
                            ry: "18",
                            fill: "var(--prsb-muzzle)",
                            ...i,
                            strokeWidth: 3
                        }), (0, l.jsx)("path", {
                            d: "M91 98 q9 -5 18 0 q-2 9 -9 10 q-7 -1 -9 -10 Z",
                            fill: a
                        }), (0, l.jsx)("circle", {
                            cx: "64",
                            cy: "106",
                            r: "9",
                            fill: "var(--prsb-blush)",
                            opacity: "0.55"
                        }), (0, l.jsx)("circle", {
                            cx: "136",
                            cy: "106",
                            r: "9",
                            fill: "var(--prsb-blush)",
                            opacity: "0.55"
                        }), (0, l.jsx)(t, {
                            expr: s
                        })]
                    })]
                })
            }
            let p = [
                [30, 0],
                [46, .35],
                [60, .15],
                [74, .5],
                [88, .25],
                [52, .6]
            ];

            function h({
                className: s = ""
            }) {
                return (0, l.jsxs)("svg", {
                    viewBox: "0 0 120 110",
                    "aria-hidden": !0,
                    className: `prsb-pcloud block ${s}`,
                    children: [(0, l.jsx)("g", {
                        className: "prsb-pdrops",
                        children: p.map(([s, r]) => (0, l.jsx)("path", {
                            className: "prsb-pdrop",
                            d: `M${s} 56 l-3 12`,
                            stroke: "var(--prsb-rain)",
                            strokeWidth: "3.5",
                            strokeLinecap: "round",
                            style: {
                                animationDelay: `${r}s`
                            }
                        }, s))
                    }), (0, l.jsx)("path", {
                        d: "M24 58 C10 58 8 40 22 36 C22 20 42 14 52 24 C58 10 82 10 86 28 C100 26 110 38 102 50 C110 58 100 64 92 60 Z",
                        fill: "var(--prsb-cloud)",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, l.jsx)("path", {
                        d: "M40 44 q4 3 8 0 M70 44 q4 3 8 0",
                        fill: "none",
                        stroke: a,
                        strokeWidth: "2.5",
                        strokeLinecap: "round"
                    })]
                })
            }

            function o({
                depth: s
            }) {
                let r, e, a = (r = "far" === s ? 26 : 16, e = "far" === s ? 1 : 2, Array.from({
                        length: r
                    }, (s, r) => ({
                        x: (53 * r + 17 * e) % 360,
                        y: (97 * r + 31 * e) % 300
                    }))),
                    i = "far" === s ? 10 : 18;
                return (0, l.jsx)("svg", {
                    viewBox: "0 0 360 600",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: `prsb-rain prsb-rain-${s}`,
                    children: [0, 300].flatMap(r => a.map((e, a) => (0, l.jsx)("path", {
                        d: `M${e.x} ${e.y+r} l-3 ${i}`,
                        stroke: "var(--prsb-rain)",
                        strokeWidth: "far" === s ? 1.6 : 2.6,
                        strokeLinecap: "round"
                    }, `${r}-${a}`)))
                })
            }

            function x({
                kind: s
            }) {
                return "park" === s ? (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)("path", {
                        d: "M0 220 Q120 150 240 200 T480 190 T720 200 V300 H0 Z",
                        fill: "var(--prsb-far)"
                    }), [60, 210, 380, 560, 660].map(s => (0, l.jsxs)("g", {
                        children: [(0, l.jsx)("rect", {
                            x: s - 3,
                            y: "176",
                            width: "6",
                            height: "22",
                            fill: "var(--prsb-mid)"
                        }), (0, l.jsx)("circle", {
                            cx: s,
                            cy: "170",
                            r: "16",
                            fill: "var(--prsb-mid)"
                        })]
                    }, s))]
                }) : (0, l.jsx)(l.Fragment, {
                    children: [
                        [0, 150, 90],
                        [96, 120, 70],
                        [172, 168, 110],
                        [288, 132, 80],
                        [374, 104, 96],
                        [476, 154, 70],
                        [552, 126, 90],
                        [648, 160, 72]
                    ].map(([s, r, e]) => (0, l.jsxs)("g", {
                        children: [(0, l.jsx)("rect", {
                            x: s,
                            y: r,
                            width: e,
                            height: 300 - r,
                            fill: "var(--prsb-far)"
                        }), s % 2 == 0 ? (0, l.jsx)("rect", {
                            x: s + e / 2 - 10,
                            y: r - 18,
                            width: "20",
                            height: "18",
                            rx: "4",
                            fill: "var(--prsb-far)"
                        }) : null, [0, 1].map(a => [0, 1, 2].map(i => (0, l.jsx)("rect", {
                            x: s + 12 + i * Math.round((e - 24) / 3),
                            y: r + 16 + 30 * a,
                            width: "10",
                            height: "12",
                            rx: "2",
                            fill: (a + i + s) % 3 == 0 ? "var(--prsb-sun)" : "var(--prsb-mid)",
                            opacity: (a + i + s) % 3 == 0 ? .9 : .6
                        }, `${a}-${i}`)))]
                    }, s))
                })
            }

            function j({
                x: s
            }) {
                return (0, l.jsxs)("g", {
                    children: [(0, l.jsx)("path", {
                        className: "prsb-draw",
                        pathLength: 1,
                        d: `M${s} 280 V120 q0 -14 16 -14 h14`,
                        fill: "none",
                        ...i,
                        strokeWidth: 5
                    }), (0, l.jsx)("path", {
                        d: `M${s+22} 104 h20 l-4 10 h-12 Z`,
                        fill: "var(--prsb-mid)",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("circle", {
                        className: "prsb-glow",
                        cx: s + 32,
                        cy: "122",
                        r: "14",
                        fill: "var(--prsb-sun)",
                        opacity: "0.35"
                    })]
                })
            }

            function f({
                kind: s
            }) {
                return "park" === s ? (0, l.jsxs)(l.Fragment, {
                    children: [
                        [90, 330, 600].map(s => (0, l.jsxs)("g", {
                            children: [(0, l.jsx)("path", {
                                className: "prsb-draw",
                                pathLength: 1,
                                d: `M${s} 280 V180 M${s} 214 l-16 -18 M${s} 200 l14 -14`,
                                fill: "none",
                                ...i,
                                strokeWidth: 6
                            }), (0, l.jsx)("circle", {
                                cx: s - 18,
                                cy: "160",
                                r: "30",
                                fill: "var(--prsb-leaf)",
                                ...i
                            }), (0, l.jsx)("circle", {
                                cx: s + 18,
                                cy: "152",
                                r: "34",
                                fill: "var(--prsb-leaf)",
                                ...i
                            }), (0, l.jsx)("circle", {
                                cx: s,
                                cy: "128",
                                r: "28",
                                fill: "var(--prsb-leaf)",
                                ...i
                            })]
                        }, s)), (0, l.jsx)("path", {
                            d: "M430 246 h80 M434 246 v34 M506 246 v34 M424 228 h92",
                            fill: "none",
                            ...i,
                            strokeWidth: 6
                        })
                    ]
                }) : "door" === s ? (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)("rect", {
                        x: "300",
                        y: "96",
                        width: "260",
                        height: "190",
                        fill: "var(--prsb-wall)",
                        ...i
                    }), (0, l.jsx)("path", {
                        d: "M290 96 h280 l-14 -26 h-252 Z",
                        fill: "var(--f-accent)",
                        ...i
                    }), (0, l.jsx)("rect", {
                        x: "392",
                        y: "150",
                        width: "68",
                        height: "130",
                        rx: "6",
                        fill: "var(--prsb-sun)",
                        ...i
                    }), (0, l.jsxs)("g", {
                        className: "prsb-doorleaf",
                        children: [(0, l.jsx)("rect", {
                            x: "396",
                            y: "154",
                            width: "60",
                            height: "122",
                            rx: "4",
                            fill: "var(--prsb-door)",
                            ...i,
                            strokeWidth: 3
                        }), (0, l.jsx)("circle", {
                            cx: "446",
                            cy: "216",
                            r: "4",
                            fill: "var(--prsb-sun)",
                            stroke: a,
                            strokeWidth: "2"
                        }), (0, l.jsx)("rect", {
                            x: "408",
                            y: "170",
                            width: "36",
                            height: "14",
                            rx: "3",
                            fill: "var(--prsb-paper)",
                            stroke: a,
                            strokeWidth: "2"
                        })]
                    }), (0, l.jsx)("path", {
                        d: "M384 150 q42 -30 84 0",
                        fill: "none",
                        stroke: "var(--prsb-sun)",
                        strokeWidth: "6",
                        strokeLinecap: "round",
                        strokeDasharray: "2 12"
                    }), (0, l.jsx)("rect", {
                        x: "324",
                        y: "130",
                        width: "44",
                        height: "44",
                        rx: "4",
                        fill: "var(--prsb-sun)",
                        opacity: "0.8",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("path", {
                        d: "M346 130 v44 M324 152 h44",
                        stroke: a,
                        strokeWidth: "3"
                    }), (0, l.jsx)("path", {
                        d: "M490 254 h36 l-6 26 h-24 Z",
                        fill: "var(--f-accent)",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("path", {
                        d: "M508 254 v-20 m0 8 l-10 -10 m10 4 l10 -10",
                        fill: "none",
                        stroke: "var(--prsb-leaf)",
                        strokeWidth: "4",
                        strokeLinecap: "round"
                    })]
                }) : (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)("path", {
                        d: "M0 96 Q150 130 300 98 T600 100 T720 104",
                        fill: "none",
                        stroke: a,
                        strokeWidth: "2.5"
                    }), (0, l.jsx)("path", {
                        d: "M0 112 Q150 146 300 114 T600 116 T720 120",
                        fill: "none",
                        stroke: a,
                        strokeWidth: "2.5"
                    }), [176, 520].map(s => (0, l.jsxs)("g", {
                        transform: `translate(${s} ${176===s?104:96})`,
                        children: [(0, l.jsx)("ellipse", {
                            cx: "0",
                            cy: "0",
                            rx: "9",
                            ry: "7",
                            fill: a
                        }), (0, l.jsx)("circle", {
                            cx: "7",
                            cy: "-6",
                            r: "5",
                            fill: a
                        }), (0, l.jsx)("path", {
                            d: "M11 -6 l6 2 l-6 2",
                            fill: "var(--prsb-sun)"
                        })]
                    }, s)), (0, l.jsx)(j, {
                        x: 80
                    }), (0, l.jsx)(j, {
                        x: 400
                    }), "night" === s ? null : (0, l.jsx)(j, {
                        x: 660
                    })]
                })
            }

            function u({
                kind: s
            }) {
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)("path", {
                        d: "M0 262 Q180 254 360 262 T720 262 V300 H0 Z",
                        fill: "var(--prsb-ground)",
                        ...i,
                        strokeWidth: 3
                    }), [30, 150, 260, 470, 650].map(s => (0, l.jsx)("path", {
                        d: `M${s} 262 l4 -12 l4 12 l4 -9 l4 9`,
                        fill: "none",
                        stroke: "var(--prsb-leaf)",
                        strokeWidth: "3",
                        strokeLinejoin: "round"
                    }, s)), "park" === s || "night" === s ? (0, l.jsx)("ellipse", {
                        className: "prsb-puddle",
                        cx: "night" === s ? 230 : 474,
                        cy: "276",
                        rx: "44",
                        ry: "8",
                        fill: "var(--prsb-rain)",
                        opacity: "0.7",
                        stroke: a,
                        strokeWidth: "2.5"
                    }) : null, "street" === s ? (0, l.jsx)("path", {
                        d: "M486 270 q4 -16 18 -14 q14 2 12 14 Z",
                        fill: "var(--prsb-far)",
                        ...i,
                        strokeWidth: 3
                    }) : null, "door" === s ? (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("rect", {
                            x: "530",
                            y: "264",
                            width: "80",
                            height: "12",
                            rx: "3",
                            fill: "var(--prsb-wall)",
                            ...i,
                            strokeWidth: 3
                        }), (0, l.jsx)("rect", {
                            x: "548",
                            y: "276",
                            width: "44",
                            height: "8",
                            rx: "3",
                            fill: "var(--f-accent)",
                            stroke: a,
                            strokeWidth: "2.5"
                        })]
                    }) : null]
                })
            }

            function b({
                kind: s
            }) {
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)("svg", {
                        viewBox: "0 0 720 300",
                        "aria-hidden": !0,
                        className: "prsb-layer prsb-layer-far",
                        children: (0, l.jsx)(x, {
                            kind: s
                        })
                    }), (0, l.jsx)("svg", {
                        viewBox: "0 0 720 300",
                        "aria-hidden": !0,
                        className: "prsb-layer prsb-layer-mid",
                        children: (0, l.jsx)(f, {
                            kind: s
                        })
                    }), (0, l.jsx)("svg", {
                        viewBox: "0 0 720 300",
                        "aria-hidden": !0,
                        className: "prsb-layer prsb-layer-near",
                        children: (0, l.jsx)(u, {
                            kind: s
                        })
                    })]
                })
            }

            function k() {
                return (0, l.jsx)("svg", {
                    viewBox: "0 0 100 40",
                    "aria-hidden": !0,
                    className: "prsb-dizzy block",
                    children: [18, 50, 82].map((s, r) => (0, l.jsx)("path", {
                        d: `M${s} ${1===r?6:14} l3 7 l7 1 l-5 5 l1 7 l-6 -3 l-6 3 l1 -7 l-5 -5 l7 -1 Z`,
                        fill: "var(--prsb-sun)",
                        stroke: a,
                        strokeWidth: "2",
                        strokeLinejoin: "round"
                    }, s))
                })
            }

            function m({
                className: s = ""
            }) {
                return (0, l.jsx)("svg", {
                    viewBox: "0 0 32 30",
                    "aria-hidden": !0,
                    className: `block ${s}`,
                    children: (0, l.jsx)("path", {
                        d: "M16 28 C6 21 1.5 15.5 1.5 9.5 C1.5 5 5 1.5 9.2 1.5 C12.2 1.5 14.6 3.2 16 5.8 C17.4 3.2 19.8 1.5 22.8 1.5 C27 1.5 30.5 5 30.5 9.5 C30.5 15.5 26 21 16 28 Z",
                        fill: "var(--f-accent)",
                        stroke: a,
                        strokeWidth: "2",
                        strokeLinejoin: "round"
                    })
                })
            }

            function v() {
                return (0, l.jsxs)("svg", {
                    viewBox: "0 0 220 80",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, l.jsx)("rect", {
                        x: "10",
                        y: "10",
                        width: "200",
                        height: "22",
                        rx: "6",
                        fill: "var(--prsb-wood)",
                        ...i
                    }), (0, l.jsx)("path", {
                        d: "M26 32 v40 M194 32 v40",
                        ...i,
                        strokeWidth: 8,
                        stroke: "var(--prsb-wood)"
                    }), (0, l.jsx)("path", {
                        d: "M26 32 v40 M194 32 v40",
                        fill: "none",
                        stroke: a,
                        strokeWidth: "2",
                        opacity: "0.4"
                    }), (0, l.jsx)("path", {
                        d: "M40 20 h120",
                        stroke: a,
                        strokeWidth: "2",
                        opacity: "0.3"
                    }), (0, l.jsx)("rect", {
                        x: "160",
                        y: "-6",
                        width: "18",
                        height: "16",
                        rx: "4",
                        fill: "var(--prsb-cloud)",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("rect", {
                        x: "34",
                        y: "-14",
                        width: "10",
                        height: "24",
                        rx: "2",
                        fill: "var(--prsb-paper)",
                        ...i,
                        strokeWidth: 2.5
                    }), (0, l.jsx)("path", {
                        className: "prsb-flame",
                        d: "M39 -16 q-6 -8 0 -16 q6 8 0 16 Z",
                        fill: "var(--prsb-sun)",
                        stroke: a,
                        strokeWidth: "2"
                    })]
                })
            }

            function y() {
                return (0, l.jsxs)("svg", {
                    viewBox: "0 0 160 160",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, l.jsx)("g", {
                        className: "prsb-rays",
                        children: Array.from({
                            length: 12
                        }, (s, r) => (0, l.jsx)("path", {
                            d: "M80 8 l7 20 h-14 Z",
                            fill: "var(--prsb-sun)",
                            stroke: a,
                            strokeWidth: "2.5",
                            strokeLinejoin: "round",
                            transform: `rotate(${30*r} 80 80)`
                        }, r))
                    }), (0, l.jsx)("circle", {
                        cx: "80",
                        cy: "80",
                        r: "40",
                        fill: "var(--prsb-sun)",
                        ...i
                    }), (0, l.jsx)("path", {
                        d: "M64 78 q5 -6 10 0 M86 78 q5 -6 10 0",
                        fill: "none",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, l.jsx)("path", {
                        d: "M68 92 q12 12 24 0",
                        fill: "none",
                        ...i,
                        strokeWidth: 3.5
                    }), (0, l.jsx)("circle", {
                        cx: "58",
                        cy: "90",
                        r: "6",
                        fill: "var(--prsb-blush)",
                        opacity: "0.7"
                    }), (0, l.jsx)("circle", {
                        cx: "102",
                        cy: "90",
                        r: "6",
                        fill: "var(--prsb-blush)",
                        opacity: "0.7"
                    })]
                })
            }

            function g({
                kind: s
            }) {
                return "White flag" === s ? (0, l.jsxs)("svg", {
                    viewBox: "0 0 120 140",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, l.jsx)("path", {
                        d: "M30 136 V12",
                        ...i,
                        strokeWidth: 6,
                        stroke: "var(--prsb-wood)"
                    }), (0, l.jsx)("path", {
                        d: "M30 136 V12",
                        fill: "none",
                        stroke: a,
                        strokeWidth: "1.5",
                        opacity: "0.5"
                    }), (0, l.jsx)("path", {
                        className: "prsb-wave",
                        d: "M32 16 C56 6 72 26 108 14 L104 66 C72 78 56 58 32 68 Z",
                        fill: "#ffffff",
                        ...i
                    }), (0, l.jsx)("path", {
                        d: "M50 38 q10 -6 20 0 q10 6 20 0",
                        fill: "none",
                        stroke: a,
                        strokeWidth: "2.5",
                        opacity: "0.3"
                    }), (0, l.jsx)("circle", {
                        cx: "30",
                        cy: "10",
                        r: "6",
                        fill: "var(--prsb-sun)",
                        ...i,
                        strokeWidth: 3
                    })]
                }) : "Balloon" === s ? (0, l.jsxs)("svg", {
                    viewBox: "0 0 120 140",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, l.jsx)("path", {
                        d: "M60 92 C70 104 50 116 60 136",
                        fill: "none",
                        stroke: a,
                        strokeWidth: "2.5"
                    }), (0, l.jsx)("path", {
                        d: "M60 92 C30 72 14 56 14 36 C14 20 26 8 40 8 C50 8 56 14 60 22 C64 14 70 8 80 8 C94 8 106 20 106 36 C106 56 90 72 60 92 Z",
                        fill: "var(--f-accent)",
                        ...i
                    }), (0, l.jsx)("path", {
                        d: "M54 92 h12 l-6 8 Z",
                        fill: "var(--f-accent)",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("path", {
                        d: "M30 32 q4 -12 16 -14",
                        fill: "none",
                        stroke: "#ffffff",
                        strokeWidth: "5",
                        strokeLinecap: "round",
                        opacity: "0.7"
                    }), (0, l.jsx)("path", {
                        d: "M60 30 l-6 14 l10 4 l-6 14",
                        fill: "none",
                        stroke: "var(--f-onAccent)",
                        strokeWidth: "3.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })]
                }) : (0, l.jsxs)("svg", {
                    viewBox: "0 0 120 140",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, l.jsx)("path", {
                        d: "M60 136 V70",
                        ...i,
                        strokeWidth: 7,
                        stroke: "var(--prsb-wood)"
                    }), (0, l.jsx)("rect", {
                        x: "8",
                        y: "10",
                        width: "104",
                        height: "70",
                        rx: "10",
                        fill: "var(--prsb-paper)",
                        ...i
                    }), (0, l.jsx)("path", {
                        d: "M60 64 C42 52 34 44 34 34 C34 27 40 22 46 22 C52 22 56 26 60 32 C64 26 68 22 74 22 C80 22 86 27 86 34 C86 44 78 52 60 64 Z",
                        fill: "var(--f-accent)",
                        ...i,
                        strokeWidth: 3
                    }), (0, l.jsx)("path", {
                        d: "M60 30 v30",
                        stroke: a,
                        strokeWidth: "2.5",
                        strokeDasharray: "4 4"
                    }), (0, l.jsx)("path", {
                        d: "M52 38 l16 4 M52 48 l16 4",
                        stroke: a,
                        strokeWidth: "2.5",
                        strokeLinecap: "round"
                    })]
                })
            }

            function N({
                kind: s
            }) {
                return "Paw" === s ? (0, l.jsxs)("svg", {
                    viewBox: "0 0 80 80",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, l.jsx)("circle", {
                        cx: "40",
                        cy: "40",
                        r: "34",
                        fill: "var(--f-accent)",
                        ...i
                    }), (0, l.jsx)("ellipse", {
                        cx: "40",
                        cy: "48",
                        rx: "13",
                        ry: "11",
                        fill: "var(--f-onAccent)"
                    }), [
                        [24, 32],
                        [34, 22],
                        [46, 22],
                        [56, 32]
                    ].map(([s, r]) => (0, l.jsx)("ellipse", {
                        cx: s,
                        cy: r,
                        rx: "5.5",
                        ry: "6.5",
                        fill: "var(--f-onAccent)"
                    }, s))]
                }) : "Plaster" === s ? (0, l.jsxs)("svg", {
                    viewBox: "0 0 80 80",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, l.jsxs)("g", {
                        transform: "rotate(-30 40 40)",
                        children: [(0, l.jsx)("rect", {
                            x: "4",
                            y: "26",
                            width: "72",
                            height: "28",
                            rx: "14",
                            fill: "var(--prsb-paper)",
                            ...i
                        }), (0, l.jsx)("rect", {
                            x: "28",
                            y: "26",
                            width: "24",
                            height: "28",
                            fill: "var(--prsb-muzzle)",
                            ...i,
                            strokeWidth: 3
                        }), [34, 40, 46].map(s => (0, l.jsx)("circle", {
                            cx: s,
                            cy: 40 === s ? 36 : 44,
                            r: "1.6",
                            fill: a
                        }, s))]
                    }), (0, l.jsxs)("g", {
                        transform: "rotate(30 40 40)",
                        children: [(0, l.jsx)("rect", {
                            x: "4",
                            y: "26",
                            width: "72",
                            height: "28",
                            rx: "14",
                            fill: "var(--prsb-paper)",
                            ...i
                        }), (0, l.jsx)("rect", {
                            x: "28",
                            y: "26",
                            width: "24",
                            height: "28",
                            fill: "var(--prsb-muzzle)",
                            ...i,
                            strokeWidth: 3
                        })]
                    })]
                }) : (0, l.jsxs)("svg", {
                    viewBox: "0 0 80 80",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, l.jsx)("path", {
                        d: "M40 8 C46 8 48 14 54 14 C60 14 66 18 66 26 C72 30 72 38 68 44 C72 50 70 60 62 62 C60 70 50 74 44 70 C40 74 32 74 28 70 C20 72 12 66 14 58 C6 54 6 44 12 40 C8 32 12 22 22 22 C24 14 32 8 40 8 Z",
                        fill: "var(--f-accent)",
                        ...i
                    }), (0, l.jsx)("path", {
                        d: "M40 56 C30 49 25 44 25 37 C25 32 29 29 33 29 C36 29 38 31 40 34 C42 31 44 29 47 29 C51 29 55 32 55 37 C55 44 50 49 40 56 Z",
                        fill: "var(--f-onAccent)"
                    })]
                })
            }
        },
        86578: () => {}
    }
]);