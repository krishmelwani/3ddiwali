"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [23445], {
        23445: (e, t, a) => {
            a.d(t, {
                Pz: () => s,
                UF: () => n,
                W5: () => u,
                lw: () => r,
                qC: () => l
            });
            var o = a(84910),
                i = a(95468);

            function r(e, t) {
                let a = e.createElement("canvas");
                a.width = 256, a.height = 256;
                let i = a.getContext("2d");
                if (i) {
                    let e = i.createRadialGradient(107.52, 102.4, 12.8, 128, 128, 122.88);
                    e.addColorStop(0, "#fffbee"), e.addColorStop(.75, "#f6edd2"), e.addColorStop(.97, "#e9dcb8"), e.addColorStop(1, "rgba(233,220,184,0)"), i.fillStyle = e, i.beginPath(), i.arc(128, 128, 122.88, 0, 2 * Math.PI), i.fill(), i.save(), i.beginPath(), i.arc(128, 128, 117.76, 0, 2 * Math.PI), i.clip();
                    for (let e = 0; e < 16; e++) {
                        let e = 256 * (.03 + .08 * t());
                        i.fillStyle = `rgba(196,182,150,${.25+.3*t()})`, i.beginPath(), i.arc(256 * (.2 + .6 * t()), 256 * (.2 + .6 * t()), e, 0, 2 * Math.PI), i.fill()
                    }
                    i.restore()
                }
                let r = new o.GOR(a);
                r.colorSpace = o.er$;
                let l = new o.V9B({
                        map: r,
                        transparent: !0,
                        fog: !1,
                        depthWrite: !0,
                        toneMapped: !1
                    }),
                    n = new o.bdM(1, 1),
                    s = new o.eaF(n, l);
                return s.userData.noShadow = !0, {
                    mesh: s,
                    material: l,
                    dispose() {
                        r.dispose(), n.dispose(), l.dispose()
                    }
                }
            }

            function l(e) {
                let {
                    center: t,
                    width: a,
                    time: r,
                    px: l,
                    rand: n
                } = e, s = t.clone().normalize(), u = new o.Pq0().crossVectors(s, new o.Pq0(0, 1, 0)).normalize(), f = new o.Pq0().crossVectors(u, s).normalize(), d = new Float32Array(780), c = new Float32Array(260), p = new Float32Array(260), v = new o.LoY;
                v.setAttribute("position", new o.THS(d, 3)), v.setAttribute("aOrder", new o.THS(c, 1)), v.setAttribute("aSize", new o.THS(p, 1));
                let m = {
                        uTime: r,
                        uPx: l,
                        uProgress: {
                            value: 0
                        },
                        uDim: {
                            value: 1
                        },
                        uColor: {
                            value: new o.Q1f("#dfe9ff")
                        }
                    },
                    h = new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: o.EZo,
                        uniforms: m,
                        vertexShader: `uniform float uTime, uPx, uProgress; attribute float aOrder, aSize; varying float vA;
      void main(){ float on = smoothstep(aOrder, aOrder + 0.04, uProgress);
        float pop = 1.0 + 1.4*exp(-max(uProgress - aOrder, 0.0)*30.0)*on;
        vA = on*(0.8 + 0.2*sin(uTime*2.0 + aOrder*90.0));
        vec4 mv = modelViewMatrix*vec4(position, 1.0); gl_Position = projectionMatrix*mv;
        gl_PointSize = clamp(aSize*pop*uPx/max(-mv.z, 0.1), 1.0, 64.0); }`,
                        fragmentShader: `uniform vec3 uColor; uniform float uDim; varying float vA;
      void main(){ vec2 q = gl_PointCoord - 0.5; float d = length(q)*2.0; if (d > 1.0) discard;
        float core = smoothstep(0.3, 0.0, d); float halo = pow(1.0 - d, 3.0)*0.6;
        float cross = max(smoothstep(0.08, 0.0, abs(q.x))*(1.0 - d), smoothstep(0.08, 0.0, abs(q.y))*(1.0 - d))*0.6;
        gl_FragColor = vec4(uColor*(core*1.6 + halo + cross)*vA*uDim, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                    }),
                    g = new o.ONl(v, h);
                g.frustumCulled = !1, g.userData.noShadow = !0;
                let w = new Float32Array(1560),
                    S = new Float32Array(520),
                    b = new Float32Array(520),
                    x = new o.LoY;
                x.setAttribute("position", new o.THS(w, 3)), x.setAttribute("aT", new o.THS(S, 1)), x.setAttribute("aOrder", new o.THS(b, 1));
                let y = new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: o.EZo,
                        uniforms: m,
                        vertexShader: `uniform float uProgress; attribute float aT, aOrder; varying float vA;
      void main(){ float local = clamp((uProgress - aOrder)/0.05, 0.0, 1.0); vA = step(aT, local + 0.001)*0.5*step(0.001, uProgress);
        gl_Position = projectionMatrix*modelViewMatrix*vec4(position, 1.0); }`,
                        fragmentShader: `uniform vec3 uColor; uniform float uDim; varying float vA; void main(){ if (vA < 0.01) discard; gl_FragColor = vec4(uColor*vA*uDim, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`
                    }),
                    A = new o.DXC(x, y);
                return A.frustumCulled = !1, A.userData.noShadow = !0, {
                    stars: g,
                    lines: A,
                    uniforms: m,
                    setCanvas: function(e) {
                        let r = e.width / 46,
                            l = (0, i._F)(e, 2, r, 260, n),
                            s = a / e.width;
                        l.sort((e, t) => e[0] - t[0]);
                        let m = l.length,
                            h = [];
                        l.forEach((i, r) => {
                            let l, v, g = (l = (i[0] - e.width / 2) * s, v = (e.height / 2 - i[1]) * s, new o.Pq0().copy(t).addScaledVector(u, l).addScaledVector(f, v));
                            h.push(g), d.set([g.x, g.y, g.z], 3 * r), c[r] = (m > 1 ? r / (m - 1) : 0) * .88, p[r] = (.9 + 1.4 * n()) * (a / 60)
                        });
                        let g = 1.9 * r,
                            y = [];
                        for (let e = 0; e < m; e++)
                            for (let t = e + 1; t < m; t++) {
                                let a = l[e],
                                    o = l[t],
                                    i = Math.hypot(a[0] - o[0], a[1] - o[1]);
                                i < g && y.push([i, e, t])
                            }
                        y.sort((e, t) => e[0] - t[0]);
                        let A = Array.from({
                                length: m
                            }, (e, t) => t),
                            C = e => {
                                let t = e;
                                for (; A[t] !== t;) t = A[t];
                                let a = e;
                                for (; A[a] !== t;) {
                                    let e = A[a];
                                    A[a] = t, a = e
                                }
                                return t
                            },
                            P = 0;
                        for (let [, e, t] of y) {
                            if (P >= 260) break;
                            let a = C(e),
                                o = C(t);
                            if (a === o) continue;
                            A[a] = o;
                            let i = h[e],
                                r = h[t];
                            w.set([i.x, i.y, i.z, r.x, r.y, r.z], 6 * P);
                            let l = Math.max(c[e], c[t]);
                            b[2 * P] = l, b[2 * P + 1] = l, S[2 * P] = 0, S[2 * P + 1] = 1, P++
                        }
                        for (let e of (v.setDrawRange(0, m), x.setDrawRange(0, 2 * P), ["position", "aOrder", "aSize"])) v.attributes[e].needsUpdate = !0;
                        for (let e of ["position", "aT", "aOrder"]) x.attributes[e].needsUpdate = !0
                    },
                    dispose() {
                        v.dispose(), h.dispose(), x.dispose(), y.dispose()
                    }
                }
            }

            function n(e) {
                let {
                    px: t,
                    rand: a
                } = e, i = new o.bdM(1, 1);
                i.translate(-.5, 0, 0);
                let r = {
                        uFade: {
                            value: 1
                        },
                        uColor: {
                            value: new o.Q1f("#fff4d6")
                        }
                    },
                    l = new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: o.EZo,
                        uniforms: r,
                        vertexShader: "varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position, 1.0); }",
                        fragmentShader: `uniform float uFade; uniform vec3 uColor; varying vec2 vUv;
      void main(){ float along = pow(vUv.x, 2.2); float across = 1.0 - abs(vUv.y - 0.5)*2.0; across = pow(across, 1.6 + (1.0 - vUv.x)*4.0);
        float head = smoothstep(0.9, 1.0, vUv.x)*across*across*2.0;
        gl_FragColor = vec4(uColor*(along*across + head)*uFade*1.6, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                    }),
                    n = new o.eaF(i, l);
                n.matrixAutoUpdate = !1, n.visible = !1, n.frustumCulled = !1, n.userData.noShadow = !0;
                let s = new Float32Array(168),
                    u = new Float32Array(56),
                    f = Array.from({
                        length: 56
                    }, () => new o.Pq0),
                    d = new o.LoY;
                d.setAttribute("position", new o.THS(s, 3)), d.setAttribute("aLife", new o.THS(u, 1));
                let c = new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: o.EZo,
                        uniforms: {
                            uPx: t
                        },
                        vertexShader: `uniform float uPx; attribute float aLife; varying float vA;
      void main(){ vA = aLife; vec4 mv = modelViewMatrix*vec4(position, 1.0); gl_Position = projectionMatrix*mv;
        gl_PointSize = aLife > 0.0 ? clamp(1.6*aLife*uPx/max(-mv.z, 0.1), 1.0, 24.0) : 0.0; }`,
                        fragmentShader: `varying float vA; void main(){ float d = length(gl_PointCoord - 0.5)*2.0; if (d > 1.0 || vA <= 0.0) discard;
      gl_FragColor = vec4(vec3(1.0, 0.92, 0.7)*pow(1.0 - d, 1.5)*vA*1.5, 1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`
                    }),
                    p = new o.ONl(d, c);
                p.frustumCulled = !1, p.visible = !1, p.userData.noShadow = !0;
                let v = null,
                    m = 0,
                    h = 0,
                    g = new o.Pq0,
                    w = new o.Pq0,
                    S = new o.kn4,
                    b = new o.Pq0,
                    x = new o.Pq0,
                    y = new o.Pq0;
                return {
                    streak: n,
                    sparks: p,
                    fire(e, t, a, o) {
                        v = {
                            from: e.clone().normalize().multiplyScalar(200),
                            to: t.clone().normalize().multiplyScalar(200),
                            start: a,
                            dur: o ? 1.7 : 1,
                            big: o
                        }, n.visible = !0, p.visible = !0
                    },
                    get busy() {
                        return !!v
                    },
                    headDirection: () => v ? g.clone() : null,
                    reset() {
                        v = null, n.visible = !1, u.fill(0), d.attributes.aLife.needsUpdate = !0, p.visible = !1, h = 0
                    },
                    update(e, t) {
                        if (v) {
                            let t = (e - v.start) / v.dur;
                            if (t >= 1.25) v = null, n.visible = !1;
                            else {
                                let e = Math.min(1, t),
                                    i = e * e * (3 - 2 * e) * .6 + .4 * e;
                                g.lerpVectors(v.from, v.to, i);
                                let l = (v.big ? .32 : .22) * Math.min(1, 3 * e);
                                w.lerpVectors(v.from, v.to, Math.max(0, i - l)), r.uFade.value = t < 1 ? 1 : Math.max(0, 1 - (t - 1) * 4), b.subVectors(g, w);
                                let d = Math.max(.01, b.length());
                                b.normalize(), y.copy(g).negate().normalize(), x.crossVectors(y, b).normalize(), y.crossVectors(b, x).normalize();
                                let c = v.big ? 2.6 : 1.6;
                                if (S.makeBasis(b.clone().multiplyScalar(d), x.clone().multiplyScalar(c), y), S.setPosition(g), n.matrix.copy(S), n.matrixWorldNeedsUpdate = !0, t < 1) {
                                    let e = v.big ? 3 : 2;
                                    for (let t = 0; t < e; t++) {
                                        let e = m++ % 56,
                                            t = .15 * a(),
                                            i = new o.Pq0().lerpVectors(g, w, t);
                                        s.set([i.x, i.y, i.z], 3 * e), u[e] = .7 + .6 * a(), f[e].set((a() - .5) * 3, -1.5 - 3 * a(), (a() - .5) * 3)
                                    }
                                }
                            }
                        }
                        h = 0;
                        for (let e = 0; e < 56; e++) {
                            let a = u[e];
                            if (a <= 0) continue;
                            u[e] = Math.max(0, a - .9 * t);
                            let o = f[e];
                            s[3 * e] = s[3 * e] + o.x * t, s[3 * e + 1] = s[3 * e + 1] + o.y * t, s[3 * e + 2] = s[3 * e + 2] + o.z * t, h++
                        }(h || v) && (d.attributes.position.needsUpdate = !0, d.attributes.aLife.needsUpdate = !0), p.visible = h > 0 || !!v
                    },
                    dispose() {
                        i.dispose(), l.dispose(), d.dispose(), c.dispose()
                    }
                }
            }

            function s(e) {
                let {
                    slots: t,
                    perSlot: a,
                    time: i,
                    px: r,
                    rand: l,
                    calm: n
                } = e, s = t * a, u = new Float32Array(3 * s), f = new Float32Array(3 * s), d = new Float32Array(s), c = new Float32Array(s), p = new Float32Array(s);
                for (let e = 0; e < t; e++)
                    for (let t = 0; t < a; t++) {
                        let o = e * a + t,
                            i = 2 * l() - 1,
                            r = l() * Math.PI * 2,
                            n = Math.sqrt(1 - i * i),
                            s = .78 + .22 * l();
                        f.set([Math.cos(r) * n * s, i * s, Math.sin(r) * n * s], 3 * o), d[o] = e, c[o] = (t + .9 * l()) / a, p[o] = +(0 === t)
                    }
                let v = new o.LoY;
                v.setAttribute("position", new o.THS(u, 3)), v.setAttribute("aDir", new o.THS(f, 3)), v.setAttribute("aSlot", new o.THS(d, 1)), v.setAttribute("aRand", new o.THS(c, 1)), v.setAttribute("aRocket", new o.THS(p, 1));
                let m = Array.from({
                        length: t
                    }, () => new o.Pq0(0, -999, 0)),
                    h = Array.from({
                        length: t
                    }, () => -1e3),
                    g = Array.from({
                        length: t
                    }, () => new o.Q1f),
                    w = Array.from({
                        length: t
                    }, () => new o.Q1f),
                    S = Array.from({
                        length: t
                    }, () => 0),
                    b = Array.from({
                        length: t
                    }, () => 8),
                    x = new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: o.EZo,
                        uniforms: {
                            uTime: i,
                            uPx: r,
                            uCalm: {
                                value: +!!n
                            },
                            uOrigin: {
                                value: m
                            },
                            uStart: {
                                value: h
                            },
                            uC1: {
                                value: g
                            },
                            uC2: {
                                value: w
                            },
                            uKind: {
                                value: S
                            },
                            uScale: {
                                value: b
                            }
                        },
                        defines: {
                            SLOTS: t,
                            RISE: "1.10"
                        },
                        vertexShader: `uniform vec3 uOrigin[SLOTS]; uniform float uStart[SLOTS]; uniform vec3 uC1[SLOTS]; uniform vec3 uC2[SLOTS];
      uniform float uKind[SLOTS]; uniform float uScale[SLOTS]; uniform float uTime, uPx, uCalm;
      attribute vec3 aDir; attribute float aSlot, aRand, aRocket; varying vec3 vC; varying float vA;
      void main(){
        int s = int(aSlot + 0.5);
        vec3 o = uOrigin[s]; float t = uTime - uStart[s]; float k = uKind[s]; float sc = uScale[s];
        vec3 p = o; float a = 0.0; float size = 0.0; vec3 col = uC1[s];
        float life = k > 2.5 ? 3.4 : 2.3;
        if (t < 0.0 && t > -RISE) {
          float u = (t + RISE)/RISE; float lag = aRocket > 0.5 ? 0.0 : aRand*0.5;
          float uu = clamp(u - lag, 0.0, 1.0);
          float drop = 24.0;
          p = o + vec3(sin(uu*7.0 + float(s))*0.25, -drop*(1.0 - uu)*(1.0 - uu), 0.0);
          bool trail = aRocket > 0.5 || aRand < 0.16;
          a = trail && u > lag ? (aRocket > 0.5 ? 1.0 : (1.0 - lag*2.0)*0.6) : 0.0;
          size = aRocket > 0.5 ? 0.55 : 0.3;
          col = vec3(1.0, 0.82, 0.55);
        } else if (t >= 0.0 && t < life + 0.6) {
          vec3 d = aDir;
          float an = aRand*6.2831853;
          if (k > 0.5 && k < 1.5) { d = vec3(cos(an), sin(an), 0.0)*(0.95 + 0.05*fract(aRand*31.0)); }
          else if (k > 1.5 && k < 2.5) { float sn = sin(an); d = vec3(16.0*sn*sn*sn, 13.0*cos(an) - 5.0*cos(2.0*an) - 2.0*cos(3.0*an) - cos(4.0*an), 0.0)/17.0; }
          float pistil = (k < 0.5 || k > 2.5) ? step(fract(aRand*13.7), 0.28) : 0.0;
          d *= mix(1.0, 0.42, pistil);
          float drag = k > 2.5 ? 1.7 : 2.6;
          float g = k > 2.5 ? 1.5 : 0.8;
          p = o + d*sc*(1.0 - exp(-t*drag)) - vec3(0.0, g*t*t*0.5, 0.0);
          float fade = 1.0 - smoothstep(life*0.35, life, t + fract(aRand*17.0)*0.5);
          float flash = 1.0 + 2.5*exp(-t*9.0);
          float crackle = uCalm > 0.5 ? 1.0 : mix(1.0, step(0.45, fract(t*7.0 + aRand*13.0)), smoothstep(life*0.5, life*0.8, t));
          a = fade*crackle*flash;
          col = mix(uC1[s], uC2[s], pistil > 0.5 ? 1.0 : step(0.8, fract(aRand*7.3)));
          col = mix(col, vec3(1.0, 0.55, 0.2), smoothstep(life*0.5, life, t)*0.6);
          if (aRocket > 0.5) { a = 2.0*exp(-t*8.0); col = vec3(1.0, 0.95, 0.85); size = 1.1; } else size = (k > 2.5 ? 0.55 : 0.68)*(1.0 - 0.45*t/life);
        }
        vC = col; vA = a;
        vec4 mv = modelViewMatrix*vec4(p, 1.0);
        gl_Position = projectionMatrix*mv;
        gl_PointSize = a > 0.001 ? clamp(size*uPx/max(-mv.z, 0.1), 1.0, 48.0) : 0.0;
        if (a <= 0.001) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      }`,
                        fragmentShader: `varying vec3 vC; varying float vA;
      void main(){ float d = length(gl_PointCoord - 0.5)*2.0; if (d > 1.0) discard; float core = smoothstep(0.45, 0.0, d); float halo = pow(1.0 - d, 2.0)*0.5;
        gl_FragColor = vec4((vC*(core + halo) + vec3(core*core*0.5))*vA, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                    }),
                    y = new o.ONl(v, x);
                y.frustumCulled = !1, y.userData.noShadow = !0, y.visible = !1;
                let A = 0,
                    C = [];
                return {
                    points: y,
                    launch(e, a, o, r, l, n = 0) {
                        let s = A++ % t;
                        m[s].copy(e);
                        let u = i.value + n + 1.1;
                        return h[s] = u, g[s].set(o), w[s].set(r), S[s] = a, b[s] = l, y.visible = !0, C.push(u), u
                    },
                    popped(e) {
                        let t = 0;
                        for (let a = C.length - 1; a >= 0; a--) C[a] <= e && (C.splice(a, 1), t++);
                        return t
                    },
                    reset() {
                        for (let e = 0; e < t; e++) h[e] = -1e3;
                        C.length = 0, y.visible = !1
                    },
                    dispose() {
                        v.dispose(), x.dispose()
                    }
                }
            }

            function u(e) {
                let {
                    count: t,
                    center: a,
                    width: r,
                    time: l,
                    px: n,
                    rand: s
                } = e, u = new Float32Array(3 * t), f = new Float32Array(3 * t), d = new Float32Array(t);
                for (let e = 0; e < t; e++) {
                    let t = 2 * s() - 1,
                        a = s() * Math.PI * 2,
                        o = Math.sqrt(1 - t * t);
                    f.set([Math.cos(a) * o, t, Math.sin(a) * o * .4], 3 * e), d[e] = s()
                }
                let c = new o.LoY;
                c.setAttribute("position", new o.THS(u, 3)), c.setAttribute("aDir", new o.THS(f, 3)), c.setAttribute("aRand", new o.THS(d, 1));
                let p = {
                        uTime: l,
                        uPx: n,
                        uStart: {
                            value: -1e3
                        },
                        uOrigin: {
                            value: a.clone()
                        },
                        uColorA: {
                            value: new o.Q1f("#ffd27a")
                        },
                        uColorB: {
                            value: new o.Q1f("#ff8fab")
                        },
                        uWidth: {
                            value: r
                        },
                        uSize: {
                            value: .42
                        }
                    },
                    v = new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: o.EZo,
                        uniforms: p,
                        vertexShader: `uniform float uTime, uPx, uStart, uWidth, uSize; uniform vec3 uOrigin, uColorA, uColorB;
      attribute vec3 aDir; attribute float aRand; varying vec3 vC; varying float vA;
      void main(){
        float t = uTime - uStart; vec3 p = position; float a = 0.0;
        if (t > -1.2 && t < 0.0) {
          float u = (t + 1.2)/1.2; float lag = aRand*0.4; float uu = clamp(u - lag, 0.0, 1.0);
          p = uOrigin + vec3(0.0, -26.0*(1.0 - uu)*(1.0 - uu), 0.0);
          a = aRand < 0.05 && u > lag ? 1.0 - lag*2.0 : 0.0;
        } else if (t >= 0.0) {
          vec3 burst = uOrigin + aDir*uWidth*0.32*(1.0 - exp(-t*3.0));
          float m = smoothstep(0.25 + aRand*0.25, 1.2 + aRand*0.4, t);
          p = mix(burst, position, m);
          p += vec3(sin(uTime*1.3 + aRand*40.0), cos(uTime*1.1 + aRand*23.0), 0.0)*0.06*m;
          a = (1.0 + 2.0*exp(-t*5.0))*(0.78 + 0.22*sin(uTime*(2.0 + aRand*3.0) + aRand*60.0));
        }
        float across = clamp((position.x - uOrigin.x)/uWidth + 0.5, 0.0, 1.0);
        vC = mix(uColorA, uColorB, across*0.8);
        vA = a;
        vec4 mv = modelViewMatrix*vec4(p, 1.0); gl_Position = projectionMatrix*mv;
        gl_PointSize = a > 0.0 ? clamp(uSize*uPx/max(-mv.z, 0.1), 1.0, 32.0) : 0.0;
        if (a <= 0.0) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      }`,
                        fragmentShader: `varying vec3 vC; varying float vA;
      void main(){ float d = length(gl_PointCoord - 0.5)*2.0; if (d > 1.0) discard; float core = smoothstep(0.5, 0.0, d); float halo = pow(1.0 - d, 2.0)*0.45;
        gl_FragColor = vec4((vC*(core*1.2 + halo) + vec3(core*core*0.4))*vA, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`
                    }),
                    m = new o.ONl(c, v);
                return m.frustumCulled = !1, m.visible = !1, m.userData.noShadow = !0, {
                    points: m,
                    uniforms: p,
                    setCanvas(e) {
                        let o = (0, i._F)(e, 2, 0, 4 * t, s),
                            l = r / e.width;
                        for (let i = 0; i < t; i++) {
                            let t = o.length ? o[i % o.length] : [e.width / 2, e.height / 2],
                                r = 1.5 * (i >= o.length);
                            u.set([a.x + (t[0] - e.width / 2 + (s() - .5) * r) * l, a.y + (e.height / 2 - t[1] + (s() - .5) * r) * l, a.z], 3 * i)
                        }
                        c.attributes.position.needsUpdate = !0
                    },
                    start(e) {
                        p.uStart.value = e + 1.2, m.visible = !0
                    },
                    reset() {
                        p.uStart.value = -1e3, m.visible = !1
                    },
                    dispose() {
                        c.dispose(), v.dispose()
                    }
                }
            }
        },
        95468: (e, t, a) => {
            a.d(t, {
                Lf: () => p,
                Mr: () => c,
                Qw: () => l,
                _F: () => d,
                gS: () => v,
                lP: () => n,
                zq: () => f
            });
            var o = a(84910),
                i = a(63962);
            let r = new o.Q1f;

            function l(e, t) {
                return r.set(e), t >= 0 ? r.lerp(new o.Q1f(1, 1, 1), t) : r.multiplyScalar(1 + t), `#${r.getHexString()}`
            }
            class n {
                get size() {
                    return this.parts.length
                }
                addMatrix(e, t, a) {
                    let i = e.index ? e.toNonIndexed() : e.clone();
                    for (let e of Object.keys(i.attributes)) "position" !== e && "normal" !== e && i.deleteAttribute(e);
                    i.attributes.normal || i.computeVertexNormals(), i.applyMatrix4(a), r.set(t);
                    let l = i.attributes.position.count,
                        n = new Float32Array(3 * l);
                    for (let e = 0; e < l; e++) n[3 * e] = r.r, n[3 * e + 1] = r.g, n[3 * e + 2] = r.b;
                    i.setAttribute("color", new o.qtW(n, 3)), this.parts.push(i)
                }
                add(e, t, a, o = [0, 0, 0], i = [1, 1, 1]) {
                    this.matrix.compose(this.posV.set(a[0], a[1], a[2]), this.quat.setFromEuler(this.euler.set(o[0], o[1], o[2])), this.scaleV.set(i[0], i[1], i[2])), this.addMatrix(e, t, this.matrix)
                }
                addOnce(e, t, a, o, i) {
                    this.add(e, t, a, o, i), e.dispose()
                }
                box(e, t, a, o) {
                    this.add(this.unit.box, a, t, o, e)
                }
                cyl(e, t, a, i, r = 12, l, n) {
                    let s = this.unit.cyl.get(r);
                    s || (s = new o.Ho_(1, 1, 1, r), this.unit.cyl.set(r, s)), this.add(s, i, a, l, [e, t, n ? ? e])
                }
                cone(e, t, a, i, r, l = 12, n) {
                    this.addOnce(new o.Ho_(e, t, a, l), r, i, n)
                }
                sph(e, t, a, o) {
                    this.add(this.unit.sph, a, t, o, "number" == typeof e ? [e, e, e] : e)
                }
                rod(e, t, a, i, r = 6) {
                    let l = new o.Pq0(e[0], e[1], e[2]),
                        n = new o.Pq0(t[0], t[1], t[2]),
                        s = l.distanceTo(n),
                        u = this.unit.cyl.get(r);
                    u || (u = new o.Ho_(1, 1, 1, r), this.unit.cyl.set(r, u));
                    let f = n.clone().sub(l).normalize();
                    this.quat.setFromUnitVectors(new o.Pq0(0, 1, 0), f), this.matrix.compose(l.clone().add(n).multiplyScalar(.5), this.quat, this.scaleV.set(a, s, a)), this.addMatrix(u, i, this.matrix)
                }
                build(e) {
                    let t = this.parts.length ? (0, i.pP)(this.parts, !1) : null;
                    for (let e of this.parts) e.dispose();
                    for (let e of (this.parts.length = 0, this.unit.box.dispose(), this.unit.sph.dispose(), this.unit.cyl.values())) e.dispose();
                    return t ? (t.computeBoundingSphere(), new o.eaF(t, e)) : null
                }
                constructor() {
                    this.parts = [], this.matrix = new o.kn4, this.quat = new o.PTz, this.euler = new o.O9p, this.scaleV = new o.Pq0, this.posV = new o.Pq0, this.unit = {
                        box: new o.iNn(1, 1, 1),
                        sph: new o.Gu$(1, 12, 9),
                        cyl: new Map
                    }
                }
            }
            let s = `uniform float uTime, uPx, uTwinkle, uBoost, uChase;
attribute float aSize; attribute float aRand; attribute vec3 aColor;
varying vec3 vC; varying float vA;
void main(){
  vec4 mv = modelViewMatrix*vec4(position, 1.0);
  gl_Position = projectionMatrix*mv;
  float tw = 1.0 - uTwinkle*0.5*(1.0 + sin(uTime*(1.1 + aRand*2.0) + aRand*40.0));
  float chase = 1.0 + uChase*0.9*pow(0.5 + 0.5*sin(uTime*5.0 - aRand*0.0 - position.x*1.3 - position.z*1.3), 6.0);
  vA = tw*chase;
  vC = aColor;
  gl_PointSize = clamp(aSize*uPx*(1.0 + uBoost*0.35)/max(-mv.z, 0.1), 1.0, 220.0);
}`,
                u = `uniform float uOpacity, uBoost, uCore; varying vec3 vC; varying float vA;
void main(){
  vec2 q = gl_PointCoord - 0.5; float d = length(q)*2.0; if (d > 1.0) discard;
  float core = smoothstep(uCore, 0.0, d);
  float halo = pow(1.0 - d, 2.4)*0.5;
  vec3 c = vC*(halo + core*1.3) + vec3(core*core*0.55);
  gl_FragColor = vec4(c*vA*uOpacity*(1.0 + uBoost*0.6), 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

            function f(e) {
                let t = e.positions.length / 3,
                    a = new o.LoY;
                a.setAttribute("position", new o.THS(new Float32Array(e.positions), 3));
                let i = new Float32Array(3 * t),
                    r = new Float32Array(t),
                    l = new Float32Array(t),
                    n = new o.Q1f;
                for (let a = 0; a < t; a++) n.set("function" == typeof e.colors ? e.colors(a) : e.colors[a % e.colors.length] ? ? "#ffffff"), i.set([n.r, n.g, n.b], 3 * a), r[a] = "number" == typeof e.sizes ? e.sizes : e.sizes[a] ? ? .2, l[a] = e.rand();
                let f = new o.THS(i, 3);
                a.setAttribute("aColor", f), a.setAttribute("aSize", new o.THS(r, 1)), a.setAttribute("aRand", new o.THS(l, 1));
                let d = {
                        uTime: e.time,
                        uPx: e.px,
                        uTwinkle: {
                            value: e.twinkle ? ? .25
                        },
                        uOpacity: {
                            value: e.opacity ? ? 1
                        },
                        uBoost: {
                            value: 0
                        },
                        uChase: {
                            value: 0
                        },
                        uCore: {
                            value: e.core ? ? .3
                        }
                    },
                    c = new o.BKk({
                        transparent: !0,
                        depthWrite: !1,
                        blending: o.EZo,
                        uniforms: d,
                        vertexShader: s,
                        fragmentShader: u
                    }),
                    p = new o.ONl(a, c);
                return p.frustumCulled = !1, p.userData.noShadow = !0, Object.assign(p, {
                    uniforms: d,
                    count: t,
                    setColor(e, t) {
                        n.set(t), i[3 * e] = n.r, i[3 * e + 1] = n.g, i[3 * e + 2] = n.b
                    },
                    commit() {
                        f.needsUpdate = !0
                    }
                }), p
            }

            function d(e, t, a, o, i) {
                let r, l = e.getContext("2d");
                if (!l) return [];
                let {
                    width: n,
                    height: s
                } = e;
                try {
                    r = l.getImageData(0, 0, n, s).data
                } catch {
                    return []
                }
                let u = [];
                for (let e = 0; e < s; e += t)
                    for (let a = 0; a < n; a += t)(r[(e * n + a) * 4 + 3] ? ? 0) > 140 && u.push([a + (i() - .5) * t * .6, e + (i() - .5) * t * .6]);
                for (let e = u.length - 1; e > 0; e--) {
                    let t = Math.floor(i() * (e + 1)),
                        a = u[e];
                    u[e] = u[t], u[t] = a
                }
                if (a <= 0) return u.slice(0, o);
                let f = new Map,
                    d = [],
                    c = a * a;
                for (let e of u) {
                    let t = Math.floor(e[0] / a),
                        i = Math.floor(e[1] / a),
                        r = !0;
                    for (let a = -1; a <= 1 && r; a++)
                        for (let o = -1; o <= 1 && r; o++)
                            for (let l of f.get(`${t+a},${i+o}`) ? ? []) {
                                let t = l[0] - e[0],
                                    a = l[1] - e[1];
                                if (t * t + a * a < c) {
                                    r = !1;
                                    break
                                }
                            }
                    if (!r) continue;
                    d.push(e);
                    let l = `${t},${i}`,
                        n = f.get(l);
                    if (n ? n.push(e) : f.set(l, [e]), d.length >= o) break
                }
                return d
            }

            function c(e, t, a, o) {
                e.beginPath(), e.moveTo(t, a + .3 * o), e.bezierCurveTo(t, a, t - .5 * o, a, t - .5 * o, a + .3 * o), e.bezierCurveTo(t - .5 * o, a + .6 * o, t, a + .8 * o, t, a + o), e.bezierCurveTo(t, a + .8 * o, t + .5 * o, a + .6 * o, t + .5 * o, a + .3 * o), e.bezierCurveTo(t + .5 * o, a, t, a, t, a + .3 * o), e.fill()
            }

            function p(e, t, a, o, i, r, l, n = "#ffffff", s = 700) {
                e.fillStyle = n, e.textBaseline = "middle", e.textAlign = "left";
                let u = o.trim(),
                    f = i.trim(),
                    d = .5 * a;
                if (!u && !f) return void c(e, t / 2, a / 2 - .55 * d, 1.1 * d);
                let v = .35 * d,
                    m = Math.round(.62 * a),
                    h = (t - d - 2 * v - 16) / (u && f ? 2 : 1),
                    g = u ? l(e, u, r, m, h, s) : "";
                e.font = g || `${s} ${m}px ${r}`;
                let w = u ? e.measureText(u).width : 0,
                    S = f ? l(e, f, r, m, h, s) : "";
                e.font = S || `${s} ${m}px ${r}`;
                let b = (t - (w + (f ? e.measureText(f).width : 0) + d + (u ? v : 0) + (f ? v : 0))) / 2;
                u && (e.font = g, e.fillText(u, b, a / 2), b += w + v), s < 600 ? (c(e, b + d / 2, a / 2 - .48 * d, d), e.save(), e.globalCompositeOperation = "destination-out", c(e, b + d / 2, a / 2 - .48 * d + .12 * d, .76 * d), e.restore()) : c(e, b + d / 2, a / 2 - .48 * d, d), b += d + v, f && (e.font = S, e.fillText(f, b, a / 2))
            }

            function v(e, t, a, o, i, r, l, n = 400) {
                e.fillStyle = "#ffffff", e.textAlign = "center", e.textBaseline = "middle";
                let s = o.trim(),
                    u = i.trim(),
                    f = a / 3,
                    d = (a, o) => {
                        c(e, t / 2, a - .5 * o, o), e.save(), e.globalCompositeOperation = "destination-out", c(e, t / 2, a - .5 * o + .12 * o, .76 * o), e.restore()
                    };
                if (!s && !u) return void d(a / 2, .6 * a);
                let p = Math.round(.78 * f);
                s && (e.font = l(e, s, r, p, t - 24, n), e.fillText(s, t / 2, .5 * f)), d(1.5 * f, .62 * f), u && (e.font = l(e, u, r, p, t - 24, n), e.fillText(u, t / 2, 2.5 * f))
            }
        }
    }
]);