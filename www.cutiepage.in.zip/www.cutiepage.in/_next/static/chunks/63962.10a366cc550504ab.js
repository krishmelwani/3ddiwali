"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [63962], {
        63962: (e, t, r) => {
            r.d(t, {
                pP: () => o
            });
            var i = r(84910);

            function o(e, t = !1) {
                let r = null !== e[0].index,
                    l = new Set(Object.keys(e[0].attributes)),
                    n = new Set(Object.keys(e[0].morphAttributes)),
                    u = {},
                    m = {},
                    a = e[0].morphTargetsRelative,
                    f = new i.LoY,
                    h = 0;
                for (let i = 0; i < e.length; ++i) {
                    let o = e[i],
                        s = 0;
                    if (r !== (null !== o.index)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."), null;
                    for (let e in o.attributes) {
                        if (!l.has(e)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + '. All geometries must have compatible attributes; make sure "' + e + '" attribute exists among all geometries, or in none of them.'), null;
                        void 0 === u[e] && (u[e] = []), u[e].push(o.attributes[e]), s++
                    }
                    if (s !== l.size) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ". Make sure all geometries have the same number of attributes."), null;
                    if (a !== o.morphTargetsRelative) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ". .morphTargetsRelative must be consistent throughout all geometries."), null;
                    for (let e in o.morphAttributes) {
                        if (!n.has(e)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ".  .morphAttributes must be consistent throughout all geometries."), null;
                        void 0 === m[e] && (m[e] = []), m[e].push(o.morphAttributes[e])
                    }
                    if (t) {
                        let e;
                        if (r) e = o.index.count;
                        else {
                            if (void 0 === o.attributes.position) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ". The geometry must have either an index or a position attribute"), null;
                            e = o.attributes.position.count
                        }
                        f.addGroup(h, e, i), h += e
                    }
                }
                if (r) {
                    let t = 0,
                        r = [];
                    for (let i = 0; i < e.length; ++i) {
                        let o = e[i].index;
                        for (let e = 0; e < o.count; ++e) r.push(o.getX(e) + t);
                        t += e[i].attributes.position.count
                    }
                    f.setIndex(r)
                }
                for (let e in u) {
                    let t = s(u[e]);
                    if (!t) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + e + " attribute."), null;
                    f.setAttribute(e, t)
                }
                for (let e in m) {
                    let t = m[e][0].length;
                    if (0 !== t) {
                        f.morphAttributes = f.morphAttributes || {}, f.morphAttributes[e] = [];
                        for (let r = 0; r < t; ++r) {
                            let t = [];
                            for (let i = 0; i < m[e].length; ++i) t.push(m[e][i][r]);
                            let i = s(t);
                            if (!i) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + e + " morphAttribute."), null;
                            f.morphAttributes[e].push(i)
                        }
                    }
                }
                return f
            }

            function s(e) {
                let t, r, o, s = -1,
                    l = 0;
                for (let i = 0; i < e.length; ++i) {
                    let n = e[i];
                    if (void 0 === t && (t = n.array.constructor), t !== n.array.constructor) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."), null;
                    if (void 0 === r && (r = n.itemSize), r !== n.itemSize) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."), null;
                    if (void 0 === o && (o = n.normalized), o !== n.normalized) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."), null;
                    if (-1 === s && (s = n.gpuType), s !== n.gpuType) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."), null;
                    l += n.count * r
                }
                let n = new t(l),
                    u = new i.THS(n, r, o),
                    m = 0;
                for (let t = 0; t < e.length; ++t) {
                    let i = e[t];
                    if (i.isInterleavedBufferAttribute) {
                        let e = m / r;
                        for (let t = 0, o = i.count; t < o; t++)
                            for (let o = 0; o < r; o++) {
                                let r = i.getComponent(t, o);
                                u.setComponent(t + e, o, r)
                            }
                    } else n.set(i.array, m);
                    m += i.count * r
                }
                return void 0 !== s && (u.gpuType = s), u
            }
        }
    }
]);