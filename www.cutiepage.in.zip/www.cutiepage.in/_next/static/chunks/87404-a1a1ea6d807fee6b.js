"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [87404], {
        13384: (e, t, n) => {
            n.d(t, {
                Toast: () => m,
                ToastProvider: () => u,
                useToast: () => d
            });
            var r = n(73365),
                l = n(1521),
                i = n(64112),
                a = n(83078),
                s = n(79225),
                o = n(54872);
            let c = (0, l.createContext)(() => {});

            function d() {
                return (0, l.useContext)(c)
            }

            function u({
                children: e
            }) {
                let [t, n] = (0, l.useState)([]), i = (0, l.useRef)(1), a = (0, l.useCallback)(e => {
                    n(t => t.filter(t => t.id !== e))
                }, []), s = (0, l.useCallback)((e, t) => {
                    let r = i.current++;
                    n(n => [...n.slice(-2), {
                        id: r,
                        message: e,
                        ...t
                    }])
                }, []);
                return (0, r.jsxs)(c.Provider, {
                    value: s,
                    children: [e, (0, r.jsx)("div", {
                        "aria-live": "polite",
                        "aria-atomic": "false",
                        className: "pointer-events-none fixed inset-x-0 bottom-5 z-[70] flex flex-col items-center gap-2 px-4",
                        children: t.map(e => (0, r.jsx)(p, {
                            item: e,
                            onDismiss: a
                        }, e.id))
                    })]
                })
            }

            function p({
                item: e,
                onDismiss: t
            }) {
                let n = e.duration ? ? (e.action ? 6e3 : 4e3);
                return (0, l.useEffect)(() => {
                    let r = window.setTimeout(() => t(e.id), n);
                    return () => window.clearTimeout(r)
                }, [n, e.id, t]), (0, r.jsx)(m, {
                    message: e.message,
                    tone: e.tone,
                    action: e.action,
                    onDismiss: () => t(e.id)
                })
            }

            function m({
                message: e,
                tone: t = "default",
                action: n,
                onDismiss: l,
                className: c
            }) {
                return (0, r.jsxs)("div", {
                    role: "error" === t ? "alert" : "status",
                    className: (0, o.cn)("cp-anim-toast pointer-events-auto flex max-w-[min(440px,100%)] items-center gap-2.5 rounded-xl bg-cp-ink py-2.5 pr-2 pl-3.5 text-[13px] text-white shadow-cp-float", c),
                    children: ["error" === t ? (0, r.jsx)(i.A, {
                        className: "size-4 shrink-0 text-cp-danger",
                        strokeWidth: 1.75,
                        "aria-hidden": !0
                    }) : null, "success" === t ? (0, r.jsx)(a.A, {
                        className: "size-4 shrink-0 text-cp-success",
                        strokeWidth: 1.75,
                        "aria-hidden": !0
                    }) : null, (0, r.jsx)("span", {
                        className: "min-w-0 flex-1 leading-snug",
                        children: e
                    }), n ? (0, r.jsx)("button", {
                        type: "button",
                        onClick: () => {
                            n.onClick(), l ? .()
                        },
                        className: "shrink-0 rounded-md px-2 py-1 font-medium text-cp-lavender hover:bg-white/10",
                        children: n.label
                    }) : null, l ? (0, r.jsx)("button", {
                        type: "button",
                        onClick: l,
                        "aria-label": "Dismiss",
                        className: "shrink-0 rounded-md p-1 text-white/60 hover:bg-white/10 hover:text-white",
                        children: (0, r.jsx)(s.A, {
                            className: "size-3.5",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        })
                    }) : null]
                })
            }
        },
        17001: (e, t, n) => {
            n.d(t, {
                D0: () => c,
                N_: () => a,
                c8: () => s,
                pd: () => o
            });
            var r = n(73365),
                l = n(1521),
                i = n(54872);
            let a = (0, i.cn)("w-full min-w-0 rounded-lg border border-transparent bg-cp-subtle text-cp-ink outline-none", "transition-[background-color,border-color,box-shadow] duration-150 motion-reduce:transition-none", "placeholder:text-cp-faint hover:border-cp-line", "focus:border-cp-select focus:bg-cp-bg focus:ring-3 focus:ring-cp-select/15", "aria-invalid:border-cp-danger aria-invalid:focus:ring-cp-danger/15", "disabled:cursor-not-allowed disabled:text-cp-faint disabled:hover:border-transparent"),
                s = {
                    sm: "h-9 px-3 text-[13px]",
                    md: "h-11 px-3.5 text-[14px]"
                },
                o = l.forwardRef(({
                    className: e,
                    inputSize: t = "md",
                    invalid: n,
                    ...l
                }, o) => (0, r.jsx)("input", {
                    ref: o,
                    "aria-invalid": n || l["aria-invalid"] || void 0,
                    className: (0, i.cn)("flex", a, s[t], e),
                    ...l
                }));

            function c({
                label: e,
                htmlFor: t,
                hint: n,
                error: a,
                children: s,
                className: o
            }) {
                let d = a ? `${t}-error` : n ? `${t}-hint` : void 0,
                    u = d && l.isValidElement(s) ? l.cloneElement(s, {
                        "aria-describedby": s.props["aria-describedby"] ? ? d
                    }) : s;
                return (0, r.jsxs)("div", {
                    className: (0, i.cn)("flex flex-col gap-1.5", o),
                    children: [(0, r.jsx)("label", {
                        htmlFor: t,
                        className: "text-[12px] font-medium text-cp-ink",
                        children: e
                    }), u, a ? (0, r.jsx)("p", {
                        id: `${t}-error`,
                        className: "text-[12px] text-cp-danger-ink",
                        children: a
                    }) : n ? (0, r.jsx)("p", {
                        id: `${t}-hint`,
                        className: "text-[12px] text-cp-muted",
                        children: n
                    }) : null]
                })
            }
            o.displayName = "Input"
        },
        24656: (e, t, n) => {
            n.d(t, {
                Tooltip: () => a
            });
            var r = n(73365),
                l = n(1521),
                i = n(54872);

            function a({
                label: e,
                children: t,
                side: n = "top",
                delay: s = 400,
                defaultOpen: o = !1,
                className: c
            }) {
                let d = (0, l.useId)(),
                    [u, p] = (0, l.useState)(null),
                    m = (0, l.useRef)(null);
                (0, l.useEffect)(() => {
                    if (!u) return;
                    let e = e => {
                        "Escape" === e.key && p(null)
                    };
                    return document.addEventListener("keydown", e), () => document.removeEventListener("keydown", e)
                }, [u]), (0, l.useEffect)(() => () => {
                    m.current && clearTimeout(m.current)
                }, []);
                let x = (0, l.useCallback)((e, t) => {
                        m.current && clearTimeout(m.current), m.current = setTimeout(() => {
                            if (!e.isConnected) return;
                            let t = e.getBoundingClientRect();
                            p({
                                x: t.left + t.width / 2,
                                y: "bottom" === n ? t.bottom + 6 : t.top - 6
                            })
                        }, t)
                    }, [n]),
                    f = (0, l.useCallback)(() => {
                        m.current && clearTimeout(m.current), m.current = null, p(null)
                    }, []);
                if (!(0, l.isValidElement)(t)) return t;
                let b = t.props,
                    h = (0, l.cloneElement)(t, {
                        "aria-describedby": (0, i.cn)(b["aria-describedby"], d) || void 0,
                        onPointerEnter: e => {
                            b.onPointerEnter ? .(e), "touch" !== e.pointerType && x(e.currentTarget, s)
                        },
                        onPointerLeave: e => {
                            b.onPointerLeave ? .(e), f()
                        },
                        onPointerDown: e => {
                            b.onPointerDown ? .(e), f()
                        },
                        onFocus: e => {
                            b.onFocus ? .(e), e.currentTarget.matches(":focus-visible") && x(e.currentTarget, 0)
                        },
                        onBlur: e => {
                            b.onBlur ? .(e), f()
                        }
                    }),
                    v = "pointer-events-none z-[100] max-w-[220px] rounded-md bg-cp-ink px-2 py-1 text-center text-[12px] leading-[1.35] font-medium text-white shadow-cp-float";
                return o ? (0, r.jsxs)("span", {
                    className: "relative inline-flex",
                    children: [h, (0, r.jsx)("span", {
                        id: d,
                        role: "tooltip",
                        className: (0, i.cn)(v, "absolute left-1/2 w-max -translate-x-1/2", "top" === n ? "bottom-[calc(100%+6px)]" : "top-[calc(100%+6px)]", c),
                        children: e
                    })]
                }) : (0, r.jsxs)(r.Fragment, {
                    children: [h, (0, r.jsx)("span", {
                        id: d,
                        role: "tooltip",
                        hidden: !u,
                        className: (0, i.cn)(v, "fixed w-max", c),
                        style: u ? {
                            left: u.x,
                            top: u.y,
                            transform: `translateX(-50%)${"top"===n?" translateY(-100%)":""}`
                        } : void 0,
                        children: e
                    })]
                })
            }
        },
        28431: (e, t, n) => {
            n.d(t, {
                TabPanel: () => s,
                Tabs: () => a
            });
            var r = n(73365),
                l = n(1521),
                i = n(54872);

            function a({
                tabs: e,
                value: t,
                onChange: n,
                idBase: s,
                label: o,
                className: c
            }) {
                let d = (0, l.useRef)([]),
                    u = e.filter(e => !e.disabled);
                return (0, r.jsx)("div", {
                    role: "tablist",
                    "aria-label": o,
                    onKeyDown: function(r) {
                        if (!["ArrowRight", "ArrowLeft", "Home", "End"].includes(r.key) || 0 === u.length) return;
                        r.preventDefault();
                        let l = u.findIndex(e => e.value === t),
                            i = l;
                        "ArrowRight" === r.key && (i = (l + 1) % u.length), "ArrowLeft" === r.key && (i = (l - 1 + u.length) % u.length), "Home" === r.key && (i = 0), "End" === r.key && (i = u.length - 1);
                        let a = u[i];
                        n(a.value), d.current[e.indexOf(a)] ? .focus()
                    },
                    className: (0, i.cn)("no-scrollbar flex items-end gap-5 overflow-x-auto border-b border-cp-line", c),
                    children: e.map((e, l) => {
                        let a = e.value === t;
                        return (0, r.jsxs)("button", {
                            ref: e => {
                                d.current[l] = e
                            },
                            id: `${s}-tab-${e.value}`,
                            type: "button",
                            role: "tab",
                            "aria-selected": a,
                            "aria-controls": `${s}-panel-${e.value}`,
                            tabIndex: a ? 0 : -1,
                            disabled: e.disabled,
                            onClick: () => n(e.value),
                            className: (0, i.cn)("-mb-px inline-flex h-10 shrink-0 items-center gap-1.5 border-b-2 text-[14px] whitespace-nowrap transition-colors duration-150 motion-reduce:transition-none", "focus-visible:rounded-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", "disabled:cursor-not-allowed disabled:text-cp-faint", a ? "border-cp-primary font-medium text-cp-ink" : "border-transparent text-cp-muted hover:text-cp-ink"),
                            children: [e.label, "number" == typeof e.count ? (0, r.jsx)("span", {
                                className: (0, i.cn)("rounded-md px-1.5 text-[12px] leading-5 tabular-nums", a ? "bg-cp-primary-soft text-cp-primary" : "bg-cp-subtle text-cp-muted"),
                                children: e.count
                            }) : null]
                        }, e.value)
                    })
                })
            }

            function s({
                idBase: e,
                value: t,
                children: n,
                className: l
            }) {
                return (0, r.jsx)("div", {
                    role: "tabpanel",
                    id: `${e}-panel-${t}`,
                    "aria-labelledby": `${e}-tab-${t}`,
                    tabIndex: 0,
                    className: (0, i.cn)("outline-none focus-visible:outline-2 focus-visible:outline-cp-select", l),
                    children: n
                })
            }
        },
        31496: (e, t, n) => {
            n.d(t, {
                e: () => a
            });
            var r = n(73365),
                l = n(54872);
            let i = {
                sm: "size-6 text-[11px]",
                md: "size-8 text-[12px]",
                lg: "size-10 text-[14px]",
                xl: "size-14 text-[18px]"
            };

            function a({
                src: e,
                name: t,
                size: n = "md",
                className: s
            }) {
                let o = (0, l.cn)("inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full", i[n], s);
                return e ? (0, r.jsx)("img", {
                    src: e,
                    alt: t,
                    className: (0, l.cn)(o, "bg-cp-subtle object-cover"),
                    referrerPolicy: "no-referrer"
                }) : (0, r.jsx)("span", {
                    role: "img",
                    "aria-label": t,
                    className: (0, l.cn)(o, "bg-cp-primary-soft font-semibold text-cp-primary"),
                    children: (0, r.jsx)("span", {
                        "aria-hidden": !0,
                        children: function(e) {
                            let t = (e ? ? "").split("@")[0].trim();
                            if (!t) return "?";
                            let n = t.split(/[\s._-]+/).filter(Boolean);
                            return (n.length > 1 ? n[0][0] + n[n.length - 1][0] : n[0][0]).toUpperCase()
                        }(t)
                    })
                })
            }
        },
        32675: (e, t, n) => {
            n.d(t, {
                Dialog: () => s,
                DialogBody: () => o
            });
            var r = n(73365),
                l = n(1521),
                i = n(54872),
                a = n(56855);

            function s({
                open: e,
                onClose: t,
                labelledBy: n,
                label: o,
                children: c,
                className: d,
                initialFocus: u,
                size: p = "md"
            }) {
                let m = (0, l.useRef)(null);
                return ((0, a.V)({
                    open: e,
                    panelRef: m,
                    onClose: t,
                    initialFocus: u
                }), e) ? (0, r.jsxs)("div", {
                    className: "fixed inset-0 z-[100] flex items-center justify-center p-4",
                    children: [(0, r.jsx)("div", {
                        "aria-hidden": !0,
                        className: "cp-anim-fade absolute inset-0 bg-cp-ink/35 backdrop-blur-md",
                        onMouseDown: () => t()
                    }), (0, r.jsx)("div", {
                        ref: m,
                        role: "dialog",
                        "aria-modal": "true",
                        "aria-labelledby": n,
                        "aria-label": n ? void 0 : o,
                        tabIndex: -1,
                        className: (0, i.cn)("cp-anim-pop relative max-h-[calc(100dvh-2rem)] w-full overflow-y-auto rounded-2xl bg-cp-bg text-cp-ink shadow-cp-modal outline-none", "sm" === p && "max-w-sm", "md" === p && "max-w-md", "lg" === p && "max-w-2xl", d),
                        children: c
                    })]
                }) : null
            }

            function o({
                titleId: e,
                title: t,
                description: n,
                children: l,
                actions: a,
                className: s
            }) {
                return (0, r.jsxs)("div", {
                    className: (0, i.cn)("p-5", s),
                    children: [(0, r.jsx)("h2", {
                        id: e,
                        className: "text-[15px] font-semibold tracking-[-0.01em] text-cp-ink",
                        children: t
                    }), n ? (0, r.jsx)("p", {
                        className: "mt-1.5 text-[13px] leading-relaxed text-cp-muted",
                        children: n
                    }) : null, l ? (0, r.jsx)("div", {
                        className: "mt-4",
                        children: l
                    }) : null, a ? (0, r.jsx)("div", {
                        className: "mt-5 flex justify-end gap-2",
                        children: a
                    }) : null]
                })
            }
        },
        35770: (e, t, n) => {
            n.d(t, {
                p: () => i
            });
            var r = n(73365),
                l = n(54872);

            function i({
                icon: e,
                title: t,
                description: n,
                action: a,
                className: s,
                bordered: o = !0
            }) {
                return (0, r.jsxs)("div", {
                    className: (0, l.cn)("flex flex-col items-center justify-center px-6 py-12 text-center", o && "rounded-xl border border-dashed border-cp-line-strong", s),
                    children: [e ? (0, r.jsx)("span", {
                        className: "mb-3 flex size-10 items-center justify-center rounded-xl bg-cp-primary-soft text-cp-primary",
                        children: (0, r.jsx)(e, {
                            className: "size-4",
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        })
                    }) : null, (0, r.jsx)("p", {
                        className: "text-[15px] font-semibold text-cp-ink",
                        children: t
                    }), n ? (0, r.jsx)("p", {
                        className: "mt-1 max-w-sm text-[13px] leading-relaxed text-cp-muted",
                        children: n
                    }) : null, a ? (0, r.jsx)("div", {
                        className: "mt-4",
                        children: a
                    }) : null]
                })
            }
        },
        45158: (e, t, n) => {
            n.d(t, {
                E: () => i
            });
            var r = n(73365),
                l = n(54872);

            function i({
                className: e,
                rounded: t = "lg"
            }) {
                return (0, r.jsx)("div", {
                    "aria-hidden": !0,
                    "data-skeleton": !0,
                    className: (0, l.cn)("bg-cp-subtle motion-safe:animate-pulse", "md" === t && "rounded-md", "lg" === t && "rounded-lg", "xl" === t && "rounded-xl", "full" === t && "rounded-full", e)
                })
            }
        },
        47068: (e, t, n) => {
            n.d(t, {
                Sheet: () => s
            });
            var r = n(73365),
                l = n(1521),
                i = n(54872),
                a = n(56855);

            function s({
                open: e,
                onClose: t,
                labelledBy: n,
                label: o,
                side: c = "bottom",
                children: d,
                className: u,
                initialFocus: p
            }) {
                let m = (0, l.useRef)(null);
                return ((0, a.V)({
                    open: e,
                    panelRef: m,
                    onClose: t,
                    initialFocus: p
                }), e) ? (0, r.jsxs)("div", {
                    className: "fixed inset-0 z-[100]",
                    children: [(0, r.jsx)("div", {
                        "aria-hidden": !0,
                        className: "cp-anim-fade absolute inset-0 bg-cp-ink/35 backdrop-blur-md",
                        onMouseDown: () => t()
                    }), (0, r.jsxs)("div", {
                        ref: m,
                        role: "dialog",
                        "aria-modal": "true",
                        "aria-labelledby": n,
                        "aria-label": n ? void 0 : o,
                        tabIndex: -1,
                        "data-side": c,
                        className: (0, i.cn)("absolute flex flex-col overflow-y-auto bg-cp-bg text-cp-ink shadow-cp-modal outline-none", "bottom" === c && "cp-anim-sheet-up inset-x-0 bottom-0 max-h-[85dvh] rounded-t-2xl pb-[max(1rem,env(safe-area-inset-bottom))]", "right" === c && "cp-anim-sheet-left inset-y-0 right-0 w-full max-w-md", u),
                        children: ["bottom" === c ? (0, r.jsx)("div", {
                            "aria-hidden": !0,
                            className: "mx-auto mt-2 mb-1 h-1 w-9 shrink-0 rounded-full bg-cp-line-strong"
                        }) : null, d]
                    })]
                }) : null
            }
        },
        53445: (e, t, n) => {
            n.d(t, {
                T: () => s
            });
            var r = n(73365),
                l = n(1521),
                i = n(54872),
                a = n(17001);
            let s = l.forwardRef(({
                className: e,
                invalid: t,
                ...n
            }, l) => (0, r.jsx)("textarea", {
                ref: l,
                "aria-invalid": t || n["aria-invalid"] || void 0,
                className: (0, i.cn)("flex min-h-28 px-3.5 py-2.5 text-[14px] leading-relaxed", a.N_, e),
                ...n
            }));
            s.displayName = "Textarea"
        },
        56224: (e, t, n) => {
            n.d(t, {
                E: () => i
            });
            var r = n(73365),
                l = n(54872);

            function i({
                className: e,
                children: t,
                variant: n = "default",
                tone: a,
                dot: s = !1
            }) {
                return a ? (0, r.jsxs)("span", {
                    "data-slot": "badge",
                    className: (0, l.cn)("inline-flex h-5 items-center gap-1 rounded-md px-1.5 text-[12px] leading-none font-medium whitespace-nowrap", {
                        neutral: "bg-cp-subtle text-cp-muted",
                        primary: "bg-cp-primary-soft text-cp-primary",
                        success: "bg-cp-success/10 text-cp-success-ink",
                        warning: "bg-cp-warning/15 text-cp-warning-ink",
                        danger: "bg-cp-danger/10 text-cp-danger-ink"
                    }[a], e),
                    children: [s ? (0, r.jsx)("span", {
                        "aria-hidden": !0,
                        className: "size-1.5 rounded-full bg-current"
                    }) : null, t]
                }) : (0, r.jsx)("span", {
                    className: (0, l.cn)("inline-flex items-center rounded-full px-3 py-1 text-xs font-medium tracking-[0.16em] uppercase", {
                        default: "border border-cp-line bg-cp-bg/70 text-cp-muted",
                        accent: "border border-cp-primary/20 bg-cp-primary-soft text-cp-primary",
                        dark: "border border-white/10 bg-white/10 text-white/90",
                        outline: "border border-cp-primary text-cp-primary"
                    }[n], e),
                    children: t
                })
            }
        },
        56855: (e, t, n) => {
            n.d(t, {
                V: () => i,
                a: () => l
            });
            var r = n(1521);

            function l(e) {
                return Array.from(e.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')).filter(e => !e.closest("[inert]") && e.getClientRects().length > 0)
            }

            function i({
                open: e,
                panelRef: t,
                onClose: n,
                initialFocus: a
            }) {
                let s = (0, r.useEffectEvent)(() => n());
                (0, r.useEffect)(() => {
                    if (!e) return;
                    let n = t.current;
                    if (!n) return;
                    let r = document.activeElement;
                    ("self" === a ? n : (a ? n.querySelector(a) : null) ? ? l(n)[0] ? ? n).focus({
                        preventScroll: !0
                    });
                    let i = document.documentElement,
                        o = i.style.overflow,
                        c = i.style.paddingRight,
                        d = window.innerWidth - i.clientWidth;

                    function u(e) {
                        if ("Escape" === e.key) {
                            e.stopPropagation(), s();
                            return
                        }
                        if ("Tab" !== e.key || !n) return;
                        let t = l(n);
                        if (0 === t.length) {
                            e.preventDefault(), n.focus();
                            return
                        }
                        let r = t[0],
                            i = t[t.length - 1],
                            a = document.activeElement;
                        e.shiftKey && (a === r || !n.contains(a)) ? (e.preventDefault(), i.focus()) : e.shiftKey || a !== i && n.contains(a) || (e.preventDefault(), r.focus())
                    }
                    return i.style.overflow = "hidden", d > 0 && (i.style.paddingRight = `${d}px`), document.addEventListener("keydown", u), () => {
                        document.removeEventListener("keydown", u), i.style.overflow = o, i.style.paddingRight = c, r ? .focus ? .({
                            preventScroll: !0
                        })
                    }
                }, [e, a, t])
            }
        },
        68069: (e, t, n) => {
            n.d(t, {
                Segmented: () => a
            });
            var r = n(73365),
                l = n(1521),
                i = n(54872);

            function a({
                options: e,
                value: t,
                onChange: n,
                label: s,
                size: o = "md",
                className: c
            }) {
                let d = (0, l.useRef)([]),
                    u = e.filter(e => !e.disabled);
                return (0, r.jsx)("div", {
                    role: "radiogroup",
                    "aria-label": s,
                    onKeyDown: function(r) {
                        if (!["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp", "Home", "End"].includes(r.key) || 0 === u.length) return;
                        r.preventDefault();
                        let l = u.findIndex(e => e.value === t),
                            i = l;
                        ("ArrowRight" === r.key || "ArrowDown" === r.key) && (i = (l + 1) % u.length), ("ArrowLeft" === r.key || "ArrowUp" === r.key) && (i = (l - 1 + u.length) % u.length), "Home" === r.key && (i = 0), "End" === r.key && (i = u.length - 1);
                        let a = u[i];
                        n(a.value), d.current[e.indexOf(a)] ? .focus()
                    },
                    className: (0, i.cn)("inline-flex items-stretch rounded-lg bg-cp-subtle p-0.5", "md" === o ? "h-9" : "h-8", c),
                    children: e.map((e, l) => {
                        let a = e.value === t;
                        return (0, r.jsx)("button", {
                            ref: e => {
                                d.current[l] = e
                            },
                            type: "button",
                            role: "radio",
                            "aria-checked": a,
                            "aria-label": e.ariaLabel,
                            disabled: e.disabled,
                            tabIndex: a ? 0 : -1,
                            onClick: () => n(e.value),
                            className: (0, i.cn)("flex flex-1 items-center justify-center gap-1.5 rounded-md px-3 text-[13px] whitespace-nowrap transition-colors duration-150 motion-reduce:transition-none", "focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-cp-select", "disabled:cursor-not-allowed disabled:text-cp-faint", a ? "bg-cp-bg font-medium text-cp-ink shadow-[0_1px_2px_rgba(20,12,60,0.08)]" : "text-cp-muted hover:text-cp-ink"),
                            children: e.label
                        }, e.value)
                    })
                })
            }
        },
        74511: (e, t, n) => {
            n.d(t, {
                Switch: () => a
            });
            var r = n(73365),
                l = n(1521),
                i = n(54872);
            let a = l.forwardRef(function({
                checked: e,
                onCheckedChange: t,
                label: n,
                size: a = "md",
                disabled: s,
                className: o,
                id: c,
                ...d
            }, u) {
                let p = l.useId(),
                    m = c ? ? p,
                    x = (0, r.jsx)("button", {
                        ref: u,
                        id: m,
                        type: "button",
                        role: "switch",
                        "aria-checked": e,
                        disabled: s,
                        onClick: () => t ? .(!e),
                        className: (0, i.cn)("relative inline-flex shrink-0 cursor-pointer items-center rounded-full transition-colors duration-150 motion-reduce:transition-none", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", "disabled:cursor-not-allowed disabled:opacity-50", "md" === a ? "h-6 w-10" : "h-5 w-8", e ? "bg-cp-primary" : "bg-cp-line-strong", !n && o),
                        ...d,
                        children: (0, r.jsx)("span", {
                            "aria-hidden": !0,
                            className: (0, i.cn)("absolute left-0.5 rounded-full bg-cp-bg shadow-[0_1px_2px_rgba(20,12,60,0.2)] transition-transform duration-150 motion-reduce:transition-none", "md" === a ? "size-5" : "size-4", e && ("md" === a ? "translate-x-4" : "translate-x-3"))
                        })
                    });
                return n ? (0, r.jsxs)("span", {
                    className: (0, i.cn)("inline-flex items-center gap-2.5", o),
                    children: [x, (0, r.jsx)("label", {
                        htmlFor: m,
                        className: "cursor-pointer text-[13px] text-cp-ink",
                        children: n
                    })]
                }) : x
            })
        },
        87404: (e, t, n) => {
            n.d(t, {
                Ex: () => r.E,
                $n: () => l.$,
                Zp: () => i.Zp,
                lG: () => a.Dialog,
                pp: () => s.p,
                D0: () => o.D0,
                pd: () => o.pd,
                $q: () => c.Segmented,
                l6: () => d.l,
                cj: () => u.Sheet,
                EA: () => p.E,
                dO: () => m.Switch,
                Kp: () => x.TabPanel,
                tU: () => x.Tabs,
                TM: () => f.T
            }), n(31496);
            var r = n(56224),
                l = n(9388),
                i = n(45421);
            n(73365);
            var a = n(32675),
                s = n(35770),
                o = n(17001);
            n(99438);
            var c = n(68069),
                d = n(87583),
                u = n(47068);
            n(99568);
            var p = n(45158),
                m = n(74511),
                x = n(28431),
                f = n(53445);
            n(13384), n(24656)
        },
        87583: (e, t, n) => {
            n.d(t, {
                l: () => o
            });
            var r = n(73365),
                l = n(1521),
                i = n(39255),
                a = n(54872),
                s = n(17001);
            let o = l.forwardRef(({
                className: e,
                inputSize: t = "md",
                invalid: n,
                children: l,
                ...o
            }, c) => (0, r.jsxs)("span", {
                className: (0, a.cn)("relative inline-flex w-full", e),
                children: [(0, r.jsx)("select", {
                    ref: c,
                    "aria-invalid": n || o["aria-invalid"] || void 0,
                    className: (0, a.cn)(s.N_, s.c8[t], "cursor-pointer appearance-none pr-9"),
                    ...o,
                    children: l
                }), (0, r.jsx)(i.A, {
                    "aria-hidden": !0,
                    strokeWidth: 1.75,
                    className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-cp-muted"
                })]
            }));
            o.displayName = "Select"
        },
        99438: (e, t, n) => {
            n.d(t, {
                Menu: () => o,
                MenuItem: () => u,
                MenuLabel: () => x,
                MenuRadioItem: () => p,
                MenuSeparator: () => m
            });
            var r = n(73365),
                l = n(1521),
                i = n(26821),
                a = n(54872);
            let s = (0, l.createContext)({
                close: () => {}
            });

            function o({
                trigger: e,
                children: t,
                align: n = "start",
                className: i,
                menuClassName: d,
                label: u,
                defaultOpen: p = !1
            }) {
                let [m, x] = (0, l.useState)(p), f = (0, l.useRef)(null), b = (0, l.useRef)(null), h = (0, l.useRef)(null), v = (0, l.useId)(), g = (0, l.useRef)(!1), w = (0, l.useCallback)((e = !0) => {
                    x(!1), e && b.current ? .focus({
                        preventScroll: !0
                    })
                }, []);
                return (0, l.useEffect)(() => {
                    if (m) return g.current ? c(h.current)[0] ? .focus({
                        preventScroll: !0
                    }) : p || h.current ? .focus({
                        preventScroll: !0
                    }), document.addEventListener("pointerdown", e, !0), document.addEventListener("keydown", t), () => {
                        document.removeEventListener("pointerdown", e, !0), document.removeEventListener("keydown", t)
                    };

                    function e(e) {
                        f.current ? .contains(e.target) || w(!1)
                    }

                    function t(e) {
                        "Escape" === e.key && (e.stopPropagation(), w())
                    }
                }, [m, w, p]), (0, r.jsxs)("div", {
                    ref: f,
                    className: (0, a.cn)("relative inline-block", i),
                    children: [e({
                        ref: b,
                        onClick: e => {
                            g.current = 0 === e.detail, x(!m)
                        },
                        "aria-haspopup": "menu",
                        "aria-expanded": m,
                        "aria-controls": m ? v : void 0
                    }, m), m ? (0, r.jsx)(s.Provider, {
                        value: {
                            close: w
                        },
                        children: (0, r.jsx)("div", {
                            ref: h,
                            id: v,
                            role: "menu",
                            "aria-label": u,
                            tabIndex: -1,
                            onKeyDown: function(e) {
                                let t = c(h.current);
                                if (0 === t.length) return;
                                let n = t.indexOf(document.activeElement),
                                    r = null;
                                if ("ArrowDown" === e.key) r = (n + 1) % t.length;
                                else if ("ArrowUp" === e.key) r = (n - 1 + t.length) % t.length;
                                else if ("Home" === e.key) r = 0;
                                else if ("End" === e.key) r = t.length - 1;
                                else if ("Tab" === e.key) return void w(!1);
                                null !== r && (e.preventDefault(), t[r] ? .focus())
                            },
                            className: (0, a.cn)("cp-anim-menu absolute top-[calc(100%+6px)] z-40 min-w-[200px] rounded-xl border border-cp-line bg-cp-bg p-1 shadow-cp-float outline-none", "end" === n ? "right-0 origin-top-right" : "left-0 origin-top-left", d),
                            children: t
                        })
                    }) : null]
                })
            }

            function c(e) {
                return e ? Array.from(e.querySelectorAll('[role="menuitem"]:not([aria-disabled="true"]), [role="menuitemradio"]')) : []
            }
            let d = "flex h-8 w-full items-center gap-2.5 rounded-md px-2.5 text-left text-[13px] outline-none transition-colors duration-100 hover:bg-cp-subtle focus-visible:bg-cp-subtle";

            function u({
                icon: e,
                children: t,
                onSelect: n,
                tone: i = "default",
                disabled: o = !1,
                hint: c
            }) {
                let {
                    close: p
                } = (0, l.useContext)(s);
                return (0, r.jsxs)("button", {
                    type: "button",
                    role: "menuitem",
                    tabIndex: -1,
                    "aria-disabled": o || void 0,
                    onClick: () => {
                        o || (p(!0), n())
                    },
                    className: (0, a.cn)(d, "danger" === i ? "text-cp-danger-ink" : "text-cp-ink", o && "cursor-not-allowed text-cp-faint hover:bg-transparent"),
                    children: [e ? (0, r.jsx)(e, {
                        className: (0, a.cn)("size-4 shrink-0", "danger" === i ? "" : "text-cp-muted"),
                        strokeWidth: 1.75,
                        "aria-hidden": !0
                    }) : null, (0, r.jsx)("span", {
                        className: "min-w-0 flex-1 truncate",
                        children: t
                    }), c ? (0, r.jsx)("span", {
                        className: "shrink-0 text-[12px] text-cp-faint",
                        children: c
                    }) : null]
                })
            }

            function p({
                checked: e,
                children: t,
                onSelect: n
            }) {
                let {
                    close: o
                } = (0, l.useContext)(s);
                return (0, r.jsxs)("button", {
                    type: "button",
                    role: "menuitemradio",
                    "aria-checked": e,
                    tabIndex: -1,
                    onClick: () => {
                        n(), o()
                    },
                    className: (0, a.cn)(d, "text-cp-ink"),
                    children: [(0, r.jsx)("span", {
                        className: "min-w-0 flex-1 truncate",
                        children: t
                    }), (0, r.jsx)(i.A, {
                        className: (0, a.cn)("size-4 shrink-0", e ? "text-cp-primary" : "invisible"),
                        strokeWidth: 1.75,
                        "aria-hidden": !0
                    })]
                })
            }

            function m() {
                return (0, r.jsx)("div", {
                    role: "separator",
                    className: "mx-1 my-1 h-px bg-cp-line"
                })
            }

            function x({
                children: e
            }) {
                return (0, r.jsx)("div", {
                    className: "truncate px-2.5 pt-1.5 pb-1 text-[12px] text-cp-muted",
                    role: "presentation",
                    children: e
                })
            }
        }
    }
]);