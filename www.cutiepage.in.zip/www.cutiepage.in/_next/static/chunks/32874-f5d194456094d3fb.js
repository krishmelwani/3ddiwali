"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [32874], {
        82055: (e, a, t) => {
            t.d(a, {
                JQ: () => r,
                K2: () => c,
                Wo: () => p,
                dP: () => d,
                iP: () => i,
                kq: () => s,
                qu: () => o,
                sD: () => n
            });
            let i = {
                    width: 1080,
                    height: 1920,
                    previewWidth: 540,
                    previewHeight: 960,
                    fps: 30,
                    bitrate: 4e6,
                    avcCodecs: ["avc1.640028", "avc1.4d0028"],
                    beats: 7,
                    maxPhotos: 7,
                    photoMaxPx: 1440
                },
                o = "video",
                r = ["photo1", "photo2", "photo3", "photo4", "photo5", "photo6", "photo7"],
                n = {
                    base: "https://cdn.cutiepage.in/static/mini-videos",
                    music: e => `https://cdn.cutiepage.in/static/mini-videos/${e}/music-v1.m4a`,
                    art: (e, a) => `https://cdn.cutiepage.in/static/mini-videos/${e}/art/${a}-v1.webp`,
                    sample: e => `https://cdn.cutiepage.in/static/mini-videos/${e}/sample-v1.mp4`
                },
                s = 24;
            class p extends Error {
                constructor(e, a) {
                    super(e), this.name = "VideoExportError", this.stage = a
                }
            }
            let d = [{
                key: "cp-vid-diye",
                stem: "diye",
                exportName: "cpVidDiyeTemplate",
                name: "Diwali Diyas",
                category: "Festival"
            }, {
                key: "cp-vid-diwali-raat",
                stem: "diwali-raat",
                exportName: "cpVidDiwaliRaatTemplate",
                name: "Diwali Lanterns",
                category: "Festival"
            }, {
                key: "cp-vid-diwali-rangoli",
                stem: "diwali-rangoli",
                exportName: "cpVidDiwaliRangoliTemplate",
                name: "Diwali Rangoli",
                category: "Festival"
            }, {
                key: "cp-vid-diwali-fireworks",
                stem: "diwali-fireworks",
                exportName: "cpVidDiwaliFireworksTemplate",
                name: "Diwali Fireworks",
                category: "Festival"
            }, {
                key: "cp-vid-diwali-mithai",
                stem: "diwali-mithai",
                exportName: "cpVidDiwaliMithaiTemplate",
                name: "Diwali Mithai Box",
                category: "Festival"
            }, {
                key: "cp-vid-diwali-toran",
                stem: "diwali-toran",
                exportName: "cpVidDiwaliToranTemplate",
                name: "Diwali Door Toran",
                category: "Festival"
            }, {
                key: "cp-vid-diwali-family",
                stem: "diwali-family",
                exportName: "cpVidDiwaliFamilyTemplate",
                name: "Diwali Family Album",
                category: "Festival"
            }, {
                key: "cp-vid-diwali-golden",
                stem: "diwali-golden",
                exportName: "cpVidDiwaliGoldenTemplate",
                name: "Diwali Golden Glow",
                category: "Festival"
            }, {
                key: "cp-vid-tilak",
                stem: "tilak",
                exportName: "cpVidTilakTemplate",
                name: "Bhai Dooj Tilak",
                category: "Family"
            }, {
                key: "cp-vid-bachpan",
                stem: "bachpan",
                exportName: "cpVidBachpanTemplate",
                name: "Bhai Dooj Then & Now",
                category: "Family"
            }, {
                key: "cp-vid-bhaidooj-fights",
                stem: "bhaidooj-fights",
                exportName: "cpVidBhaidoojFightsTemplate",
                name: "Bhai Dooj Sibling Fights",
                category: "Family"
            }, {
                key: "cp-vid-bhaidooj-gift",
                stem: "bhaidooj-gift",
                exportName: "cpVidBhaidoojGiftTemplate",
                name: "Bhai Dooj Gift Hamper",
                category: "Family"
            }, {
                key: "cp-vid-bhaidooj-games",
                stem: "bhaidooj-games",
                exportName: "cpVidBhaidoojGamesTemplate",
                name: "Bhai Dooj Childhood Games",
                category: "Family"
            }, {
                key: "cp-vid-bhaidooj-letter",
                stem: "bhaidooj-letter",
                exportName: "cpVidBhaidoojLetterTemplate",
                name: "Bhai Dooj Letter",
                category: "Family"
            }, {
                key: "cp-vid-bday-cake",
                stem: "bday-cake",
                exportName: "cpVidBdayCakeTemplate",
                name: "Birthday Cake & Candles",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-balloons",
                stem: "bday-balloons",
                exportName: "cpVidBdayBalloonsTemplate",
                name: "Birthday Balloons",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-gift",
                stem: "bday-gift",
                exportName: "cpVidBdayGiftTemplate",
                name: "Birthday Gift Box",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-party",
                stem: "bday-party",
                exportName: "cpVidBdayPartyTemplate",
                name: "Birthday Party Lights",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-confetti",
                stem: "bday-confetti",
                exportName: "cpVidBdayConfettiTemplate",
                name: "Birthday Confetti Pop",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-stars",
                stem: "bday-stars",
                exportName: "cpVidBdayStarsTemplate",
                name: "Birthday Starry Wish",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-countdown",
                stem: "bday-countdown",
                exportName: "cpVidBdayCountdownTemplate",
                name: "Birthday Countdown",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-memories",
                stem: "bday-memories",
                exportName: "cpVidBdayMemoriesTemplate",
                name: "Birthday Memory Wall",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-bestie",
                stem: "bday-bestie",
                exportName: "cpVidBdayBestieTemplate",
                name: "Birthday Bestie",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-maa",
                stem: "bday-maa",
                exportName: "cpVidBdayMaaTemplate",
                name: "Birthday for Maa",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-cupcakes",
                stem: "bday-cupcakes",
                exportName: "cpVidBdayCupcakesTemplate",
                name: "Birthday Cupcakes",
                category: "Birthday"
            }, {
                key: "cp-vid-bday-trailer",
                stem: "bday-trailer",
                exportName: "cpVidBdayTrailerTemplate",
                name: "Birthday Movie Trailer",
                category: "Birthday"
            }, {
                key: "cp-vid-safar",
                stem: "safar",
                exportName: "cpVidSafarTemplate",
                name: "Anniversary Polaroids",
                category: "Anniversary"
            }, {
                key: "cp-vid-film",
                stem: "film",
                exportName: "cpVidFilmTemplate",
                name: "Anniversary Love Film",
                category: "Anniversary"
            }, {
                key: "cp-vid-anni-roses",
                stem: "anni-roses",
                exportName: "cpVidAnniRosesTemplate",
                name: "Anniversary Roses",
                category: "Anniversary"
            }, {
                key: "cp-vid-anni-letters",
                stem: "anni-letters",
                exportName: "cpVidAnniLettersTemplate",
                name: "Anniversary Love Letters",
                category: "Anniversary"
            }, {
                key: "cp-vid-anni-our-song",
                stem: "anni-our-song",
                exportName: "cpVidAnniOurSongTemplate",
                name: "Anniversary Our Song",
                category: "Anniversary"
            }, {
                key: "cp-vid-anni-stars",
                stem: "anni-stars",
                exportName: "cpVidAnniStarsTemplate",
                name: "Anniversary Under the Stars",
                category: "Anniversary"
            }, {
                key: "cp-vid-anni-ring",
                stem: "anni-ring",
                exportName: "cpVidAnniRingTemplate",
                name: "Anniversary Ring Box",
                category: "Anniversary"
            }, {
                key: "cp-vid-anni-rainy-date",
                stem: "anni-rainy-date",
                exportName: "cpVidAnniRainyDateTemplate",
                name: "Anniversary Rainy Date",
                category: "Anniversary"
            }, {
                key: "cp-vid-cute-teddy",
                stem: "cute-teddy",
                exportName: "cpVidCuteTeddyTemplate",
                name: "Cute Teddy Hug",
                category: "Love"
            }, {
                key: "cp-vid-cute-hearts",
                stem: "cute-hearts",
                exportName: "cpVidCuteHeartsTemplate",
                name: "Cute Hearts Rain",
                category: "Love"
            }, {
                key: "cp-vid-cute-reasons",
                stem: "cute-reasons",
                exportName: "cpVidCuteReasonsTemplate",
                name: "Cute Reasons I Love You",
                category: "Love"
            }, {
                key: "cp-vid-cute-kitty",
                stem: "cute-kitty",
                exportName: "cpVidCuteKittyTemplate",
                name: "Cute Kitty Love",
                category: "Love"
            }, {
                key: "cp-vid-cute-proposal",
                stem: "cute-proposal",
                exportName: "cpVidCuteProposalTemplate",
                name: "Cute Will You Be Mine",
                category: "Love"
            }, {
                key: "cp-vid-cute-miss-you",
                stem: "cute-miss-you",
                exportName: "cpVidCuteMissYouTemplate",
                name: "Cute Miss You",
                category: "Love"
            }, {
                key: "cp-vid-cute-love-meter",
                stem: "cute-love-meter",
                exportName: "cpVidCuteLoveMeterTemplate",
                name: "Cute Love Meter",
                category: "Love"
            }, {
                key: "cp-vid-cute-bouquet",
                stem: "cute-bouquet",
                exportName: "cpVidCuteBouquetTemplate",
                name: "Cute Flower Bouquet",
                category: "Love"
            }, {
                key: "cp-vid-cute-moon",
                stem: "cute-moon",
                exportName: "cpVidCuteMoonTemplate",
                name: "Cute Moon & Stars",
                category: "Love"
            }, {
                key: "cp-vid-cute-scrapbook",
                stem: "cute-scrapbook",
                exportName: "cpVidCuteScrapbookTemplate",
                name: "Cute Scrapbook",
                category: "Love"
            }, {
                key: "cp-vid-sorry-ears",
                stem: "sorry-ears",
                exportName: "cpVidSorryEarsTemplate",
                name: "Sorry Kaan Pakad Ke",
                category: "Apology"
            }, {
                key: "cp-vid-sorry-coupons",
                stem: "sorry-coupons",
                exportName: "cpVidSorryCouponsTemplate",
                name: "Sorry Forgive Me Coupons",
                category: "Apology"
            }, {
                key: "cp-vid-sorry-puppy",
                stem: "sorry-puppy",
                exportName: "cpVidSorryPuppyTemplate",
                name: "Sorry Puppy Eyes",
                category: "Apology"
            }, {
                key: "cp-vid-sorry-flowers",
                stem: "sorry-flowers",
                exportName: "cpVidSorryFlowersTemplate",
                name: "Sorry Flowers",
                category: "Apology"
            }, {
                key: "cp-vid-sorry-letter",
                stem: "sorry-letter",
                exportName: "cpVidSorryLetterTemplate",
                name: "Sorry Letter",
                category: "Apology"
            }, {
                key: "cp-vid-sorry-rainbow",
                stem: "sorry-rainbow",
                exportName: "cpVidSorryRainbowTemplate",
                name: "Sorry Rain to Rainbow",
                category: "Apology"
            }];

            function c(e) {
                return "string" == typeof e && e.startsWith("cp-vid-")
            }
        },
        95928: (e, a, t) => {
            t.d(a, {
                AT: () => p,
                Bp: () => n,
                fs: () => r,
                gp: () => o,
                kB: () => d,
                ne: () => s,
                pG: () => c,
                vV: () => m,
                zi: () => i
            });
            let i = {
                    cta: "Send invite \xb7 {price}",
                    ctaNoPrice: "Send invite",
                    offerSingle: "Pay only {price}",
                    offerInvite: "{price} for {count} guests \xb7 {unlimited} unlimited",
                    offerFree: "Free",
                    explainerInvite: "{count} pages, one for each guest, all unlocked by this one payment.",
                    explainerSingle: "One page, yours to share anywhere.",
                    explainerClosed: "This invite opens soon. Your design stays saved on this device.",
                    loading: "This invite opens soon.",
                    saved: "Saved on this device",
                    didNotFit: "Your photos didn't fit on this device",
                    didNotFitNotice: "Your photos didn't fit on this device. Try fewer or smaller photos, then try again.",
                    claimFailed: "We couldn't save your invite to your account. Check your connection and try again.",
                    retry: "Try again",
                    advancedHint: "Open the Advanced editor to edit every word and photo.",
                    modeLabel: "Editor",
                    modeSimple: "Simple editor",
                    modeAdvanced: "Advanced editor",
                    previewLabel: "Live preview of your {name}",
                    signIn: {
                        title: "Sign in to send your invite",
                        description: "Your invite stays right here. Sign in with Google and you come straight back to this editor to pay and make it live.",
                        footnote: "Secure sign-in"
                    },
                    guestNames: {
                        title: "Who are you inviting?",
                        count: "{count} of {max}",
                        hint: "Up to {max} names, separated by commas. Each guest gets their own page with their name on it. Leave it blank to add names later.",
                        paid: " All {max} unlock for {price}.",
                        inputLabel: "Guest names, separated by commas",
                        placeholder: "Riya, Aman, Neha",
                        tooLong: "Keep each name under {max} characters.",
                        tooMany: "Up to {max} names, one page each."
                    },
                    plans: {
                        label: "Choose your invite",
                        unlimitedTitle: "Unlimited guests",
                        limitedTitle: "Up to {count} guests",
                        unlimitedDetail: "A personal link for everyone you invite.",
                        limitedDetail: "{count} personal links, each greeting a guest by name."
                    }
                },
                o = {
                    lang: "bn",
                    cta: "\u09b2\u09be\u0987\u09ad \u0995\u09b0\u09cb \xb7 {price}",
                    ctaNoPrice: "\u09b2\u09be\u0987\u09ad \u0995\u09b0\u09cb",
                    offerSingle: "\u09ae\u09be\u09a4\u09cd\u09b0 {price}",
                    offerInvite: "{count} \u099c\u09a8 \u0985\u09a4\u09bf\u09a5\u09bf {price} \xb7 \u09af\u09a4 \u0996\u09c1\u09b6\u09bf {unlimited}",
                    offerFree: "\u09ac\u09bf\u09a8\u09be\u09ae\u09c2\u09b2\u09cd\u09af\u09c7",
                    saved: "\u098f\u0987 \u09ab\u09cb\u09a8\u09c7 \u09b8\u09c7\u09ad \u09b9\u09af\u09bc\u09c7\u099b\u09c7 \u2713",
                    didNotFit: "\u099b\u09ac\u09bf\u0997\u09c1\u09b2\u09cb \u098f\u0987 \u09ab\u09cb\u09a8\u09c7 \u0986\u0981\u099f\u09b2 \u09a8\u09be",
                    didNotFitNotice: "\u099b\u09ac\u09bf\u0997\u09c1\u09b2\u09cb \u098f\u0987 \u09ab\u09cb\u09a8\u09c7 \u0986\u0981\u099f\u09b2 \u09a8\u09be\u0964 \u0995\u09ae \u09ac\u09be \u099b\u09cb\u099f \u099b\u09ac\u09bf \u09a6\u09bf\u09af\u09bc\u09c7 \u0986\u09ac\u09be\u09b0 \u099a\u09c7\u09b7\u09cd\u099f\u09be \u0995\u09b0\u09cb\u0964",
                    claimFailed: "\u09a4\u09cb\u09ae\u09be\u09b0 \u09a1\u09bf\u099c\u09be\u0987\u09a8\u099f\u09be \u0985\u09cd\u09af\u09be\u0995\u09be\u0989\u09a8\u09cd\u099f\u09c7 \u09b8\u09c7\u09ad \u0995\u09b0\u09be \u0997\u09c7\u09b2 \u09a8\u09be\u0964 \u0987\u09a8\u09cd\u099f\u09be\u09b0\u09a8\u09c7\u099f \u09a6\u09c7\u0996\u09c7 \u0986\u09ac\u09be\u09b0 \u099a\u09c7\u09b7\u09cd\u099f\u09be \u0995\u09b0\u09cb\u0964",
                    retry: "\u0986\u09ac\u09be\u09b0 \u099a\u09c7\u09b7\u09cd\u099f\u09be \u0995\u09b0\u09cb",
                    advancedHint: "\u09b8\u09ac \u09b2\u09c7\u0996\u09be \u0986\u09b0 \u099b\u09ac\u09bf \u09ac\u09a6\u09b2\u09be\u09a4\u09c7 Advanced \u0996\u09cb\u09b2\u09cb\u0964",
                    modeLabel: "\u098f\u09a1\u09bf\u099f\u09b0",
                    modeSimple: "\u09b8\u09b9\u099c \xb7 Simple",
                    modeAdvanced: "\u09b8\u09ac \u0995\u09bf\u099b\u09c1 \xb7 Advanced",
                    previewLabel: "{name}: \u09b2\u09be\u0987\u09ad \u09aa\u09cd\u09b0\u09bf\u09ad\u09bf\u0989",
                    signIn: {
                        title: "\u09b2\u09be\u0987\u09ad \u0995\u09b0\u09a4\u09c7 \u09b8\u09be\u0987\u09a8 \u0987\u09a8 \u0995\u09b0\u09cb",
                        description: "\u09a4\u09cb\u09ae\u09be\u09b0 \u09a1\u09bf\u099c\u09be\u0987\u09a8 \u098f\u0996\u09be\u09a8\u09c7\u0987 \u09a5\u09be\u0995\u09ac\u09c7\u0964 Google \u09a6\u09bf\u09af\u09bc\u09c7 \u09b8\u09be\u0987\u09a8 \u0987\u09a8 \u0995\u09b0\u09b2\u09c7\u0987 \u098f\u0987 \u098f\u09a1\u09bf\u099f\u09b0\u09c7 \u09ab\u09bf\u09b0\u09c7 \u0986\u09b8\u09ac\u09c7, \u09a4\u09be\u09b0\u09aa\u09b0 \u09aa\u09c7\u09ae\u09c7\u09a8\u09cd\u099f \u0986\u09b0 \u09b2\u09be\u0987\u09ad\u0964",
                        footnote: "\u09a8\u09bf\u09b0\u09be\u09aa\u09a6 \u09b8\u09be\u0987\u09a8 \u0987\u09a8"
                    },
                    guestNames: {
                        title: "\u0995\u09be\u0995\u09c7 \u0995\u09be\u0995\u09c7 \u09a8\u09bf\u09ae\u09a8\u09cd\u09a4\u09cd\u09b0\u09a3? \xb7 Guests",
                        count: "{count}/{max}",
                        hint: "\u0995\u09ae\u09be \u09a6\u09bf\u09af\u09bc\u09c7 \u0986\u09b2\u09be\u09a6\u09be \u0995\u09b0\u09c7 {max} \u099c\u09a8 \u09aa\u09b0\u09cd\u09af\u09a8\u09cd\u09a4 \u09a8\u09be\u09ae \u09b2\u09c7\u0996\u09cb\u0964 \u09aa\u09cd\u09b0\u09a4\u09cd\u09af\u09c7\u0995 \u0985\u09a4\u09bf\u09a5\u09bf \u09a8\u09bf\u099c\u09c7\u09b0 \u09a8\u09be\u09ae\u09c7 \u0986\u09b2\u09be\u09a6\u09be \u09aa\u09be\u09a4\u09be \u09aa\u09be\u09ac\u09c7\u09a8\u0964 \u09a8\u09be\u09ae \u09aa\u09b0\u09c7 \u09a6\u09bf\u09b2\u09c7\u0993 \u099a\u09b2\u09ac\u09c7\u0964",
                        paid: " {max}\u099f\u09be \u09aa\u09be\u09a4\u09be\u0987 \u0996\u09c1\u09b2\u09ac\u09c7 {price}-\u09a4\u09c7\u0964",
                        inputLabel: "\u0985\u09a4\u09bf\u09a5\u09bf\u09a6\u09c7\u09b0 \u09a8\u09be\u09ae, \u0995\u09ae\u09be \u09a6\u09bf\u09af\u09bc\u09c7 \u0986\u09b2\u09be\u09a6\u09be \u0995\u09b0\u09c7",
                        placeholder: "\u09b0\u09bf\u09af\u09bc\u09be, \u0985\u09af\u09bc\u09a8, \u09ae\u09cc",
                        tooLong: "\u09aa\u09cd\u09b0\u09a4\u09cd\u09af\u09c7\u0995\u099f\u09be \u09a8\u09be\u09ae {max} \u0985\u0995\u09cd\u09b7\u09b0\u09c7\u09b0 \u09ae\u09a7\u09cd\u09af\u09c7 \u09b0\u09be\u0996\u09cb\u0964",
                        tooMany: "{max} \u099c\u09a8 \u09aa\u09b0\u09cd\u09af\u09a8\u09cd\u09a4 \u09a8\u09be\u09ae, \u09aa\u09cd\u09b0\u09a4\u09cd\u09af\u09c7\u0995\u09c7\u09b0 \u098f\u0995\u099f\u09be \u0995\u09b0\u09c7 \u09aa\u09be\u09a4\u09be\u0964"
                    },
                    plans: {
                        label: "\u09a8\u09bf\u09ae\u09a8\u09cd\u09a4\u09cd\u09b0\u09a3 \u09ac\u09c7\u099b\u09c7 \u09a8\u09be\u0993",
                        unlimitedTitle: "\u09af\u09a4 \u0996\u09c1\u09b6\u09bf \u0985\u09a4\u09bf\u09a5\u09bf",
                        limitedTitle: "{count} \u099c\u09a8 \u0985\u09a4\u09bf\u09a5\u09bf",
                        unlimitedDetail: "\u09af\u09be\u0995\u09c7 \u09a1\u09be\u0995\u09ac\u09c7, \u09a4\u09be\u09b0 \u099c\u09a8\u09cd\u09af\u0987 \u0986\u09b2\u09be\u09a6\u09be \u09b2\u09bf\u0982\u0995\u0964",
                        limitedDetail: "{count}\u099f\u09be \u0986\u09b2\u09be\u09a6\u09be \u09b2\u09bf\u0982\u0995, \u09aa\u09cd\u09b0\u09a4\u09cd\u09af\u09c7\u0995\u099f\u09be \u0985\u09a4\u09bf\u09a5\u09bf\u09b0 \u09a8\u09be\u09ae \u09a7\u09b0\u09c7 \u09a1\u09be\u0995\u09c7\u0964"
                    },
                    uploads: {
                        photo: "\u099b\u09ac\u09bf\u099f\u09be \u09a8\u09c7\u0993\u09af\u09bc\u09be \u0997\u09c7\u09b2 \u09a8\u09be\u0964 \u0985\u09a8\u09cd\u09af \u098f\u0995\u099f\u09be \u099b\u09ac\u09bf \u09a6\u09be\u0993\u0964",
                        songTooBig: "\u0997\u09be\u09a8\u09c7\u09b0 \u09ab\u09be\u0987\u09b2\u099f\u09be \u09e9 MB-\u09b0 \u09ac\u09c7\u09b6\u09bf\u0964 \u099b\u09cb\u099f \u098f\u0995\u099f\u09be MP3 \u09a6\u09be\u0993\u0964",
                        songNotMp3: "\u09b6\u09c1\u09a7\u09c1 MP3 \u09ab\u09be\u0987\u09b2 \u09a6\u09c7\u0993\u09af\u09bc\u09be \u09af\u09be\u09ac\u09c7\u0964",
                        notKept: "\u098f\u0987 \u09ab\u09cb\u09a8\u09c7 \u09ab\u09be\u0987\u09b2\u099f\u09be \u09b0\u09be\u0996\u09be \u0997\u09c7\u09b2 \u09a8\u09be\u0964 \u09b8\u09be\u0987\u09a8 \u0987\u09a8 \u0995\u09b0\u09b2\u09c7 \u0985\u09cd\u09af\u09be\u0995\u09be\u0989\u09a8\u09cd\u099f\u09c7 \u09b8\u09c7\u09ad \u09b9\u09ac\u09c7\u0964"
                    },
                    switchLabel: "\u0995\u09cb\u09a8\u099f\u09be \u09ac\u09be\u09a8\u09be\u09ac\u09c7?",
                    explainerInvite: "{count}\u099f\u09be \u09aa\u09be\u09a4\u09be, \u09aa\u09cd\u09b0\u09a4\u09cd\u09af\u09c7\u0995 \u0985\u09a4\u09bf\u09a5\u09bf\u09b0 \u099c\u09a8\u09cd\u09af \u098f\u0995\u099f\u09be, \u098f\u0995 \u09aa\u09c7\u09ae\u09c7\u09a8\u09cd\u099f\u09c7\u0987 \u09b8\u09ac \u0996\u09cb\u09b2\u09c7\u0964",
                    explainerSingle: "\u098f\u0995\u099f\u09be\u0987 \u09aa\u09be\u09a4\u09be, \u09af\u09c7\u0996\u09be\u09a8\u09c7 \u0996\u09c1\u09b6\u09bf \u09aa\u09be\u09a0\u09be\u0993\u0964",
                    explainerClosed: "\u09b6\u09bf\u0997\u0997\u09bf\u09b0\u0987 \u0996\u09c1\u09b2\u099b\u09c7\u0964 \u09a4\u09cb\u09ae\u09be\u09b0 \u09a1\u09bf\u099c\u09be\u0987\u09a8 \u098f\u0987 \u09ab\u09cb\u09a8\u09c7\u0987 \u09b8\u09c7\u09ad \u09a5\u09be\u0995\u09ac\u09c7\u0964",
                    loading: "\u09b6\u09bf\u0997\u0997\u09bf\u09b0\u0987 \u0996\u09c1\u09b2\u099b\u09c7\u0964"
                },
                r = {
                    cta: "Make it live \xb7 {price}",
                    ctaNoPrice: "Make it live",
                    explainerClosed: "The Navratri proposal opens soon. Your design stays saved on this device.",
                    loading: "The Navratri proposal opens soon.",
                    claimFailed: "We couldn't save your proposal to your account. Check your connection and try again.",
                    signIn: {
                        title: "Sign in to make it live",
                        description: "Your proposal stays right here. Sign in with Google and you come straight back to this editor to pay and make it live.",
                        footnote: "Secure sign-in"
                    },
                    switchLabel: "What are you making?"
                },
                n = {
                    explainerSingle: "One page, and a personal link for every guest that greets them by name.",
                    explainerClosed: "The party invite opens soon. Your design stays saved on this device.",
                    loading: "The party invite opens soon."
                },
                s = {
                    explainerSingle: "One page for every event, and a personal link for every guest that greets them by name.",
                    explainerClosed: "The wedding invite opens soon. Your design stays saved on this device.",
                    loading: "The wedding invite opens soon."
                },
                p = {
                    explainerSingle: "One page for your event, and a personal link for every guest that greets them by name.",
                    explainerClosed: "The corporate invite opens soon. Your design stays saved on this device.",
                    loading: "The corporate invite opens soon."
                },
                d = {
                    cta: "Make it live \xb7 {price}",
                    ctaNoPrice: "Make it live",
                    explainerClosed: "This design opens soon. Your work stays saved on this device.",
                    loading: "Loading your design\u2026",
                    claimFailed: "We couldn't save your page to your account. Check your connection and try again.",
                    signIn: {
                        title: "Sign in to make it live",
                        description: "Your page stays right here. Sign in with Google and you come straight back to this editor to make it live.",
                        footnote: "Secure sign-in"
                    }
                };

            function c(e, a) {
                return e.replace(/\{(\w+)\}/g, (e, t) => Object.prototype.hasOwnProperty.call(a, t) ? String(a[t]) : e)
            }

            function m(e) {
                return e ? { ...i,
                    ...e,
                    signIn: { ...i.signIn,
                        ...e.signIn
                    },
                    guestNames: { ...i.guestNames,
                        ...e.guestNames
                    },
                    plans: { ...i.plans,
                        ...e.plans
                    }
                } : i
            }
        }
    }
]);