(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [85941], {
        9421: (r, e, t) => {
            "use strict";
            t.d(e, {
                $w: () => b,
                BQ: () => B,
                Es: () => k,
                HW: () => w,
                S7: () => Z,
                Vf: () => $,
                Ww: () => m,
                Xe: () => R,
                _X: () => C,
                ai: () => f,
                d3: () => S,
                dI: () => H,
                dO: () => W,
                dV: () => u,
                eC: () => N,
                eM: () => x,
                ed: () => y,
                fl: () => g,
                fz: () => V,
                gY: () => p,
                kC: () => Q,
                mf: () => M,
                qW: () => j,
                ul: () => z,
                vY: () => v,
                y0: () => L
            });
            var s = t(73365);
            let l = {
                    stroke: "var(--f-fg)",
                    strokeWidth: 3.5,
                    strokeLinejoin: "round",
                    strokeLinecap: "round"
                },
                a = {
                    stroke: "var(--f-fg)",
                    strokeWidth: 2.5,
                    strokeLinejoin: "round",
                    strokeLinecap: "round"
                },
                i = {
                    rest: {
                        d: "M14 28 Q21 42 17 54",
                        hand: [17, 56]
                    },
                    drive: {
                        d: "M14 28 Q30 32 44 24",
                        hand: [46, 23]
                    },
                    wave: {
                        d: "M14 28 Q27 20 27 3",
                        hand: [27, 0]
                    },
                    hold: {
                        d: "M14 28 Q23 46 31 39",
                        hand: [32, 38]
                    },
                    hug: {
                        d: "M14 28 Q24 36 34 32",
                        hand: [35, 31]
                    }
                };

            function c({
                expr: r
            }) {
                return "laugh" === r ? (0, s.jsx)("path", {
                    d: "M-11 0 Q-7.5 -5.5 -4 0 M4 0 Q7.5 -5.5 11 0",
                    fill: "none",
                    ...a,
                    strokeWidth: 2.8
                }) : "soft" === r ? (0, s.jsx)("path", {
                    d: "M-11 -2 Q-7.5 2.5 -4 -2 M4 -2 Q7.5 2.5 11 -2",
                    fill: "none",
                    ...a,
                    strokeWidth: 2.8
                }) : "shock" === r ? (0, s.jsxs)("g", {
                    className: "prrt-eyes",
                    children: [(0, s.jsx)("circle", {
                        cx: "-7.5",
                        cy: "-1",
                        r: "4",
                        fill: "#ffffff",
                        ...a,
                        strokeWidth: 2
                    }), (0, s.jsx)("circle", {
                        cx: "7.5",
                        cy: "-1",
                        r: "4",
                        fill: "#ffffff",
                        ...a,
                        strokeWidth: 2
                    }), (0, s.jsx)("circle", {
                        cx: "-7.5",
                        cy: "-0.5",
                        r: "1.9",
                        fill: "var(--f-fg)"
                    }), (0, s.jsx)("circle", {
                        cx: "7.5",
                        cy: "-0.5",
                        r: "1.9",
                        fill: "var(--f-fg)"
                    })]
                }) : (0, s.jsxs)("g", {
                    className: "prrt-eyes",
                    children: [(0, s.jsx)("ellipse", {
                        cx: "-7.5",
                        cy: "-1",
                        rx: "2.5",
                        ry: "3.3",
                        fill: "var(--f-fg)"
                    }), (0, s.jsx)("ellipse", {
                        cx: "7.5",
                        cy: "-1",
                        rx: "2.5",
                        ry: "3.3",
                        fill: "var(--f-fg)"
                    }), (0, s.jsx)("circle", {
                        cx: "-6.6",
                        cy: "-2.3",
                        r: "0.9",
                        fill: "#ffffff"
                    }), (0, s.jsx)("circle", {
                        cx: "8.4",
                        cy: "-2.3",
                        r: "0.9",
                        fill: "#ffffff"
                    })]
                })
            }

            function n({
                expr: r
            }) {
                switch (r) {
                    case "laugh":
                        return (0, s.jsxs)("g", {
                            children: [(0, s.jsx)("path", {
                                d: "M-7 6 Q0 18 7 6 Z",
                                fill: "var(--f-fg)",
                                ...a,
                                strokeWidth: 2
                            }), (0, s.jsx)("path", {
                                d: "M-3.4 11.6 Q0 9.5 3.4 11.6 Q0 14.5 -3.4 11.6 Z",
                                fill: "var(--prrt-tongue)"
                            })]
                        });
                    case "shock":
                        return (0, s.jsx)("ellipse", {
                            cx: "0",
                            cy: "10",
                            rx: "3.4",
                            ry: "4.4",
                            fill: "var(--f-fg)"
                        });
                    case "soft":
                        return (0, s.jsx)("path", {
                            d: "M-3.5 9 Q0 12 3.5 9",
                            fill: "none",
                            ...a,
                            strokeWidth: 2.4
                        });
                    case "proud":
                        return (0, s.jsx)("path", {
                            d: "M-7.5 6.5 Q0 15.5 7.5 6.5 Z",
                            fill: "#ffffff",
                            ...a,
                            strokeWidth: 2.2
                        });
                    default:
                        return (0, s.jsx)("path", {
                            d: "M-5.5 7.5 Q0 13 5.5 7.5",
                            fill: "none",
                            ...a,
                            strokeWidth: 2.6
                        })
                }
            }

            function d({
                expr: r
            }) {
                return "shock" === r ? (0, s.jsx)("path", {
                    d: "M-11 -11 Q-7.5 -14 -4 -11.5 M4 -11.5 Q7.5 -14 11 -11",
                    fill: "none",
                    ...a,
                    strokeWidth: 2.2
                }) : "proud" === r ? (0, s.jsx)("path", {
                    d: "M-11 -9 L-4 -10.5 M4 -10.5 L11 -9",
                    fill: "none",
                    ...a,
                    strokeWidth: 2.2
                }) : null
            }

            function o({
                who: r,
                expr: e,
                arm: t = "rest",
                helmet: h = !1
            }) {
                let f = "a" === r ? "var(--prrt-shirtA)" : "var(--prrt-shirtB)",
                    x = "a" === r ? "var(--prrt-skinA)" : "var(--prrt-skinB)",
                    p = i[t];
                return (0, s.jsx)("g", {
                    className: `prrt-bestie prrt-bestie-${r}`,
                    children: (0, s.jsxs)("g", {
                        className: "prrt-breathe",
                        children: ["a" === r ? (0, s.jsxs)("g", {
                            children: [(0, s.jsx)("path", {
                                d: "M14 -16 C36 -14 40 10 26 24 C30 8 24 -4 12 -6 Z",
                                fill: "var(--prrt-hair)",
                                ...a
                            }), (0, s.jsx)("circle", {
                                cx: "16",
                                cy: "-12",
                                r: "4.5",
                                fill: "var(--f-accent)",
                                ...a,
                                strokeWidth: 2
                            })]
                        }) : (0, s.jsxs)("g", {
                            fill: "var(--prrt-hair)",
                            ...a,
                            children: [(0, s.jsx)("circle", {
                                cx: "-19",
                                cy: "-6",
                                r: "9"
                            }), (0, s.jsx)("circle", {
                                cx: "19",
                                cy: "-6",
                                r: "9"
                            }), (0, s.jsx)("circle", {
                                cx: "-14",
                                cy: "-18",
                                r: "10"
                            }), (0, s.jsx)("circle", {
                                cx: "14",
                                cy: "-18",
                                r: "10"
                            }), (0, s.jsx)("circle", {
                                cx: "0",
                                cy: "-24",
                                r: "11"
                            })]
                        }), (0, s.jsx)("path", {
                            d: "M-19 24 Q-23 46 -20 60 H20 Q23 46 19 24 Q0 16 -19 24 Z",
                            fill: f,
                            ...l
                        }), "a" === r ? (0, s.jsx)("path", {
                            d: "M0 22 V40 M-3 30 h0.1 M-3 36 h0.1",
                            fill: "none",
                            ...a,
                            strokeWidth: 2.4
                        }) : (0, s.jsx)("path", {
                            d: "M-20 40 H20 M-20 47 H20",
                            fill: "none",
                            stroke: "var(--prrt-stripe)",
                            strokeWidth: "4"
                        }), (0, s.jsx)("path", {
                            d: "M-14 28 Q-21 42 -17 54",
                            fill: "none",
                            stroke: f,
                            strokeWidth: "8",
                            strokeLinecap: "round"
                        }), (0, s.jsx)("path", {
                            d: "M-14 28 Q-21 42 -17 54",
                            fill: "none",
                            ...a,
                            strokeWidth: 1.6,
                            opacity: "0.5"
                        }), (0, s.jsx)("circle", {
                            cx: "-17",
                            cy: "56",
                            r: "4.5",
                            fill: x,
                            ...a,
                            strokeWidth: 2
                        }), (0, s.jsx)("rect", {
                            x: "-5",
                            y: "15",
                            width: "10",
                            height: "9",
                            fill: x,
                            ...a,
                            strokeWidth: 2
                        }), (0, s.jsx)("circle", {
                            cx: "0",
                            cy: "0",
                            r: "21",
                            fill: x,
                            ...l
                        }), h ? (0, s.jsxs)("g", {
                            children: [(0, s.jsx)("path", {
                                d: "M-23 -2 Q-25 -30 0 -30 Q25 -30 23 -2 Q12 -12 0 -12 Q-12 -12 -23 -2 Z",
                                fill: "a" === r ? "var(--f-accent)" : "var(--prrt-scooter)",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M-4 -29 Q0 -18 -2 -12 M4 -29 Q7 -18 6 -12",
                                fill: "none",
                                stroke: "#ffffff",
                                strokeWidth: "3",
                                strokeLinecap: "round",
                                opacity: "0.85"
                            }), (0, s.jsx)("path", {
                                d: "M-21 -3 Q-24 10 -18 14 M21 -3 Q24 10 18 14",
                                fill: "none",
                                ...a,
                                strokeWidth: 2
                            })]
                        }) : "a" === r ? (0, s.jsx)("path", {
                            d: "M-21 -4 Q-21 -25 0 -25 Q21 -25 21 -4 Q13 -15 3 -12 Q-7 -19 -21 -4 Z",
                            fill: "var(--prrt-hair)",
                            ...a
                        }) : (0, s.jsxs)("g", {
                            children: [(0, s.jsxs)("g", {
                                fill: "var(--prrt-hair)",
                                ...a,
                                children: [(0, s.jsx)("circle", {
                                    cx: "-11",
                                    cy: "-17",
                                    r: "7"
                                }), (0, s.jsx)("circle", {
                                    cx: "0",
                                    cy: "-20",
                                    r: "7.5"
                                }), (0, s.jsx)("circle", {
                                    cx: "11",
                                    cy: "-17",
                                    r: "7"
                                })]
                            }), (0, s.jsx)("path", {
                                d: "M-20 -10 Q0 -20 20 -10",
                                fill: "none",
                                stroke: "var(--prrt-truck)",
                                strokeWidth: "5",
                                strokeLinecap: "round"
                            }), (0, s.jsx)("path", {
                                d: "M19 -10 L27 -15 M19 -10 L27 -5",
                                fill: "none",
                                stroke: "var(--prrt-truck)",
                                strokeWidth: "3.5",
                                strokeLinecap: "round"
                            })]
                        }), (0, s.jsx)(d, {
                            expr: e
                        }), (0, s.jsx)(c, {
                            expr: e
                        }), (0, s.jsx)(n, {
                            expr: e
                        }), (0, s.jsx)("ellipse", {
                            cx: "-12.5",
                            cy: "6",
                            rx: "4",
                            ry: "2.4",
                            fill: "var(--f-accent)",
                            opacity: "0.32"
                        }), (0, s.jsx)("ellipse", {
                            cx: "12.5",
                            cy: "6",
                            rx: "4",
                            ry: "2.4",
                            fill: "var(--f-accent)",
                            opacity: "0.32"
                        }), (0, s.jsxs)("g", {
                            className: "wave" === t ? "prrt-arm prrt-wave" : "prrt-arm",
                            children: [(0, s.jsx)("path", {
                                d: p.d,
                                fill: "none",
                                stroke: f,
                                strokeWidth: "8",
                                strokeLinecap: "round"
                            }), (0, s.jsx)("circle", {
                                cx: p.hand[0],
                                cy: p.hand[1],
                                r: "4.5",
                                fill: x,
                                ...a,
                                strokeWidth: 2
                            })]
                        })]
                    })
                })
            }

            function h({
                cx: r,
                cy: e
            }) {
                return (0, s.jsx)("g", {
                    transform: `translate(${r} ${e})`,
                    children: (0, s.jsxs)("g", {
                        className: "prrt-wheel",
                        children: [(0, s.jsx)("circle", {
                            r: "19",
                            fill: "var(--prrt-tyre)",
                            ...l
                        }), (0, s.jsx)("circle", {
                            r: "10",
                            fill: "var(--f-surface)",
                            ...a
                        }), (0, s.jsx)("path", {
                            d: "M0 -10 V10 M-10 0 H10 M-7 -7 L7 7 M-7 7 L7 -7",
                            stroke: "var(--f-fg)",
                            strokeWidth: "1.6",
                            opacity: "0.6"
                        }), (0, s.jsx)("circle", {
                            r: "3",
                            fill: "var(--f-fg)"
                        })]
                    })
                })
            }

            function f({
                exprA: r,
                exprB: e,
                armB: t = "hug"
            }) {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 240 180",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, s.jsxs)("g", {
                        className: "prrt-puffs",
                        children: [(0, s.jsx)("circle", {
                            cx: "16",
                            cy: "152",
                            r: "6"
                        }), (0, s.jsx)("circle", {
                            cx: "6",
                            cy: "144",
                            r: "4.5"
                        }), (0, s.jsx)("circle", {
                            cx: "-4",
                            cy: "150",
                            r: "3.5"
                        })]
                    }), (0, s.jsxs)("g", {
                        className: "prrt-wobble",
                        children: [(0, s.jsx)("g", {
                            transform: "translate(70 62)",
                            children: (0, s.jsx)("path", {
                                className: "prrt-scarf",
                                d: "M4 0 C-14 -4 -26 6 -44 2 C-38 10 -50 16 -58 14 C-44 22 -20 14 4 10 Z",
                                fill: "var(--prrt-truck)",
                                ...a
                            })
                        }), (0, s.jsx)("rect", {
                            x: "12",
                            y: "84",
                            width: "30",
                            height: "30",
                            rx: "7",
                            fill: "var(--f-accent)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M14 96 H40 M27 84 V114",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2.5",
                            opacity: "0.5"
                        }), (0, s.jsx)("g", {
                            transform: "wave" === t ? "translate(76 40) scale(-1 1)" : "translate(76 40)",
                            children: (0, s.jsx)(o, {
                                who: "b",
                                expr: e,
                                arm: t,
                                helmet: !0
                            })
                        }), (0, s.jsx)("path", {
                            d: "M80 100 Q98 106 102 116 Q100 128 98 140",
                            fill: "none",
                            stroke: "var(--prrt-pants)",
                            strokeWidth: "9",
                            strokeLinecap: "round"
                        }), (0, s.jsx)("path", {
                            d: "M92 142 H104",
                            stroke: "var(--f-fg)",
                            strokeWidth: "6",
                            strokeLinecap: "round"
                        }), (0, s.jsx)("path", {
                            d: "M30 146 C24 118 44 102 80 100 L134 100 C142 114 140 132 130 146 Z",
                            fill: "var(--prrt-scooter)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M42 120 C52 112 86 110 104 116",
                            fill: "none",
                            stroke: "#ffffff",
                            strokeWidth: "3",
                            strokeLinecap: "round",
                            opacity: "0.55"
                        }), (0, s.jsx)("path", {
                            d: "M50 101 C50 88 128 86 132 101 Z",
                            fill: "var(--prrt-seat)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M126 140 H162 L166 148 H122 Z",
                            fill: "var(--prrt-seat)",
                            ...a
                        }), (0, s.jsx)("path", {
                            d: "M156 148 C150 120 156 92 170 72 L182 75 C174 96 174 122 180 148 Z",
                            fill: "var(--prrt-scooter)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M164 140 C172 124 200 124 208 142",
                            fill: "var(--prrt-scooter)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M174 74 L178 58",
                            ...l,
                            strokeWidth: 5,
                            fill: "none"
                        }), (0, s.jsx)("path", {
                            d: "M188 56 L196 38",
                            ...a,
                            fill: "none"
                        }), (0, s.jsx)("ellipse", {
                            cx: "198",
                            cy: "34",
                            rx: "6.5",
                            ry: "4.5",
                            fill: "var(--prrt-sky)",
                            ...a
                        }), (0, s.jsx)("circle", {
                            cx: "190",
                            cy: "68",
                            r: "7",
                            fill: "var(--prrt-light)",
                            ...l
                        }), (0, s.jsx)("g", {
                            transform: "translate(114 36)",
                            children: (0, s.jsx)(o, {
                                who: "a",
                                expr: r,
                                arm: "drive",
                                helmet: !0
                            })
                        }), (0, s.jsx)("path", {
                            d: "M120 96 Q142 100 146 112 Q148 126 150 138",
                            fill: "none",
                            stroke: "var(--prrt-pants)",
                            strokeWidth: "9",
                            strokeLinecap: "round"
                        }), (0, s.jsx)("path", {
                            d: "M146 140 H160",
                            stroke: "var(--f-fg)",
                            strokeWidth: "6",
                            strokeLinecap: "round"
                        }), (0, s.jsx)("path", {
                            d: "M158 58 L196 55",
                            ...l,
                            strokeWidth: 5,
                            fill: "none"
                        }), (0, s.jsx)(h, {
                            cx: 58,
                            cy: 150
                        }), (0, s.jsx)(h, {
                            cx: 186,
                            cy: 150
                        })]
                    })]
                })
            }

            function x() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 200 124",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, s.jsx)("path", {
                        d: "M58 16 Q125 -6 194 16 Z",
                        fill: "var(--prrt-scooter)",
                        ...l
                    }), (0, s.jsx)("rect", {
                        x: "58",
                        y: "16",
                        width: "136",
                        height: "80",
                        rx: "5",
                        fill: "var(--prrt-truck)",
                        ...l
                    }), (0, s.jsx)("rect", {
                        x: "66",
                        y: "26",
                        width: "120",
                        height: "48",
                        rx: "4",
                        fill: "var(--f-surface)",
                        ...a
                    }), (0, s.jsx)("path", {
                        d: "M66 80 l8 -6 l8 6 l8 -6 l8 6 l8 -6 l8 6 l8 -6 l8 6 l8 -6 l8 6 l8 -6 l8 6 l8 -6 l8 6 l8 -6",
                        fill: "none",
                        stroke: "var(--f-surface)",
                        strokeWidth: "2.5"
                    }), (0, s.jsx)("circle", {
                        cx: "74",
                        cy: "88",
                        r: "3",
                        fill: "var(--f-accent)"
                    }), (0, s.jsx)("circle", {
                        cx: "178",
                        cy: "88",
                        r: "3",
                        fill: "var(--f-accent)"
                    }), (0, s.jsx)("path", {
                        d: "M8 98 L8 54 Q10 36 28 34 L58 34 L58 98 Z",
                        fill: "var(--prrt-truck)",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M16 54 Q18 42 30 42 L50 42 L50 60 L16 60 Z",
                        fill: "var(--prrt-sky)",
                        ...a
                    }), (0, s.jsx)("path", {
                        d: "M6 98 H60",
                        ...l,
                        strokeWidth: 6
                    }), [12, 20, 28, 36, 44, 52].map((r, e) => (0, s.jsxs)("g", {
                        children: [(0, s.jsx)("path", {
                            d: `M${r} 101 V108`,
                            stroke: "var(--f-fg)",
                            strokeWidth: "1.5"
                        }), (0, s.jsx)("circle", {
                            cx: r,
                            cy: "110",
                            r: "2.4",
                            fill: e % 2 ? "var(--f-accent)" : "var(--prrt-glow)"
                        })]
                    }, r)), (0, s.jsx)("path", {
                        d: "M8 66 L2 66",
                        ...l
                    }), (0, s.jsx)("circle", {
                        cx: "14",
                        cy: "80",
                        r: "4",
                        fill: "var(--prrt-light)",
                        ...a
                    }), [36, 150, 176].map(r => (0, s.jsxs)("g", {
                        children: [(0, s.jsx)("circle", {
                            cx: r,
                            cy: "100",
                            r: "13",
                            fill: "var(--prrt-tyre)",
                            ...l
                        }), (0, s.jsx)("circle", {
                            cx: r,
                            cy: "100",
                            r: "5",
                            fill: "var(--f-surface)",
                            ...a
                        })]
                    }, r))]
                })
            }

            function p() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 400 100",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block h-full w-1/2",
                    children: [(0, s.jsx)("path", {
                        d: "M0 64 Q40 22 90 52 Q130 76 170 40 Q210 8 260 46 Q300 74 340 44 Q372 24 400 64 V100 H0 Z",
                        fill: "var(--prrt-hill-far)"
                    }), (0, s.jsx)("path", {
                        d: "M150 50 l20 -12 l20 12",
                        fill: "none",
                        stroke: "#ffffff",
                        strokeWidth: "3",
                        strokeLinecap: "round",
                        opacity: "0.6"
                    }), (0, s.jsx)("path", {
                        d: "M0 80 Q60 58 120 76 Q200 96 260 72 Q330 52 400 80 V100 H0 Z",
                        fill: "var(--prrt-hill)",
                        opacity: "0.75"
                    })]
                })
            }

            function j() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 400 80",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block h-full w-1/2",
                    children: [(0, s.jsx)("path", {
                        d: "M0 40 Q100 30 200 40 T400 40",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "1.2",
                        opacity: "0.4"
                    }), [30, 230].map(r => (0, s.jsx)("g", {
                        children: (0, s.jsx)("path", {
                            d: `M${r} 80 V24 M${r-8} 30 H${r+8}`,
                            stroke: "var(--f-fg)",
                            strokeWidth: "3",
                            strokeLinecap: "round"
                        })
                    }, r)), [
                        [90, 1],
                        [150, .8],
                        [310, 1.1],
                        [360, .85]
                    ].map(([r, e]) => (0, s.jsxs)("g", {
                        transform: `translate(${r} 80) scale(${e})`,
                        children: [(0, s.jsx)("path", {
                            d: "M0 0 V-22",
                            stroke: "var(--prrt-trunk)",
                            strokeWidth: "5"
                        }), (0, s.jsx)("circle", {
                            cx: "0",
                            cy: "-36",
                            r: "18",
                            fill: "var(--prrt-hill)",
                            ...a
                        }), (0, s.jsx)("circle", {
                            cx: "-10",
                            cy: "-28",
                            r: "11",
                            fill: "var(--prrt-hill)",
                            ...a
                        }), (0, s.jsx)("circle", {
                            cx: "11",
                            cy: "-28",
                            r: "11",
                            fill: "var(--prrt-hill)",
                            ...a
                        })]
                    }, r)), [200, 270].map(r => (0, s.jsxs)("g", {
                        children: [(0, s.jsx)("path", {
                            d: `M${r} 80 V62 Q${r+9} 54 ${r+18} 62 V80 Z`,
                            fill: "#ffffff",
                            ...a
                        }), (0, s.jsx)("path", {
                            d: `M${r} 64 Q${r+9} 54 ${r+18} 64 V68 H${r} Z`,
                            fill: "var(--prrt-glow)"
                        })]
                    }, r))]
                })
            }

            function u() {
                return (0, s.jsx)("svg", {
                    viewBox: "0 0 400 8",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block h-full w-1/2",
                    children: [0, 50, 100, 150, 200, 250, 300, 350].map(r => (0, s.jsx)("rect", {
                        x: r + 12,
                        y: "0",
                        width: "26",
                        height: "8",
                        rx: "3",
                        fill: "#ffffff",
                        opacity: "0.85"
                    }, r))
                })
            }

            function v() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 400 30",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block h-full w-1/2",
                    children: [(0, s.jsx)("path", {
                        d: "M0 30 V18 Q50 10 100 18 T200 18 T300 18 T400 18 V30 Z",
                        fill: "var(--prrt-hill)"
                    }), [20, 70, 130, 175, 240, 290, 350].map((r, e) => (0, s.jsxs)("g", {
                        children: [(0, s.jsx)("path", {
                            d: `M${r} 20 l-4 -12 M${r} 20 l1 -14 M${r} 20 l6 -11`,
                            stroke: "var(--prrt-hill)",
                            strokeWidth: "2.5",
                            strokeLinecap: "round"
                        }), e % 2 ? (0, s.jsx)("circle", {
                            cx: r + 1,
                            cy: "6",
                            r: "3.4",
                            fill: "var(--prrt-glow)",
                            stroke: "var(--f-fg)",
                            strokeWidth: "1.2"
                        }) : null]
                    }, r))]
                })
            }

            function k({
                className: r = ""
            }) {
                return (0, s.jsx)("svg", {
                    viewBox: "0 0 90 40",
                    "aria-hidden": !0,
                    className: r,
                    children: (0, s.jsx)("path", {
                        d: "M14 34 Q2 34 4 24 Q6 14 18 16 Q22 4 38 6 Q52 0 60 12 Q76 8 80 20 Q90 24 84 34 Z",
                        fill: "#ffffff",
                        ...a,
                        strokeWidth: 2,
                        opacity: "0.95"
                    })
                })
            }

            function m() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 400 80",
                    preserveAspectRatio: "none",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, s.jsx)("rect", {
                        x: "0",
                        y: "6",
                        width: "400",
                        height: "74",
                        fill: "var(--prrt-road)"
                    }), (0, s.jsx)("path", {
                        className: "prrt-draw",
                        pathLength: 1,
                        d: "M0 8 H400",
                        stroke: "var(--prrt-glow)",
                        strokeWidth: "4"
                    }), (0, s.jsx)("path", {
                        className: "prrt-draw",
                        pathLength: 1,
                        d: "M0 74 H400",
                        stroke: "#ffffff",
                        strokeWidth: "3",
                        opacity: "0.7"
                    })]
                })
            }

            function g() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 60 70",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, s.jsx)("path", {
                        d: "M6 68 V26 Q30 -6 54 26 V68 Z",
                        fill: "#ffffff",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M8 26 Q30 -4 52 26 V30 H8 Z",
                        fill: "var(--prrt-glow)"
                    }), (0, s.jsx)("path", {
                        d: "M6 30 H54",
                        ...a
                    })]
                })
            }
            let M = {
                    Pahaad: (0, s.jsxs)("svg", {
                        viewBox: "0 0 100 100",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [(0, s.jsx)("circle", {
                            cx: "50",
                            cy: "50",
                            r: "44",
                            fill: "var(--prrt-sky)",
                            ...l
                        }), (0, s.jsx)("circle", {
                            cx: "68",
                            cy: "34",
                            r: "9",
                            fill: "var(--prrt-glow)",
                            ...a
                        }), (0, s.jsx)("path", {
                            d: "M10 74 L36 36 L50 56 L62 42 L90 74 Z",
                            fill: "var(--prrt-hill)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M30 45 L36 36 L43 46 L38 44 L34 48 Z M58 47 L62 42 L67 48 Z",
                            fill: "#ffffff",
                            ...a,
                            strokeWidth: 1.6
                        }), (0, s.jsx)("path", {
                            d: "M14 78 Q50 90 86 78",
                            fill: "none",
                            ...l
                        })]
                    }),
                    Samundar: (0, s.jsxs)("svg", {
                        viewBox: "0 0 100 100",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [(0, s.jsx)("circle", {
                            cx: "50",
                            cy: "50",
                            r: "44",
                            fill: "var(--prrt-glow)",
                            ...l
                        }), (0, s.jsx)("circle", {
                            cx: "50",
                            cy: "46",
                            r: "14",
                            fill: "var(--f-accent)",
                            ...a
                        }), (0, s.jsx)("path", {
                            d: "M8 58 Q20 50 30 58 T50 58 T70 58 T92 58 V70 Q50 96 8 70 Z",
                            fill: "var(--prrt-scooter)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M18 72 Q28 66 38 72 T58 72 T80 72",
                            fill: "none",
                            stroke: "#ffffff",
                            strokeWidth: "3",
                            strokeLinecap: "round"
                        }), (0, s.jsx)("path", {
                            d: "M76 58 Q74 36 70 28 M70 28 q-12 -2 -16 6 M70 28 q10 -8 18 -2 M70 28 q4 -10 -4 -14",
                            fill: "none",
                            ...a,
                            strokeWidth: 3
                        })]
                    }),
                    Registaan: (0, s.jsxs)("svg", {
                        viewBox: "0 0 100 100",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [(0, s.jsx)("circle", {
                            cx: "50",
                            cy: "50",
                            r: "44",
                            fill: "var(--prrt-glow)",
                            ...l
                        }), (0, s.jsx)("circle", {
                            cx: "34",
                            cy: "34",
                            r: "10",
                            fill: "var(--f-accent)",
                            ...a
                        }), (0, s.jsx)("path", {
                            d: "M8 66 Q34 44 58 62 Q76 50 92 62 V70 Q50 96 8 70 Z",
                            fill: "var(--prrt-truck)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M52 54 q4 -10 10 -6 q4 -8 10 -2 l6 -2 l-2 6 q0 6 -6 6 l0 8 M58 52 l-1 10 M70 58 v6",
                            fill: "none",
                            ...a,
                            strokeWidth: 2.6
                        })]
                    })
                },
                y = {
                    Nimbu: (0, s.jsxs)("svg", {
                        viewBox: "0 0 60 110",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [(0, s.jsx)("path", {
                            d: "M30 0 V96",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2"
                        }), (0, s.jsx)("ellipse", {
                            cx: "30",
                            cy: "24",
                            rx: "13",
                            ry: "11",
                            fill: "#f5d33a",
                            ...a
                        }), (0, s.jsx)("circle", {
                            cx: "30",
                            cy: "44",
                            r: "5",
                            fill: "#3b2a26"
                        }), [56, 68, 80, 92].map((r, e) => (0, s.jsx)("path", {
                            d: `M30 ${r} q${e%2?10:-10} 4 ${e%2?6:-6} 12`,
                            fill: "none",
                            stroke: "#2f9e44",
                            strokeWidth: "6",
                            strokeLinecap: "round"
                        }, r))]
                    }),
                    Nazar: (0, s.jsxs)("svg", {
                        viewBox: "0 0 60 110",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [(0, s.jsx)("path", {
                            d: "M30 0 V30",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2"
                        }), (0, s.jsx)("circle", {
                            cx: "30",
                            cy: "50",
                            r: "20",
                            fill: "#1f5fd1",
                            ...a
                        }), (0, s.jsx)("circle", {
                            cx: "30",
                            cy: "50",
                            r: "13",
                            fill: "#ffffff"
                        }), (0, s.jsx)("circle", {
                            cx: "30",
                            cy: "50",
                            r: "8",
                            fill: "#7cc4ff"
                        }), (0, s.jsx)("circle", {
                            cx: "30",
                            cy: "50",
                            r: "4",
                            fill: "#111a2e"
                        }), (0, s.jsx)("path", {
                            d: "M22 72 L20 100 M30 72 V104 M38 72 L40 100",
                            stroke: "var(--f-accent)",
                            strokeWidth: "3",
                            strokeLinecap: "round"
                        })]
                    }),
                    Ghanti: (0, s.jsxs)("svg", {
                        viewBox: "0 0 60 110",
                        "aria-hidden": !0,
                        className: "block size-full",
                        children: [(0, s.jsx)("path", {
                            d: "M30 0 V34",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2"
                        }), (0, s.jsx)("path", {
                            d: "M14 76 Q14 40 30 36 Q46 40 46 76 Z",
                            fill: "#e3a21a",
                            ...a
                        }), (0, s.jsx)("path", {
                            d: "M10 76 H50",
                            ...a,
                            strokeWidth: 4
                        }), (0, s.jsx)("circle", {
                            cx: "30",
                            cy: "84",
                            r: "5",
                            fill: "#b37a10",
                            ...a,
                            strokeWidth: 1.6
                        }), (0, s.jsx)("path", {
                            d: "M22 50 Q24 44 30 42",
                            fill: "none",
                            stroke: "#fff4c2",
                            strokeWidth: "3",
                            strokeLinecap: "round"
                        })]
                    })
                };

            function N({
                kind: r
            }) {
                switch (r) {
                    case "thermos":
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 64 64",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("rect", {
                                x: "20",
                                y: "14",
                                width: "24",
                                height: "44",
                                rx: "8",
                                fill: "var(--prrt-scooter)",
                                ...l
                            }), (0, s.jsx)("rect", {
                                x: "22",
                                y: "6",
                                width: "20",
                                height: "10",
                                rx: "3",
                                fill: "var(--f-accent)",
                                ...a
                            }), (0, s.jsx)("path", {
                                d: "M20 30 H44 M20 40 H44",
                                stroke: "#ffffff",
                                strokeWidth: "3",
                                opacity: "0.7"
                            }), (0, s.jsx)("path", {
                                d: "M50 10 q-4 -4 0 -8 M56 14 q-4 -4 0 -8",
                                fill: "none",
                                ...a,
                                strokeWidth: 2
                            })]
                        });
                    case "shades":
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 64 64",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("path", {
                                d: "M4 26 H60",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M6 26 Q6 44 18 44 Q28 44 28 26 Z M36 26 Q36 44 46 44 Q58 44 58 26 Z",
                                fill: "var(--f-fg)",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M11 31 l6 6 M41 31 l6 6",
                                stroke: "#ffffff",
                                strokeWidth: "2.5",
                                strokeLinecap: "round",
                                opacity: "0.8"
                            })]
                        });
                    case "chips":
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 64 64",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("path", {
                                d: "M14 8 l4 4 l4 -4 l4 4 l4 -4 l4 4 l4 -4 l4 4 l4 -4 L50 56 l-4 -4 l-4 4 l-4 -4 l-4 4 l-4 -4 l-4 4 l-4 -4 l-4 4 Z",
                                fill: "var(--prrt-truck)",
                                ...l,
                                strokeWidth: 3
                            }), (0, s.jsx)("circle", {
                                cx: "32",
                                cy: "32",
                                r: "10",
                                fill: "var(--prrt-glow)",
                                ...a
                            }), (0, s.jsx)("path", {
                                d: "M27 31 h0.1 M37 31 h0.1 M27 36 Q32 40 37 36",
                                fill: "none",
                                ...a,
                                strokeWidth: 2.6
                            })]
                        });
                    case "cassette":
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 64 64",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("rect", {
                                x: "6",
                                y: "14",
                                width: "52",
                                height: "36",
                                rx: "5",
                                fill: "var(--f-accent)",
                                ...l
                            }), (0, s.jsx)("rect", {
                                x: "14",
                                y: "20",
                                width: "36",
                                height: "16",
                                rx: "3",
                                fill: "var(--f-surface)",
                                ...a
                            }), (0, s.jsx)("circle", {
                                cx: "23",
                                cy: "28",
                                r: "4",
                                fill: "var(--f-fg)"
                            }), (0, s.jsx)("circle", {
                                cx: "41",
                                cy: "28",
                                r: "4",
                                fill: "var(--f-fg)"
                            }), (0, s.jsx)("path", {
                                d: "M18 50 L22 42 H42 L46 50",
                                fill: "none",
                                ...a
                            })]
                        });
                    default:
                        return (0, s.jsxs)("svg", {
                            viewBox: "0 0 64 64",
                            "aria-hidden": !0,
                            className: "block size-full",
                            children: [(0, s.jsx)("path", {
                                d: "M6 14 L22 8 L42 14 L58 8 V50 L42 56 L22 50 L6 56 Z",
                                fill: "var(--f-surface)",
                                ...l
                            }), (0, s.jsx)("path", {
                                d: "M22 8 V50 M42 14 V56",
                                ...a,
                                strokeWidth: 2
                            }), (0, s.jsx)("path", {
                                d: "M12 44 Q22 30 32 36 T52 22",
                                fill: "none",
                                stroke: "var(--f-accent)",
                                strokeWidth: "2.6",
                                strokeDasharray: "3 4",
                                strokeLinecap: "round"
                            }), (0, s.jsx)("path", {
                                d: "M52 14 q-6 0 -6 6 q0 5 6 12 q6 -7 6 -12 q0 -6 -6 -6 Z",
                                fill: "var(--f-accent)",
                                ...a,
                                strokeWidth: 2
                            })]
                        })
                }
            }

            function w({
                zipped: r
            }) {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 170 180",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, s.jsx)("path", {
                        d: "M30 60 Q22 150 40 170 H130 Q148 150 140 60 Z",
                        fill: "var(--f-accent)",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M58 40 Q85 14 112 40",
                        fill: "none",
                        ...l,
                        strokeWidth: 6
                    }), r ? (0, s.jsxs)("g", {
                        children: [(0, s.jsx)("path", {
                            d: "M28 62 Q85 30 142 62 Q140 78 85 78 Q30 78 28 62 Z",
                            fill: "var(--prrt-shirtB)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M40 66 Q85 50 130 66",
                            fill: "none",
                            stroke: "var(--f-fg)",
                            strokeWidth: "2.5",
                            strokeDasharray: "4 4"
                        }), (0, s.jsx)("circle", {
                            cx: "128",
                            cy: "68",
                            r: "4",
                            fill: "var(--prrt-glow)",
                            ...a
                        })]
                    }) : (0, s.jsxs)("g", {
                        children: [(0, s.jsx)("ellipse", {
                            cx: "85",
                            cy: "62",
                            rx: "56",
                            ry: "16",
                            fill: "var(--prrt-tyre)",
                            ...l
                        }), (0, s.jsx)("path", {
                            d: "M30 60 Q24 40 46 44 M140 60 Q146 40 124 44",
                            fill: "none",
                            ...l
                        })]
                    }), (0, s.jsx)("rect", {
                        x: "46",
                        y: "104",
                        width: "78",
                        height: "52",
                        rx: "14",
                        fill: "var(--prrt-scooter)",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M52 116 H118",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5",
                        strokeDasharray: "4 4"
                    }), (0, s.jsx)("path", {
                        d: "M36 80 V160 M134 80 V160",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2.5",
                        opacity: "0.35"
                    })]
                })
            }

            function b({
                exprA: r,
                exprB: e
            }) {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 320 200",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, s.jsx)("path", {
                        d: "M0 18 Q160 52 320 18",
                        fill: "none",
                        stroke: "var(--f-fg)",
                        strokeWidth: "1.6"
                    }), [30, 70, 110, 150, 190, 230, 270, 300].map((r, e) => (0, s.jsx)("circle", {
                        className: `prrt-bulb prrt-bulb-${e%3}`,
                        cx: r,
                        cy: (18 + 34 * Math.sin(r / 320 * Math.PI)).toFixed(2),
                        r: "5",
                        fill: e % 2 ? "var(--prrt-glow)" : "var(--f-accent)",
                        stroke: "var(--f-fg)",
                        strokeWidth: "1.6"
                    }, r)), (0, s.jsx)("g", {
                        transform: "translate(96 92)",
                        children: (0, s.jsx)(o, {
                            who: "a",
                            expr: r,
                            arm: "hold"
                        })
                    }), (0, s.jsx)("g", {
                        transform: "translate(224 92)",
                        children: (0, s.jsx)("g", {
                            transform: "scale(-1 1)",
                            children: (0, s.jsx)(o, {
                                who: "b",
                                expr: e,
                                arm: "hold"
                            })
                        })
                    }), [128, 192].map(r => (0, s.jsxs)("g", {
                        children: [(0, s.jsx)("path", {
                            d: `M${r-9} 128 L${r-7} 146 H${r+7} L${r+9} 128 Z`,
                            fill: "var(--prrt-kulhad)",
                            ...a
                        }), (0, s.jsx)("path", {
                            d: `M${r-3} 122 q-3 -5 0 -10 M${r+4} 122 q-3 -5 0 -10`,
                            className: "prrt-steam",
                            fill: "none",
                            stroke: "var(--f-fg)",
                            strokeWidth: "1.8",
                            strokeLinecap: "round",
                            opacity: "0.5"
                        })]
                    }, r)), (0, s.jsx)("rect", {
                        x: "40",
                        y: "146",
                        width: "240",
                        height: "16",
                        rx: "4",
                        fill: "var(--prrt-trunk)",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M58 162 L52 198 M262 162 L268 198",
                        ...l,
                        strokeWidth: 6
                    }), (0, s.jsx)("path", {
                        d: "M150 140 Q160 132 170 140 L168 146 H152 Z",
                        fill: "var(--f-surface)",
                        ...a
                    })]
                })
            }

            function W() {
                return (0, s.jsxs)("g", {
                    children: [(0, s.jsx)("path", {
                        d: "M20 110 A90 90 0 0 1 200 110 Z",
                        fill: "var(--f-surface)",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M32 110 A78 78 0 0 1 55 55",
                        fill: "none",
                        stroke: "var(--prrt-hill)",
                        strokeWidth: "14"
                    }), (0, s.jsx)("path", {
                        d: "M55 55 A78 78 0 0 1 110 32",
                        fill: "none",
                        stroke: "var(--prrt-glow)",
                        strokeWidth: "14"
                    }), (0, s.jsx)("path", {
                        d: "M110 32 A78 78 0 0 1 165 55",
                        fill: "none",
                        stroke: "var(--prrt-truck)",
                        strokeWidth: "14"
                    }), (0, s.jsx)("path", {
                        d: "M165 55 A78 78 0 0 1 188 110",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "14"
                    }), (0, s.jsx)("path", {
                        d: "M180 92 q8 -6 6 -16 q-6 4 -8 10 q-4 -4 -2 -10 q-8 6 -4 16 Z",
                        fill: "var(--f-accent)",
                        ...a,
                        strokeWidth: 1.6
                    })]
                })
            }

            function L() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 320 210",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [
                        [
                            [24, 20],
                            [70, 44],
                            [120, 14],
                            [210, 30],
                            [262, 12],
                            [296, 50],
                            [168, 46]
                        ].map(([r, e], t) => (0, s.jsx)("path", {
                            className: `prrt-star prrt-star-${t%3}`,
                            d: `M${r} ${e-5} L${r+1.6} ${e-1.6} L${r+5} ${e} L${r+1.6} ${e+1.6} L${r} ${e+5} L${r-1.6} ${e+1.6} L${r-5} ${e} L${r-1.6} ${e-1.6} Z`,
                            fill: "var(--prrt-glow)"
                        }, r)), (0, s.jsx)("path", {
                            d: "M0 160 Q160 140 320 160 V210 H0 Z",
                            fill: "var(--prrt-hill)",
                            ...l
                        }), (0, s.jsx)("g", {
                            transform: "translate(62 104)",
                            children: (0, s.jsx)(o, {
                                who: "a",
                                expr: "soft",
                                arm: "rest"
                            })
                        }), (0, s.jsx)("g", {
                            transform: "translate(258 104)",
                            children: (0, s.jsx)("g", {
                                transform: "scale(-1 1)",
                                children: (0, s.jsx)(o, {
                                    who: "b",
                                    expr: "soft",
                                    arm: "rest"
                                })
                            })
                        }), (0, s.jsxs)("g", {
                            className: "prrt-fire",
                            children: [(0, s.jsx)("path", {
                                className: "prrt-flame prrt-flame-0",
                                d: "M160 176 C132 170 136 132 152 116 C150 132 160 136 162 124 C166 104 156 92 160 80 C186 100 196 140 184 164 C180 172 172 176 160 176 Z",
                                fill: "var(--f-accent)",
                                ...a
                            }), (0, s.jsx)("path", {
                                className: "prrt-flame prrt-flame-1",
                                d: "M160 174 C146 170 144 148 154 136 C156 146 162 148 164 140 C170 128 166 120 168 112 C182 130 184 156 176 168 C172 172 166 174 160 174 Z",
                                fill: "var(--prrt-truck)"
                            }), (0, s.jsx)("path", {
                                className: "prrt-flame prrt-flame-2",
                                d: "M160 172 C152 168 152 156 158 150 C160 156 164 156 166 150 C172 158 170 168 166 170 Z",
                                fill: "var(--prrt-glow)"
                            })]
                        }), (0, s.jsx)("path", {
                            d: "M126 186 L194 166 M126 166 L194 186",
                            ...l,
                            strokeWidth: 11,
                            stroke: "var(--prrt-trunk)"
                        }), (0, s.jsx)("path", {
                            d: "M126 186 L194 166 M126 166 L194 186",
                            fill: "none",
                            ...a,
                            strokeWidth: 2
                        })
                    ]
                })
            }

            function Q() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 90 40",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, s.jsx)("rect", {
                        x: "8",
                        y: "10",
                        width: "72",
                        height: "20",
                        rx: "10",
                        fill: "var(--prrt-trunk)",
                        ...l
                    }), (0, s.jsx)("ellipse", {
                        cx: "74",
                        cy: "20",
                        rx: "7",
                        ry: "9",
                        fill: "var(--prrt-kulhad)",
                        ...a
                    }), (0, s.jsx)("path", {
                        d: "M71 20 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0",
                        fill: "none",
                        ...a,
                        strokeWidth: 1.4
                    }), (0, s.jsx)("path", {
                        d: "M20 16 H50 M28 24 H60",
                        stroke: "var(--f-fg)",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        opacity: "0.4"
                    })]
                })
            }

            function $() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 120 110",
                    "aria-hidden": !0,
                    className: "block size-full",
                    children: [(0, s.jsx)("rect", {
                        x: "0",
                        y: "0",
                        width: "120",
                        height: "110",
                        fill: "var(--prrt-sky)"
                    }), (0, s.jsx)("g", {
                        transform: "translate(38 44)",
                        children: (0, s.jsx)(o, {
                            who: "b",
                            expr: "proud",
                            arm: "hug"
                        })
                    }), (0, s.jsx)("g", {
                        transform: "translate(82 46)",
                        children: (0, s.jsx)(o, {
                            who: "a",
                            expr: "laugh",
                            arm: "wave"
                        })
                    })]
                })
            }

            function C() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 80 100",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, s.jsx)("ellipse", {
                        cx: "40",
                        cy: "18",
                        rx: "16",
                        ry: "14",
                        fill: "var(--f-accent)",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M32 30 L30 58 H50 L48 30 Z",
                        fill: "var(--prrt-trunk)",
                        ...l
                    }), (0, s.jsx)("rect", {
                        x: "10",
                        y: "58",
                        width: "60",
                        height: "18",
                        rx: "5",
                        fill: "var(--prrt-scooter)",
                        ...l
                    }), (0, s.jsx)("rect", {
                        x: "14",
                        y: "76",
                        width: "52",
                        height: "10",
                        rx: "2",
                        fill: "var(--f-accent)",
                        ...a
                    })]
                })
            }
            let B = {
                    start: [44, 344],
                    stops: [
                        [92, 252],
                        [232, 204],
                        [104, 118]
                    ],
                    end: [250, 48]
                },
                Z = ["M44 344 C40 304 70 280 92 252", "M92 252 C130 214 184 240 232 204", "M232 204 C276 168 156 150 104 118", "M104 118 C70 92 140 40 250 48"];

            function H() {
                return (0, s.jsxs)("g", {
                    children: [(0, s.jsx)("rect", {
                        x: "4",
                        y: "4",
                        width: "312",
                        height: "372",
                        rx: "6",
                        fill: "var(--f-surface)",
                        ...l
                    }), (0, s.jsx)("path", {
                        d: "M108 6 V374 M212 6 V374",
                        stroke: "var(--f-fg)",
                        strokeWidth: "1.4",
                        opacity: "0.25"
                    }), (0, s.jsx)("rect", {
                        x: "108",
                        y: "6",
                        width: "104",
                        height: "368",
                        fill: "var(--f-fg)",
                        opacity: "0.04"
                    }), (0, s.jsx)("path", {
                        d: "M6 190 H314",
                        stroke: "var(--f-fg)",
                        strokeWidth: "1.4",
                        opacity: "0.25"
                    }), (0, s.jsx)("path", {
                        d: "M6 300 C60 280 80 320 140 300 S240 250 314 270",
                        fill: "none",
                        stroke: "var(--prrt-sky)",
                        strokeWidth: "12",
                        strokeLinecap: "round"
                    }), (0, s.jsx)("path", {
                        d: "M210 330 l18 -26 l18 26 Z M232 340 l14 -20 l14 20 Z",
                        fill: "var(--prrt-hill)",
                        ...a,
                        strokeWidth: 2
                    }), (0, s.jsx)("path", {
                        d: "M20 120 l16 -24 l16 24 Z M42 132 l12 -18 l12 18 Z",
                        fill: "var(--prrt-hill)",
                        ...a,
                        strokeWidth: 2
                    }), [
                        [270, 120],
                        [286, 136],
                        [180, 330],
                        [40, 210]
                    ].map(([r, e]) => (0, s.jsxs)("g", {
                        children: [(0, s.jsx)("circle", {
                            cx: r,
                            cy: e,
                            r: "8",
                            fill: "var(--prrt-hill)",
                            ...a,
                            strokeWidth: 1.8
                        }), (0, s.jsx)("path", {
                            d: `M${r} ${e+8} V${e+14}`,
                            stroke: "var(--f-fg)",
                            strokeWidth: "2"
                        })]
                    }, `${r}-${e}`)), (0, s.jsx)("ellipse", {
                        cx: "180",
                        cy: "100",
                        rx: "26",
                        ry: "14",
                        fill: "var(--prrt-sky)",
                        ...a,
                        strokeWidth: 2
                    }), (0, s.jsx)("path", {
                        d: "M286 20 l6 12 l-6 -4 l-6 4 Z",
                        fill: "var(--f-accent)",
                        ...a,
                        strokeWidth: 1.6
                    }), (0, s.jsx)("path", {
                        d: "M286 36 V44",
                        stroke: "var(--f-fg)",
                        strokeWidth: "1.6"
                    })]
                })
            }

            function R() {
                return (0, s.jsxs)("g", {
                    children: [(0, s.jsx)("path", {
                        d: "M6 28 C4 18 12 14 22 14 L32 14 C34 20 34 26 32 28 Z",
                        fill: "var(--prrt-scooter)",
                        ...a
                    }), (0, s.jsx)("path", {
                        d: "M34 28 C32 20 34 12 38 6 L42 7 C40 14 40 22 42 28 Z",
                        fill: "var(--prrt-scooter)",
                        ...a
                    }), (0, s.jsx)("path", {
                        d: "M36 6 H46",
                        ...a
                    }), (0, s.jsx)("circle", {
                        cx: "12",
                        cy: "30",
                        r: "5",
                        fill: "var(--prrt-tyre)",
                        ...a,
                        strokeWidth: 2
                    }), (0, s.jsx)("circle", {
                        cx: "40",
                        cy: "30",
                        r: "5",
                        fill: "var(--prrt-tyre)",
                        ...a,
                        strokeWidth: 2
                    }), (0, s.jsx)("circle", {
                        cx: "22",
                        cy: "6",
                        r: "6",
                        fill: "var(--f-accent)",
                        ...a,
                        strokeWidth: 2
                    })]
                })
            }

            function V() {
                return (0, s.jsx)("svg", {
                    viewBox: "0 0 48 36",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: (0, s.jsx)(R, {})
                })
            }

            function S() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 200 200",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, s.jsx)("g", {
                        className: "prrt-rays",
                        children: Array.from({
                            length: 12
                        }, (r, e) => {
                            let t = e * Math.PI / 6,
                                l = (100 + 62 * Math.cos(t)).toFixed(2),
                                a = (100 + 62 * Math.sin(t)).toFixed(2),
                                i = (100 + 92 * Math.cos(t)).toFixed(2),
                                c = (100 + 92 * Math.sin(t)).toFixed(2);
                            return (0, s.jsx)("path", {
                                d: `M${l} ${a} L${i} ${c}`,
                                stroke: "var(--prrt-glow)",
                                strokeWidth: "7",
                                strokeLinecap: "round",
                                opacity: "0.7"
                            }, e)
                        })
                    }), (0, s.jsx)("circle", {
                        cx: "100",
                        cy: "100",
                        r: "52",
                        fill: "var(--prrt-sun)",
                        ...l
                    })]
                })
            }

            function z() {
                return (0, s.jsxs)("svg", {
                    viewBox: "0 0 150 80",
                    "aria-hidden": !0,
                    className: "block size-full overflow-visible",
                    children: [(0, s.jsx)("circle", {
                        cx: "40",
                        cy: "40",
                        r: "34",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "2.5"
                    }), (0, s.jsx)("circle", {
                        cx: "40",
                        cy: "40",
                        r: "26",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "1.5"
                    }), (0, s.jsx)("path", {
                        className: "prrt-draw",
                        pathLength: 1,
                        d: "M80 22 q10 -6 20 0 t20 0 t20 0 M80 40 q10 -6 20 0 t20 0 t20 0 M80 58 q10 -6 20 0 t20 0 t20 0",
                        fill: "none",
                        stroke: "var(--f-accent)",
                        strokeWidth: "2.5"
                    })]
                })
            }
        },
        78765: () => {},
        85941: (r, e, t) => {
            "use strict";
            t.r(e), t.d(e, {
                CampfireLogs: () => N,
                CoverScene: () => h,
                IntroSequence: () => x,
                LicenceStamp: () => w,
                PackBag: () => u,
                RevLaunch: () => v,
                RoastMeter: () => g,
                RouteMap: () => k,
                SunsetRide: () => f
            });
            var s = t(73365),
                l = t(1521),
                a = t(9421),
                i = t(87191),
                c = t(34768),
                n = t(82161);

            function d(r, e, t) {
                let s = (0, l.useRef)(null),
                    a = (0, l.useRef)(!1),
                    i = r => {
                        r.style.translate = "", delete r.dataset.dragging
                    };
                return {
                    onPointerDown(r) {
                        t || (s.current = {
                            id: r.pointerId,
                            x: r.clientX,
                            y: r.clientY,
                            moved: !1
                        }, r.currentTarget.setPointerCapture(r.pointerId))
                    },
                    onPointerMove(r) {
                        let e = s.current;
                        if (!e || e.id !== r.pointerId) return;
                        let t = r.clientX - e.x,
                            l = r.clientY - e.y;
                        !e.moved && 8 > Math.hypot(t, l) || (e.moved = !0, r.currentTarget.dataset.dragging = "", r.currentTarget.style.translate = `${Math.round(t)}px ${Math.round(l)}px`)
                    },
                    onPointerUp(t) {
                        let l = s.current;
                        s.current = null;
                        let c = t.currentTarget;
                        if (!l ? .moved) return;
                        a.current = !0;
                        let n = r.current ? .getBoundingClientRect();
                        n && t.clientX > n.left - 24 && t.clientX < n.right + 24 && t.clientY > n.top - 24 && t.clientY < n.bottom + 24 ? (delete c.dataset.dragging, e(c)) : i(c)
                    },
                    onPointerCancel(r) {
                        s.current = null, i(r.currentTarget)
                    },
                    onClick(r) {
                        if (a.current) {
                            a.current = !1;
                            return
                        }
                        t || e(r.currentTarget)
                    }
                }
            }

            function o({
                kind: r,
                moving: e,
                exprA: t,
                exprB: l,
                armB: i,
                label: c,
                truck: n,
                milestone: d,
                charm: h
            }) {
                return (0, s.jsxs)("div", {
                    className: "prrt-scene",
                    "data-scene": r,
                    ...e ? {
                        "data-moving": ""
                    } : {},
                    role: "img",
                    "aria-label": c,
                    children: [(0, s.jsx)("div", {
                        className: "prrt-sky"
                    }), "sunset" === r ? (0, s.jsx)("div", {
                        className: "prrt-sunset-sun",
                        children: (0, s.jsx)(a.d3, {})
                    }) : (0, s.jsx)("div", {
                        className: "prrt-sun"
                    }), (0, s.jsx)(a.Es, {
                        className: "prrt-cloud prrt-cloud-0"
                    }), (0, s.jsx)(a.Es, {
                        className: "prrt-cloud prrt-cloud-1"
                    }), (0, s.jsx)("div", {
                        className: "prrt-layer prrt-far",
                        children: (0, s.jsxs)("div", {
                            className: "prrt-strip prrt-strip-far",
                            children: [(0, s.jsx)(a.gY, {}), (0, s.jsx)(a.gY, {})]
                        })
                    }), (0, s.jsx)("div", {
                        className: "prrt-layer prrt-mid",
                        children: (0, s.jsxs)("div", {
                            className: "prrt-strip prrt-strip-mid",
                            children: [(0, s.jsx)(a.qW, {}), (0, s.jsx)(a.qW, {})]
                        })
                    }), (0, s.jsxs)("div", {
                        className: "prrt-layer prrt-road",
                        children: [(0, s.jsx)(a.Ww, {}), (0, s.jsx)("div", {
                            className: "prrt-dashes",
                            children: (0, s.jsxs)("div", {
                                className: "prrt-strip prrt-strip-dash",
                                children: [(0, s.jsx)(a.dV, {}), (0, s.jsx)(a.dV, {})]
                            })
                        })]
                    }), d ? (0, s.jsxs)("div", {
                        className: "prrt-milestone",
                        children: [(0, s.jsx)(a.fl, {}), (0, s.jsx)("div", {
                            className: "prrt-milestone-text",
                            children: d
                        })]
                    }) : null, n ? (0, s.jsxs)("div", {
                        className: "prrt-truck",
                        children: [(0, s.jsx)(a.eM, {}), (0, s.jsx)("div", {
                            className: "prrt-truck-text",
                            children: n
                        })]
                    }) : null, (0, s.jsxs)("div", {
                        className: "prrt-rider",
                        children: [(0, s.jsx)(a.ai, {
                            exprA: t,
                            exprB: l,
                            armB: i
                        }), h ? (0, s.jsx)("span", {
                            className: "prrt-charm",
                            children: h
                        }) : null]
                    }), (0, s.jsx)("div", {
                        className: "prrt-layer prrt-near",
                        children: (0, s.jsxs)("div", {
                            className: "prrt-strip prrt-strip-near",
                            children: [(0, s.jsx)(a.vY, {}), (0, s.jsx)(a.vY, {})]
                        })
                    })]
                })
            }

            function h({
                label: r,
                truck: e,
                milestone: t
            }) {
                return (0, s.jsx)(o, {
                    kind: "cover",
                    moving: !1,
                    exprA: "happy",
                    exprB: "laugh",
                    armB: "wave",
                    label: r,
                    truck: e,
                    milestone: t
                })
            }

            function f({
                label: r
            }) {
                let e = "edit" === (0, c.useMode)();
                return (0, s.jsx)(o, {
                    kind: "sunset",
                    moving: !e,
                    exprA: "laugh",
                    exprB: "happy",
                    armB: "wave",
                    label: r
                })
            }

            function x({
                skip: r,
                children: e
            }) {
                let t = "edit" === (0, c.useMode)(),
                    a = (0, l.useRef)(null),
                    [n, d] = (0, l.useState)(!1);
                return (0, i.useReplaySignal)(a, () => d(!1)), (0, s.jsxs)("div", {
                    ref: a,
                    className: "prrt-seq",
                    ...n ? {
                        "data-skip": ""
                    } : {},
                    onPointerDown: () => {
                        t || d(!0)
                    },
                    children: [t ? null : (0, s.jsx)("button", {
                        type: "button",
                        className: "prrt-skip",
                        onClick: () => d(!0),
                        children: r
                    }), e]
                })
            }
            t(78765);
            let p = ["thermos", "shades", "chips", "cassette", "map"];

            function j({
                kind: r,
                label: e,
                name: t,
                packed: l,
                target: i,
                onPack: n
            }) {
                let o = "edit" === (0, c.useMode)(),
                    h = d(i, n, o || l);
                return (0, s.jsxs)("li", {
                    className: "prrt-pack-slot",
                    children: [(0, s.jsx)("button", {
                        type: "button",
                        className: "prrt-pack-item",
                        "aria-label": t,
                        disabled: l,
                        tabIndex: o ? -1 : void 0,
                        ...l ? {
                            "data-packed": ""
                        } : {},
                        ...h,
                        children: (0, s.jsx)("span", {
                            className: "prrt-pack-art",
                            children: (0, s.jsx)(a.eC, {
                                kind: r
                            })
                        })
                    }), (0, s.jsx)("span", {
                        className: "prrt-pack-label",
                        children: e
                    })]
                })
            }

            function u({
                labels: r,
                names: e,
                sticker: t,
                bagLabel: d,
                hint: o,
                done: h
            }) {
                let f = "edit" === (0, c.useMode)(),
                    x = (0, n.useFolioSound)(),
                    v = (0, l.useRef)(null),
                    k = (0, l.useRef)(null),
                    [m, g] = (0, l.useState)(() => p.map(() => !1)),
                    [M, y] = (0, l.useState)(0);
                (0, i.useReplaySignal)(v, () => {
                    v.current ? .querySelectorAll(".prrt-pack-item").forEach(r => {
                        r.style.translate = ""
                    }), g(p.map(() => !1))
                });
                let N = m.filter(Boolean).length,
                    w = !f && N === p.length;
                return (0, s.jsxs)("div", {
                    ref: v,
                    className: "prrt-pack",
                    ...w || f ? {
                        "data-done": ""
                    } : {},
                    children: [(0, s.jsx)("ul", {
                        className: "prrt-pack-row",
                        children: p.map((t, l) => (0, s.jsx)(j, {
                            kind: t,
                            label: r[l],
                            name: e[l] ? ? "",
                            packed: !f && m[l],
                            target: k,
                            onPack: r => {
                                f || m[l] || (x.unlock(r), function(r, e) {
                                    if (!e) return;
                                    let t = r.getBoundingClientRect(),
                                        s = e.getBoundingClientRect();
                                    r.style.setProperty("--prrt-fx", `${Math.round(s.left+s.width/2-(t.left+t.width/2))}px`), r.style.setProperty("--prrt-fy", `${Math.round(s.top+.35*s.height-(t.top+t.height/2))}px`)
                                }(r, k.current), x.playEffect(N + 1 === p.length ? "win" : "pop"), g(r => r.map((r, e) => e === l || r)), y(r => r + 1))
                            }
                        }, t))
                    }), (0, s.jsx)("div", {
                        ref: k,
                        className: "prrt-bag",
                        role: "img",
                        "aria-label": d,
                        "data-bump": M % 2,
                        children: (0, s.jsxs)("div", {
                            className: "prrt-bag-inner",
                            children: [(0, s.jsx)(a.HW, {
                                zipped: w
                            }), (0, s.jsx)("span", {
                                className: "prrt-sticker",
                                children: t
                            })]
                        })
                    }), (0, s.jsx)("div", {
                        className: "prrt-pack-meter",
                        "aria-hidden": !0,
                        children: p.map((r, e) => (0, s.jsx)("i", { ...f || m[e] ? {
                                "data-on": ""
                            } : {}
                        }, r))
                    }), (0, s.jsx)("div", {
                        className: "prrt-pack-hint",
                        children: o
                    }), (0, s.jsx)("div", {
                        className: "prrt-reveal",
                        children: h
                    })]
                })
            }

            function v({
                label: r,
                revButton: e,
                hint: t,
                charm: a,
                done: d
            }) {
                let h = "edit" === (0, c.useMode)(),
                    f = (0, n.useFolioSound)(),
                    x = (0, l.useRef)(null),
                    p = (0, l.useRef)(0),
                    j = (0, l.useRef)(null),
                    [u, k] = (0, l.useState)(0),
                    m = !h && u >= 3,
                    g = () => {
                        j.current && clearInterval(j.current), j.current = null
                    };
                (0, l.useEffect)(() => g, []), (0, i.useReplaySignal)(x, () => {
                    g(), p.current = 0, k(0)
                });
                let M = r => {
                    if (h || p.current >= 3) return;
                    f.unlock(r);
                    let e = p.current + 1;
                    p.current = e, k(e), f.playEffect(e >= 3 ? "horn" : "charge"), e >= 3 && g()
                };
                return (0, s.jsxs)("div", {
                    ref: x,
                    className: "prrt-rev",
                    "data-rev": Math.min(u, 3),
                    ...m || h ? {
                        "data-done": ""
                    } : {},
                    children: [(0, s.jsx)(o, {
                        kind: "ride",
                        moving: m,
                        exprA: m ? "laugh" : "happy",
                        exprB: m ? "laugh" : u > 0 ? "shock" : "happy",
                        armB: m ? "wave" : "hug",
                        label: r,
                        charm: a
                    }), (0, s.jsx)("div", {
                        className: "prrt-rev-meter",
                        "aria-hidden": !0,
                        children: (0, s.jsx)("i", {
                            style: {
                                transform: `scaleX(${h?1:Math.min(u,3)/3})`
                            }
                        })
                    }), h || !m ? (0, s.jsx)("button", {
                        type: "button",
                        className: "prrt-rev-btn",
                        tabIndex: h ? -1 : void 0,
                        onPointerDown: r => {
                            if (h) return;
                            let e = r.currentTarget;
                            g(), j.current = setInterval(() => M(e), 380)
                        },
                        onPointerUp: g,
                        onPointerLeave: g,
                        onPointerCancel: g,
                        onContextMenu: r => r.preventDefault(),
                        onClick: r => M(r.currentTarget),
                        children: e
                    }) : null, (0, s.jsx)("div", {
                        className: "prrt-rev-hint",
                        children: t
                    }), (0, s.jsx)("div", {
                        className: "prrt-reveal",
                        children: d
                    })]
                })
            }

            function k({
                pins: r,
                pinNames: e,
                cards: t,
                start: d,
                end: o,
                hint: h,
                done: f
            }) {
                let x = "edit" === (0, c.useMode)(),
                    p = (0, n.useFolioSound)(),
                    j = (0, l.useRef)(null),
                    u = `prrt-route-${(0,l.useId)().replace(/[^a-zA-Z0-9_-]/g,"")}`,
                    [v, m] = (0, l.useState)(0),
                    [g, M] = (0, l.useState)(null);
                (0, i.useReplaySignal)(j, () => {
                    m(0), M(null)
                });
                let y = x ? 3 : v,
                    N = y + +(y >= 3),
                    w = 0 === y ? a.BQ.start : y >= 3 && !x && null === g ? a.BQ.end : a.BQ.stops[Math.max(0, g ? ? y - 1)];
                return (0, s.jsxs)("div", {
                    ref: j,
                    className: "prrt-route",
                    ...y >= 3 ? {
                        "data-done": ""
                    } : {},
                    children: [(0, s.jsxs)("div", {
                        className: "prrt-map",
                        children: [(0, s.jsxs)("svg", {
                            viewBox: "0 0 320 380",
                            "aria-hidden": !0,
                            className: "block size-full overflow-visible",
                            children: [(0, s.jsx)(a.dI, {}), (0, s.jsx)("mask", {
                                id: u,
                                maskUnits: "userSpaceOnUse",
                                x: "0",
                                y: "0",
                                width: "320",
                                height: "380",
                                children: a.S7.map((r, e) => (0, s.jsx)("path", {
                                    className: "prrt-leg",
                                    ...e < N ? {
                                        "data-on": ""
                                    } : {},
                                    d: r,
                                    pathLength: 1,
                                    fill: "none",
                                    stroke: "#ffffff",
                                    strokeWidth: "16",
                                    strokeLinecap: "round"
                                }, r))
                            }), (0, s.jsx)("path", {
                                d: a.S7.join(" "),
                                fill: "none",
                                stroke: "var(--f-fg)",
                                strokeWidth: "2",
                                strokeDasharray: "2 8",
                                opacity: "0.18"
                            }), (0, s.jsx)("path", {
                                d: a.S7.join(" "),
                                fill: "none",
                                stroke: "var(--f-accent)",
                                strokeWidth: "5",
                                strokeDasharray: "1 10",
                                strokeLinecap: "round",
                                mask: `url(#${u})`
                            }), (0, s.jsx)("circle", {
                                cx: a.BQ.start[0],
                                cy: a.BQ.start[1],
                                r: "7",
                                fill: "var(--f-fg)"
                            }), (0, s.jsx)("path", {
                                d: "M244 48 l6 -16 l6 16 Z",
                                fill: "var(--f-accent)",
                                stroke: "var(--f-fg)",
                                strokeWidth: "2"
                            }), (0, s.jsx)("g", {
                                className: "prrt-marker",
                                style: {
                                    transform: `translate(${w[0]}px, ${w[1]}px)`
                                },
                                children: (0, s.jsx)("g", {
                                    className: "prrt-marker-bob",
                                    children: (0, s.jsx)("svg", {
                                        x: "-20",
                                        y: "-34",
                                        width: "40",
                                        height: "30",
                                        viewBox: "0 0 48 36",
                                        overflow: "visible",
                                        children: (0, s.jsx)(a.Xe, {})
                                    })
                                })
                            })]
                        }), (0, s.jsx)("span", {
                            className: "prrt-map-tag prrt-map-start",
                            children: d
                        }), (0, s.jsx)("span", {
                            className: "prrt-map-tag prrt-map-end",
                            children: o
                        }), a.BQ.stops.map(([t, l], a) => (0, s.jsxs)("button", {
                            type: "button",
                            className: "prrt-pin",
                            style: {
                                left: `${(t/320*100).toFixed(2)}%`,
                                top: `${(l/380*100).toFixed(2)}%`
                            },
                            "aria-label": e[a],
                            tabIndex: x ? -1 : void 0,
                            disabled: !x && a > v,
                            ...a === v && !x ? {
                                "data-next": ""
                            } : {},
                            ...a < y ? {
                                "data-seen": ""
                            } : {},
                            onClick: r => {
                                var e;
                                return e = r.currentTarget, void(!x && !(a > v) && (p.unlock(e), p.playEffect(a === v ? a + 1 === 3 ? "win" : "reveal" : "tap"), a === v && m(a + 1), M(a)))
                            },
                            children: [(0, s.jsx)("span", {
                                className: "prrt-pin-dot",
                                children: a + 1
                            }), (0, s.jsx)("span", {
                                className: "prrt-pin-label",
                                children: r[a]
                            })]
                        }, `${t}-${l}`))]
                    }), (0, s.jsx)("div", {
                        className: "prrt-route-hint",
                        children: h
                    }), x ? (0, s.jsx)("div", {
                        className: "prrt-cards",
                        children: t.map((r, e) => (0, s.jsx)("div", {
                            className: "prrt-card-slot",
                            children: r
                        }, e))
                    }) : null !== g ? (0, s.jsx)("div", {
                        className: "prrt-card-slot prrt-card-pop",
                        children: t[g]
                    }, g) : null, (0, s.jsx)("div", {
                        className: "prrt-reveal",
                        children: f
                    })]
                })
            }
            let m = [
                ["happy", "happy"],
                ["laugh", "shock"],
                ["laugh", "laugh"],
                ["proud", "shock"],
                ["soft", "soft"]
            ];

            function g({
                levels: r,
                lines: e,
                dialLabel: t,
                roastButton: d,
                hint: o,
                done: h
            }) {
                let f = "edit" === (0, c.useMode)(),
                    x = (0, n.useFolioSound)(),
                    p = (0, l.useRef)(null),
                    j = (0, l.useRef)(null),
                    u = (0, l.useRef)(!1),
                    [v, k] = (0, l.useState)(0),
                    [M, y] = (0, l.useState)(!1);
                (0, i.useReplaySignal)(p, () => {
                    k(0), y(!1)
                });
                let N = f ? 4 : v,
                    w = m[N],
                    b = -80 + 40 * N,
                    W = (r, e) => {
                        if (f) return;
                        let t = Math.max(0, Math.min(4, r));
                        t !== v && (x.unlock(e), x.playEffect(4 === t ? "win" : t > v ? "tick" : "tap"), k(t), 4 === t && y(!0))
                    };
                return (0, s.jsxs)("div", {
                    ref: p,
                    className: "prrt-roast",
                    "data-level": N,
                    ...M || f ? {
                        "data-done": ""
                    } : {},
                    children: [(0, s.jsx)("div", {
                        className: "prrt-dhaba",
                        children: (0, s.jsx)(a.$w, {
                            exprA: w[0],
                            exprB: w[1]
                        })
                    }), f ? (0, s.jsx)("ol", {
                        className: "prrt-roast-list",
                        children: r.map((r, t) => (0, s.jsxs)("li", {
                            className: "prrt-bubble",
                            children: [(0, s.jsx)("span", {
                                className: "prrt-roast-level",
                                children: r
                            }), e[t]]
                        }, t))
                    }) : N > 0 ? (0, s.jsxs)("div", {
                        className: "prrt-bubble prrt-bubble-pop",
                        "aria-live": "polite",
                        children: [(0, s.jsx)("span", {
                            className: "prrt-roast-level",
                            children: r[N - 1]
                        }), e[N - 1]]
                    }, N) : null, (0, s.jsx)("button", {
                        type: "button",
                        className: "prrt-dial",
                        "aria-label": t,
                        tabIndex: f ? -1 : void 0,
                        onPointerDown: r => {
                            f || (j.current = r.pointerId, u.current = !1, r.currentTarget.setPointerCapture(r.pointerId))
                        },
                        onPointerMove: r => {
                            let e, t, s;
                            if (j.current !== r.pointerId) return;
                            let l = (t = (e = r.currentTarget.getBoundingClientRect()).left + e.width / 2, s = e.top + e.height * (110 / 124), Math.round((Math.max(-90, Math.min(90, 180 * Math.atan2(r.clientX - t, s - r.clientY) / Math.PI)) + 80) / 40));
                            l !== v && (u.current = !0, W(l, r.currentTarget))
                        },
                        onPointerUp: () => {
                            j.current = null
                        },
                        onPointerCancel: () => {
                            j.current = null
                        },
                        onClick: r => {
                            if (u.current) {
                                u.current = !1;
                                return
                            }
                            W(v >= 4 ? 1 : v + 1, r.currentTarget)
                        },
                        children: (0, s.jsxs)("svg", {
                            viewBox: "0 0 220 124",
                            "aria-hidden": !0,
                            className: "block size-full overflow-visible",
                            children: [(0, s.jsx)(a.dO, {}), (0, s.jsxs)("g", {
                                transform: "translate(110 110)",
                                children: [(0, s.jsx)("g", {
                                    className: "prrt-needle",
                                    style: {
                                        transform: `rotate(${b}deg)`
                                    },
                                    children: (0, s.jsx)("path", {
                                        d: "M-5 0 L0 -76 L5 0 Z",
                                        fill: "var(--f-fg)"
                                    })
                                }), (0, s.jsx)("circle", {
                                    r: "9",
                                    fill: "var(--f-accent)",
                                    stroke: "var(--f-fg)",
                                    strokeWidth: "3"
                                })]
                            })]
                        })
                    }), f ? null : (0, s.jsx)("button", {
                        type: "button",
                        className: "prrt-small-btn",
                        onClick: r => W(v >= 4 ? 1 : v + 1, r.currentTarget),
                        children: d
                    }), (0, s.jsx)("div", {
                        className: "prrt-roast-hint",
                        children: o
                    }), (0, s.jsx)("div", {
                        className: "prrt-reveal",
                        children: h
                    })]
                })
            }
            let M = [
                [-14, 0, 5],
                [10, 380, 4],
                [-4, 760, 6],
                [18, 1140, 4],
                [-20, 1520, 5],
                [6, 1900, 4],
                [-10, 2280, 6],
                [14, 2660, 5]
            ];

            function y({
                target: r,
                onDrop: e,
                disabled: t,
                label: l
            }) {
                let i = "edit" === (0, c.useMode)(),
                    n = d(r, e, t || i);
                return (0, s.jsx)("button", {
                    type: "button",
                    className: "prrt-log",
                    "aria-label": l,
                    disabled: t && !i,
                    tabIndex: i ? -1 : void 0,
                    ...n,
                    children: (0, s.jsx)(a.kC, {})
                })
            }

            function N({
                confessions: r,
                logLabel: e,
                logButton: t,
                hint: d,
                done: o
            }) {
                let h = "edit" === (0, c.useMode)(),
                    f = (0, n.useFolioSound)(),
                    x = (0, l.useRef)(null),
                    p = (0, l.useRef)(null),
                    [j, u] = (0, l.useState)(0);
                (0, i.useReplaySignal)(x, () => u(0));
                let v = h ? 3 : j,
                    k = r => {
                        h || j >= 3 || (f.unlock(r), f.playEffect(j + 1 === 3 ? "reveal" : "puff"), r instanceof HTMLElement && (r.style.translate = ""), u(r => Math.min(3, r + 1)))
                    };
                return (0, s.jsxs)("div", {
                    ref: x,
                    className: "prrt-camp",
                    "data-fire": v,
                    ...v >= 3 ? {
                        "data-done": ""
                    } : {},
                    children: [(0, s.jsxs)("div", {
                        className: "prrt-campfire",
                        children: [(0, s.jsx)(a.y0, {}), (0, s.jsx)("div", {
                            ref: p,
                            className: "prrt-fire-zone",
                            "aria-hidden": !0,
                            children: M.map(([r, e, t], l) => (0, s.jsx)("i", {
                                className: "prrt-spark",
                                style: {
                                    "--x": `${r}px`,
                                    "--d": `${e}ms`,
                                    "--s": `${t}px`
                                }
                            }, l))
                        }), v < 3 ? (0, s.jsx)("div", {
                            className: "prrt-log-pile",
                            children: (0, s.jsx)(y, {
                                target: p,
                                onDrop: k,
                                disabled: v >= 3,
                                label: e
                            }, j)
                        }) : null]
                    }), (0, s.jsx)("ol", {
                        className: "prrt-confessions",
                        children: r.slice(0, v).map((r, e) => (0, s.jsx)("li", {
                            className: "prrt-confession",
                            ...e === v - 1 && !h ? {
                                "data-new": ""
                            } : {},
                            children: r
                        }, e))
                    }), h || v >= 3 ? null : (0, s.jsx)("button", {
                        type: "button",
                        className: "prrt-small-btn",
                        onClick: r => k(r.currentTarget),
                        children: t
                    }), (0, s.jsx)("div", {
                        className: "prrt-camp-hint",
                        children: d
                    }), (0, s.jsx)("div", {
                        className: "prrt-reveal",
                        children: o
                    })]
                })
            }

            function w({
                card: r,
                mark: e,
                stampLabel: t,
                stampButton: o,
                hint: h,
                done: f
            }) {
                let x = "edit" === (0, c.useMode)(),
                    p = (0, n.useFolioSound)(),
                    j = (0, l.useRef)(null),
                    u = (0, l.useRef)(null),
                    [v, k] = (0, l.useState)(!1);
                (0, i.useReplaySignal)(j, () => k(!1));
                let m = x || v,
                    g = r => {
                        x || v || (p.unlock(r), p.playEffect("stamp"), r instanceof HTMLElement && (r.style.translate = ""), k(!0))
                    },
                    M = d(u, g, x || v);
                return (0, s.jsxs)("div", {
                    ref: j,
                    className: "prrt-licence",
                    ...m ? {
                        "data-done": ""
                    } : {},
                    children: [(0, s.jsxs)("div", {
                        ref: u,
                        className: "prrt-card",
                        ...v ? {
                            "data-slam": ""
                        } : {},
                        children: [(0, s.jsx)("div", {
                            className: "prrt-card-photo",
                            children: (0, s.jsx)(a.Vf, {})
                        }), (0, s.jsx)("div", {
                            className: "prrt-card-words",
                            children: r
                        }), m ? (0, s.jsx)("div", {
                            className: "prrt-stamp-mark",
                            children: e
                        }) : null]
                    }), m ? null : (0, s.jsxs)("div", {
                        className: "prrt-stamp-row",
                        children: [(0, s.jsx)("button", {
                            type: "button",
                            className: "prrt-stamp",
                            "aria-label": t,
                            tabIndex: x ? -1 : void 0,
                            ...M,
                            children: (0, s.jsx)(a._X, {})
                        }), (0, s.jsx)("button", {
                            type: "button",
                            className: "prrt-small-btn",
                            onClick: r => g(r.currentTarget),
                            children: o
                        })]
                    }), (0, s.jsx)("div", {
                        className: "prrt-stamp-hint",
                        children: h
                    }), (0, s.jsx)("div", {
                        className: "prrt-reveal",
                        children: f
                    })]
                })
            }
        }
    }
]);