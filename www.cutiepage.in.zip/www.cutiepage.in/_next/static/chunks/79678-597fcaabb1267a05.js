"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [79678], {
        14578: (e, t, n) => {
            n.d(t, {
                f: () => l,
                p: () => s
            });
            let i = [/Instagram/i, /FBAN|FBAV|FB_IAB|FB4A|FBIOS/, /\bMessenger(?:Lite)?\b/i, /musical_ly|BytedanceWebview|\bTikTok\b/i, /Snapchat/i, /\bLine\//, /\bTwitter\b/i, /LinkedInApp/i, /\bPinterest\b/i, /; wv\)/],
                a = /\b(iPhone|iPad|iPod)\b.*AppleWebKit(?!.*Safari\/)/;

            function l(e) {
                return !!e && (!!i.some(t => t.test(e)) || a.test(e))
            }

            function s(e, t) {
                if (!t || !e.startsWith("https://")) return null;
                let n = e.slice(8);
                return /Android/i.test(t) ? `intent://${n}#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=${encodeURIComponent(e)};end` : /\b(iPhone|iPad|iPod)\b/.test(t) ? `x-safari-https://${n}` : null
            }
        },
        23408: (e, t, n) => {
            n.d(t, {
                Ij: () => g,
                o4: () => y
            });
            var i = n(73365),
                a = n(1521),
                l = n(2911),
                s = n(24583),
                r = n(54582),
                o = n(88786),
                c = n(60151),
                d = n(37809),
                u = n(54872),
                p = n(69034);
            async function m() {
                let {
                    createSupabaseBrowserClient: e
                } = await Promise.all([n.e(74339), n.e(16937), n.e(88681)]).then(n.bind(n, 11062));
                return e()
            }
            let h = "cp_otp_pending",
                f = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            function x() {
                try {
                    let e = localStorage.getItem(h);
                    if (!e) return null;
                    let t = JSON.parse(e);
                    if ("string" != typeof t ? .email || "number" != typeof t.sentAt || Date.now() - t.sentAt > 6e5) return localStorage.removeItem(h), null;
                    return t
                } catch {
                    return null
                }
            }

            function g() {
                return null !== x()
            }

            function b(e) {
                try {
                    e ? localStorage.setItem(h, JSON.stringify(e)) : localStorage.removeItem(h)
                } catch {}
            }

            function y({
                nextPath: e,
                surface: t,
                inAppBrowser: n,
                emphasis: h = "secondary",
                onVerifyStart: g,
                onVerifyEnd: w,
                onCodeSent: j,
                onSignedIn: v,
                presetEmail: k,
                onChangeContact: S,
                onSendFailed: N,
                captcha: C = !0,
                onEngage: _
            }) {
                let A = (0, c.u)(e),
                    [I, F] = (0, a.useState)("email"),
                    [P, E] = (0, a.useState)(k ? ? ""),
                    [O, B] = (0, a.useState)(""),
                    [W, $] = (0, a.useState)(null),
                    [M, z] = (0, a.useState)(!1),
                    [T, D] = (0, a.useState)("idle"),
                    [R, L] = (0, a.useState)(null),
                    [J, G] = (0, a.useState)(null),
                    [U, q] = (0, a.useState)(() => Date.now()),
                    V = (0, a.useRef)(null),
                    Z = (0, a.useRef)(null),
                    Y = (0, a.useRef)(null),
                    H = (0, a.useRef)(!1),
                    K = (0, a.useRef)(null),
                    Q = (0, a.useRef)(!1),
                    X = (0, a.useCallback)(() => (Y.current ? ? = m().catch(e => {
                        throw Y.current = null, e
                    }), Y.current), []),
                    ee = (0, a.useCallback)((e, i = {}) => {
                        (0, d.G4)({
                            name: e,
                            props: {
                                surface: t,
                                in_app_browser: n,
                                ...i
                            }
                        })
                    }, [t, n]);
                (0, a.useEffect)(() => {
                    let e = x();
                    if (e && (!k || e.email === k)) {
                        E(e.email), G(e.sentAt), F("code");
                        return
                    }
                    k && !Q.current && (Q.current = !0, ei(!1))
                }, []);
                let et = J ? Math.max(0, 60 - Math.floor((U - J) / 1e3)) : 0;

                function en(e, t) {
                    let i = (0, r.CA)(e, n);
                    return (ee("auth_otp_failed", {
                        stage: t,
                        code: i.kind
                    }), "banned" === i.kind) ? window.location.assign("/login?error=auth_callback_failed&reason=user_banned") : L(i.message), i.kind
                }
                async function ei(e, t = W) {
                    _ ? .();
                    let i = P.trim().toLowerCase();
                    if (!f.test(i)) return void L("Please enter a valid email address.");
                    if (!t) return M ? void L(null) : (K.current = e, L(null), void D("sending"));
                    D("sending"), L(null);
                    try {
                        let {
                            error: n
                        } = await (await X()).auth.signInWithOtp({
                            email: i,
                            options: {
                                shouldCreateUser: !0,
                                captchaToken: t
                            }
                        });
                        if (n) throw n;
                        let a = Date.now();
                        E(i), G(a), q(a), B(""), F("code"), j ? .(), (0, o.yR)({
                            chunks: !v
                        }), b({
                            email: i,
                            sentAt: a
                        }), ee("auth_otp_requested", {
                            resend: e
                        }), H.current = !1
                    } catch (i) {
                        let t = en(i, "send");
                        "captcha" !== t || H.current ? !e && "banned" !== t && N && N((0, r.CA)(i, n).message) : (H.current = !0, L("One moment, finishing a quick security check. Then tap the button again."))
                    } finally {
                        V.current ? .reset(), D("idle")
                    }
                }
                async function ea() {
                    let e = A;
                    for (let t = 0; t < 2; t += 1) try {
                        let t = await fetch("/api/auth/complete", {
                            method: "POST",
                            headers: {
                                "content-type": "application/json"
                            },
                            credentials: "same-origin",
                            keepalive: !0,
                            body: JSON.stringify({
                                next: A
                            })
                        });
                        if (t.ok) {
                            let n = await t.json();
                            e = (0, c.u)(n.data ? .location ? ? A);
                            break
                        }
                        if (t.status < 500 && 429 !== t.status) break
                    } catch {}
                    return e
                }
                async function el(e) {
                    if (v) {
                        b(null), (0, d.Sm)(!0), ea(), D("idle"), v();
                        return
                    }
                    D("redirecting");
                    let t = (0, o.Ub)(A, e);
                    if (t) {
                        b(null), (0, d.Sm)(!0), ea(), window.location.assign((0, o.ku)(t));
                        return
                    }
                    let n = await ea();
                    b(null), (0, d.Sm)(!0), window.location.assign((0, o.ku)(n))
                }
                async function es(e) {
                    if (6 !== e.length || "idle" !== T) return;
                    let t = null;
                    D("verifying"), L(null), g ? .();
                    try {
                        let {
                            data: n,
                            error: i
                        } = await (await X()).auth.verifyOtp({
                            email: P,
                            token: e,
                            type: "email"
                        });
                        if (i) throw i;
                        t = n.user, ee("auth_otp_verified")
                    } catch (e) {
                        en(e, "verify"), B(""), D("idle"), w ? .(), Z.current ? .focus();
                        return
                    }
                    await el(t)
                }

                function er(e) {
                    e.preventDefault(), ei(!1)
                }

                function eo() {
                    (b(null), S) ? S(): (F("email"), B(""), G(null), L(null))
                }(0, a.useEffect)(() => {
                    if ("code" !== I || et <= 0) return;
                    let e = window.setInterval(() => q(Date.now()), 1e3);
                    return () => window.clearInterval(e)
                }, [I, et]), (0, a.useEffect)(() => {
                    "code" === I && Z.current ? .focus()
                }, [I]);
                let ec = "h-12 w-full rounded-full border border-cp-line bg-cp-bg text-[15px] text-cp-ink transition-[border-color,box-shadow] duration-150 placeholder:text-cp-muted hover:border-cp-line-strong focus:border-cp-primary focus:shadow-[0_0_0_4px_color-mix(in_srgb,var(--cp-primary)_16%,transparent)] focus:outline-none disabled:opacity-60",
                    ed = (0, u.cn)("absolute top-1.5 right-1.5 inline-flex h-9 items-center gap-1.5 rounded-full px-4 text-[13px] font-medium transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select disabled:cursor-not-allowed disabled:opacity-60", "primary" === h || "code" === I ? "bg-cp-primary text-white hover:bg-cp-primary-hover" : "bg-cp-primary/10 text-cp-primary hover:bg-cp-primary/15"),
                    eu = "font-medium text-cp-primary underline-offset-2 hover:underline disabled:cursor-default disabled:text-cp-muted disabled:no-underline",
                    ep = "idle" !== T;
                return (0, i.jsxs)("div", {
                    className: "w-full",
                    onFocusCapture: _,
                    onPointerDownCapture: _,
                    children: ["email" === I && k ? (0, i.jsxs)("form", {
                        onSubmit: er,
                        noValidate: !0,
                        children: [(0, i.jsxs)("p", {
                            className: "mb-2 text-[13px] leading-5 text-cp-muted",
                            children: ["Code goes to ", (0, i.jsx)("span", {
                                className: "font-medium break-all text-cp-ink",
                                children: P
                            }), " \xb7 ", (0, i.jsx)("button", {
                                type: "button",
                                onClick: eo,
                                className: eu,
                                children: "Change"
                            })]
                        }), (0, i.jsxs)("button", {
                            type: "submit",
                            disabled: ep,
                            className: (0, u.cn)(ed, "static h-11 w-full justify-center"),
                            children: ["sending" === T ? (0, i.jsx)(l.A, {
                                className: "size-3.5 animate-spin",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            }) : null, "sending" === T ? "Sending code" : "Send code"]
                        })]
                    }) : "email" === I ? (0, i.jsxs)("form", {
                        onSubmit: er,
                        noValidate: !0,
                        className: "relative",
                        children: [(0, i.jsx)("label", {
                            htmlFor: `otp-email-${t}`,
                            className: "sr-only",
                            children: "Email address"
                        }), (0, i.jsx)("input", {
                            id: `otp-email-${t}`,
                            type: "email",
                            inputMode: "email",
                            autoComplete: "email",
                            autoCapitalize: "none",
                            spellCheck: !1,
                            placeholder: "Your email",
                            value: P,
                            onChange: e => {
                                E(e.target.value), R && L(null)
                            },
                            disabled: ep,
                            className: (0, u.cn)(ec, "pr-32 pl-5")
                        }), (0, i.jsxs)("button", {
                            type: "submit",
                            disabled: ep,
                            className: ed,
                            children: ["sending" === T ? (0, i.jsx)(l.A, {
                                className: "size-3.5 animate-spin",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            }) : null, "sending" === T ? "Sending" : "Send code", "sending" === T ? null : (0, i.jsx)(s.A, {
                                className: "size-3.5",
                                strokeWidth: 2,
                                "aria-hidden": !0
                            })]
                        })]
                    }) : (0, i.jsxs)("form", {
                        onSubmit: function(e) {
                            e.preventDefault(), es(O)
                        },
                        noValidate: !0,
                        children: [(0, i.jsxs)("p", {
                            className: "mb-2 text-[13px] leading-5 text-cp-muted",
                            children: ["Code sent to ", (0, i.jsx)("span", {
                                className: "font-medium break-all text-cp-ink",
                                children: P
                            }), " \xb7 ", (0, i.jsx)("button", {
                                type: "button",
                                onClick: eo,
                                className: eu,
                                children: "Change"
                            })]
                        }), (0, i.jsxs)("div", {
                            className: "relative",
                            children: [(0, i.jsx)("label", {
                                htmlFor: `otp-code-${t}`,
                                className: "sr-only",
                                children: "6-digit code"
                            }), (0, i.jsx)("input", {
                                ref: Z,
                                id: `otp-code-${t}`,
                                type: "text",
                                inputMode: "numeric",
                                autoComplete: "one-time-code",
                                pattern: "[0-9]*",
                                placeholder: "000000",
                                value: O,
                                onChange: e => {
                                    let t;
                                    B(t = e.target.value.replace(/\D/g, "").slice(0, 6)), R && L(null), 6 === t.length && es(t)
                                },
                                disabled: ep,
                                className: (0, u.cn)(ec, "pr-32 pl-5 font-mono text-[20px] font-semibold tracking-[0.4em] placeholder:tracking-[0.4em] placeholder:text-cp-line-strong")
                            }), (0, i.jsxs)("button", {
                                type: "submit",
                                disabled: ep || 6 !== O.length,
                                className: ed,
                                children: ["verifying" === T || "redirecting" === T ? (0, i.jsx)(l.A, {
                                    className: "size-3.5 animate-spin",
                                    strokeWidth: 2,
                                    "aria-hidden": !0
                                }) : null, "verifying" === T ? "Checking" : "redirecting" === T ? "Signing in" : "Continue"]
                            })]
                        }), (0, i.jsxs)("p", {
                            className: "mt-2 text-[12px] leading-5 text-cp-muted",
                            children: ["Not there? Check Spam, or", " ", et > 0 ? (0, i.jsxs)("span", {
                                children: ["resend in", " ", (0, i.jsx)("span", {
                                    className: "font-medium text-cp-ink tabular-nums",
                                    children: `${Math.floor(et/60)}:${String(et%60).padStart(2,"0")}`
                                })]
                            }) : (0, i.jsx)("button", {
                                type: "button",
                                onClick: () => void ei(!0),
                                disabled: ep,
                                className: eu,
                                children: "sending" === T ? "sending\u2026" : "resend the code"
                            }), "."]
                        })]
                    }), C && ("email" === I || "sending" === T) ? (0, i.jsx)(p.$, {
                        ref: V,
                        onToken: e => {
                            $(e), e && z(!1);
                            let t = K.current;
                            e && null !== t && (K.current = null, ei(t, e))
                        },
                        onError: e => {
                            z(!0), null !== K.current && (K.current = null, D("idle")), ee("auth_otp_failed", {
                                stage: "captcha_widget",
                                code: e ? ? "unknown"
                            })
                        },
                        className: "mt-2 flex justify-center empty:mt-0"
                    }) : null, M && !W ? (0, i.jsxs)("p", {
                        className: "mt-1.5 text-center text-[13px] leading-5 text-cp-muted",
                        children: ["The security check didn't go through.", " ", (0, i.jsx)("button", {
                            type: "button",
                            onClick: () => {
                                L(null), V.current ? .reset()
                            },
                            className: eu,
                            children: "Try again"
                        }), n ? ", or open this page in Chrome or Safari." : ", or use Continue with Google above."]
                    }) : null, (0, i.jsx)("p", {
                        role: "status",
                        "aria-live": "polite",
                        className: "mt-1.5 min-h-5 text-[13px] leading-5 text-cp-danger-ink empty:mt-0 empty:min-h-0",
                        children: R
                    })]
                })
            }
        },
        79678: (e, t, n) => {
            n.d(t, {
                O5: () => f,
                Uk: () => y,
                lB: () => w,
                tz: () => m
            });
            var i = n(73365),
                a = n(1521),
                l = n(98196),
                s = n(80289),
                r = n(23408),
                o = n(97587),
                c = n(84346),
                d = n(14578),
                u = n(80937);
            let p = null;

            function m(e = 1 / 0) {
                return (!p || Date.now() - p.at > e) && (p = {
                    at: Date.now(),
                    promise: fetch("/api/auth/methods", {
                        credentials: "same-origin"
                    }).then(async e => {
                        if (!e.ok) return {
                            emailOtp: !1,
                            whatsapp: !1
                        };
                        let t = await e.json();
                        try {
                            localStorage.setItem(h, JSON.stringify(t))
                        } catch {}
                        return t
                    }).catch(() => ({
                        emailOtp: !1,
                        whatsapp: !1
                    }))
                }), p.promise
            }
            let h = "cp_auth_methods";

            function f() {
                try {
                    let e = JSON.parse(localStorage.getItem(h) ? ? "null");
                    return e && "boolean" == typeof e.emailOtp ? e : null
                } catch {
                    return null
                }
            }
            let x = () => () => {};
            async function g(e) {
                let {
                    createSupabaseBrowserClient: t
                } = await Promise.all([n.e(74339), n.e(16937), n.e(88681)]).then(n.bind(n, 11062)), i = t(), a = new URL("/auth/callback", (0, u.M3)(window.location.host) && !window.location.hostname.endsWith(".localhost") ? "https://www.cutiepage.in" : window.location.origin);
                a.searchParams.set("next", e.startsWith("/") ? e : "/dashboard");
                let {
                    error: l
                } = await i.auth.signInWithOAuth({
                    provider: "google",
                    options: {
                        redirectTo: a.toString()
                    }
                });
                if (l) throw l
            }

            function b({
                className: e = "size-4"
            }) {
                return (0, i.jsxs)("svg", {
                    className: e,
                    viewBox: "0 0 24 24",
                    "aria-hidden": "true",
                    children: [(0, i.jsx)("path", {
                        fill: "#EA4335",
                        d: "M12 10.2v3.9h5.5c-.2 1.3-1.5 3.8-5.5 3.8-3.3 0-6-2.7-6-6s2.7-6 6-6c1.9 0 3.1.8 3.8 1.4l2.6-2.5C16.7 3.3 14.6 2.4 12 2.4A9.6 9.6 0 0 0 2.4 12 9.6 9.6 0 0 0 12 21.6c5.5 0 9.1-3.8 9.1-9.2 0-.6-.1-1-.2-1.4H12Z"
                    }), (0, i.jsx)("path", {
                        fill: "#34A853",
                        d: "M2.4 12c0 3.8 2.2 7.1 5.3 8.7l3.1-2.4c-.9-.3-4-1.6-4-6.3 0-.7.1-1.4.3-2L4 7.5A9.5 9.5 0 0 0 2.4 12Z"
                    }), (0, i.jsx)("path", {
                        fill: "#4A90E2",
                        d: "M12 21.6c2.6 0 4.8-.9 6.4-2.4l-3.1-2.4c-.8.5-1.8.9-3.3.9-2.6 0-4.8-1.7-5.6-4l-3.2 2.5c1.6 3.2 4.9 5.4 8.8 5.4Z"
                    }), (0, i.jsx)("path", {
                        fill: "#FBBC05",
                        d: "M6.4 13.7A5.8 5.8 0 0 1 6.1 12c0-.7.1-1.4.3-2L3.2 7.5A9.6 9.6 0 0 0 2.4 12c0 1.5.3 2.9.8 4.2l3.2-2.5Z"
                    })]
                })
            }

            function y({
                open: e,
                nextPath: t,
                eyebrow: n,
                title: r = "Sign in to continue",
                description: u = "Sign in to save your work and pick up right where you left off.",
                footnote: p = "Secure sign-in \xb7 You\u2019ll come right back here",
                onClose: h,
                onSignedIn: g
            }) {
                let [b, j] = (0, a.useState)(!1);
                (0, a.useEffect)(() => {
                    (0, o.k)() && j(!0)
                }, []);
                let v = e || b,
                    [k, S] = (0, a.useState)(!1),
                    [N, C] = (0, a.useState)(!0),
                    [_, A] = (0, a.useState)(!0),
                    [I, F] = (0, a.useState)(!1),
                    P = (0, a.useSyncExternalStore)(x, () => (0, d.f)(navigator.userAgent), () => !1);
                (0, a.useEffect)(() => {
                    let e = !1,
                        t = e => {
                            C(e.emailOtp), A(!0 === e.whatsapp), F(!0 === e.whatsappSendsCode)
                        },
                        n = f();
                    return n && t(n), m(v ? 6e4 : 1 / 0).then(n => {
                        e || t(n)
                    }), () => {
                        e = !0
                    }
                }, [v]);
                let E = t.startsWith("/") ? t : "/dashboard";
                (0, a.useEffect)(() => {
                    let e = 0,
                        t = requestAnimationFrame(() => {
                            e = requestAnimationFrame(() => S(v))
                        });
                    return () => {
                        cancelAnimationFrame(t), e && cancelAnimationFrame(e)
                    }
                }, [v]), (0, a.useEffect)(() => {
                    v && (0, c.sF)("auth_sheet_open", "sheet", P)
                }, [v, P]);
                let O = h ? () => {
                    (0, c.sF)("auth_sheet_dismiss", "sheet", P), j(!1), h()
                } : void 0;
                return ((0, a.useEffect)(() => {
                    if (!v) return;
                    let e = document.body.style.overflow;
                    return document.body.style.overflow = "hidden", () => {
                        document.body.style.overflow = e
                    }
                }, [v]), "u" < typeof document) ? null : (0, l.createPortal)((0, i.jsx)("div", {
                    "aria-hidden": !v,
                    className: ["fixed inset-0 z-[140] flex items-end justify-center bg-cp-ink/40 px-0 pt-6 transition-opacity duration-[320ms] ease-out will-change-[opacity] md:items-center md:px-6 md:py-8", k ? "opacity-100" : "pointer-events-none opacity-0 invisible transition-[opacity,visibility] delay-[0ms,320ms]"].join(" "),
                    onClick: O,
                    children: (0, i.jsx)("div", {
                        role: "dialog",
                        "aria-modal": "true",
                        "aria-labelledby": "signin-sheet-title",
                        className: ["relative flex w-full max-w-md flex-col transition-[transform,opacity] duration-[320ms] ease-[cubic-bezier(0.22,1,0.36,1)] will-change-[transform,opacity]", k ? "translate-y-0 opacity-100 md:scale-100" : "translate-y-full opacity-0 md:translate-y-6 md:scale-[0.97]"].join(" "),
                        onClick: e => e.stopPropagation(),
                        children: (0, i.jsxs)("div", {
                            className: "rounded-t-2xl bg-cp-bg px-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))] pt-3 shadow-cp-modal md:rounded-2xl md:pb-7 md:pt-7",
                            children: [(0, i.jsx)("span", {
                                className: "mx-auto mb-5 block h-1 w-9 rounded-full bg-cp-line-strong md:hidden",
                                "aria-hidden": !0
                            }), n ? (0, i.jsx)("span", {
                                className: "inline-flex items-center gap-1.5 rounded-md bg-cp-primary-soft px-2 py-0.5 text-[12px] font-medium text-cp-primary",
                                children: n
                            }) : null, (0, i.jsx)("h2", {
                                id: "signin-sheet-title",
                                className: `text-[20px] font-semibold leading-snug tracking-[-0.02em] text-cp-ink ${n?"mt-3":""}`,
                                children: r
                            }), u ? (0, i.jsx)("p", {
                                className: "mt-1.5 text-[14px] leading-6 text-cp-muted",
                                children: u
                            }) : null, (0, i.jsx)("div", {
                                className: "mt-6",
                                children: (0, i.jsx)(w, {
                                    nextPath: E,
                                    inAppBrowser: P,
                                    emailOtp: N,
                                    whatsapp: _,
                                    whatsappSendsCode: I,
                                    onSignedIn: g ? () => {
                                        j(!1), g()
                                    } : void 0
                                })
                            }), (0, i.jsxs)("p", {
                                className: "mt-4 flex items-center justify-center gap-1.5 text-center text-[12px] text-cp-muted",
                                children: [(0, i.jsx)(s.A, {
                                    className: "size-3.5 text-cp-success-ink",
                                    strokeWidth: 1.75,
                                    "aria-hidden": !0
                                }), p]
                            })]
                        })
                    })
                }), document.body)
            }

            function w({
                nextPath: e,
                inAppBrowser: t,
                emailOtp: n,
                whatsapp: l,
                whatsappSendsCode: s,
                onSignedIn: d
            }) {
                let [u, p] = (0, a.useState)("idle"), [m, h] = (0, a.useState)(null), f = t && n, [x, y] = (0, a.useState)(f || !l ? "email" : "whatsapp"), j = {
                    captcha: "email" === x,
                    onEngage: () => y("email")
                }, v = {
                    captcha: "whatsapp" === x,
                    onEngage: () => y("whatsapp")
                }, k = (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)("button", {
                        type: "button",
                        onClick: function() {
                            h(null), p("pending"), (0, c.sF)("auth_google_click", "sheet", t), g(e).catch(e => {
                                (0, c.sF)("auth_google_failed", "sheet", t, "start"), p("idle"), h(e instanceof Error ? e.message : "Could not start sign-in.")
                            })
                        },
                        disabled: "pending" === u,
                        className: "flex h-12 w-full items-center justify-center rounded-full bg-cp-primary px-5 text-[14px] font-semibold text-white transition-colors duration-150 hover:bg-cp-primary-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select disabled:cursor-not-allowed disabled:opacity-60",
                        children: [(0, i.jsx)("span", {
                            className: "mr-2 flex size-6 items-center justify-center rounded-full bg-cp-bg",
                            children: (0, i.jsx)(b, {})
                        }), "pending" === u ? "Taking you to Google\u2026" : "Continue with Google"]
                    }), m ? (0, i.jsx)("p", {
                        role: "status",
                        className: "mt-3 rounded-lg border border-cp-line bg-cp-subtle px-3.5 py-3 text-[13px] leading-5 text-cp-ink",
                        children: m
                    }) : null]
                });
                return (0, i.jsx)(i.Fragment, {
                    children: f ? (0, i.jsxs)("div", {
                        children: [(0, i.jsx)(r.o4, {
                            nextPath: e,
                            surface: "sheet",
                            inAppBrowser: !0,
                            emphasis: "primary",
                            onSignedIn: d,
                            ...j
                        }), l ? (0, i.jsx)("div", {
                            className: "mt-3",
                            children: (0, i.jsx)(o.r, {
                                nextPath: e,
                                surface: "sheet",
                                inAppBrowser: !0,
                                onSignedIn: d,
                                sendsCode: s,
                                ...v
                            })
                        }) : null, (0, i.jsx)("div", {
                            className: "mt-3",
                            children: k
                        }), (0, i.jsx)("p", {
                            className: "mt-1 text-center text-[12px] leading-5 text-cp-muted",
                            children: "If Google won't open here, it works in Chrome or Safari."
                        })]
                    }) : (0, i.jsxs)(i.Fragment, {
                        children: [k, l ? (0, i.jsx)("div", {
                            className: "mt-3",
                            children: (0, i.jsx)(o.r, {
                                nextPath: e,
                                surface: "sheet",
                                inAppBrowser: !1,
                                onSignedIn: d,
                                sendsCode: s,
                                ...v
                            })
                        }) : null, n ? (0, i.jsxs)(i.Fragment, {
                            children: [(0, i.jsxs)("div", {
                                className: "my-3 flex items-center gap-3 text-[12px] text-cp-muted",
                                "aria-hidden": !0,
                                children: [(0, i.jsx)("span", {
                                    className: "h-px flex-1 bg-cp-line"
                                }), "or use your email", (0, i.jsx)("span", {
                                    className: "h-px flex-1 bg-cp-line"
                                })]
                            }), (0, i.jsx)(r.o4, {
                                nextPath: e,
                                surface: "sheet",
                                inAppBrowser: !1,
                                onSignedIn: d,
                                ...j
                            })]
                        }) : null]
                    })
                })
            }
        },
        80937: (e, t, n) => {
            n.d(t, {
                J2: () => l,
                M3: () => a
            });
            let i = "/linkverse";

            function a(e) {
                let t = (e ? ? "").toLowerCase().split(":")[0];
                return "linkverse.cutiepage.in" === t || "linkverse.localhost" === t
            }

            function l(e) {
                return e === i || e.startsWith(`${i}/`)
            }
        }
    }
]);