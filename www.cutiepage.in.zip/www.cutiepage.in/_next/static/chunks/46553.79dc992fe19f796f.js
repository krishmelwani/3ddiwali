"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [46553], {
        46553: (e, t, o) => {
            o.r(t), o.d(t, {
                createWorldRuntime: () => z
            });
            var n = o(95813),
                a = o(84910),
                r = o(9159),
                l = o(77137),
                i = o(19776),
                s = o(77738);

            function c(e, t = 2) {
                let o = e.createBuffer(1, Math.max(1, Math.floor(e.sampleRate * t)), e.sampleRate),
                    n = o.getChannelData(0),
                    a = 0;
                for (let e = 0; e < n.length; e++) {
                    let t = 2 * Math.random() - 1;
                    a = (a + .02 * t) / 1.02, n[e] = .5 * t + 3 * a
                }
                return o
            }
            let u = [0, .45, -.45, .9, -.9, 1.35, -1.35];
            var d = o(8617);

            function p(e, t) {
                return e.canvasTexture(`marker-heart-${t}`, 128, 128, (e, o, n) => {
                    let a = e.createRadialGradient(o / 2, n / 2, 0, o / 2, n / 2, o / 2);
                    a.addColorStop(0, "rgba(255,255,255,0.55)"), a.addColorStop(1, "rgba(255,255,255,0)"), e.fillStyle = a, e.fillRect(0, 0, o, n);
                    let r = .46 * o,
                        l = o / 2,
                        i = .3 * n;
                    e.fillStyle = t, e.strokeStyle = "#ffffff", e.lineWidth = 6, e.beginPath(), e.moveTo(l, i + .3 * r), e.bezierCurveTo(l, i, l - .5 * r, i, l - .5 * r, i + .3 * r), e.bezierCurveTo(l - .5 * r, i + .6 * r, l, i + .8 * r, l, i + r), e.bezierCurveTo(l, i + .8 * r, l + .5 * r, i + .6 * r, l + .5 * r, i + .3 * r), e.bezierCurveTo(l + .5 * r, i, l, i, l, i + .3 * r), e.stroke(), e.fill()
                })
            }

            function h(e, t) {
                return e.canvasTexture(`marker-diya-${t}`, 128, 128, (e, o, n) => {
                    let a = e.createRadialGradient(o / 2, .42 * n, 0, o / 2, .42 * n, o / 2);
                    a.addColorStop(0, "rgba(255,236,190,0.7)"), a.addColorStop(1, "rgba(255,236,190,0)"), e.fillStyle = a, e.fillRect(0, 0, o, n), e.fillStyle = "#fff4c8", e.strokeStyle = "#ffb347", e.lineWidth = 4, e.beginPath(), e.moveTo(o / 2, .12 * n), e.quadraticCurveTo(.68 * o, .42 * n, o / 2, .56 * n), e.quadraticCurveTo(.32 * o, .42 * n, o / 2, .12 * n), e.fill(), e.stroke(), e.fillStyle = t, e.strokeStyle = "#ffffff", e.lineWidth = 6, e.beginPath(), e.moveTo(.14 * o, .6 * n), e.quadraticCurveTo(o / 2, .98 * n, .86 * o, .6 * n), e.closePath(), e.stroke(), e.fill()
                })
            }
            var f = o(93440),
                m = o(22408);

            function x(e, t, o) {
                let n = !1;
                for (let a = 0, r = o.length - 1; a < o.length; r = a++) {
                    let [l, i] = o[a], [s, c] = o[r];
                    i > t != c > t && e < (s - l) * (t - i) / (c - i) + l && (n = !n)
                }
                return n
            }

            function g(e, t, o) {
                let n = o[0] ? ? [e, t],
                    a = 1 / 0;
                for (let r = 0, l = o.length - 1; r < o.length; l = r++) {
                    let [i, s] = o[l], [c, u] = o[r], d = function(e, t, o, n, a, r) {
                        let l = a - o,
                            i = r - n,
                            s = l * l + i * i,
                            c = s > 0 ? Math.max(0, Math.min(1, ((e - o) * l + (t - n) * i) / s)) : 0;
                        return [o + l * c, n + i * c]
                    }(e, t, i, s, c, u), p = (d[0] - e) ** 2 + (d[1] - t) ** 2;
                    p < a && (a = p, n = d)
                }
                return n
            }

            function y(e, t, o, n = .35) {
                if (!x(t, o, e.boundary)) return !1;
                let a = g(t, o, e.boundary);
                if ((a[0] - t) ** 2 + (a[1] - o) ** 2 < n * n) return !1;
                for (let a of e.circles)
                    if ((a.x - t) ** 2 + (a.z - o) ** 2 < (a.r + n) ** 2) return !1;
                for (let a of e.blocks ? ? []) {
                    if (x(t, o, a)) return !1;
                    let e = g(t, o, a);
                    if ((e[0] - t) ** 2 + (e[1] - o) ** 2 < n * n) return !1
                }
                return !0
            }

            function w(e, t, o, n) {
                let a = t,
                    r = o;
                for (let t = 0; t < 3; t++) {
                    for (let t of e.circles) {
                        let e = a - t.x,
                            o = r - t.z,
                            l = Math.hypot(e, o),
                            i = t.r + n;
                        if (l < i) {
                            let n = l > 1e-6 ? i / l : 1;
                            a = t.x + (l > 1e-6 ? e * n : i), r = t.z + (l > 1e-6 ? o * n : 0)
                        }
                    }
                    for (let t of e.blocks ? ? []) {
                        let e = g(a, r, t),
                            o = x(a, r, t),
                            l = a - e[0],
                            i = r - e[1],
                            s = Math.hypot(l, i);
                        if (o || s < n) {
                            let t = o ? -1 : 1,
                                c = s > 1e-6 ? l / s * t : 0,
                                u = s > 1e-6 ? i / s * t : 0;
                            a = e[0] + c * n, r = e[1] + u * n
                        }
                    }
                    let t = x(a, r, e.boundary),
                        o = g(a, r, e.boundary),
                        l = a - o[0],
                        i = r - o[1],
                        s = Math.hypot(l, i);
                    if (!t || s < n) {
                        let c = 0,
                            u = 0;
                        for (let [t, o] of e.boundary) c += t, u += o;
                        c /= e.boundary.length || 1, u /= e.boundary.length || 1;
                        let d = t && s > 1e-6 ? [l / s, i / s] : [c - o[0], u - o[1]],
                            p = Math.hypot(d[0], d[1]) || 1;
                        a = o[0] + d[0] / p * n, r = o[1] + d[1] / p * n
                    }
                }
                return [a, r]
            }

            function M(e, t, o, n, a, r = .35) {
                let l = t + n,
                    i = o + a;
                if (y(e, l, i, r)) return [l, i];
                let [s, c] = w(e, l, i, r);
                return y(e, s, c, .98 * r) && Math.hypot(s - t, c - o) <= 1.5 * Math.hypot(n, a) + 1e-6 ? [s, c] : y(e, l, o, r) ? [l, o] : y(e, t, i, r) ? [t, i] : [t, o]
            }

            function b(e, t, o, n = .35) {
                if (y(e, t, o, n)) return [t, o];
                let [a, r] = w(e, t, o, n);
                return [a, r]
            }

            function k(e, t, o, n) {
                let a = Math.max(1, Math.ceil(Math.hypot(o[0] - t[0], o[1] - t[1]) / .2));
                for (let r = 1; r <= a; r++) {
                    let l = r / a;
                    if (!y(e, t[0] + (o[0] - t[0]) * l, t[1] + (o[1] - t[1]) * l, n)) return !1
                }
                return !0
            }
            let v = new WeakMap;

            function z(e) {
                let t, {
                        host: o,
                        spec: g,
                        fonts: w,
                        edit: z,
                        onState: A,
                        onFallback: E
                    } = e,
                    P = "siblings" === g.bond,
                    S = o.ownerDocument,
                    C = S.defaultView,
                    L = e.values,
                    R = e.reducedMotion,
                    j = e.quality,
                    I = "auto" === j ? (0, f.o)(C) : j,
                    V = {
                        phase: "loading",
                        mode: "walk",
                        found: Array.from({
                            length: g.memoryCount
                        }, () => !1),
                        near: null,
                        open: null,
                        target: 0,
                        tourIndex: 0,
                        tourCount: 0,
                        progress: 0,
                        quality: I,
                        qualityChoice: j,
                        fps: 60,
                        drawCalls: 0,
                        action: null,
                        finaleReady: !1,
                        contextLost: !1,
                        autoTour: !0,
                        guide: !0,
                        walking: !1
                    },
                    q = "",
                    F = (e = !1) => {
                        let t = JSON.stringify(V);
                        (e || t !== q) && (q = t, A({ ...V,
                            found: [...V.found],
                            action: V.action ? { ...V.action
                            } : null
                        }))
                    };
                if (!C || ! function(e) {
                        try {
                            let t = e.createElement("canvas").getContext("webgl2");
                            return t ? .getExtension("WEBGL_lose_context") ? .loseContext(), !!t
                        } catch {
                            return !1
                        }
                    }(S)) return queueMicrotask(() => E("no-webgl")), T(V);
                let Y = S.createElement("canvas");
                Y.className = "wd-canvas", Y.setAttribute("aria-hidden", "true"), o.appendChild(Y);
                try {
                    t = new n.JeP({
                        canvas: Y,
                        antialias: !0,
                        powerPreference: "high-performance",
                        alpha: !1
                    })
                } catch {
                    return Y.remove(), queueMicrotask(() => E("no-webgl")), T(V)
                }
                if (!t.capabilities.isWebGL2) return t.dispose(), Y.remove(), queueMicrotask(() => E("no-webgl")), T(V);
                t.outputColorSpace = a.er$, t.toneMapping = a.FV, t.shadowMap.type = a.Wk7, t.info.autoReset = !1;
                let D = new a.ubm(50, 1, .05, 600),
                    B = function(e, t) {
                        let o = new a.Pq0(0, 3, 8),
                            n = new a.Pq0(0, 1, 0),
                            r = 50,
                            l = null,
                            i = null,
                            s = "shot",
                            c = 0,
                            d = .32,
                            p = 4.6,
                            h = new a.Pq0,
                            f = new a.Pq0,
                            m = new a.Pq0,
                            x = 0,
                            g = 0,
                            y = 0,
                            w = null,
                            M = null,
                            b = 0,
                            k = 0;

                        function v(t) {
                            let o = Math.min(2, Math.max(1, 1.25 / Math.max(.3, e.aspect))),
                                n = new a.Pq0(...t.look),
                                r = new a.Pq0(...t.pos).sub(n),
                                l = Math.min(o, 1 + 2 / (r.length() || 1));
                            l > 1 && M && (l = 1 + (l - 1) * Math.max(0, Math.min(1, M(n.clone().add(r), n.clone().addScaledVector(r, l)))));
                            let i = t.fov ? ? 50,
                                s = o / l,
                                c = s > 1.001 ? Math.min(72, 2 * a.cj9.radToDeg(Math.atan(Math.tan(a.cj9.degToRad(i) / 2) * s))) : i;
                            return {
                                pos: n.clone().add(r.multiplyScalar(l)),
                                look: n,
                                fov: Math.max(i, c)
                            }
                        }

                        function z(e, a = 2.2) {
                            s = "shot", i = null;
                            let c = v(e);
                            if (a <= 0 || t()) {
                                o.copy(c.pos), n.copy(c.look), r = c.fov, l = null;
                                return
                            }
                            l = {
                                fromPos: o.clone(),
                                fromLook: n.clone(),
                                toPos: c.pos,
                                toLook: c.look,
                                t: 0,
                                seconds: a,
                                fromFov: r,
                                toFov: c.fov
                            }
                        }
                        return {
                            get mode() {
                                return s
                            },
                            get moving() {
                                return !!l || !!i
                            },
                            goTo: z,
                            setBound(e) {
                                w = e
                            },
                            setShotRoom(e) {
                                M = e
                            },
                            cut(e) {
                                z(e, 0)
                            },
                            fly(e, a, s) {
                                if (!e.length) return s();
                                if (t() || 1 === e.length) {
                                    z(e[e.length - 1], 0), s();
                                    return
                                }
                                z(e[0], 0), i = {
                                    shots: e,
                                    index: 1,
                                    seconds: a,
                                    onDone: s
                                };
                                let c = v(e[1]);
                                l = {
                                    fromPos: o.clone(),
                                    fromLook: n.clone(),
                                    toPos: c.pos,
                                    toLook: c.look,
                                    t: 0,
                                    seconds: a,
                                    fromFov: r,
                                    toFov: c.fov
                                }
                            },
                            skip() {
                                if (!i) return;
                                let e = i.shots[i.shots.length - 1],
                                    t = i.onDone;
                                i = null, z(e, 0), t()
                            },
                            follow(e) {
                                "follow" !== s && (s = "follow", c = e + Math.PI, g = 0, x = 0, l = null, i = null)
                            },
                            drag(e, t) {
                                "follow" === s ? (g -= .006 * e, d = a.cj9.clamp(d + .004 * t, .08, .95)) : (b = a.cj9.clamp(b + .004 * e, -.6, .6), k = a.cj9.clamp(k + .004 * t, -.3, .3))
                            },
                            zoom(e) {
                                p = a.cj9.clamp(p + e, 2.8, 8)
                            },
                            get heading() {
                                return c + g + Math.PI
                            },
                            update(a, M, z, T, A) {
                                if (y += a, "follow" === s) {
                                    let t = z + Math.PI;
                                    if (T && !A) {
                                        let e = t - c;
                                        c += Math.atan2(Math.sin(e), Math.cos(e)) * Math.min(1, .9 * a), g *= Math.max(0, 1 - .6 * a)
                                    }
                                    let l = Math.min(1.25, Math.max(1, 1.1 / Math.max(.3, e.aspect))),
                                        i = p * l;
                                    h.set(M.x, M.y + .95, M.z);
                                    let s = (e, t) => (t.set(h.x + Math.sin(e) * Math.cos(d) * i, h.y + Math.sin(d) * i, h.z + Math.cos(e) * Math.cos(d) * i), w && t.copy(w(h, t)), Math.hypot(t.x - h.x, t.z - h.z));
                                    if (w) {
                                        let e = Math.cos(d) * i * .85,
                                            t = 0,
                                            o = -1;
                                        for (let n of u) {
                                            let a = s(c + g + n, m);
                                            if (a > o + .3 && (o = a, t = n), a >= e) {
                                                t = n;
                                                break
                                            }
                                        }
                                        x += (t - x) * Math.min(1, 1.6 * a)
                                    }
                                    let y = Math.min(1, s(c + g + x, f) / Math.max(.1, Math.cos(d) * i)),
                                        b = 1 - Math.exp(-(6 * a));
                                    o.lerp(f, b), n.lerp(h, b), r += (52 + (1 - y) * 20 - r) * b
                                } else if (l) {
                                    l.t += a;
                                    let e = Math.min(1, l.t / l.seconds),
                                        t = e < .5 ? 4 * e * e * e : 1 - Math.pow(-2 * e + 2, 3) / 2;
                                    if (o.lerpVectors(l.fromPos, l.toPos, t), n.lerpVectors(l.fromLook, l.toLook, t), r = l.fromFov + (l.toFov - l.fromFov) * t, e >= 1 && (l = null, i))
                                        if (i.index < i.shots.length - 1) {
                                            i.index++;
                                            let e = v(i.shots[i.index]);
                                            l = {
                                                fromPos: o.clone(),
                                                fromLook: n.clone(),
                                                toPos: e.pos,
                                                toLook: e.look,
                                                t: 0,
                                                seconds: i.seconds,
                                                fromFov: r,
                                                toFov: e.fov
                                            }
                                        } else {
                                            let e = i.onDone;
                                            i = null, e()
                                        }
                                }
                                A || (b *= Math.max(0, 1 - 2 * a), k *= Math.max(0, 1 - 2 * a));
                                let E = t() || "follow" === s ? 0 : 1;
                                e.position.set(o.x + .05 * Math.sin(.25 * y) * E, o.y + .035 * Math.sin(.4 * y) * E, o.z), e.lookAt(n), (b || k) && (e.rotateY(b), e.rotateX(k)), Math.abs(e.fov - r) > .01 && (e.fov = r, e.updateProjectionMatrix())
                            }
                        }
                    }(D, () => R),
                    G = (e, t) => {
                        if (!K) return !0;
                        let o = K.walk;
                        if (!x(e, t, o.boundary)) return !1;
                        for (let n of o.circles)
                            if ((n.x - e) ** 2 + (n.z - t) ** 2 < (2.2 * n.r + .3) ** 2) return !1;
                        return !0
                    },
                    O = new a.Pq0;
                B.setBound((e, t) => {
                    O.copy(t);
                    let o = 0;
                    for (let n = 1; n <= 14; n++) {
                        let a = n / 14;
                        if (!G(e.x + (t.x - e.x) * a, e.z + (t.z - e.z) * a)) break;
                        o = a
                    }
                    let n = Math.max(.3, o);
                    return O.set(e.x + (t.x - e.x) * n, t.y - (1 - n) * (t.y - e.y) * .6, e.z + (t.z - e.z) * n), O
                });
                let W = (e, t, o) => {
                    if (!K || t > 4.5) return !0;
                    for (let t of K.walk.circles)
                        if ((t.x - e) ** 2 + (t.z - o) ** 2 < (2.6 * t.r + .4) ** 2) return !1;
                    for (let t of K.walk.blocks ? ? [])
                        if (x(e, o, t)) return !1;
                    return !0
                };
                B.setShotRoom((e, t) => {
                    let o = 0;
                    for (let n = 1; n <= 10; n++) {
                        let a = n / 10;
                        if (!W(e.x + (t.x - e.x) * a, e.y + (t.y - e.y) * a, e.z + (t.z - e.z) * a)) break;
                        o = a
                    }
                    return o
                });
                let X = function(e) {
                        let t = null,
                            o = null,
                            n = null,
                            a = 1,
                            r = .7,
                            l = null,
                            i = null,
                            s = null,
                            u = !1,
                            d = !1,
                            p = null,
                            h = () => {
                                try {
                                    p ? .setVolume(d && !u ? r : 0)
                                } catch {}
                            };

                        function f(e) {
                            if (!t || !o || !n || u) return;
                            l ? .stop();
                            let a = n,
                                r = t,
                                i = {
                                    ctx: r,
                                    out: a,
                                    noise: e => c(r, e),
                                    chirp: (e, t, o, n, l) => (function(e, t, o, n, a, r, l) {
                                        let i = e.currentTime;
                                        for (let s = 0; s < n; s++) {
                                            let n = e.createOscillator(),
                                                s = e.createGain();
                                            n.type = "sine", n.frequency.setValueAtTime(o, i), n.frequency.exponentialRampToValueAtTime(o * l, i + .07), s.gain.setValueAtTime(1e-4, i), s.gain.exponentialRampToValueAtTime(r, i + .01), s.gain.exponentialRampToValueAtTime(1e-4, i + .09), n.connect(s).connect(t), n.start(i), n.stop(i + .1), i += a + .05 * Math.random()
                                        }
                                    })(r, a, e, t, o, n, l),
                                    mood: e.mood
                                };
                            try {
                                l = e.spec.ambience ? e.spec.ambience(i) : function(e, t) {
                                    let {
                                        ctx: o,
                                        out: n
                                    } = t, a = o.createBufferSource();
                                    a.buffer = t.noise(2), a.loop = !0;
                                    let r = o.createBiquadFilter(),
                                        l = o.createGain(),
                                        [i, s, c] = {
                                            park: ["lowpass", 900, .05],
                                            river: ["lowpass", 480, .22],
                                            rain: ["bandpass", 2200, .35],
                                            rooftop: ["lowpass", 260, .12],
                                            diwali: ["lowpass", 320, .1],
                                            haveli: ["lowpass", 300, .1]
                                        }[e];
                                    r.type = i, r.frequency.value = s, r.Q.value = .4, l.gain.setValueAtTime(0, o.currentTime), l.gain.linearRampToValueAtTime(c, o.currentTime + 1.2), a.connect(r).connect(l).connect(n), a.start();
                                    let u = setInterval(() => {
                                        "park" === e && .5 > Math.random() && t.chirp(2400 + 1200 * Math.random(), 2 + Math.floor(3 * Math.random()), .11, .04, 1.5), ("river" === e || "rooftop" === e) && .4 > Math.random() && t.chirp(4300 + 300 * Math.random(), 4, .06, .012, 1.05)
                                    }, "park" === e ? 1400 : 900);
                                    return {
                                        stop() {
                                            clearInterval(u);
                                            try {
                                                l.gain.setTargetAtTime(0, o.currentTime, .2), a.stop(o.currentTime + .8)
                                            } catch {}
                                        }
                                    }
                                }(e.kind, i)
                            } catch {
                                l = null
                            }
                        }
                        return {
                            get volume() {
                                return r
                            },
                            unlock() {
                                d = !0;
                                try {
                                    p ? .unlock()
                                } catch {}
                                h();
                                let l = function() {
                                    if (t) return t;
                                    let l = e ? .AudioContext ? ? e ? .webkitAudioContext;
                                    if (!l) return null;
                                    try {
                                        t = new l
                                    } catch {
                                        return null
                                    }
                                    return (o = t.createGain()).gain.value = r, o.connect(t.destination), (n = t.createGain()).gain.value = a, n.connect(o), t
                                }();
                                l && ("suspended" === l.state && l.resume().catch(() => {}), i && (s = i, i = null, f(s)))
                            },
                            setVolume(e) {
                                r = Math.max(0, Math.min(1, e)), o && t && o.gain.setTargetAtTime(r, t.currentTime, .05), h()
                            },
                            startAmbience(e, o, n) {
                                let a = {
                                    spec: e,
                                    kind: o,
                                    mood: n
                                };
                                if (!t) {
                                    i = a;
                                    return
                                }
                                s = a, f(a)
                            },
                            duckAmbience(e) {
                                a = Math.max(0, Math.min(1, e)), n && t && n.gain.setTargetAtTime(a, t.currentTime, .7)
                            },
                            stopAmbience() {
                                l ? .stop(), l = null, i = null, s = null
                            },
                            suspend() {
                                u = !0, h(), l ? .stop(), l = null, t && "running" === t.state && t.suspend().catch(() => {})
                            },
                            resume() {
                                u && (u = !1, h(), t && "suspended" === t.state && t.resume().catch(() => {}), s && f(s))
                            },
                            sfx(e) {
                                if (t && o && !u && !(r <= 0)) try {
                                    ! function(e, t, o) {
                                        let n = e.currentTime,
                                            a = (o, a, r, l, i = "sine", s) => {
                                                let c = e.createOscillator(),
                                                    u = e.createGain();
                                                c.type = i, c.frequency.setValueAtTime(o, n + a), s && c.frequency.exponentialRampToValueAtTime(s, n + a + r), u.gain.setValueAtTime(1e-4, n + a), u.gain.exponentialRampToValueAtTime(l, n + a + .015), u.gain.exponentialRampToValueAtTime(1e-4, n + a + r), c.connect(u).connect(t), c.start(n + a), c.stop(n + a + r + .05)
                                            },
                                            r = (o, a, r, l, i = "bandpass") => {
                                                let s = e.createBufferSource();
                                                s.buffer = c(e, a + .1);
                                                let u = e.createBiquadFilter();
                                                u.type = i, u.frequency.value = l;
                                                let d = e.createGain();
                                                d.gain.setValueAtTime(r, n + o), d.gain.exponentialRampToValueAtTime(1e-4, n + o + a), s.connect(u).connect(d).connect(t), s.start(n + o), s.stop(n + o + a + .05)
                                            };
                                        switch (o) {
                                            case "chime":
                                                [880, 1175, 1568].forEach((e, t) => a(e, .09 * t, .9, .05));
                                                break;
                                            case "found":
                                                [659, 784, 988, 1319].forEach((e, t) => a(e, .07 * t, .7, .05, "triangle"));
                                                break;
                                            case "pop":
                                                a(520, 0, .12, .08, "sine", 1400);
                                                break;
                                            case "whoosh":
                                                r(0, .7, .18, 900);
                                                break;
                                            case "splash":
                                                r(0, .5, .3, 1800, "highpass"), a(300, 0, .2, .04, "sine", 120);
                                                break;
                                            case "sparkle":
                                                for (let e = 0; e < 6; e++) a(1800 + 1600 * Math.random(), .05 * e, .25, .025);
                                                break;
                                            case "firework":
                                                a(300, 0, .6, .03, "sine", 1200), r(.6, 1.2, .35, 600, "lowpass");
                                                break;
                                            case "pour":
                                                r(0, 1.4, .08, 1400);
                                                break;
                                            case "thunder":
                                                r(0, 2.6, .4, 140, "lowpass");
                                                break;
                                            case "bell":
                                                [523, 1258, 1730, 2342, 2960].forEach((e, t) => a(e, 0, 3.6 - .55 * t, [.07, .045, .03, .02, .012][t])), a(261, 0, 2.2, .03, "sine", 259), r(0, .05, .12, 3200, "highpass");
                                                break;
                                            case "flutter":
                                                for (let e = 0; e < 9; e++) r(.07 * e, .06, .09 - .008 * e, 700 + 60 * e)
                                        }
                                    }(t, o, e)
                                } catch {}
                            },
                            attach(e) {
                                p && p !== e && p.dispose(), p = e, e && (d && e.unlock(), h())
                            },
                            dispose() {
                                p ? .dispose(), p = null, l ? .stop(), l = null, t ? .close().catch(() => {}), t = null, o = null
                            }
                        }
                    }(C),
                    N = (0, f.s)(),
                    U = new a.tBo,
                    _ = new a.Zcv(new a.Pq0(0, 1, 0), 0),
                    H = null,
                    J = null,
                    K = null,
                    Z = null,
                    $ = null,
                    Q = null,
                    ee = [],
                    et = {
                        x: 0,
                        z: 0,
                        heading: 0,
                        speed: 0
                    },
                    eo = null,
                    en = new a.I9Y,
                    ea = new Set,
                    er = {
                        x: 0,
                        z: 0,
                        heading: 0,
                        mode: "follow",
                        wander: null
                    },
                    el = 0,
                    ei = -1,
                    es = -1,
                    ec = -1,
                    eu = -1,
                    ed = !1,
                    ep = new Set;

                function eh() {
                    if (!C) return;
                    let e = Math.max(1, o.clientWidth),
                        n = Math.max(1, o.clientHeight),
                        a = "high" === I ? Math.min(C.devicePixelRatio || 1, 2) : 1;
                    t.setPixelRatio(a), t.setSize(e, n, !1), $ ? .setPixelRatio(a), $ ? .setSize(e, n), D.aspect = e / n, D.updateProjectionMatrix(), J && (J.ctx.px.value = n * a / (2 * Math.tan(D.fov * Math.PI / 360)))
                }
                let ef = (e, t) => K ? .walk.height ? .(e, t) ? ? 0;

                function em(e) {
                    if (et.x = e.x, et.z = e.z, et.heading = e.facing, et.speed = 0, eo = null, !J) return;
                    let t = (0, m.A)(e),
                        {
                            a: o,
                            b: n
                        } = J.ctx.actors;
                    o.object.position.set(t.a[0], ef(t.a[0], t.a[1]), t.a[1]), n.object.position.set(t.b[0], ef(t.b[0], t.b[1]), t.b[1]), o.object.rotation.set(0, e.facing, 0), n.object.rotation.set(0, e.facing, 0);
                    let a = J.ctx.actors.pet;
                    er.x = t.pet[0], er.z = t.pet[1], er.heading = e.facing, a && (a.object.position.set(er.x, ef(er.x, er.z), er.z), a.object.rotation.set(0, e.facing, 0))
                }

                function ex(e) {
                    let t = "high" === I;
                    e.traverse(e => {
                        if (e instanceof a.ZyN && (e.castShadow = t, t && e.shadow.mapSize.set(1024, 1024)), e.isMesh) {
                            if (e.userData.noShadow) {
                                e.castShadow = !1, e.receiveShadow = !1;
                                return
                            }
                            e.receiveShadow = t && !e.userData.castOnly, e.castShadow = t && !e.userData.receiveOnly
                        }
                    })
                }

                function eg() {
                    H && (K ? .dispose ? .(), H.traverse(e => {
                        e.geometry && e.geometry.dispose();
                        let t = e.material;
                        Array.isArray(t) ? t.forEach(e => e.dispose()) : t ? .dispose ? .()
                    }), Z ? .dispose(), J ? .dispose(), $ ? .dispose(), Q ? .dispose(), $ = null, Q = null, Z = null, J = null, K = null, H = null)
                }

                function ey() {
                    eg();
                    let e = new a.Z58,
                        o = (0, d.q6)({
                            scene: e,
                            doc: S,
                            quality: I,
                            reducedMotion: R,
                            fonts: w,
                            values: L,
                            memoryCount: g.memoryCount,
                            bond: g.bond
                        });
                    o.setHooks({
                        camera: (e, t) => B.goTo(e, t),
                        place: e => em(e)
                    }), o.setSfx(e => X.sfx(e)), o.setSoundSink(e => X.attach(e));
                    let n = g.build(o.ctx);
                    e.add(n.root), n.sky && e.add(n.sky), e.fog = new a.jUj(n.fog[0], n.fog[1], n.fog[2]), t.toneMappingExposure = n.exposure, t.shadowMap.enabled = "high" === I, n.setMood(L.mood), n.setValues(o.sceneValues());
                    let c = function(e) {
                        let {
                            fx: t,
                            memories: o
                        } = e, n = new a.YJl;
                        n.name = "hotspots";
                        let r = [],
                            l = e.accent,
                            i = "diya" === e.shape ? h : p,
                            s = i(t, l);
                        o.forEach(e => {
                            let o = new a.RoJ({
                                    map: s,
                                    transparent: !0,
                                    depthWrite: !1,
                                    depthTest: !0
                                }),
                                i = new a.kxk(o);
                            i.scale.setScalar(.42);
                            let c = new a.Pq0(e.at[0], e.at[1], e.at[2]);
                            i.position.copy(c), i.renderOrder = 5;
                            let u = t.glow(l, 1.1, .55);
                            u.position.copy(c), n.add(u, i), r.push({
                                sprite: i,
                                glow: u,
                                base: c,
                                material: o
                            })
                        });
                        let c = new a.Ho_(.18, .32, 6, 16, 1, !0);
                        c.translate(0, 3, 0);
                        let u = new a.V9B({
                                color: l,
                                transparent: !0,
                                opacity: .16,
                                blending: a.EZo,
                                depthWrite: !1
                            }),
                            d = new a.eaF(c, u);
                        d.userData.noShadow = !0, d.visible = !1, n.add(d);
                        let f = new Float32Array(72),
                            m = t.particles({
                                count: 24,
                                positions: f,
                                color: l,
                                size: .12,
                                mode: "twinkle",
                                opacity: .8
                            });
                        m.visible = !1, n.add(m);
                        let x = o.map(() => !1),
                            g = null,
                            y = !0,
                            w = 0;
                        return {
                            root: n,
                            setFound(e) {
                                x = [...e]
                            },
                            setGuide(e) {
                                y = e
                            },
                            setAccent(e) {
                                if (e !== l) {
                                    for (let o of (s = i(t, l = e), r)) o.material.map = s, o.material.needsUpdate = !0, o.glow.material.color.set(l);
                                    u.color.set(l), m.material.uniforms.uColor.value.set(l)
                                }
                            },
                            nextTarget(e) {
                                for (let t of e ? ? o.map((e, t) => t))
                                    if (!x[t]) return t;
                                return null
                            },
                            near(e, t) {
                                let n = null,
                                    a = 1 / 0;
                                return o.forEach((o, r) => {
                                    let l = o.radius ? ? 2.4,
                                        i = Math.min(Math.hypot(o.stand.x - e, o.stand.z - t), Math.hypot(o.at[0] - e, o.at[2] - t));
                                    i < l && i < a && (a = i, n = r)
                                }), n
                            },
                            update(t, n, a, l, i) {
                                g = l;
                                let s = e.reducedMotion();
                                r.forEach((e, o) => {
                                    let n = x[o],
                                        a = s ? 0 : .06 * Math.sin(2 * t + o);
                                    e.sprite.position.set(e.base.x, e.base.y + a, e.base.z), e.glow.position.copy(e.sprite.position);
                                    let r = s ? 1 : 1 + .08 * Math.sin(3 * t + o);
                                    e.sprite.scale.setScalar((n ? .26 : o === g ? .5 : .4) * r), e.material.opacity = n ? .45 : 1, e.glow.material.opacity = n ? .15 : o === g ? .75 : .5, e.sprite.visible = i, e.glow.visible = i
                                });
                                let c = y && i && null !== g;
                                if (d.visible = c, m.visible = c, !c || null === g) return;
                                let p = o[g];
                                if (d.position.set(p.at[0], 0, p.at[2]), u.opacity = .12 + (s ? 0 : .04 * Math.sin(2 * t)), (w -= n) <= 0) {
                                    w = .25;
                                    let e = p.stand.x,
                                        t = p.stand.z,
                                        o = Math.min(24, Math.max(2, Math.floor(Math.hypot(e - a.x, t - a.z) / .7)));
                                    for (let n = 0; n < 24; n++) {
                                        let r = n < o ? (n + 1) / (o + 1) : 1;
                                        f[3 * n] = a.x + (e - a.x) * r, f[3 * n + 1] = n < o ? .05 : -5, f[3 * n + 2] = a.z + (t - a.z) * r
                                    }
                                    m.geometry.getAttribute("position").needsUpdate = !0
                                }
                            },
                            pickables: () => r.map(e => e.sprite),
                            dispose() {
                                for (let e of r) e.material.dispose();
                                c.dispose(), u.dispose()
                            }
                        }
                    }({
                        fx: o.ctx.fx,
                        memories: n.memories,
                        accent: L.accent,
                        reducedMotion: () => R,
                        shape: P ? "diya" : "heart"
                    });
                    e.add(c.root), ex(e), H = e, J = o, K = n, Z = c, V.tourCount = (ee = n.tour.length ? n.tour : n.memories.map((e, t) => ({
                        memory: t,
                        stand: e.stand,
                        shot: e.shot
                    }))).length, Z.setFound(V.found), Z.setGuide(V.guide), "high" === I && (($ = new r.s(t)).addPass(new i.A(e, D)), Q = new s.C(new a.I9Y(256, 256), .45, .5, .86), $.addPass(Q), $.addPass(new l.X)), eh();
                    let u = o.walkClips();
                    J.ctx.actors.a.play(u.a, {
                        speed: 0,
                        fade: 0
                    }), J.ctx.actors.b.play(u.b, {
                        speed: 0,
                        fade: 0
                    }), J.ctx.actors.pet ? .play("idle", {
                        fade: 0
                    })
                }

                function ew() {
                    let e = ee.map(e => e.memory).filter(e => null !== e);
                    return Z ? .nextTarget(e.length ? e : void 0) ? ? null
                }

                function eM(e, t, o, n) {
                    if (!K) return;
                    let [a, r] = b(K.walk, e, t), l = function(e, t, o, n = .35) {
                        if (k(e, t, o, n)) return [o];
                        let a = function(e, t) {
                                let o = v.get(e);
                                if (o) return o;
                                let n = e.boundary.map(e => e[0]),
                                    a = e.boundary.map(e => e[1]),
                                    r = Math.min(...n),
                                    l = Math.min(...a),
                                    i = Math.ceil((Math.max(...n) - r) / .5) + 1,
                                    s = Math.ceil((Math.max(...a) - l) / .5) + 1,
                                    c = new Uint8Array(i * s);
                                for (let o = 0; o < s; o++)
                                    for (let n = 0; n < i; n++) c[o * i + n] = +!!y(e, r + .5 * n, l + .5 * o, t);
                                let u = {
                                    x0: r,
                                    z0: l,
                                    w: i,
                                    h: s,
                                    ok: c
                                };
                                return v.set(e, u), u
                            }(e, n),
                            r = e => {
                                let t = Math.round((e[0] - a.x0) / .5),
                                    o = Math.round((e[1] - a.z0) / .5);
                                for (let e = 0; e <= 4; e++)
                                    for (let n = -e; n <= e; n++)
                                        for (let r = -e; r <= e; r++) {
                                            let e = t + r,
                                                l = o + n;
                                            if (e >= 0 && l >= 0 && e < a.w && l < a.h && a.ok[l * a.w + e]) return l * a.w + e
                                        }
                                return -1
                            },
                            l = r(t),
                            i = r(o);
                        if (l < 0 || i < 0) return [o];
                        let s = new Int32Array(a.w * a.h).fill(-1);
                        s[l] = l;
                        let c = [l];
                        for (let e = 0; e < c.length && s[i] < 0; e++) {
                            let t = c[e],
                                o = t % a.w,
                                n = (t - o) / a.w;
                            for (let [e, r] of [
                                    [1, 0],
                                    [-1, 0],
                                    [0, 1],
                                    [0, -1],
                                    [1, 1],
                                    [1, -1],
                                    [-1, 1],
                                    [-1, -1]
                                ]) {
                                let l = o + e,
                                    i = n + r,
                                    u = i * a.w + l;
                                l < 0 || i < 0 || l >= a.w || i >= a.h || !a.ok[u] || s[u] >= 0 || (!e || !r || a.ok[n * a.w + l] && a.ok[i * a.w + o]) && (s[u] = t, c.push(u))
                            }
                        }
                        if (s[i] < 0) return [o];
                        let u = [];
                        for (let e = i; e !== l; e = s[e]) u.push([a.x0 + e % a.w * .5, a.z0 + .5 * Math.floor(e / a.w)]);
                        u.reverse(), u[u.length - 1] = o;
                        let d = [],
                            p = t,
                            h = 0;
                        for (; h < u.length;) {
                            let t = h;
                            for (; t + 1 < u.length && k(e, p, u[t + 1], n);) t++;
                            p = u[t], d.push(p), h = t + 1
                        }
                        return d
                    }(K.walk, [et.x, et.z], [a, r]), [i, s] = l.shift();
                    eo = {
                        x: i,
                        z: s,
                        path: l,
                        speed: o,
                        onArrive: n,
                        stuck: 0,
                        last: 1 / 0
                    }
                }

                function eb(e) {
                    if (!K || !ee.length) return;
                    let t = ee.length;
                    V.tourIndex = (e % t + t) % t;
                    let o = ee[V.tourIndex];
                    V.phase = "explore", V.open = null, V.action = null, B.goTo(o.shot, 2.4), eu = -1, eM(o.stand.x, o.stand.z, 2.3, () => {
                        et.heading = o.stand.facing, eu = .7
                    }), F(!0)
                }

                function ek(e) {
                    V.phase = "card", V.open = e, V.action = null, V.found[e] || (V.found[e] = !0, Z ? .setFound(V.found), K ? .memories[e] ? .onFound ? .(), X.sfx("found")), F(!0)
                }

                function ev(e) {
                    if (!K) return;
                    let t = K.memories[e];
                    t && (V.phase = "look", V.near = null, V.open = null, B.goTo(t.shot, 1.8), "walk" === V.mode && eM(t.stand.x, t.stand.z, 2.3, () => et.heading = t.stand.facing), ec = R ? .1 : 1.7, ez = e, F(!0))
                }
                let ez = -1;

                function eT() {
                    let e = V.action ? .index;
                    if (void 0 === e || !K) return;
                    let t = K.memories[e] ? .interaction;
                    if (!t) return ek(e);
                    let o = 1;
                    try {
                        o = t.run()
                    } catch {
                        o = .2
                    }
                    ep.add(e), V.action = null, es = Math.max(.2, Math.min(24, o)), eA = e, F(!0)
                }
                let eA = -1,
                    eE = -1,
                    eP = {
                        id: -1,
                        x: 0,
                        y: 0,
                        startX: 0,
                        startY: 0,
                        t: 0,
                        moved: !1
                    },
                    eS = new a.I9Y;

                function eC(e, t) {
                    let o = Y.getBoundingClientRect();
                    eS.set((e - o.left) / o.width * 2 - 1, -(2 * ((t - o.top) / o.height)) + 1), U.setFromCamera(eS, D)
                }

                function eL(e) {
                    return e.length > 0 && U.intersectObjects(e, !0).length > 0
                }
                let eR = -1,
                    ej = e => {
                        if (!z) {
                            eP.id = e.pointerId, eP.x = eP.startX = e.clientX, eP.y = eP.startY = e.clientY, eP.t = performance.now(), eP.moved = !1;
                            try {
                                Y.setPointerCapture(e.pointerId)
                            } catch {}
                            if ("action" === V.phase && V.action ? .verb === "hold" && K) {
                                let t = K.memories[V.action.index] ? .interaction;
                                eC(e.clientX, e.clientY), t ? .targets && eL(t.targets) && (ed = !0)
                            }
                        }
                    },
                    eI = e => {
                        if (e.pointerId !== eP.id) return;
                        let t = e.clientX - eP.x,
                            o = e.clientY - eP.y;
                        eP.x = e.clientX, eP.y = e.clientY, Math.hypot(e.clientX - eP.startX, e.clientY - eP.startY) > 8 && (eP.moved = !0), eP.moved && !ed && B.drag(t, o)
                    },
                    eV = e => {
                        if (e.pointerId === eP.id) {
                            if (eP.id = -1, ed) {
                                ed = !1;
                                return
                            }!eP.moved && performance.now() - eP.t < 450 && function(e, t) {
                                if (!K || !J || z) return;
                                if (X.unlock(), eC(e, t), "action" === V.phase && V.action) {
                                    let e = K.memories[V.action.index] ? .interaction;
                                    if (e ? .targets && eL(e.targets)) {
                                        "tap" === e.verb && eT();
                                        return
                                    }
                                }
                                let o = J.ctx.actors.pet;
                                if (o && eL([o.object])) {
                                    o.react(), o.showTag(!0), eR = 3, X.sfx("pop");
                                    return
                                }
                                if ("explore" !== V.phase) return;
                                let n = Z ? .pickables() ? ? [],
                                    r = U.intersectObjects(n, !1)[0];
                                if (r) {
                                    let e = n.indexOf(r.object);
                                    if (e >= 0) {
                                        if ("tour" === V.mode) {
                                            let t = ee.findIndex(t => t.memory === e);
                                            t >= 0 && eb(t)
                                        } else ev(e);
                                        return
                                    }
                                }
                                if ("walk" === V.mode) {
                                    let e = K.memories.findIndex(e => e.interaction ? .targets && eL(e.interaction.targets));
                                    if (e >= 0) return ev(e);
                                    let t = new a.Pq0;
                                    _.constant = -ef(et.x, et.z), U.ray.intersectPlane(_, t) && eM(t.x, t.z, 1.7)
                                }
                            }(e.clientX, e.clientY)
                        }
                    },
                    eq = () => {
                        eP.id = -1, ed = !1
                    },
                    eF = e => {
                        "follow" === B.mode && (e.preventDefault(), B.zoom(.004 * e.deltaY))
                    },
                    eY = {
                        KeyW: [0, 1],
                        ArrowUp: [0, 1],
                        KeyS: [0, -1],
                        ArrowDown: [0, -1],
                        KeyA: [-1, 0],
                        ArrowLeft: [-1, 0],
                        KeyD: [1, 0],
                        ArrowRight: [1, 0]
                    },
                    eD = e => {
                        let t;
                        !(!eO || z || (t = e.target) && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) && "walk" === V.mode && "explore" === V.phase && eY[e.code] && (ea.add(e.code), e.preventDefault())
                    },
                    eB = e => {
                        ea.delete(e.code)
                    },
                    eG = e => {
                        e.preventDefault(), V.contextLost = !0, e0(), F(!0)
                    };
                Y.addEventListener("pointerdown", ej), Y.addEventListener("pointermove", eI), Y.addEventListener("pointerup", eV), Y.addEventListener("pointercancel", eq), Y.addEventListener("wheel", eF, {
                    passive: !1
                }), Y.addEventListener("webglcontextlost", eG), C.addEventListener("keydown", eD), C.addEventListener("keyup", eB);
                let eO = !1,
                    eW = !1,
                    eX = "hidden" !== S.visibilityState,
                    eN = C.ResizeObserver ? new C.ResizeObserver(() => eh()) : null;
                eN ? .observe(o);
                let eU = C.IntersectionObserver ? new C.IntersectionObserver(e => {
                    eW = e.some(e => e.isIntersecting), eQ()
                }) : null;
                eU ? .observe(o), eU || (eW = !0);
                let e_ = () => {
                    eX = "hidden" !== S.visibilityState, eQ()
                };
                S.addEventListener("visibilitychange", e_);
                let eH = 0,
                    eJ = 0,
                    eK = 0,
                    eZ = 0;

                function e$() {
                    return eO && eW && eX && !V.contextLost && !!K
                }

                function eQ() {
                    e$() ? eH || (eJ = performance.now(), N.reset(), eH = C.requestAnimationFrame(e2), X.resume()) : (e0(), X.suspend())
                }

                function e0() {
                    eH && C.cancelAnimationFrame(eH), eH = 0
                }
                let e1 = new a.Pq0;

                function e2(e) {
                    if (eH = 0, !e$() || !K || !J || !H || !Z) return;
                    eH = C.requestAnimationFrame(e2);
                    let o = Math.min(.05, (e - eJ) / 1e3);
                    if (z && o < 1 / 32) return;
                    eJ = e, o <= 0 && (o = 1 / 60), eK += o;
                    let n = J.ctx;
                    if (n.time.value = eK, ec >= 0 && (ec -= o) < 0 && function() {
                            let e = ez;
                            if (ez = -1, !K || e < 0) return;
                            let t = K.memories[e];
                            t.interaction ? (V.phase = "action", V.action = {
                                index: e,
                                verb: t.interaction.verb,
                                hold: 0
                            }, F(!0)) : ek(e)
                        }(), es >= 0 && (es -= o) < 0 && eA >= 0) {
                        let e = eA;
                        eA = -1, ek(e)
                    }
                    if (eu >= 0 && (eu -= o) < 0) {
                        let e = ee[V.tourIndex];
                        e && null !== e.memory && "explore" === V.phase && "tour" === V.mode && (ez = e.memory, V.phase = "look", ec = .2)
                    }
                    if (eE >= 0 && (eE -= o) < 0 && "tour" === V.mode && "explore" === V.phase) {
                        let e = ew(),
                            t = null === e ? -1 : ee.findIndex(t => t.memory === e);
                        t >= 0 && eb(t)
                    }
                    if (eR >= 0 && (eR -= o) < 0 && n.actors.pet ? .showTag(!1), ei >= 0 && ((ei += o) > 2.6 && ei - o <= 2.6 && (P || (n.actors.a.play("swayTogether", {
                            fade: .6
                        }), n.actors.b.play("swayTogether", {
                            fade: .6
                        })), n.actors.pet ? .react()), !V.finaleReady && ei > (R ? 1.5 : 4.5) && (V.finaleReady = !0, F(!0))), "action" === V.phase && V.action ? .verb === "hold") {
                        let e = K.memories[V.action.index] ? .interaction,
                            t = e ? .holdSeconds ? ? 1.6,
                            n = V.action.hold;
                        V.action.hold = ed ? Math.min(1, n + o / t) : Math.max(0, n - o / (.6 * t)), V.action.hold !== n && e ? .hold ? .(V.action.hold), V.action.hold >= 1 && (ed = !1, eT())
                    }! function(e) {
                        if (!K || !J || J.held()) return;
                        let t = J.ctx.actors,
                            o = 0,
                            n = 0,
                            a = 0,
                            r = en.x,
                            l = en.y;
                        for (let e of ea) {
                            let t = eY[e];
                            t && (r += t[0], l += t[1])
                        }
                        let i = Math.min(1, Math.hypot(r, l));
                        if (i > .08 && "walk" === V.mode && "explore" === V.phase) {
                            eo = null;
                            let e = B.heading,
                                t = Math.sin(e),
                                s = Math.cos(e),
                                c = (t * l + -Math.cos(e) * r) / (Math.hypot(r, l) || 1),
                                u = (s * l + Math.sin(e) * r) / (Math.hypot(r, l) || 1);
                            a = 1.7 * i, o = c, n = u
                        } else if (eo) {
                            let t = eo.x - et.x,
                                r = eo.z - et.z,
                                l = Math.hypot(t, r);
                            if (eo.path.length && l < .3)[eo.x, eo.z] = eo.path.shift(), eo.stuck = 0, eo.last = 1 / 0;
                            else if (l < .08) {
                                let e = eo.onArrive;
                                eo = null, e ? .()
                            } else if (a = eo.path.length ? eo.speed : Math.min(eo.speed, 3 * l + .4), o = t / l, n = r / l, eo.stuck = l < eo.last - .002 ? 0 : eo.stuck + e, eo.last = l, eo.stuck > .8) {
                                let e = eo.onArrive;
                                eo = null, e ? .()
                            }
                        }
                        if (et.speed += (a - et.speed) * Math.min(1, 8 * e), et.speed > .02 && (o || n)) {
                            let [t, a] = M(K.walk, et.x, et.z, o * et.speed * e, n * et.speed * e);
                            et.x = t, et.z = a;
                            let r = Math.atan2(o, n),
                                l = Math.atan2(Math.sin(r - et.heading), Math.cos(r - et.heading));
                            et.heading += l * Math.min(1, 8 * e)
                        }
                        let s = (0, m.A)({
                                x: et.x,
                                z: et.z,
                                facing: et.heading
                            }),
                            c = t.a.object,
                            u = t.b.object;
                        c.position.x += (s.a[0] - c.position.x) * Math.min(1, 14 * e), c.position.z += (s.a[1] - c.position.z) * Math.min(1, 14 * e), u.position.x += (s.b[0] - u.position.x) * Math.min(1, 7 * e), u.position.z += (s.b[1] - u.position.z) * Math.min(1, 7 * e), c.position.y = ef(c.position.x, c.position.z), u.position.y = ef(u.position.x, u.position.z), c.rotation.y = et.heading, u.rotation.y += Math.atan2(Math.sin(et.heading - u.rotation.y), Math.cos(et.heading - u.rotation.y)) * Math.min(1, 6 * e);
                        let d = J.walkClips(),
                            p = et.speed > .05;
                        t.a.play(d.a, {
                            speed: p ? et.speed : 0
                        }), t.b.play(d.b, {
                            speed: p ? et.speed : 0
                        }), V.walking = p, el = p ? 0 : el + e
                    }(o),
                    function(e) {
                        let t = J ? .ctx.actors.pet;
                        if (!t || !K || !J || J.held() && "held" !== er.mode) return;
                        let o = t.object,
                            n = er.x,
                            a = er.z,
                            r = "idle";
                        if ("held" === er.mode) er.wander && ([n, a] = er.wander);
                        else {
                            let e = (0, m.A)({
                                x: et.x,
                                z: et.z,
                                facing: et.heading
                            }).pet;
                            if (el > 22) er.mode = "sleep";
                            else if (el > 4) {
                                if ("follow" === er.mode) {
                                    er.mode = "wander";
                                    let e = Math.random() * Math.PI * 2,
                                        t = 1.2 + 1.4 * Math.random(),
                                        [o, n] = b(K.walk, et.x + Math.cos(e) * t, et.z + Math.sin(e) * t, .25);
                                    er.wander = [o, n]
                                }
                            } else er.mode = "follow";
                            "follow" === er.mode ? [n, a] = e : "wander" === er.mode && er.wander && ([n, a] = er.wander)
                        }
                        let l = n - er.x,
                            i = a - er.z,
                            s = Math.hypot(l, i);
                        if (s > .12 && "sleep" !== er.mode) {
                            let t = Math.min(2.4, 2.5 * s),
                                [o, n] = M(K.walk, er.x, er.z, l / s * t * e, i / s * t * e, .2);
                            er.x = o, er.z = n;
                            let a = Math.atan2(l, i);
                            er.heading += Math.atan2(Math.sin(a - er.heading), Math.cos(a - er.heading)) * Math.min(1, 7 * e), r = "trot"
                        } else "sleep" === er.mode ? r = "sleep" : ("wander" === er.mode || "held" === er.mode) && (r = "sit");
                        o.position.set(er.x, ef(er.x, er.z), er.z), o.rotation.y = er.heading, t.play(r, {
                            speed: s
                        })
                    }(o), K.update(eK, o), n.actors.a.update(o), n.actors.b.update(o), n.actors.pet ? .update(o), "card" === V.phase || "look" === V.phase ? (n.actors.a.lookAt(D.position), n.actors.b.lookAt(D.position)) : V.walking ? (n.actors.a.lookAt(null), n.actors.b.lookAt(null)) : (n.actors.a.lookAt(n.actors.b.object.position.clone().setY(1.05)), n.actors.b.lookAt(n.actors.a.object.position.clone().setY(1.05))), e1.set(et.x, ef(et.x, et.z), et.z), V.target = V.found.every(Boolean) ? null : ew();
                    let a = "explore" === V.phase || "choose" === V.phase || "edit" === V.phase;
                    Z.update(eK, o, e1, V.target, a), "walk" === V.mode && "explore" === V.phase ? V.near = Z.near(et.x, et.z) : "explore" !== V.phase && (V.near = null), B.update(o, e1, et.heading, V.walking, eP.id >= 0 && eP.moved), K.sky && K.sky.position.copy(D.position), t.info.reset(), $ ? $.render(o) : t.render(H, D), V.drawCalls = t.info.render.calls;
                    let r = z ? "ok" : N.sample(o, I, "auto" === j);
                    if (V.fps = Math.round(N.fps), "drop" === r) {
                        V.quality = I = "low", e4();
                        return
                    }
                    "fallback" === r ? E("slow") : (eZ -= o) <= 0 && (eZ = .15, F())
                }
                let e5 = !1;

                function e4() {
                    let e = [...V.found],
                        t = V.phase,
                        o = {
                            x: et.x,
                            z: et.z,
                            facing: et.heading
                        };
                    e0();
                    try {
                        ey()
                    } catch {
                        E("error");
                        return
                    }
                    V.found = e, Z ? .setFound(e);
                    try {
                        K ? .restore ? .(e)
                    } catch {}
                    em(o), V.phase = t, "walk" === V.mode && ("explore" === t || "choose" === t) && B.follow(et.heading), eQ(), F(!0)
                }
                let e3 = [() => {
                        V.progress = .15
                    }, () => {
                        ey(), V.progress = .65
                    }, () => {
                        if (K && H) {
                            if (em(K.spawn), z) {
                                let e = ee[0];
                                e ? (em(e.stand), B.cut(e.shot)) : B.cut(K.intro[K.intro.length - 1] ? ? K.letter), V.phase = "edit"
                            } else B.cut(K.intro[0] ? ? K.letter), V.phase = "ready";
                            t.compile(H, D), V.progress = 1
                        }
                    }],
                    e6 = 0,
                    e8 = !1;

                function e9() {
                    K && "ready" === V.phase && (V.phase = "intro", F(!0), X.startAmbience(g, K.ambience, L.mood), B.fly(K.intro, 2.3 * !R, () => {
                        "intro" === V.phase && (V.phase = "choose", F(!0))
                    }))
                }
                return C.setTimeout(function e() {
                    if (!e5) {
                        try {
                            e3[e6] ? .()
                        } catch {
                            E("error");
                            return
                        }
                        e6++, F(!0), e6 < e3.length ? C.setTimeout(e, 16) : (eQ(), e8 && e9())
                    }
                }, 0), {
                    get state() {
                        return V
                    },
                    setValues(e) {
                        let t = L.accent;
                        if (L = e, !J || !K) return;
                        let o = J.setValues(e, () => {
                            K && J && K.setValues(J.sceneValues())
                        });
                        if (o.mood && K.setMood(e.mood), o.scene && K.setValues(J.sceneValues()), t !== e.accent && Z ? .setAccent(e.accent), J.ctx.actors.pet) {
                            let e = (0, m.A)({
                                x: et.x,
                                z: et.z,
                                facing: et.heading
                            }).pet;
                            Math.hypot(er.x - et.x, er.z - et.z) > 6 && ([er.x, er.z] = e)
                        }
                        ex(J.actorsRoot)
                    },
                    setActive(e) {
                        eO = e, eQ()
                    },
                    start() {
                        "ready" === V.phase ? e9() : "loading" === V.phase && (e8 = !0)
                    },
                    skipIntro() {
                        "intro" === V.phase && B.skip()
                    },
                    choose(e) {
                        if (K)
                            if (X.unlock(), V.mode = e, "walk" === e) V.phase = "explore", B.follow(et.heading), F(!0);
                            else {
                                let e = ew();
                                eb(null === e ? 0 : Math.max(0, ee.findIndex(t => t.memory === e)))
                            }
                    },
                    tourNext() {
                        "card" === V.phase && (V.open = null), eb(V.tourIndex + 1)
                    },
                    tourBack() {
                        "card" === V.phase && (V.open = null), eb(V.tourIndex - 1)
                    },
                    setAutoTour(e) {
                        V.autoTour = e, F(!0)
                    },
                    look(e) {
                        let t = e ? ? V.near;
                        null != t && (X.unlock(), ev(t))
                    },
                    closeCard() {
                        "card" === V.phase && (V.open = null, V.action = null, V.phase = "explore", "walk" === V.mode ? B.follow(et.heading) : V.autoTour && !V.found.every(Boolean) && (eE = 1.1), F(!0))
                    },
                    actionDown() {
                        X.unlock(), "action" === V.phase && V.action && ("tap" === V.action.verb ? eT() : ed = !0)
                    },
                    actionUp() {
                        ed = !1
                    },
                    openLetter() {
                        K && (V.open = null, V.action = null, V.phase = "letter", B.goTo(K.letter, 2 * !R), X.sfx("chime"), F(!0))
                    },
                    closeLetter() {
                        "letter" === V.phase && function() {
                            if (!K || !J) return;
                            let {
                                actors: e,
                                stage: t
                            } = J.ctx;
                            V.phase = "finale", V.open = null, V.finaleReady = !1, t.hold();
                            let o = K.finale.spot;
                            if (em(o), P) {
                                let t = (0, m.A)(o, .22);
                                e.a.object.position.set(t.a[0], ef(t.a[0], t.a[1]), t.a[1]), e.b.object.position.set(t.b[0], ef(t.b[0], t.b[1]), t.b[1]), e.a.object.rotation.y = o.facing, e.b.object.rotation.y = o.facing, e.a.play("sideHug", {
                                    fade: .5
                                }), e.b.play("sideHug", {
                                    fade: .5
                                }), e.a.setExpression("laugh"), e.b.setExpression("happy")
                            } else {
                                let t = (0, m.A)(o, .2);
                                e.a.object.position.set(t.a[0], 0, t.a[1]), e.b.object.position.set(t.b[0], 0, t.b[1]), e.a.object.rotation.y = o.facing - Math.PI / 2, e.b.object.rotation.y = o.facing + Math.PI / 2, e.a.play("hug", {
                                    fade: .4
                                }), e.b.play("hug", {
                                    fade: .4
                                }), e.a.setExpression("love"), e.b.setExpression("love")
                            }
                            if (er.mode = "held", e.pet) {
                                let [e, t] = (0, m.A)(o).pet;
                                er.wander = [e, t]
                            }
                            let n = K.finale.shot,
                                [a, r, l] = n.look,
                                i = D.aspect < .8 ? { ...n,
                                    look: [a + (o.x - a) * .5, r + (1.1 - r) * .5, l + (o.z - l) * .5]
                                } : n,
                                [s, , c] = i.pos,
                                u = D.position.x,
                                d = D.position.z,
                                p = s - u,
                                h = c - d,
                                f = Math.max(0, Math.min(1, ((o.x - u) * p + (o.z - d) * h) / (p * p + h * h || 1)));
                            if (!R && 1.6 > Math.hypot(u + p * f - o.x, d + h * f - o.z)) {
                                let [e, , t] = i.look, [, o] = i.pos;
                                B.cut({ ...i,
                                    pos: [e + (s - e) * 1.35, o + 1.4, t + (c - t) * 1.35]
                                })
                            }
                            B.goTo(i, 2.6 * !R);
                            try {
                                K.finale.start()
                            } catch {}
                            X.sfx("chime"), X.duckAmbience(.2), ei = 0, F(!0)
                        }()
                    },
                    replay() {
                        if (K && J) {
                            for (let e of (J.ctx.stage.release(), V.found = V.found.map(() => !1), Z ? .setFound(V.found), K.memories)) try {
                                e.interaction ? .reset ? .()
                            } catch {}
                            try {
                                K.finale.reset ? .()
                            } catch {}
                            ep.clear(), X.duckAmbience(1), J.ctx.actors.a.setExpression("happy"), J.ctx.actors.b.setExpression("happy"), er.mode = "follow", ei = -1, V.finaleReady = !1, em(K.spawn), V.tourIndex = 0
                        }
                        K && B.goTo(K.intro[K.intro.length - 1] ? ? K.letter, 1.2), V.phase = "choose", V.open = null, V.action = null, F(!0)
                    },
                    setGuide(e) {
                        V.guide = e, Z ? .setGuide(e), F(!0)
                    },
                    setQuality(e) {
                        j = e, V.qualityChoice = e;
                        let t = "auto" === e ? (0, f.o)(C) : e;
                        t !== I && (I = t, V.quality = t, K && e4()), F(!0)
                    },
                    setReducedMotion(e) {
                        R = e
                    },
                    setVolume(e) {
                        X.setVolume(e)
                    },
                    unlockAudio() {
                        X.unlock()
                    },
                    joystick(e, t) {
                        en.set(e, t)
                    },
                    dispose() {
                        e5 = !0, e0(), Y.removeEventListener("pointerdown", ej), Y.removeEventListener("pointermove", eI), Y.removeEventListener("pointerup", eV), Y.removeEventListener("pointercancel", eq), Y.removeEventListener("wheel", eF), Y.removeEventListener("webglcontextlost", eG), C.removeEventListener("keydown", eD), C.removeEventListener("keyup", eB), S.removeEventListener("visibilitychange", e_), eN ? .disconnect(), eU ? .disconnect(), X.dispose(), eg(), t.dispose(), t.forceContextLoss(), Y.remove()
                    }
                }
            }

            function T(e) {
                let t = () => {};
                return {
                    state: e,
                    setValues: t,
                    setActive: t,
                    start: t,
                    skipIntro: t,
                    choose: t,
                    tourNext: t,
                    tourBack: t,
                    setAutoTour: t,
                    look: t,
                    closeCard: t,
                    actionDown: t,
                    actionUp: t,
                    openLetter: t,
                    closeLetter: t,
                    replay: t,
                    setGuide: t,
                    setQuality: t,
                    setReducedMotion: t,
                    setVolume: t,
                    unlockAudio: t,
                    joystick: t,
                    dispose: t
                }
            }
        },
        93440: (e, t, o) => {
            function n(e) {
                let t = e ? .navigator;
                if (!t) return "low";
                let o = t.deviceMemory,
                    n = t.hardwareConcurrency;
                return o && o <= 4 || n && n <= 4 || (e ? .screen ? .width ? ? 1e3) < 500 && (!o || o < 6) ? "low" : "high"
            }

            function a() {
                let e = 0,
                    t = 0,
                    o = 0,
                    n = 60,
                    a = 0;
                return {
                    get fps() {
                        return n
                    },
                    reset() {
                        e = 0, t = 0, o = 0, a = 0
                    },
                    sample(r, l, i) {
                        if ((a += r) < 2.5 || (e += r, t++, e < .5)) return "ok";
                        if (n = t / e, e = 0, t = 0, n < ("high" === l ? 40 : 20) ? o += .5 : o = Math.max(0, o - .5), o >= 3) {
                            if (o = 0, "high" === l && i) return "drop";
                            if ("low" === l) return "fallback"
                        }
                        return "ok"
                    }
                }
            }
            o.d(t, {
                o: () => n,
                s: () => a
            })
        }
    }
]);