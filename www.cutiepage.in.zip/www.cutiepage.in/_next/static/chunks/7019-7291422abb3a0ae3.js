(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7019], {
        7019: (e, t, l) => {
            "use strict";
            l.r(t), l.d(t, {
                CakeCeremony: () => C,
                ConfettiTap: () => d,
                DeckCard: () => N,
                GiftBox: () => S,
                HoldToWish: () => b,
                LightsContinue: () => j,
                LightsGate: () => v,
                LockNotice: () => k,
                LockScreen: () => x,
                StoryDeck: () => y
            });
            var n = l(73365),
                i = l(1521),
                o = l(94830),
                s = l(87191),
                a = l(34768),
                r = l(82161);

            function c() {
                let e = (0, i.useRef)([]);
                return (0, i.useEffect)(() => () => {
                    for (let t of e.current) clearTimeout(t)
                }, []), {
                    later: (0, i.useCallback)((t, l) => {
                        e.current.push(setTimeout(t, l))
                    }, []),
                    clear: (0, i.useCallback)(() => {
                        for (let t of e.current) clearTimeout(t);
                        e.current = []
                    }, [])
                }
            }

            function d({
                children: e,
                effect: t = "popper",
                className: l,
                style: o
            }) {
                let c = (0, a.useMode)(),
                    u = (0, r.useSoundEffect)(),
                    [f, h] = (0, i.useState)(0),
                    p = "edit" === c;
                return (0, n.jsxs)("div", {
                    className: `folio-ctap${l?` ${l}`:""}`,
                    style: o,
                    ...!p && f > 0 ? {
                        "data-tap": f % 2 == 1 ? "a" : "b"
                    } : {},
                    onClick: p ? void 0 : () => {
                        h(e => e + 1), u(t)
                    },
                    children: [e, !p && f > 0 ? (0, n.jsx)(s.ConfettiBurst, {
                        seed: f + 60,
                        count: 16,
                        top: "30%"
                    }, f) : null]
                })
            }

            function u(e) {
                let t = setInterval(e, 15e3);
                return () => clearInterval(t)
            }
            l(30032);
            let f = () => Math.floor(Date.now() / 6e4),
                h = () => null;

            function p() {
                let e = (0, i.useSyncExternalStore)(u, f, h),
                    t = "9:41";
                if (null !== e) {
                    let l = new Date(6e4 * e);
                    t = (0, o.pW)(l.getHours(), l.getMinutes())
                }
                return (0, n.jsx)("span", {
                    className: "folio-lock-time",
                    children: t
                })
            }

            function x({
                date: e,
                notifications: t,
                wallpaper: l,
                slideLabel: d,
                className: u
            }) {
                let f = (0, a.useMode)(),
                    h = (0, a.useStory)(),
                    k = (0, r.useFolioSound)(),
                    m = (0, i.useRef)(null),
                    j = (0, i.useRef)(null),
                    v = (0, i.useRef)(null),
                    [g, y] = (0, i.useState)(0),
                    [N, b] = (0, i.useState)(!1),
                    [C, S] = (0, i.useState)(!1),
                    {
                        later: $,
                        clear: w
                    } = c(),
                    M = "edit" === f;
                (0, s.useReplaySignal)(m, () => {
                    w(), y(0), b(!1), S(!1)
                });
                let I = e => {
                        M || C || (k.unlock(e), y(1), S(!0), k.playEffect("unlock"), $(() => {
                            h.next()
                        }, 1e3))
                    },
                    E = () => {
                        let e = j.current,
                            t = e ? .querySelector(".folio-lock-knob");
                        return {
                            track: e ? .clientWidth ? ? 0,
                            knob: t ? .offsetWidth ? ? 0
                        }
                    };
                return (0, n.jsx)("div", {
                    ref: m,
                    className: `folio-lock${C?" is-unlocked":""}${u?` ${u}`:""}`,
                    children: (0, n.jsxs)("div", {
                        className: "folio-lock-phone",
                        children: [l ? (0, n.jsx)("div", {
                            className: "folio-lock-wallpaper",
                            children: l
                        }) : null, (0, n.jsxs)("div", {
                            className: "folio-lock-glass",
                            children: [(0, n.jsx)("div", {
                                className: "folio-lock-island",
                                "aria-hidden": !0
                            }), (0, n.jsxs)("div", {
                                className: "folio-lock-head",
                                children: [(0, n.jsx)("span", {
                                    "aria-hidden": !0,
                                    className: "folio-lock-padlock",
                                    children: (0, n.jsxs)("svg", {
                                        viewBox: "0 0 24 24",
                                        children: [(0, n.jsx)("path", {
                                            d: "M7 10V7a5 5 0 0 1 10 0v3",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "2.4",
                                            strokeLinecap: "round"
                                        }), (0, n.jsx)("rect", {
                                            x: "4.5",
                                            y: "10",
                                            width: "15",
                                            height: "11",
                                            rx: "3",
                                            fill: "currentColor"
                                        })]
                                    })
                                }), (0, n.jsx)("div", {
                                    className: "folio-lock-date",
                                    children: e
                                }), (0, n.jsx)(p, {})]
                            }), t ? (0, n.jsx)("div", {
                                className: "folio-lock-notices",
                                children: t
                            }) : null, (0, n.jsxs)("div", {
                                ref: j,
                                className: "folio-lock-track",
                                children: [(0, n.jsx)("span", {
                                    className: "folio-lock-slide-label",
                                    style: {
                                        opacity: 1 - 1.4 * g
                                    },
                                    children: d
                                }), (0, n.jsx)("button", {
                                    type: "button",
                                    className: "folio-lock-knob",
                                    "aria-label": "Slide to unlock",
                                    tabIndex: M ? -1 : void 0,
                                    style: {
                                        "--slide": g,
                                        transition: N ? "none" : void 0
                                    },
                                    onPointerDown: e => {
                                        M || C || (v.current = {
                                            id: e.pointerId,
                                            x0: e.clientX,
                                            moved: !1
                                        }, e.currentTarget.setPointerCapture ? .(e.pointerId), b(!0))
                                    },
                                    onPointerMove: e => {
                                        let t = v.current;
                                        if (!t || t.id !== e.pointerId) return;
                                        let l = e.clientX - t.x0;
                                        Math.abs(l) > 8 && (t.moved = !0);
                                        let {
                                            track: n,
                                            knob: i
                                        } = E();
                                        y((0, o.oX)(l, n, i))
                                    },
                                    onPointerUp: e => {
                                        let t = v.current;
                                        if (!t || t.id !== e.pointerId) return;
                                        v.current = null, b(!1);
                                        let {
                                            track: l,
                                            knob: n
                                        } = E(), i = (0, o.oX)(e.clientX - t.x0, l, n);
                                        !t.moved || i >= o.lu ? I(e.currentTarget) : y(0)
                                    },
                                    onPointerCancel: () => {
                                        v.current = null, b(!1), y(0)
                                    },
                                    onKeyDown: e => {
                                        ("Enter" === e.key || " " === e.key) && (e.preventDefault(), I(e.currentTarget))
                                    },
                                    children: (0, n.jsx)("svg", {
                                        viewBox: "0 0 24 24",
                                        "aria-hidden": !0,
                                        children: (0, n.jsx)("path", {
                                            d: "M9 5l7 7-7 7",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "3",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        })
                                    })
                                })]
                            }), (0, n.jsx)("div", {
                                className: "folio-lock-homebar",
                                "aria-hidden": !0
                            })]
                        })]
                    })
                })
            }

            function k({
                app: e,
                title: t,
                children: l,
                when: i,
                icon: o
            }) {
                let {
                    index: s
                } = (0, a.useItemPosition)();
                return (0, n.jsxs)("div", {
                    className: "folio-lock-notice",
                    style: {
                        "--n": s
                    },
                    children: [(0, n.jsx)("span", {
                        "aria-hidden": !0,
                        className: "folio-lock-notice-icon",
                        children: o
                    }), (0, n.jsxs)("div", {
                        className: "folio-lock-notice-body",
                        children: [(0, n.jsxs)("div", {
                            className: "folio-lock-notice-top",
                            children: [(0, n.jsx)("span", {
                                className: "folio-lock-notice-app",
                                children: e
                            }), i ? (0, n.jsx)("span", {
                                className: "folio-lock-notice-when",
                                children: i
                            }) : null]
                        }), (0, n.jsx)("div", {
                            className: "folio-lock-notice-title",
                            children: t
                        }), (0, n.jsx)("div", {
                            className: "folio-lock-notice-text",
                            children: l
                        })]
                    })]
                })
            }
            let m = (0, i.createContext)({
                lit: !1,
                editing: !1,
                next: null
            });

            function j({
                children: e,
                className: t
            }) {
                let l = (0, i.useContext)(m);
                if (l.editing) return (0, n.jsx)("span", {
                    className: `folio-pill${t?` ${t}`:""}`,
                    "aria-hidden": !0,
                    children: e
                });
                if (!l.lit || !l.next) return null;
                let o = l.next;
                return (0, n.jsx)("button", {
                    type: "button",
                    className: `folio-pill folio-lights-continue${t?` ${t}`:""}`,
                    onClick: () => o(),
                    children: e
                })
            }

            function v({
                dark: e,
                hint: t,
                children: l,
                className: d
            }) {
                let u = (0, a.useMode)(),
                    f = (0, a.useStory)(),
                    h = (0, r.useFolioSound)(),
                    p = (0, i.useRef)(null),
                    x = (0, i.useRef)(null),
                    [k, j] = (0, i.useState)(0),
                    [g, y] = (0, i.useState)(!1),
                    [N, b] = (0, i.useState)(!1),
                    [C, S] = (0, i.useState)(!1),
                    {
                        later: $,
                        clear: w
                    } = c(),
                    M = "edit" === u;
                (0, s.useReplaySignal)(p, () => {
                    w(), j(0), y(!1), b(!1), S(!1)
                });
                let I = e => {
                        M || C || (h.unlock(e), h.playEffect("switch"), S(!0), $(() => h.playEffect("popper"), 380))
                    },
                    E = M || C;
                return (0, n.jsxs)("div", {
                    ref: p,
                    className: `folio-lights${E?" is-lit":""}${M?" is-editing":""}${d?` ${d}`:""}`,
                    children: [M ? (0, n.jsx)("div", {
                        className: "folio-lights-dark is-preview",
                        children: e
                    }) : null, (0, n.jsxs)("div", {
                        className: "folio-lights-room",
                        children: [(0, n.jsx)(m.Provider, {
                            value: {
                                lit: C,
                                editing: M,
                                next: f.active ? f.next : null
                            },
                            children: l
                        }), C && !M ? (0, n.jsx)(s.ConfettiBurst, {
                            seed: 14,
                            count: 40,
                            top: "34%"
                        }) : null]
                    }), M ? null : (0, n.jsx)("div", {
                        className: "folio-lights-dark",
                        "aria-hidden": !!C || void 0,
                        children: (0, n.jsx)("div", {
                            className: "folio-lights-dark-content",
                            children: e
                        })
                    }), !M && C ? (0, n.jsx)("span", {
                        "aria-hidden": !0,
                        className: "folio-lights-flash"
                    }) : null, (0, n.jsxs)("div", {
                        className: "folio-lights-cord",
                        children: [(0, n.jsx)("span", {
                            "aria-hidden": !0,
                            className: "folio-lights-bulb"
                        }), (0, n.jsxs)("button", {
                            type: "button",
                            className: `folio-lights-pull${N?" is-tugging":""}`,
                            "aria-label": "Pull the cord to turn on the lights",
                            disabled: E,
                            tabIndex: M ? -1 : void 0,
                            style: {
                                "--stretch": Math.round(k),
                                transition: g ? "none" : void 0
                            },
                            onPointerDown: e => {
                                M || C || (x.current = {
                                    id: e.pointerId,
                                    y0: e.clientY,
                                    moved: !1
                                }, e.currentTarget.setPointerCapture ? .(e.pointerId), y(!0))
                            },
                            onPointerMove: e => {
                                let t = x.current;
                                if (!t || t.id !== e.pointerId) return;
                                let l = e.clientY - t.y0;
                                Math.abs(l) > 8 && (t.moved = !0), j((0, o.yF)(l))
                            },
                            onPointerUp: e => {
                                let t = x.current;
                                if (!t || t.id !== e.pointerId) return;
                                x.current = null, y(!1), j(0);
                                let l = e.clientY - t.y0;
                                if (t.moved) l >= o.Hs && I(e.currentTarget);
                                else {
                                    b(!0);
                                    let t = e.currentTarget;
                                    h.unlock(t), $(() => {
                                        b(!1), I(t)
                                    }, 260)
                                }
                            },
                            onPointerCancel: () => {
                                x.current = null, y(!1), j(0)
                            },
                            onKeyDown: e => {
                                ("Enter" === e.key || " " === e.key) && (e.preventDefault(), I(e.currentTarget))
                            },
                            children: [(0, n.jsx)("span", {
                                "aria-hidden": !0,
                                className: "folio-lights-string"
                            }), (0, n.jsx)("span", {
                                "aria-hidden": !0,
                                className: "folio-lights-bob"
                            })]
                        }), M || !C ? (0, n.jsx)("span", {
                            className: "folio-lights-hint",
                            children: t
                        }) : null]
                    })]
                })
            }
            let g = (0, i.createContext)(null);

            function y({
                count: e,
                stackId: t,
                nextLabel: l = "Next card \u203a",
                tapHint: c,
                end: d,
                children: u,
                className: f
            }) {
                let h = (0, a.useMode)(),
                    p = (0, r.useSoundEffect)(),
                    x = (0, i.useRef)(null),
                    [k, m] = (0, i.useState)(0),
                    [j, v] = (0, i.useState)(0),
                    N = "edit" === h,
                    b = Math.max(0, e - 1),
                    C = (0, a.useStackEntryIds)(t ? ? ""),
                    S = (0, a.useEditFocusItemId)(),
                    $ = N && S ? C.indexOf(S) : -1,
                    [w, M] = (0, i.useState)(0);
                $ >= 0 && $ !== w && M($);
                let I = Math.min(N ? w : k, b),
                    E = I >= b;
                (0, s.useReplaySignal)(x, () => {
                    m(0), v(0)
                });
                let P = () => {
                    if (N) return;
                    if (E) {
                        v(e => e + 1), p("tap");
                        return
                    }
                    let t = (0, o.m7)(k, e);
                    m(t), p(t >= b ? "win" : "next")
                };
                return (0, n.jsxs)("div", {
                    ref: x,
                    className: `folio-deck${N?" is-editing":""}${f?` ${f}`:""}`,
                    children: [N ? null : (0, n.jsx)("ol", {
                        className: "folio-deck-progress",
                        "aria-label": `Card ${I+1} of ${e}`,
                        children: Array.from({
                            length: e
                        }, (e, t) => (0, n.jsx)("li", {
                            className: t <= k ? "is-done" : void 0
                        }, t))
                    }), (0, n.jsx)("div", {
                        className: "folio-deck-cards",
                        ...!N ? {
                            role: "button",
                            tabIndex: 0,
                            "aria-label": "Next card",
                            onClick: P,
                            onKeyDown: e => {
                                ("Enter" === e.key || " " === e.key) && (e.preventDefault(), P())
                            }
                        } : {},
                        ...j > 0 ? {
                            "data-bump": j % 2 == 1 ? "a" : "b"
                        } : {},
                        children: (0, n.jsx)(g.Provider, {
                            value: {
                                current: I
                            },
                            children: u
                        })
                    }), N && t && C.length > 1 ? (0, n.jsx)("div", {
                        className: "folio-deck-tabs",
                        "aria-label": "Cards",
                        children: C.map((e, l) => (0, n.jsx)("button", {
                            type: "button",
                            tabIndex: -1,
                            "data-folio-pick": e,
                            "data-folio-pick-stack": t,
                            "aria-label": `Edit card ${l+1}`,
                            "aria-current": l === I ? "true" : void 0,
                            children: l + 1
                        }, e))
                    }) : null, N ? (0, n.jsxs)("div", {
                        className: "folio-deck-foot",
                        children: [C.length > 1 ? (0, n.jsx)("button", {
                            type: "button",
                            tabIndex: -1,
                            className: "folio-deck-next",
                            "data-folio-pick": C[(I + 1) % C.length],
                            "data-folio-pick-stack": t,
                            children: l
                        }) : null, d]
                    }) : (0, n.jsx)("div", {
                        className: "folio-deck-foot",
                        children: E && d ? d : (0, n.jsxs)(n.Fragment, {
                            children: [c ? (0, n.jsx)("span", {
                                className: "folio-deck-hint",
                                children: c
                            }) : null, E ? null : (0, n.jsx)("button", {
                                type: "button",
                                className: "folio-deck-next",
                                onClick: P,
                                children: l
                            })]
                        })
                    })]
                })
            }

            function N({
                children: e,
                className: t,
                style: l
            }) {
                let s = (0, i.useContext)(g),
                    {
                        index: r
                    } = (0, a.useItemPosition)();
                if (!s) return (0, n.jsx)("div", {
                    className: `folio-deck-card${t?` ${t}`:""}`,
                    style: l,
                    children: e
                });
                let c = (0, o.v6)(r, s.current),
                    d = "behind" === c.kind ? {
                        "--depth": Math.min(c.depth, 3),
                        zIndex: 20 - c.depth
                    } : "top" === c.kind ? {
                        zIndex: 20
                    } : {
                        "--side": (0, o.R1)(r),
                        zIndex: 21
                    };
                return (0, n.jsx)("div", {
                    className: `folio-deck-card is-${c.kind}${t?` ${t}`:""}`,
                    style: { ...l,
                        ...d
                    },
                    "aria-hidden": "top" !== c.kind || void 0,
                    children: e
                })
            }

            function b({
                label: e,
                holdingLabel: t,
                doneLabel: l,
                children: c,
                className: d
            }) {
                let u = (0, a.useMode)(),
                    f = (0, r.useFolioSound)(),
                    h = (0, i.useRef)(null),
                    p = (0, i.useRef)(null),
                    [x, k] = (0, i.useState)(!1),
                    [m, j] = (0, i.useState)(!1),
                    v = "edit" === u,
                    g = v || m,
                    y = (0, s.usePrefersReducedMotion)() ? 400 : o.dy,
                    N = () => {
                        p.current && clearTimeout(p.current), p.current = null, k(!1)
                    };
                (0, i.useEffect)(() => () => {
                    p.current && clearTimeout(p.current)
                }, []), (0, s.useReplaySignal)(h, () => {
                    N(), j(!1)
                });
                let C = () => {
                        p.current = null, k(!1), j(!0), f.playEffect("win")
                    },
                    S = e => {
                        v || m || x || (f.unlock(e), f.playEffect("charge"), k(!0), p.current = setTimeout(C, y))
                    },
                    $ = () => {
                        x && !m && N()
                    };
                return (0, n.jsxs)("div", {
                    ref: h,
                    className: `folio-wish${x?" is-holding":""}${g?" is-done":""}${d?` ${d}`:""}`,
                    style: {
                        "--hold-ms": `${y}ms`
                    },
                    children: [(0, n.jsx)("div", {
                        className: "folio-wish-orbit",
                        "aria-hidden": !0,
                        children: Array.from({
                            length: 8
                        }, (e, t) => (0, n.jsx)("i", {
                            style: {
                                "--k": t
                            }
                        }, t))
                    }), (0, n.jsxs)("button", {
                        type: "button",
                        className: "folio-wish-button",
                        disabled: g,
                        tabIndex: v ? -1 : void 0,
                        onPointerDown: e => {
                            e.currentTarget.setPointerCapture ? .(e.pointerId), S(e.currentTarget)
                        },
                        onPointerUp: $,
                        onPointerCancel: $,
                        onLostPointerCapture: $,
                        onContextMenu: e => e.preventDefault(),
                        onKeyDown: e => {
                            " " !== e.key && "Enter" !== e.key || e.repeat || (e.preventDefault(), S(e.currentTarget))
                        },
                        onKeyUp: e => {
                            (" " === e.key || "Enter" === e.key) && $()
                        },
                        onClick: e => {
                            0 !== e.detail || x || m || v || (f.unlock(e.currentTarget), C())
                        },
                        children: [(0, n.jsxs)("svg", {
                            className: "folio-wish-ring",
                            viewBox: "0 0 120 120",
                            "aria-hidden": !0,
                            children: [(0, n.jsx)("circle", {
                                cx: "60",
                                cy: "60",
                                r: "54",
                                pathLength: 100
                            }), (0, n.jsx)("circle", {
                                cx: "60",
                                cy: "60",
                                r: "54",
                                pathLength: 100,
                                className: "folio-wish-ring-fill"
                            })]
                        }), (0, n.jsx)("span", {
                            className: "folio-wish-label",
                            children: g && l ? l : x ? t : e
                        })]
                    }), g ? (0, n.jsx)("div", {
                        className: "folio-wish-done",
                        children: c
                    }) : null, m && !v ? (0, n.jsx)(s.ConfettiBurst, {
                        seed: 31,
                        count: 30,
                        top: "40%"
                    }) : null]
                })
            }

            function C({
                age: e,
                cake: t,
                inside: l,
                blowText: d,
                cutText: u,
                doneText: f,
                cutForMeLabel: h,
                continueLabel: p,
                className: x
            }) {
                let k = (0, a.useMode)(),
                    m = (0, a.useStory)(),
                    j = (0, r.useFolioSound)(),
                    v = (0, i.useRef)(null),
                    g = (0, i.useRef)(null),
                    y = (0, i.useRef)(null),
                    N = (0, o.F1)(e),
                    [b, S] = (0, i.useState)([]),
                    [$, w] = (0, i.useState)("blow"),
                    [M, I] = (0, i.useState)(null),
                    [E, P] = (0, i.useState)(.5),
                    {
                        later: R,
                        clear: T
                    } = c(),
                    D = "edit" === k,
                    B = D ? "done" : $;
                (0, s.useReplaySignal)(v, () => {
                    T(), S([]), w("blow"), I(null), P(.5)
                });
                let F = e => {
                        D || "cut" !== $ || (P(e), I(null), w("done"), j.playEffect("cut"), R(() => j.playEffect("popper"), 260))
                    },
                    L = e => {
                        let t = g.current ? .getBoundingClientRect();
                        return t ? {
                            x: e.clientX - t.left,
                            y: e.clientY - t.top
                        } : {
                            x: 0,
                            y: 0
                        }
                    },
                    W = D || "cut" !== $ ? {} : {
                        onPointerDown: e => {
                            e.currentTarget.setPointerCapture ? .(e.pointerId);
                            let t = L(e);
                            y.current = {
                                id: e.pointerId,
                                start: t
                            }, I({
                                x: t.x,
                                y0: t.y,
                                y1: t.y
                            }), j.playEffect("scratch")
                        },
                        onPointerMove: e => {
                            let t = y.current;
                            if (!t || t.id !== e.pointerId) return;
                            let l = L(e);
                            I({
                                x: t.start.x,
                                y0: t.start.y,
                                y1: Math.max(t.start.y, l.y)
                            })
                        },
                        onPointerUp: e => {
                            let t = y.current;
                            if (!t || t.id !== e.pointerId) return;
                            y.current = null;
                            let l = L(e),
                                n = g.current ? .getBoundingClientRect(),
                                i = n ? .width ? ? 0,
                                s = n ? .height ? ? 0;
                            (0, o.Do)(t.start, l, i, s) ? F((0, o.og)(t.start, l, i)): (I(null), j.playEffect("nope"))
                        },
                        onPointerCancel: () => {
                            y.current = null, I(null)
                        }
                    },
                    U = (e, i = !1) => (0, n.jsxs)("div", {
                        className: "folio-cake-unit",
                        children: [(0, n.jsx)("div", {
                            className: "folio-cake-candles",
                            children: N.map((t, l) => {
                                let i = !D && (b.includes(l) || "blow" !== $);
                                return (0, n.jsxs)("span", {
                                    className: `folio-cake-candle${t?" is-number":""}${i?" is-out":""}`,
                                    children: [!e || D || "blow" !== $ || i ? null : (0, n.jsx)("button", {
                                        type: "button",
                                        className: "folio-cake-flame-hit",
                                        "aria-label": `Blow out candle ${l+1}`,
                                        onClick: e => ((e, t) => {
                                            if (D || "blow" !== $ || b.includes(e)) return;
                                            j.unlock(t), j.playEffect("puff");
                                            let l = [...b, e];
                                            S(l), l.length >= N.length && R(() => {
                                                w("cut"), j.playEffect("reveal")
                                            }, 700)
                                        })(l, e.currentTarget)
                                    }), (0, n.jsx)("span", {
                                        "aria-hidden": !0,
                                        className: "folio-cake-flame"
                                    }), i && !D ? (0, n.jsx)("span", {
                                        "aria-hidden": !0,
                                        className: "folio-cake-smoke"
                                    }) : null, (0, n.jsx)("span", {
                                        "aria-hidden": !0,
                                        className: "folio-cake-wick"
                                    }), (0, n.jsx)("span", {
                                        className: "folio-cake-wax",
                                        children: t
                                    })]
                                }, l)
                            })
                        }), (0, n.jsxs)("div", {
                            className: "folio-cake-art",
                            children: [i ? (0, n.jsx)("div", {
                                className: "folio-cake-ghost",
                                children: t
                            }) : t, i && l ? (0, n.jsx)("div", {
                                className: "folio-cake-inside",
                                children: l
                            }) : null]
                        })]
                    });
                return (0, n.jsxs)("div", {
                    ref: v,
                    className: `folio-cake is-${B}${D?" is-editing":""}${x?` ${x}`:""}`,
                    children: [(0, n.jsxs)("div", {
                        className: "folio-cake-copy",
                        "aria-live": "polite",
                        children: [D ? (0, n.jsxs)(n.Fragment, {
                            children: [(0, n.jsx)("div", {
                                className: "folio-cake-beat",
                                children: d
                            }), (0, n.jsx)("div", {
                                className: "folio-cake-beat",
                                children: u
                            }), (0, n.jsx)("div", {
                                className: "folio-cake-beat",
                                children: f
                            })]
                        }) : (0, n.jsx)("div", {
                            className: "folio-cake-beat is-current",
                            children: "blow" === $ ? d : "cut" === $ ? u : f
                        }, $), D || "cut" !== $ ? null : (0, n.jsx)("button", {
                            type: "button",
                            className: "folio-pill is-quiet folio-cake-forme",
                            onClick: () => F(.5),
                            children: h
                        }), !D && "done" === $ && m.active ? (0, n.jsx)("button", {
                            type: "button",
                            className: "folio-pill",
                            onClick: () => m.next(),
                            children: p
                        }) : null]
                    }), (0, n.jsxs)("div", {
                        ref: g,
                        className: "folio-cake-stage",
                        style: {
                            "--cut-at": E
                        },
                        ...W,
                        children: ["done" === B ? (0, n.jsxs)("div", {
                            className: "folio-cake-split",
                            children: [(0, n.jsx)("div", {
                                className: "folio-cake-half is-mid",
                                "aria-hidden": !0,
                                children: U(!1, !0)
                            }), (0, n.jsx)("div", {
                                className: "folio-cake-half is-left",
                                "aria-hidden": !0,
                                children: U(!1)
                            }), (0, n.jsx)("div", {
                                className: "folio-cake-half is-right",
                                "aria-hidden": !0,
                                children: U(!1)
                            })]
                        }) : U(!0), "cut" === B ? (0, n.jsxs)(n.Fragment, {
                            children: [(0, n.jsx)("span", {
                                "aria-hidden": !0,
                                className: "folio-cake-guide"
                            }), (0, n.jsx)("span", {
                                "aria-hidden": !0,
                                className: "folio-cake-knife",
                                children: (0, n.jsxs)("svg", {
                                    viewBox: "0 0 40 120",
                                    children: [(0, n.jsx)("rect", {
                                        x: "15",
                                        y: "0",
                                        width: "10",
                                        height: "38",
                                        rx: "5",
                                        fill: "var(--fp-ink)"
                                    }), (0, n.jsx)("path", {
                                        d: "M14 40 H26 V104 Q26 116 20 118 Q14 116 14 104 Z",
                                        fill: "var(--fp-card)",
                                        stroke: "var(--fp-ink)",
                                        strokeWidth: "3",
                                        strokeLinejoin: "round"
                                    })]
                                })
                            })]
                        }) : null, M ? (0, n.jsx)("span", {
                            "aria-hidden": !0,
                            className: "folio-cake-trail",
                            style: {
                                left: M.x,
                                top: M.y0,
                                height: Math.max(2, M.y1 - M.y0)
                            }
                        }) : null, "done" !== $ || D ? null : (0, n.jsx)(s.ConfettiBurst, {
                            seed: 52,
                            count: 44,
                            top: "30%"
                        })]
                    })]
                })
            }

            function S({
                box: e,
                lid: t,
                hint: l,
                children: c,
                taps: d = 3,
                className: u
            }) {
                let f = (0, a.useMode)(),
                    h = (0, r.useFolioSound)(),
                    p = (0, i.useRef)(null),
                    [x, k] = (0, i.useState)({
                        taps: 0,
                        open: !1
                    }),
                    m = "edit" === f,
                    j = m || x.open;
                return (0, s.useReplaySignal)(p, () => k({
                    taps: 0,
                    open: !1
                })), (0, n.jsxs)("div", {
                    ref: p,
                    className: `folio-gift${j?" is-open":""}${u?` ${u}`:""}`,
                    ...!j && x.taps > 0 ? {
                        "data-shake": x.taps % 2 == 1 ? "a" : "b"
                    } : {},
                    children: [j ? (0, n.jsx)("div", {
                        className: "folio-gift-contents",
                        children: c
                    }) : null, (0, n.jsxs)("button", {
                        type: "button",
                        className: "folio-gift-box",
                        "aria-label": j ? "Gift opened" : "Tap the gift to open it",
                        disabled: j,
                        tabIndex: m ? -1 : void 0,
                        onClick: e => (e => {
                            if (m || x.open) return;
                            h.unlock(e);
                            let t = (0, o.Up)(x, d);
                            k(t), h.playEffect(t.open ? "popper" : "shake")
                        })(e.currentTarget),
                        children: [(0, n.jsx)("span", {
                            className: "folio-gift-lid",
                            "aria-hidden": !0,
                            children: t
                        }), (0, n.jsx)("span", {
                            className: "folio-gift-base",
                            "aria-hidden": !0,
                            children: e
                        }), j ? null : (0, n.jsx)("span", {
                            className: "folio-gift-dots",
                            "aria-hidden": !0,
                            children: Array.from({
                                length: d
                            }, (e, t) => (0, n.jsx)("i", {
                                className: t < x.taps ? "is-on" : void 0
                            }, t))
                        })]
                    }), j ? null : (0, n.jsx)("span", {
                        className: "folio-gift-hint",
                        children: l
                    }), x.open && !m ? (0, n.jsx)(s.ConfettiBurst, {
                        seed: 77,
                        count: 40,
                        top: "38%"
                    }) : null]
                })
            }
        },
        30032: () => {},
        94830: (e, t, l) => {
            "use strict";
            l.d(t, {
                Do: () => h,
                F1: () => f,
                Hs: () => s,
                R1: () => u,
                Up: () => x,
                dy: () => r,
                lu: () => i,
                m7: () => d,
                oX: () => o,
                og: () => p,
                pW: () => k,
                v6: () => c,
                yF: () => a
            });
            let n = (e, t, l) => Math.min(l, Math.max(t, e)),
                i = .82;

            function o(e, t, l) {
                let i = t - l;
                return i > 0 ? n(e / i, 0, 1) : 0
            }
            let s = 64;

            function a(e, t = 120) {
                return e > 0 && t > 0 ? t * (1 - Math.exp(-e / t)) : 0
            }
            let r = 1600;

            function c(e, t) {
                return e < t ? {
                    kind: "gone"
                } : e === t ? {
                    kind: "top"
                } : {
                    kind: "behind",
                    depth: e - t
                }
            }

            function d(e, t) {
                return t <= 0 ? 0 : Math.min(t - 1, Math.max(0, e) + 1)
            }

            function u(e) {
                return e % 2 == 0 ? -1 : 1
            }

            function f(e) {
                let t = (e.match(/\d/g) ? ? []).slice(0, 3);
                return t.length > 0 ? t : Array.from({
                    length: 3
                }, () => "")
            }

            function h(e, t, l, n) {
                if (!(l > 0) || !(n > 0)) return !1;
                let i = t.y - e.y,
                    o = Math.abs(t.x - e.x);
                return i >= .4 * n && o <= .5 * i
            }

            function p(e, t, l) {
                return l > 0 ? n((e.x + t.x) / 2 / l, .32, .68) : .5
            }

            function x(e, t = 3) {
                if (e.open) return e;
                let l = e.taps + 1;
                return {
                    taps: l,
                    open: l >= Math.max(1, t)
                }
            }

            function k(e, t, l = !0) {
                let i = n(Math.floor(e), 0, 23),
                    o = n(Math.floor(t), 0, 59);
                return `${l?i%12||12:i}:${String(o).padStart(2,"0")}`
            }
        }
    }
]);