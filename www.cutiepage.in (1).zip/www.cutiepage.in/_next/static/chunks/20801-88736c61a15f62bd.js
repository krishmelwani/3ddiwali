"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [20801], {
        1976: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = {
                bindSnapshot: function() {
                    return u
                },
                createAsyncLocalStorage: function() {
                    return i
                },
                createSnapshot: function() {
                    return d
                }
            };
            for (var n in r) Object.defineProperty(t, n, {
                enumerable: !0,
                get: r[n]
            });
            let l = Object.defineProperty(Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available"), "__NEXT_ERROR_CODE", {
                value: "E504",
                enumerable: !1,
                configurable: !0
            });
            class o {
                disable() {
                    throw l
                }
                getStore() {}
                run() {
                    throw l
                }
                exit() {
                    throw l
                }
                enterWith() {
                    throw l
                }
                static bind(e) {
                    return e
                }
            }
            let a = "u" > typeof globalThis && globalThis.AsyncLocalStorage;

            function i() {
                return a ? new a : new o
            }

            function u(e) {
                return a ? a.bind(e) : o.bind(e)
            }

            function d() {
                return a ? a.snapshot() : function(e, ...t) {
                    return e(...t)
                }
            }
        },
        4525: (e, t, r) => {
            r.d(t, {
                default: () => i
            });
            var n = r(1521),
                l = {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: 24,
                    height: 24,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: 2,
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                },
                o = r(5695);
            let a = (0, n.createContext)({}),
                i = (0, n.forwardRef)(({
                    color: e,
                    size: t,
                    strokeWidth: r,
                    absoluteStrokeWidth: i,
                    className: u = "",
                    children: d,
                    iconNode: s,
                    ...c
                }, f) => {
                    let {
                        size: p = 24,
                        strokeWidth: y = 2,
                        absoluteStrokeWidth: b = !1,
                        color: h = "currentColor",
                        className: m = ""
                    } = (0, n.useContext)(a) ? ? {}, g = i ? ? b ? 24 * Number(r ? ? y) / Number(t ? ? p) : r ? ? y;
                    return (0, n.createElement)("svg", {
                        ref: f,
                        ...l,
                        width: t ? ? p ? ? l.width,
                        height: t ? ? p ? ? l.height,
                        stroke: e ? ? h,
                        strokeWidth: g,
                        className: (0, o.z)("lucide", m, u),
                        ...!d && !(e => {
                            for (let t in e)
                                if (t.startsWith("aria-") || "role" === t || "title" === t) return !0;
                            return !1
                        })(c) && {
                            "aria-hidden": "true"
                        },
                        ...c
                    }, [...s.map(([e, t]) => (0, n.createElement)(e, t)), ...Array.isArray(d) ? d : [d]])
                })
        },
        5695: (e, t, r) => {
            r.d(t, {
                z: () => n
            });
            let n = (...e) => e.filter((e, t, r) => !!e && "" !== e.trim() && r.indexOf(e) === t).join(" ").trim()
        },
        16168: (e, t, r) => {
            r.d(t, {
                F: () => a
            });
            var n = r(68662);
            let l = e => "boolean" == typeof e ? `${e}` : 0 === e ? "0" : e,
                o = n.$,
                a = (e, t) => r => {
                    var n;
                    if ((null == t ? void 0 : t.variants) == null) return o(e, null == r ? void 0 : r.class, null == r ? void 0 : r.className);
                    let {
                        variants: a,
                        defaultVariants: i
                    } = t, u = Object.keys(a).map(e => {
                        let t = null == r ? void 0 : r[e],
                            n = null == i ? void 0 : i[e];
                        if (null === t) return null;
                        let o = l(t) || l(n);
                        return a[e][o]
                    }), d = r && Object.entries(r).reduce((e, t) => {
                        let [r, n] = t;
                        return void 0 === n || (e[r] = n), e
                    }, {});
                    return o(e, u, null == t || null == (n = t.compoundVariants) ? void 0 : n.reduce((e, t) => {
                        let {
                            class: r,
                            className: n,
                            ...l
                        } = t;
                        return Object.entries(l).every(e => {
                            let [t, r] = e;
                            return Array.isArray(r) ? r.includes({ ...i,
                                ...d
                            }[t]) : ({ ...i,
                                ...d
                            })[t] === r
                        }) ? [...e, r, n] : e
                    }, []), null == r ? void 0 : r.class, null == r ? void 0 : r.className)
                }
        },
        18493: (e, t, r) => {
            r.d(t, {
                A: () => n
            });
            let n = (0, r(96296).A)("tag", [
                ["path", {
                    d: "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",
                    key: "vktsd0"
                }],
                ["circle", {
                    cx: "7.5",
                    cy: "7.5",
                    r: ".5",
                    fill: "currentColor",
                    key: "kqv944"
                }]
            ])
        },
        26599: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return l
                }
            });
            let n = r(12563)._(r(51343));

            function l(e, t) {
                let r = {};
                "function" == typeof e && (r.loader = e);
                let l = { ...r,
                    ...t
                };
                return (0, n.default)({ ...l,
                    modules: l.loadableGenerated ? .modules
                })
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        38372: (e, t, r) => {
            function n({
                reason: e,
                children: t
            }) {
                return t
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "BailoutToCSR", {
                enumerable: !0,
                get: function() {
                    return n
                }
            }), r(24104)
        },
        48495: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = {
                default: function() {
                    return s
                },
                getImageProps: function() {
                    return d
                }
            };
            for (var l in n) Object.defineProperty(t, l, {
                enumerable: !0,
                get: n[l]
            });
            let o = r(12563),
                a = r(53441),
                i = r(38137),
                u = o._(r(93635));

            function d(e) {
                let {
                    props: t
                } = (0, a.getImgProps)(e, {
                    defaultLoader: u.default,
                    imgConf: {
                        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                        imageSizes: [32, 48, 64, 96, 128, 256, 384],
                        qualities: [75],
                        path: "/_next/image",
                        loader: "default",
                        dangerouslyAllowSVG: !1,
                        unoptimized: !0
                    }
                });
                for (let [e, r] of Object.entries(t)) void 0 === r && delete t[e];
                return {
                    props: t
                }
            }
            let s = i.Image
        },
        51343: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return u
                }
            });
            let n = r(73365),
                l = r(1521),
                o = r(38372);

            function a(e) {
                return {
                    default: e && "default" in e ? e.default : e
                }
            }
            r(52393);
            let i = {
                    loader: () => Promise.resolve(a(() => null)),
                    loading: null,
                    ssr: !0
                },
                u = function(e) {
                    let t = { ...i,
                            ...e
                        },
                        r = (0, l.lazy)(() => t.loader().then(a)),
                        u = t.loading;

                    function d(e) {
                        let a = u ? (0, n.jsx)(u, {
                                isLoading: !0,
                                pastDelay: !0,
                                error: null
                            }) : null,
                            i = !t.ssr || !!t.loading,
                            d = i ? l.Suspense : l.Fragment,
                            s = t.ssr ? (0, n.jsxs)(n.Fragment, {
                                children: [null, (0, n.jsx)(r, { ...e
                                })]
                            }) : (0, n.jsx)(o.BailoutToCSR, {
                                reason: "next/dynamic",
                                children: (0, n.jsx)(r, { ...e
                                })
                            });
                        return (0, n.jsx)(d, { ...i ? {
                                fallback: a
                            } : {},
                            children: s
                        })
                    }
                    return d.displayName = "LoadableComponent", d
                }
        },
        52393: (e, t, r) => {
            function n({
                moduleIds: e
            }) {
                return null
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "PreloadChunks", {
                enumerable: !0,
                get: function() {
                    return n
                }
            }), r(73365), r(98196), r(89442), r(91319), r(68491)
        },
        58872: (e, t, r) => {
            r.d(t, {
                default: () => l.a
            });
            var n = r(48495),
                l = r.n(n)
        },
        86714: (e, t, r) => {
            r.d(t, {
                default: () => l.a
            });
            var n = r(26599),
                l = r.n(n)
        },
        89442: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "workAsyncStorage", {
                enumerable: !0,
                get: function() {
                    return n.workAsyncStorageInstance
                }
            });
            let n = r(99238)
        },
        90925: (e, t, r) => {
            r.d(t, {
                A: () => n
            });
            let n = (0, r(96296).A)("star", [
                ["path", {
                    d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
                    key: "r04s7s"
                }]
            ])
        },
        92166: (e, t, r) => {
            let n, l;
            r.d(t, {
                DX: () => d,
                xV: () => c
            });
            var o, a = r(1521),
                i = r.t(a, 2);

            function u(e, t) {
                if ("function" == typeof e) return e(t);
                null != e && (e.current = t)
            }
            var d = (o = "Slot", (n = a.forwardRef((e, t) => {
                    var r;
                    let n, l, {
                            children: i,
                            ...d
                        } = e,
                        c = null,
                        p = !1,
                        g = [];
                    y(i) && "function" == typeof m && (i = m(i._payload)), a.Children.forEach(i, e => {
                        var t;
                        if (t = e, a.isValidElement(t) && "function" == typeof t.type && "__radixId" in t.type && t.type.__radixId === s) {
                            p = !0;
                            let t = "child" in e.props ? e.props.child : e.props.children;
                            y(t) && "function" == typeof m && (t = m(t._payload)), c = f(e, t), g.push(c ? .props ? .children)
                        } else g.push(e)
                    }), c ? c = a.cloneElement(c, void 0, g) : !p && 1 === a.Children.count(i) && a.isValidElement(i) && (c = i);
                    let v = c ? (r = c, (l = (n = Object.getOwnPropertyDescriptor(r.props, "ref") ? .get) && "isReactWarning" in n && n.isReactWarning) ? r.ref : (l = (n = Object.getOwnPropertyDescriptor(r, "ref") ? .get) && "isReactWarning" in n && n.isReactWarning) ? r.props.ref : r.props.ref || r.ref) : void 0,
                        _ = function(...e) {
                            return a.useCallback(function(...e) {
                                return t => {
                                    let r = !1,
                                        n = e.map(e => {
                                            let n = u(e, t);
                                            return r || "function" != typeof n || (r = !0), n
                                        });
                                    if (r) return () => {
                                        for (let t = 0; t < n.length; t++) {
                                            let r = n[t];
                                            "function" == typeof r ? r() : u(e[t], null)
                                        }
                                    }
                                }
                            }(...e), e)
                        }(t, v);
                    if (!c) {
                        if (i || 0 === i) throw Error(p ? h(o) : b(o));
                        return i
                    }
                    let j = function(e, t) {
                        let r = { ...t
                        };
                        for (let n in t) {
                            let l = e[n],
                                o = t[n];
                            /^on[A-Z]/.test(n) ? l && o ? r[n] = (...e) => {
                                let t = o(...e);
                                return l(...e), t
                            } : l && (r[n] = l) : "style" === n ? r[n] = { ...l,
                                ...o
                            } : "className" === n && (r[n] = [l, o].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...r
                        }
                    }(d, c.props ? ? {});
                    return c.type !== a.Fragment && (j.ref = t ? _ : v), a.cloneElement(c, j)
                })).displayName = `${o}.Slot`, n),
                s = Symbol.for("radix.slottable"),
                c = ((l = e => "child" in e ? e.children(e.child) : e.children).displayName = "Slottable.Slottable", l.__radixId = s, l),
                f = (e, t) => {
                    if ("child" in e.props) {
                        let t = e.props.child;
                        return a.isValidElement(t) ? a.cloneElement(t, void 0, e.props.children(t.props.children)) : null
                    }
                    return a.isValidElement(t) ? t : null
                },
                p = Symbol.for("react.lazy");

            function y(e) {
                var t;
                return null != e && "object" == typeof e && "$$typeof" in e && e.$$typeof === p && "_payload" in e && "object" == typeof(t = e._payload) && null !== t && "then" in t
            }
            var b = e => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`,
                h = e => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`,
                m = i[" use ".trim().toString()]
        },
        96296: (e, t, r) => {
            r.d(t, {
                A: () => i
            });
            var n = r(1521),
                l = r(5695);
            let o = e => {
                let t = e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, r) => r ? r.toUpperCase() : t.toLowerCase());
                return t.charAt(0).toUpperCase() + t.slice(1)
            };
            var a = r(4525);
            let i = (e, t) => {
                let r = (0, n.forwardRef)(({
                    className: r,
                    ...i
                }, u) => (0, n.createElement)(a.default, {
                    ref: u,
                    iconNode: t,
                    className: (0, l.z)(`lucide-${o(e).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`, `lucide-${e}`, r),
                    ...i
                }));
                return r.displayName = o(e), r
            }
        },
        99238: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "workAsyncStorageInstance", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let n = (0, r(1976).createAsyncLocalStorage)()
        }
    }
]);