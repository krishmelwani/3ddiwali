"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [31148], {
        31148: (e, a, t) => {
            t.d(a, {
                SupportLauncher: () => b
            });
            var r = t(73365),
                n = t(1521),
                i = t(29717),
                s = t(89622),
                o = t(89931),
                l = t(67972);
            let c = {
                    default: "right-[max(1rem,env(safe-area-inset-right))] bottom-[max(1rem,env(safe-area-inset-bottom))]",
                    editor: "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(0.75rem,env(safe-area-inset-bottom))+7.5rem)] lg:right-5 lg:bottom-20",
                    "editor-v2": "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(0.75rem,env(safe-area-inset-bottom))+5.5rem)] lg:right-[calc(var(--cp-kiara-editor-right,300px)+1.25rem)] lg:bottom-[calc(var(--cp-kiara-editor-bottom,0px)+1.25rem)]",
                    "app-shell": "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(env(safe-area-inset-bottom)+5rem)] lg:bottom-[max(1rem,env(safe-area-inset-bottom))]",
                    checkout: "max-lg:hidden right-[max(1rem,env(safe-area-inset-right))] bottom-[max(1rem,env(safe-area-inset-bottom))]"
                },
                u = null;

            function m() {
                return u || (u = t.e(8808).then(t.bind(t, 8808)).catch(e => {
                    throw u = null, e
                })), u
            }
            let d = () => () => {};

            function p() {
                m().catch(() => {})
            }
            let f = `
@keyframes kiara-halo{to{transform:rotate(360deg)}}
@keyframes kiara-bubble-in{from{opacity:0;transform:translateY(10px) scale(.8)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:no-preference){.kiara-halo{animation:kiara-halo 4s linear infinite}.kiara-bubble-in{animation:kiara-bubble-in .45s cubic-bezier(.34,1.56,.64,1) both}}
html[data-home-motion=lite] .kiara-halo{animation:none}`;

            function h({
                placement: e
            }) {
                return window.matchMedia(l.QB).matches ? (0, r.jsxs)("div", {
                    role: "dialog",
                    "aria-label": "Chat with Kiara",
                    "aria-busy": "true",
                    className: o.Mw,
                    children: [(0, r.jsx)("div", {
                        "aria-hidden": "true",
                        className: `${o.IX} kiara-scrim-in`
                    }), (0, r.jsx)("div", {
                        className: `${o.RC} kiara-sheet-in`,
                        children: (0, r.jsx)(o.TQ, {})
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Loading your chat"
                    })]
                }) : (0, r.jsxs)("div", {
                    role: "dialog",
                    "aria-label": "Chat with Kiara",
                    "aria-busy": "true",
                    className: `fixed ${l.pI[e]} z-40 h-[640px] max-h-[calc(100dvh-2rem)] w-[420px] max-w-[calc(100vw-2rem)] overflow-hidden rounded-3xl`,
                    children: [(0, r.jsx)(o.TQ, {}), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Loading your chat"
                    })]
                })
            }

            function b({
                surface: e,
                placement: a = "default"
            }) {
                let t = (0, i.usePathname)(),
                    o = (0, n.useSyncExternalStore)(d, () => (0, l.IO)(window.location), () => !1),
                    [u, g] = (0, n.useState)(!1),
                    [v, x] = (0, n.useState)(!1),
                    [k, y] = (0, n.useState)(!1),
                    [w, j] = (0, n.useState)(void 0),
                    [N, I] = (0, n.useState)(void 0),
                    [S, z] = (0, n.useState)(!1),
                    [C, $] = (0, n.useState)(!1),
                    [E, _] = (0, n.useState)(null),
                    [A, D] = (0, n.useState)(null),
                    [M, L] = (0, n.useState)(!1),
                    O = (0, n.useRef)(!1),
                    [T, U] = (0, n.useState)(!1),
                    K = (0, n.useRef)(null);
                (0, n.useEffect)(() => {
                    if (!(0, l.IO)(window.location)) return;
                    let e = !1,
                        a = () => {};
                    return (0, l.KD)().then(t => {
                        if (!e) {
                            if (!t.enabled) return void g(!0);
                            x(t.signedIn), y(!0 === t.pageEdits), j(t.chatUrl), I(t.firstName), a = (0, l.dV)(() => {
                                let a;
                                a = navigator.connection, a ? .saveData === !0 || /2g/.test(a ? .effectiveType ? ? "") || p(), (0, l.FS)().then(a => {
                                    !e && a && U(!0)
                                })
                            })
                        }
                    }), () => {
                        e = !0, a()
                    }
                }, []);
                let P = o && !u && (0, l.j7)(t ? ? "/"),
                    Q = (0, n.useCallback)(() => {
                        O.current || (0, l.h2)()
                    }, []),
                    W = (0, n.useCallback)(async e => {
                        if (e && e.trim() && D({
                                text: e.trim(),
                                nonce: Date.now()
                            }), Q(), O.current = !0, z(!0), U(!1), !E) {
                            L(!0), $(!0);
                            try {
                                let [e] = await Promise.all([m(), (0, l.KD)()]);
                                _(() => e.SupportWidget)
                            } catch {
                                z(!1)
                            } finally {
                                $(!1)
                            }
                        }
                    }, [E, Q]);
                (0, n.useEffect)(() => {
                    if (!P) return;
                    let e = e => {
                        let a = e.detail;
                        W("string" == typeof a ? .message ? a.message : void 0)
                    };
                    return window.addEventListener(l.Qy, e), () => window.removeEventListener(l.Qy, e)
                }, [P, W]);
                let F = (0, n.useCallback)(() => {
                        z(!1), L(!1), K.current ? .focus({
                            preventScroll: !0
                        })
                    }, []),
                    R = (0, n.useCallback)(() => D(null), []);
                return P ? (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsxs)("button", {
                        ref: K,
                        type: "button",
                        "aria-label": T ? "Chat with Kiara, new reply from our team" : "Chat with Kiara",
                        "aria-expanded": S,
                        "aria-busy": C || void 0,
                        onPointerEnter: p,
                        onFocus: p,
                        onTouchStart: p,
                        onPointerDown: S ? void 0 : Q,
                        onClick: () => S ? F() : void W(),
                        className: `kiara-bubble-in group fixed ${c[a]} z-30 flex cursor-pointer flex-col items-center gap-1.5 rounded-2xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select`,
                        children: [S ? null : (0, r.jsxs)("span", {
                            className: "relative -mx-4 rounded-full border border-cp-line bg-cp-bg px-2 py-0.5 text-[11px] font-medium whitespace-nowrap text-cp-ink shadow-cp-float sm:px-2.5 sm:py-1 sm:text-[12px]",
                            children: ["Ask anything", (0, r.jsx)("span", {
                                "aria-hidden": "true",
                                className: "absolute -bottom-1 left-1/2 size-2 -translate-x-1/2 rotate-45 border-r border-b border-cp-line bg-cp-bg"
                            })]
                        }), (0, r.jsxs)("span", {
                            className: "relative inline-flex size-14 items-center justify-center rounded-full bg-cp-bg text-white shadow-cp-float transition-transform duration-200 motion-safe:group-hover:-translate-y-0.5 motion-safe:group-hover:-rotate-6 motion-safe:group-active:scale-95",
                            children: [(0, r.jsx)("style", {
                                children: f
                            }), S ? null : (0, r.jsx)("span", {
                                "aria-hidden": "true",
                                className: "kiara-halo absolute -inset-[3px] rounded-full opacity-90 blur-[2px]",
                                style: {
                                    background: "conic-gradient(var(--cp-rose), var(--cp-lavender), var(--cp-primary), var(--cp-rose))"
                                }
                            }), (0, r.jsx)("span", {
                                "aria-hidden": "true",
                                className: "absolute inset-0 rounded-full bg-cp-bg"
                            }), S ? (0, r.jsx)("span", {
                                className: "relative inline-flex size-14 items-center justify-center rounded-full bg-cp-primary",
                                children: (0, r.jsx)("svg", {
                                    "aria-hidden": "true",
                                    viewBox: "0 0 24 24",
                                    className: "size-6",
                                    fill: "none",
                                    stroke: "currentColor",
                                    strokeWidth: 1.75,
                                    strokeLinecap: "round",
                                    children: (0, r.jsx)("path", {
                                        d: "M6 6l12 12M18 6L6 18"
                                    })
                                })
                            }) : (0, r.jsx)(s.W, {
                                size: 56,
                                className: "relative"
                            }), T && !S ? (0, r.jsx)("span", {
                                "aria-hidden": "true",
                                className: "absolute top-0.5 right-0.5 size-3.5 rounded-full bg-cp-danger-strong ring-2 ring-cp-bg"
                            }) : null]
                        })]
                    }), S && !E ? (0, r.jsx)(h, {
                        placement: a
                    }) : null, E ? (0, r.jsx)(E, {
                        open: S,
                        onClose: F,
                        surface: e,
                        placement: a,
                        signedIn: v,
                        pageEdits: k,
                        chatUrl: w,
                        pendingMessage: A,
                        onPendingConsumed: R,
                        skipEnterAnimation: M,
                        firstName: N
                    }) : null]
                }) : null
            }
        },
        67972: (e, a, t) => {
            t.d(a, {
                Ar: () => v,
                EI: () => k,
                FS: () => A,
                IO: () => b,
                KD: () => z,
                On: () => s,
                QB: () => o,
                Qy: () => n,
                RY: () => g,
                Te: () => C,
                ZM: () => d,
                dV: () => D,
                h2: () => m,
                hT: () => E,
                if: () => x,
                j7: () => h,
                mx: () => c,
                pI: () => l,
                x6: () => _
            });
            var r = t(29267);
            let n = "cp-support:open",
                i = "cp_support_status_v1",
                s = "cp_support_conversation_v1",
                o = "(max-width: 639px)",
                l = {
                    default: "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(1rem,env(safe-area-inset-bottom))+4.75rem)] max-h-[calc(100dvh-12rem)]",
                    editor: "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(0.75rem,env(safe-area-inset-bottom))+10.25rem)] max-h-[calc(100dvh-11.5rem)] lg:right-5 lg:bottom-[9.75rem] lg:max-h-[calc(100dvh-10.75rem)]",
                    "editor-v2": "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(0.75rem,env(safe-area-inset-bottom))+10.25rem)] max-h-[calc(100dvh-11.5rem)] lg:right-[calc(var(--cp-kiara-editor-right,300px)+1.25rem)] lg:bottom-24 lg:max-h-[calc(100dvh-7rem)]",
                    "app-shell": "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(env(safe-area-inset-bottom)+9.75rem)] max-h-[calc(100dvh-15rem)] md:bottom-[calc(max(1rem,env(safe-area-inset-bottom))+4.75rem)] md:max-h-[calc(100dvh-12rem)]",
                    checkout: "right-[max(1rem,env(safe-area-inset-right))] bottom-[calc(max(1rem,env(safe-area-inset-bottom))+4.75rem)] max-h-[calc(100dvh-12rem)]"
                },
                c = {
                    cache: "no-store",
                    credentials: "same-origin",
                    headers: {
                        accept: "application/json"
                    }
                },
                u = null;

            function m(e) {
                let a = e ? .now ? ? Date.now();
                if (u && a - u.at < 15e3) return;
                let t = e ? .fetchImpl ? ? ("function" == typeof fetch ? fetch : null);
                if (!t) return;
                let r = t("/api/support/history", c);
                r.catch(() => {}), u = {
                    at: a,
                    response: r
                }
            }

            function d(e = Date.now()) {
                let a = u;
                return u = null, a && e - a.at < 15e3 ? a.response : null
            }
            let p = new Set(["www.cutiepage.in", "cutiepage.in", "dash.cutiepage.in", "localhost", "127.0.0.1"]),
                f = ["/preview", "/pv"];

            function h(e) {
                let a = (e || "/").toLowerCase();
                for (let e of f)
                    if (a === e || a.startsWith(`${e}/`)) return !1;
                return !0
            }

            function b(e) {
                var a;
                return a = e.hostname, p.has(a.trim().toLowerCase().replace(/\.$/, "")) && h(e.pathname)
            }

            function g() {
                try {
                    return window.sessionStorage
                } catch {
                    return null
                }
            }

            function v() {
                try {
                    return window.localStorage
                } catch {
                    return null
                }
            }

            function x(e, a) {
                if (!e) return null;
                try {
                    return e.getItem(a)
                } catch {
                    return null
                }
            }

            function k(e, a, t) {
                if (e) try {
                    e.setItem(a, t)
                } catch {}
            }

            function y(e, a) {
                if (e ? .removeItem) try {
                    e.removeItem(a)
                } catch {}
            }
            let w = {
                enabled: !1,
                signedIn: !1,
                pageEdits: !1
            };

            function j(e) {
                return "string" == typeof e && e.startsWith("https://") ? {
                    chatUrl: e
                } : {}
            }

            function N(e) {
                let a = "string" == typeof e ? e.trim().slice(0, 24) : "";
                return a ? {
                    firstName: a
                } : {}
            }

            function I(e, a, t) {
                k(e, i, JSON.stringify({
                    at: t,
                    enabled: a.enabled,
                    signedIn: a.signedIn,
                    pageEdits: !0 === a.pageEdits,
                    ...j(a.chatUrl),
                    ...N(a.firstName)
                }))
            }
            let S = null;

            function z(e) {
                let a = e ? .storage === void 0 ? g() : e.storage,
                    t = e ? .now ? ? Date.now,
                    n = function(e, a) {
                        let t = x(e, i);
                        if (!t) return null;
                        try {
                            let e = JSON.parse(t);
                            if ("number" != typeof e.at || "boolean" != typeof e.enabled) return null;
                            let r = a - e.at,
                                n = e.enabled ? 3e5 : 6e4;
                            if (r < 0 || r >= n) return null;
                            return {
                                enabled: e.enabled,
                                signedIn: !0 === e.signedIn,
                                pageEdits: !0 === e.pageEdits,
                                ...j(e.chatUrl),
                                ...N(e.firstName)
                            }
                        } catch {
                            return null
                        }
                    }(a, t());
                if (n) return Promise.resolve(n);
                if (S) return S;
                let s = e ? .fetchImpl ? ? ("function" == typeof fetch ? fetch : null);
                return s ? S = (async () => {
                    try {
                        var e;
                        let n = (0, r.Zc)("/api/support/status"),
                            i = (e, a) => s(e, {
                                cache: "no-store",
                                credentials: a,
                                headers: {
                                    accept: "application/json"
                                }
                            }),
                            o = n ? await i(n, "include").catch(() => null) : null;
                        if ((!o || (0, r.mv)(o)) && (o = await i("/api/support/status", "same-origin")), 404 === o.status) return I(a, w, t()), w;
                        if (!o.ok) return w;
                        let l = (e = await o.json().catch(() => null)) && "object" == typeof e ? {
                            enabled: !0 === e.enabled,
                            signedIn: !0 === e.signedIn,
                            pageEdits: !0 === e.pageEdits,
                            ...j(e.chatUrl),
                            ...N(e.firstName)
                        } : w;
                        return I(a, l, t()), l
                    } catch {
                        return w
                    } finally {
                        S = null
                    }
                })() : Promise.resolve(w)
            }

            function C(e = g()) {
                y(e, i)
            }
            let $ = "cp_support_human";

            function E(e, a) {
                k(e, $, JSON.stringify(a))
            }

            function _(e) {
                y(e, $)
            }
            async function A(e) {
                let a = e ? .storage === void 0 ? v() : e.storage;
                try {
                    if (!x(a, $)) return !1;
                    let t = function(e) {
                        let a = x(e, $);
                        if (!a) return null;
                        try {
                            let e = JSON.parse(a);
                            if ("string" != typeof e.conversationId || !e.conversationId || e.conversationId.length > 64 || "string" != typeof e.seenAt || Number.isNaN(Date.parse(e.seenAt))) return null;
                            return {
                                conversationId: e.conversationId,
                                seenAt: e.seenAt
                            }
                        } catch {
                            return null
                        }
                    }(a);
                    if (!t) return _(a), !1;
                    let r = e ? .fetchImpl ? ? ("function" == typeof fetch ? fetch : null);
                    if (!r) return !1;
                    let n = new URLSearchParams({
                            conversationId: t.conversationId,
                            after: t.seenAt
                        }),
                        i = await r(`/api/support/history?${n.toString()}`, {
                            cache: "no-store",
                            credentials: "same-origin",
                            headers: {
                                accept: "application/json"
                            }
                        });
                    if (!i.ok) return (403 === i.status || 404 === i.status) && _(a), !1;
                    let s = await i.json().catch(() => null);
                    if (!s || "object" != typeof s) return !1;
                    if (s.conversationId !== t.conversationId) return _(a), !1;
                    return !0 !== s.humanActive && _(a), Array.isArray(s.items) && s.items.some(e => !!e && "object" == typeof e && "agent" === e.kind)
                } catch {
                    return !1
                }
            }

            function D(e, a = 2e3) {
                let t = window;
                if ("function" == typeof t.requestIdleCallback) {
                    let r = t.requestIdleCallback(e, {
                        timeout: a
                    });
                    return () => t.cancelIdleCallback ? .(r)
                }
                let r = window.setTimeout(e, a);
                return () => window.clearTimeout(r)
            }
        },
        89622: (e, a, t) => {
            t.d(a, {
                W: () => i
            });
            var r = t(73365),
                n = t(1521);

            function i({
                size: e,
                className: a = ""
            }) {
                let [t, s] = (0, n.useState)(!1), o = `inline-flex shrink-0 select-none items-center justify-center rounded-full ${a}`;
                return t ? (0, r.jsx)("span", {
                    "aria-hidden": "true",
                    style: {
                        width: e,
                        height: e,
                        fontSize: Math.round(.42 * e)
                    },
                    className: `${o} bg-cp-primary-soft font-semibold text-cp-primary`,
                    children: "K"
                }) : (0, r.jsx)("img", {
                    src: "https://cdn.cutiepage.in/support/kiara.webp",
                    alt: "",
                    "aria-hidden": "true",
                    width: e,
                    height: e,
                    decoding: "async",
                    draggable: !1,
                    onError: () => s(!0),
                    style: {
                        width: e,
                        height: e
                    },
                    className: `${o} object-cover`
                })
            }
        },
        89931: (e, a, t) => {
            let r, n;
            t.d(a, {
                IX: () => c,
                Mw: () => l,
                RC: () => u,
                SF: () => p,
                TQ: () => f,
                VN: () => o
            });
            var i = t(73365),
                s = t(1521);
            let o = `
@keyframes kiara-ring-pulse{0%,100%{opacity:.25;transform:scale(.82)}40%{opacity:1;transform:scale(1)}}
@keyframes kiara-wash-in{from{opacity:0}to{opacity:1}}
@keyframes kiara-bloom{0%{opacity:0;transform:scale(0)}35%{opacity:1}100%{opacity:1;transform:scale(1)}}
@keyframes kiara-aurora{0%,100%{transform:translate3d(0,0,0) scale(1)}50%{transform:translate3d(5%,-4%,0) scale(1.06)}}
@keyframes kiara-pop{0%{opacity:0;transform:scale(.5)}60%{opacity:1;transform:scale(1.06)}100%{opacity:1;transform:scale(1)}}
@keyframes kiara-portal-out{from{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(1.03)}}
@keyframes kiara-spin{to{transform:rotate(360deg)}}
@keyframes kiara-blob-a{0%,100%{transform:translate3d(-10%,8%,0) scale(1)}33%{transform:translate3d(8%,-8%,0) scale(1.12)}66%{transform:translate3d(14%,6%,0) scale(.96)}}
@keyframes kiara-blob-b{0%,100%{transform:translate3d(8%,-10%,0) scale(1.08)}33%{transform:translate3d(-12%,-2%,0) scale(.94)}66%{transform:translate3d(-4%,10%,0) scale(1.14)}}
@keyframes kiara-blob-c{0%,100%{transform:translate3d(0,0,0) scale(.9)}50%{transform:translate3d(-10%,-12%,0) scale(1.1)}}
@keyframes kiara-aurora-in{from{opacity:0;transform:scale(.6) rotate(-40deg)}to{opacity:1;transform:none}}
@keyframes kiara-sheet-in{from{transform:translate3d(0,100%,0)}to{transform:none}}
@keyframes kiara-sheet-out{to{transform:translate3d(0,100%,0)}}
@keyframes kiara-fade-out{to{opacity:0}}
@keyframes kiara-breath{0%,100%{opacity:.55;transform:scale(.9)}50%{opacity:1;transform:scale(1.1)}}
.kiara-ring-glow{background:conic-gradient(var(--cp-rose),var(--cp-lavender),var(--cp-primary),var(--cp-rose))}
@media (prefers-reduced-motion:no-preference){
.kiara-spark-ring{animation:kiara-ring-pulse 1.3s ease-in-out infinite}
.kiara-wash-in{animation:kiara-wash-in .6s ease-out both}
.kiara-bloom{animation:kiara-bloom 1.1s cubic-bezier(.22,1,.36,1) .1s both}
.kiara-aurora{animation:kiara-aurora 8s ease-in-out infinite}
.kiara-pop{animation:kiara-pop .7s cubic-bezier(.34,1.56,.64,1) .55s both}
.kiara-portal-out{animation:kiara-portal-out .6s cubic-bezier(.4,0,.2,1) both}
.kiara-ring-glow{animation:kiara-spin 2.6s linear infinite}
.kiara-blobs{animation:kiara-wash-in 1s ease-out .4s both}
.kiara-blob-a{animation:kiara-blob-a 9s ease-in-out infinite}
.kiara-blob-b{animation:kiara-blob-b 11s ease-in-out infinite}
.kiara-blob-c{animation:kiara-blob-c 7s ease-in-out infinite}
.kiara-aurora-in{animation:kiara-aurora-in 1.4s cubic-bezier(.22,1,.36,1) .2s both}
.kiara-aurora-spin{animation:kiara-spin 12s linear infinite}
.kiara-sheet-in{animation:kiara-sheet-in .55s cubic-bezier(.32,.72,0,1) both}
.kiara-sheet-out{animation:kiara-sheet-out .32s cubic-bezier(.4,0,1,1) forwards;pointer-events:none}
.kiara-scrim-in{animation:kiara-wash-in .35s ease-out both}
.kiara-scrim-out{animation:kiara-fade-out .32s ease-in forwards}
.kiara-breath{animation:kiara-breath 2.4s ease-in-out .9s infinite}
}`,
                l = "fixed inset-0 z-[90] flex flex-col justify-end",
                c = "absolute inset-0 bg-cp-ink/45",
                u = "relative flex h-[calc(100dvh-2.75rem)] flex-col overflow-hidden rounded-t-3xl bg-cp-bg shadow-cp-modal will-change-transform";

            function m() {
                if ("u" < typeof navigator) return !1;
                let e = navigator;
                return void 0 !== e.deviceMemory && e.deviceMemory <= 4 || void 0 !== e.hardwareConcurrency && e.hardwareConcurrency <= 4 || e.connection ? .saveData === !0
            }
            let d = (r = [
                [0, -1],
                [1, 0],
                [0, 1],
                [-1, 0]
            ], n = (e, a) => r.map(([t, r]) => [20 + t * e, 20 + r * e, a]), [
                [
                    [20, 20, 2.1]
                ],
                [...[
                    [-3.4, -3.4],
                    [3.4, -3.4],
                    [-3.4, 3.4],
                    [3.4, 3.4]
                ].map(([e, a]) => [20 + e, 20 + a, 1.2]), ...n(3.6, 1.6)], n(8, 1.7), n(12.5, 1.4), n(17, 1.1)
            ]);

            function p({
                size: e = 28,
                tone: a = "brand"
            }) {
                var t;
                let r = (t = (0, s.useId)(), `k${t.replace(/[^a-zA-Z0-9_-]/g,"")}`);
                return (0, i.jsx)("span", {
                    "aria-hidden": "true",
                    className: "relative inline-block shrink-0",
                    style: {
                        width: e,
                        height: e
                    },
                    children: d.map((t, n) => (0, i.jsxs)("svg", {
                        viewBox: "0 0 40 40",
                        width: e,
                        height: e,
                        className: "kiara-spark-ring absolute inset-0",
                        style: {
                            animationDelay: `${110*n}ms`
                        },
                        children: [(0, i.jsx)("defs", {
                            children: (0, i.jsxs)("linearGradient", {
                                id: `${r}${n}`,
                                x1: "0",
                                y1: "0",
                                x2: "40",
                                y2: "40",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, i.jsx)("stop", {
                                    offset: "0",
                                    stopColor: "var(--cp-rose)"
                                }), (0, i.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "var(--cp-primary)"
                                })]
                            })
                        }), t.map(([e, t, s]) => (0, i.jsx)("circle", {
                            cx: e,
                            cy: t,
                            r: s,
                            fill: "light" === a ? "white" : `url(#${r}${n})`
                        }, `${e}-${t}`))]
                    }, n))
                })
            }

            function f({
                leaving: e = !1,
                settled: a = !1
            }) {
                let [t] = (0, s.useState)(m), r = e => a ? "" : e;
                return (0, i.jsxs)("div", {
                    "aria-hidden": "true",
                    className: `absolute inset-0 overflow-hidden ${e?"kiara-portal-out":""}`,
                    children: [(0, i.jsx)("style", {
                        children: o
                    }), (0, i.jsx)("div", {
                        className: `absolute inset-0 ${r("kiara-wash-in")}`,
                        style: t ? {
                            background: "color-mix(in srgb, var(--cp-bg) 70%, transparent)"
                        } : {
                            backdropFilter: "grayscale(1)",
                            WebkitBackdropFilter: "grayscale(1)"
                        }
                    }), (0, i.jsx)("div", {
                        className: "absolute top-full left-[88%] size-[300vmax] max-h-[3000px] max-w-[3000px] -translate-x-1/2 -translate-y-1/2",
                        children: (0, i.jsx)("div", {
                            className: `size-full rounded-full ${r("kiara-bloom")}`,
                            style: {
                                background: "radial-gradient(closest-side, color-mix(in srgb, var(--cp-rose) 55%, transparent) 0%, color-mix(in srgb, var(--cp-lavender) 60%, transparent) 30%, color-mix(in srgb, var(--cp-bg) 30%, transparent) 70%)"
                            }
                        })
                    }), t ? null : (0, i.jsx)("div", {
                        className: `absolute top-1/2 left-1/2 size-[160vmax] max-h-[1600px] max-w-[1600px] -translate-x-1/2 -translate-y-1/2 ${r("kiara-aurora-in")}`,
                        children: (0, i.jsx)("div", {
                            className: "kiara-aurora-spin size-full rounded-full opacity-60",
                            style: {
                                background: "conic-gradient(from 0deg, color-mix(in srgb, var(--cp-rose) 55%, transparent), color-mix(in srgb, var(--cp-lavender) 65%, transparent), color-mix(in srgb, var(--cp-pastel-butter) 70%, transparent), color-mix(in srgb, var(--cp-primary) 30%, transparent), color-mix(in srgb, var(--cp-rose) 55%, transparent))",
                                maskImage: "radial-gradient(closest-side, black 20%, transparent)",
                                WebkitMaskImage: "radial-gradient(closest-side, black 20%, transparent)"
                            }
                        })
                    }), (0, i.jsxs)("div", {
                        className: `absolute inset-0 ${r("kiara-blobs")}`,
                        children: [(0, i.jsx)("div", {
                            className: "kiara-blob-a absolute -bottom-[20%] -left-[30%] size-[90%] rounded-full",
                            style: {
                                background: "radial-gradient(closest-side, color-mix(in srgb, var(--cp-rose) 50%, transparent), transparent)"
                            }
                        }), (0, i.jsx)("div", {
                            className: "kiara-blob-b absolute -top-[15%] -right-[30%] size-[95%] rounded-full",
                            style: {
                                background: "radial-gradient(closest-side, color-mix(in srgb, var(--cp-primary) 35%, transparent), transparent)"
                            }
                        }), (0, i.jsx)("div", {
                            className: "kiara-blob-c absolute top-[30%] left-[20%] size-[60%] rounded-full",
                            style: {
                                background: "radial-gradient(closest-side, color-mix(in srgb, var(--cp-lavender) 55%, transparent), transparent)"
                            }
                        })]
                    }), (0, i.jsx)("div", {
                        className: "absolute inset-0 flex items-center justify-center",
                        children: (0, i.jsxs)("span", {
                            className: `relative inline-flex size-24 items-center justify-center ${r("kiara-pop")}`,
                            children: [(0, i.jsx)("span", {
                                "aria-hidden": "true",
                                className: "kiara-breath absolute inset-0 rounded-full",
                                style: {
                                    background: "radial-gradient(closest-side, color-mix(in srgb, white 70%, transparent), transparent)"
                                }
                            }), (0, i.jsx)(p, {
                                size: 44,
                                tone: "light"
                            })]
                        })
                    })]
                })
            }
        }
    }
]);