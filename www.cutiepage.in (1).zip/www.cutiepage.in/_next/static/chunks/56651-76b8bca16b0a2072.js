"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [56651], {
        9388: (e, t, r) => {
            r.d(t, {
                $: () => p
            });
            var n = r(73365),
                i = r(1521),
                a = r(92166),
                l = r(16168),
                o = r(54872);
            let s = (0, l.F)(["inline-flex shrink-0 cursor-pointer items-center justify-center gap-1.5 whitespace-nowrap rounded-full font-medium", "transition-[background-color,color,border-color,box-shadow,transform] duration-150", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", "disabled:cursor-not-allowed disabled:opacity-50 aria-disabled:cursor-not-allowed aria-disabled:opacity-50", "motion-reduce:transition-none"], {
                    variants: {
                        variant: {
                            primary: "border-0 bg-cp-primary text-white hover:bg-cp-primary-hover active:scale-[0.98] motion-reduce:active:scale-100",
                            secondary: "border-0 bg-cp-subtle text-cp-ink hover:bg-cp-hover active:scale-[0.98] motion-reduce:active:scale-100",
                            outline: "border border-cp-primary bg-cp-bg text-cp-primary hover:bg-cp-primary-soft active:scale-[0.98] motion-reduce:active:scale-100",
                            ghost: "border-0 bg-transparent text-cp-ink hover:bg-cp-subtle active:bg-cp-hover",
                            "ghost-dark": "border-0 bg-transparent text-white/80 hover:bg-white/10 hover:text-white",
                            danger: "border-0 bg-cp-danger-strong text-white hover:bg-cp-danger-strong/90 active:scale-[0.98] motion-reduce:active:scale-100"
                        },
                        size: {
                            xs: "h-8 px-3 text-[13px]",
                            sm: "h-9 px-3.5 text-[13px]",
                            md: "h-11 px-4 text-[14px]",
                            lg: "h-14 px-6 text-[15px] font-semibold"
                        },
                        iconOnly: {
                            true: "px-0",
                            false: ""
                        }
                    },
                    compoundVariants: [{
                        iconOnly: !0,
                        size: "xs",
                        className: "w-8"
                    }, {
                        iconOnly: !0,
                        size: "sm",
                        className: "w-9"
                    }, {
                        iconOnly: !0,
                        size: "md",
                        className: "w-11"
                    }, {
                        iconOnly: !0,
                        size: "lg",
                        className: "w-14"
                    }],
                    defaultVariants: {
                        variant: "primary",
                        size: "md",
                        iconOnly: !1
                    }
                }),
                c = {
                    xs: "size-4",
                    sm: "size-4",
                    md: "size-4",
                    lg: "size-[18px]"
                };

            function d({
                className: e
            }) {
                return (0, n.jsxs)("svg", {
                    className: (0, o.cn)("animate-spin motion-reduce:animate-none", e),
                    viewBox: "0 0 24 24",
                    fill: "none",
                    "aria-hidden": "true",
                    children: [(0, n.jsx)("circle", {
                        className: "opacity-25",
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "currentColor",
                        strokeWidth: "3"
                    }), (0, n.jsx)("path", {
                        className: "opacity-90",
                        d: "M12 2a10 10 0 0 1 10 10",
                        stroke: "currentColor",
                        strokeWidth: "3",
                        strokeLinecap: "round"
                    })]
                })
            }

            function u(e, t) {
                return e ? i.isValidElement(e) ? i.cloneElement(e, {
                    className: (0, o.cn)(t, "shrink-0", e.props.className)
                }) : e : null
            }
            let p = i.forwardRef(({
                className: e,
                variant: t,
                size: r,
                iconOnly: l = !1,
                iconLeading: p,
                iconTrailing: m,
                loading: f = !1,
                asChild: h = !1,
                disabled: g,
                children: b,
                type: x,
                ...y
            }, v) => {
                let w = r ? ? "md",
                    k = c[w],
                    N = g || f,
                    j = f ? (0, n.jsx)(d, {
                        className: k
                    }) : u(p, k),
                    _ = f && !p ? null : u(m, k),
                    S = l && f ? null : l ? u(b, k) : b,
                    E = (0, o.cn)(s({
                        variant: t,
                        size: w,
                        iconOnly: l
                    }), f && "pointer-events-none", e);
                return h ? (0, n.jsx)(a.DX, {
                    className: E,
                    "data-cp-button": "",
                    "aria-busy": f || void 0,
                    "aria-disabled": N || void 0,
                    "data-disabled": N || void 0,
                    ref: v,
                    ...y,
                    children: i.isValidElement(b) ? i.cloneElement(b, void 0, (0, n.jsxs)(n.Fragment, {
                        children: [j, (0, n.jsx)(a.xV, {
                            children: b.props.children
                        }), _]
                    })) : b
                }) : (0, n.jsxs)("button", {
                    "data-cp-button": "",
                    className: E,
                    ref: v,
                    type: x ? ? "button",
                    disabled: N,
                    "aria-busy": f || void 0,
                    "aria-disabled": N || void 0,
                    ...y,
                    children: [j, (0, n.jsx)(a.xV, {
                        children: S
                    }), _]
                })
            });
            p.displayName = "Button"
        },
        16168: (e, t, r) => {
            r.d(t, {
                F: () => l
            });
            var n = r(68662);
            let i = e => "boolean" == typeof e ? `${e}` : 0 === e ? "0" : e,
                a = n.$,
                l = (e, t) => r => {
                    var n;
                    if ((null == t ? void 0 : t.variants) == null) return a(e, null == r ? void 0 : r.class, null == r ? void 0 : r.className);
                    let {
                        variants: l,
                        defaultVariants: o
                    } = t, s = Object.keys(l).map(e => {
                        let t = null == r ? void 0 : r[e],
                            n = null == o ? void 0 : o[e];
                        if (null === t) return null;
                        let a = i(t) || i(n);
                        return l[e][a]
                    }), c = r && Object.entries(r).reduce((e, t) => {
                        let [r, n] = t;
                        return void 0 === n || (e[r] = n), e
                    }, {});
                    return a(e, s, null == t || null == (n = t.compoundVariants) ? void 0 : n.reduce((e, t) => {
                        let {
                            class: r,
                            className: n,
                            ...i
                        } = t;
                        return Object.entries(i).every(e => {
                            let [t, r] = e;
                            return Array.isArray(r) ? r.includes({ ...o,
                                ...c
                            }[t]) : ({ ...o,
                                ...c
                            })[t] === r
                        }) ? [...e, r, n] : e
                    }, []), null == r ? void 0 : r.class, null == r ? void 0 : r.className)
                }
        },
        18542: (e, t, r) => {
            r.d(t, {
                FR: () => d,
                T5: () => o,
                Zf: () => s,
                ee: () => c,
                gk: () => u,
                tH: () => l
            });
            let n = "cp_chunk_reload_at",
                i = /ChunkLoadError|Loading chunk [^ ]+ failed|Loading CSS chunk|Failed to fetch dynamically imported module|Importing a module script failed|error loading dynamically imported module/i,
                a = /\b[a-zA-Z_$][\w$]?(?:\[[a-zA-Z_$][\w$]?\]|\.[a-zA-Z_$][\w$]?) is not a function\b|Cannot read propert(?:y|ies) of undefined \(reading '(?:call|exports|default)'\)/i;

            function l(e) {
                var t;
                return e instanceof Error && (t = `${e.name} ${e.message}`, i.test(t) || a.test(t))
            }

            function o() {
                try {
                    let e = Number(sessionStorage.getItem(n) ? ? 0);
                    if (Date.now() - e < 3e4) return !1;
                    sessionStorage.setItem(n, String(Date.now()))
                } catch {}
                return window.location.reload(), !0
            }

            function s() {
                try {
                    let e = Number(sessionStorage.getItem(n) ? ? 0);
                    return Date.now() - e < 3e4
                } catch {
                    return !1
                }
            }

            function c() {
                try {
                    sessionStorage.removeItem(n)
                } catch {}
            }

            function d() {
                try {
                    let e = new URL(window.location.href);
                    e.searchParams.set("__rl", String(Date.now())), window.location.replace(e.toString())
                } catch {
                    window.location.reload()
                }
            }
            let u = "__rl"
        },
        54872: (e, t, r) => {
            r.d(t, {
                cn: () => a
            });
            var n = r(68662),
                i = r(35490);

            function a(...e) {
                return (0, i.QP)((0, n.$)(e))
            }
        },
        56651: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => o
            });
            var n = r(73365),
                i = r(1521),
                a = r(9388),
                l = r(18542);

            function o({
                error: e,
                reset: t
            }) {
                let r = (0, l.tH)(e),
                    s = (0, l.Zf)();
                return (0, i.useEffect)(() => {
                    r && (0, l.T5)()
                }, [r]), (0, i.useEffect)(() => {
                    try {
                        let e = new URL(window.location.href);
                        if (!e.searchParams.has(l.gk)) return;
                        e.searchParams.delete(l.gk), window.history.replaceState({}, "", e.toString())
                    } catch {}
                }, []), (0, n.jsx)("div", {
                    className: "flex min-h-screen items-center justify-center bg-cp-canvas px-4 sm:px-6",
                    children: (0, n.jsxs)("div", {
                        className: "w-full max-w-lg rounded-2xl border border-cp-line bg-cp-bg p-8 text-center",
                        children: [(0, n.jsx)("p", {
                            className: "text-[12px] font-medium text-cp-muted",
                            children: r ? "Update available" : "Something went wrong"
                        }), (0, n.jsx)("h1", {
                            className: "mt-3 text-balance text-[26px] font-semibold leading-tight tracking-[-0.02em] text-cp-ink sm:text-[28px]",
                            children: r ? "Refreshing to the latest version." : s ? "That didn't work. Let's reload the page." : "We hit an unexpected error."
                        }), (0, n.jsx)("p", {
                            className: "mt-3 text-sm leading-6 text-cp-muted",
                            children: r ? "The site was updated while you were browsing. If the page doesn't refresh on its own, tap the button below." : s ? "Reloading should clear it. If it keeps happening, please let us know." : "Something went wrong on our end. Reloading the page usually fixes it."
                        }), (0, n.jsx)(a.$, {
                            variant: "primary",
                            className: "mt-6",
                            onClick: function() {
                                ((0, l.ee)(), r || s) ? (0, l.FR)() : t()
                            },
                            children: r || s ? "Reload page" : "Try again"
                        }), e.digest ? (0, n.jsxs)("p", {
                            className: "mt-4 text-[12px] tabular-nums text-cp-muted",
                            children: ["Reference: ", e.digest]
                        }) : null]
                    })
                })
            }
        },
        92166: (e, t, r) => {
            let n, i;
            r.d(t, {
                DX: () => c,
                xV: () => u
            });
            var a, l = r(1521),
                o = r.t(l, 2);

            function s(e, t) {
                if ("function" == typeof e) return e(t);
                null != e && (e.current = t)
            }
            var c = (a = "Slot", (n = l.forwardRef((e, t) => {
                    var r;
                    let n, i, {
                            children: o,
                            ...c
                        } = e,
                        u = null,
                        m = !1,
                        x = [];
                    f(o) && "function" == typeof b && (o = b(o._payload)), l.Children.forEach(o, e => {
                        var t;
                        if (t = e, l.isValidElement(t) && "function" == typeof t.type && "__radixId" in t.type && t.type.__radixId === d) {
                            m = !0;
                            let t = "child" in e.props ? e.props.child : e.props.children;
                            f(t) && "function" == typeof b && (t = b(t._payload)), u = p(e, t), x.push(u ? .props ? .children)
                        } else x.push(e)
                    }), u ? u = l.cloneElement(u, void 0, x) : !m && 1 === l.Children.count(o) && l.isValidElement(o) && (u = o);
                    let y = u ? (r = u, (i = (n = Object.getOwnPropertyDescriptor(r.props, "ref") ? .get) && "isReactWarning" in n && n.isReactWarning) ? r.ref : (i = (n = Object.getOwnPropertyDescriptor(r, "ref") ? .get) && "isReactWarning" in n && n.isReactWarning) ? r.props.ref : r.props.ref || r.ref) : void 0,
                        v = function(...e) {
                            return l.useCallback(function(...e) {
                                return t => {
                                    let r = !1,
                                        n = e.map(e => {
                                            let n = s(e, t);
                                            return r || "function" != typeof n || (r = !0), n
                                        });
                                    if (r) return () => {
                                        for (let t = 0; t < n.length; t++) {
                                            let r = n[t];
                                            "function" == typeof r ? r() : s(e[t], null)
                                        }
                                    }
                                }
                            }(...e), e)
                        }(t, y);
                    if (!u) {
                        if (o || 0 === o) throw Error(m ? g(a) : h(a));
                        return o
                    }
                    let w = function(e, t) {
                        let r = { ...t
                        };
                        for (let n in t) {
                            let i = e[n],
                                a = t[n];
                            /^on[A-Z]/.test(n) ? i && a ? r[n] = (...e) => {
                                let t = a(...e);
                                return i(...e), t
                            } : i && (r[n] = i) : "style" === n ? r[n] = { ...i,
                                ...a
                            } : "className" === n && (r[n] = [i, a].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...r
                        }
                    }(c, u.props ? ? {});
                    return u.type !== l.Fragment && (w.ref = t ? v : y), l.cloneElement(u, w)
                })).displayName = `${a}.Slot`, n),
                d = Symbol.for("radix.slottable"),
                u = ((i = e => "child" in e ? e.children(e.child) : e.children).displayName = "Slottable.Slottable", i.__radixId = d, i),
                p = (e, t) => {
                    if ("child" in e.props) {
                        let t = e.props.child;
                        return l.isValidElement(t) ? l.cloneElement(t, void 0, e.props.children(t.props.children)) : null
                    }
                    return l.isValidElement(t) ? t : null
                },
                m = Symbol.for("react.lazy");

            function f(e) {
                var t;
                return null != e && "object" == typeof e && "$$typeof" in e && e.$$typeof === m && "_payload" in e && "object" == typeof(t = e._payload) && null !== t && "then" in t
            }
            var h = e => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`,
                g = e => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`,
                b = o[" use ".trim().toString()]
        }
    }
]);