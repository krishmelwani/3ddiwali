"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [84327], {
        35490: (e, r, o) => {
            o.d(r, {
                QP: () => eb
            });
            let t = (e = new Map, r = null, o) => ({
                    nextPart: e,
                    validators: r,
                    classGroupId: o
                }),
                l = [],
                s = (e, r, o) => {
                    if (0 == e.length - r) return o.classGroupId;
                    let t = e[r],
                        l = o.nextPart.get(t);
                    if (l) {
                        let o = s(e, r + 1, l);
                        if (o) return o
                    }
                    let a = o.validators;
                    if (null === a) return;
                    let n = 0 === r ? e.join("-") : e.slice(r).join("-"),
                        i = a.length;
                    for (let e = 0; e < i; e++) {
                        let r = a[e];
                        if (r.validator(n)) return r.classGroupId
                    }
                },
                a = (e, r) => {
                    let o = t();
                    for (let t in e) n(e[t], o, t, r);
                    return o
                },
                n = (e, r, o, t) => {
                    let l = e.length;
                    for (let s = 0; s < l; s++) i(e[s], r, o, t)
                },
                i = (e, r, o, t) => {
                    "string" == typeof e ? d(e, r, o) : "function" == typeof e ? c(e, r, o, t) : m(e, r, o, t)
                },
                d = (e, r, o) => {
                    ("" === e ? r : p(r, e)).classGroupId = o
                },
                c = (e, r, o, t) => {
                    b(e) ? n(e(t), r, o, t) : (null === r.validators && (r.validators = []), r.validators.push({
                        classGroupId: o,
                        validator: e
                    }))
                },
                m = (e, r, o, t) => {
                    let l = Object.entries(e),
                        s = l.length;
                    for (let e = 0; e < s; e++) {
                        let [s, a] = l[e];
                        n(a, p(r, s), o, t)
                    }
                },
                p = (e, r) => {
                    let o = e,
                        l = r.split("-"),
                        s = l.length;
                    for (let e = 0; e < s; e++) {
                        let r = l[e],
                            s = o.nextPart.get(r);
                        s || (s = t(), o.nextPart.set(r, s)), o = s
                    }
                    return o
                },
                b = e => "isThemeGetter" in e && !0 === e.isThemeGetter,
                u = [],
                f = (e, r, o, t, l) => ({
                    modifiers: e,
                    hasImportantModifier: r,
                    baseClassName: o,
                    maybePostfixModifierPosition: t,
                    isExternal: l
                }),
                g = /\s+/,
                h = e => {
                    let r;
                    if ("string" == typeof e) return e;
                    let o = "";
                    for (let t = 0; t < e.length; t++) e[t] && (r = h(e[t])) && (o && (o += " "), o += r);
                    return o
                },
                k = [],
                x = e => {
                    let r = r => r[e] || k;
                    return r.isThemeGetter = !0, r
                },
                w = /^\[(?:(\w[\w-]*):)?(.+)\]$/i,
                v = /^\((?:(\w[\w-]*):)?(.+)\)$/i,
                y = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,
                z = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
                j = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
                G = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
                C = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
                N = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
                W = e => y.test(e),
                I = e => !!e && !Number.isNaN(Number(e)),
                O = e => !!e && Number.isInteger(Number(e)),
                $ = e => e.endsWith("%") && I(e.slice(0, -1)),
                M = e => z.test(e),
                _ = () => !0,
                P = e => j.test(e) && !G.test(e),
                S = () => !1,
                A = e => C.test(e),
                E = e => N.test(e),
                L = e => !Q(e) && !U(e),
                T = e => e.startsWith("@container") && ("/" === e[10] && void 0 !== e[11] || "s" === e[11] && void 0 !== e[16] && e.startsWith("-size/", 10) || "n" === e[11] && void 0 !== e[18] && e.startsWith("-normal/", 10)),
                q = e => et(e, en, S),
                Q = e => w.test(e),
                B = e => et(e, ei, P),
                D = e => et(e, ed, I),
                F = e => et(e, em, _),
                H = e => et(e, ec, S),
                J = e => et(e, es, S),
                K = e => et(e, ea, E),
                R = e => et(e, ep, A),
                U = e => v.test(e),
                V = e => el(e, ei),
                X = e => el(e, ec),
                Y = e => el(e, es),
                Z = e => el(e, en),
                ee = e => el(e, ea),
                er = e => el(e, ep, !0),
                eo = e => el(e, em, !0),
                et = (e, r, o) => {
                    let t = w.exec(e);
                    return !!t && (t[1] ? r(t[1]) : o(t[2]))
                },
                el = (e, r, o = !1) => {
                    let t = v.exec(e);
                    return !!t && (t[1] ? r(t[1]) : o)
                },
                es = e => "position" === e || "percentage" === e,
                ea = e => "image" === e || "url" === e,
                en = e => "length" === e || "size" === e || "bg-size" === e,
                ei = e => "length" === e,
                ed = e => "number" === e,
                ec = e => "family-name" === e,
                em = e => "number" === e || "weight" === e,
                ep = e => "shadow" === e,
                eb = ((e, ...r) => {
                    let o, t, n, i, d = e => {
                        let r = t(e);
                        if (r) return r;
                        let l = ((e, r) => {
                            let {
                                parseClassName: o,
                                getClassGroupId: t,
                                getConflictingClassGroupIds: l,
                                sortModifiers: s,
                                postfixLookupClassGroupIds: a
                            } = r, n = [], i = e.trim().split(g), d = "";
                            for (let e = i.length - 1; e >= 0; e -= 1) {
                                let r, c = i[e],
                                    {
                                        isExternal: m,
                                        modifiers: p,
                                        hasImportantModifier: b,
                                        baseClassName: u,
                                        maybePostfixModifierPosition: f
                                    } = o(c);
                                if (m) {
                                    d = c + (d.length > 0 ? " " + d : d);
                                    continue
                                }
                                let g = !!f;
                                if (g) {
                                    let e = (r = t(u.substring(0, f))) && a[r] ? t(u) : void 0;
                                    e && e !== r && (r = e, g = !1)
                                } else r = t(u);
                                if (!r) {
                                    if (!g || !(r = t(u))) {
                                        d = c + (d.length > 0 ? " " + d : d);
                                        continue
                                    }
                                    g = !1
                                }
                                let h = 0 === p.length ? "" : 1 === p.length ? p[0] : s(p).join(":"),
                                    k = b ? h + "!" : h,
                                    x = k + r;
                                if (n.indexOf(x) > -1) continue;
                                n.push(x);
                                let w = l(r, g);
                                for (let e = 0; e < w.length; ++e) {
                                    let r = w[e];
                                    n.push(k + r)
                                }
                                d = c + (d.length > 0 ? " " + d : d)
                            }
                            return d
                        })(e, o);
                        return n(e, l), l
                    };
                    return i = c => {
                        var m;
                        let p;
                        return t = (o = {
                            cache: (e => {
                                if (e < 1) return {
                                    get: () => void 0,
                                    set: () => {}
                                };
                                let r = 0,
                                    o = Object.create(null),
                                    t = Object.create(null),
                                    l = (l, s) => {
                                        o[l] = s, ++r > e && (r = 0, t = o, o = Object.create(null))
                                    };
                                return {
                                    get(e) {
                                        let r = o[e];
                                        return void 0 !== r ? r : void 0 !== (r = t[e]) ? (l(e, r), r) : void 0
                                    },
                                    set(e, r) {
                                        e in o ? o[e] = r : l(e, r)
                                    }
                                }
                            })((m = r.reduce((e, r) => r(e), e())).cacheSize),
                            parseClassName: (e => {
                                let {
                                    prefix: r,
                                    experimentalParseClassName: o
                                } = e, t = e => {
                                    let r, o = [],
                                        t = 0,
                                        l = 0,
                                        s = 0,
                                        a = e.length;
                                    for (let n = 0; n < a; n++) {
                                        let a = e[n];
                                        if (0 === t && 0 === l) {
                                            if (":" === a) {
                                                o.push(e.slice(s, n)), s = n + 1;
                                                continue
                                            }
                                            if ("/" === a) {
                                                r = n;
                                                continue
                                            }
                                        }
                                        "[" === a ? t++ : "]" === a ? t-- : "(" === a ? l++ : ")" === a && l--
                                    }
                                    let n = 0 === o.length ? e : e.slice(s),
                                        i = n,
                                        d = !1;
                                    return n.endsWith("!") ? (i = n.slice(0, -1), d = !0) : n.startsWith("!") && (i = n.slice(1), d = !0), f(o, d, i, r && r > s ? r - s : void 0)
                                };
                                if (r) {
                                    let e = r + ":",
                                        o = t;
                                    t = r => r.startsWith(e) ? o(r.slice(e.length)) : f(u, !1, r, void 0, !0)
                                }
                                if (o) {
                                    let e = t;
                                    t = r => o({
                                        className: r,
                                        parseClassName: e
                                    })
                                }
                                return t
                            })(m),
                            sortModifiers: (p = new Map, m.orderSensitiveModifiers.forEach((e, r) => {
                                p.set(e, 1e6 + r)
                            }), e => {
                                let r = [],
                                    o = [];
                                for (let t = 0; t < e.length; t++) {
                                    let l = e[t],
                                        s = "[" === l[0],
                                        a = p.has(l);
                                    s || a ? (o.length > 0 && (o.sort(), r.push(...o), o = []), r.push(l)) : o.push(l)
                                }
                                return o.length > 0 && (o.sort(), r.push(...o)), r
                            }),
                            postfixLookupClassGroupIds: (e => {
                                let r = Object.create(null),
                                    o = e.postfixLookupClassGroups;
                                if (o)
                                    for (let e = 0; e < o.length; e++) r[o[e]] = !0;
                                return r
                            })(m),
                            ...(e => {
                                let r = (e => {
                                        let {
                                            theme: r,
                                            classGroups: o
                                        } = e;
                                        return a(o, r)
                                    })(e),
                                    {
                                        conflictingClassGroups: o,
                                        conflictingClassGroupModifiers: t
                                    } = e;
                                return {
                                    getClassGroupId: e => {
                                        if (e.startsWith("[") && e.endsWith("]")) {
                                            var o;
                                            let r, t, l;
                                            return -1 === (o = e).slice(1, -1).indexOf(":") ? void 0 : (t = (r = o.slice(1, -1)).indexOf(":"), (l = r.slice(0, t)) ? "arbitrary.." + l : void 0)
                                        }
                                        let t = e.split("-"),
                                            l = +("" === t[0] && t.length > 1);
                                        return s(t, l, r)
                                    },
                                    getConflictingClassGroupIds: (e, r) => {
                                        if (r) {
                                            let r = t[e],
                                                s = o[e];
                                            if (r) {
                                                if (s) {
                                                    let e = Array(s.length + r.length);
                                                    for (let r = 0; r < s.length; r++) e[r] = s[r];
                                                    for (let o = 0; o < r.length; o++) e[s.length + o] = r[o];
                                                    return e
                                                }
                                                return r
                                            }
                                            return s || l
                                        }
                                        return o[e] || l
                                    }
                                }
                            })(m)
                        }).cache.get, n = o.cache.set, i = d, d(c)
                    }, (...e) => i(((...e) => {
                        let r, o, t = 0,
                            l = "";
                        for (; t < e.length;)(r = e[t++]) && (o = h(r)) && (l && (l += " "), l += o);
                        return l
                    })(...e))
                })(() => {
                    let e = x("color"),
                        r = x("font"),
                        o = x("text"),
                        t = x("font-weight"),
                        l = x("tracking"),
                        s = x("leading"),
                        a = x("breakpoint"),
                        n = x("container"),
                        i = x("spacing"),
                        d = x("radius"),
                        c = x("shadow"),
                        m = x("inset-shadow"),
                        p = x("text-shadow"),
                        b = x("drop-shadow"),
                        u = x("blur"),
                        f = x("perspective"),
                        g = x("aspect"),
                        h = x("ease"),
                        k = x("animate"),
                        w = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"],
                        v = () => ["center", "top", "bottom", "left", "right", "top-left", "left-top", "top-right", "right-top", "bottom-right", "right-bottom", "bottom-left", "left-bottom"],
                        y = () => [...v(), U, Q],
                        z = () => ["auto", "hidden", "clip", "visible", "scroll"],
                        j = () => ["auto", "contain", "none"],
                        G = () => [U, Q, i],
                        C = () => [W, "full", "auto", ...G()],
                        N = () => [O, "none", "subgrid", U, Q],
                        P = () => ["auto", {
                            span: ["full", O, U, Q]
                        }, O, U, Q],
                        S = () => [O, "auto", U, Q],
                        A = () => ["auto", "min", "max", "fr", U, Q],
                        E = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"],
                        et = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"],
                        el = () => ["auto", ...G()],
                        es = () => [W, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...G()],
                        ea = () => [W, "screen", "full", "dvw", "lvw", "svw", "min", "max", "fit", ...G()],
                        en = () => [W, "screen", "full", "lh", "dvh", "lvh", "svh", "min", "max", "fit", ...G()],
                        ei = () => [e, U, Q],
                        ed = () => [...v(), Y, J, {
                            position: [U, Q]
                        }],
                        ec = () => ["no-repeat", {
                            repeat: ["", "x", "y", "space", "round"]
                        }],
                        em = () => ["auto", "cover", "contain", Z, q, {
                            size: [U, Q]
                        }],
                        ep = () => [$, V, B],
                        eb = () => ["", "none", "full", d, U, Q],
                        eu = () => ["", I, V, B],
                        ef = () => ["solid", "dashed", "dotted", "double"],
                        eg = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"],
                        eh = () => [I, $, Y, J],
                        ek = () => ["", "none", u, U, Q],
                        ex = () => ["none", I, U, Q],
                        ew = () => ["none", I, U, Q],
                        ev = () => [I, U, Q],
                        ey = () => [W, "full", ...G()];
                    return {
                        cacheSize: 500,
                        theme: {
                            animate: ["spin", "ping", "pulse", "bounce"],
                            aspect: ["video"],
                            blur: [M],
                            breakpoint: [M],
                            color: [_],
                            container: [M],
                            "drop-shadow": [M],
                            ease: ["in", "out", "in-out"],
                            font: [L],
                            "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
                            "inset-shadow": [M],
                            leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
                            perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
                            radius: [M],
                            shadow: [M],
                            spacing: ["px", I],
                            text: [M],
                            "text-shadow": [M],
                            tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
                        },
                        classGroups: {
                            aspect: [{
                                aspect: ["auto", "square", W, Q, U, g]
                            }],
                            container: ["container"],
                            "container-type": [{
                                "@container": ["", "normal", "size", U, Q]
                            }],
                            "container-named": [T],
                            columns: [{
                                columns: [I, Q, U, n]
                            }],
                            "break-after": [{
                                "break-after": w()
                            }],
                            "break-before": [{
                                "break-before": w()
                            }],
                            "break-inside": [{
                                "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                            }],
                            "box-decoration": [{
                                "box-decoration": ["slice", "clone"]
                            }],
                            box: [{
                                box: ["border", "content"]
                            }],
                            display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                            sr: ["sr-only", "not-sr-only"],
                            float: [{
                                float: ["right", "left", "none", "start", "end"]
                            }],
                            clear: [{
                                clear: ["left", "right", "both", "none", "start", "end"]
                            }],
                            isolation: ["isolate", "isolation-auto"],
                            "object-fit": [{
                                object: ["contain", "cover", "fill", "none", "scale-down"]
                            }],
                            "object-position": [{
                                object: y()
                            }],
                            overflow: [{
                                overflow: z()
                            }],
                            "overflow-x": [{
                                "overflow-x": z()
                            }],
                            "overflow-y": [{
                                "overflow-y": z()
                            }],
                            overscroll: [{
                                overscroll: j()
                            }],
                            "overscroll-x": [{
                                "overscroll-x": j()
                            }],
                            "overscroll-y": [{
                                "overscroll-y": j()
                            }],
                            position: ["static", "fixed", "absolute", "relative", "sticky"],
                            inset: [{
                                inset: C()
                            }],
                            "inset-x": [{
                                "inset-x": C()
                            }],
                            "inset-y": [{
                                "inset-y": C()
                            }],
                            start: [{
                                "inset-s": C(),
                                start: C()
                            }],
                            end: [{
                                "inset-e": C(),
                                end: C()
                            }],
                            "inset-bs": [{
                                "inset-bs": C()
                            }],
                            "inset-be": [{
                                "inset-be": C()
                            }],
                            top: [{
                                top: C()
                            }],
                            right: [{
                                right: C()
                            }],
                            bottom: [{
                                bottom: C()
                            }],
                            left: [{
                                left: C()
                            }],
                            visibility: ["visible", "invisible", "collapse"],
                            z: [{
                                z: [O, "auto", U, Q]
                            }],
                            basis: [{
                                basis: [W, "full", "auto", n, ...G()]
                            }],
                            "flex-direction": [{
                                flex: ["row", "row-reverse", "col", "col-reverse"]
                            }],
                            "flex-wrap": [{
                                flex: ["nowrap", "wrap", "wrap-reverse"]
                            }],
                            flex: [{
                                flex: [I, W, "auto", "initial", "none", Q]
                            }],
                            grow: [{
                                grow: ["", I, U, Q]
                            }],
                            shrink: [{
                                shrink: ["", I, U, Q]
                            }],
                            order: [{
                                order: [O, "first", "last", "none", U, Q]
                            }],
                            "grid-cols": [{
                                "grid-cols": N()
                            }],
                            "col-start-end": [{
                                col: P()
                            }],
                            "col-start": [{
                                "col-start": S()
                            }],
                            "col-end": [{
                                "col-end": S()
                            }],
                            "grid-rows": [{
                                "grid-rows": N()
                            }],
                            "row-start-end": [{
                                row: P()
                            }],
                            "row-start": [{
                                "row-start": S()
                            }],
                            "row-end": [{
                                "row-end": S()
                            }],
                            "grid-flow": [{
                                "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                            }],
                            "auto-cols": [{
                                "auto-cols": A()
                            }],
                            "auto-rows": [{
                                "auto-rows": A()
                            }],
                            gap: [{
                                gap: G()
                            }],
                            "gap-x": [{
                                "gap-x": G()
                            }],
                            "gap-y": [{
                                "gap-y": G()
                            }],
                            "justify-content": [{
                                justify: [...E(), "normal"]
                            }],
                            "justify-items": [{
                                "justify-items": [...et(), "normal"]
                            }],
                            "justify-self": [{
                                "justify-self": ["auto", ...et()]
                            }],
                            "align-content": [{
                                content: ["normal", ...E()]
                            }],
                            "align-items": [{
                                items: [...et(), {
                                    baseline: ["", "last"]
                                }]
                            }],
                            "align-self": [{
                                self: ["auto", ...et(), {
                                    baseline: ["", "last"]
                                }]
                            }],
                            "place-content": [{
                                "place-content": E()
                            }],
                            "place-items": [{
                                "place-items": [...et(), "baseline"]
                            }],
                            "place-self": [{
                                "place-self": ["auto", ...et()]
                            }],
                            p: [{
                                p: G()
                            }],
                            px: [{
                                px: G()
                            }],
                            py: [{
                                py: G()
                            }],
                            ps: [{
                                ps: G()
                            }],
                            pe: [{
                                pe: G()
                            }],
                            pbs: [{
                                pbs: G()
                            }],
                            pbe: [{
                                pbe: G()
                            }],
                            pt: [{
                                pt: G()
                            }],
                            pr: [{
                                pr: G()
                            }],
                            pb: [{
                                pb: G()
                            }],
                            pl: [{
                                pl: G()
                            }],
                            m: [{
                                m: el()
                            }],
                            mx: [{
                                mx: el()
                            }],
                            my: [{
                                my: el()
                            }],
                            ms: [{
                                ms: el()
                            }],
                            me: [{
                                me: el()
                            }],
                            mbs: [{
                                mbs: el()
                            }],
                            mbe: [{
                                mbe: el()
                            }],
                            mt: [{
                                mt: el()
                            }],
                            mr: [{
                                mr: el()
                            }],
                            mb: [{
                                mb: el()
                            }],
                            ml: [{
                                ml: el()
                            }],
                            "space-x": [{
                                "space-x": G()
                            }],
                            "space-x-reverse": ["space-x-reverse"],
                            "space-y": [{
                                "space-y": G()
                            }],
                            "space-y-reverse": ["space-y-reverse"],
                            size: [{
                                size: es()
                            }],
                            "inline-size": [{
                                inline: ["auto", ...ea()]
                            }],
                            "min-inline-size": [{
                                "min-inline": ["auto", ...ea()]
                            }],
                            "max-inline-size": [{
                                "max-inline": ["none", ...ea()]
                            }],
                            "block-size": [{
                                block: ["auto", ...en()]
                            }],
                            "min-block-size": [{
                                "min-block": ["auto", ...en()]
                            }],
                            "max-block-size": [{
                                "max-block": ["none", ...en()]
                            }],
                            w: [{
                                w: [n, "screen", ...es()]
                            }],
                            "min-w": [{
                                "min-w": [n, "screen", "none", ...es()]
                            }],
                            "max-w": [{
                                "max-w": [n, "screen", "none", "prose", {
                                    screen: [a]
                                }, ...es()]
                            }],
                            h: [{
                                h: ["screen", "lh", ...es()]
                            }],
                            "min-h": [{
                                "min-h": ["screen", "lh", "none", ...es()]
                            }],
                            "max-h": [{
                                "max-h": ["screen", "lh", ...es()]
                            }],
                            "font-size": [{
                                text: ["base", o, V, B]
                            }],
                            "font-smoothing": ["antialiased", "subpixel-antialiased"],
                            "font-style": ["italic", "not-italic"],
                            "font-weight": [{
                                font: [t, eo, F]
                            }],
                            "font-stretch": [{
                                "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", $, Q]
                            }],
                            "font-family": [{
                                font: [X, H, r]
                            }],
                            "font-features": [{
                                "font-features": [Q]
                            }],
                            "fvn-normal": ["normal-nums"],
                            "fvn-ordinal": ["ordinal"],
                            "fvn-slashed-zero": ["slashed-zero"],
                            "fvn-figure": ["lining-nums", "oldstyle-nums"],
                            "fvn-spacing": ["proportional-nums", "tabular-nums"],
                            "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
                            tracking: [{
                                tracking: [l, U, Q]
                            }],
                            "line-clamp": [{
                                "line-clamp": [I, "none", U, D]
                            }],
                            leading: [{
                                leading: [s, ...G()]
                            }],
                            "list-image": [{
                                "list-image": ["none", U, Q]
                            }],
                            "list-style-position": [{
                                list: ["inside", "outside"]
                            }],
                            "list-style-type": [{
                                list: ["disc", "decimal", "none", U, Q]
                            }],
                            "text-alignment": [{
                                text: ["left", "center", "right", "justify", "start", "end"]
                            }],
                            "placeholder-color": [{
                                placeholder: ei()
                            }],
                            "text-color": [{
                                text: ei()
                            }],
                            "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                            "text-decoration-style": [{
                                decoration: [...ef(), "wavy"]
                            }],
                            "text-decoration-thickness": [{
                                decoration: [I, "from-font", "auto", U, B]
                            }],
                            "text-decoration-color": [{
                                decoration: ei()
                            }],
                            "underline-offset": [{
                                "underline-offset": [I, "auto", U, Q]
                            }],
                            "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                            "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                            "text-wrap": [{
                                text: ["wrap", "nowrap", "balance", "pretty"]
                            }],
                            indent: [{
                                indent: G()
                            }],
                            "tab-size": [{
                                tab: [O, U, Q]
                            }],
                            "vertical-align": [{
                                align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", U, Q]
                            }],
                            whitespace: [{
                                whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                            }],
                            break: [{
                                break: ["normal", "words", "all", "keep"]
                            }],
                            wrap: [{
                                wrap: ["break-word", "anywhere", "normal"]
                            }],
                            hyphens: [{
                                hyphens: ["none", "manual", "auto"]
                            }],
                            content: [{
                                content: ["none", U, Q]
                            }],
                            "bg-attachment": [{
                                bg: ["fixed", "local", "scroll"]
                            }],
                            "bg-clip": [{
                                "bg-clip": ["border", "padding", "content", "text"]
                            }],
                            "bg-origin": [{
                                "bg-origin": ["border", "padding", "content"]
                            }],
                            "bg-position": [{
                                bg: ed()
                            }],
                            "bg-repeat": [{
                                bg: ec()
                            }],
                            "bg-size": [{
                                bg: em()
                            }],
                            "bg-image": [{
                                bg: ["none", {
                                    linear: [{
                                        to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                                    }, O, U, Q],
                                    radial: ["", U, Q],
                                    conic: [O, U, Q]
                                }, ee, K]
                            }],
                            "bg-color": [{
                                bg: ei()
                            }],
                            "gradient-from-pos": [{
                                from: ep()
                            }],
                            "gradient-via-pos": [{
                                via: ep()
                            }],
                            "gradient-to-pos": [{
                                to: ep()
                            }],
                            "gradient-from": [{
                                from: ei()
                            }],
                            "gradient-via": [{
                                via: ei()
                            }],
                            "gradient-to": [{
                                to: ei()
                            }],
                            rounded: [{
                                rounded: eb()
                            }],
                            "rounded-s": [{
                                "rounded-s": eb()
                            }],
                            "rounded-e": [{
                                "rounded-e": eb()
                            }],
                            "rounded-t": [{
                                "rounded-t": eb()
                            }],
                            "rounded-r": [{
                                "rounded-r": eb()
                            }],
                            "rounded-b": [{
                                "rounded-b": eb()
                            }],
                            "rounded-l": [{
                                "rounded-l": eb()
                            }],
                            "rounded-ss": [{
                                "rounded-ss": eb()
                            }],
                            "rounded-se": [{
                                "rounded-se": eb()
                            }],
                            "rounded-ee": [{
                                "rounded-ee": eb()
                            }],
                            "rounded-es": [{
                                "rounded-es": eb()
                            }],
                            "rounded-tl": [{
                                "rounded-tl": eb()
                            }],
                            "rounded-tr": [{
                                "rounded-tr": eb()
                            }],
                            "rounded-br": [{
                                "rounded-br": eb()
                            }],
                            "rounded-bl": [{
                                "rounded-bl": eb()
                            }],
                            "border-w": [{
                                border: eu()
                            }],
                            "border-w-x": [{
                                "border-x": eu()
                            }],
                            "border-w-y": [{
                                "border-y": eu()
                            }],
                            "border-w-s": [{
                                "border-s": eu()
                            }],
                            "border-w-e": [{
                                "border-e": eu()
                            }],
                            "border-w-bs": [{
                                "border-bs": eu()
                            }],
                            "border-w-be": [{
                                "border-be": eu()
                            }],
                            "border-w-t": [{
                                "border-t": eu()
                            }],
                            "border-w-r": [{
                                "border-r": eu()
                            }],
                            "border-w-b": [{
                                "border-b": eu()
                            }],
                            "border-w-l": [{
                                "border-l": eu()
                            }],
                            "divide-x": [{
                                "divide-x": eu()
                            }],
                            "divide-x-reverse": ["divide-x-reverse"],
                            "divide-y": [{
                                "divide-y": eu()
                            }],
                            "divide-y-reverse": ["divide-y-reverse"],
                            "border-style": [{
                                border: [...ef(), "hidden", "none"]
                            }],
                            "divide-style": [{
                                divide: [...ef(), "hidden", "none"]
                            }],
                            "border-color": [{
                                border: ei()
                            }],
                            "border-color-x": [{
                                "border-x": ei()
                            }],
                            "border-color-y": [{
                                "border-y": ei()
                            }],
                            "border-color-s": [{
                                "border-s": ei()
                            }],
                            "border-color-e": [{
                                "border-e": ei()
                            }],
                            "border-color-bs": [{
                                "border-bs": ei()
                            }],
                            "border-color-be": [{
                                "border-be": ei()
                            }],
                            "border-color-t": [{
                                "border-t": ei()
                            }],
                            "border-color-r": [{
                                "border-r": ei()
                            }],
                            "border-color-b": [{
                                "border-b": ei()
                            }],
                            "border-color-l": [{
                                "border-l": ei()
                            }],
                            "divide-color": [{
                                divide: ei()
                            }],
                            "outline-style": [{
                                outline: [...ef(), "none", "hidden"]
                            }],
                            "outline-offset": [{
                                "outline-offset": [I, U, Q]
                            }],
                            "outline-w": [{
                                outline: ["", I, V, B]
                            }],
                            "outline-color": [{
                                outline: ei()
                            }],
                            shadow: [{
                                shadow: ["", "none", c, er, R]
                            }],
                            "shadow-color": [{
                                shadow: ei()
                            }],
                            "inset-shadow": [{
                                "inset-shadow": ["none", m, er, R]
                            }],
                            "inset-shadow-color": [{
                                "inset-shadow": ei()
                            }],
                            "ring-w": [{
                                ring: eu()
                            }],
                            "ring-w-inset": ["ring-inset"],
                            "ring-color": [{
                                ring: ei()
                            }],
                            "ring-offset-w": [{
                                "ring-offset": [I, B]
                            }],
                            "ring-offset-color": [{
                                "ring-offset": ei()
                            }],
                            "inset-ring-w": [{
                                "inset-ring": eu()
                            }],
                            "inset-ring-color": [{
                                "inset-ring": ei()
                            }],
                            "text-shadow": [{
                                "text-shadow": ["none", p, er, R]
                            }],
                            "text-shadow-color": [{
                                "text-shadow": ei()
                            }],
                            opacity: [{
                                opacity: [I, U, Q]
                            }],
                            "mix-blend": [{
                                "mix-blend": [...eg(), "plus-darker", "plus-lighter"]
                            }],
                            "bg-blend": [{
                                "bg-blend": eg()
                            }],
                            "mask-clip": [{
                                "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
                            }, "mask-no-clip"],
                            "mask-composite": [{
                                mask: ["add", "subtract", "intersect", "exclude"]
                            }],
                            "mask-image-linear-pos": [{
                                "mask-linear": [I]
                            }],
                            "mask-image-linear-from-pos": [{
                                "mask-linear-from": eh()
                            }],
                            "mask-image-linear-to-pos": [{
                                "mask-linear-to": eh()
                            }],
                            "mask-image-linear-from-color": [{
                                "mask-linear-from": ei()
                            }],
                            "mask-image-linear-to-color": [{
                                "mask-linear-to": ei()
                            }],
                            "mask-image-t-from-pos": [{
                                "mask-t-from": eh()
                            }],
                            "mask-image-t-to-pos": [{
                                "mask-t-to": eh()
                            }],
                            "mask-image-t-from-color": [{
                                "mask-t-from": ei()
                            }],
                            "mask-image-t-to-color": [{
                                "mask-t-to": ei()
                            }],
                            "mask-image-r-from-pos": [{
                                "mask-r-from": eh()
                            }],
                            "mask-image-r-to-pos": [{
                                "mask-r-to": eh()
                            }],
                            "mask-image-r-from-color": [{
                                "mask-r-from": ei()
                            }],
                            "mask-image-r-to-color": [{
                                "mask-r-to": ei()
                            }],
                            "mask-image-b-from-pos": [{
                                "mask-b-from": eh()
                            }],
                            "mask-image-b-to-pos": [{
                                "mask-b-to": eh()
                            }],
                            "mask-image-b-from-color": [{
                                "mask-b-from": ei()
                            }],
                            "mask-image-b-to-color": [{
                                "mask-b-to": ei()
                            }],
                            "mask-image-l-from-pos": [{
                                "mask-l-from": eh()
                            }],
                            "mask-image-l-to-pos": [{
                                "mask-l-to": eh()
                            }],
                            "mask-image-l-from-color": [{
                                "mask-l-from": ei()
                            }],
                            "mask-image-l-to-color": [{
                                "mask-l-to": ei()
                            }],
                            "mask-image-x-from-pos": [{
                                "mask-x-from": eh()
                            }],
                            "mask-image-x-to-pos": [{
                                "mask-x-to": eh()
                            }],
                            "mask-image-x-from-color": [{
                                "mask-x-from": ei()
                            }],
                            "mask-image-x-to-color": [{
                                "mask-x-to": ei()
                            }],
                            "mask-image-y-from-pos": [{
                                "mask-y-from": eh()
                            }],
                            "mask-image-y-to-pos": [{
                                "mask-y-to": eh()
                            }],
                            "mask-image-y-from-color": [{
                                "mask-y-from": ei()
                            }],
                            "mask-image-y-to-color": [{
                                "mask-y-to": ei()
                            }],
                            "mask-image-radial": [{
                                "mask-radial": [U, Q]
                            }],
                            "mask-image-radial-from-pos": [{
                                "mask-radial-from": eh()
                            }],
                            "mask-image-radial-to-pos": [{
                                "mask-radial-to": eh()
                            }],
                            "mask-image-radial-from-color": [{
                                "mask-radial-from": ei()
                            }],
                            "mask-image-radial-to-color": [{
                                "mask-radial-to": ei()
                            }],
                            "mask-image-radial-shape": [{
                                "mask-radial": ["circle", "ellipse"]
                            }],
                            "mask-image-radial-size": [{
                                "mask-radial": [{
                                    closest: ["side", "corner"],
                                    farthest: ["side", "corner"]
                                }]
                            }],
                            "mask-image-radial-pos": [{
                                "mask-radial-at": v()
                            }],
                            "mask-image-conic-pos": [{
                                "mask-conic": [I]
                            }],
                            "mask-image-conic-from-pos": [{
                                "mask-conic-from": eh()
                            }],
                            "mask-image-conic-to-pos": [{
                                "mask-conic-to": eh()
                            }],
                            "mask-image-conic-from-color": [{
                                "mask-conic-from": ei()
                            }],
                            "mask-image-conic-to-color": [{
                                "mask-conic-to": ei()
                            }],
                            "mask-mode": [{
                                mask: ["alpha", "luminance", "match"]
                            }],
                            "mask-origin": [{
                                "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
                            }],
                            "mask-position": [{
                                mask: ed()
                            }],
                            "mask-repeat": [{
                                mask: ec()
                            }],
                            "mask-size": [{
                                mask: em()
                            }],
                            "mask-type": [{
                                "mask-type": ["alpha", "luminance"]
                            }],
                            "mask-image": [{
                                mask: ["none", U, Q]
                            }],
                            filter: [{
                                filter: ["", "none", U, Q]
                            }],
                            blur: [{
                                blur: ek()
                            }],
                            brightness: [{
                                brightness: [I, U, Q]
                            }],
                            contrast: [{
                                contrast: [I, U, Q]
                            }],
                            "drop-shadow": [{
                                "drop-shadow": ["", "none", b, er, R]
                            }],
                            "drop-shadow-color": [{
                                "drop-shadow": ei()
                            }],
                            grayscale: [{
                                grayscale: ["", I, U, Q]
                            }],
                            "hue-rotate": [{
                                "hue-rotate": [I, U, Q]
                            }],
                            invert: [{
                                invert: ["", I, U, Q]
                            }],
                            saturate: [{
                                saturate: [I, U, Q]
                            }],
                            sepia: [{
                                sepia: ["", I, U, Q]
                            }],
                            "backdrop-filter": [{
                                "backdrop-filter": ["", "none", U, Q]
                            }],
                            "backdrop-blur": [{
                                "backdrop-blur": ek()
                            }],
                            "backdrop-brightness": [{
                                "backdrop-brightness": [I, U, Q]
                            }],
                            "backdrop-contrast": [{
                                "backdrop-contrast": [I, U, Q]
                            }],
                            "backdrop-grayscale": [{
                                "backdrop-grayscale": ["", I, U, Q]
                            }],
                            "backdrop-hue-rotate": [{
                                "backdrop-hue-rotate": [I, U, Q]
                            }],
                            "backdrop-invert": [{
                                "backdrop-invert": ["", I, U, Q]
                            }],
                            "backdrop-opacity": [{
                                "backdrop-opacity": [I, U, Q]
                            }],
                            "backdrop-saturate": [{
                                "backdrop-saturate": [I, U, Q]
                            }],
                            "backdrop-sepia": [{
                                "backdrop-sepia": ["", I, U, Q]
                            }],
                            "border-collapse": [{
                                border: ["collapse", "separate"]
                            }],
                            "border-spacing": [{
                                "border-spacing": G()
                            }],
                            "border-spacing-x": [{
                                "border-spacing-x": G()
                            }],
                            "border-spacing-y": [{
                                "border-spacing-y": G()
                            }],
                            "table-layout": [{
                                table: ["auto", "fixed"]
                            }],
                            caption: [{
                                caption: ["top", "bottom"]
                            }],
                            transition: [{
                                transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", U, Q]
                            }],
                            "transition-behavior": [{
                                transition: ["normal", "discrete"]
                            }],
                            duration: [{
                                duration: [I, "initial", U, Q]
                            }],
                            ease: [{
                                ease: ["linear", "initial", h, U, Q]
                            }],
                            delay: [{
                                delay: [I, U, Q]
                            }],
                            animate: [{
                                animate: ["none", k, U, Q]
                            }],
                            backface: [{
                                backface: ["hidden", "visible"]
                            }],
                            perspective: [{
                                perspective: [f, U, Q]
                            }],
                            "perspective-origin": [{
                                "perspective-origin": y()
                            }],
                            rotate: [{
                                rotate: ex()
                            }],
                            "rotate-x": [{
                                "rotate-x": ex()
                            }],
                            "rotate-y": [{
                                "rotate-y": ex()
                            }],
                            "rotate-z": [{
                                "rotate-z": ex()
                            }],
                            scale: [{
                                scale: ew()
                            }],
                            "scale-x": [{
                                "scale-x": ew()
                            }],
                            "scale-y": [{
                                "scale-y": ew()
                            }],
                            "scale-z": [{
                                "scale-z": ew()
                            }],
                            "scale-3d": ["scale-3d"],
                            skew: [{
                                skew: ev()
                            }],
                            "skew-x": [{
                                "skew-x": ev()
                            }],
                            "skew-y": [{
                                "skew-y": ev()
                            }],
                            transform: [{
                                transform: [U, Q, "", "none", "gpu", "cpu"]
                            }],
                            "transform-origin": [{
                                origin: y()
                            }],
                            "transform-style": [{
                                transform: ["3d", "flat"]
                            }],
                            translate: [{
                                translate: ey()
                            }],
                            "translate-x": [{
                                "translate-x": ey()
                            }],
                            "translate-y": [{
                                "translate-y": ey()
                            }],
                            "translate-z": [{
                                "translate-z": ey()
                            }],
                            "translate-none": ["translate-none"],
                            zoom: [{
                                zoom: [O, U, Q]
                            }],
                            accent: [{
                                accent: ei()
                            }],
                            appearance: [{
                                appearance: ["none", "auto"]
                            }],
                            "caret-color": [{
                                caret: ei()
                            }],
                            "color-scheme": [{
                                scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
                            }],
                            cursor: [{
                                cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", U, Q]
                            }],
                            "field-sizing": [{
                                "field-sizing": ["fixed", "content"]
                            }],
                            "pointer-events": [{
                                "pointer-events": ["auto", "none"]
                            }],
                            resize: [{
                                resize: ["none", "", "y", "x"]
                            }],
                            "scroll-behavior": [{
                                scroll: ["auto", "smooth"]
                            }],
                            "scrollbar-thumb-color": [{
                                "scrollbar-thumb": ei()
                            }],
                            "scrollbar-track-color": [{
                                "scrollbar-track": ei()
                            }],
                            "scrollbar-gutter": [{
                                "scrollbar-gutter": ["auto", "stable", "both"]
                            }],
                            "scrollbar-w": [{
                                scrollbar: ["auto", "thin", "none"]
                            }],
                            "scroll-m": [{
                                "scroll-m": G()
                            }],
                            "scroll-mx": [{
                                "scroll-mx": G()
                            }],
                            "scroll-my": [{
                                "scroll-my": G()
                            }],
                            "scroll-ms": [{
                                "scroll-ms": G()
                            }],
                            "scroll-me": [{
                                "scroll-me": G()
                            }],
                            "scroll-mbs": [{
                                "scroll-mbs": G()
                            }],
                            "scroll-mbe": [{
                                "scroll-mbe": G()
                            }],
                            "scroll-mt": [{
                                "scroll-mt": G()
                            }],
                            "scroll-mr": [{
                                "scroll-mr": G()
                            }],
                            "scroll-mb": [{
                                "scroll-mb": G()
                            }],
                            "scroll-ml": [{
                                "scroll-ml": G()
                            }],
                            "scroll-p": [{
                                "scroll-p": G()
                            }],
                            "scroll-px": [{
                                "scroll-px": G()
                            }],
                            "scroll-py": [{
                                "scroll-py": G()
                            }],
                            "scroll-ps": [{
                                "scroll-ps": G()
                            }],
                            "scroll-pe": [{
                                "scroll-pe": G()
                            }],
                            "scroll-pbs": [{
                                "scroll-pbs": G()
                            }],
                            "scroll-pbe": [{
                                "scroll-pbe": G()
                            }],
                            "scroll-pt": [{
                                "scroll-pt": G()
                            }],
                            "scroll-pr": [{
                                "scroll-pr": G()
                            }],
                            "scroll-pb": [{
                                "scroll-pb": G()
                            }],
                            "scroll-pl": [{
                                "scroll-pl": G()
                            }],
                            "snap-align": [{
                                snap: ["start", "end", "center", "align-none"]
                            }],
                            "snap-stop": [{
                                snap: ["normal", "always"]
                            }],
                            "snap-type": [{
                                snap: ["none", "x", "y", "both"]
                            }],
                            "snap-strictness": [{
                                snap: ["mandatory", "proximity"]
                            }],
                            touch: [{
                                touch: ["auto", "none", "manipulation"]
                            }],
                            "touch-x": [{
                                "touch-pan": ["x", "left", "right"]
                            }],
                            "touch-y": [{
                                "touch-pan": ["y", "up", "down"]
                            }],
                            "touch-pz": ["touch-pinch-zoom"],
                            select: [{
                                select: ["none", "text", "all", "auto"]
                            }],
                            "will-change": [{
                                "will-change": ["auto", "scroll", "contents", "transform", U, Q]
                            }],
                            fill: [{
                                fill: ["none", ...ei()]
                            }],
                            "stroke-w": [{
                                stroke: [I, V, B, D]
                            }],
                            stroke: [{
                                stroke: ["none", ...ei()]
                            }],
                            "forced-color-adjust": [{
                                "forced-color-adjust": ["auto", "none"]
                            }]
                        },
                        conflictingClassGroups: {
                            "container-named": ["container-type"],
                            overflow: ["overflow-x", "overflow-y"],
                            overscroll: ["overscroll-x", "overscroll-y"],
                            inset: ["inset-x", "inset-y", "inset-bs", "inset-be", "start", "end", "top", "right", "bottom", "left"],
                            "inset-x": ["right", "left"],
                            "inset-y": ["top", "bottom"],
                            flex: ["basis", "grow", "shrink"],
                            gap: ["gap-x", "gap-y"],
                            p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
                            px: ["pr", "pl"],
                            py: ["pt", "pb"],
                            m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
                            mx: ["mr", "ml"],
                            my: ["mt", "mb"],
                            size: ["w", "h"],
                            "font-size": ["leading"],
                            "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                            "fvn-ordinal": ["fvn-normal"],
                            "fvn-slashed-zero": ["fvn-normal"],
                            "fvn-figure": ["fvn-normal"],
                            "fvn-spacing": ["fvn-normal"],
                            "fvn-fraction": ["fvn-normal"],
                            "line-clamp": ["display", "overflow"],
                            rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                            "rounded-s": ["rounded-ss", "rounded-es"],
                            "rounded-e": ["rounded-se", "rounded-ee"],
                            "rounded-t": ["rounded-tl", "rounded-tr"],
                            "rounded-r": ["rounded-tr", "rounded-br"],
                            "rounded-b": ["rounded-br", "rounded-bl"],
                            "rounded-l": ["rounded-tl", "rounded-bl"],
                            "border-spacing": ["border-spacing-x", "border-spacing-y"],
                            "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-bs", "border-w-be", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                            "border-w-x": ["border-w-r", "border-w-l"],
                            "border-w-y": ["border-w-t", "border-w-b"],
                            "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-bs", "border-color-be", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                            "border-color-x": ["border-color-r", "border-color-l"],
                            "border-color-y": ["border-color-t", "border-color-b"],
                            translate: ["translate-x", "translate-y", "translate-none"],
                            "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
                            "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mbs", "scroll-mbe", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                            "scroll-mx": ["scroll-mr", "scroll-ml"],
                            "scroll-my": ["scroll-mt", "scroll-mb"],
                            "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pbs", "scroll-pbe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                            "scroll-px": ["scroll-pr", "scroll-pl"],
                            "scroll-py": ["scroll-pt", "scroll-pb"],
                            touch: ["touch-x", "touch-y", "touch-pz"],
                            "touch-x": ["touch"],
                            "touch-y": ["touch"],
                            "touch-pz": ["touch"]
                        },
                        conflictingClassGroupModifiers: {
                            "font-size": ["leading"]
                        },
                        postfixLookupClassGroups: ["container-type"],
                        orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
                    }
                })
        },
        68662: (e, r, o) => {
            o.d(r, {
                $: () => t
            });

            function t() {
                for (var e, r, o = 0, t = "", l = arguments.length; o < l; o++)(e = arguments[o]) && (r = function e(r) {
                    var o, t, l = "";
                    if ("string" == typeof r || "number" == typeof r) l += r;
                    else if ("object" == typeof r)
                        if (Array.isArray(r)) {
                            var s = r.length;
                            for (o = 0; o < s; o++) r[o] && (t = e(r[o])) && (l && (l += " "), l += t)
                        } else
                            for (t in r) r[t] && (l && (l += " "), l += t);
                    return l
                }(e)) && (t && (t += " "), t += r);
                return t
            }
        }
    }
]);