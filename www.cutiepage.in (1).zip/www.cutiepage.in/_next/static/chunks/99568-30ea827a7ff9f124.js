"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [99568], {
        4231: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = {
                formatUrl: function() {
                    return i
                },
                formatWithValidation: function() {
                    return c
                },
                urlObjectKeys: function() {
                    return l
                }
            };
            for (var o in n) Object.defineProperty(t, o, {
                enumerable: !0,
                get: n[o]
            });
            let u = r(21512)._(r(95685)),
                a = /https?|ftp|gopher|file/;

            function i(e) {
                let {
                    auth: t,
                    hostname: r
                } = e, n = e.protocol || "", o = e.pathname || "", i = e.hash || "", l = e.query || "", c = !1;
                t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? c = t + e.host : r && (c = t + (~r.indexOf(":") ? `[${r}]` : r), e.port && (c += ":" + e.port)), l && "object" == typeof l && (l = String(u.urlQueryToSearchParams(l)));
                let f = e.search || l && `?${l}` || "";
                return n && !n.endsWith(":") && (n += ":"), e.slashes || (!n || a.test(n)) && !1 !== c ? (c = "//" + (c || ""), o && "/" !== o[0] && (o = "/" + o)) : c || (c = ""), i && "#" !== i[0] && (i = "#" + i), f && "?" !== f[0] && (f = "?" + f), o = o.replace(/[?#]/g, encodeURIComponent), f = f.replace("#", "%23"), `${n}${c}${o}${f}${i}`
            }
            let l = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

            function c(e) {
                return i(e)
            }
        },
        50957: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = {
                DecodeError: function() {
                    return g
                },
                MiddlewareNotFoundError: function() {
                    return P
                },
                MissingStaticPage: function() {
                    return v
                },
                NormalizeError: function() {
                    return m
                },
                PageNotFoundError: function() {
                    return b
                },
                SP: function() {
                    return h
                },
                ST: function() {
                    return y
                },
                WEB_VITALS: function() {
                    return o
                },
                execOnce: function() {
                    return u
                },
                getDisplayName: function() {
                    return f
                },
                getLocationOrigin: function() {
                    return l
                },
                getURL: function() {
                    return c
                },
                isAbsoluteUrl: function() {
                    return i
                },
                isResSent: function() {
                    return s
                },
                loadGetInitialProps: function() {
                    return d
                },
                normalizeRepeatedSlashes: function() {
                    return p
                },
                stringifyError: function() {
                    return _
                }
            };
            for (var n in r) Object.defineProperty(t, n, {
                enumerable: !0,
                get: r[n]
            });
            let o = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];

            function u(e) {
                let t, r = !1;
                return (...n) => (r || (r = !0, t = e(...n)), t)
            }
            let a = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
                i = e => a.test(e);

            function l() {
                let {
                    protocol: e,
                    hostname: t,
                    port: r
                } = window.location;
                return `${e}//${t}${r?":"+r:""}`
            }

            function c() {
                let {
                    href: e
                } = window.location, t = l();
                return e.substring(t.length)
            }

            function f(e) {
                return "string" == typeof e ? e : e.displayName || e.name || "Unknown"
            }

            function s(e) {
                return e.finished || e.headersSent
            }

            function p(e) {
                let t = e.split("?");
                return t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (t[1] ? `?${t.slice(1).join("?")}` : "")
            }
            async function d(e, t) {
                let r = t.res || t.ctx && t.ctx.res;
                if (!e.getInitialProps) return t.ctx && t.Component ? {
                    pageProps: await d(t.Component, t.ctx)
                } : {};
                let n = await e.getInitialProps(t);
                if (r && s(r)) return n;
                if (!n) throw Object.defineProperty(Error(`"${f(e)}.getInitialProps()" should resolve to an object. But found "${n}" instead.`), "__NEXT_ERROR_CODE", {
                    value: "E1025",
                    enumerable: !1,
                    configurable: !0
                });
                return n
            }
            let h = "u" > typeof performance,
                y = h && ["mark", "measure", "getEntriesByName"].every(e => "function" == typeof performance[e]);
            class g extends Error {}
            class m extends Error {}
            class b extends Error {
                constructor(e) {
                    super(), this.code = "ENOENT", this.name = "PageNotFoundError", this.message = `Cannot find module for page: ${e}`
                }
            }
            class v extends Error {
                constructor(e, t) {
                    super(), this.message = `Failed to load static file for page: ${e} ${t}`
                }
            }
            class P extends Error {
                constructor() {
                    super(), this.code = "ENOENT", this.message = "Cannot find the middleware module"
                }
            }

            function _(e) {
                return JSON.stringify({
                    message: e.message,
                    stack: e.stack
                })
            }
        },
        74662: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "errorOnce", {
                enumerable: !0,
                get: function() {
                    return r
                }
            });
            let r = e => {}
        },
        77994: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "isLocalURL", {
                enumerable: !0,
                get: function() {
                    return u
                }
            });
            let n = r(50957),
                o = r(91212);

            function u(e) {
                if (!(0, n.isAbsoluteUrl)(e)) return !0;
                try {
                    let t = (0, n.getLocationOrigin)(),
                        r = new URL(e, t);
                    return r.origin === t && (0, o.hasBasePath)(r.pathname)
                } catch (e) {
                    return !1
                }
            }
        },
        80160: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "useMergedRef", {
                enumerable: !0,
                get: function() {
                    return o
                }
            });
            let n = r(1521);

            function o(e, t) {
                let r = (0, n.useRef)(null),
                    o = (0, n.useRef)(null);
                return (0, n.useCallback)(n => {
                    if (null === n) {
                        let e = r.current;
                        e && (r.current = null, e());
                        let t = o.current;
                        t && (o.current = null, t())
                    } else e && (r.current = u(e, n)), t && (o.current = u(t, n))
                }, [e, t])
            }

            function u(e, t) {
                if ("function" != typeof e) return e.current = t, () => {
                    e.current = null
                }; {
                    let r = e(t);
                    return "function" == typeof r ? r : () => e(null)
                }
            }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        95685: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = {
                assign: function() {
                    return i
                },
                searchParamsToUrlQuery: function() {
                    return o
                },
                urlQueryToSearchParams: function() {
                    return a
                }
            };
            for (var n in r) Object.defineProperty(t, n, {
                enumerable: !0,
                get: r[n]
            });

            function o(e) {
                let t = {};
                for (let [r, n] of e.entries()) {
                    let e = t[r];
                    void 0 === e ? t[r] = n : Array.isArray(e) ? e.push(n) : t[r] = [e, n]
                }
                return t
            }

            function u(e) {
                return "string" == typeof e ? e : ("number" != typeof e || isNaN(e)) && "boolean" != typeof e ? "" : String(e)
            }

            function a(e) {
                let t = new URLSearchParams;
                for (let [r, n] of Object.entries(e))
                    if (Array.isArray(n))
                        for (let e of n) t.append(r, u(e));
                    else t.set(r, u(n));
                return t
            }

            function i(e, ...t) {
                for (let r of t) {
                    for (let t of r.keys()) e.delete(t);
                    for (let [t, n] of r.entries()) e.append(t, n)
                }
                return e
            }
        },
        99568: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = {
                default: function() {
                    return m
                },
                useLinkStatus: function() {
                    return v
                }
            };
            for (var o in n) Object.defineProperty(t, o, {
                enumerable: !0,
                get: n[o]
            });
            let u = r(21512),
                a = r(73365),
                i = u._(r(1521)),
                l = r(4231),
                c = r(96745),
                f = r(80160),
                s = r(50957),
                p = r(77675);
            r(30208);
            let d = r(70892),
                h = r(67808),
                y = r(77994),
                g = r(96697);

            function m(e) {
                var t, n;
                let o, u, m, [v, P] = (0, i.useOptimistic)(h.IDLE_LINK_STATUS),
                    _ = (0, i.useRef)(null),
                    {
                        href: E,
                        as: O,
                        children: S,
                        prefetch: j = null,
                        passHref: C,
                        replace: T,
                        shallow: N,
                        scroll: R,
                        onClick: L,
                        onMouseEnter: k,
                        onTouchStart: x,
                        legacyBehavior: w = !1,
                        onNavigate: M,
                        transitionTypes: $,
                        ref: A,
                        unstable_dynamicOnHover: I,
                        ...U
                    } = e;
                o = S, w && ("string" == typeof o || "number" == typeof o) && (o = (0, a.jsx)("a", {
                    children: o
                }));
                let F = i.default.useContext(c.AppRouterContext),
                    D = !1 !== j,
                    B = !1 !== j ? null === (n = j) || "auto" === n ? g.FetchStrategy.PPR : g.FetchStrategy.Full : g.FetchStrategy.PPR,
                    K = "string" == typeof(t = O || E) ? t : (0, l.formatUrl)(t);
                if (w) {
                    if (o ? .$$typeof === Symbol.for("react.lazy")) throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."), "__NEXT_ERROR_CODE", {
                        value: "E863",
                        enumerable: !1,
                        configurable: !0
                    });
                    u = i.default.Children.only(o)
                }
                let z = w ? u && "object" == typeof u && u.ref : A,
                    Q = i.default.useCallback(e => (null !== F && (_.current = (0, h.mountLinkInstance)(e, K, F, B, D, P)), () => {
                        _.current && ((0, h.unmountLinkForCurrentNavigation)(_.current), _.current = null), (0, h.unmountPrefetchableInstance)(e)
                    }), [D, K, F, B, P]),
                    W = {
                        ref: (0, f.useMergedRef)(Q, z),
                        onClick(e) {
                            w || "function" != typeof L || L(e), w && u.props && "function" == typeof u.props.onClick && u.props.onClick(e), !F || e.defaultPrevented || function(e, t, n, o, u, a, l) {
                                {
                                    let c, {
                                        nodeName: f
                                    } = e.currentTarget;
                                    if ("A" === f.toUpperCase() && ((c = e.currentTarget.getAttribute("target")) && "_self" !== c || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which) || e.currentTarget.hasAttribute("download")) return;
                                    if (!(0, y.isLocalURL)(t)) {
                                        o && (e.preventDefault(), location.replace(t));
                                        return
                                    }
                                    if (e.preventDefault(), a) {
                                        let e = !1;
                                        if (a({
                                                preventDefault: () => {
                                                    e = !0
                                                }
                                            }), e) return
                                    }
                                    let {
                                        dispatchNavigateAction: s
                                    } = r(97488);
                                    i.default.startTransition(() => {
                                        s(t, o ? "replace" : "push", !1 === u ? d.ScrollBehavior.NoScroll : d.ScrollBehavior.Default, n.current, l)
                                    })
                                }
                            }(e, K, _, T, R, M, $)
                        },
                        onMouseEnter(e) {
                            w || "function" != typeof k || k(e), w && u.props && "function" == typeof u.props.onMouseEnter && u.props.onMouseEnter(e), F && D && (0, h.onNavigationIntent)(e.currentTarget, !0 === I)
                        },
                        onTouchStart: function(e) {
                            w || "function" != typeof x || x(e), w && u.props && "function" == typeof u.props.onTouchStart && u.props.onTouchStart(e), F && D && (0, h.onNavigationIntent)(e.currentTarget, !0 === I)
                        }
                    };
                return (0, s.isAbsoluteUrl)(K) ? W.href = K : w && !C && ("a" !== u.type || "href" in u.props) || (W.href = (0, p.addBasePath)(K)), m = w ? i.default.cloneElement(u, W) : (0, a.jsx)("a", { ...U,
                    ...W,
                    children: o
                }), (0, a.jsx)(b.Provider, {
                    value: v,
                    children: m
                })
            }
            r(74662);
            let b = (0, i.createContext)(h.IDLE_LINK_STATUS),
                v = () => (0, i.useContext)(b);
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        }
    }
]);