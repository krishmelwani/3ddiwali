"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [43636], {
        5595: (e, t, n) => {
            n.d(t, {
                BE: () => l,
                N8: () => c,
                dG: () => o,
                sI: () => s
            });
            let i = Date.parse("2026-07-30T00:00:00Z") - 198e5,
                a = Date.parse("2026-07-30T23:59:59Z") - 198e5,
                r = Date.parse("2026-07-24T00:00:00Z") - 198e5,
                s = {
                    announcement: "Friendship Day is 30 July. Pages ready in 30 seconds",
                    heroBadge: "Friendship Day \xb7 30 July",
                    heroTitle: "Send your best friend a page, not a story repost.",
                    heroPoints: ["Their photos, your words, your song", "Ready to send in 30 seconds", "One private link, password protected", "Lifetime validity (pay once)"],
                    heroPrimaryCta: "See Friendship Day pages",
                    heroSecondaryCta: "How it works",
                    bannerEyebrow: "Friendship Day 2026",
                    bannerTitle: "Send your best friend a page, not a story repost",
                    bannerBody: "Friendship Day lands Thursday 30 July. Pick a design, add your photos and your song, and share one private link before the day arrives.",
                    countdownLabel: "Friendship Day in",
                    countdownEndedLabel: "Happy Friendship Day",
                    primaryCta: "See Friendship Day pages",
                    secondaryCta: "Preview the design",
                    sectionEyebrow: "Friendship Day picks",
                    sectionTitle: "Made for the people who put up with you",
                    modalHeadline: "Friendship Day picks",
                    modalSubline: "Four pages worth sending on 30 July. Tap one to preview it live.",
                    pageTitle: "Four pages worth sending on Friendship Day",
                    pageIntro: "Hand-picked for 30 July. Open any one to preview it live, personalise it with your photos and words, and share a private link. Or browse the full catalogue if none of these fit.",
                    pageAllCta: "Browse all templates"
                };

            function o(e) {
                return e >= r && e <= a
            }

            function l(e) {
                return Math.max(0, i - e)
            }

            function c(e) {
                let t = Math.max(0, Math.floor(e / 1e3));
                return {
                    days: Math.floor(t / 86400),
                    hours: Math.floor(t % 86400 / 3600),
                    minutes: Math.floor(t % 3600 / 60),
                    seconds: t % 60
                }
            }
        },
        6238: (e, t, n) => {
            n.d(t, {
                h: () => h
            });
            var i = n(1521),
                a = n(41786);
            let r = null,
                s = new Set,
                o = !1,
                l = !1;

            function c(e) {
                if (r !== e)
                    for (let t of (r = e, s)) t()
            }

            function d() {
                try {
                    return (0, a.hO)((0, a.MB)(document.cookie))
                } catch {
                    return !0
                }
            }

            function u() {
                l || (l = !0, Promise.all([n.e(74339), n.e(7998), n.e(16937), n.e(21381), n.e(63529)]).then(n.bind(n, 11062)).then(({
                    createSupabaseBrowserClient: e
                }) => {
                    let t;
                    try {
                        t = e()
                    } catch {
                        c(!1);
                        return
                    }
                    t.auth.getSession().then(({
                        data: e
                    }) => c(!!e.session)), t.auth.onAuthStateChange((e, t) => c(!!t))
                }).catch(() => {
                    l = !1, c(!1)
                }))
            }

            function p() {
                "hidden" !== document.visibilityState && d() && u()
            }

            function f(e) {
                return s.add(e), o ? !l && d() && u() : (o = !0, d() ? u() : queueMicrotask(() => {
                    l || c(!1)
                }), window.addEventListener("focus", p), document.addEventListener("visibilitychange", p)), () => {
                    s.delete(e)
                }
            }

            function h() {
                return {
                    isAuthed: (0, i.useSyncExternalStore)(f, () => r, () => null)
                }
            }
        },
        9411: (e, t, n) => {
            n.d(t, {
                A: () => i
            });
            let i = (0, n(96296).A)("arrow-up-right", [
                ["path", {
                    d: "M7 7h10v10",
                    key: "1tivn9"
                }],
                ["path", {
                    d: "M7 17 17 7",
                    key: "1vkiza"
                }]
            ])
        },
        38277: (e, t, n) => {
            n.d(t, {
                Hz: () => d,
                Ur: () => j
            });
            var i = n(73365),
                a = n(1521),
                r = n(99568),
                s = n.n(r),
                o = n(69580),
                l = n(54872);
            let c = "gifts:cart-updated";

            function d() {
                window.dispatchEvent(new CustomEvent(c))
            }
            let u = "gifts:cart-count",
                p = 0,
                f = 0,
                h = null,
                m = new Set,
                x = !1;

            function y(e) {
                return m.add(e), () => m.delete(e)
            }

            function b() {
                if (!x && (x = !0, 0 === p)) {
                    let e = function() {
                        try {
                            let e = window.sessionStorage.getItem(u);
                            if (!e) return null;
                            let t = JSON.parse(e);
                            if ("number" == typeof t ? .value && "number" == typeof t ? .at) return t
                        } catch {}
                        return null
                    }();
                    e && (p = e.value, f = e.at)
                }
                return p
            }

            function v() {
                return 0
            }

            function g(e) {
                let t = Date.now();
                return !e && t - f < 6e4 ? Promise.resolve() : h || (h = (async () => {
                    try {
                        let e = await fetch("/api/gifts/cart?count=1", {
                            cache: "no-store"
                        });
                        if (!e.ok) return;
                        let t = await e.json().catch(() => null),
                            n = t ? .data ? .itemCount;
                        "number" == typeof n && function(e, t) {
                            p = e, f = t;
                            try {
                                window.sessionStorage.setItem(u, JSON.stringify({
                                    value: e,
                                    at: t
                                }))
                            } catch {}
                            m.forEach(e => e())
                        }(n, Date.now())
                    } catch {} finally {
                        h = null
                    }
                })())
            }

            function w({
                count: e,
                className: t
            }) {
                return 0 === e ? null : (0, i.jsx)("span", {
                    className: (0, l.cn)("pointer-events-none absolute flex min-w-[16px] items-center justify-center rounded-full bg-cp-primary px-1 py-px text-[10px] font-bold leading-[14px] text-white", t),
                    "aria-hidden": !0,
                    children: e > 9 ? "9+" : e
                })
            }

            function j({
                variant: e,
                size: t = "md",
                collapsed: n = !1,
                onNavigate: r
            }) {
                let d, u = (d = (0, a.useSyncExternalStore)(y, b, v), (0, a.useEffect)(() => {
                        g(!1);
                        let e = () => void g(!0);
                        return window.addEventListener(c, e), () => window.removeEventListener(c, e)
                    }, []), d),
                    p = u > 0 ? `Cart, ${u} item${1===u?"":"s"}` : "Cart";
                if ("header" === e) return (0, i.jsxs)(s(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    "aria-label": p,
                    onClick: r,
                    className: "relative inline-flex size-10 items-center justify-center rounded-full text-cp-ink/80 transition-colors duration-150 hover:bg-white/70 hover:text-cp-ink",
                    children: [(0, i.jsx)(o.A, {
                        className: "size-[21px]",
                        strokeWidth: 1.9,
                        "aria-hidden": !0
                    }), (0, i.jsx)(w, {
                        count: u,
                        className: "right-0.5 top-0.5"
                    })]
                });
                if ("topbar" === e) return (0, i.jsxs)(s(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    "aria-label": p,
                    className: "relative ml-auto inline-flex size-10 items-center justify-center text-cp-ink/80 transition-colors duration-150 hover:text-cp-ink",
                    children: [(0, i.jsx)(o.A, {
                        className: "size-[21px]",
                        strokeWidth: 1.9,
                        "aria-hidden": !0
                    }), (0, i.jsx)(w, {
                        count: u,
                        className: "right-0 top-0.5"
                    })]
                });
                let f = "lg" === t;
                return (0, i.jsxs)(s(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    onClick: r,
                    title: n ? p : void 0,
                    "aria-label": n ? p : void 0,
                    className: (0, l.cn)("group flex items-center rounded-xl transition-colors duration-150", "font-medium text-cp-ink/80 hover:bg-cp-subtle hover:text-cp-ink", n ? "justify-center px-0 py-3" : f ? "gap-4 px-4 py-3.5 text-[16px]" : "gap-3.5 px-3.5 py-3 text-[14px]"),
                    children: [(0, i.jsxs)("span", {
                        className: "relative shrink-0",
                        children: [(0, i.jsx)(o.A, {
                            className: (0, l.cn)("shrink-0 text-cp-muted", f ? "size-[20px]" : "size-[17px]"),
                            strokeWidth: 1.6,
                            "aria-hidden": !0
                        }), n ? (0, i.jsx)(w, {
                            count: u,
                            className: "-right-2 -top-1.5"
                        }) : null]
                    }), (0, i.jsx)("span", {
                        className: (0, l.cn)("truncate", n && "hidden"),
                        children: "Cart"
                    }), !n && u > 0 ? (0, i.jsx)("span", {
                        className: "ml-auto inline-flex min-w-[20px] items-center justify-center rounded-full bg-cp-primary-soft px-1.5 py-0.5 text-[11px] font-semibold text-cp-primary",
                        "aria-label": `${u} item${1===u?"":"s"} in cart`,
                        children: u > 9 ? "9+" : u
                    }) : null]
                })
            }
        },
        43636: (e, t, n) => {
            n.d(t, {
                SiteHeaderClient: () => N
            });
            var i = n(73365),
                a = n(87608),
                r = n.n(a),
                s = n(1521),
                o = n(99568),
                l = n.n(o),
                c = n(29717),
                d = n(9411),
                u = n(17552),
                p = n(38277),
                f = n(26752),
                h = n(5595),
                m = n(99195),
                x = n(6238),
                y = n(21381),
                b = n(54872);
            let v = /[\u0980-\u09FF]/,
                g = "New: Cutiepage Games \xb7 Free couple games, play now \u2192";

            function w() {
                return () => {}
            }

            function j() {
                return (0, m.Nu)(Date.now()) ? .look === "festive"
            }
            let k = [f.O.header.announcementBar.line1, f.O.header.announcementBar.line2, f.O.header.announcementBar.line3].filter(Boolean);

            function N({
                showCart: e = !1,
                announcements: t
            }) {
                let [n, a] = (0, s.useState)(!1), [o, v] = (0, s.useState)(!1), [C, z] = (0, s.useState)(!1), {
                    isAuthed: D
                } = (0, x.h)(), F = (0, s.useSyncExternalStore)(w, j, j), _ = (0, c.usePathname)();
                (0, s.useEffect)(() => {
                    z((0, h.dG)(Date.now()));
                    let e = window.setInterval(() => z((0, h.dG)(Date.now())), 6e4);
                    return () => window.clearInterval(e)
                }, []);
                let M = [...t ? ? k],
                    L = [...F ? ["\u2726 Shubho Pujo \xb7 Happy Navratri \u2726"] : [], g, ...C ? [h.sI.announcement] : [], ...M],
                    O = D ? (0, y.ce)("/dashboard") : "/login",
                    A = D ? f.O.header.dashboardCta : f.O.header.loginCta;
                (0, s.useEffect)(() => {
                    let e = window.scrollY,
                        t = !1,
                        n = () => {
                            t = !1;
                            let n = window.scrollY;
                            if ("true" !== document.documentElement.dataset.autohideHeader) {
                                a(!1), e = n;
                                return
                            }
                            let i = n - e;
                            Math.abs(i) > 6 && (a(i > 0 && n > 120), e = n)
                        },
                        i = () => {
                            t || (t = !0, window.requestAnimationFrame(n))
                        };
                    return n(), window.addEventListener("scroll", i, {
                        passive: !0
                    }), () => window.removeEventListener("scroll", i)
                }, []), (0, s.useEffect)(() => (o ? document.body.style.overflow = "hidden" : document.body.style.overflow = "", () => {
                    document.body.style.overflow = ""
                }), [o]), (0, s.useEffect)(() => {
                    if (!o) return;
                    let e = e => {
                        "Escape" === e.key && v(!1)
                    };
                    return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e)
                }, [o]);
                let I = e => "/" === e ? "/" === _ : _ === e || _.startsWith(`${e}/`),
                    B = (0, s.useRef)(null),
                    [H, P] = (0, s.useState)(null),
                    T = f.O.header.navItems.findIndex(e => I(e.href)),
                    W = H ? ? (T >= 0 ? T : null),
                    [$, J] = (0, s.useState)(null),
                    [G, q] = (0, s.useState)(!1);
                return (0, s.useLayoutEffect)(() => {
                    let e = () => {
                        let e = null === W ? null : B.current ? .children[W];
                        J(e && e.offsetWidth ? e.offsetLeft + e.offsetWidth / 2 : null)
                    };
                    return e(), document.fonts ? .ready.then(e), window.addEventListener("resize", e), () => window.removeEventListener("resize", e)
                }, [W]), (0, s.useEffect)(() => {
                    if (null === $ || G) return;
                    let e = requestAnimationFrame(() => q(!0));
                    return () => cancelAnimationFrame(e)
                }, [$, G]), (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)("header", {
                        className: (0, b.cn)("fixed top-0 right-0 left-0 z-50 transition-transform duration-300 ease-out motion-reduce:transition-none", n && !o ? "-translate-y-full" : "translate-y-0"),
                        children: [(0, i.jsxs)("div", {
                            className: "jsx-182ed0d040d28b51 relative overflow-hidden bg-[linear-gradient(90deg,var(--cp-warning),var(--cp-pastel-butter),var(--cp-warning))] text-cp-night",
                            children: [(0, i.jsx)("div", {
                                className: "jsx-182ed0d040d28b51 mx-auto flex min-h-8 max-w-7xl items-center justify-center px-3 py-1.5 text-center sm:px-6 sm:py-0",
                                children: (0, i.jsx)(S, {
                                    rotation: L
                                })
                            }), (0, i.jsx)(r(), {
                                id: "182ed0d040d28b51",
                                children: "@keyframes announcement-fade{0%{opacity:0}100%{opacity:1}}"
                            })]
                        }), (0, i.jsx)("div", {
                            className: "cp-frosted border-b border-cp-line bg-cp-bg/90 backdrop-blur-xl",
                            children: (0, i.jsxs)("div", {
                                className: "relative mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 pr-2 pl-4 sm:pl-5",
                                children: [(0, i.jsx)(u.R, {
                                    size: "sm",
                                    showLogo: !0,
                                    withWordmark: !0,
                                    tone: "dark"
                                }), (0, i.jsxs)("nav", {
                                    ref: B,
                                    "aria-label": "Main",
                                    onMouseLeave: () => P(null),
                                    className: "absolute left-1/2 hidden -translate-x-1/2 items-center gap-1 lg:flex",
                                    children: [f.O.header.navItems.map((e, t) => {
                                        let n = "badge" in e ? e.badge : void 0,
                                            a = I(e.href);
                                        return (0, i.jsxs)(l(), {
                                            href: e.href,
                                            "aria-current": a ? "page" : void 0,
                                            onMouseEnter: () => P(t),
                                            onFocus: () => P(t),
                                            onBlur: () => P(null),
                                            className: (0, b.cn)("relative inline-flex h-9 items-center gap-1.5 px-2.5 text-[14px] xl:px-3.5 font-medium whitespace-nowrap transition-colors duration-150", e.xlOnly && "hidden xl:inline-flex", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", a ? "text-cp-ink" : "text-cp-muted hover:text-cp-ink"),
                                            children: [e.label, n ? (0, i.jsx)("span", {
                                                className: "rounded-md bg-cp-primary-soft px-1.5 py-0.5 text-[10px] font-semibold text-cp-primary",
                                                children: n
                                            }) : null]
                                        }, e.href)
                                    }), (0, i.jsx)("span", {
                                        "aria-hidden": !0,
                                        style: {
                                            translate: `${($??0)-2}px 0`
                                        },
                                        className: (0, b.cn)("pointer-events-none absolute bottom-0 left-0 size-1 rounded-full", G && "transition-[translate,opacity,background-color] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none", null === $ ? "opacity-0" : "opacity-100", null !== H && H !== T ? "bg-cp-primary/50" : "bg-cp-primary")
                                    })]
                                }), (0, i.jsxs)("div", {
                                    className: "hidden items-center gap-1.5 lg:flex",
                                    children: [e ? (0, i.jsx)(p.Ur, {
                                        variant: "header"
                                    }) : null, (0, i.jsx)(E, {}), (0, i.jsx)(l(), {
                                        href: O,
                                        prefetch: !1,
                                        className: (0, b.cn)("inline-flex h-10 items-center rounded-full px-3 text-[14px] font-medium xl:px-4.5 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", "text-cp-ink/80 hover:text-cp-ink"),
                                        children: A
                                    }), (0, i.jsxs)(l(), {
                                        href: "/products",
                                        className: "group inline-flex h-10 items-center gap-2.5 rounded-full bg-cp-primary pr-1 pl-4.5 text-[14px] font-semibold text-white transition-colors hover:bg-cp-primary-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                                        children: [f.O.header.primaryCta, (0, i.jsx)(d.A, {
                                            className: "size-8 rounded-full bg-white p-1.5 text-cp-primary transition-transform duration-200 group-hover:rotate-45 motion-reduce:transition-none",
                                            strokeWidth: 2.25,
                                            "aria-hidden": !0
                                        })]
                                    })]
                                }), (0, i.jsxs)("div", {
                                    className: "flex items-center gap-1 lg:hidden",
                                    children: [(0, i.jsx)(E, {}), e ? (0, i.jsx)(p.Ur, {
                                        variant: "header"
                                    }) : null, (0, i.jsxs)("button", {
                                        type: "button",
                                        onClick: () => v(!o),
                                        "aria-label": f.O.header.mobileMenuLabel,
                                        "aria-expanded": o,
                                        className: "relative z-50 flex size-10 flex-col items-center justify-center gap-[5px] rounded-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                                        children: [(0, i.jsx)("span", {
                                            className: (0, b.cn)("h-px w-[19px] bg-cp-ink transition-all duration-300 motion-reduce:transition-none", o && "translate-y-[6px] rotate-45")
                                        }), (0, i.jsx)("span", {
                                            className: (0, b.cn)("h-px w-[19px] bg-cp-ink transition-all duration-300 motion-reduce:transition-none", o && "opacity-0")
                                        }), (0, i.jsx)("span", {
                                            className: (0, b.cn)("h-px w-[19px] bg-cp-ink transition-all duration-300 motion-reduce:transition-none", o && "-translate-y-[6px] -rotate-45")
                                        })]
                                    })]
                                })]
                            })
                        })]
                    }), (0, i.jsxs)("div", {
                        className: (0, b.cn)("fixed inset-0 z-[45] bg-cp-bg transition-opacity duration-300 motion-reduce:transition-none lg:hidden", o ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"),
                        "aria-hidden": !o || void 0,
                        inert: !o,
                        children: [(0, i.jsx)("div", {
                            "aria-hidden": !0,
                            className: "pointer-events-none absolute inset-0 bg-[radial-gradient(28rem_22rem_at_100%_0%,rgba(196,181,253,0.45),transparent_65%),radial-gradient(24rem_20rem_at_0%_45%,rgba(187,247,208,0.35),transparent_65%),radial-gradient(26rem_20rem_at_100%_100%,rgba(255,213,186,0.4),transparent_65%)]"
                        }), (0, i.jsx)("div", {
                            className: "relative flex h-full flex-col overflow-y-auto px-5 pt-24 pb-8",
                            children: (0, i.jsxs)("div", {
                                className: "flex flex-1 flex-col justify-center py-6",
                                children: [(0, i.jsx)("nav", {
                                    "aria-label": "Main",
                                    className: "flex flex-col rounded-3xl bg-cp-bg/85 px-3 py-1 shadow-cp-float ring-1 ring-cp-line",
                                    children: f.O.header.navItems.map((e, t) => {
                                        let n = "badge" in e ? e.badge : void 0,
                                            a = I(e.href);
                                        return (0, i.jsxs)(l(), {
                                            href: e.href,
                                            prefetch: !1,
                                            onClick: () => v(!1),
                                            "aria-current": a ? "page" : void 0,
                                            className: (0, b.cn)("group flex items-baseline gap-3 border-b border-cp-line px-2 py-3.5 transition-[translate,opacity] duration-500 last:border-b-0 motion-reduce:transition-none", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", o ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"),
                                            style: {
                                                transitionDelay: o ? `${50*t}ms` : "0ms"
                                            },
                                            children: [(0, i.jsx)("span", {
                                                "aria-hidden": !0,
                                                className: "w-5 font-display text-xs text-cp-muted italic",
                                                children: String(t + 1).padStart(2, "0")
                                            }), (0, i.jsx)("span", {
                                                className: (0, b.cn)("flex-1 text-[17px] font-medium tracking-tight transition-colors duration-200", a ? "text-cp-primary" : "text-cp-ink group-active:text-cp-primary"),
                                                children: e.label
                                            }), n ? (0, i.jsx)("span", {
                                                className: "rounded-full bg-cp-primary-soft px-2 py-0.5 text-[10px] font-semibold text-cp-primary",
                                                children: n
                                            }) : null, (0, i.jsx)(d.A, {
                                                "aria-hidden": !0,
                                                strokeWidth: 2,
                                                className: (0, b.cn)("size-4 self-center transition-transform duration-200 group-active:rotate-45", a ? "text-cp-primary" : "text-cp-muted")
                                            })]
                                        }, e.href)
                                    })
                                }), (0, i.jsxs)("div", {
                                    className: (0, b.cn)("mt-5 grid grid-cols-2 gap-3 transition-[translate,opacity] duration-500 motion-reduce:transition-none", o ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"),
                                    style: {
                                        transitionDelay: o ? `${50*f.O.header.navItems.length}ms` : "0ms"
                                    },
                                    children: [(0, i.jsx)(l(), {
                                        href: O,
                                        prefetch: !1,
                                        onClick: () => v(!1),
                                        className: "inline-flex h-13 items-center justify-center rounded-full bg-cp-subtle px-5 text-[15px] font-semibold text-cp-ink ring-1 ring-cp-line focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                                        children: A
                                    }), (0, i.jsxs)(l(), {
                                        href: "/products",
                                        prefetch: !1,
                                        onClick: () => v(!1),
                                        className: "inline-flex h-13 items-center justify-center gap-2 rounded-full bg-cp-primary pr-1.5 pl-5 text-[15px] font-semibold text-white transition-transform duration-300 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                                        children: [f.O.header.primaryCta, (0, i.jsx)(d.A, {
                                            "aria-hidden": !0,
                                            className: "ml-auto size-10 rounded-full bg-white p-2.5 text-cp-primary",
                                            strokeWidth: 2.25
                                        })]
                                    })]
                                }), (0, i.jsx)("p", {
                                    className: "mt-4 text-center text-[12.5px] text-cp-muted",
                                    children: m.uy.trustLine
                                })]
                            })
                        })]
                    })]
                })
            }

            function E() {
                return (0, i.jsxs)(l(), {
                    href: "/plus",
                    prefetch: !1,
                    className: "inline-flex h-8 items-center rounded-full bg-cp-primary-soft px-3 text-[13px] font-semibold whitespace-nowrap text-cp-primary ring-1 ring-cp-line transition-colors duration-150 hover:bg-cp-pastel-lilac focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                    children: ["Get ", (0, i.jsx)("span", {
                        className: "ml-1 font-display font-normal italic",
                        children: "Plus"
                    })]
                })
            }

            function S({
                rotation: e
            }) {
                let [t, n] = (0, s.useState)(0);
                (0, s.useEffect)(() => {
                    let t = window.setInterval(() => n(t => (t + 1) % e.length), 3500);
                    return () => window.clearInterval(t)
                }, [e.length]);
                let a = e[t % e.length],
                    r = (0, b.cn)("animate-[announcement-fade_200ms_ease-out] text-[10px] leading-[1.35] font-medium motion-reduce:animate-none sm:text-[11px]", v.test(a ? ? "") ? "text-[11px] sm:text-[12.5px]" : "tracking-[0.04em] uppercase sm:tracking-[0.13em]");
                return a === g ? (0, i.jsx)("a", {
                    href: (0, y.kH)(),
                    className: (0, b.cn)(r, "font-bold underline underline-offset-2 hover:text-cp-primary"),
                    children: a
                }, t) : (0, i.jsx)("span", {
                    className: r,
                    children: a
                }, t)
            }
        },
        69580: (e, t, n) => {
            n.d(t, {
                A: () => i
            });
            let i = (0, n(96296).A)("shopping-bag", [
                ["path", {
                    d: "M16 10a4 4 0 0 1-8 0",
                    key: "1ltviw"
                }],
                ["path", {
                    d: "M3.103 6.034h17.794",
                    key: "awc11p"
                }],
                ["path", {
                    d: "M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",
                    key: "o988cm"
                }]
            ])
        }
    }
]);