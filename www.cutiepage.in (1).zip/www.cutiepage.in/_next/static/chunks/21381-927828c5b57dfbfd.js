"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [21381], {
        21381: (t, e, n) => {
            n.d(e, {
                Ex: () => R,
                Gb: () => c,
                JE: () => T,
                Mj: () => C,
                Mz: () => S,
                QM: () => w,
                Ze: () => A,
                Zp: () => O,
                ce: () => D,
                du: () => h,
                hh: () => l,
                kH: () => P,
                rn: () => U,
                y: () => f
            });
            var _ = n(55365),
                i = n(53388),
                E = n(89651);
            let r = "dash.cutiepage.in";

            function o(t) {
                return t.split(":")[0]
            }
            let l = "cutiepage.app";

            function A(t) {
                let e = (t ? ? "").trim().split(":")[0].toLowerCase();
                return "localhost" === e || e.endsWith(".localhost")
            }
            let u = "sandbox.cutiepage.in";

            function s() {
                return E.env.CPTF_RENDER_ORIGIN ? .trim() || "https://render.cutiepage.app".trim() || void 0
            }

            function a() {
                let t = s();
                if (!t) return u;
                try {
                    let e = t.includes("://") ? t : `https://${t}`;
                    return new URL(e).hostname.toLowerCase()
                } catch {
                    return u
                }
            }

            function c() {
                let t = s();
                if (t ? .includes("://")) try {
                    return new URL(t).origin
                } catch {}
                return `https://${a()}`
            }

            function U() {
                let t = a();
                return !("cutiepage.in" === t || t.endsWith(".cutiepage.in"))
            }
            let I = "play.cutiepage.in",
                N = "/play";

            function S(t) {
                return t === N || t.startsWith(`${N}/`)
            }

            function T(t) {
                if (!t) return !1;
                let e = o(t).toLowerCase();
                return e === I || "play.localhost" === e
            }

            function L() {
                if (d(window.location.hostname)) return window.location.origin;
                try {
                    let t = new URL((0, _.jb)().NEXT_PUBLIC_APP_URL ? ? "");
                    return d(t.hostname) ? t.origin : null
                } catch {
                    return null
                }
            }

            function C(t = "/") {
                let e = L();
                return e ? `${e}${N}${"/"===t?"":t}` : `https://${I}${t}`
            }

            function P() {
                let t = L();
                return t ? `${t}/couple-games` : "https://games.cutiepage.in/"
            }

            function R(t) {
                return t === i.Un || t.startsWith(`${i.Un}/`)
            }

            function h(t) {
                if (!t) return !1;
                let e = o(t).toLowerCase();
                return e === i.m$ || e === i.r_
            }

            function p(t) {
                if (!t) return;
                let e = o(t);
                if ("localhost" === e || e.endsWith(".localhost") || /^\d+\.\d+\.\d+\.\d+$/.test(e) || ! function(t) {
                        if (!t) return !0;
                        let e = o(t).toLowerCase();
                        return !!("cutiepage.in" === e || e.endsWith(".cutiepage.in") || e === l || e.endsWith(`.${l}`) || "localhost" === e || e.endsWith(".localhost") || e.endsWith(".workers.dev") || /^\d+\.\d+\.\d+\.\d+$/.test(e) || e.startsWith("["))
                    }(e) || function(t) {
                        if (!t) return !1;
                        let e = o(t).toLowerCase();
                        return e === a() || "sandbox.localhost" === e
                    }(e)) return;
                let n = e.toLowerCase();
                if (n === l || n.endsWith(`.${l}`)) return;
                let _ = e.split(".");
                if (!(_.length < 2)) return "." + _.slice(-2).join(".")
            }

            function f(t) {
                return null == t ? function() {
                    let t = (0, _.jb)().NEXT_PUBLIC_APP_URL;
                    if (t) try {
                        return p(new URL(t).host)
                    } catch {
                        return
                    }
                }() : p(t)
            }

            function O() {
                let t = window.location.origin;
                if (!t) return `https://${r}`;
                try {
                    let e = new URL(t);
                    return e.hostname = function(t) {
                        let [e, n] = B(t), _ = t => n ? `${t}:${n}` : t;
                        return _(d(e) || e.startsWith("dash.") ? e : e.startsWith("www.") ? "dash." + e.slice(4) : e.endsWith(".cutiepage.in") ? r : "dash." + e)
                    }(e.hostname), e.origin
                } catch {
                    return `https://${r}`
                }
            }

            function B(t) {
                if (t.startsWith("[")) {
                    let e = t.indexOf("]");
                    if (-1 !== e) {
                        let n = t.slice(e + 1).replace(/^:/, "");
                        return [t.slice(0, e + 1), n || void 0]
                    }
                }
                let [e, n] = t.split(":");
                return [e, n || void 0]
            }

            function d(t) {
                return "localhost" === t || t.endsWith(".localhost") || /^\d+\.\d+\.\d+\.\d+$/.test(t) || t.startsWith("[")
            }

            function D(t) {
                let e = t.startsWith("/") ? t : `/${t}`;
                return `${O()}${e}`
            }

            function w(t) {
                let e = t || window.location.host;
                if (e) try {
                    let t = e.split(":"),
                        n = t[0],
                        _ = t[1],
                        i = function(t) {
                            let [e, n] = B(t), _ = t => n ? `${t}:${n}` : t;
                            return _("dash.localhost" === e ? "localhost" : e === r ? "www.cutiepage.in" : d(e) ? e : e.startsWith("dash.") ? "www." + e.slice(5) : e)
                        }(n),
                        E = n.includes("localhost") ? "http" : "https";
                    return `${E}://${i}${_?`:${_}`:""}`
                } catch {}
                let n = (0, _.jb)().NEXT_PUBLIC_APP_URL;
                return n || "https://www.cutiepage.in"
            }
        },
        53388: (t, e, n) => {
            n.d(e, {
                $q: () => u,
                Dw: () => s,
                Un: () => E,
                c5: () => o,
                dX: () => U,
                eM: () => l,
                kR: () => a,
                m$: () => _,
                r_: () => i,
                t: () => c,
                wZ: () => A
            }), n(89651);
            let _ = "tv.cutiepage.in",
                i = "tv.localhost",
                E = "/tv";

            function r() {
                let t;
                return "localhost" === (t = window.location.hostname.toLowerCase()) || "127.0.0.1" === t || t.endsWith(".localhost") ? window.location.origin : null
            }

            function o(t = "/") {
                return "/" === t || "" === t ? E : `${E}${t.startsWith("/")?t:`/${t}`}`
            }

            function l(t = "/") {
                let e = r();
                return e ? `${e}${o(t)}` : `https://${_}${""===t?"/":t}`
            }
            let A = 14400,
                u = 60,
                s = 10;

            function a() {
                return `${r()??"https://www.cutiepage.in"}/plus?utm_source=tv`
            }
            let c = 100,
                U = /^[a-z0-9_]{3,20}$/
        },
        55365: (t, e, n) => {
            n.d(e, {
                jb: () => o
            });
            var _ = n(19071),
                i = n(58560);
            n(89651);
            let E = _.vk(t => {
                if ("string" != typeof t || "" !== t.trim()) return t
            }, _.Yj().min(1).optional());
            _.Ik({
                NEXT_PUBLIC_APP_URL: _.Yj().url(),
                PAYMENT_CALLBACK_BASE_URL: _.Yj().url().optional(),
                NEXT_PUBLIC_SUPABASE_URL: _.Yj().url(),
                NEXT_PUBLIC_SUPABASE_ANON_KEY: E,
                NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY: E,
                SUPABASE_SERVICE_ROLE_KEY: _.Yj().min(1),
                ADMIN_USERNAME: E,
                ADMIN_PASSWORD: E,
                ADMIN_SESSION_SECRET: E,
                TEAMMATE_USERNAME: E,
                TEAMMATE_PASSWORD: E,
                RAZORPAY_KEY_ID: E,
                RAZORPAY_KEY_SECRET: E,
                RAZORPAY_WEBHOOK_SECRET: E,
                RAZORPAY_CHECKOUT_CONFIG_ID: E,
                RAZORPAY_PLUS_PLAN_ID: E,
                CASHFREE_APP_ID: E,
                CASHFREE_SECRET: E,
                CASHFREE_ENV: _.k5(["production", "sandbox"]).optional(),
                CASHFREE_WEBHOOK_SECRET: E,
                PAYU_MERCHANT_KEY: E,
                PAYU_MERCHANT_SALT: E,
                PAYU_MODE: _.k5(["production", "test"]).optional(),
                CRON_SECRET: E,
                UPSTASH_REDIS_REST_URL: E,
                UPSTASH_REDIS_REST_TOKEN: E,
                CLOUDINARY_CLOUD_NAME: E,
                CLOUDINARY_API_KEY: E,
                CLOUDINARY_API_SECRET: E,
                CLOUDINARY_UPLOAD_FOLDER: E,
                R2_ACCOUNT_ID: E,
                R2_ACCESS_KEY_ID: E,
                R2_SECRET_ACCESS_KEY: E,
                R2_BUCKET: E,
                R2_PUBLIC_BASE_URL: E,
                NEW_PROJECTS_USE_R2: _.k5(["true", "false"]).optional(),
                COMPOSED_ENGINE_ENABLED: _.k5(["true", "false"]).optional(),
                CREATOR_STUDIO_ENABLED: _.k5(["true", "false"]).optional(),
                CREATOR_PAYOUTS_ENABLED: _.k5(["true", "false"]).optional(),
                REFERRALS_ENABLED: _.k5(["true", "false"]).optional(),
                GIFTS_ENABLED: _.k5(["true", "false"]).optional(),
                CUSTOM_DOMAINS_ALLOWED_EMAILS: E,
                CUSTOM_DOMAIN_PRICE_INR: i.ai().int().positive().default(20),
                CUSTOM_DOMAINS_CF_API_TOKEN: E,
                CUSTOM_DOMAINS_CF_ZONE_ID: E,
                CPTF_RENDER_ORIGIN: E,
                BROWSER_RENDERING_API_TOKEN: E,
                NEXT_PUBLIC_META_PIXEL_ID: E,
                META_PIXEL_ID: E,
                META_DATASET_ID: E,
                META_ACCESS_TOKEN: E,
                META_TEST_EVENT_CODE: E,
                META_API_VERSION: E,
                META_DEBUG: _.k5(["true", "false"]).optional(),
                META_PURCHASE_TEMPLATE_SLUGS: E
            });
            let r = _.Ik({
                NEXT_PUBLIC_APP_URL: _.Yj().url().optional(),
                NEXT_PUBLIC_SUPABASE_URL: _.Yj().url().optional(),
                NEXT_PUBLIC_SUPABASE_ANON_KEY: E,
                NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY: E,
                NEXT_PUBLIC_META_PIXEL_ID: E,
                NEXT_PUBLIC_META_DEBUG: _.k5(["true", "false"]).optional(),
                NEXT_PUBLIC_META_CONSENT_MODE: _.k5(["implied", "explicit"]).optional()
            });

            function o() {
                let t = r.parse({
                    NEXT_PUBLIC_APP_URL: function() {
                        var t = "https://www.cutiepage.in";
                        if (!t) return;
                        let e = t.trim();
                        if (e) return new URL(/^[a-zA-Z][a-zA-Z\d+\-.]*:\/\//.test(e) ? e : `https://${e}`).origin
                    }(),
                    NEXT_PUBLIC_SUPABASE_URL: "https://accounts.cutiepage.in",
                    NEXT_PUBLIC_SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzg3NTY0NTI1LCJleHAiOjE5NDUyNDQ1MjV9._hi0D7XtuHsys4J3xHwUcZq_gMCOQeJ9cz8I_PT3Pn0",
                    NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY: "",
                    NEXT_PUBLIC_META_PIXEL_ID: "1075267798614786",
                    NEXT_PUBLIC_META_DEBUG: "false",
                    NEXT_PUBLIC_META_CONSENT_MODE: "implied"
                });
                return { ...t,
                    NEXT_PUBLIC_SUPABASE_ANON_KEY: t.NEXT_PUBLIC_SUPABASE_ANON_KEY ? ? t.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY
                }
            }
        }
    }
]);