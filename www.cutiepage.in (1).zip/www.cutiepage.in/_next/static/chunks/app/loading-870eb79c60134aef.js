(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [94209], {
        11737: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => r
            });
            var i = n(73365),
                s = n(54219);

            function r() {
                return (0, i.jsx)(s.Q, {})
            }
        },
        54219: (e, t, n) => {
            "use strict";
            n.d(t, {
                Q: () => a
            });
            var i = n(73365),
                s = n(54872),
                r = n(96331);

            function a({
                title: e = "Loading",
                subtitle: t,
                overlay: n = !1,
                visible: c = !0
            }) {
                return (0, i.jsxs)("div", {
                    role: c ? "status" : void 0,
                    "aria-hidden": !c || void 0,
                    className: (0, s.cn)("flex items-center justify-center px-6", n ? "fixed inset-0 z-[90] bg-cp-canvas/85 backdrop-blur-xl transition-opacity duration-300 ease-out starting:opacity-0 motion-reduce:transition-none" : "min-h-screen bg-cp-canvas", n && !c && "pointer-events-none opacity-0"),
                    children: [(0, i.jsxs)("div", {
                        className: (0, s.cn)("flex flex-col items-center text-center", n ? "transition-opacity duration-300 ease-out starting:opacity-0 motion-reduce:transition-none" : "animate-[cp-loader-in_240ms_ease-out_300ms_both]", n && !c && "opacity-0"),
                        children: [(0, i.jsx)(r.k, {}), (0, i.jsx)("p", {
                            className: "mt-4 max-w-[18rem] text-[14px] font-medium text-balance text-cp-muted",
                            children: e
                        }), t ? (0, i.jsx)("p", {
                            className: "mt-1 max-w-[18rem] text-[13px] leading-snug text-balance text-cp-muted/80",
                            children: t
                        }) : null]
                    }), (0, i.jsx)("style", {
                        children: "@keyframes cp-loader-in { from { opacity: 0; } to { opacity: 1; } }"
                    })]
                })
            }
        },
        54872: (e, t, n) => {
            "use strict";
            n.d(t, {
                cn: () => r
            });
            var i = n(68662),
                s = n(35490);

            function r(...e) {
                return (0, s.QP)((0, i.$)(e))
            }
        },
        87871: (e, t, n) => {
            Promise.resolve().then(n.bind(n, 11737))
        },
        96331: (e, t, n) => {
            "use strict";
            n.d(t, {
                k: () => r
            });
            var i = n(73365),
                s = n(54872);

            function r({
                className: e
            }) {
                return (0, i.jsxs)("svg", {
                    "aria-hidden": !0,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    className: (0, s.cn)("size-7 text-cp-primary motion-safe:animate-[spin_0.9s_linear_infinite]", e),
                    children: [(0, i.jsx)("circle", {
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "var(--cp-line)",
                        strokeWidth: "2",
                        vectorEffect: "non-scaling-stroke"
                    }), (0, i.jsx)("path", {
                        d: "M22 12a10 10 0 0 0-10-10",
                        stroke: "currentColor",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        vectorEffect: "non-scaling-stroke"
                    })]
                })
            }
        }
    },
    e => {
        e.O(0, [84327, 2347, 15158, 77358], () => e(e.s = 87871)), _N_E = e.O()
    }
]);