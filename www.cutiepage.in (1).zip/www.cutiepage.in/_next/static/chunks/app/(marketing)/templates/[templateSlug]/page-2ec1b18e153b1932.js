(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [50736], {
        974: (e, t, r) => {
            "use strict";
            r.d(t, {
                R: () => s
            });
            var n = r(73365),
                i = r(94296);
            let a = {
                backgroundImage: (0, i.RA)(),
                backgroundRepeat: "no-repeat",
                backgroundPosition: "center top calc(var(--preview-bar-height, 0px) + 20px)",
                backgroundSize: i.Pm + "px " + i.WH + "px"
            };

            function s({
                intensity: e = 1,
                contained: t = !1
            } = {}) {
                return (0, n.jsx)("div", {
                    "aria-hidden": !0,
                    "data-watermark": "",
                    className: t ? "pointer-events-none absolute inset-0 z-[60] select-none" : "pointer-events-none fixed inset-0 z-[9998] select-none",
                    style: { ...a,
                        opacity: e
                    }
                })
            }
        },
        1960: (e, t, r) => {
            "use strict";
            r.d(t, {
                b: () => a
            });
            var n = r(73365),
                i = r(96331);

            function a() {
                return (0, n.jsxs)("div", {
                    role: "status",
                    className: "absolute inset-0 flex flex-col items-center justify-center bg-cp-canvas px-6",
                    children: [(0, n.jsx)(i.k, {}), (0, n.jsx)("p", {
                        className: "mt-4 text-[14px] font-medium text-cp-muted",
                        children: "Loading preview"
                    })]
                })
            }
        },
        5273: (e, t, r) => {
            "use strict";
            r.d(t, {
                Ym: () => l,
                Jr: () => o,
                Du: () => c,
                gO: () => s
            });
            var n = r(9788),
                i = r(76139);
            let a = "product";

            function s(e) {
                let t;
                (0, i.sx)(n.Q7.viewContent, {
                    content_ids: [e.contentId],
                    content_type: a,
                    ...e.contentName ? {
                        content_name: e.contentName
                    } : {},
                    ...e.contentCategory ? {
                        content_category: e.contentCategory
                    } : {},
                    ..."number" == typeof e.valueInr ? {
                        value: e.valueInr,
                        currency: "INR"
                    } : {}
                }, (t = "u" > typeof crypto && "function" == typeof crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}${Math.random().toString(36).slice(2,10)}`, `viewcontent_${t}`))
            }

            function o(e) {
                var t;
                let r;
                (0, i.sx)(n.Q7.initiateCheckout, {
                    content_ids: [e.contentId],
                    content_type: a,
                    ...e.contentName ? {
                        content_name: e.contentName
                    } : {},
                    value: e.valueInr,
                    currency: "INR",
                    num_items: e.numItems ? ? 1
                }, (t = e.projectId, r = Math.floor(Date.now() / 18e5), `checkout_${t}_${r}`))
            }

            function l(e) {
                var t;
                (0, i.sx)(n.Q7.completeRegistration, {
                    content_name: "account",
                    status: !0,
                    ...e.method ? {
                        registration_method: e.method
                    } : {}
                }, (t = e.userId, `signup_${t}`))
            }

            function c(e) {
                if (Number.isFinite(e.valueInr) && !(e.valueInr <= 0)) {
                    var t;
                    (0, i.sx)(n.Q7.purchase, {
                        content_ids: [e.contentId],
                        content_type: a,
                        ...e.contentName ? {
                            content_name: e.contentName
                        } : {},
                        value: e.valueInr,
                        currency: "INR",
                        num_items: e.numItems ? ? 1
                    }, (t = e.paymentId, `purchase_${t}`))
                }
            }
        },
        9411: (e, t, r) => {
            "use strict";
            r.d(t, {
                A: () => n
            });
            let n = (0, r(96296).A)("arrow-up-right", [
                ["path", {
                    d: "M7 7h10v10",
                    key: "1tivn9"
                }],
                ["path", {
                    d: "M7 17 17 7",
                    key: "1vkiza"
                }]
            ])
        },
        13489: (e, t, r) => {
            "use strict";
            r.d(t, {
                MetaPurchase: () => s,
                MetaViewContent: () => a
            });
            var n = r(1521),
                i = r(5273);

            function a(e) {
                let t = (0, n.useRef)(!1);
                return (0, n.useEffect)(() => {
                    t.current || (t.current = !0, (0, i.gO)(e))
                }, []), null
            }

            function s(e) {
                let t = (0, n.useRef)(!1);
                return (0, n.useEffect)(() => {
                    t.current || (t.current = !0, (0, i.Du)(e))
                }, []), null
            }
        },
        21196: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                RevealSection: () => s
            });
            var n = r(73365),
                i = r(1521),
                a = r(54872);

            function s({
                children: e,
                className: t,
                delayMs: r = 0
            }) {
                let o = (0, i.useRef)(null),
                    [l, c] = (0, i.useState)(!0);
                return (0, i.useEffect)(() => {
                    let e = o.current;
                    if (!e || "u" < typeof IntersectionObserver || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
                    let t = e.getBoundingClientRect();
                    if (t.top <= .92 * window.innerHeight) return;
                    let r = 0,
                        n = window.innerWidth;
                    for (let t = e.parentElement; t; t = t.parentElement)
                        if ("visible" !== getComputedStyle(t).overflowX) {
                            let e = t.getBoundingClientRect();
                            r = Math.max(r, e.left), n = Math.min(n, e.right)
                        }
                    if (t.left >= n - 8 || t.right <= r + 8) return;
                    c(!1);
                    let i = new IntersectionObserver(e => {
                        e.some(e => e.isIntersecting) && (c(!0), i.disconnect())
                    }, {
                        rootMargin: "0px 0px -8% 0px"
                    });
                    return i.observe(e), () => i.disconnect()
                }, []), (0, n.jsx)("div", {
                    ref: o,
                    className: (0, a.cn)("reveal-section", l && "is-visible", t),
                    style: {
                        transitionDelay: `${r}ms`
                    },
                    children: e
                })
            }
        },
        23129: (e, t, r) => {
            "use strict";
            r.d(t, {
                CreatorWatermark: () => d
            });
            var n = r(73365),
                i = r(1521);
            let a = "Made in CutiePage",
                s = 'url("data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="180" height="110" viewBox="0 0 180 110"><g transform="rotate(-24 90 55)" font-family="Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif" font-size="15" font-weight="700" text-anchor="middle" dominant-baseline="middle"><text x="90" y="55" fill="none" stroke="#ffffff" stroke-opacity="0.38" stroke-width="3" stroke-linejoin="round">' + a + '</text><text x="90" y="55" fill="#1a1a1a" fill-opacity="0.26">' + a + "</text></g></svg>") + '")',
                o = "180px 110px",
                l = [
                    ["position", "absolute"],
                    ["inset", "0"],
                    ["display", "block"],
                    ["visibility", "visible"],
                    ["opacity", "1"],
                    ["pointer-events", "none"],
                    ["background-image", s],
                    ["background-repeat", "repeat"],
                    ["background-position", "center"],
                    ["background-size", o]
                ],
                c = [
                    ["position", "absolute"],
                    ["inset", "0"],
                    ["z-index", "2147483647"],
                    ["display", "block"],
                    ["visibility", "visible"],
                    ["opacity", "1"],
                    ["pointer-events", "none"]
                ];

            function d() {
                let e = (0, i.useRef)(null);
                return (0, i.useEffect)(() => {
                    let t = e.current;
                    if (!t) return;
                    let r = new MutationObserver(() => n()),
                        n = () => {
                            r.disconnect();
                            let e = t.querySelector("[data-creator-wm-tile]");
                            for (let [r, n] of (e || ((e = t.ownerDocument.createElement("div")).setAttribute("data-creator-wm-tile", ""), t.appendChild(e)), l)) e.style.setProperty(r, n, "important");
                            for (let [e, r] of c) t.style.setProperty(e, r, "important");
                            r.observe(t, {
                                childList: !0,
                                subtree: !0,
                                attributes: !0,
                                attributeFilter: ["style", "class", "hidden"]
                            })
                        };
                    n();
                    let i = t.parentElement,
                        a = null;
                    return i && (a = new MutationObserver(() => {
                        t.isConnected || i.appendChild(t), n()
                    })).observe(i, {
                        childList: !0
                    }), () => {
                        r.disconnect(), a ? .disconnect()
                    }
                }, []), (0, n.jsx)("div", {
                    ref: e,
                    "aria-hidden": !0,
                    "data-creator-wm": "",
                    className: "pointer-events-none absolute inset-0 select-none",
                    style: {
                        zIndex: 0x7fffffff
                    },
                    children: (0, n.jsx)("div", {
                        "data-creator-wm-tile": "",
                        className: "absolute inset-0",
                        style: {
                            backgroundImage: s,
                            backgroundRepeat: "repeat",
                            backgroundPosition: "center",
                            backgroundSize: o
                        }
                    })
                })
            }
        },
        26821: (e, t, r) => {
            "use strict";
            r.d(t, {
                A: () => n
            });
            let n = (0, r(96296).A)("check", [
                ["path", {
                    d: "M20 6 9 17l-5-5",
                    key: "1gmf2c"
                }]
            ])
        },
        28682: (e, t, r) => {
            "use strict";
            r.d(t, {
                A: () => n
            });
            let n = (0, r(96296).A)("arrow-left", [
                ["path", {
                    d: "m12 19-7-7 7-7",
                    key: "1l729n"
                }],
                ["path", {
                    d: "M19 12H5",
                    key: "x3x0zl"
                }]
            ])
        },
        29717: (e, t, r) => {
            "use strict";
            var n = r(21505);
            r.o(n, "usePathname") && r.d(t, {
                usePathname: function() {
                    return n.usePathname
                }
            }), r.o(n, "useRouter") && r.d(t, {
                useRouter: function() {
                    return n.useRouter
                }
            }), r.o(n, "useSearchParams") && r.d(t, {
                useSearchParams: function() {
                    return n.useSearchParams
                }
            })
        },
        38277: (e, t, r) => {
            "use strict";
            r.d(t, {
                Hz: () => d,
                Ur: () => k
            });
            var n = r(73365),
                i = r(1521),
                a = r(99568),
                s = r.n(a),
                o = r(69580),
                l = r(54872);
            let c = "gifts:cart-updated";

            function d() {
                window.dispatchEvent(new CustomEvent(c))
            }
            let u = "gifts:cart-count",
                p = 0,
                m = 0,
                f = null,
                h = new Set,
                x = !1;

            function v(e) {
                return h.add(e), () => h.delete(e)
            }

            function b() {
                if (!x && (x = !0, 0 === p)) {
                    let e = function() {
                        try {
                            let e = window.sessionStorage.getItem(u);
                            if (!e) return null;
                            let t = JSON.parse(e);
                            if ("number" == typeof t ? .value && "number" == typeof t ? .at) return t
                        } catch {}
                        return null
                    }();
                    e && (p = e.value, m = e.at)
                }
                return p
            }

            function g() {
                return 0
            }

            function y(e) {
                let t = Date.now();
                return !e && t - m < 6e4 ? Promise.resolve() : f || (f = (async () => {
                    try {
                        let e = await fetch("/api/gifts/cart?count=1", {
                            cache: "no-store"
                        });
                        if (!e.ok) return;
                        let t = await e.json().catch(() => null),
                            r = t ? .data ? .itemCount;
                        "number" == typeof r && function(e, t) {
                            p = e, m = t;
                            try {
                                window.sessionStorage.setItem(u, JSON.stringify({
                                    value: e,
                                    at: t
                                }))
                            } catch {}
                            h.forEach(e => e())
                        }(r, Date.now())
                    } catch {} finally {
                        f = null
                    }
                })())
            }

            function w({
                count: e,
                className: t
            }) {
                return 0 === e ? null : (0, n.jsx)("span", {
                    className: (0, l.cn)("pointer-events-none absolute flex min-w-[16px] items-center justify-center rounded-full bg-cp-primary px-1 py-px text-[10px] font-bold leading-[14px] text-white", t),
                    "aria-hidden": !0,
                    children: e > 9 ? "9+" : e
                })
            }

            function k({
                variant: e,
                size: t = "md",
                collapsed: r = !1,
                onNavigate: a
            }) {
                let d, u = (d = (0, i.useSyncExternalStore)(v, b, g), (0, i.useEffect)(() => {
                        y(!1);
                        let e = () => void y(!0);
                        return window.addEventListener(c, e), () => window.removeEventListener(c, e)
                    }, []), d),
                    p = u > 0 ? `Cart, ${u} item${1===u?"":"s"}` : "Cart";
                if ("header" === e) return (0, n.jsxs)(s(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    "aria-label": p,
                    onClick: a,
                    className: "relative inline-flex size-10 items-center justify-center rounded-full text-cp-ink/80 transition-colors duration-150 hover:bg-white/70 hover:text-cp-ink",
                    children: [(0, n.jsx)(o.A, {
                        className: "size-[21px]",
                        strokeWidth: 1.9,
                        "aria-hidden": !0
                    }), (0, n.jsx)(w, {
                        count: u,
                        className: "right-0.5 top-0.5"
                    })]
                });
                if ("topbar" === e) return (0, n.jsxs)(s(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    "aria-label": p,
                    className: "relative ml-auto inline-flex size-10 items-center justify-center text-cp-ink/80 transition-colors duration-150 hover:text-cp-ink",
                    children: [(0, n.jsx)(o.A, {
                        className: "size-[21px]",
                        strokeWidth: 1.9,
                        "aria-hidden": !0
                    }), (0, n.jsx)(w, {
                        count: u,
                        className: "right-0 top-0.5"
                    })]
                });
                let m = "lg" === t;
                return (0, n.jsxs)(s(), {
                    href: "/gifts/cart",
                    prefetch: !1,
                    onClick: a,
                    title: r ? p : void 0,
                    "aria-label": r ? p : void 0,
                    className: (0, l.cn)("group flex items-center rounded-xl transition-colors duration-150", "font-medium text-cp-ink/80 hover:bg-cp-subtle hover:text-cp-ink", r ? "justify-center px-0 py-3" : m ? "gap-4 px-4 py-3.5 text-[16px]" : "gap-3.5 px-3.5 py-3 text-[14px]"),
                    children: [(0, n.jsxs)("span", {
                        className: "relative shrink-0",
                        children: [(0, n.jsx)(o.A, {
                            className: (0, l.cn)("shrink-0 text-cp-muted", m ? "size-[20px]" : "size-[17px]"),
                            strokeWidth: 1.6,
                            "aria-hidden": !0
                        }), r ? (0, n.jsx)(w, {
                            count: u,
                            className: "-right-2 -top-1.5"
                        }) : null]
                    }), (0, n.jsx)("span", {
                        className: (0, l.cn)("truncate", r && "hidden"),
                        children: "Cart"
                    }), !r && u > 0 ? (0, n.jsx)("span", {
                        className: "ml-auto inline-flex min-w-[20px] items-center justify-center rounded-full bg-cp-primary-soft px-1.5 py-0.5 text-[11px] font-semibold text-cp-primary",
                        "aria-label": `${u} item${1===u?"":"s"} in cart`,
                        children: u > 9 ? "9+" : u
                    }) : null]
                })
            }
        },
        51342: (e, t, r) => {
            "use strict";
            r.d(t, {
                TrendingProductsCarousel: () => l
            });
            var n = r(73365),
                i = r(1521),
                a = r(21196),
                s = r(80304),
                o = r(54872);

            function l({
                templates: e,
                detailLabel: t,
                hidePagination: r = !1,
                hideOffer: c = !1,
                minimal: d = !1
            }) {
                let u = (0, i.useRef)(null),
                    [p, m] = (0, i.useState)(1),
                    [f, h] = (0, i.useState)(0);
                return (0, i.useEffect)(() => {
                    let e = u.current;
                    if (!e) return;
                    let t = () => Math.max(1, Math.ceil(e.scrollWidth / e.clientWidth)),
                        r = () => {
                            let r = t(),
                                n = Math.min(r - 1, Math.round(e.scrollLeft / e.clientWidth));
                            m(r), h(n)
                        };
                    r();
                    let n = () => {
                        h(Math.min(Math.max(0, t() - 1), Math.round(e.scrollLeft / e.clientWidth)))
                    };
                    e.addEventListener("scroll", n, {
                        passive: !0
                    });
                    let i = new ResizeObserver(r);
                    return i.observe(e), () => {
                        e.removeEventListener("scroll", n), i.disconnect()
                    }
                }, []), (0, n.jsxs)("div", {
                    children: [(0, n.jsx)("div", {
                        ref: u,
                        className: "no-scrollbar flex snap-x snap-mandatory gap-3 overflow-x-auto pb-3 scroll-smooth sm:gap-4",
                        "aria-label": "Trending products",
                        children: e.map((e, r) => (0, n.jsx)("div", {
                            className: "flex min-w-0 shrink-0 snap-start basis-[82%] sm:basis-[calc((100%-1rem)/2)] md:basis-[calc((100%-2rem)/3)] lg:basis-[calc((100%-3rem)/4)]",
                            children: (0, n.jsx)(a.RevealSection, {
                                className: "h-full w-full",
                                delayMs: 80 + 35 * r,
                                children: (0, n.jsx)(s.TemplateCard, {
                                    template: e,
                                    detailLabel: t,
                                    hideOffer: c,
                                    minimal: d,
                                    compactOnDesktop: !0
                                })
                            })
                        }, e.id))
                    }), p > 1 && !r ? (0, n.jsx)("div", {
                        className: "mt-6 flex items-center justify-center gap-2",
                        "aria-label": "Trending products pages",
                        children: Array.from({
                            length: p
                        }, (e, t) => {
                            let r = t === f;
                            return (0, n.jsx)("button", {
                                type: "button",
                                "aria-label": `Go to trending products page ${t+1}`,
                                "aria-pressed": r,
                                onClick: () => {
                                    let e;
                                    (e = u.current) && e.scrollTo({
                                        left: e.clientWidth * t,
                                        behavior: "smooth"
                                    })
                                },
                                className: (0, o.cn)("h-2 rounded-full transition-[width,background-color] duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select", r ? "w-5 bg-cp-primary" : "w-2 bg-cp-line-strong hover:bg-cp-lavender")
                            }, t)
                        })
                    }) : null]
                })
            }
        },
        53683: (e, t, r) => {
            "use strict";
            r.d(t, {
                TemplateDetailPrice: () => o
            });
            var n = r(73365),
                i = r(32420),
                a = r(9710),
                s = r(70414);

            function o({
                template: e,
                currencySuffix: t,
                couponCopy: r,
                suppressDerivedAnchor: l
            }) {
                let c = (0, a.l)(e.slug, e.priceInr),
                    d = (0, s.G5)(e.priceInr),
                    u = r || l ? { ...d,
                        hasOffer: !1,
                        compareAtInr: null,
                        discountPercent: null
                    } : d;
                return (0, n.jsxs)("div", {
                    className: "mt-5 space-y-1.5",
                    children: [(0, n.jsxs)("div", {
                        className: "flex flex-wrap items-baseline gap-x-2.5 gap-y-1",
                        children: [(0, n.jsx)("p", {
                            className: "text-[24px] font-semibold tracking-[-0.02em] text-cp-ink sm:text-[28px]",
                            children: u.isFree ? "Free" : `${(0,s.Dh)(u.priceInr)} ${t}`
                        }), u.hasOffer && null !== u.compareAtInr ? (0, n.jsxs)(n.Fragment, {
                            children: [(0, n.jsx)("p", {
                                className: "text-[15px] font-medium text-cp-muted line-through sm:text-[17px]",
                                children: (0, s.Dh)(u.compareAtInr)
                            }), (0, n.jsxs)("span", {
                                className: "rounded-md bg-cp-success/10 px-1.5 py-0.5 text-[12px] font-semibold text-cp-success-ink",
                                children: [u.discountPercent, "% off"]
                            })]
                        }) : null]
                    }), r ? (0, n.jsxs)("div", {
                        className: "group relative inline-flex w-fit",
                        children: [(0, n.jsx)("button", {
                            type: "button",
                            title: r.productTooltip,
                            "aria-label": r.productTooltip,
                            className: "cursor-help rounded-md text-left",
                            children: (0, n.jsx)(i.M, {
                                size: "md",
                                copy: r
                            })
                        }), (0, n.jsx)("span", {
                            role: "tooltip",
                            className: "pointer-events-none absolute top-full left-0 z-20 mt-2 w-max max-w-[min(20rem,80vw)] rounded-lg bg-cp-ink px-3 py-2 text-[12px] font-medium text-white opacity-0 shadow-cp-float transition-opacity duration-150 group-hover:opacity-100 group-focus-within:opacity-100",
                            children: r.productTooltip
                        })]
                    }) : c ? (0, n.jsx)(i.M, {
                        size: "md",
                        copy: c.copy
                    }) : null]
                })
            }
        },
        55684: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                TopOnFreshLoad: () => i
            });
            var n = r(1521);

            function i() {
                return (0, n.useEffect)(() => {
                    let [e] = performance.getEntriesByType("navigation");
                    if (e && "navigate" !== e.type || window.location.hash || document.body.hasAttribute("data-overlay-open")) return;
                    window.scrollTo(0, 0);
                    let t = [requestAnimationFrame(() => {
                        if (document.body.hasAttribute("data-overlay-open")) return;
                        window.scrollTo(0, 0);
                        let e = requestAnimationFrame(() => {
                            document.body.hasAttribute("data-overlay-open") || window.scrollTo(0, 0)
                        });
                        t.push(e)
                    })];
                    return () => {
                        for (let e of t) cancelAnimationFrame(e)
                    }
                }, []), null
            }
        },
        69580: (e, t, r) => {
            "use strict";
            r.d(t, {
                A: () => n
            });
            let n = (0, r(96296).A)("shopping-bag", [
                ["path", {
                    d: "M16 10a4 4 0 0 1-8 0",
                    key: "1ltviw"
                }],
                ["path", {
                    d: "M3.103 6.034h17.794",
                    key: "awc11p"
                }],
                ["path", {
                    d: "M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",
                    key: "o988cm"
                }]
            ])
        },
        70154: (e, t, r) => {
            "use strict";
            r.d(t, {
                CreatorVideoWall: () => d,
                N: () => o,
                h: () => l
            });
            var n = r(73365),
                i = r(1521),
                a = r(78175),
                s = r(70288);

            function o() {
                if ("u" < typeof navigator) return !1;
                let e = navigator.connection;
                if (!e) return !1;
                if (e.saveData) return !0;
                let t = e.effectiveType ? ? "";
                return "slow-2g" === t || "2g" === t || "3g" === t || "number" == typeof e.downlink && e.downlink > 0 && e.downlink < 1.5
            }

            function l({
                video: e,
                index: t,
                lowBitrate: r
            }) {
                let a = (0, i.useRef)(null),
                    o = (0, i.useRef)(null),
                    [c, d] = (0, i.useState)(!1),
                    [u, p] = (0, i.useState)(!1),
                    m = r ? e.lowSrc : e.src;
                return (0, i.useEffect)(() => {
                    let e = o.current;
                    if (!e || (0, s.r)(navigator) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
                    if ("u" < typeof IntersectionObserver) return void d(!0);
                    let t = new IntersectionObserver(e => {
                        e.some(e => e.isIntersecting) && (d(!0), t.disconnect())
                    }, {
                        rootMargin: "100% 0px"
                    });
                    return t.observe(e), () => t.disconnect()
                }, []), (0, i.useEffect)(() => {
                    if (!c) return;
                    let e = a.current;
                    if (!e) return;
                    if (e.muted = !0, e.defaultMuted = !0, e.setAttribute("controlsList", "nodownload noplaybackrate noremoteplayback"), e.disablePictureInPicture = !0, "u" < typeof IntersectionObserver) return void e.play().catch(() => {});
                    let t = new IntersectionObserver(t => {
                        for (let r of t) r.isIntersecting ? e.play().catch(() => {}) : e.paused || e.pause()
                    }, {
                        threshold: .35
                    });
                    return t.observe(e), () => t.disconnect()
                }, [c]), (0, n.jsxs)("div", {
                    ref: o,
                    className: "group relative overflow-hidden rounded-[1.35rem] border border-[var(--color-border)] bg-[#EFEAE1] shadow-[0_8px_22px_rgba(15,23,42,0.06)] transition-[border-color,box-shadow] duration-300 hover:border-[var(--color-lavender)]/40 hover:shadow-[0_12px_28px_rgba(91,63,232,0.10)]",
                    style: {
                        aspectRatio: "9 / 16",
                        animationDelay: `${70*t}ms`
                    },
                    onContextMenu: e => e.preventDefault(),
                    children: [(0, n.jsx)("video", {
                        ref: a,
                        muted: !0,
                        loop: !0,
                        playsInline: !0,
                        preload: c ? "metadata" : "none",
                        onLoadedData: () => p(!0),
                        onContextMenu: e => e.preventDefault(),
                        className: `size-full object-cover transition-opacity duration-700 ${u?"opacity-100":"opacity-0"}`,
                        children: c ? (0, n.jsx)("source", {
                            src: m,
                            type: "video/mp4"
                        }) : null
                    }), (0, n.jsx)("img", {
                        src: e.poster,
                        alt: "",
                        loading: "lazy",
                        "aria-hidden": !0,
                        draggable: !1,
                        onContextMenu: e => e.preventDefault(),
                        className: `pointer-events-none absolute inset-0 size-full object-cover transition-opacity duration-700 ${u?"opacity-0":"opacity-100"}`
                    }), (0, n.jsx)("div", {
                        "aria-hidden": !0,
                        className: "absolute inset-0 z-10 select-none",
                        onContextMenu: e => e.preventDefault(),
                        style: {
                            WebkitTouchCallout: "none",
                            WebkitUserSelect: "none"
                        }
                    }), (0, n.jsx)("div", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute inset-x-0 bottom-0 z-20 h-2/5 bg-gradient-to-t from-black/45 via-black/10 to-transparent opacity-80"
                    }), (0, n.jsxs)("div", {
                        "aria-hidden": !0,
                        className: "pointer-events-none absolute bottom-2 left-2 z-20 flex items-center gap-1 rounded-full bg-black/35 px-1.5 py-0.5 text-[8px] font-semibold uppercase tracking-[0.12em] text-white/90 backdrop-blur-sm sm:bottom-3 sm:left-3 sm:gap-1.5 sm:px-2.5 sm:py-1 sm:text-[10px] sm:tracking-[0.14em]",
                        children: [(0, n.jsxs)("span", {
                            className: "relative flex size-1 sm:size-1.5",
                            children: [(0, n.jsx)("span", {
                                className: "absolute inline-flex size-full animate-ping rounded-full bg-white/70"
                            }), (0, n.jsx)("span", {
                                className: "relative inline-flex size-1 rounded-full bg-white sm:size-1.5"
                            })]
                        }), "Creator"]
                    })]
                })
            }
            let c = {
                wide: "grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-6",
                compact: "grid grid-cols-3 gap-3 sm:gap-4 sm:grid-cols-6"
            };

            function d({
                layout: e = "wide"
            }) {
                let [t, r] = (0, i.useState)(!1);
                return (0, i.useEffect)(() => {
                    r(o())
                }, []), (0, n.jsx)("div", {
                    className: c[e],
                    children: a.X.map((e, r) => (0, n.jsx)(l, {
                        video: e,
                        index: r,
                        lowBitrate: t
                    }, e.id))
                })
            }
        },
        70288: (e, t, r) => {
            "use strict";
            r.d(t, {
                HomeMotionTier: () => a,
                r: () => i
            });
            var n = r(1521);

            function i(e) {
                return !!e.connection ? .saveData || "number" == typeof e.deviceMemory && e.deviceMemory <= 2 || "number" == typeof e.hardwareConcurrency && e.hardwareConcurrency > 0 && e.hardwareConcurrency <= 2
            }

            function a() {
                return (0, n.useEffect)(() => {
                    if (!i(navigator)) return;
                    let e = document.documentElement;
                    return e.dataset.homeMotion = "lite", () => {
                        delete e.dataset.homeMotion
                    }
                }, []), null
            }
        },
        72471: (e, t, r) => {
            "use strict";
            r.d(t, {
                TemplateReviewForm: () => l
            });
            var n = r(73365),
                i = r(1521),
                a = r(90925),
                s = r(9388),
                o = r(54872);

            function l({
                templateId: e,
                templateName: t
            }) {
                let [r, c] = (0, i.useState)(!1), [d, u] = (0, i.useState)(0), [p, m] = (0, i.useState)(0), [f, h] = (0, i.useState)(""), [x, v] = (0, i.useState)(!1), [b, g] = (0, i.useState)(!1), [y, w] = (0, i.useState)(!1), [k, j] = (0, i.useState)(null);
                async function N() {
                    if (d < 1) return void j("Pick a star rating first.");
                    v(!0), j(null);
                    try {
                        let t = await fetch(`/api/templates/${encodeURIComponent(e)}/reviews`, {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    rating: d,
                                    comment: f
                                })
                            }),
                            r = await t.json().catch(() => null);
                        if (!t.ok) return void j(r ? .error ? ? "Could not save your rating. Try again.");
                        g(!0)
                    } catch {
                        j("Could not save your rating. Check your connection.")
                    } finally {
                        v(!1)
                    }
                }
                return ((0, i.useEffect)(() => {
                    let t = !0;
                    return fetch(`/api/templates/${encodeURIComponent(e)}/reviews?eligibility=1`).then(e => e.ok ? e.json() : null).then(e => {
                        if (!t || !e ? .data ? .canReview) return;
                        c(!0);
                        let r = e.data.existing;
                        r && (u(r.rating), h(r.comment ? ? ""), w(!0))
                    }).catch(() => {}), () => {
                        t = !1
                    }
                }, [e]), r) ? (0, n.jsx)("section", {
                    className: "pt-16 sm:pt-20",
                    children: (0, n.jsx)("div", {
                        className: "mx-auto max-w-6xl px-4 sm:px-6 lg:px-8",
                        children: (0, n.jsx)("div", {
                            className: "rounded-xl border border-cp-line bg-cp-bg p-5 sm:p-7",
                            children: b ? (0, n.jsxs)("div", {
                                className: "flex flex-col items-start gap-1",
                                children: [(0, n.jsxs)("p", {
                                    className: "text-[17px] font-semibold tracking-[-0.01em] text-cp-ink",
                                    children: ["Thanks for rating ", t]
                                }), (0, n.jsx)("p", {
                                    className: "text-[14px] text-cp-muted",
                                    children: "We've saved it. Ratings are totalled once a day, so the average above updates within 24 hours."
                                })]
                            }) : (0, n.jsxs)(n.Fragment, {
                                children: [(0, n.jsx)("p", {
                                    className: "text-[15px] font-semibold text-cp-ink",
                                    children: y ? "Update your rating" : "Rate this template"
                                }), (0, n.jsx)("p", {
                                    className: "mt-1 text-[14px] text-cp-muted",
                                    children: "You used this template, so your rating helps everyone else choose."
                                }), (0, n.jsx)("div", {
                                    className: "mt-4 flex items-center gap-1",
                                    onMouseLeave: () => m(0),
                                    children: [1, 2, 3, 4, 5].map(e => {
                                        let t = (p || d) >= e;
                                        return (0, n.jsx)("button", {
                                            type: "button",
                                            onClick: () => u(e),
                                            onMouseEnter: () => m(e),
                                            "aria-label": `${e} star${1===e?"":"s"}`,
                                            "aria-pressed": d === e,
                                            className: "rounded-lg p-1 transition-transform duration-150 hover:scale-110 focus-visible:outline-2 focus-visible:outline-cp-select motion-reduce:transition-none",
                                            children: (0, n.jsx)(a.A, {
                                                strokeWidth: 1.75,
                                                "aria-hidden": !0,
                                                className: (0, o.cn)("size-7 transition-colors", t ? "fill-cp-warning text-cp-warning" : "text-cp-faint")
                                            })
                                        }, e)
                                    })
                                }), (0, n.jsx)("textarea", {
                                    value: f,
                                    onChange: e => h(e.target.value),
                                    maxLength: 2e3,
                                    rows: 3,
                                    placeholder: "What did you like about it? (optional)",
                                    className: "mt-4 w-full resize-y rounded-lg border border-cp-line bg-cp-bg px-3 py-2.5 text-[14px] text-cp-ink outline-none transition-colors placeholder:text-cp-faint focus:border-cp-line-strong focus:ring-2 focus:ring-cp-select/30"
                                }), k ? (0, n.jsx)("p", {
                                    className: "mt-2 text-[13px] font-medium text-cp-danger-ink",
                                    children: k
                                }) : null, (0, n.jsx)(s.$, {
                                    type: "button",
                                    variant: "secondary",
                                    onClick: N,
                                    disabled: x,
                                    className: "mt-4 h-10 rounded-lg border-0 bg-cp-subtle text-cp-ink hover:bg-cp-hover hover:text-cp-ink",
                                    children: x ? "Saving\u2026" : y ? "Update rating" : "Submit rating"
                                })]
                            })
                        })
                    })
                }) : null
            }
        },
        75133: (e, t, r) => {
            "use strict";
            r.d(t, {
                GiftCardActions: () => d
            });
            var n = r(73365),
                i = r(29717),
                a = r(1521),
                s = r(26821),
                o = r(38277),
                l = r(9388),
                c = r(26752);

            function d({
                href: e,
                soleVariantId: t,
                hasStock: r
            }) {
                let u = c.O.productsPage.giftsListing.grid,
                    p = (0, i.useRouter)(),
                    [m, f] = (0, a.useState)(null),
                    [h, x] = (0, a.useState)(!1);
                async function v(n) {
                    if (!m) {
                        if (!t || !r) return void p.push(e);
                        f(n);
                        try {
                            if (!(await fetch("/api/gifts/cart", {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify({
                                        variantId: t,
                                        quantity: 1,
                                        personalization: {}
                                    })
                                })).ok) {
                                p.push(e), f(null);
                                return
                            }
                            if ((0, o.Hz)(), "buy" === n) return void p.push("/gifts/checkout");
                            x(!0), f(null)
                        } catch {
                            p.push(e), f(null)
                        }
                    }
                }
                return (0, n.jsxs)("div", {
                    className: "grid gap-2 @[13.5rem]:grid-cols-2",
                    children: [(0, n.jsx)(l.$, {
                        type: "button",
                        variant: "secondary",
                        size: "sm",
                        disabled: null !== m && "cart" !== m,
                        loading: "cart" === m,
                        onClick: () => void v("cart"),
                        iconLeading: h ? (0, n.jsx)(s.A, {
                            strokeWidth: 1.75,
                            "aria-hidden": !0
                        }) : void 0,
                        className: h ? "h-10 w-full min-w-0 rounded-xl border border-cp-success/30 bg-cp-success/10 px-3 text-[13px] text-cp-success-ink hover:bg-cp-success/10 sm:h-9" : "h-10 w-full min-w-0 rounded-xl border border-cp-line-strong bg-cp-bg px-3 text-[13px] text-cp-ink hover:border-cp-ink/30 hover:bg-cp-subtle sm:h-9",
                        children: h ? u.addedCta : u.addToCartCta
                    }), (0, n.jsx)(l.$, {
                        type: "button",
                        variant: "primary",
                        size: "sm",
                        disabled: null !== m && "buy" !== m,
                        loading: "buy" === m,
                        onClick: () => void v("buy"),
                        className: "h-10 w-full min-w-0 rounded-xl px-3 text-[13px] font-semibold sm:h-9",
                        children: u.buyNowCta
                    })]
                })
            }
        },
        78175: (e, t, r) => {
            "use strict";
            r.d(t, {
                X: () => n
            });
            let n = [{
                id: "creator-1",
                src: "/api/creator-reels/r1h",
                lowSrc: "/api/creator-reels/r1l",
                poster: "/api/creator-reels/r1p"
            }, {
                id: "creator-2",
                src: "/api/creator-reels/r2h",
                lowSrc: "/api/creator-reels/r2l",
                poster: "/api/creator-reels/r2p"
            }, {
                id: "creator-3",
                src: "/api/creator-reels/r3h",
                lowSrc: "/api/creator-reels/r3l",
                poster: "/api/creator-reels/r3p"
            }, {
                id: "creator-4",
                src: "/api/creator-reels/r4h",
                lowSrc: "/api/creator-reels/r4l",
                poster: "/api/creator-reels/r4p"
            }, {
                id: "creator-5",
                src: "/api/creator-reels/r5h",
                lowSrc: "/api/creator-reels/r5l",
                poster: "/api/creator-reels/r5p"
            }, {
                id: "creator-6",
                src: "/api/creator-reels/r6h",
                lowSrc: "/api/creator-reels/r6l",
                poster: "/api/creator-reels/r6p"
            }]
        },
        94296: (e, t, r) => {
            "use strict";
            r.d(t, {
                Pm: () => n,
                RA: () => a,
                WH: () => i
            });
            let n = 300,
                i = 46;

            function a() {
                return 'url("data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="300" height="46" viewBox="0 0 300 46"><defs><filter id="s" x="-10%" y="-40%" width="120%" height="180%"><feDropShadow dx="0" dy="0" stdDeviation="1.2" flood-color="#ffffff" flood-opacity="0.9"/></filter></defs><rect x="35" y="1" width="230" height="44" rx="14" fill="#ffffff" fill-opacity="0.72"/><g font-family="Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif" text-anchor="middle" fill="#2a2140" filter="url(#s)"><text x="150" y="18" font-size="14" font-weight="600"><tspan fill="#ff5c8a" fill-opacity="1">\u2665 </tspan>Made with Cutiepage</text><text x="150" y="38" font-size="12" font-weight="500" fill-opacity="0.8">Make it live to remove watermark</text></g></svg>') + '")'
            }
        },
        96331: (e, t, r) => {
            "use strict";
            r.d(t, {
                k: () => a
            });
            var n = r(73365),
                i = r(54872);

            function a({
                className: e
            }) {
                return (0, n.jsxs)("svg", {
                    "aria-hidden": !0,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    className: (0, i.cn)("size-7 text-cp-primary motion-safe:animate-[spin_0.9s_linear_infinite]", e),
                    children: [(0, n.jsx)("circle", {
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "var(--cp-line)",
                        strokeWidth: "2",
                        vectorEffect: "non-scaling-stroke"
                    }), (0, n.jsx)("path", {
                        d: "M22 12a10 10 0 0 0-10-10",
                        stroke: "currentColor",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        vectorEffect: "non-scaling-stroke"
                    })]
                })
            }
        },
        98983: (e, t, r) => {
            Promise.resolve().then(r.bind(r, 13489)), Promise.resolve().then(r.bind(r, 99324)), Promise.resolve().then(r.bind(r, 75133)), Promise.resolve().then(r.bind(r, 11831)), Promise.resolve().then(r.bind(r, 70154)), Promise.resolve().then(r.bind(r, 99448)), Promise.resolve().then(r.bind(r, 53683)), Promise.resolve().then(r.bind(r, 72471)), Promise.resolve().then(r.bind(r, 55684)), Promise.resolve().then(r.bind(r, 51342)), Promise.resolve().then(r.bind(r, 94612)), Promise.resolve().then(r.bind(r, 4525)), Promise.resolve().then(r.t.bind(r, 99568, 23)), Promise.resolve().then(r.t.bind(r, 38137, 23))
        },
        99324: (e, t, r) => {
            "use strict";
            r.d(t, {
                TemplateViewTracker: () => a
            });
            var n = r(1521),
                i = r(84346);

            function a({
                slug: e,
                name: t,
                priceInr: r,
                category: s
            }) {
                let o = (0, n.useRef)(!1);
                return (0, n.useEffect)(() => {
                    e && !o.current && (o.current = !0, (0, i.y8)({
                        slug: e,
                        name: t,
                        priceInr: r,
                        category: s
                    }))
                }, [e]), null
            }
        },
        99448: (e, t, r) => {
            "use strict";
            r.d(t, {
                TemplateDetailCtas: () => w
            });
            var n = r(73365),
                i = r(1521),
                a = r(98196),
                s = r(86714),
                o = r(99568),
                l = r.n(o),
                c = r(9411),
                d = r(28682),
                u = r(9388),
                p = r(1960),
                m = r(974),
                f = r(23129);

            function h() {
                return "u" < typeof navigator ? null : navigator.connection ? ? null
            }
            var x = r(84346),
                v = r(6238),
                b = r(88340),
                g = r(54872);
            let y = (0, s.default)(() => Promise.all([r.e(15708), r.e(62610), r.e(76981), r.e(93602), r.e(7998), r.e(85319), r.e(34768), r.e(2461), r.e(82599)]).then(r.bind(r, 59126)), {
                loadableGenerated: {
                    webpack: () => [59126]
                },
                ssr: !1
            });

            function w({
                templateSlug: e,
                templateName: t,
                priceInr: r,
                previewHref: a,
                customizeCta: s,
                payLaterCta: o,
                previewCta: d,
                enginePreview: p
            }) {
                let {
                    isAuthed: m
                } = (0, v.h)(), [f, g] = (0, i.useState)(!1), [y, N] = (0, i.useState)(!1), C = (0, b.dU)(), S = C(`/dashboard/templates/${e}/start`), I = C(`/try/${e}`), z = m ? S : I, E = (0, i.useCallback)(() => g(!1), []), M = (0, i.useRef)(z);
                (0, i.useEffect)(() => {
                    M.current = z
                }, [z]);
                let P = (0, i.useCallback)(() => M.current, []),
                    R = (0, i.useCallback)(n => (0, x.Zi)({
                        slug: e,
                        name: t,
                        priceInr: r
                    }, n), [e, t, r]),
                    A = (0, i.useCallback)(() => R("preview"), [R]);
                (0, i.useEffect)(() => {
                    f && (0, x.TX)({
                        slug: e,
                        name: t,
                        priceInr: r
                    })
                }, [f, e, t, r]);
                let T = (0, i.useRef)(null);
                (0, i.useEffect)(() => {
                    let e = T.current;
                    e && ("1" === e.dataset.pendingClick && (delete e.dataset.pendingClick, g(!0)), e.dataset.hydrated = "1")
                }, []), (0, i.useEffect)(() => {
                    if (function(e) {
                            if (!e) return !0;
                            if (e.saveData) return !1;
                            let t = e.effectiveType;
                            return "slow-2g" !== t && "2g" !== t && "3g" !== t
                        }(h())) return function(e, t = 3e3) {
                        let r, n, i = !1,
                            a = () => {
                                i || ("function" == typeof window.requestIdleCallback ? r = window.requestIdleCallback(() => {
                                    i || e()
                                }, {
                                    timeout: t
                                }) : n = window.setTimeout(() => {
                                    i || e()
                                }, 1500))
                            };
                        return "complete" === document.readyState ? a() : window.addEventListener("load", a, {
                            once: !0
                        }), () => {
                            i = !0, window.removeEventListener("load", a), void 0 !== r && window.cancelIdleCallback ? .(r), void 0 !== n && window.clearTimeout(n)
                        }
                    }(() => N(!0))
                }, []);
                let _ = (0, i.useCallback)(() => {
                    h() ? .saveData || N(!0)
                }, []);
                return (0, n.jsxs)("div", {
                    className: "mt-6 flex flex-col gap-2.5",
                    children: [(0, n.jsx)(u.$, {
                        asChild: !0,
                        variant: "primary",
                        size: "lg",
                        className: "h-12 w-full rounded-xl bg-cp-select text-[16px] font-semibold text-white hover:bg-cp-primary focus-visible:ring-cp-select",
                        children: (0, n.jsx)(l(), {
                            href: z,
                            prefetch: !1,
                            onClick: () => R("detail"),
                            children: r > 0 ? o : s
                        })
                    }), (0, n.jsx)(u.$, {
                        ref: T,
                        type: "button",
                        variant: "secondary",
                        size: "lg",
                        iconTrailing: (0, n.jsx)(c.A, {
                            strokeWidth: 1.75
                        }),
                        className: "h-12 w-full rounded-xl border border-cp-line-strong bg-cp-bg text-[15px] text-cp-ink hover:bg-cp-subtle hover:text-cp-ink focus-visible:ring-cp-select",
                        "data-preview-cta": "",
                        onClick: () => g(!0),
                        onPointerEnter: _,
                        onTouchStart: _,
                        onFocus: _,
                        children: d
                    }), (0, n.jsx)(k, {}), (0, n.jsx)(j, {
                        open: f,
                        preload: y,
                        templateName: t,
                        previewHref: a,
                        getCustomizeHref: P,
                        onCustomize: A,
                        customizeCta: s,
                        onClose: E,
                        enginePreview: p
                    })]
                })
            }

            function k() {
                return (0, n.jsx)("span", {
                    suppressHydrationWarning: !0,
                    dangerouslySetInnerHTML: {
                        __html: "<script>(function(){var b=document.querySelector('[data-preview-cta]');if(!b)return;var h=function(e){if(b.dataset.hydrated==='1'){document.removeEventListener('click',h,true);return;}if(b.contains(e.target)){b.dataset.pendingClick='1';}};document.addEventListener('click',h,true);})();<\/script>"
                    }
                })
            }
            let j = (0, i.memo)(function({
                open: e,
                preload: t,
                templateName: r,
                previewHref: s,
                getCustomizeHref: o,
                onCustomize: c,
                customizeCta: h,
                onClose: x,
                enginePreview: v
            }) {
                let [b, w] = (0, i.useState)(!1), [k, j] = (0, i.useState)(!1), [N, C] = (0, i.useState)(0), [S, I] = (0, i.useState)(!1), z = (0, i.useRef)(!1), E = (0, i.useRef)(N);
                (0, i.useEffect)(() => {
                    E.current = N
                }, [N]);
                let M = (0, i.useCallback)(e => {
                        let t = E.current,
                            r = () => {
                                E.current === t && I(!0)
                            };
                        try {
                            let t = e.currentTarget.contentWindow;
                            if (t && "function" == typeof t.requestIdleCallback) return void t.requestIdleCallback(r, {
                                timeout: 1500
                            })
                        } catch {}
                        r()
                    }, []),
                    P = (0, i.useCallback)(() => I(!0), []);
                if ((0, i.useEffect)(() => {
                        if (e) {
                            z.current = !0;
                            let e = window.requestAnimationFrame(() => {
                                j(!0), w(!0)
                            });
                            return () => window.cancelAnimationFrame(e)
                        }
                        if (!z.current) return;
                        z.current = !1;
                        let t = window.requestAnimationFrame(() => w(!1)),
                            r = window.setTimeout(() => {
                                j(!1), I(!1), C(e => e + 1)
                            }, 220);
                        return () => {
                            window.cancelAnimationFrame(t), window.clearTimeout(r)
                        }
                    }, [e]), (0, i.useEffect)(() => {
                        if (!e) return;
                        let t = document.body.style.overflow;
                        return document.body.style.overflow = "hidden", document.body.setAttribute("data-overlay-open", "preview"), () => {
                            document.body.style.overflow = t, document.body.removeAttribute("data-overlay-open")
                        }
                    }, [e]), (0, i.useEffect)(() => {
                        if (e) return document.addEventListener("keydown", t), () => document.removeEventListener("keydown", t);

                        function t(e) {
                            "Escape" === e.key && x()
                        }
                    }, [e, x]), !e && !t && !k) return null;
                let R = e || k;
                return (0, a.createPortal)((0, n.jsxs)("div", {
                    role: "dialog",
                    "aria-modal": R ? "true" : void 0,
                    "aria-hidden": !R || void 0,
                    "aria-label": `${r} preview`,
                    inert: !R,
                    className: (0, g.cn)("fixed inset-0 z-[100] flex flex-col bg-cp-canvas transition-opacity duration-200 ease-out", b ? "opacity-100" : "opacity-0", R ? "" : "pointer-events-none invisible"),
                    children: [(0, n.jsxs)("div", {
                        className: (0, g.cn)("flex h-14 items-center justify-between gap-3 border-b border-cp-line bg-cp-bg px-3 transition-all duration-200 ease-out sm:px-4", b ? "translate-y-0 opacity-100" : "-translate-y-2 opacity-0"),
                        children: [(0, n.jsxs)("button", {
                            type: "button",
                            onClick: x,
                            "aria-label": "Back",
                            className: "inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full px-2.5 text-[13px] font-medium text-cp-ink transition-colors duration-150 hover:bg-cp-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                            children: [(0, n.jsx)(d.A, {
                                className: "size-4",
                                strokeWidth: 1.75,
                                "aria-hidden": !0
                            }), (0, n.jsx)("span", {
                                children: "Back"
                            })]
                        }), (0, n.jsxs)("div", {
                            className: "min-w-0 truncate text-[13px] text-cp-muted",
                            children: [(0, n.jsx)("span", {
                                className: "hidden sm:inline",
                                children: "Previewing\xa0"
                            }), (0, n.jsx)("span", {
                                className: "font-semibold text-cp-ink",
                                children: r
                            })]
                        }), (0, n.jsx)(u.$, {
                            asChild: !0,
                            variant: "primary",
                            size: "sm",
                            className: "h-9 shrink-0 rounded-xl bg-cp-primary font-semibold whitespace-nowrap text-white hover:bg-cp-primary-hover focus-visible:ring-cp-select",
                            children: (0, n.jsx)(l(), {
                                href: o(),
                                prefetch: !1,
                                onClick: c,
                                children: h
                            })
                        })]
                    }), (0, n.jsxs)("div", {
                        className: (0, g.cn)("relative flex-1 overflow-hidden transition-all duration-200 ease-out", b ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0"),
                        children: [v ? (0, n.jsx)("div", {
                            className: "flex size-full flex-col",
                            children: (0, n.jsxs)("div", {
                                className: "relative min-h-0 flex-1",
                                children: [(0, n.jsx)(y, {
                                    seed: v,
                                    active: R,
                                    onReady: P
                                }, `engine#${N}`), (0, n.jsx)(m.R, {
                                    contained: !0
                                }), v.creatorWatermark ? (0, n.jsx)(f.CreatorWatermark, {}) : null]
                            })
                        }) : (0, n.jsx)("iframe", {
                            src: s,
                            title: `${r} preview`,
                            tabIndex: R ? void 0 : -1,
                            className: "size-full border-0 bg-cp-bg",
                            onLoad: M
                        }, `${s}#${N}`), S ? null : (0, n.jsx)(p.b, {})]
                    })]
                }), document.body)
            })
        }
    },
    e => {
        e.O(0, [84327, 99568, 38137, 20801, 26752, 47105, 80304, 76139, 2347, 15158, 77358], () => e(e.s = 98983)), _N_E = e.O()
    }
]);