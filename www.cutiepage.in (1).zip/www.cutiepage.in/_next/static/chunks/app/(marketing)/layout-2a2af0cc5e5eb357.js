(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [29181], {
        15249: (e, t, n) => {
            Promise.resolve().then(n.bind(n, 81726)), Promise.resolve().then(n.bind(n, 43636)), Promise.resolve().then(n.bind(n, 31148)), Promise.resolve().then(n.bind(n, 4525)), Promise.resolve().then(n.t.bind(n, 99568, 23)), Promise.resolve().then(n.t.bind(n, 38137, 23))
        },
        29267: (e, t, n) => {
            "use strict";
            n.d(t, {
                Zc: () => s,
                mv: () => a
            });
            let i = new Set(["www.cutiepage.in", "dash.cutiepage.in"]);

            function s(e) {
                let t;
                if ("u" < typeof location) return null;
                let n = location.hostname;
                return i.has(n) || "/api/analytics/collect" === e && "https:" === location.protocol && (t = /^([a-z0-9-]+)\.cutiepage\.app$/.exec(n) ? .[1]) && "render" !== t && "ads" !== t ? "https://chat.cutiepage.in" + e : null
            }

            function a(e) {
                return !e.ok && 429 !== e.status
            }
        },
        81726: (e, t, n) => {
            "use strict";
            n.d(t, {
                PageTransition: () => o
            });
            var i = n(73365),
                s = n(29717),
                a = n(1521);

            function o({
                children: e
            }) {
                let t = (0, s.usePathname)(),
                    [n] = (0, a.useState)(t);
                return (0, i.jsx)("div", {
                    className: t === n ? void 0 : "animate-page-enter",
                    children: e
                }, t)
            }
        }
    },
    e => {
        e.O(0, [84327, 7998, 99568, 38137, 54559, 21381, 26752, 31148, 89655, 43636, 2347, 15158, 77358], () => e(e.s = 15249)), _N_E = e.O()
    }
]);