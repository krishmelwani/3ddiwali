(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7177], {
        18542: (e, t, n) => {
            "use strict";
            n.d(t, {
                FR: () => l,
                T5: () => c,
                Zf: () => s,
                ee: () => u,
                gk: () => d,
                tH: () => a
            });
            let r = "cp_chunk_reload_at",
                o = /ChunkLoadError|Loading chunk [^ ]+ failed|Loading CSS chunk|Failed to fetch dynamically imported module|Importing a module script failed|error loading dynamically imported module/i,
                i = /\b[a-zA-Z_$][\w$]?(?:\[[a-zA-Z_$][\w$]?\]|\.[a-zA-Z_$][\w$]?) is not a function\b|Cannot read propert(?:y|ies) of undefined \(reading '(?:call|exports|default)'\)/i;

            function a(e) {
                var t;
                return e instanceof Error && (t = `${e.name} ${e.message}`, o.test(t) || i.test(t))
            }

            function c() {
                try {
                    let e = Number(sessionStorage.getItem(r) ? ? 0);
                    if (Date.now() - e < 3e4) return !1;
                    sessionStorage.setItem(r, String(Date.now()))
                } catch {}
                return window.location.reload(), !0
            }

            function s() {
                try {
                    let e = Number(sessionStorage.getItem(r) ? ? 0);
                    return Date.now() - e < 3e4
                } catch {
                    return !1
                }
            }

            function u() {
                try {
                    sessionStorage.removeItem(r)
                } catch {}
            }

            function l() {
                try {
                    let e = new URL(window.location.href);
                    e.searchParams.set("__rl", String(Date.now())), window.location.replace(e.toString())
                } catch {
                    window.location.reload()
                }
            }
            let d = "__rl"
        },
        26700: (e, t, n) => {
            "use strict";
            n.d(t, {
                ChunkReloadGuard: () => i
            });
            var r = n(1521),
                o = n(18542);

            function i() {
                return (0, r.useEffect)(() => {
                    function e(e) {
                        (0, o.tH)(e.reason) && (0, o.T5)() && e.preventDefault()
                    }

                    function t(e) {
                        (0, o.tH)(e.error) && (0, o.T5)() && e.preventDefault()
                    }
                    return window.addEventListener("unhandledrejection", e), window.addEventListener("error", t), () => {
                        window.removeEventListener("unhandledrejection", e), window.removeEventListener("error", t)
                    }
                }, []), null
            }
        },
        29267: (e, t, n) => {
            "use strict";
            n.d(t, {
                Zc: () => o,
                mv: () => i
            });
            let r = new Set(["www.cutiepage.in", "dash.cutiepage.in"]);

            function o(e) {
                let t;
                if ("u" < typeof location) return null;
                let n = location.hostname;
                return r.has(n) || "/api/analytics/collect" === e && "https:" === location.protocol && (t = /^([a-z0-9-]+)\.cutiepage\.app$/.exec(n) ? .[1]) && "render" !== t && "ads" !== t ? "https://chat.cutiepage.in" + e : null
            }

            function i(e) {
                return !e.ok && 429 !== e.status
            }
        },
        29717: (e, t, n) => {
            "use strict";
            var r = n(21505);
            n.o(r, "usePathname") && n.d(t, {
                usePathname: function() {
                    return r.usePathname
                }
            }), n.o(r, "useRouter") && n.d(t, {
                useRouter: function() {
                    return r.useRouter
                }
            }), n.o(r, "useSearchParams") && n.d(t, {
                useSearchParams: function() {
                    return r.useSearchParams
                }
            })
        },
        30664: e => {
            e.exports = {
                style: {
                    fontFamily: "'Caveat', 'Caveat Fallback'",
                    fontStyle: "normal"
                },
                className: "__className_67b544",
                variable: "__variable_67b544"
            }
        },
        33488: (e, t, n) => {
            "use strict";
            n.d(t, {
                AnalyticsBeacon: () => l
            });
            var r = n(73365),
                o = n(29717),
                i = n(1521),
                a = n(80937),
                c = n(37809),
                s = n(58975);

            function u() {
                let e = (0, o.usePathname)(),
                    t = (0, o.useSearchParams)(),
                    n = (0, i.useRef)(null);
                return (0, i.useEffect)(() => {
                    !e || !(0, s.KC)() || (0, a.M3)(window.location.host) || (0, a.J2)(e) || n.current !== e && (n.current = e, (0, c.G4)({
                        name: "page_view",
                        path: e,
                        props: function(e) {
                            if (!e) return {};
                            let t = {};
                            for (let n of ["utm_source", "utm_medium", "utm_campaign"]) {
                                let r = e.get(n);
                                r && (t[n] = r.slice(0, 64))
                            }
                            return t
                        }(t)
                    }))
                }, [e, t]), (0, i.useEffect)(() => {
                    let e = () => {
                        "hidden" === document.visibilityState && (0, c.Sm)(!0)
                    };
                    return document.addEventListener("visibilitychange", e), window.addEventListener("pagehide", e), () => {
                        document.removeEventListener("visibilitychange", e), window.removeEventListener("pagehide", e), (0, c.Sm)(!0)
                    }
                }, []), null
            }

            function l() {
                return (0, r.jsx)(i.Suspense, {
                    fallback: null,
                    children: (0, r.jsx)(u, {})
                })
            }
        },
        37809: (e, t, n) => {
            "use strict";
            n.d(t, {
                G4: () => s,
                Sm: () => u,
                zy: () => l
            });
            var r = n(29267);
            let o = "/api/analytics/collect",
                i = [],
                a = null,
                c = "cp_an_sid";

            function s(e) {
                try {
                    if (i.push({ ...e,
                            ts: Date.now(),
                            referrer: document.referrer || "",
                            session_id: function() {
                                try {
                                    let e = sessionStorage.getItem(c);
                                    return e || (e = "u" > typeof crypto && "randomUUID" in crypto ? crypto.randomUUID().replace(/-/g, "").slice(0, 24) : Math.random().toString(36).slice(2) + Date.now().toString(36), sessionStorage.setItem(c, e)), e
                                } catch {
                                    return ""
                                }
                            }()
                        }), i.length >= 25) return void u();
                    null === a && (a = setTimeout(() => u(), 2e3))
                } catch {}
            }

            function u(e = !1) {
                if (null !== a && (clearTimeout(a), a = null), !i.length) return;
                let t = i;
                i = [];
                let n = JSON.stringify({
                        events: t
                    }),
                    c = (0, r.Zc)(o),
                    s = () => fetch(o, {
                        method: "POST",
                        headers: {
                            "content-type": "application/json"
                        },
                        body: n,
                        keepalive: !0
                    }).catch(() => {});
                try {
                    if (e && "u" > typeof navigator && navigator.sendBeacon) {
                        let e = new Blob([n], {
                            type: c ? "text/plain" : "application/json"
                        });
                        if (navigator.sendBeacon(c ? ? o, e)) return
                    }
                    if (!c) return void s();
                    fetch(c, {
                        method: "POST",
                        headers: {
                            "content-type": "text/plain"
                        },
                        body: n,
                        keepalive: !0,
                        credentials: "omit"
                    }).then(e => {
                        (0, r.mv)(e) && s()
                    }, () => void s())
                } catch {}
            }

            function l(e, t) {
                s({
                    name: "template_impression",
                    template_slug: e,
                    props: {
                        surface: t
                    }
                })
            }
        },
        41786: (e, t, n) => {
            "use strict";

            function r(e) {
                let t = new Set;
                for (let n of e) n.startsWith("sb-") && t.add(n);
                return [...t]
            }

            function o(e) {
                return e.some(i)
            }

            function i(e) {
                return e.startsWith("sb-") && (e.endsWith("-auth-token") || /-auth-token\.\d+$/.test(e))
            }

            function a(e) {
                return [...new Set(e.filter(i))]
            }

            function c(e) {
                return e ? e.split(";").map(e => e.split("=")[0] ? .trim()).filter(e => !!e) : []
            }
            n.d(t, {
                Bz: () => r,
                MB: () => c,
                hO: () => o,
                tr: () => a
            })
        },
        43333: () => {},
        50068: (e, t, n) => {
            "use strict";
            n.d(t, {
                T$: () => o,
                mZ: () => r,
                wb: () => a,
                yq: () => i
            });
            let r = 2592e3,
                o = "ref",
                i = 4;

            function a(e) {
                return e.trim().toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 32)
            }
        },
        53180: (e, t, n) => {
            "use strict";
            n.d(t, {
                F: () => o,
                T: () => r
            });
            let r = "https://cdn.cutiepage.in",
                o = "https://pub-9a93db46c01f4a47846cf3de6e3f148e.r2.dev"
        },
        55275: e => {
            e.exports = {
                style: {
                    fontFamily: "'Fraunces', 'Fraunces Fallback'"
                },
                className: "__className_34a102",
                variable: "__variable_34a102"
            }
        },
        58560: (e, t, n) => {
            "use strict";
            n.d(t, {
                ai: () => i
            });
            var r = n(76724),
                o = n(19071);

            function i(e) {
                return r.qG(o.rS, e)
            }
        },
        70097: (e, t, n) => {
            "use strict";
            n.d(t, {
                ReferralTracker: () => h
            });
            var r = n(1521),
                o = n(50068);
            let i = "cp_ref_backup";
            var a = n(88340);
            let c = "cp_vid",
                s = "cp_vid",
                u = "cp_sid",
                l = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

            function d(e) {
                return "string" == typeof e && l.test(e)
            }

            function f() {
                try {
                    if ("u" > typeof crypto && "randomUUID" in crypto) return crypto.randomUUID();
                    let e = "u" > typeof crypto ? crypto : void 0;
                    if (e && "function" == typeof e.getRandomValues) {
                        let t = e.getRandomValues(new Uint8Array(16));
                        t[6] = 15 & t[6] | 64, t[8] = 63 & t[8] | 128;
                        let n = Array.from(t).map(e => e.toString(16).padStart(2, "0")).join("");
                        return `${n.slice(0,8)}-${n.slice(8,12)}-${n.slice(12,16)}-${n.slice(16,20)}-${n.slice(20)}`
                    }
                } catch {}
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, e => {
                    let t = 16 * Math.random() | 0;
                    return ("x" === e ? t : 3 & t | 8).toString(16)
                })
            }
            var m = n(58975);

            function h() {
                return (0, r.useEffect)(() => {
                    if ((0, m.py)()) return;
                    let e = function() {
                            let e = null,
                                t = null;
                            try {
                                e = function(e) {
                                    if ("u" < typeof document) return null;
                                    let t = document.cookie.match(RegExp(`(?:^|;\\s*)${e}=([^;]*)`));
                                    return t ? decodeURIComponent(t[1]) : null
                                }(c)
                            } catch {}
                            try {
                                t = window.localStorage.getItem(s)
                            } catch {}
                            let n = (d(e) ? e : null) ? ? (d(t) ? t : null) ? ? f();
                            if (n !== e) try {
                                ! function(e, t) {
                                    if ("u" < typeof document) return;
                                    let n = "https:" === window.location.protocol ? "; Secure" : "";
                                    document.cookie = `${e}=${encodeURIComponent(t)}; Path=/; Max-Age=63072000; SameSite=Lax${n}`
                                }(c, n)
                            } catch {}
                            if (n !== t) try {
                                window.localStorage.setItem(s, n)
                            } catch {}
                            return n
                        }(),
                        t = function() {
                            try {
                                let e = window.sessionStorage.getItem(u);
                                if (d(e)) return e;
                                let t = f();
                                return window.sessionStorage.setItem(u, t), t
                            } catch {
                                return null
                            }
                        }(),
                        n = new URLSearchParams(window.location.search),
                        r = n.get(o.T$);
                    r && ((0, a.Iu)(r), function(e) {
                        let t = (0, o.wb)(e);
                        if (!(t.length < o.yq)) try {
                            if (function() {
                                    try {
                                        let e = window.localStorage.getItem(i);
                                        if (!e) return null;
                                        let t = JSON.parse(e),
                                            n = (0, o.wb)(String(t.code ? ? "")),
                                            r = Number(t.firstSeenAt);
                                        if (n.length < o.yq || !Number.isFinite(r)) return null;
                                        if (Date.now() - r > 1e3 * o.mZ) return function() {
                                            try {
                                                window.localStorage.removeItem(i)
                                            } catch {}
                                        }(), null;
                                        return {
                                            code: n,
                                            firstSeenAt: r
                                        }
                                    } catch {
                                        return null
                                    }
                                }()) return;
                            let e = {
                                code: t,
                                firstSeenAt: Date.now()
                            };
                            window.localStorage.setItem(i, JSON.stringify(e))
                        } catch {}
                    }(r), fetch("/api/referrals/track", {
                        method: "POST",
                        headers: {
                            "content-type": "application/json"
                        },
                        body: JSON.stringify({
                            code: r,
                            path: window.location.pathname,
                            visitorId: e,
                            sessionId: t,
                            utm: {
                                source: n.get("utm_source"),
                                medium: n.get("utm_medium"),
                                campaign: n.get("utm_campaign"),
                                content: n.get("utm_content"),
                                term: n.get("utm_term")
                            },
                            referrerHost: function() {
                                try {
                                    if (!document.referrer) return null;
                                    let e = new URL(document.referrer).hostname;
                                    return e && e !== window.location.hostname ? e : null
                                } catch {
                                    return null
                                }
                            }()
                        }),
                        keepalive: !0
                    }).catch(() => {}))
                }, []), null
            }
        },
        70288: (e, t, n) => {
            "use strict";
            n.d(t, {
                HomeMotionTier: () => i,
                r: () => o
            });
            var r = n(1521);

            function o(e) {
                return !!e.connection ? .saveData || "number" == typeof e.deviceMemory && e.deviceMemory <= 2 || "number" == typeof e.hardwareConcurrency && e.hardwareConcurrency > 0 && e.hardwareConcurrency <= 2
            }

            function i() {
                return (0, r.useEffect)(() => {
                    if (!o(navigator)) return;
                    let e = document.documentElement;
                    return e.dataset.homeMotion = "lite", () => {
                        delete e.dataset.homeMotion
                    }
                }, []), null
            }
        },
        72042: (e, t, n) => {
            Promise.resolve().then(n.t.bind(n, 43333, 23)), Promise.resolve().then(n.bind(n, 33488)), Promise.resolve().then(n.bind(n, 87547)), Promise.resolve().then(n.bind(n, 70288)), Promise.resolve().then(n.bind(n, 78448)), Promise.resolve().then(n.bind(n, 26700)), Promise.resolve().then(n.bind(n, 88544)), Promise.resolve().then(n.bind(n, 70097)), Promise.resolve().then(n.t.bind(n, 55275, 23)), Promise.resolve().then(n.t.bind(n, 78934, 23)), Promise.resolve().then(n.t.bind(n, 30664, 23))
        },
        78448: (e, t, n) => {
            "use strict";
            n.d(t, {
                AssetFallback: () => i
            });
            var r = n(1521),
                o = n(53180);

            function i() {
                return (0, r.useEffect)(() => {
                    let e = "r2Fallback";

                    function t(t) {
                        let n = t.target;
                        if (!(n instanceof HTMLImageElement) && !(n instanceof HTMLVideoElement) && !(n instanceof HTMLAudioElement) && !(n instanceof HTMLSourceElement) || n.dataset[e]) return;
                        let r = !1;
                        if (n.src && n.src.startsWith(o.T) && (n.src = n.src.replace(o.T, o.F), r = !0), (n instanceof HTMLSourceElement || n instanceof HTMLImageElement) && n.srcset.includes(o.T) && (n.srcset = n.srcset.replaceAll(o.T, o.F), r = !0), r) {
                            n.dataset[e] = "1";
                            let t = n.parentElement;
                            n instanceof HTMLSourceElement && (t instanceof HTMLVideoElement || t instanceof HTMLAudioElement) && t.load()
                        }
                    }
                    return document.addEventListener("error", t, !0), () => document.removeEventListener("error", t, !0)
                }, []), null
            }
        },
        78934: e => {
            e.exports = {
                style: {
                    fontFamily: "'Inter', 'Inter Fallback'",
                    fontStyle: "normal"
                },
                className: "__className_176161",
                variable: "__variable_176161"
            }
        },
        80937: (e, t, n) => {
            "use strict";
            n.d(t, {
                J2: () => i,
                M3: () => o
            });
            let r = "/linkverse";

            function o(e) {
                let t = (e ? ? "").toLowerCase().split(":")[0];
                return "linkverse.cutiepage.in" === t || "linkverse.localhost" === t
            }

            function i(e) {
                return e === r || e.startsWith(`${r}/`)
            }
        },
        87547: (e, t, n) => {
            "use strict";
            n.d(t, {
                TrackerScripts: () => b
            });
            var r = n(73365),
                o = n(1521),
                i = n(66961),
                a = n(41786),
                c = n(77547),
                s = n(76139);

            function u({
                hashedUserData: e
            }) {
                let t = (0, o.useRef)(!1);
                return (0, o.useEffect)(() => {
                    if (0 === Object.keys(e).length) return;

                    function n() {
                        return !!t.current || !!(0, s.sq)() && ((0, s.UW)(e), t.current = !0, !0)
                    }
                    let r = 0;
                    if (!n()) {
                        let e = 0;
                        r = window.setInterval(() => {
                            e += 1, (n() || e >= 20) && window.clearInterval(r)
                        }, 250)
                    }

                    function o() {
                        n()
                    }
                    return window.addEventListener(c.qH, o), () => {
                        r && window.clearInterval(r), window.removeEventListener(c.qH, o)
                    }
                }, [e]), null
            }

            function l() {
                let [e, t] = (0, o.useState)(null);
                return ((0, o.useEffect)(() => {
                    if (!(0, i.nj)().enabled || ! function() {
                            try {
                                return (0, a.Bz)((0, a.MB)(document.cookie)).length > 0
                            } catch {
                                return !1
                            }
                        }()) return;
                    let e = !1;
                    return fetch("/api/me/meta-matching", {
                        credentials: "same-origin"
                    }).then(e => e.ok ? e.json() : null).then(n => {
                        if (e) return;
                        let r = n ? .data ? .hashed;
                        r && "object" == typeof r && Object.keys(r).length > 0 && t(r)
                    }).catch(() => {}), () => {
                        e = !0
                    }
                }, []), e) ? (0, r.jsx)(u, {
                    hashedUserData: e
                }) : null
            }

            function d(e) {
                return window.addEventListener(c.qH, e), () => window.removeEventListener(c.qH, e)
            }

            function f() {
                let e = (0, o.useSyncExternalStore)(d, c.nG, () => !1),
                    t = (0, o.useCallback)(e => {
                        (0, c.eD)(e)
                    }, []);
                return e ? (0, r.jsx)("div", {
                    role: "dialog",
                    "aria-live": "polite",
                    "aria-label": "Cookie preferences",
                    className: "fixed inset-x-0 bottom-0 z-[9999] border-t border-black/10 bg-white/95 p-4 shadow-lg backdrop-blur md:p-5",
                    children: (0, r.jsxs)("div", {
                        className: "mx-auto flex max-w-4xl flex-col gap-3 md:flex-row md:items-center md:justify-between",
                        children: [(0, r.jsx)("p", {
                            className: "text-sm text-neutral-700",
                            children: "We use cookies to measure our ads and improve your experience. You can decline without affecting how the site works."
                        }), (0, r.jsxs)("div", {
                            className: "flex shrink-0 gap-2",
                            children: [(0, r.jsx)("button", {
                                type: "button",
                                onClick: () => t("denied"),
                                className: "rounded-full border border-neutral-300 px-4 py-2 text-sm font-medium text-neutral-700 transition hover:bg-neutral-100",
                                children: "Decline"
                            }), (0, r.jsx)("button", {
                                type: "button",
                                onClick: () => t("granted"),
                                className: "rounded-full bg-neutral-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-neutral-700",
                                children: "Accept"
                            })]
                        })]
                    })
                }) : null
            }
            var m = n(29717);

            function h() {
                let e = (0, m.usePathname)(),
                    t = (0, o.useRef)(null);
                return (0, o.useEffect)(() => {
                    function n() {
                        (0, s.fv)() && (t.current = window.location.pathname)
                    }
                    return (0, s.fv)() && (t.current = e), window.addEventListener(c.qH, n), () => {
                        window.removeEventListener(c.qH, n)
                    }
                }, []), (0, o.useEffect)(() => {
                    e && t.current !== e && (t.current = e, (0, s.oe)())
                }, [e]), null
            }
            var p = n(80937),
                w = n(21381),
                g = n(58975);
            let v = () => () => {};

            function y() {
                return (0, o.useEffect)(() => {
                    if ("function" != typeof window.gtag) return;
                    let e = () => {
                        (0, g.ZX)(function(e = "G-TG1WP8K1B1") {
                            return `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(e)}`
                        }())
                    };
                    return (0, g._J)(window.location.search) ? void e() : (0, g.C9)(e)
                }, []), null
            }

            function x() {
                try {
                    let {
                        host: e,
                        pathname: t
                    } = window.location;
                    return (0, w.du)(e) || (0, w.Ex)(t) || (0, p.M3)(e) || (0, p.J2)(t)
                } catch {
                    return !1
                }
            }

            function b() {
                let e = (0, o.useSyncExternalStore)(v, g.KC, () => !1),
                    t = (0, o.useSyncExternalStore)(v, x, () => !1);
                return !e || t ? null : (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(y, {}), (0, r.jsx)(o.Suspense, {
                        fallback: null,
                        children: (0, r.jsx)(h, {})
                    }), (0, r.jsx)(l, {}), (0, r.jsx)(f, {})]
                })
            }
        },
        88340: (e, t, n) => {
            "use strict";
            n.d(t, {
                Iu: () => c,
                dU: () => s
            });
            var r = n(1521),
                o = n(50068);
            let i = "cp_ref_sticky";

            function a() {
                try {
                    let e = new URLSearchParams(window.location.search).get(o.T$);
                    if (e) return e;
                    return window.sessionStorage.getItem(i)
                } catch {
                    try {
                        return new URLSearchParams(window.location.search).get(o.T$)
                    } catch {
                        return null
                    }
                }
            }

            function c(e) {
                try {
                    if (window.sessionStorage.getItem(i)) return;
                    window.sessionStorage.setItem(i, e)
                } catch {}
            }

            function s() {
                let e = (0, r.useSyncExternalStore)(u, a, () => null);
                return (0, r.useCallback)(t => e ? function(e, t) {
                    var n, r;
                    let i, a;
                    if (!e.startsWith("/") || e.startsWith("//")) return e;
                    let [c, s] = -1 === (i = (n = e).indexOf("#")) ? [n, ""] : [n.slice(0, i), n.slice(i)], [u, l] = -1 === (a = (r = c).indexOf("?")) ? [r, ""] : [r.slice(0, a), r.slice(a + 1)], d = new URLSearchParams(l);
                    return d.has(o.T$) ? e : (d.set(o.T$, t), `${u}?${d.toString()}${s}`)
                }(t, e) : t, [e])
            }

            function u() {
                return () => {}
            }
        },
        88544: (e, t, n) => {
            "use strict";
            n.d(t, {
                TopProgressBar: () => a
            });
            var r = n(73365),
                o = n(1521),
                i = n(29717);

            function a() {
                let e = (0, i.usePathname)(),
                    t = (0, i.useSearchParams)(),
                    [n, a] = (0, o.useState)(0),
                    [c, s] = (0, o.useState)(!1),
                    u = (0, o.useRef)(null),
                    l = (0, o.useRef)(null),
                    d = (0, o.useRef)(!1),
                    f = (0, o.useRef)(""),
                    m = () => {
                        u.current && (clearInterval(u.current), u.current = null), l.current && (clearTimeout(l.current), l.current = null)
                    },
                    h = () => {
                        d.current || (d.current = !0, m(), queueMicrotask(() => {
                            d.current && (s(!0), a(8))
                        }), u.current = setInterval(() => {
                            a(e => e >= 90 ? e : e + Math.max(.5, .08 * (90 - e)))
                        }, 200))
                    };
                return ((0, o.useEffect)(() => {
                    f.current = `${e}?${t?.toString()??""}`;
                    let n = e => {
                            let t;
                            if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || 0 !== e.button || e.defaultPrevented) return;
                            let n = e.target ? .closest("a");
                            if (!n) return;
                            let r = n.getAttribute("href");
                            if (!r || "_blank" === n.target || n.hasAttribute("download") || r.startsWith("#") || r.startsWith("mailto:") || r.startsWith("tel:") || n.getAttribute("rel") ? .includes("external")) return;
                            try {
                                t = new URL(r, window.location.href)
                            } catch {
                                return
                            }
                            if (t.origin !== window.location.origin) return;
                            let o = `${window.location.pathname}${window.location.search}`;
                            `${t.pathname}${t.search}` !== o && h()
                        },
                        r = window.history.pushState.bind(window.history);
                    window.history.pushState = function(...e) {
                        let t = e[2];
                        if (t) try {
                            let e = new URL(t, window.location.href),
                                n = `${window.location.pathname}${window.location.search}`;
                            `${e.pathname}${e.search}` !== n && h()
                        } catch {
                            h()
                        }
                        return r(...e)
                    };
                    let o = () => h();
                    return document.addEventListener("click", n, {
                        capture: !0
                    }), window.addEventListener("popstate", o), () => {
                        document.removeEventListener("click", n, {
                            capture: !0
                        }), window.removeEventListener("popstate", o), window.history.pushState = r
                    }
                }, [e, t]), (0, o.useEffect)(() => (d.current && (d.current = !1, m(), queueMicrotask(() => a(100)), l.current = setTimeout(() => {
                    s(!1), a(0)
                }, 280)), m), [e, t]), c) ? (0, r.jsx)("div", {
                    "aria-hidden": !0,
                    "data-top-progress": !0,
                    className: "pointer-events-none fixed inset-x-0 top-0 z-[10000] h-[2.5px]",
                    children: (0, r.jsx)("div", {
                        className: "h-full origin-left bg-[var(--color-primary,#D95D39)] shadow-[0_1px_4px_rgba(217,93,57,0.3)]",
                        style: {
                            width: `${n}%`,
                            transition: 100 === n ? "width 200ms cubic-bezier(0.4, 0, 0.2, 1), opacity 250ms ease-in-out 100ms" : "width 300ms cubic-bezier(0.1, 0.8, 0.1, 1)",
                            opacity: +(100 !== n)
                        }
                    })
                }) : null
            }
        }
    },
    e => {
        e.O(0, [88424, 27562, 7998, 21381, 76139, 2347, 15158, 77358], () => e(e.s = 72042)), _N_E = e.O()
    }
]);