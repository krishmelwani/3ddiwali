"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [80304], {
        6238: (e, t, i) => {
            i.d(t, {
                h: () => g
            });
            var a = i(1521),
                n = i(41786);
            let r = null,
                s = new Set,
                l = !1,
                c = !1;

            function o(e) {
                if (r !== e)
                    for (let t of (r = e, s)) t()
            }

            function p() {
                try {
                    return (0, n.hO)((0, n.MB)(document.cookie))
                } catch {
                    return !0
                }
            }

            function u() {
                c || (c = !0, Promise.all([i.e(74339), i.e(7998), i.e(16937), i.e(21381), i.e(63529)]).then(i.bind(i, 11062)).then(({
                    createSupabaseBrowserClient: e
                }) => {
                    let t;
                    try {
                        t = e()
                    } catch {
                        o(!1);
                        return
                    }
                    t.auth.getSession().then(({
                        data: e
                    }) => o(!!e.session)), t.auth.onAuthStateChange((e, t) => o(!!t))
                }).catch(() => {
                    c = !1, o(!1)
                }))
            }

            function d() {
                "hidden" !== document.visibilityState && p() && u()
            }

            function m(e) {
                return s.add(e), l ? !c && p() && u() : (l = !0, p() ? u() : queueMicrotask(() => {
                    c || o(!1)
                }), window.addEventListener("focus", d), document.addEventListener("visibilitychange", d)), () => {
                    s.delete(e)
                }
            }

            function g() {
                return {
                    isAuthed: (0, a.useSyncExternalStore)(m, () => r, () => null)
                }
            }
        },
        9710: (e, t, i) => {
            i.d(t, {
                l: () => c
            });
            var a = i(1521);
            let n = {
                    id: "boyfriends-day-2026",
                    slug: "girlfriends-day-v2",
                    priceInr: 149,
                    endsAtMs: Date.parse("2026-10-03T23:59:59Z") - 198e5,
                    copy: {
                        badge: "Special offer",
                        productNote: "Boyfriend's Day special offer: \u20b9149",
                        checkoutLabel: "Boyfriend's Day special offer"
                    }
                },
                r = { ...n,
                    id: "boyfriends-day-story-2026",
                    slug: "cp-boyfriends-day"
                },
                s = [n, r];

            function l() {
                return () => {}
            }

            function c(e, t) {
                return (0, a.useSyncExternalStore)(l, () => {
                    var i;
                    return i = Date.now(), e ? s.find(a => a.slug === e && i <= a.endsAtMs && t > 0 && t <= a.priceInr) ? ? null : null
                }, () => null)
            }
        },
        11831: (e, t, i) => {
            i.r(t), i.d(t, {
                CoverVideo: () => o
            });
            var a = i(73365),
                n = i(1521),
                r = i(54872);
            let s = "(prefers-reduced-motion: reduce)";

            function l() {
                let e = navigator.connection ? .saveData;
                return !window.matchMedia ? .(s).matches && !e
            }

            function c(e) {
                let t = window.matchMedia ? .(s);
                return t ? .addEventListener("change", e), () => t ? .removeEventListener("change", e)
            }

            function o({
                src: e,
                className: t
            }) {
                let i = (0, n.useRef)(null),
                    s = (0, n.useSyncExternalStore)(c, l, () => !1),
                    [p, u] = (0, n.useState)(!1),
                    [d, m] = (0, n.useState)(!1);
                return ((0, n.useEffect)(() => {
                    let e = i.current;
                    if (!s || !e || "u" < typeof IntersectionObserver) return;
                    let t = new IntersectionObserver(t => {
                        t.some(e => e.isIntersecting) ? (u(!0), e.play().catch(() => void 0)) : e.pause()
                    }, {
                        rootMargin: "200px 0px"
                    });
                    return t.observe(e), () => t.disconnect()
                }, [s]), s) ? (0, a.jsx)("video", {
                    ref: i,
                    src: p ? e : void 0,
                    muted: !0,
                    loop: !0,
                    playsInline: !0,
                    autoPlay: p,
                    preload: "none",
                    "aria-hidden": !0,
                    tabIndex: -1,
                    disablePictureInPicture: !0,
                    onLoadedData: () => m(!0),
                    className: (0, r.cn)("pointer-events-none absolute inset-0 h-full w-full object-cover transition-opacity duration-500 motion-reduce:transition-none", d ? "opacity-100" : "opacity-0", t)
                }) : null
            }
        },
        32420: (e, t, i) => {
            i.d(t, {
                M: () => s
            });
            var a = i(73365),
                n = i(18493),
                r = i(54872);

            function s({
                size: e = "sm",
                className: t,
                copy: i
            }) {
                let l = "md" === e;
                return (0, a.jsxs)("span", {
                    className: (0, r.cn)("relative inline-flex items-center overflow-hidden rounded-md bg-cp-primary font-semibold text-white", l ? "gap-1.5 px-2.5 py-1 text-[13px]" : "gap-1 px-1.5 py-0.5 text-[9px] uppercase tracking-wide sm:text-[10px]", t),
                    children: [(0, a.jsx)(n.A, {
                        className: (0, r.cn)("shrink-0", l ? "size-3.5" : "size-2.5 sm:size-3"),
                        "aria-hidden": "true"
                    }), l ? i.productNote : i.badge, (0, a.jsx)("span", {
                        "aria-hidden": "true",
                        className: "pointer-events-none absolute inset-0 -translate-x-full animate-shine bg-gradient-to-r from-transparent via-white/40 to-transparent"
                    })]
                })
            }
        },
        41786: (e, t, i) => {
            function a(e) {
                let t = new Set;
                for (let i of e) i.startsWith("sb-") && t.add(i);
                return [...t]
            }

            function n(e) {
                return e.some(r)
            }

            function r(e) {
                return e.startsWith("sb-") && (e.endsWith("-auth-token") || /-auth-token\.\d+$/.test(e))
            }

            function s(e) {
                return [...new Set(e.filter(r))]
            }

            function l(e) {
                return e ? e.split(";").map(e => e.split("=")[0] ? .trim()).filter(e => !!e) : []
            }
            i.d(t, {
                Bz: () => a,
                MB: () => l,
                hO: () => n,
                tr: () => s
            })
        },
        45421: (e, t, i) => {
            i.d(t, {
                BT: () => c,
                Wu: () => o,
                ZB: () => l,
                Zp: () => r,
                aR: () => s
            });
            var a = i(73365);
            i(1521);
            var n = i(54872);

            function r({
                className: e,
                interactive: t = !1,
                ...i
            }) {
                return (0, a.jsx)("div", {
                    className: (0, n.cn)("rounded-xl border border-cp-line bg-cp-bg text-cp-ink transition-[border-color,box-shadow] duration-200 motion-reduce:transition-none", t && "hover:border-cp-line-strong hover:shadow-cp-float", e),
                    ...i
                })
            }

            function s({
                className: e,
                ...t
            }) {
                return (0, a.jsx)("div", {
                    className: (0, n.cn)("space-y-1.5 p-6", e),
                    ...t
                })
            }

            function l({
                className: e,
                ...t
            }) {
                return (0, a.jsx)("h3", {
                    className: (0, n.cn)("text-[17px] font-semibold tracking-[-0.01em] text-balance text-cp-ink", e),
                    ...t
                })
            }

            function c({
                className: e,
                ...t
            }) {
                return (0, a.jsx)("p", {
                    className: (0, n.cn)("text-sm leading-6 text-cp-muted", e),
                    ...t
                })
            }

            function o({
                className: e,
                ...t
            }) {
                return (0, a.jsx)("div", {
                    className: (0, n.cn)("p-6 pt-0", e),
                    ...t
                })
            }
        },
        50068: (e, t, i) => {
            i.d(t, {
                T$: () => n,
                mZ: () => a,
                wb: () => s,
                yq: () => r
            });
            let a = 2592e3,
                n = "ref",
                r = 4;

            function s(e) {
                return e.trim().toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 32)
            }
        },
        61716: (e, t, i) => {
            i.d(t, {
                m: () => s,
                S: () => r
            });
            let a = {
                "/static/anniversary-special-cover.jpg": {
                    avif: [640, 1280, 1920],
                    webp: [640, 1280, 1920]
                },
                "/static/anniversary-special.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/apology.jpg": {
                    avif: [640, 1280, 1920],
                    webp: [640, 1280, 1920]
                },
                "/static/bday-wish-4.jpg": {
                    avif: [640, 1280, 1920],
                    webp: [640, 1280, 1920]
                },
                "/static/bday-wish1-cover.jpg": {
                    avif: [640, 1280, 1920],
                    webp: [640, 1280, 1920]
                },
                "/static/bday-wish1.jpg": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/birthday-wish4-v2.png": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/cashfree.png": {
                    avif: [640, 1280, 1920],
                    webp: [640, 1280, 1920]
                },
                "/static/catalog/covers/anniversary.webp": {
                    avif: [640],
                    webp: [640]
                },
                "/static/catalog/covers/apology.webp": {
                    avif: [640],
                    webp: [640]
                },
                "/static/catalog/covers/birthday.webp": {
                    avif: [640],
                    webp: [640]
                },
                "/static/catalog/covers/family.webp": {
                    avif: [640],
                    webp: [640]
                },
                "/static/catalog/covers/festival.webp": {
                    avif: [640],
                    webp: [640]
                },
                "/static/catalog/covers/friendship.webp": {
                    avif: [640],
                    webp: [640]
                },
                "/static/catalog/covers/love.webp": {
                    avif: [640],
                    webp: [640]
                },
                "/static/catalog/covers/wedding.webp": {
                    avif: [640],
                    webp: [640]
                },
                "/static/cute-birthday.jpg": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/cutiecoin.jpeg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/logo.webp": {
                    avif: [256],
                    webp: [256]
                },
                "/static/products/birthday-wish1.jpg": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/products/birthday-wish2.jpg": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/products/cutiepack.jpg": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/products/cutiepack499.png": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/products/wish1.jpg": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/reviews/review1.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review10.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review11.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review12.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review13.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review14.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review2.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review3.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review4.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review5.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review6.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review7.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review8.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/reviews/review9.jpg": {
                    avif: [640],
                    webp: [640]
                },
                "/static/special-apology.jpg": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/special-apology.webp": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/sweet-birthday.webp": {
                    avif: [640, 1280],
                    webp: [640, 1280]
                },
                "/static/template-showcase.jpg": {
                    avif: [640],
                    webp: [640]
                }
            };

            function n(e) {
                if (!e.startsWith("https://cdn.cutiepage.in")) return null;
                try {
                    return new URL(e).pathname
                } catch {
                    return null
                }
            }

            function r(e) {
                let t = n(e);
                return !!t && t in a
            }

            function s(e, t) {
                let i = n(e);
                if (!i) return null;
                let r = a[i] ? .[t];
                return r ? .length ? r.map(i => `${e}.${i}.${t} ${i}w`).join(", ") : null
            }
        },
        80304: (e, t, i) => {
            i.d(t, {
                TemplateCard: () => E
            });
            var a = i(73365),
                n = i(86714),
                r = i(99568),
                s = i.n(r),
                l = i(90925),
                c = i(94612),
                o = i(9388),
                p = i(45421),
                u = i(26752),
                d = i(84346),
                m = i(1521),
                g = i(6238),
                f = i(70414),
                v = i(29359),
                w = i(32420),
                b = i(11831);
            let h = "https://cdn.cutiepage.in",
                x = {
                    "cp-world-diwali": `${h}/static/worlds/cp-world-diwali/preview-v3.mp4`,
                    "cp-world-park": `${h}/static/worlds/cp-world-park/preview-v1.mp4`,
                    "cp-world-river": `${h}/static/worlds/cp-world-river/preview-v1.mp4`,
                    "cp-world-rain": `${h}/static/worlds/cp-world-rain/preview-v1.mp4`,
                    "cp-world-rooftop": `${h}/static/worlds/cp-world-rooftop/preview-v1.mp4`,
                    "cp-world-bhai-dooj": `${h}/static/worlds/cp-world-bhai-dooj/preview-v1.mp4`,
                    "cp-diya": `${h}/static/previews/cp-diya/preview-v1.mp4`,
                    "cp-diwali-dabba": `${h}/static/previews/cp-diwali-dabba/preview-v1.mp4`
                };
            var y = i(9710),
                j = i(88340);
            let N = {
                    birthday: {
                        min: 1e3,
                        max: 1500
                    }
                },
                A = {
                    "birthday-surprise": 5
                },
                _ = {
                    "couples-day": {
                        min: 100,
                        max: 150
                    },
                    "couples-day-v2": {
                        min: 100,
                        max: 150
                    },
                    "raksha-bandhan": {
                        min: 100,
                        max: 150
                    }
                },
                S = {
                    min: 200,
                    max: 700
                };

            function k(e) {
                let t = 0;
                for (let i = 0; i < e.length; i += 1) t = (t << 5) - t + e.charCodeAt(i) | 0;
                return Math.abs(t)
            }
            S.min;
            let I = {
                "anniversary-special": 4.5,
                "bday-wish-3": 4.5
            };
            var C = i(54872);
            let $ = (0, n.default)(() => Promise.all([i.e(76981), i.e(93602), i.e(7998), i.e(85319), i.e(34768), i.e(76347), i.e(4136)]).then(i.bind(i, 10454)), {
                loadableGenerated: {
                    webpack: () => [10454]
                },
                ssr: !1,
                loading: () => (0, a.jsx)("span", {
                    "aria-hidden": !0,
                    className: "absolute inset-0 bg-cp-night"
                })
            });

            function E({
                template: e,
                detailLabel: t = u.O.productsPage.grid.previewCta,
                compactOnDesktop: i = !1,
                hideOffer: n = !1,
                minimal: r = !1,
                hideDescription: h = !1,
                href: T,
                videoPreview: B = !1
            }) {
                var M, P, L, O, F;
                let R, z, G, {
                        isAuthed: U
                    } = (0, g.h)(),
                    Z = (0, f.G5)(e.priceInr),
                    D = (0, v.ax)(e.slug),
                    Q = (0, y.l)(e.slug, e.priceInr),
                    W = null !== D,
                    q = n || W || (0, f.TH)(e.slug, e.pricingModel) ? { ...Z,
                        hasOffer: !1,
                        compareAtInr: null,
                        discountPercent: null
                    } : Z,
                    V = e.ratingCount ? ? 0,
                    X = e.ratingAvg ? ? 0,
                    J = V > 0 && X > 0,
                    H = J ? null : e.ratingFrom ? ? null,
                    K = H ? ? {
                        id: e.id,
                        slug: e.slug,
                        category: e.category,
                        ratingAvg: X,
                        ratingCount: V
                    },
                    Y = H ? (H.ratingCount ? ? 0) > 0 && (H.ratingAvg ? ? 0) > 0 : J,
                    ee = Y ? null : (R = k(K.id), z = Math.round(4.0000000000000036), G = 15 + Math.floor(R / 97) % 16, {
                        ratingAvg: Number((4.5 + R % (z + 1) / 10).toFixed(1)),
                        ratingCount: G
                    }),
                    et = Y ? function(e, t) {
                        if (!Number.isFinite(e)) return e;
                        let i = null != t ? I[t] : void 0;
                        return void 0 === i ? e : Math.max(e, i)
                    }(K.ratingAvg ? ? 0, K.slug) : ee.ratingAvg,
                    ei = (M = K.ratingCount, P = K.id, L = K.category, O = K.slug, (Number.isFinite(M) && M > 0 ? M : 0) + function(e, t, i) {
                        if (null != i && i in A) return A[i];
                        let a = null != i && i in _ ? _[i] : t ? N[t.trim().toLowerCase()] ? ? S : S,
                            n = a.max - a.min + 1;
                        return a.min + Math.floor(k(e) / 13) % n
                    }(P, L, O)),
                    ea = (0, j.dU)(),
                    en = ea(T || (U ? `/dashboard/templates/${e.slug}/start` : `/try/${e.slug}`)),
                    er = ea(T ? ? `/templates/${e.slug}`),
                    es = B ? null : Object.hasOwn(x, F = e.slug) ? x[F] : null,
                    el = {
                        name: e.name,
                        priceInr: e.priceInr,
                        category: e.category
                    },
                    ec = function(e, t = "listing", i) {
                        let [a, n] = (0, m.useState)(null), r = (0, m.useRef)(!1), s = (0, m.useRef)(i);
                        (0, m.useEffect)(() => {
                            s.current = i
                        });
                        let l = (0, m.useCallback)(e => {
                            n(e)
                        }, []);
                        return (0, m.useEffect)(() => {
                            if (!a || !e || r.current || "u" < typeof IntersectionObserver) return;
                            let i = null,
                                n = new IntersectionObserver(a => {
                                    for (let l of a) l.isIntersecting ? null !== i || r.current || (i = setTimeout(() => {
                                        r.current || (r.current = !0, (0, d.B_)({ ...s.current,
                                            slug: e
                                        }, t), n.disconnect())
                                    }, 1e3)) : null !== i && (clearTimeout(i), i = null)
                                }, {
                                    threshold: .5
                                });
                            return n.observe(a), () => {
                                null !== i && clearTimeout(i), n.disconnect()
                            }
                        }, [a, e, t]), l
                    }(e.slug, "listing", el),
                    eo = () => (0, d.Vd)({ ...el,
                        slug: e.slug
                    }, "listing");
                return (0, a.jsx)("div", {
                    ref: ec,
                    className: "h-full",
                    children: (0, a.jsxs)(p.Zp, {
                        className: (0, C.cn)("group flex h-full flex-col overflow-hidden rounded-3xl border border-cp-line bg-cp-bg shadow-none transition-colors duration-150 hover:border-cp-line-strong"),
                        children: [B ? (0, a.jsx)("div", {
                            className: "p-1.5 sm:p-2",
                            children: (0, a.jsxs)("div", {
                                className: "relative aspect-[9/16] overflow-hidden rounded-2xl bg-cp-night",
                                children: [(0, a.jsx)($, {
                                    videoKey: e.slug
                                }), e.badgeLabel ? (0, a.jsx)("span", {
                                    className: "absolute top-2 left-2 rounded-full bg-cp-primary px-2 py-0.5 text-[10px] leading-4 font-semibold text-white shadow-cp-float sm:top-2.5 sm:left-2.5 sm:text-[11px]",
                                    children: e.badgeLabel
                                }) : null]
                            })
                        }) : null, (0, a.jsxs)(s(), {
                            href: er,
                            onClick: eo,
                            className: (0, C.cn)("block p-1.5 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-cp-select sm:p-2", B ? "pt-0 sm:pt-0" : "rounded-t-3xl"),
                            children: [B ? null : (0, a.jsxs)("div", {
                                className: (0, C.cn)("relative aspect-[16/11] overflow-hidden rounded-2xl bg-cp-canvas", i && "lg:aspect-[16/10]"),
                                children: [(0, a.jsx)(c.BlurImage, {
                                    src: e.thumbnailUrl,
                                    alt: `${e.name} template preview`,
                                    fill: !0,
                                    sizes: "(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw",
                                    className: "object-cover transition-transform duration-300 ease-out group-hover:scale-[1.03] motion-reduce:transition-none"
                                }), es ? (0, a.jsx)(b.CoverVideo, {
                                    src: es
                                }) : null, e.badgeLabel ? (0, a.jsx)("span", {
                                    className: "absolute top-2 left-2 rounded-full bg-cp-primary px-2 py-0.5 text-[10px] leading-4 font-semibold text-white shadow-cp-float sm:top-2.5 sm:left-2.5 sm:text-[11px]",
                                    children: e.badgeLabel
                                }) : null]
                            }), (0, a.jsx)(p.aR, {
                                className: (0, C.cn)("flex-1 space-y-0 px-1.5 pt-3 pb-0 sm:px-2 sm:pt-3.5", i && "lg:px-1.5"),
                                children: (0, a.jsxs)("div", {
                                    className: "min-w-0",
                                    children: [(0, a.jsx)(p.ZB, {
                                        className: "truncate font-sans text-[14px] leading-5 font-semibold tracking-[-0.015em] text-cp-ink sm:text-[16px] sm:leading-6",
                                        children: e.name
                                    }), r || h ? null : (0, a.jsx)(p.BT, {
                                        className: "mt-1 line-clamp-2 min-h-[2.25rem] text-[12px] leading-[1.125rem] text-cp-muted sm:min-h-[2.5rem] sm:text-[13px] sm:leading-5",
                                        children: e.description
                                    })]
                                })
                            })]
                        }), (0, a.jsxs)(p.Wu, {
                            className: (0, C.cn)("@container mt-auto px-3 pt-2.5 pb-3 sm:px-4 sm:pb-4", i && "lg:px-3.5 lg:pb-3.5"),
                            children: [(0, a.jsxs)("div", {
                                className: "flex items-center gap-1 text-[11px] tabular-nums sm:text-[12px]",
                                children: [r ? (0, a.jsx)(l.A, {
                                    strokeWidth: 1.75,
                                    "aria-hidden": !0,
                                    className: "size-3 fill-cp-warning text-cp-warning"
                                }) : (0, a.jsx)("div", {
                                    className: "flex items-center gap-px",
                                    children: Array.from({
                                        length: 5
                                    }).map((e, t) => (0, a.jsx)(l.A, {
                                        strokeWidth: 1.75,
                                        "aria-hidden": !0,
                                        className: (0, C.cn)("size-3", t < Math.round(et) ? "fill-cp-warning text-cp-warning" : "text-cp-faint")
                                    }, t))
                                }), (0, a.jsx)("span", {
                                    className: "ml-0.5 font-semibold text-cp-ink",
                                    children: et.toFixed(1)
                                }), (0, a.jsxs)("span", {
                                    className: "text-cp-muted",
                                    children: ["(", ei.toLocaleString("en-IN"), ")"]
                                }), H ? (0, a.jsxs)("span", {
                                    className: "min-w-0 truncate text-cp-muted",
                                    children: ["\xb7 ", H.label]
                                }) : null]
                            }), (0, a.jsxs)("div", {
                                className: (0, C.cn)("flex flex-wrap items-center gap-x-2 gap-y-1", r ? "mt-2" : "mt-3"),
                                children: [(0, a.jsx)("span", {
                                    className: "text-[16px] leading-6 font-semibold tracking-[-0.02em] text-cp-ink tabular-nums sm:text-[19px]",
                                    children: q.isFree ? "FREE" : (0, f.Dh)(q.priceInr)
                                }), q.hasOffer && null !== q.compareAtInr ? (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)("span", {
                                        className: "text-[12px] text-cp-muted tabular-nums line-through decoration-cp-muted/60 sm:text-[13px]",
                                        children: (0, f.Dh)(q.compareAtInr)
                                    }), (0, a.jsxs)("span", {
                                        className: "rounded-full bg-cp-success/10 px-2 py-0.5 text-[10px] leading-4 font-semibold text-cp-success-ink sm:text-[11px]",
                                        children: [q.discountPercent, "% off"]
                                    })]
                                }) : null, D ? (0, a.jsx)(w.M, {
                                    copy: D.copy
                                }) : null, Q && !D ? (0, a.jsx)(w.M, {
                                    copy: Q.copy
                                }) : null, q.isFree || q.hasOffer || W ? null : (0, a.jsx)("span", {
                                    className: "text-[11px] text-cp-muted",
                                    children: u.O.productsPage.grid.priceSuffix
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "mt-3.5 grid gap-2 @[13.5rem]:grid-cols-[auto_1fr]",
                                children: [(0, a.jsx)(o.$, {
                                    asChild: !0,
                                    variant: "secondary",
                                    size: "sm",
                                    className: "h-10 w-full min-w-0 rounded-xl border border-cp-line-strong bg-cp-bg px-4 text-[13px] text-cp-ink hover:border-cp-ink/30 hover:bg-cp-subtle sm:h-9",
                                    children: (0, a.jsx)(s(), {
                                        href: er,
                                        onClick: eo,
                                        children: t
                                    })
                                }), (0, a.jsx)(o.$, {
                                    asChild: !0,
                                    variant: "primary",
                                    size: "sm",
                                    className: "h-10 w-full min-w-0 rounded-xl px-3 text-[13px] font-semibold sm:h-9",
                                    children: (0, a.jsx)(s(), {
                                        href: en,
                                        prefetch: !1,
                                        onClick: () => (0, d.Zi)({ ...el,
                                            slug: e.slug
                                        }, "card"),
                                        children: u.O.productsPage.grid.customizeCta
                                    })
                                })]
                            })]
                        })]
                    })
                })
            }
        },
        84346: (e, t, i) => {
            i.d(t, {
                $r: () => d,
                Ag: () => m,
                B_: () => l,
                TX: () => p,
                Vd: () => c,
                YW: () => g,
                Zi: () => u,
                sF: () => f,
                y8: () => o
            });
            var a = i(37809),
                n = i(81042);

            function r(e) {
                return "number" == typeof e.priceInr ? {
                    value: e.priceInr,
                    currency: n.bg
                } : {}
            }

            function s(e) {
                return e.templateSlug ? [(0, n.Hq)({
                    slug: e.templateSlug,
                    name: e.templateName,
                    priceInr: e.valueInr
                })] : []
            }

            function l(e, t) {
                (0, a.zy)(e.slug, t), (0, n.kD)(e, t)
            }

            function c(e, t) {
                (0, n.$m)("select_item", {
                    item_list_id: t,
                    item_list_name: t,
                    items: [(0, n.Hq)(e, {
                        item_list_name: t
                    })]
                })
            }

            function o(e) {
                (0, a.G4)({
                    name: "template_view",
                    template_slug: e.slug
                }), (0, n.$m)("view_item", { ...r(e),
                    items: [(0, n.Hq)(e)]
                })
            }

            function p(e) {
                let t = (e.priceInr ? ? 0) > 0 ? "paid" : "free";
                (0, a.G4)({
                    name: "preview_open",
                    template_slug: e.slug,
                    props: {
                        tier: t
                    }
                }), (0, n.$m)("preview_open", {
                    template_slug: e.slug,
                    items: [(0, n.Hq)(e)]
                })
            }

            function u(e, t) {
                (0, a.G4)({
                    name: "template_cta_click",
                    template_slug: e.slug,
                    props: {
                        surface: t
                    }
                }), (0, n.$m)("add_to_cart", { ...r(e),
                    cta_surface: t,
                    items: [(0, n.Hq)(e)]
                }), (0, a.Sm)(!0)
            }

            function d(e) {
                (0, a.G4)({
                    name: "checkout_start",
                    template_slug: e.templateSlug ? ? void 0,
                    project_id: e.projectId,
                    props: {
                        value_inr: e.valueInr
                    }
                }), (0, n.$m)("begin_checkout", {
                    value: e.valueInr,
                    currency: n.bg,
                    items: s(e)
                })
            }

            function m(e, t) {
                (0, a.G4)({
                    name: "payment_start",
                    template_slug: e.templateSlug ? ? void 0,
                    project_id: e.projectId,
                    props: {
                        provider: t,
                        value_inr: e.valueInr
                    }
                }), (0, n.$m)("add_payment_info", {
                    value: e.valueInr,
                    currency: n.bg,
                    payment_type: t,
                    items: s(e)
                })
            }

            function g(e, t, i, r) {
                let s = {
                    provider: i,
                    value_inr: e.valueInr
                };
                r && (s.stage = r), (0, a.G4)({
                    name: `payment_${t}`,
                    template_slug: e.templateSlug ? ? void 0,
                    project_id: e.projectId,
                    props: s
                }), "success" !== t && (0, n.$m)(`payment_${t}`, {
                    payment_type: i,
                    failure_stage: r,
                    template_slug: e.templateSlug ? ? void 0
                })
            }

            function f(e, t, i, n) {
                let r = {
                    surface: t,
                    in_app_browser: i
                };
                n && (r.stage = n), (0, a.G4)({
                    name: e,
                    props: r
                }), "auth_google_click" === e && (0, a.Sm)(!0)
            }
        },
        88340: (e, t, i) => {
            i.d(t, {
                Iu: () => l,
                dU: () => c
            });
            var a = i(1521),
                n = i(50068);
            let r = "cp_ref_sticky";

            function s() {
                try {
                    let e = new URLSearchParams(window.location.search).get(n.T$);
                    if (e) return e;
                    return window.sessionStorage.getItem(r)
                } catch {
                    try {
                        return new URLSearchParams(window.location.search).get(n.T$)
                    } catch {
                        return null
                    }
                }
            }

            function l(e) {
                try {
                    if (window.sessionStorage.getItem(r)) return;
                    window.sessionStorage.setItem(r, e)
                } catch {}
            }

            function c() {
                let e = (0, a.useSyncExternalStore)(o, s, () => null);
                return (0, a.useCallback)(t => e ? function(e, t) {
                    var i, a;
                    let r, s;
                    if (!e.startsWith("/") || e.startsWith("//")) return e;
                    let [l, c] = -1 === (r = (i = e).indexOf("#")) ? [i, ""] : [i.slice(0, r), i.slice(r)], [o, p] = -1 === (s = (a = l).indexOf("?")) ? [a, ""] : [a.slice(0, s), a.slice(s + 1)], u = new URLSearchParams(p);
                    return u.has(n.T$) ? e : (u.set(n.T$, t), `${o}?${u.toString()}${c}`)
                }(t, e) : t, [e])
            }

            function o() {
                return () => {}
            }
        },
        94612: (e, t, i) => {
            i.r(t), i.d(t, {
                BlurImage: () => c
            });
            var a = i(73365),
                n = i(58872),
                r = i(1521),
                s = i(61716),
                l = i(54872);

            function c({
                onLoad: e,
                onError: t,
                ...i
            }) {
                let [o, p] = (0, r.useState)(!1), [u, d] = (0, r.useState)(!1), m = (0, r.useCallback)(e => {
                    if (!e) return;
                    let t = () => {
                        p(!0), d(!0)
                    };
                    e.complete && e.naturalWidth > 0 ? t() : (e.addEventListener("load", t, {
                        once: !0
                    }), e.addEventListener("error", t, {
                        once: !0
                    }))
                }, []);
                (0, r.useEffect)(() => {
                    if (!o || u) return;
                    let e = setTimeout(() => d(!0), 750);
                    return () => clearTimeout(e)
                }, [o, u]);
                let g = "string" == typeof i.src ? i.src : null,
                    f = g ? (0, s.m)(g, "avif") : null,
                    v = g ? (0, s.m)(g, "webp") : null,
                    w = "string" == typeof i.sizes ? i.sizes : void 0,
                    b = !!(f || v),
                    {
                        priority: h,
                        ...x
                    } = i,
                    y = (0, a.jsx)(n.default, { ...x,
                        ...b ? {
                            loading: "eager",
                            fetchPriority: "high"
                        } : {
                            priority: h
                        },
                        ref: m,
                        onLoad: t => {
                            p(!0), d(!0), e ? .(t)
                        },
                        onError: e => {
                            p(!0), d(!0), t ? .(e)
                        }
                    }),
                    j = b ? (0, a.jsxs)("picture", {
                        style: {
                            display: "contents",
                            position: "relative"
                        },
                        children: [h && f ? (0, a.jsx)("link", {
                            rel: "preload",
                            as: "image",
                            type: "image/avif",
                            imageSrcSet: f,
                            imageSizes: w,
                            fetchPriority: "high"
                        }) : null, f ? (0, a.jsx)("source", {
                            type: "image/avif",
                            srcSet: f,
                            sizes: w
                        }) : null, v ? (0, a.jsx)("source", {
                            type: "image/webp",
                            srcSet: v,
                            sizes: w
                        }) : null, y]
                    }) : y;
                return (0, a.jsxs)(a.Fragment, {
                    children: [j, !u && (0, a.jsx)("div", {
                        "aria-hidden": !0,
                        className: (0, l.cn)("pointer-events-none absolute inset-0 overflow-hidden bg-cover bg-center transition-opacity duration-700 ease-out", o && "opacity-0"),
                        style: {
                            backgroundImage: 'url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAABaElEQVR4nCxSi63EMAgzn+T2n+gN8Ea6Bs4mrRBCjXGMSfb/H85BFZqfwb0tOxTIPXkpR5rz1FJoNQjesGajTy0Ghjecv0CucCMZeEJ01XtsVm1VXhGNqI7uQClbmQUbLrfQJl0Wx6IsD7I6q5RR2RVEG//CDFTSDK+hPL0eLOZTu5xZM1g42BBI6cZV4iQ7WF9Csb/9ObaJPi56lJPeaQE1zJReEpNP70FPYEtb3wajS6KkX3eAlmgq+XwVt4FX5eEA5lTOpIbOBaBgxbPeDwewF626aUAU/efXcpc3rJ6hST+xNa7QlMeR4pToaZ/NYhJrTc0F0YDpqXydbT+aT3SSVJRCUCxco2aGlvda0yxRC6ZaAtAYGPeQqUauUwu6e523UGLl5SbBuF26wSKmFMiWXovRcqKdLCMes9upyZB6Uip8wpyPsmSfjywBZfpF0yw2+DgQGmKgXKfQ3E619PO2vu+HlN4/AAAA//+96j/fAAAABklEQVQDAMyHNORyzuJDAAAAAElFTkSuQmCC")'
                        },
                        onTransitionEnd: () => d(!0),
                        children: (0, a.jsx)("div", {
                            className: "absolute inset-0 animate-img-shimmer bg-[linear-gradient(100deg,transparent_32%,rgba(255,255,255,0.5)_50%,transparent_68%)] motion-reduce:animate-none"
                        })
                    })]
                })
            }
        }
    }
]);