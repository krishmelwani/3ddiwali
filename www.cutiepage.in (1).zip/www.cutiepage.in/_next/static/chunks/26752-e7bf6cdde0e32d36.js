"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [26752], {
        26752: (e, t, a) => {
            a.d(t, {
                O: () => i
            });
            let i = {
                site: {
                    name: "Cutiepage",
                    description: "Cutiepage is India's best digital gifting platform, trusted by 70,000+ users. Loved by couples, families, brothers and sisters, husbands and wives, and professionals. Create a customisable website gift for birthdays, anniversaries, Rakhi, and every big moment. Pick a design, add your words and photos, and share a private link in about 30 seconds.",
                    supportEmail: "support@cutiepage.in",
                    defaultTitle: "Heartfelt pages for your biggest moments"
                },
                header: {
                    navItems: [{
                        href: "/",
                        label: "Home",
                        xlOnly: !0
                    }, {
                        href: "/products",
                        label: "Templates"
                    }, {
                        href: "/collections/mini-cutievideos",
                        label: "Videos"
                    }, {
                        href: "/reviews",
                        label: "Reviews"
                    }, {
                        href: "/rewards",
                        label: "Rewards"
                    }, {
                        href: "/contact",
                        label: "Contact"
                    }],
                    loginCta: "Login",
                    dashboardCta: "Dashboard",
                    primaryCta: "Make yours",
                    mobileMenuLabel: "Toggle menu",
                    announcementBar: {
                        line1: "Cutiepage is now 70,000+ Users strong with 20,000+ Orders!",
                        line2: "Bhai Dooj special \uD83E\uDE94 Make a cute gift page for your brother or sister",
                        line3: "Make it first, pay later \xb7 Ready in about 30 seconds"
                    }
                },
                footer: {
                    blurb: "Cutiepage is India's best digital gifting platform, trusted by 70,000+ users. Loved by couples, families, brothers and sisters, husbands and wives, and professionals. Create a customisable website gift for birthdays, anniversaries, Rakhi, and every big moment. Pick a design, add your words and photos, and share a private link in about 30 seconds.",
                    linkGroups: {
                        Product: [{
                            label: "Templates",
                            href: "/products"
                        }, {
                            label: "How it works",
                            href: "/#how-it-works"
                        }, {
                            label: "Reviews",
                            href: "/reviews"
                        }, {
                            label: "Rewards",
                            href: "/rewards"
                        }],
                        Company: [{
                            label: "About",
                            href: "/about"
                        }, {
                            label: "Collab",
                            href: "/collab"
                        }, {
                            label: "Earn with us",
                            href: "/earn-with-us"
                        }],
                        Support: [{
                            label: "Contact",
                            href: "/contact"
                        }, {
                            label: "Copyright",
                            href: "/copyright-policy"
                        }, {
                            label: "Creator Terms",
                            href: "/creator-terms"
                        }, {
                            label: "Creator Reselling",
                            href: "/creator-reselling-policy"
                        }, {
                            label: "Privacy Policy",
                            href: "/privacy-policy"
                        }, {
                            label: "Refund & shipping",
                            href: "/refund-shipping-policy"
                        }, {
                            label: "Terms of Service",
                            href: "/terms-services"
                        }],
                        Resources: [{
                            label: "Blog",
                            href: "/blog"
                        }, {
                            label: "Guides",
                            href: "/guides"
                        }, {
                            label: "Website for girlfriend",
                            href: "/guides/website-for-girlfriend"
                        }, {
                            label: "Website for boyfriend",
                            href: "/guides/website-for-boyfriend"
                        }, {
                            label: "Birthday website",
                            href: "/guides/birthday-website-for-girlfriend"
                        }, {
                            label: "Anniversary website",
                            href: "/guides/anniversary-website"
                        }, {
                            label: "Website for wife",
                            href: "/guides/website-for-wife"
                        }, {
                            label: "Long distance gifts",
                            href: "/guides/long-distance-relationship-gift"
                        }, {
                            label: "Website for couples",
                            href: "/guides/personal-website-builder-for-couples"
                        }, {
                            label: "Durga Puja proposal",
                            href: "/collections/durgapuja"
                        }, {
                            label: "Durga Puja invite",
                            href: "/collections/durgapuja-invite"
                        }, {
                            label: "Navratri proposal",
                            href: "/collections/navratri"
                        }, {
                            label: "Navratri invite",
                            href: "/collections/navratri-invite"
                        }, {
                            label: "Festival templates",
                            href: "/festival-templates"
                        }]
                    },
                    giftsLinkGroup: [{
                        label: "Shop gifts",
                        href: "/products?type=gifts"
                    }, {
                        label: "Mugs",
                        href: "/products?type=gifts&category=mugs"
                    }, {
                        label: "Photo frames",
                        href: "/products?type=gifts&category=frames"
                    }, {
                        label: "Hampers",
                        href: "/products?type=gifts&category=hampers"
                    }],
                    socialLinks: [{
                        label: "Instagram",
                        href: "https://instagram.com/cutiepage.in"
                    }, {
                        label: "LinkedIn",
                        href: "https://www.linkedin.com/company/cutiepage-technologies-private-limited"
                    }],
                    copyrightSuffix: "Made with care."
                },
                home: {
                    hero: {
                        badge: "India's best digital gifting platform",
                        title: "Create a personalised website gift and share it as a link.",
                        descriptionPoints: ["Beautifully crafted designs, ready in seconds", "Add your own words, photos, and moments", "Share a single link, anywhere, with anyone", "Privacy first: lock your page behind a password", "No coding, no setup, no design skills needed"],
                        features: [{
                            icon: "badge-check",
                            label: "Ad-free experience"
                        }, {
                            icon: "lock",
                            label: "Password protected"
                        }, {
                            icon: "qr",
                            label: "Live QR code"
                        }, {
                            icon: "code",
                            label: "No coding required"
                        }, {
                            icon: "clock",
                            label: "Make in 30 seconds"
                        }],
                        primaryCta: "See the templates",
                        secondaryCta: "How it works",
                        stats: [{
                            value: "15+",
                            label: "designs to choose from"
                        }, {
                            value: "Pay once",
                            label: "use multiple times"
                        }, {
                            value: "Instant",
                            label: "ready to share!"
                        }]
                    },
                    featuredProducts: {
                        badge: "Trending now",
                        title: {
                            beforeHighlight: "Pages people are ",
                            highlight: "sending right now."
                        },
                        buyNowCta: "Get this one",
                        customizeCta: "Make it yours",
                        previewCta: "Take a look",
                        priceSuffix: "one-time",
                        ratingValue: "4.9",
                        ratingCount: "(128)",
                        viewAllCta: "See all templates"
                    },
                    comparison: {
                        badge: "Why Cutiepage",
                        title: {
                            beforeHighlight: "Not another ",
                            highlight: "cheap Canva template"
                        },
                        description: "Anyone can hand you a flat file and call it a gift. We hand you a living page that is crafted, hosted, and ready to share in seconds.",
                        ours: "Cutiepage\u2122",
                        theirs: "Canva & other \u201ccreators\u201d",
                        theirsShort: "Others",
                        featureHeading: "Why CutiePage is best",
                        rows: [{
                            feature: "Ready to share",
                            ours: "Live in under 30 seconds",
                            theirs: "Hours of dragging and exporting",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "A real shareable link",
                            ours: "Clean link + live QR code",
                            theirs: "A static image or PDF",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "Edit after your page goes live",
                            ours: "Change anything, anytime",
                            theirs: "Start over from scratch",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "Looks great on phones",
                            ours: "Built mobile-first",
                            theirs: "Breaks outside the canvas",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "Design skill needed",
                            ours: "None, just fill it in",
                            theirs: "You do the heavy lifting",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "Pricing",
                            ours: "Pay once, use again and again",
                            theirs: "Subscriptions & hidden fees",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "Affordable rate",
                            ours: "Premium pages at a wallet-friendly price",
                            theirs: "You overpay for a flat file",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "Privacy first",
                            ours: "Lock your page behind a password",
                            theirs: "Anyone with the file can see it",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "Ads & watermarks",
                            ours: "Never, fully ad-free",
                            theirs: "Watermarks unless you pay more",
                            oursHas: !0,
                            theirsHas: !1
                        }, {
                            feature: "Real human support",
                            ours: "We reply within hours",
                            theirs: "You're on your own",
                            oursHas: !0,
                            theirsHas: !1
                        }],
                        footnote: "Made with care, delivered instantly. That's the whole difference.",
                        cta: "See it for yourself"
                    }
                },
                marquee: {
                    items: ["WEDDING PAGES", "BIRTHDAY PAGES", "MILESTONE MOMENTS", "PERSONAL STORIES", "PORTFOLIO PAGES", "CELEBRATION SITES", "SHARE A LINK", "MAKE IT YOURS"]
                },
                howItWorks: {
                    badge: "How it works",
                    title: {
                        beforeHighlight: "Four steps to ",
                        highlight: "one link."
                    },
                    description: "Pick a design, put yourself into it, and share the link with a cute QR. That's really it.",
                    steps: [{
                        number: "01",
                        title: "Pick a design",
                        description: "Choose a polished template that fits your moment."
                    }, {
                        number: "02",
                        title: "Make it yours",
                        description: "Add your words and photos, no design skills needed."
                    }, {
                        number: "03",
                        title: "Pay once",
                        description: "One simple payment when you're ready. No subscriptions."
                    }, {
                        number: "04",
                        title: "Share with a QR",
                        description: "Go live with a clean link and a matching QR code."
                    }]
                },
                statsBar: {
                    items: [{
                        value: "20000+",
                        label: "Orders fulfilled"
                    }, {
                        value: "70000+",
                        label: "Real users"
                    }, {
                        value: "30000+",
                        label: "Pages made"
                    }, {
                        value: "4.94/5",
                        label: "Rated by 2100+ people"
                    }]
                },
                homeCreatorProof: {
                    badge: "Creators on Cutiepage",
                    title: {
                        beforeHighlight: "Seen, made and loved by ",
                        highlight: "real creators"
                    },
                    description: "50+ influencers and creators have made a page on Cutiepage.",
                    screenshotsTitle: "And what people told us after"
                },
                reviews: {
                    metadata: {
                        title: "Reviews",
                        description: "50+ influencers and creators and 70,000+ users have tried Cutiepage. Watch real creator reviews and read real words from people who made a page for someone they love."
                    },
                    creators: {
                        badge: "Creators on Cutiepage",
                        title: {
                            beforeHighlight: "Seen, made and loved by ",
                            highlight: "real creators"
                        },
                        description: "More than 50+ influencers and creators, and 70,000+ users have tried Cutiepage, and we are actively growing. India's fast and most loved digital gifting platform.",
                        stats: [{
                            value: "50+",
                            label: "Influencers & creators"
                        }, {
                            value: "70,000+",
                            label: "Users have tried it"
                        }, {
                            value: "4.94/5",
                            label: "Average rating"
                        }]
                    }
                },
                subscribe: {
                    title: "Be first when something new drops",
                    formLabel: "Your email",
                    placeholder: "you@example.com",
                    submitCta: "Yes, keep me posted",
                    submittingCta: "Adding you...",
                    successMessage: "You're in. I'll reach out when there's something worth seeing.",
                    errorMessage: "Something went wrong on my end. Give it another go?"
                },
                auth: {
                    loginTitle: "Let's get you in",
                    loginDescription: "Free to join \xb7 No password needed",
                    googleCta: "Continue with Google",
                    loadingGoogleCta: "Taking you to Google...",
                    callbackError: "That sign-in didn't work \u2014 want to try again?",
                    defaultError: "Something went wrong getting you signed in. If this keeps happening, drop me a message."
                },
                contact: {
                    metadata: {
                        title: "Contact",
                        description: "Got a question, a request, or just want to say hello? I'd genuinely love to hear from you."
                    },
                    faq: {
                        eyebrow: "Quick help",
                        title: "Quick help for some most asked issues",
                        items: [{
                            question: "Did the payment but haven't got access?",
                            answer: "Access is granted automatically and usually unlocks instantly. If it doesn't, it will update within 15 minutes, but make sure you are properly logged in and you have refreshed the page. If it still hasn't unlocked after that, email us at support@cutiepage.in and mention the email ID you used and your payment ID (you'll find it in the Payments section of your dashboard)."
                        }, {
                            question: "Can I edit my page after it goes live?",
                            answer: "Yes. You buy once and use it multiple times. Your page stays fully editable from your dashboard after it goes live, and there is no limit on how many times you can edit and update your live page. Make your changes and they'll go live on the same shareable link, no need to pay again."
                        }, {
                            question: "Is my page private?",
                            answer: "Cutiepage is privacy first. When you make your page live, you set a password on your page, so only the people you share the password with can open your link. Nobody stumbles onto your moment by accident."
                        }, {
                            question: "I was charged but the payment shows as failed \u2014 what now?",
                            answer: "Banks sometimes hold a charge even when the payment didn't go through. These are released automatically, usually within 5\u20137 working days. If it doesn't reverse, email us at support@cutiepage.in with your email ID and payment ID and we'll help sort it out."
                        }, {
                            question: "Do you offer refunds?",
                            answer: "If something genuinely went wrong with your purchase, reach out at support@cutiepage.in with your email ID and payment ID and we'll make it right."
                        }, {
                            question: "Can I request a custom template?",
                            answer: "Absolutely \u2014 that's our favourite kind of message. Tell us what you have in mind through the contact form below and we'll let you know what's possible."
                        }]
                    },
                    title: "Still having an issue? Contact us",
                    infoCards: [{
                        label: "Email us",
                        value: "support@cutiepage.in"
                    }, {
                        label: "We reply within",
                        value: "5 hours"
                    }, {
                        label: "Based in",
                        value: "India \uD83C\uDDEE\uD83C\uDDF3"
                    }],
                    legalEntity: "Legal name: PINAK KUNDU. CutiePage (cutiepage.in) is owned and operated by PINAK KUNDU, India.",
                    sentTitle: "Got it, thank you!",
                    sentDescription: "We'll write back within 5 hours. Looking forward to it.",
                    form: {
                        nameLabel: "Your name",
                        namePlaceholder: "What should we call you?",
                        emailLabel: "Your email",
                        emailPlaceholder: "you@example.com",
                        messageLabel: "What's on your mind?",
                        messagePlaceholder: "Tell us what you're thinking...",
                        sendCta: "Send message",
                        sendingCta: "Sending..."
                    }
                },
                productsPage: {
                    browse: {
                        occasionsEyebrow: "Browse by occasion",
                        coverExploreCta: "Explore",
                        coverCountSuffix: "designs",
                        coverCountSingular: "design",
                        collectionsEyebrow: "Collection",
                        collectionComingSoon: "First drop coming soon",
                        collectionExploreCta: "Enter the collection",
                        trendingTitle: "Trending now",
                        seeAllCta: "See all templates",
                        backToBrowseCta: "Back to occasions"
                    },
                    browseToggle: {
                        label: "Browse templates",
                        category: "By category",
                        product: "By product"
                    },
                    occasionPage: {
                        breadcrumbRoot: "Templates",
                        audienceTitleLead: "Every template works for",
                        audienceTitleAccent: "anyone.",
                        audienceBody: "Partner, best friend or family. Change every word and photo to fit them.",
                        countSuffix: "designs",
                        emptyTitle: "Designs for this occasion are on their way.",
                        emptyDescription: "We are adding templates here right now. Meanwhile, every other occasion is ready to personalise.",
                        emptyCta: "Browse other occasions",
                        otherOccasionsEyebrow: "Other occasions",
                        otherOccasionsTitle: "Not quite this one?",
                        faqEyebrow: "Questions"
                    },
                    collectionPage: {
                        breadcrumbRoot: "Templates",
                        breadcrumbCollections: "Collections",
                        countSuffix: "designs in the collection",
                        notifyHint: "Follow @cutiepage for the drop date.",
                        backCta: "Browse by occasion"
                    },
                    metadata: {
                        title: "Templates",
                        description: "Designs for weddings, birthdays, milestones, portfolios \u2014 and any moment worth a page of its own."
                    },
                    listing: {
                        title: "Pick a template, make it first, pay later",
                        showingPrefix: "Showing",
                        showingConnector: "of",
                        showingSuffix: "designs",
                        filtersTitle: "Filter",
                        categoryTitle: "Category",
                        priceTitle: "Price",
                        resetFiltersCta: "Reset filters",
                        categoryOptions: {
                            all: "All"
                        },
                        priceOptions: {
                            all: "Any price",
                            under100: "Under \u20b9100",
                            between100And300: "\u20b9100 to \u20b9300",
                            above300: "Above \u20b9300"
                        },
                        searchPlaceholder: "Search templates",
                        emptyState: {
                            title: "No templates found",
                            description: "Try another category or price.",
                            clearCta: "Clear filters"
                        },
                        typeToggle: {
                            label: "Product type",
                            digital: "Templates",
                            gifts: "Gifts"
                        }
                    },
                    giftsListing: {
                        eyebrow: "Gifts",
                        title: "Something they can hold.",
                        pairedOffer: {
                            label: "Paired gift",
                            buy: "Buy a physical gift",
                            connector: "+",
                            free: "get a digital CutiePage free",
                            note: "Digital gift is delivered instantly. Physical gift arrives in 5-7 days.",
                            points: ["Every physical gift qualifies", "Yours for life", "No extra cost, ever"]
                        },
                        showingPrefix: "Showing",
                        showingConnector: "of",
                        showingSuffix: "gifts",
                        occasionTitle: "Occasion",
                        categoryOptions: {
                            all: "All gifts"
                        },
                        occasionOptions: {
                            all: "Any occasion"
                        },
                        priceOptions: {
                            all: "Any price",
                            under499: "Under Rs. 499",
                            between500And999: "Rs. 500 - 999",
                            between1000And1999: "Rs. 1,000 - 1,999",
                            above2000: "Rs. 2,000+"
                        },
                        searchPlaceholder: "Search gifts",
                        emptyState: {
                            title: "No gifts match those filters.",
                            description: "Try a different category or occasion to bring the collection back.",
                            clearCta: "Clear filters"
                        },
                        comingSoon: {
                            title: "The gift collection is on its way.",
                            description: "We're stocking the shelves right now. Meanwhile, every template is ready to customise.",
                            cta: "Browse templates"
                        },
                        grid: {
                            fromPrefix: "from",
                            outOfStock: "Out of stock",
                            viewCta: "View",
                            addToCartCta: "Add to cart",
                            addedCta: "Added",
                            buyNowCta: "Buy now",
                            variantHint: "options"
                        }
                    },
                    hero: {
                        badge: "Pick something you love",
                        title: {
                            beforeHighlight: "A page for ",
                            highlight: "your moment"
                        },
                        description: "Every template here is already designed and ready. Find the one that fits, fill it with your story, and share a link people will actually open."
                    },
                    grid: {
                        buyNowCta: "Get this one",
                        customizeCta: "Make it yours",
                        previewCta: "Take a look",
                        priceSuffix: "one-time",
                        ratingValue: "4.9",
                        ratingCount: "(128)"
                    },
                    detail: {
                        reviewLabelSuffix: "platform rating",
                        customizeCta: "Make it yours",
                        payLaterCta: "Make it first, pay later",
                        previewCta: "Take a preview",
                        priceCurrencySuffix: "INR",
                        description: "This is NOT a cheap Canva template. Every page is professionally designed and animated by our team. You just fill in your details and it is ready to share in 30 seconds. And you only buy it once: edit your page and update your live page as many times as you like, on the same link, at no extra cost.",
                        descriptionPoints: [{
                            title: "Fully customisable",
                            text: "Every photo, name and word on this page is yours to change. Make it about the two of you, not the sample you are looking at."
                        }, {
                            title: "Made by professionals",
                            text: "Designed and animated by real designers. A premium, one of a kind page, not a recycled Canva graphic."
                        }, {
                            title: "Ready in 30 seconds",
                            text: "No design skills needed. Just add your photos, names and words, and your page is live."
                        }, {
                            title: "Feels expensive and personal",
                            text: "Looks like it was made just for them. Way better than a plain text or a flat card."
                        }, {
                            title: "Fill, make it live, share",
                            text: "Add your details, hit Make it live, and share the link or QR code. That is it."
                        }],
                        whatYouGetTitle: "What You'll Get",
                        whatYouGet: [{
                            title: "Buy once, use multiple times",
                            description: "You pay once. After that you get unlimited edits: change your page and update your live page as many times as you want, and nothing extra to pay. Every update goes to the same shareable link, so whatever you made live last is what your link shows. Anyone who already has the link keeps seeing your newest version."
                        }, {
                            title: "Mobile responsive",
                            description: "Built to look clean and feel easy to open on phones, where most people will actually view it."
                        }, {
                            title: "Privacy first, password protected",
                            description: "Lock your live page behind a password so only the people you share it with can open the link."
                        }, {
                            title: "Add your own domain",
                            description: "Already own a domain? Point it at your page in a few clicks and share it on your own web address instead of ours. Optional, and only if you want it."
                        }],
                        trustPoints: ["Professionally designed and animated. Not a cheap Canva template you have seen a hundred times.", "Privacy first. Add a password so only the right people can open your page.", "Made for mobile so your loved one can open it instantly, anywhere."],
                        ratings: {
                            sectionTitle: "Ratings and reviews",
                            summary: "Clean, reliable, and easy to personalise.",
                            breakdown: [{
                                label: "5",
                                value: 88
                            }, {
                                label: "4",
                                value: 9
                            }, {
                                label: "3",
                                value: 0
                            }, {
                                label: "2",
                                value: 0
                            }, {
                                label: "1",
                                value: 0
                            }],
                            verifiedReviewLabel: "Verified review"
                        },
                        recommendations: {
                            eyebrow: "You might also like",
                            title: "More templates worth a look.",
                            badge: "Handpicked for you",
                            emptyTitle: "Nothing here just yet.",
                            emptyDescription: "As soon as we add more templates, matching recommendations will show up here automatically."
                        }
                    }
                }
            }
        }
    }
]);