"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [89655], {
        17552: (e, t, i) => {
            i.d(t, {
                R: () => d
            });
            var a = i(73365),
                n = i(58872),
                s = i(99568),
                o = i.n(s),
                r = i(54872);
            let p = {
                    dark: {
                        name: "text-cp-ink",
                        by: "text-cp-muted"
                    },
                    light: {
                        name: "text-white",
                        by: "text-white/55"
                    }
                },
                l = {
                    sm: {
                        name: "text-[15px] leading-none",
                        by: "text-[9px] leading-none tracking-[0.18em]",
                        gap: "gap-[3px]",
                        logo: 28
                    },
                    md: {
                        name: "text-[17px] leading-none",
                        by: "text-[10px] leading-none tracking-[0.18em]",
                        gap: "gap-[4px]",
                        logo: 32
                    },
                    lg: {
                        name: "text-[22px] leading-none",
                        by: "text-[11px] leading-none tracking-[0.18em]",
                        gap: "gap-[5px]",
                        logo: 40
                    }
                };

            function d({
                href: e = "/",
                tone: t = "dark",
                size: i = "md",
                align: s = "start",
                className: c,
                showLogo: h = !1,
                withWordmark: g = !1,
                hideWordmarkOnMobile: u = !1
            }) {
                let m = p[t],
                    f = l[i],
                    A = (0, a.jsx)("span", {
                        "aria-hidden": !0,
                        className: "align-super text-[0.5em] font-medium tracking-normal",
                        children: "\u2122"
                    }),
                    b = (0, a.jsxs)("span", {
                        className: (0, r.cn)("inline-flex flex-col", "center" === s ? "items-center" : "end" === s ? "items-end" : "items-start", f.gap),
                        children: [(0, a.jsxs)("span", {
                            className: (0, r.cn)("font-sans font-semibold tracking-[-0.02em]", m.name, f.name),
                            children: ["Cutiepage", A]
                        }), (0, a.jsx)("span", {
                            className: (0, r.cn)("font-medium uppercase", m.by, f.by),
                            children: "by pinak"
                        })]
                    }),
                    w = h ? (0, a.jsx)(n.default, {
                        src: "/brand/logo.webp",
                        alt: "Cutiepage",
                        width: f.logo,
                        height: f.logo,
                        priority: !0,
                        fetchPriority: "high",
                        sizes: `${f.logo}px`,
                        className: (0, r.cn)("shrink-0", g ? void 0 : c),
                        style: {
                            width: f.logo,
                            height: f.logo
                        }
                    }) : null,
                    v = h ? g ? (0, a.jsxs)("span", {
                        className: (0, r.cn)("inline-flex items-center gap-2", c),
                        children: [w, (0, a.jsxs)("span", {
                            "aria-hidden": !0,
                            className: (0, r.cn)("font-sans font-semibold tracking-[-0.02em]", m.name, f.name, u && "hidden sm:inline"),
                            children: ["Cutiepage", A]
                        })]
                    }) : w : (0, a.jsx)("span", {
                        className: c,
                        children: b
                    });
                return e ? (0, a.jsx)(o(), {
                    href: e,
                    className: "inline-flex items-center rounded-lg no-underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cp-select",
                    children: v
                }) : v
            }
        },
        41786: (e, t, i) => {
            function a(e) {
                let t = new Set;
                for (let i of e) i.startsWith("sb-") && t.add(i);
                return [...t]
            }

            function n(e) {
                return e.some(s)
            }

            function s(e) {
                return e.startsWith("sb-") && (e.endsWith("-auth-token") || /-auth-token\.\d+$/.test(e))
            }

            function o(e) {
                return [...new Set(e.filter(s))]
            }

            function r(e) {
                return e ? e.split(";").map(e => e.split("=")[0] ? .trim()).filter(e => !!e) : []
            }
            i.d(t, {
                Bz: () => a,
                MB: () => r,
                hO: () => n,
                tr: () => o
            })
        },
        54872: (e, t, i) => {
            i.d(t, {
                cn: () => s
            });
            var a = i(68662),
                n = i(35490);

            function s(...e) {
                return (0, n.QP)((0, a.$)(e))
            }
        },
        91466: (e, t, i) => {
            i.d(t, {
                $l: () => l,
                MA: () => s,
                dk: () => o,
                k7: () => r,
                rG: () => p
            });
            let a = "https://cdn.cutiepage.in/static/home-film";

            function n(e, t, i) {
                let n, s;
                return [{
                    src: `${a}/festive-${e}-v1-av1.mp4`,
                    type: (n = t, `video/mp4; codecs="av01.0.${n}M.10"`)
                }, {
                    src: `${a}/festive-${e}-v1-hevc.mp4`,
                    type: (s = i, `video/mp4; codecs="hvc1.1.6.L${s}.90"`)
                }, {
                    src: `${a}/festive-${e}-v1-h264.mp4`,
                    type: 'video/mp4; codecs="avc1.640029"'
                }]
            }
            let s = {
                    look: "festive",
                    desktop: {
                        sources: n("desktop", "08", 120),
                        sdSources: n("desktop720", "05", 93),
                        posterAvif: `${a}/festive-desktop-v1-poster-1280.avif 1280w, ${a}/festive-desktop-v1-poster.avif 1920w`,
                        posterWebp: `${a}/festive-desktop-v1-poster-1280.webp 1280w, ${a}/festive-desktop-v1-poster.webp 1920w`,
                        posterJpg: `${a}/festive-desktop-v1-poster.jpg`,
                        width: 1920,
                        height: 1080,
                        placeholder: {
                            gradient: ["#403929", "#735e48", "#6b5b4a"],
                            lqip: "data:image/webp;base64,UklGRqwAAABXRUJQVlA4IKAAAACwBACdASoYAA4APu1iqU2ppaOiMAgBMB2JaACdMoAlsBWIfKO1bGjYST4w2igAAP7bYfBNyd277pnQ4DN+5vqhshRyhQcdI6jpU6HhKeZZEuh3iG0X/APVtwrvgtoAUSHnuhiE1hIQL/zVxTUZmVY18qJjiDgwTQm3u6S6PydlGfyOv3jgJ6j0sUsWZ9SLPdwQLwf0GcKgKez0ncbo3IAA"
                        }
                    },
                    mobile: {
                        sources: n("mobile", "04", 93),
                        posterAvif: `${a}/festive-mobile-v1-poster.avif`,
                        posterWebp: `${a}/festive-mobile-v1-poster.webp`,
                        posterJpg: `${a}/festive-mobile-v1-poster.jpg`,
                        width: 608,
                        height: 1080,
                        placeholder: {
                            gradient: ["#564532", "#a8765e", "#a38973"],
                            lqip: "data:image/webp;base64,UklGRr4AAABXRUJQVlA4ILIAAAAQBQCdASoOABkAPu1iqU2ppaOiMAgBMB2JbACdMoR3EGAPh51K0XMYNn3CMB5mSMWAAP7pRAzieY8FrtG+PL2ZS/4RDWwtUHaS9pKJTWT9XMZ/nVhSaN6xw20L9E+57m8XTt37F+EGKpTt4cL2iZ5XIJ71DGvgHMmyLQf8Ph2+tXMAJVmmZ72K/3o59Dk8vxxetp4BSnYfaN5klrh/guHg+GOGVWSSFNWtloef57xlR7wA"
                        }
                    }
                },
                o = {
                    desktop: {
                        mp4: `${a}/aura-desktop-v1.mp4`,
                        webm: `${a}/aura-desktop-v1.webm`,
                        posterAvif: `${a}/aura-desktop-v1-poster.avif`,
                        posterWebp: `${a}/aura-desktop-v1-poster.webp`,
                        posterJpg: `${a}/aura-desktop-v1-poster.jpg`,
                        width: 1280,
                        height: 720,
                        placeholder: {
                            gradient: ["#2b2f21", "#655b30", "#726434"],
                            lqip: "data:image/webp;base64,UklGRoAAAABXRUJQVlA4IHQAAADQAwCdASoYAA4APu1iqU2ppaQiMAgBMB2JZgC06CB991pM4TQVYgAA/unW990t2rIZ0Jlz95HOPFf3cMDeQbBQ5kT3HUwR61WK3so8HxjQBy4W3jWeOrIUeRrlUFdSD0y0D1B7gzPbHnOPbr7wHhB3pwAAAA=="
                        }
                    },
                    mobile: {
                        mp4: `${a}/aura-mobile-v1.mp4`,
                        webm: `${a}/aura-mobile-v1.webm`,
                        posterAvif: `${a}/aura-mobile-v1-poster.avif`,
                        posterWebp: `${a}/aura-mobile-v1-poster.webp`,
                        posterJpg: `${a}/aura-mobile-v1-poster.jpg`,
                        width: 720,
                        height: 1280,
                        placeholder: {
                            gradient: ["#383a26", "#625436", "#5a503b"],
                            lqip: "data:image/webp;base64,UklGRoYAAABXRUJQVlA4IHoAAAAwBACdASoOABkAPu1iqU2ppaOiMAgBMB2JagC7MoACn/4Tucf6F9Do6YAA/hnEZphsizCGnqbMZ4O/+rOIgaMw2PgL7VTRXOiKEvt7MnK92k2ZOW3h3tyRctjeMrYKegamnT6b/bxnbP+48zX13SIy+/HskSq2lLwAAA=="
                        }
                    }
                },
                r = {
                    occasionBirthday: {
                        name: "occasion-birthday-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    occasionAnniversary: {
                        name: "occasion-anniversary-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    occasionSorry: {
                        name: "occasion-sorry-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    occasionLongDistance: {
                        name: "occasion-long-distance-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    faqLetter: {
                        name: "faq-letter-v1",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 2e3
                    },
                    domainStudy: {
                        name: "domain-study-v1",
                        widths: [1200, 1920],
                        width: 1920,
                        height: 1200
                    },
                    storyDaylight: {
                        name: "story-daylight-v1",
                        widths: [1200, 1920],
                        width: 1920,
                        height: 1080
                    },
                    auraRose: {
                        name: "aura-rose-v2",
                        widths: [800, 1200, 1600],
                        width: 1600,
                        height: 1600
                    },
                    closing: {
                        name: "closing-v1",
                        widths: [1200, 1920],
                        width: 1920,
                        height: 1080
                    }
                };

            function p(e, t) {
                return e.widths.map(i => `${a}/${e.name}-${i}.${t} ${i}w`).join(", ")
            }

            function l(e, t = "jpg") {
                let i = e.widths[e.widths.length - 1];
                return `${a}/${e.name}-${i}.${t}`
            }
        },
        99195: (e, t, i) => {
            i.d(t, {
                L9: () => s,
                Nu: () => p,
                uy: () => o
            });
            var a = i(91466);

            function n(e) {
                return Date.parse(`${e}Z`) - 198e5
            }
            let s = ["for her", "for him", "for a best friend", "for your wife", "for your husband", "for anyone"],
                o = {
                    eyebrow: "India's best digital gifting platform",
                    titleLead: "Make a cute gift,",
                    titleAccent: "cute",
                    ctaLabel: "Let's make something cute!",
                    ctaHref: null,
                    secondaryHref: "/products",
                    secondaryLabel: "Browse all templates",
                    trustLine: "Serving users for 1.5 years \xb7 Loved by 70,000+ people till now",
                    points: ["Your photos, your words, a song", "Pay once, no subscription", "Private, password protected link", {
                        text: "Go live on your own domain",
                        featured: !0,
                        tag: "New"
                    }],
                    showcase: ["birthday-wish-2", "netflix-story", "cute-apology-website", "anniversary-special"],
                    stickers: ["bouquet", "catTulips"]
                },
                r = [{
                    id: "pujo-navratri-2026",
                    name: "Durga Puja and Navratri",
                    countdownTargetAtMs: n("2026-10-19T00:00:00"),
                    countdownLabel: "Ashtami in",
                    countdownEndedLabel: "Shubho Pujo \xb7 Happy Navratri",
                    retiresAtMs: n("2026-10-21T23:59:59"),
                    film: a.MA,
                    look: "festive",
                    hero: {
                        eyebrow: "",
                        greetings: [{
                            text: "\u09b6\u09c1\u09ad \u09b6\u09be\u09b0\u09a6\u09c0\u09af\u09bc\u09be",
                            lang: "bn"
                        }, {
                            text: "\u0936\u0941\u092d \u0928\u0935\u0930\u093e\u0924\u094d\u0930\u093f",
                            lang: "hi"
                        }],
                        titleLead: "Pujo date? Garba partner?",
                        titleMain: "Ask them with a page.",
                        points: ["Pujo pages, all in Bengali", "Navratri garba pages", "A personal link per guest", "Send it on WhatsApp", {
                            text: "Or we send it for you",
                            featured: !0,
                            tag: "New"
                        }],
                        ctaLabel: o.ctaLabel,
                        ctaHref: "#festive"
                    },
                    accent: "#ffc15e"
                }];

            function p(e) {
                return r.find(t => e <= t.retiresAtMs) ? ? null
            }
        }
    }
]);